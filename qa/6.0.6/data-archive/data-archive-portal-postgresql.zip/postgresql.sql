--
-- PostgreSQL database dump
--

SET statement_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = off;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET escape_string_warning = off;

SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: account_; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE account_ (
    accountid bigint NOT NULL,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    parentaccountid bigint,
    name character varying(75),
    legalname character varying(75),
    legalid character varying(75),
    legaltype character varying(75),
    siccode character varying(75),
    tickersymbol character varying(75),
    industry character varying(75),
    type_ character varying(75),
    size_ character varying(75)
);


ALTER TABLE public.account_ OWNER TO postgres;

--
-- Name: address; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE address (
    addressid bigint NOT NULL,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    classnameid bigint,
    classpk bigint,
    street1 character varying(75),
    street2 character varying(75),
    street3 character varying(75),
    city character varying(75),
    zip character varying(75),
    regionid bigint,
    countryid bigint,
    typeid integer,
    mailing boolean,
    primary_ boolean
);


ALTER TABLE public.address OWNER TO postgres;

--
-- Name: announcementsdelivery; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE announcementsdelivery (
    deliveryid bigint NOT NULL,
    companyid bigint,
    userid bigint,
    type_ character varying(75),
    email boolean,
    sms boolean,
    website boolean
);


ALTER TABLE public.announcementsdelivery OWNER TO postgres;

--
-- Name: announcementsentry; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE announcementsentry (
    uuid_ character varying(75),
    entryid bigint NOT NULL,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    classnameid bigint,
    classpk bigint,
    title character varying(75),
    content text,
    url text,
    type_ character varying(75),
    displaydate timestamp without time zone,
    expirationdate timestamp without time zone,
    priority integer,
    alert boolean
);


ALTER TABLE public.announcementsentry OWNER TO postgres;

--
-- Name: announcementsflag; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE announcementsflag (
    flagid bigint NOT NULL,
    userid bigint,
    createdate timestamp without time zone,
    entryid bigint,
    value integer
);


ALTER TABLE public.announcementsflag OWNER TO postgres;

--
-- Name: assetcategory; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE assetcategory (
    uuid_ character varying(75),
    categoryid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    parentcategoryid bigint,
    leftcategoryid bigint,
    rightcategoryid bigint,
    name character varying(75),
    title text,
    vocabularyid bigint
);


ALTER TABLE public.assetcategory OWNER TO postgres;

--
-- Name: assetcategoryproperty; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE assetcategoryproperty (
    categorypropertyid bigint NOT NULL,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    categoryid bigint,
    key_ character varying(75),
    value character varying(75)
);


ALTER TABLE public.assetcategoryproperty OWNER TO postgres;

--
-- Name: assetentries_assetcategories; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE assetentries_assetcategories (
    entryid bigint NOT NULL,
    categoryid bigint NOT NULL
);


ALTER TABLE public.assetentries_assetcategories OWNER TO postgres;

--
-- Name: assetentries_assettags; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE assetentries_assettags (
    entryid bigint NOT NULL,
    tagid bigint NOT NULL
);


ALTER TABLE public.assetentries_assettags OWNER TO postgres;

--
-- Name: assetentry; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE assetentry (
    entryid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    classnameid bigint,
    classpk bigint,
    classuuid character varying(75),
    visible boolean,
    startdate timestamp without time zone,
    enddate timestamp without time zone,
    publishdate timestamp without time zone,
    expirationdate timestamp without time zone,
    mimetype character varying(75),
    title character varying(255),
    description text,
    summary text,
    url text,
    height integer,
    width integer,
    priority double precision,
    viewcount integer
);


ALTER TABLE public.assetentry OWNER TO postgres;

--
-- Name: assetlink; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE assetlink (
    linkid bigint NOT NULL,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    entryid1 bigint,
    entryid2 bigint,
    type_ integer,
    weight integer
);


ALTER TABLE public.assetlink OWNER TO postgres;

--
-- Name: assettag; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE assettag (
    tagid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    name character varying(75),
    assetcount integer
);


ALTER TABLE public.assettag OWNER TO postgres;

--
-- Name: assettagproperty; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE assettagproperty (
    tagpropertyid bigint NOT NULL,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    tagid bigint,
    key_ character varying(75),
    value character varying(255)
);


ALTER TABLE public.assettagproperty OWNER TO postgres;

--
-- Name: assettagstats; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE assettagstats (
    tagstatsid bigint NOT NULL,
    tagid bigint,
    classnameid bigint,
    assetcount integer
);


ALTER TABLE public.assettagstats OWNER TO postgres;

--
-- Name: assetvocabulary; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE assetvocabulary (
    uuid_ character varying(75),
    vocabularyid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    name character varying(75),
    title text,
    description text,
    settings_ text
);


ALTER TABLE public.assetvocabulary OWNER TO postgres;

--
-- Name: blogsentry; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE blogsentry (
    uuid_ character varying(75),
    entryid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    title character varying(150),
    urltitle character varying(150),
    content text,
    displaydate timestamp without time zone,
    allowpingbacks boolean,
    allowtrackbacks boolean,
    trackbacks text,
    status integer,
    statusbyuserid bigint,
    statusbyusername character varying(75),
    statusdate timestamp without time zone
);


ALTER TABLE public.blogsentry OWNER TO postgres;

--
-- Name: blogsstatsuser; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE blogsstatsuser (
    statsuserid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    userid bigint,
    entrycount integer,
    lastpostdate timestamp without time zone,
    ratingstotalentries integer,
    ratingstotalscore double precision,
    ratingsaveragescore double precision
);


ALTER TABLE public.blogsstatsuser OWNER TO postgres;

--
-- Name: bookmarksentry; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE bookmarksentry (
    uuid_ character varying(75),
    entryid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    userid bigint,
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    folderid bigint,
    name character varying(255),
    url text,
    comments text,
    visits integer,
    priority integer
);


ALTER TABLE public.bookmarksentry OWNER TO postgres;

--
-- Name: bookmarksfolder; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE bookmarksfolder (
    uuid_ character varying(75),
    folderid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    userid bigint,
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    parentfolderid bigint,
    name character varying(75),
    description text
);


ALTER TABLE public.bookmarksfolder OWNER TO postgres;

--
-- Name: browsertracker; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE browsertracker (
    browsertrackerid bigint NOT NULL,
    userid bigint,
    browserkey bigint
);


ALTER TABLE public.browsertracker OWNER TO postgres;

--
-- Name: calevent; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE calevent (
    uuid_ character varying(75),
    eventid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    title character varying(75),
    description text,
    startdate timestamp without time zone,
    enddate timestamp without time zone,
    durationhour integer,
    durationminute integer,
    allday boolean,
    timezonesensitive boolean,
    type_ character varying(75),
    repeating boolean,
    recurrence text,
    remindby integer,
    firstreminder integer,
    secondreminder integer
);


ALTER TABLE public.calevent OWNER TO postgres;

--
-- Name: classname_; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE classname_ (
    classnameid bigint NOT NULL,
    value character varying(200)
);


ALTER TABLE public.classname_ OWNER TO postgres;

--
-- Name: clustergroup; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE clustergroup (
    clustergroupid bigint NOT NULL,
    name character varying(75),
    clusternodeids character varying(75),
    wholecluster boolean
);


ALTER TABLE public.clustergroup OWNER TO postgres;

--
-- Name: company; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE company (
    companyid bigint NOT NULL,
    accountid bigint,
    webid character varying(75),
    key_ text,
    virtualhost character varying(75),
    mx character varying(75),
    homeurl text,
    logoid bigint,
    system boolean,
    maxusers integer
);


ALTER TABLE public.company OWNER TO postgres;

--
-- Name: contact_; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE contact_ (
    contactid bigint NOT NULL,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    accountid bigint,
    parentcontactid bigint,
    firstname character varying(75),
    middlename character varying(75),
    lastname character varying(75),
    prefixid integer,
    suffixid integer,
    male boolean,
    birthday timestamp without time zone,
    smssn character varying(75),
    aimsn character varying(75),
    facebooksn character varying(75),
    icqsn character varying(75),
    jabbersn character varying(75),
    msnsn character varying(75),
    myspacesn character varying(75),
    skypesn character varying(75),
    twittersn character varying(75),
    ymsn character varying(75),
    employeestatusid character varying(75),
    employeenumber character varying(75),
    jobtitle character varying(100),
    jobclass character varying(75),
    hoursofoperation character varying(75)
);


ALTER TABLE public.contact_ OWNER TO postgres;

--
-- Name: counter; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE counter (
    name character varying(75) NOT NULL,
    currentid bigint
);


ALTER TABLE public.counter OWNER TO postgres;

--
-- Name: country; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE country (
    countryid bigint NOT NULL,
    name character varying(75),
    a2 character varying(75),
    a3 character varying(75),
    number_ character varying(75),
    idd_ character varying(75),
    active_ boolean
);


ALTER TABLE public.country OWNER TO postgres;

--
-- Name: cyrususer; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE cyrususer (
    userid character varying(75) NOT NULL,
    password_ character varying(75) NOT NULL
);


ALTER TABLE public.cyrususer OWNER TO postgres;

--
-- Name: cyrusvirtual; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE cyrusvirtual (
    emailaddress character varying(75) NOT NULL,
    userid character varying(75) NOT NULL
);


ALTER TABLE public.cyrusvirtual OWNER TO postgres;

--
-- Name: dlfileentry; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE dlfileentry (
    uuid_ character varying(75),
    fileentryid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    userid bigint,
    username character varying(75),
    versionuserid bigint,
    versionusername character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    folderid bigint,
    name character varying(255),
    extension character varying(75),
    title character varying(255),
    description text,
    extrasettings text,
    version character varying(75),
    size_ bigint,
    readcount integer
);


ALTER TABLE public.dlfileentry OWNER TO postgres;

--
-- Name: dlfilerank; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE dlfilerank (
    filerankid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    userid bigint,
    createdate timestamp without time zone,
    folderid bigint,
    name character varying(255)
);


ALTER TABLE public.dlfilerank OWNER TO postgres;

--
-- Name: dlfileshortcut; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE dlfileshortcut (
    uuid_ character varying(75),
    fileshortcutid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    folderid bigint,
    tofolderid bigint,
    toname character varying(255),
    status integer,
    statusbyuserid bigint,
    statusbyusername character varying(75),
    statusdate timestamp without time zone
);


ALTER TABLE public.dlfileshortcut OWNER TO postgres;

--
-- Name: dlfileversion; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE dlfileversion (
    fileversionid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    folderid bigint,
    name character varying(255),
    extension character varying(75),
    title character varying(75),
    description text,
    changelog character varying(75),
    extrasettings character varying(75),
    version character varying(75),
    size_ bigint,
    status integer,
    statusbyuserid bigint,
    statusbyusername character varying(75),
    statusdate timestamp without time zone
);


ALTER TABLE public.dlfileversion OWNER TO postgres;

--
-- Name: dlfolder; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE dlfolder (
    uuid_ character varying(75),
    folderid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    parentfolderid bigint,
    name character varying(100),
    description text,
    lastpostdate timestamp without time zone
);


ALTER TABLE public.dlfolder OWNER TO postgres;

--
-- Name: emailaddress; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE emailaddress (
    emailaddressid bigint NOT NULL,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    classnameid bigint,
    classpk bigint,
    address character varying(75),
    typeid integer,
    primary_ boolean
);


ALTER TABLE public.emailaddress OWNER TO postgres;

--
-- Name: expandocolumn; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE expandocolumn (
    columnid bigint NOT NULL,
    companyid bigint,
    tableid bigint,
    name character varying(75),
    type_ integer,
    defaultdata text,
    typesettings text
);


ALTER TABLE public.expandocolumn OWNER TO postgres;

--
-- Name: expandorow; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE expandorow (
    rowid_ bigint NOT NULL,
    companyid bigint,
    tableid bigint,
    classpk bigint
);


ALTER TABLE public.expandorow OWNER TO postgres;

--
-- Name: expandotable; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE expandotable (
    tableid bigint NOT NULL,
    companyid bigint,
    classnameid bigint,
    name character varying(75)
);


ALTER TABLE public.expandotable OWNER TO postgres;

--
-- Name: expandovalue; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE expandovalue (
    valueid bigint NOT NULL,
    companyid bigint,
    tableid bigint,
    columnid bigint,
    rowid_ bigint,
    classnameid bigint,
    classpk bigint,
    data_ text
);


ALTER TABLE public.expandovalue OWNER TO postgres;

--
-- Name: group_; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE group_ (
    groupid bigint NOT NULL,
    companyid bigint,
    creatoruserid bigint,
    classnameid bigint,
    classpk bigint,
    parentgroupid bigint,
    livegroupid bigint,
    name character varying(75),
    description text,
    type_ integer,
    typesettings text,
    friendlyurl character varying(100),
    active_ boolean
);


ALTER TABLE public.group_ OWNER TO postgres;

--
-- Name: groups_orgs; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE groups_orgs (
    groupid bigint NOT NULL,
    organizationid bigint NOT NULL
);


ALTER TABLE public.groups_orgs OWNER TO postgres;

--
-- Name: groups_permissions; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE groups_permissions (
    groupid bigint NOT NULL,
    permissionid bigint NOT NULL
);


ALTER TABLE public.groups_permissions OWNER TO postgres;

--
-- Name: groups_roles; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE groups_roles (
    groupid bigint NOT NULL,
    roleid bigint NOT NULL
);


ALTER TABLE public.groups_roles OWNER TO postgres;

--
-- Name: groups_usergroups; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE groups_usergroups (
    groupid bigint NOT NULL,
    usergroupid bigint NOT NULL
);


ALTER TABLE public.groups_usergroups OWNER TO postgres;

--
-- Name: igfolder; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE igfolder (
    uuid_ character varying(75),
    folderid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    userid bigint,
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    parentfolderid bigint,
    name character varying(75),
    description text
);


ALTER TABLE public.igfolder OWNER TO postgres;

--
-- Name: igimage; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE igimage (
    uuid_ character varying(75),
    imageid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    userid bigint,
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    folderid bigint,
    name character varying(75),
    description text,
    smallimageid bigint,
    largeimageid bigint,
    custom1imageid bigint,
    custom2imageid bigint
);


ALTER TABLE public.igimage OWNER TO postgres;

--
-- Name: image; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE image (
    imageid bigint NOT NULL,
    modifieddate timestamp without time zone,
    text_ text,
    type_ character varying(75),
    height integer,
    width integer,
    size_ integer
);


ALTER TABLE public.image OWNER TO postgres;

--
-- Name: journalarticle; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE journalarticle (
    uuid_ character varying(75),
    id_ bigint NOT NULL,
    resourceprimkey bigint,
    groupid bigint,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    articleid character varying(75),
    version double precision,
    title character varying(300),
    urltitle character varying(150),
    description text,
    content text,
    type_ character varying(75),
    structureid character varying(75),
    templateid character varying(75),
    displaydate timestamp without time zone,
    expirationdate timestamp without time zone,
    reviewdate timestamp without time zone,
    indexable boolean,
    smallimage boolean,
    smallimageid bigint,
    smallimageurl text,
    status integer,
    statusbyuserid bigint,
    statusbyusername character varying(75),
    statusdate timestamp without time zone
);


ALTER TABLE public.journalarticle OWNER TO postgres;

--
-- Name: journalarticleimage; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE journalarticleimage (
    articleimageid bigint NOT NULL,
    groupid bigint,
    articleid character varying(75),
    version double precision,
    elinstanceid character varying(75),
    elname character varying(75),
    languageid character varying(75),
    tempimage boolean
);


ALTER TABLE public.journalarticleimage OWNER TO postgres;

--
-- Name: journalarticleresource; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE journalarticleresource (
    uuid_ character varying(75),
    resourceprimkey bigint NOT NULL,
    groupid bigint,
    articleid character varying(75)
);


ALTER TABLE public.journalarticleresource OWNER TO postgres;

--
-- Name: journalcontentsearch; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE journalcontentsearch (
    contentsearchid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    privatelayout boolean,
    layoutid bigint,
    portletid character varying(200),
    articleid character varying(75)
);


ALTER TABLE public.journalcontentsearch OWNER TO postgres;

--
-- Name: journalfeed; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE journalfeed (
    uuid_ character varying(75),
    id_ bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    feedid character varying(75),
    name character varying(75),
    description text,
    type_ character varying(75),
    structureid character varying(75),
    templateid character varying(75),
    renderertemplateid character varying(75),
    delta integer,
    orderbycol character varying(75),
    orderbytype character varying(75),
    targetlayoutfriendlyurl character varying(255),
    targetportletid character varying(75),
    contentfield character varying(75),
    feedtype character varying(75),
    feedversion double precision
);


ALTER TABLE public.journalfeed OWNER TO postgres;

--
-- Name: journalstructure; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE journalstructure (
    uuid_ character varying(75),
    id_ bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    structureid character varying(75),
    parentstructureid character varying(75),
    name character varying(75),
    description text,
    xsd text
);


ALTER TABLE public.journalstructure OWNER TO postgres;

--
-- Name: journaltemplate; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE journaltemplate (
    uuid_ character varying(75),
    id_ bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    templateid character varying(75),
    structureid character varying(75),
    name character varying(75),
    description text,
    xsl text,
    langtype character varying(75),
    cacheable boolean,
    smallimage boolean,
    smallimageid bigint,
    smallimageurl text
);


ALTER TABLE public.journaltemplate OWNER TO postgres;

--
-- Name: layout; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE layout (
    uuid_ character varying(75),
    plid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    privatelayout boolean,
    layoutid bigint,
    parentlayoutid bigint,
    name text,
    title text,
    description text,
    type_ character varying(75),
    typesettings text,
    hidden_ boolean,
    friendlyurl character varying(255),
    iconimage boolean,
    iconimageid bigint,
    themeid character varying(75),
    colorschemeid character varying(75),
    wapthemeid character varying(75),
    wapcolorschemeid character varying(75),
    css text,
    priority integer,
    layoutprototypeid bigint,
    dlfolderid bigint
);


ALTER TABLE public.layout OWNER TO postgres;

--
-- Name: layoutprototype; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE layoutprototype (
    layoutprototypeid bigint NOT NULL,
    companyid bigint,
    name text,
    description text,
    settings_ text,
    active_ boolean
);


ALTER TABLE public.layoutprototype OWNER TO postgres;

--
-- Name: layoutset; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE layoutset (
    layoutsetid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    privatelayout boolean,
    logo boolean,
    logoid bigint,
    themeid character varying(75),
    colorschemeid character varying(75),
    wapthemeid character varying(75),
    wapcolorschemeid character varying(75),
    css text,
    pagecount integer,
    virtualhost character varying(75),
    settings_ text,
    layoutsetprototypeid bigint
);


ALTER TABLE public.layoutset OWNER TO postgres;

--
-- Name: layoutsetprototype; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE layoutsetprototype (
    layoutsetprototypeid bigint NOT NULL,
    companyid bigint,
    name text,
    description text,
    settings_ text,
    active_ boolean
);


ALTER TABLE public.layoutsetprototype OWNER TO postgres;

--
-- Name: listtype; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE listtype (
    listtypeid integer NOT NULL,
    name character varying(75),
    type_ character varying(75)
);


ALTER TABLE public.listtype OWNER TO postgres;

--
-- Name: lock_; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE lock_ (
    uuid_ character varying(75),
    lockid bigint NOT NULL,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    classname character varying(75),
    key_ character varying(200),
    owner character varying(75),
    inheritable boolean,
    expirationdate timestamp without time zone
);


ALTER TABLE public.lock_ OWNER TO postgres;

--
-- Name: mbban; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE mbban (
    banid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    banuserid bigint
);


ALTER TABLE public.mbban OWNER TO postgres;

--
-- Name: mbcategory; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE mbcategory (
    uuid_ character varying(75),
    categoryid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    parentcategoryid bigint,
    name character varying(75),
    description text,
    threadcount integer,
    messagecount integer,
    lastpostdate timestamp without time zone
);


ALTER TABLE public.mbcategory OWNER TO postgres;

--
-- Name: mbdiscussion; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE mbdiscussion (
    discussionid bigint NOT NULL,
    classnameid bigint,
    classpk bigint,
    threadid bigint
);


ALTER TABLE public.mbdiscussion OWNER TO postgres;

--
-- Name: mbmailinglist; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE mbmailinglist (
    uuid_ character varying(75),
    mailinglistid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    categoryid bigint,
    emailaddress character varying(75),
    inprotocol character varying(75),
    inservername character varying(75),
    inserverport integer,
    inusessl boolean,
    inusername character varying(75),
    inpassword character varying(75),
    inreadinterval integer,
    outemailaddress character varying(75),
    outcustom boolean,
    outservername character varying(75),
    outserverport integer,
    outusessl boolean,
    outusername character varying(75),
    outpassword character varying(75),
    active_ boolean
);


ALTER TABLE public.mbmailinglist OWNER TO postgres;

--
-- Name: mbmessage; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE mbmessage (
    uuid_ character varying(75),
    messageid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    classnameid bigint,
    classpk bigint,
    categoryid bigint,
    threadid bigint,
    rootmessageid bigint,
    parentmessageid bigint,
    subject character varying(75),
    body text,
    attachments boolean,
    anonymous boolean,
    priority double precision,
    allowpingbacks boolean,
    status integer,
    statusbyuserid bigint,
    statusbyusername character varying(75),
    statusdate timestamp without time zone
);


ALTER TABLE public.mbmessage OWNER TO postgres;

--
-- Name: mbmessageflag; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE mbmessageflag (
    messageflagid bigint NOT NULL,
    userid bigint,
    modifieddate timestamp without time zone,
    threadid bigint,
    messageid bigint,
    flag integer
);


ALTER TABLE public.mbmessageflag OWNER TO postgres;

--
-- Name: mbstatsuser; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE mbstatsuser (
    statsuserid bigint NOT NULL,
    groupid bigint,
    userid bigint,
    messagecount integer,
    lastpostdate timestamp without time zone
);


ALTER TABLE public.mbstatsuser OWNER TO postgres;

--
-- Name: mbthread; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE mbthread (
    threadid bigint NOT NULL,
    groupid bigint,
    categoryid bigint,
    rootmessageid bigint,
    messagecount integer,
    viewcount integer,
    lastpostbyuserid bigint,
    lastpostdate timestamp without time zone,
    priority double precision,
    status integer,
    statusbyuserid bigint,
    statusbyusername character varying(75),
    statusdate timestamp without time zone
);


ALTER TABLE public.mbthread OWNER TO postgres;

--
-- Name: membershiprequest; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE membershiprequest (
    membershiprequestid bigint NOT NULL,
    companyid bigint,
    userid bigint,
    createdate timestamp without time zone,
    groupid bigint,
    comments text,
    replycomments text,
    replydate timestamp without time zone,
    replieruserid bigint,
    statusid integer
);


ALTER TABLE public.membershiprequest OWNER TO postgres;

--
-- Name: organization_; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE organization_ (
    organizationid bigint NOT NULL,
    companyid bigint,
    parentorganizationid bigint,
    leftorganizationid bigint,
    rightorganizationid bigint,
    name character varying(100),
    type_ character varying(75),
    recursable boolean,
    regionid bigint,
    countryid bigint,
    statusid integer,
    comments text
);


ALTER TABLE public.organization_ OWNER TO postgres;

--
-- Name: orggrouppermission; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE orggrouppermission (
    organizationid bigint NOT NULL,
    groupid bigint NOT NULL,
    permissionid bigint NOT NULL
);


ALTER TABLE public.orggrouppermission OWNER TO postgres;

--
-- Name: orggrouprole; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE orggrouprole (
    organizationid bigint NOT NULL,
    groupid bigint NOT NULL,
    roleid bigint NOT NULL
);


ALTER TABLE public.orggrouprole OWNER TO postgres;

--
-- Name: orglabor; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE orglabor (
    orglaborid bigint NOT NULL,
    organizationid bigint,
    typeid integer,
    sunopen integer,
    sunclose integer,
    monopen integer,
    monclose integer,
    tueopen integer,
    tueclose integer,
    wedopen integer,
    wedclose integer,
    thuopen integer,
    thuclose integer,
    friopen integer,
    friclose integer,
    satopen integer,
    satclose integer
);


ALTER TABLE public.orglabor OWNER TO postgres;

--
-- Name: passwordpolicy; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE passwordpolicy (
    passwordpolicyid bigint NOT NULL,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    defaultpolicy boolean,
    name character varying(75),
    description text,
    changeable boolean,
    changerequired boolean,
    minage bigint,
    checksyntax boolean,
    allowdictionarywords boolean,
    minalphanumeric integer,
    minlength integer,
    minlowercase integer,
    minnumbers integer,
    minsymbols integer,
    minuppercase integer,
    history boolean,
    historycount integer,
    expireable boolean,
    maxage bigint,
    warningtime bigint,
    gracelimit integer,
    lockout boolean,
    maxfailure integer,
    lockoutduration bigint,
    requireunlock boolean,
    resetfailurecount bigint,
    resetticketmaxage bigint
);


ALTER TABLE public.passwordpolicy OWNER TO postgres;

--
-- Name: passwordpolicyrel; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE passwordpolicyrel (
    passwordpolicyrelid bigint NOT NULL,
    passwordpolicyid bigint,
    classnameid bigint,
    classpk bigint
);


ALTER TABLE public.passwordpolicyrel OWNER TO postgres;

--
-- Name: passwordtracker; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE passwordtracker (
    passwordtrackerid bigint NOT NULL,
    userid bigint,
    createdate timestamp without time zone,
    password_ character varying(75)
);


ALTER TABLE public.passwordtracker OWNER TO postgres;

--
-- Name: permission_; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE permission_ (
    permissionid bigint NOT NULL,
    companyid bigint,
    actionid character varying(75),
    resourceid bigint
);


ALTER TABLE public.permission_ OWNER TO postgres;

--
-- Name: phone; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE phone (
    phoneid bigint NOT NULL,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    classnameid bigint,
    classpk bigint,
    number_ character varying(75),
    extension character varying(75),
    typeid integer,
    primary_ boolean
);


ALTER TABLE public.phone OWNER TO postgres;

--
-- Name: pluginsetting; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE pluginsetting (
    pluginsettingid bigint NOT NULL,
    companyid bigint,
    pluginid character varying(75),
    plugintype character varying(75),
    roles text,
    active_ boolean
);


ALTER TABLE public.pluginsetting OWNER TO postgres;

--
-- Name: pollschoice; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE pollschoice (
    uuid_ character varying(75),
    choiceid bigint NOT NULL,
    questionid bigint,
    name character varying(75),
    description text
);


ALTER TABLE public.pollschoice OWNER TO postgres;

--
-- Name: pollsquestion; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE pollsquestion (
    uuid_ character varying(75),
    questionid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    title text,
    description text,
    expirationdate timestamp without time zone,
    lastvotedate timestamp without time zone
);


ALTER TABLE public.pollsquestion OWNER TO postgres;

--
-- Name: pollsvote; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE pollsvote (
    voteid bigint NOT NULL,
    userid bigint,
    questionid bigint,
    choiceid bigint,
    votedate timestamp without time zone
);


ALTER TABLE public.pollsvote OWNER TO postgres;

--
-- Name: portlet; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE portlet (
    id_ bigint NOT NULL,
    companyid bigint,
    portletid character varying(200),
    roles text,
    active_ boolean
);


ALTER TABLE public.portlet OWNER TO postgres;

--
-- Name: portletitem; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE portletitem (
    portletitemid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    name character varying(75),
    portletid character varying(75),
    classnameid bigint
);


ALTER TABLE public.portletitem OWNER TO postgres;

--
-- Name: portletpreferences; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE portletpreferences (
    portletpreferencesid bigint NOT NULL,
    ownerid bigint,
    ownertype integer,
    plid bigint,
    portletid character varying(200),
    preferences text
);


ALTER TABLE public.portletpreferences OWNER TO postgres;

--
-- Name: quartz_blob_triggers; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE quartz_blob_triggers (
    trigger_name character varying(80) NOT NULL,
    trigger_group character varying(80) NOT NULL,
    blob_data bytea
);


ALTER TABLE public.quartz_blob_triggers OWNER TO postgres;

--
-- Name: quartz_calendars; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE quartz_calendars (
    calendar_name character varying(80) NOT NULL,
    calendar bytea NOT NULL
);


ALTER TABLE public.quartz_calendars OWNER TO postgres;

--
-- Name: quartz_cron_triggers; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE quartz_cron_triggers (
    trigger_name character varying(80) NOT NULL,
    trigger_group character varying(80) NOT NULL,
    cron_expression character varying(80) NOT NULL,
    time_zone_id character varying(80)
);


ALTER TABLE public.quartz_cron_triggers OWNER TO postgres;

--
-- Name: quartz_fired_triggers; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE quartz_fired_triggers (
    entry_id character varying(95) NOT NULL,
    trigger_name character varying(80) NOT NULL,
    trigger_group character varying(80) NOT NULL,
    is_volatile boolean NOT NULL,
    instance_name character varying(80) NOT NULL,
    fired_time bigint NOT NULL,
    priority integer NOT NULL,
    state character varying(16) NOT NULL,
    job_name character varying(80),
    job_group character varying(80),
    is_stateful boolean,
    requests_recovery boolean
);


ALTER TABLE public.quartz_fired_triggers OWNER TO postgres;

--
-- Name: quartz_job_details; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE quartz_job_details (
    job_name character varying(80) NOT NULL,
    job_group character varying(80) NOT NULL,
    description character varying(120),
    job_class_name character varying(128) NOT NULL,
    is_durable boolean NOT NULL,
    is_volatile boolean NOT NULL,
    is_stateful boolean NOT NULL,
    requests_recovery boolean NOT NULL,
    job_data bytea
);


ALTER TABLE public.quartz_job_details OWNER TO postgres;

--
-- Name: quartz_job_listeners; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE quartz_job_listeners (
    job_name character varying(80) NOT NULL,
    job_group character varying(80) NOT NULL,
    job_listener character varying(80) NOT NULL
);


ALTER TABLE public.quartz_job_listeners OWNER TO postgres;

--
-- Name: quartz_locks; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE quartz_locks (
    lock_name character varying(40) NOT NULL
);


ALTER TABLE public.quartz_locks OWNER TO postgres;

--
-- Name: quartz_paused_trigger_grps; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE quartz_paused_trigger_grps (
    trigger_group character varying(80) NOT NULL
);


ALTER TABLE public.quartz_paused_trigger_grps OWNER TO postgres;

--
-- Name: quartz_scheduler_state; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE quartz_scheduler_state (
    instance_name character varying(80) NOT NULL,
    last_checkin_time bigint NOT NULL,
    checkin_interval bigint NOT NULL
);


ALTER TABLE public.quartz_scheduler_state OWNER TO postgres;

--
-- Name: quartz_simple_triggers; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE quartz_simple_triggers (
    trigger_name character varying(80) NOT NULL,
    trigger_group character varying(80) NOT NULL,
    repeat_count bigint NOT NULL,
    repeat_interval bigint NOT NULL,
    times_triggered bigint NOT NULL
);


ALTER TABLE public.quartz_simple_triggers OWNER TO postgres;

--
-- Name: quartz_trigger_listeners; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE quartz_trigger_listeners (
    trigger_name character varying(80) NOT NULL,
    trigger_group character varying(80) NOT NULL,
    trigger_listener character varying(80) NOT NULL
);


ALTER TABLE public.quartz_trigger_listeners OWNER TO postgres;

--
-- Name: quartz_triggers; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE quartz_triggers (
    trigger_name character varying(80) NOT NULL,
    trigger_group character varying(80) NOT NULL,
    job_name character varying(80) NOT NULL,
    job_group character varying(80) NOT NULL,
    is_volatile boolean NOT NULL,
    description character varying(120),
    next_fire_time bigint,
    prev_fire_time bigint,
    priority integer,
    trigger_state character varying(16) NOT NULL,
    trigger_type character varying(8) NOT NULL,
    start_time bigint NOT NULL,
    end_time bigint,
    calendar_name character varying(80),
    misfire_instr integer,
    job_data bytea
);


ALTER TABLE public.quartz_triggers OWNER TO postgres;

--
-- Name: ratingsentry; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE ratingsentry (
    entryid bigint NOT NULL,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    classnameid bigint,
    classpk bigint,
    score double precision
);


ALTER TABLE public.ratingsentry OWNER TO postgres;

--
-- Name: ratingsstats; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE ratingsstats (
    statsid bigint NOT NULL,
    classnameid bigint,
    classpk bigint,
    totalentries integer,
    totalscore double precision,
    averagescore double precision
);


ALTER TABLE public.ratingsstats OWNER TO postgres;

--
-- Name: region; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE region (
    regionid bigint NOT NULL,
    countryid bigint,
    regioncode character varying(75),
    name character varying(75),
    active_ boolean
);


ALTER TABLE public.region OWNER TO postgres;

--
-- Name: release_; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE release_ (
    releaseid bigint NOT NULL,
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    servletcontextname character varying(75),
    buildnumber integer,
    builddate timestamp without time zone,
    verified boolean,
    teststring character varying(1024)
);


ALTER TABLE public.release_ OWNER TO postgres;

--
-- Name: resource_; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE resource_ (
    resourceid bigint NOT NULL,
    codeid bigint,
    primkey character varying(255)
);


ALTER TABLE public.resource_ OWNER TO postgres;

--
-- Name: resourceaction; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE resourceaction (
    resourceactionid bigint NOT NULL,
    name character varying(255),
    actionid character varying(75),
    bitwisevalue bigint
);


ALTER TABLE public.resourceaction OWNER TO postgres;

--
-- Name: resourcecode; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE resourcecode (
    codeid bigint NOT NULL,
    companyid bigint,
    name character varying(255),
    scope integer
);


ALTER TABLE public.resourcecode OWNER TO postgres;

--
-- Name: resourcepermission; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE resourcepermission (
    resourcepermissionid bigint NOT NULL,
    companyid bigint,
    name character varying(255),
    scope integer,
    primkey character varying(255),
    roleid bigint,
    actionids bigint
);


ALTER TABLE public.resourcepermission OWNER TO postgres;

--
-- Name: role_; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE role_ (
    roleid bigint NOT NULL,
    companyid bigint,
    classnameid bigint,
    classpk bigint,
    name character varying(75),
    title text,
    description text,
    type_ integer,
    subtype character varying(75)
);


ALTER TABLE public.role_ OWNER TO postgres;

--
-- Name: roles_permissions; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE roles_permissions (
    roleid bigint NOT NULL,
    permissionid bigint NOT NULL
);


ALTER TABLE public.roles_permissions OWNER TO postgres;

--
-- Name: scframeworkversi_scproductvers; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE scframeworkversi_scproductvers (
    frameworkversionid bigint NOT NULL,
    productversionid bigint NOT NULL
);


ALTER TABLE public.scframeworkversi_scproductvers OWNER TO postgres;

--
-- Name: scframeworkversion; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE scframeworkversion (
    frameworkversionid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    name character varying(75),
    url text,
    active_ boolean,
    priority integer
);


ALTER TABLE public.scframeworkversion OWNER TO postgres;

--
-- Name: sclicense; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE sclicense (
    licenseid bigint NOT NULL,
    name character varying(75),
    url text,
    opensource boolean,
    active_ boolean,
    recommended boolean
);


ALTER TABLE public.sclicense OWNER TO postgres;

--
-- Name: sclicenses_scproductentries; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE sclicenses_scproductentries (
    licenseid bigint NOT NULL,
    productentryid bigint NOT NULL
);


ALTER TABLE public.sclicenses_scproductentries OWNER TO postgres;

--
-- Name: scproductentry; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE scproductentry (
    productentryid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    name character varying(75),
    type_ character varying(75),
    tags character varying(255),
    shortdescription text,
    longdescription text,
    pageurl text,
    author character varying(75),
    repogroupid character varying(75),
    repoartifactid character varying(75)
);


ALTER TABLE public.scproductentry OWNER TO postgres;

--
-- Name: scproductscreenshot; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE scproductscreenshot (
    productscreenshotid bigint NOT NULL,
    companyid bigint,
    groupid bigint,
    productentryid bigint,
    thumbnailid bigint,
    fullimageid bigint,
    priority integer
);


ALTER TABLE public.scproductscreenshot OWNER TO postgres;

--
-- Name: scproductversion; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE scproductversion (
    productversionid bigint NOT NULL,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    productentryid bigint,
    version character varying(75),
    changelog text,
    downloadpageurl text,
    directdownloadurl character varying(2000),
    repostoreartifact boolean
);


ALTER TABLE public.scproductversion OWNER TO postgres;

--
-- Name: servicecomponent; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE servicecomponent (
    servicecomponentid bigint NOT NULL,
    buildnamespace character varying(75),
    buildnumber bigint,
    builddate bigint,
    data_ text
);


ALTER TABLE public.servicecomponent OWNER TO postgres;

--
-- Name: shard; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE shard (
    shardid bigint NOT NULL,
    classnameid bigint,
    classpk bigint,
    name character varying(75)
);


ALTER TABLE public.shard OWNER TO postgres;

--
-- Name: shoppingcart; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE shoppingcart (
    cartid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    itemids text,
    couponcodes character varying(75),
    altshipping integer,
    insure boolean
);


ALTER TABLE public.shoppingcart OWNER TO postgres;

--
-- Name: shoppingcategory; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE shoppingcategory (
    categoryid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    parentcategoryid bigint,
    name character varying(75),
    description text
);


ALTER TABLE public.shoppingcategory OWNER TO postgres;

--
-- Name: shoppingcoupon; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE shoppingcoupon (
    couponid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    code_ character varying(75),
    name character varying(75),
    description text,
    startdate timestamp without time zone,
    enddate timestamp without time zone,
    active_ boolean,
    limitcategories text,
    limitskus text,
    minorder double precision,
    discount double precision,
    discounttype character varying(75)
);


ALTER TABLE public.shoppingcoupon OWNER TO postgres;

--
-- Name: shoppingitem; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE shoppingitem (
    itemid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    categoryid bigint,
    sku character varying(75),
    name character varying(200),
    description text,
    properties text,
    fields_ boolean,
    fieldsquantities text,
    minquantity integer,
    maxquantity integer,
    price double precision,
    discount double precision,
    taxable boolean,
    shipping double precision,
    useshippingformula boolean,
    requiresshipping boolean,
    stockquantity integer,
    featured_ boolean,
    sale_ boolean,
    smallimage boolean,
    smallimageid bigint,
    smallimageurl text,
    mediumimage boolean,
    mediumimageid bigint,
    mediumimageurl text,
    largeimage boolean,
    largeimageid bigint,
    largeimageurl text
);


ALTER TABLE public.shoppingitem OWNER TO postgres;

--
-- Name: shoppingitemfield; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE shoppingitemfield (
    itemfieldid bigint NOT NULL,
    itemid bigint,
    name character varying(75),
    values_ text,
    description text
);


ALTER TABLE public.shoppingitemfield OWNER TO postgres;

--
-- Name: shoppingitemprice; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE shoppingitemprice (
    itempriceid bigint NOT NULL,
    itemid bigint,
    minquantity integer,
    maxquantity integer,
    price double precision,
    discount double precision,
    taxable boolean,
    shipping double precision,
    useshippingformula boolean,
    status integer
);


ALTER TABLE public.shoppingitemprice OWNER TO postgres;

--
-- Name: shoppingorder; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE shoppingorder (
    orderid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    number_ character varying(75),
    tax double precision,
    shipping double precision,
    altshipping character varying(75),
    requiresshipping boolean,
    insure boolean,
    insurance double precision,
    couponcodes character varying(75),
    coupondiscount double precision,
    billingfirstname character varying(75),
    billinglastname character varying(75),
    billingemailaddress character varying(75),
    billingcompany character varying(75),
    billingstreet character varying(75),
    billingcity character varying(75),
    billingstate character varying(75),
    billingzip character varying(75),
    billingcountry character varying(75),
    billingphone character varying(75),
    shiptobilling boolean,
    shippingfirstname character varying(75),
    shippinglastname character varying(75),
    shippingemailaddress character varying(75),
    shippingcompany character varying(75),
    shippingstreet character varying(75),
    shippingcity character varying(75),
    shippingstate character varying(75),
    shippingzip character varying(75),
    shippingcountry character varying(75),
    shippingphone character varying(75),
    ccname character varying(75),
    cctype character varying(75),
    ccnumber character varying(75),
    ccexpmonth integer,
    ccexpyear integer,
    ccvernumber character varying(75),
    comments text,
    pptxnid character varying(75),
    pppaymentstatus character varying(75),
    pppaymentgross double precision,
    ppreceiveremail character varying(75),
    pppayeremail character varying(75),
    sendorderemail boolean,
    sendshippingemail boolean
);


ALTER TABLE public.shoppingorder OWNER TO postgres;

--
-- Name: shoppingorderitem; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE shoppingorderitem (
    orderitemid bigint NOT NULL,
    orderid bigint,
    itemid character varying(75),
    sku character varying(75),
    name character varying(200),
    description text,
    properties text,
    price double precision,
    quantity integer,
    shippeddate timestamp without time zone
);


ALTER TABLE public.shoppingorderitem OWNER TO postgres;

--
-- Name: socialactivity; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE socialactivity (
    activityid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    userid bigint,
    createdate bigint,
    mirroractivityid bigint,
    classnameid bigint,
    classpk bigint,
    type_ integer,
    extradata text,
    receiveruserid bigint
);


ALTER TABLE public.socialactivity OWNER TO postgres;

--
-- Name: socialequityassetentry; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE socialequityassetentry (
    equityassetentryid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    userid bigint,
    assetentryid bigint,
    informationk double precision,
    informationb double precision
);


ALTER TABLE public.socialequityassetentry OWNER TO postgres;

--
-- Name: socialequitygroupsetting; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE socialequitygroupsetting (
    equitygroupsettingid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    classnameid bigint,
    type_ integer,
    enabled boolean
);


ALTER TABLE public.socialequitygroupsetting OWNER TO postgres;

--
-- Name: socialequityhistory; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE socialequityhistory (
    equityhistoryid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    userid bigint,
    createdate timestamp without time zone,
    personalequity integer
);


ALTER TABLE public.socialequityhistory OWNER TO postgres;

--
-- Name: socialequitylog; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE socialequitylog (
    equitylogid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    userid bigint,
    assetentryid bigint,
    actionid character varying(75),
    actiondate integer,
    active_ boolean,
    expiration integer,
    type_ integer,
    value integer
);


ALTER TABLE public.socialequitylog OWNER TO postgres;

--
-- Name: socialequitysetting; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE socialequitysetting (
    equitysettingid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    classnameid bigint,
    actionid character varying(75),
    dailylimit integer,
    lifespan integer,
    type_ integer,
    uniqueentry boolean,
    value integer
);


ALTER TABLE public.socialequitysetting OWNER TO postgres;

--
-- Name: socialequityuser; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE socialequityuser (
    equityuserid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    userid bigint,
    contributionk double precision,
    contributionb double precision,
    participationk double precision,
    participationb double precision,
    rank integer
);


ALTER TABLE public.socialequityuser OWNER TO postgres;

--
-- Name: socialrelation; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE socialrelation (
    uuid_ character varying(75),
    relationid bigint NOT NULL,
    companyid bigint,
    createdate bigint,
    userid1 bigint,
    userid2 bigint,
    type_ integer
);


ALTER TABLE public.socialrelation OWNER TO postgres;

--
-- Name: socialrequest; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE socialrequest (
    uuid_ character varying(75),
    requestid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    userid bigint,
    createdate bigint,
    modifieddate bigint,
    classnameid bigint,
    classpk bigint,
    type_ integer,
    extradata text,
    receiveruserid bigint,
    status integer
);


ALTER TABLE public.socialrequest OWNER TO postgres;

--
-- Name: subscription; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE subscription (
    subscriptionid bigint NOT NULL,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    classnameid bigint,
    classpk bigint,
    frequency character varying(75)
);


ALTER TABLE public.subscription OWNER TO postgres;

--
-- Name: tasksproposal; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE tasksproposal (
    proposalid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    classnameid bigint,
    classpk character varying(75),
    name character varying(75),
    description text,
    publishdate timestamp without time zone,
    duedate timestamp without time zone
);


ALTER TABLE public.tasksproposal OWNER TO postgres;

--
-- Name: tasksreview; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE tasksreview (
    reviewid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    proposalid bigint,
    assignedbyuserid bigint,
    assignedbyusername character varying(75),
    stage integer,
    completed boolean,
    rejected boolean
);


ALTER TABLE public.tasksreview OWNER TO postgres;

--
-- Name: team; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE team (
    teamid bigint NOT NULL,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    groupid bigint,
    name character varying(75),
    description text
);


ALTER TABLE public.team OWNER TO postgres;

--
-- Name: ticket; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE ticket (
    ticketid bigint NOT NULL,
    companyid bigint,
    createdate timestamp without time zone,
    classnameid bigint,
    classpk bigint,
    key_ character varying(75),
    expirationdate timestamp without time zone
);


ALTER TABLE public.ticket OWNER TO postgres;

--
-- Name: user_; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE user_ (
    uuid_ character varying(75),
    userid bigint NOT NULL,
    companyid bigint,
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    defaultuser boolean,
    contactid bigint,
    password_ character varying(75),
    passwordencrypted boolean,
    passwordreset boolean,
    passwordmodifieddate timestamp without time zone,
    digest character varying(255),
    reminderqueryquestion character varying(75),
    reminderqueryanswer character varying(75),
    gracelogincount integer,
    screenname character varying(75),
    emailaddress character varying(75),
    facebookid bigint,
    openid character varying(1024),
    portraitid bigint,
    languageid character varying(75),
    timezoneid character varying(75),
    greeting character varying(255),
    comments text,
    firstname character varying(75),
    middlename character varying(75),
    lastname character varying(75),
    jobtitle character varying(100),
    logindate timestamp without time zone,
    loginip character varying(75),
    lastlogindate timestamp without time zone,
    lastloginip character varying(75),
    lastfailedlogindate timestamp without time zone,
    failedloginattempts integer,
    lockout boolean,
    lockoutdate timestamp without time zone,
    agreedtotermsofuse boolean,
    active_ boolean
);


ALTER TABLE public.user_ OWNER TO postgres;

--
-- Name: usergroup; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE usergroup (
    usergroupid bigint NOT NULL,
    companyid bigint,
    parentusergroupid bigint,
    name character varying(75),
    description text
);


ALTER TABLE public.usergroup OWNER TO postgres;

--
-- Name: usergroupgrouprole; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE usergroupgrouprole (
    usergroupid bigint NOT NULL,
    groupid bigint NOT NULL,
    roleid bigint NOT NULL
);


ALTER TABLE public.usergroupgrouprole OWNER TO postgres;

--
-- Name: usergrouprole; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE usergrouprole (
    userid bigint NOT NULL,
    groupid bigint NOT NULL,
    roleid bigint NOT NULL
);


ALTER TABLE public.usergrouprole OWNER TO postgres;

--
-- Name: useridmapper; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE useridmapper (
    useridmapperid bigint NOT NULL,
    userid bigint,
    type_ character varying(75),
    description character varying(75),
    externaluserid character varying(75)
);


ALTER TABLE public.useridmapper OWNER TO postgres;

--
-- Name: users_groups; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE users_groups (
    userid bigint NOT NULL,
    groupid bigint NOT NULL
);


ALTER TABLE public.users_groups OWNER TO postgres;

--
-- Name: users_orgs; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE users_orgs (
    userid bigint NOT NULL,
    organizationid bigint NOT NULL
);


ALTER TABLE public.users_orgs OWNER TO postgres;

--
-- Name: users_permissions; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE users_permissions (
    userid bigint NOT NULL,
    permissionid bigint NOT NULL
);


ALTER TABLE public.users_permissions OWNER TO postgres;

--
-- Name: users_roles; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE users_roles (
    userid bigint NOT NULL,
    roleid bigint NOT NULL
);


ALTER TABLE public.users_roles OWNER TO postgres;

--
-- Name: users_teams; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE users_teams (
    userid bigint NOT NULL,
    teamid bigint NOT NULL
);


ALTER TABLE public.users_teams OWNER TO postgres;

--
-- Name: users_usergroups; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE users_usergroups (
    usergroupid bigint NOT NULL,
    userid bigint NOT NULL
);


ALTER TABLE public.users_usergroups OWNER TO postgres;

--
-- Name: usertracker; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE usertracker (
    usertrackerid bigint NOT NULL,
    companyid bigint,
    userid bigint,
    modifieddate timestamp without time zone,
    sessionid character varying(200),
    remoteaddr character varying(75),
    remotehost character varying(75),
    useragent character varying(200)
);


ALTER TABLE public.usertracker OWNER TO postgres;

--
-- Name: usertrackerpath; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE usertrackerpath (
    usertrackerpathid bigint NOT NULL,
    usertrackerid bigint,
    path_ text,
    pathdate timestamp without time zone
);


ALTER TABLE public.usertrackerpath OWNER TO postgres;

--
-- Name: vocabulary; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE vocabulary (
    vocabularyid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    name character varying(75),
    description character varying(75),
    folksonomy boolean
);


ALTER TABLE public.vocabulary OWNER TO postgres;

--
-- Name: webdavprops; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE webdavprops (
    webdavpropsid bigint NOT NULL,
    companyid bigint,
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    classnameid bigint,
    classpk bigint,
    props text
);


ALTER TABLE public.webdavprops OWNER TO postgres;

--
-- Name: website; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE website (
    websiteid bigint NOT NULL,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    classnameid bigint,
    classpk bigint,
    url text,
    typeid integer,
    primary_ boolean
);


ALTER TABLE public.website OWNER TO postgres;

--
-- Name: wikinode; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE wikinode (
    uuid_ character varying(75),
    nodeid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    name character varying(75),
    description text,
    lastpostdate timestamp without time zone
);


ALTER TABLE public.wikinode OWNER TO postgres;

--
-- Name: wikipage; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE wikipage (
    uuid_ character varying(75),
    pageid bigint NOT NULL,
    resourceprimkey bigint,
    groupid bigint,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    nodeid bigint,
    title character varying(255),
    version double precision,
    minoredit boolean,
    content text,
    summary text,
    format character varying(75),
    head boolean,
    parenttitle character varying(255),
    redirecttitle character varying(255),
    status integer,
    statusbyuserid bigint,
    statusbyusername character varying(75),
    statusdate timestamp without time zone
);


ALTER TABLE public.wikipage OWNER TO postgres;

--
-- Name: wikipageresource; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE wikipageresource (
    uuid_ character varying(75),
    resourceprimkey bigint NOT NULL,
    nodeid bigint,
    title character varying(255)
);


ALTER TABLE public.wikipageresource OWNER TO postgres;

--
-- Name: workflowdefinitionlink; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE workflowdefinitionlink (
    workflowdefinitionlinkid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    classnameid bigint,
    workflowdefinitionname character varying(75),
    workflowdefinitionversion integer
);


ALTER TABLE public.workflowdefinitionlink OWNER TO postgres;

--
-- Name: workflowinstancelink; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE workflowinstancelink (
    workflowinstancelinkid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    classnameid bigint,
    classpk bigint,
    workflowinstanceid bigint
);


ALTER TABLE public.workflowinstancelink OWNER TO postgres;

--
-- Data for Name: account_; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY account_ (accountid, companyid, userid, username, createdate, modifieddate, parentaccountid, name, legalname, legalid, legaltype, siccode, tickersymbol, industry, type_, size_) FROM stdin;
10134	10132	0		2015-12-03 01:22:40.972	2015-12-03 01:22:40.972	0	liferay.com								
\.


--
-- Data for Name: address; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY address (addressid, companyid, userid, username, createdate, modifieddate, classnameid, classpk, street1, street2, street3, city, zip, regionid, countryid, typeid, mailing, primary_) FROM stdin;
\.


--
-- Data for Name: announcementsdelivery; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY announcementsdelivery (deliveryid, companyid, userid, type_, email, sms, website) FROM stdin;
10392	10132	10386	general	f	f	f
10393	10132	10386	news	f	f	f
10394	10132	10386	test	f	f	f
\.


--
-- Data for Name: announcementsentry; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY announcementsentry (uuid_, entryid, companyid, userid, username, createdate, modifieddate, classnameid, classpk, title, content, url, type_, displaydate, expirationdate, priority, alert) FROM stdin;
\.


--
-- Data for Name: announcementsflag; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY announcementsflag (flagid, userid, createdate, entryid, value) FROM stdin;
\.


--
-- Data for Name: assetcategory; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY assetcategory (uuid_, categoryid, groupid, companyid, userid, username, createdate, modifieddate, parentcategoryid, leftcategoryid, rightcategoryid, name, title, vocabularyid) FROM stdin;
\.


--
-- Data for Name: assetcategoryproperty; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY assetcategoryproperty (categorypropertyid, companyid, userid, username, createdate, modifieddate, categoryid, key_, value) FROM stdin;
\.


--
-- Data for Name: assetentries_assetcategories; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY assetentries_assetcategories (entryid, categoryid) FROM stdin;
\.


--
-- Data for Name: assetentries_assettags; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY assetentries_assettags (entryid, tagid) FROM stdin;
\.


--
-- Data for Name: assetentry; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY assetentry (entryid, groupid, companyid, userid, username, createdate, modifieddate, classnameid, classpk, classuuid, visible, startdate, enddate, publishdate, expirationdate, mimetype, title, description, summary, url, height, width, priority, viewcount) FROM stdin;
10155	10149	10132	10135	 	2015-12-03 01:22:41.717	2015-12-03 01:22:41.717	10093	10153	16e8f319-c2cd-4b9a-bff3-a299b0478648	f	\N	\N	\N	\N	text/html	10152				0	0	0	0
10163	10157	10132	10135	 	2015-12-03 01:22:41.847	2015-12-03 01:22:41.847	10093	10161	e5622196-c37a-4c99-9a45-2eb92464d937	f	\N	\N	\N	\N	text/html	10160				0	0	0	0
10174	10165	10132	10169	Test Test	2015-12-03 01:22:42.073	2015-12-03 01:22:42.073	10046	10169	a7e72c6d-3283-47d9-8add-eb2cbb333f32	f	\N	\N	\N	\N		Test Test				0	0	0	0
10268	10171	10132	10169	Test Test	2015-12-03 01:23:31.958	2015-12-03 01:23:31.958	10093	10266	95aa411c-683f-4de5-92b1-2d73df720f32	f	\N	\N	\N	\N	text/html	10265				0	0	0	0
10273	10171	10132	10169	Test Test	2015-12-03 01:23:31.991	2015-12-03 01:23:31.991	10093	10271	5af9300f-eaff-4656-a09e-b42a2a97e778	f	\N	\N	\N	\N	text/html	10270				0	0	0	0
10281	10157	10132	10169	Test Test	2015-12-03 01:23:54.371	2015-12-03 01:23:54.371	10093	10279	7c3438b1-c7dc-4da5-835f-a0ed5d968843	f	\N	\N	\N	\N	text/html	10278				0	0	0	0
10296	10157	10132	10169	Test Test	2015-12-03 01:24:20.906	2015-12-03 01:24:20.906	10093	10294	4e574dc3-9eb8-4da1-a8a1-8cc111a1d58b	f	\N	\N	\N	\N	text/html	10291				0	0	0	0
10293	10157	10132	10169	Test Test	2015-12-03 01:24:20.889	2015-12-03 01:24:20.889	10084	10291	3c57c9c0-aa51-4fda-a3be-7aef0958745b	t	\N	\N	2015-12-03 01:24:00	\N	text/html	Web Content Title				0	0	0	2
10303	10157	10132	10169	Test Test	2015-12-03 01:24:43.062	2015-12-03 01:24:43.062	10093	10301	3941031b-0f34-40c9-965e-d3ca0139b189	f	\N	\N	\N	\N	text/html	10300				0	0	0	0
10314	10157	10132	10169	Test Test	2015-12-03 01:25:08.363	2015-12-03 01:25:08.363	10093	10312	6bda6825-5c36-4773-8976-2c975b865f7d	f	\N	\N	\N	\N	text/html	10309				0	0	0	0
10311	10157	10132	10169	Test Test	2015-12-03 01:25:08.345	2015-12-03 01:25:08.345	10073	10309	81237207-67c1-47fe-86ff-9abebe8e2a00	t	\N	\N	\N	\N	application/octet-stream	Document1				0	0	0	0
10322	10157	10132	10169	Test Test	2015-12-03 01:25:36.555	2015-12-03 01:25:36.555	10093	10320	983a655e-f0c8-4939-a21e-cb69d28c5009	f	\N	\N	\N	\N	text/html	10319				0	0	0	0
10330	10157	10132	10169	Test Test	2015-12-03 01:26:26.058	2015-12-03 01:26:26.058	10095	10328	988f6c87-79bb-43b7-b012-ead980730f89	t	\N	\N	\N	\N	text/html	Message Boards Subject				0	0	0	0
10337	10157	10132	10169	Test Test	2015-12-03 01:26:59.911	2015-12-03 01:26:59.911	10093	10335	8ec4078d-39ab-4634-8096-9eeda55eab43	f	\N	\N	\N	\N	text/html	10334				0	0	0	0
10349	10157	10132	10169	Test Test	2015-12-03 01:27:15.14	2015-12-03 01:27:15.14	10093	10347	4402e794-fed5-419c-a444-7b9d4a9dc873	f	\N	\N	\N	\N	text/html	10345				0	0	0	0
10352	10157	10132	10169	Test Test	2015-12-03 01:27:22.274	2015-12-03 01:27:22.274	10129	10351	855bc875-b286-49a5-88ce-4b1c22fd5eb9	f	\N	\N	\N	\N	text/html	FrontPage				0	0	0	0
10346	10157	10132	10169	Test Test	2015-12-03 01:27:15.134	2015-12-03 01:27:22.287	10129	10345	7803d80b-06be-46a5-848d-791a3409cc3d	t	\N	\N	\N	\N	text/html	FrontPage				0	0	0	3
10357	10157	10132	10169	Test Test	2015-12-03 01:27:45.663	2015-12-03 01:27:45.663	10093	10355	77932504-293f-47f9-8db2-de626b23053b	f	\N	\N	\N	\N	text/html	10354				0	0	0	0
10367	10157	10132	10169	Test Test	2015-12-03 01:28:15.455	2015-12-03 01:28:15.455	10093	10365	45f1b6ac-cfb7-499f-85a2-19491c6e6ba9	f	\N	\N	\N	\N	text/html	10363				0	0	0	0
10364	10157	10132	10169	Test Test	2015-12-03 01:28:15.433	2015-12-03 01:28:15.433	10068	10363	2ce59786-d672-47c2-ab6f-c0d17dce58b1	t	\N	\N	2015-12-03 01:28:00	\N	text/html	Blogs Entry Title		Blogs Entry Content		0	0	0	1
10377	10165	10132	10169	Test Test	2015-12-03 01:30:23.55	2015-12-03 01:30:23.55	10012	10374		f	\N	\N	\N	\N		Site Name				0	0	0	0
10381	10374	10132	10169	Test Test	2015-12-03 01:31:09.05	2015-12-03 01:31:09.05	10093	10379	f39e6547-30cb-4f02-9fc8-83788af62852	f	\N	\N	\N	\N	text/html	10378				0	0	0	0
10391	10165	10132	10169	Test Test	2015-12-03 01:32:09.948	2015-12-03 01:32:56.711	10046	10386	d93c3ccb-b3fb-42d7-b2b9-e67aefd61a9f	f	\N	\N	\N	\N		Userfn Userln				0	0	0	0
10398	10388	10132	10386	Userfn Userln	2015-12-03 01:33:32.12	2015-12-03 01:33:32.12	10093	10396	91260f20-91d9-49db-871c-dc7a062508e2	f	\N	\N	\N	\N	text/html	10395				0	0	0	0
10403	10388	10132	10386	Userfn Userln	2015-12-03 01:33:32.17	2015-12-03 01:33:32.17	10093	10401	55011292-5444-4ea0-b332-c5d8ab4c5fed	f	\N	\N	\N	\N	text/html	10400				0	0	0	0
\.


--
-- Data for Name: assetlink; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY assetlink (linkid, companyid, userid, username, createdate, entryid1, entryid2, type_, weight) FROM stdin;
\.


--
-- Data for Name: assettag; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY assettag (tagid, groupid, companyid, userid, username, createdate, modifieddate, name, assetcount) FROM stdin;
\.


--
-- Data for Name: assettagproperty; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY assettagproperty (tagpropertyid, companyid, userid, username, createdate, modifieddate, tagid, key_, value) FROM stdin;
\.


--
-- Data for Name: assettagstats; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY assettagstats (tagstatsid, tagid, classnameid, assetcount) FROM stdin;
\.


--
-- Data for Name: assetvocabulary; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY assetvocabulary (uuid_, vocabularyid, groupid, companyid, userid, username, createdate, modifieddate, name, title, description, settings_) FROM stdin;
d2b532a6-db7d-49b7-b6e5-c2406e351fd9	10316	10157	10132	10135	 	2015-12-03 01:25:21.055	2015-12-03 01:25:21.055	Topic	<?xml version='1.0' encoding='UTF-8'?><root available-locales="en_US" default-locale="en_US"><Title language-id="en_US">Topic</Title></root>		
7adfbac4-212d-47c0-ad8e-226a79674e16	10317	10165	10132	10135	 	2015-12-03 01:25:21.084	2015-12-03 01:25:21.084	Topic	<?xml version='1.0' encoding='UTF-8'?><root available-locales="en_US" default-locale="en_US"><Title language-id="en_US">Topic</Title></root>		
\.


--
-- Data for Name: blogsentry; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY blogsentry (uuid_, entryid, groupid, companyid, userid, username, createdate, modifieddate, title, urltitle, content, displaydate, allowpingbacks, allowtrackbacks, trackbacks, status, statusbyuserid, statusbyusername, statusdate) FROM stdin;
2ce59786-d672-47c2-ab6f-c0d17dce58b1	10363	10157	10132	10169	Test Test	2015-12-03 01:28:15.371	2015-12-03 01:28:15.468	Blogs Entry Title	blogs-entry-title	<p>\n\tBlogs Entry Content</p>	2015-12-03 01:28:00	t	t		0	10169	Test Test	2015-12-03 01:28:15.468
\.


--
-- Data for Name: blogsstatsuser; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY blogsstatsuser (statsuserid, groupid, companyid, userid, entrycount, lastpostdate, ratingstotalentries, ratingstotalscore, ratingsaveragescore) FROM stdin;
10369	10157	10132	10169	1	2015-12-03 01:28:00	0	0	0
\.


--
-- Data for Name: bookmarksentry; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY bookmarksentry (uuid_, entryid, groupid, companyid, userid, createdate, modifieddate, folderid, name, url, comments, visits, priority) FROM stdin;
\.


--
-- Data for Name: bookmarksfolder; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY bookmarksfolder (uuid_, folderid, groupid, companyid, userid, createdate, modifieddate, parentfolderid, name, description) FROM stdin;
\.


--
-- Data for Name: browsertracker; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY browsertracker (browsertrackerid, userid, browserkey) FROM stdin;
\.


--
-- Data for Name: calevent; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY calevent (uuid_, eventid, groupid, companyid, userid, username, createdate, modifieddate, title, description, startdate, enddate, durationhour, durationminute, allday, timezonesensitive, type_, repeating, recurrence, remindby, firstreminder, secondreminder) FROM stdin;
\.


--
-- Data for Name: classname_; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY classname_ (classnameid, value) FROM stdin;
10001	com.liferay.counter.model.Counter
10002	com.liferay.portal.kernel.workflow.WorkflowTask
10003	com.liferay.portal.model.Account
10004	com.liferay.portal.model.Address
10005	com.liferay.portal.model.BrowserTracker
10006	com.liferay.portal.model.ClassName
10007	com.liferay.portal.model.ClusterGroup
10008	com.liferay.portal.model.Company
10009	com.liferay.portal.model.Contact
10010	com.liferay.portal.model.Country
10011	com.liferay.portal.model.EmailAddress
10012	com.liferay.portal.model.Group
10013	com.liferay.portal.model.Image
10014	com.liferay.portal.model.Layout
10015	com.liferay.portal.model.LayoutPrototype
10016	com.liferay.portal.model.LayoutSet
10017	com.liferay.portal.model.LayoutSetPrototype
10018	com.liferay.portal.model.ListType
10019	com.liferay.portal.model.Lock
10020	com.liferay.portal.model.MembershipRequest
10021	com.liferay.portal.model.OrgGroupPermission
10022	com.liferay.portal.model.OrgGroupRole
10023	com.liferay.portal.model.OrgLabor
10024	com.liferay.portal.model.Organization
10025	com.liferay.portal.model.PasswordPolicy
10026	com.liferay.portal.model.PasswordPolicyRel
10027	com.liferay.portal.model.PasswordTracker
10028	com.liferay.portal.model.Permission
10029	com.liferay.portal.model.Phone
10030	com.liferay.portal.model.PluginSetting
10031	com.liferay.portal.model.Portlet
10032	com.liferay.portal.model.PortletItem
10033	com.liferay.portal.model.PortletPreferences
10034	com.liferay.portal.model.Region
10035	com.liferay.portal.model.Release
10036	com.liferay.portal.model.Resource
10037	com.liferay.portal.model.ResourceAction
10038	com.liferay.portal.model.ResourceCode
10039	com.liferay.portal.model.ResourcePermission
10040	com.liferay.portal.model.Role
10041	com.liferay.portal.model.ServiceComponent
10042	com.liferay.portal.model.Shard
10043	com.liferay.portal.model.Subscription
10044	com.liferay.portal.model.Team
10045	com.liferay.portal.model.Ticket
10046	com.liferay.portal.model.User
10047	com.liferay.portal.model.UserGroup
10048	com.liferay.portal.model.UserGroupGroupRole
10049	com.liferay.portal.model.UserGroupRole
10050	com.liferay.portal.model.UserIdMapper
10051	com.liferay.portal.model.UserTracker
10052	com.liferay.portal.model.UserTrackerPath
10053	com.liferay.portal.model.WebDAVProps
10054	com.liferay.portal.model.Website
10055	com.liferay.portal.model.WorkflowDefinitionLink
10056	com.liferay.portal.model.WorkflowInstanceLink
10057	com.liferay.portlet.announcements.model.AnnouncementsDelivery
10058	com.liferay.portlet.announcements.model.AnnouncementsEntry
10059	com.liferay.portlet.announcements.model.AnnouncementsFlag
10060	com.liferay.portlet.asset.model.AssetCategory
10061	com.liferay.portlet.asset.model.AssetCategoryProperty
10062	com.liferay.portlet.asset.model.AssetEntry
10063	com.liferay.portlet.asset.model.AssetLink
10064	com.liferay.portlet.asset.model.AssetTag
10065	com.liferay.portlet.asset.model.AssetTagProperty
10066	com.liferay.portlet.asset.model.AssetTagStats
10067	com.liferay.portlet.asset.model.AssetVocabulary
10068	com.liferay.portlet.blogs.model.BlogsEntry
10069	com.liferay.portlet.blogs.model.BlogsStatsUser
10070	com.liferay.portlet.bookmarks.model.BookmarksEntry
10071	com.liferay.portlet.bookmarks.model.BookmarksFolder
10072	com.liferay.portlet.calendar.model.CalEvent
10073	com.liferay.portlet.documentlibrary.model.DLFileEntry
10074	com.liferay.portlet.documentlibrary.model.DLFileRank
10075	com.liferay.portlet.documentlibrary.model.DLFileShortcut
10076	com.liferay.portlet.documentlibrary.model.DLFileVersion
10077	com.liferay.portlet.documentlibrary.model.DLFolder
10078	com.liferay.portlet.expando.model.ExpandoColumn
10079	com.liferay.portlet.expando.model.ExpandoRow
10080	com.liferay.portlet.expando.model.ExpandoTable
10081	com.liferay.portlet.expando.model.ExpandoValue
10082	com.liferay.portlet.imagegallery.model.IGFolder
10083	com.liferay.portlet.imagegallery.model.IGImage
10084	com.liferay.portlet.journal.model.JournalArticle
10085	com.liferay.portlet.journal.model.JournalArticleImage
10086	com.liferay.portlet.journal.model.JournalArticleResource
10087	com.liferay.portlet.journal.model.JournalContentSearch
10088	com.liferay.portlet.journal.model.JournalFeed
10089	com.liferay.portlet.journal.model.JournalStructure
10090	com.liferay.portlet.journal.model.JournalTemplate
10091	com.liferay.portlet.messageboards.model.MBBan
10092	com.liferay.portlet.messageboards.model.MBCategory
10093	com.liferay.portlet.messageboards.model.MBDiscussion
10094	com.liferay.portlet.messageboards.model.MBMailingList
10095	com.liferay.portlet.messageboards.model.MBMessage
10096	com.liferay.portlet.messageboards.model.MBMessageFlag
10097	com.liferay.portlet.messageboards.model.MBStatsUser
10098	com.liferay.portlet.messageboards.model.MBThread
10099	com.liferay.portlet.polls.model.PollsChoice
10100	com.liferay.portlet.polls.model.PollsQuestion
10101	com.liferay.portlet.polls.model.PollsVote
10102	com.liferay.portlet.ratings.model.RatingsEntry
10103	com.liferay.portlet.ratings.model.RatingsStats
10104	com.liferay.portlet.shopping.model.ShoppingCart
10105	com.liferay.portlet.shopping.model.ShoppingCategory
10106	com.liferay.portlet.shopping.model.ShoppingCoupon
10107	com.liferay.portlet.shopping.model.ShoppingItem
10108	com.liferay.portlet.shopping.model.ShoppingItemField
10109	com.liferay.portlet.shopping.model.ShoppingItemPrice
10110	com.liferay.portlet.shopping.model.ShoppingOrder
10111	com.liferay.portlet.shopping.model.ShoppingOrderItem
10112	com.liferay.portlet.social.model.SocialActivity
10113	com.liferay.portlet.social.model.SocialEquityAssetEntry
10114	com.liferay.portlet.social.model.SocialEquityGroupSetting
10115	com.liferay.portlet.social.model.SocialEquityHistory
10116	com.liferay.portlet.social.model.SocialEquityLog
10117	com.liferay.portlet.social.model.SocialEquitySetting
10118	com.liferay.portlet.social.model.SocialEquityUser
10119	com.liferay.portlet.social.model.SocialRelation
10120	com.liferay.portlet.social.model.SocialRequest
10121	com.liferay.portlet.softwarecatalog.model.SCFrameworkVersion
10122	com.liferay.portlet.softwarecatalog.model.SCLicense
10123	com.liferay.portlet.softwarecatalog.model.SCProductEntry
10124	com.liferay.portlet.softwarecatalog.model.SCProductScreenshot
10125	com.liferay.portlet.softwarecatalog.model.SCProductVersion
10126	com.liferay.portlet.tasks.model.TasksProposal
10127	com.liferay.portlet.tasks.model.TasksReview
10128	com.liferay.portlet.wiki.model.WikiNode
10129	com.liferay.portlet.wiki.model.WikiPage
10130	com.liferay.portlet.wiki.model.WikiPageResource
\.


--
-- Data for Name: clustergroup; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY clustergroup (clustergroupid, name, clusternodeids, wholecluster) FROM stdin;
\.


--
-- Data for Name: company; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY company (companyid, accountid, webid, key_, virtualhost, mx, homeurl, logoid, system, maxusers) FROM stdin;
10132	10134	liferay.com	rO0ABXNyABRqYXZhLnNlY3VyaXR5LktleVJlcL35T7OImqVDAgAETAAJYWxnb3JpdGhtdAASTGphdmEvbGFuZy9TdHJpbmc7WwAHZW5jb2RlZHQAAltCTAAGZm9ybWF0cQB+AAFMAAR0eXBldAAbTGphdmEvc2VjdXJpdHkvS2V5UmVwJFR5cGU7eHB0AANERVN1cgACW0Ks8xf4BghU4AIAAHhwAAAACAjgJeO8x2LcdAADUkFXfnIAGWphdmEuc2VjdXJpdHkuS2V5UmVwJFR5cGUAAAAAAAAAABIAAHhyAA5qYXZhLmxhbmcuRW51bQAAAAAAAAAAEgAAeHB0AAZTRUNSRVQ=	localhost	liferay.com		0	f	0
\.


--
-- Data for Name: contact_; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY contact_ (contactid, companyid, userid, username, createdate, modifieddate, accountid, parentcontactid, firstname, middlename, lastname, prefixid, suffixid, male, birthday, smssn, aimsn, facebooksn, icqsn, jabbersn, msnsn, myspacesn, skypesn, twittersn, ymsn, employeestatusid, employeenumber, jobtitle, jobclass, hoursofoperation) FROM stdin;
10136	10132	10135		2015-12-03 01:22:40.773	2015-12-03 01:22:40.773	10134	0				0	0	t	2015-12-03 01:22:40.773															
10170	10132	10169		2015-12-03 01:22:41.931	2015-12-03 01:22:41.931	10134	0	Test		Test	0	0	t	1970-01-01 00:00:00															
10387	10132	10169	Test Test	2015-12-03 01:32:09.278	2015-12-03 01:32:56.581	10134	0	Userfn		Userln	0	0	t	1970-01-01 00:00:00															
\.


--
-- Data for Name: counter; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY counter (name, currentid) FROM stdin;
com.liferay.portal.model.Resource	100
com.liferay.portal.model.Permission	100
com.liferay.portal.model.ResourceAction	700
com.liferay.portal.model.Layout#10149#true	1
com.liferay.portal.model.Layout#10171#true	1
com.liferay.portal.model.Layout#10171#false	1
com.liferay.portlet.documentlibrary.model.DLFileEntry	100
com.liferay.portlet.social.model.SocialActivity	100
com.liferay.portal.model.Layout#10157#false	6
com.liferay.portal.model.Layout#10374#false	1
com.liferay.portal.model.Layout#10388#true	1
com.liferay.portal.model.ResourcePermission	400
com.liferay.portal.model.Layout#10388#false	1
com.liferay.counter.model.Counter	10500
\.


--
-- Data for Name: country; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY country (countryid, name, a2, a3, number_, idd_, active_) FROM stdin;
1	Canada	CA	CAN	124	001	t
2	China	CN	CHN	156	086	t
3	France	FR	FRA	250	033	t
4	Germany	DE	DEU	276	049	t
5	Hong Kong	HK	HKG	344	852	t
6	Hungary	HU	HUN	348	036	t
7	Israel	IL	ISR	376	972	t
8	Italy	IT	ITA	380	039	t
9	Japan	JP	JPN	392	081	t
10	South Korea	KR	KOR	410	082	t
11	Netherlands	NL	NLD	528	031	t
12	Portugal	PT	PRT	620	351	t
13	Russia	RU	RUS	643	007	t
14	Singapore	SG	SGP	702	065	t
15	Spain	ES	ESP	724	034	t
16	Turkey	TR	TUR	792	090	t
17	Vietnam	VM	VNM	704	084	t
18	United Kingdom	GB	GBR	826	044	t
19	United States	US	USA	840	001	t
20	Afghanistan	AF	AFG	4	093	t
21	Albania	AL	ALB	8	355	t
22	Algeria	DZ	DZA	12	213	t
23	American Samoa	AS	ASM	16	684	t
24	Andorra	AD	AND	20	376	t
25	Angola	AO	AGO	24	244	t
26	Anguilla	AI	AIA	660	264	t
27	Antarctica	AQ	ATA	10	672	t
28	Antigua	AG	ATG	28	268	t
29	Argentina	AR	ARG	32	054	t
30	Armenia	AM	ARM	51	374	t
31	Aruba	AW	ABW	533	297	t
32	Australia	AU	AUS	36	061	t
33	Austria	AT	AUT	40	043	t
34	Azerbaijan	AZ	AZE	31	994	t
35	Bahamas	BS	BHS	44	242	t
36	Bahrain	BH	BHR	48	973	t
37	Bangladesh	BD	BGD	50	880	t
38	Barbados	BB	BRB	52	246	t
39	Belarus	BY	BLR	112	375	t
40	Belgium	BE	BEL	56	032	t
41	Belize	BZ	BLZ	84	501	t
42	Benin	BJ	BEN	204	229	t
43	Bermuda	BM	BMU	60	441	t
44	Bhutan	BT	BTN	64	975	t
45	Bolivia	BO	BOL	68	591	t
46	Bosnia-Herzegovina	BA	BIH	70	387	t
47	Botswana	BW	BWA	72	267	t
48	Brazil	BR	BRA	76	055	t
49	British Virgin Islands	VG	VGB	92	284	t
50	Brunei	BN	BRN	96	673	t
51	Bulgaria	BG	BGR	100	359	t
52	Burkina Faso	BF	BFA	854	226	t
53	Burma (Myanmar)	MM	MMR	104	095	t
54	Burundi	BI	BDI	108	257	t
55	Cambodia	KH	KHM	116	855	t
56	Cameroon	CM	CMR	120	237	t
57	Cape Verde Island	CV	CPV	132	238	t
58	Cayman Islands	KY	CYM	136	345	t
59	Central African Republic	CF	CAF	140	236	t
60	Chad	TD	TCD	148	235	t
61	Chile	CL	CHL	152	056	t
62	Christmas Island	CX	CXR	162	061	t
63	Cocos Islands	CC	CCK	166	061	t
64	Colombia	CO	COL	170	057	t
65	Comoros	KM	COM	174	269	t
66	Republic of Congo	CD	COD	180	242	t
67	Democratic Republic of Congo	CG	COG	178	243	t
68	Cook Islands	CK	COK	184	682	t
69	Costa Rica	CR	CRI	188	506	t
70	Croatia	HR	HRV	191	385	t
71	Cuba	CU	CUB	192	053	t
72	Cyprus	CY	CYP	196	357	t
73	Czech Republic	CZ	CZE	203	420	t
74	Denmark	DK	DNK	208	045	t
75	Djibouti	DJ	DJI	262	253	t
76	Dominica	DM	DMA	212	767	t
77	Dominican Republic	DO	DOM	214	809	t
78	Ecuador	EC	ECU	218	593	t
79	Egypt	EG	EGY	818	020	t
80	El Salvador	SV	SLV	222	503	t
81	Equatorial Guinea	GQ	GNQ	226	240	t
82	Eritrea	ER	ERI	232	291	t
83	Estonia	EE	EST	233	372	t
84	Ethiopia	ET	ETH	231	251	t
85	Faeroe Islands	FO	FRO	234	298	t
86	Falkland Islands	FK	FLK	238	500	t
87	Fiji Islands	FJ	FJI	242	679	t
88	Finland	FI	FIN	246	358	t
89	French Guiana	GF	GUF	254	594	t
90	French Polynesia	PF	PYF	258	689	t
91	Gabon	GA	GAB	266	241	t
92	Gambia	GM	GMB	270	220	t
93	Georgia	GE	GEO	268	995	t
94	Ghana	GH	GHA	288	233	t
95	Gibraltar	GI	GIB	292	350	t
96	Greece	GR	GRC	300	030	t
97	Greenland	GL	GRL	304	299	t
98	Grenada	GD	GRD	308	473	t
99	Guadeloupe	GP	GLP	312	590	t
100	Guam	GU	GUM	316	671	t
101	Guatemala	GT	GTM	320	502	t
102	Guinea	GN	GIN	324	224	t
103	Guinea-Bissau	GW	GNB	624	245	t
104	Guyana	GY	GUY	328	592	t
105	Haiti	HT	HTI	332	509	t
106	Honduras	HN	HND	340	504	t
107	Iceland	IS	ISL	352	354	t
108	India	IN	IND	356	091	t
109	Indonesia	ID	IDN	360	062	t
110	Iran	IR	IRN	364	098	t
111	Iraq	IQ	IRQ	368	964	t
112	Ireland	IE	IRL	372	353	t
113	Ivory Coast	CI	CIV	384	225	t
114	Jamaica	JM	JAM	388	876	t
115	Jordan	JO	JOR	400	962	t
116	Kazakhstan	KZ	KAZ	398	007	t
117	Kenya	KE	KEN	404	254	t
118	Kiribati	KI	KIR	408	686	t
119	Kuwait	KW	KWT	414	965	t
120	North Korea	KP	PRK	408	850	t
121	Kyrgyzstan	KG	KGZ	471	996	t
122	Laos	LA	LAO	418	856	t
123	Latvia	LV	LVA	428	371	t
124	Lebanon	LB	LBN	422	961	t
125	Lesotho	LS	LSO	426	266	t
126	Liberia	LR	LBR	430	231	t
127	Libya	LY	LBY	434	218	t
128	Liechtenstein	LI	LIE	438	423	t
129	Lithuania	LT	LTU	440	370	t
130	Luxembourg	LU	LUX	442	352	t
131	Macau	MO	MAC	446	853	t
132	Macedonia	MK	MKD	807	389	t
133	Madagascar	MG	MDG	450	261	t
134	Malawi	MW	MWI	454	265	t
135	Malaysia	MY	MYS	458	060	t
136	Maldives	MV	MDV	462	960	t
137	Mali	ML	MLI	466	223	t
138	Malta	MT	MLT	470	356	t
139	Marshall Islands	MH	MHL	584	692	t
140	Martinique	MQ	MTQ	474	596	t
141	Mauritania	MR	MRT	478	222	t
142	Mauritius	MU	MUS	480	230	t
143	Mayotte Island	YT	MYT	175	269	t
144	Mexico	MX	MEX	484	052	t
145	Micronesia	FM	FSM	583	691	t
146	Moldova	MD	MDA	498	373	t
147	Monaco	MC	MCO	492	377	t
148	Mongolia	MN	MNG	496	976	t
149	Montenegro	ME	MNE	499	382	t
150	Montserrat	MS	MSR	500	664	t
151	Morocco	MA	MAR	504	212	t
152	Mozambique	MZ	MOZ	508	258	t
153	Namibia	NA	NAM	516	264	t
154	Nauru	NR	NRU	520	674	t
155	Nepal	NP	NPL	524	977	t
156	Netherlands Antilles	AN	ANT	530	599	t
157	New Caledonia	NC	NCL	540	687	t
158	New Zealand	NZ	NZL	554	064	t
159	Nicaragua	NI	NIC	558	505	t
160	Niger	NE	NER	562	227	t
161	Nigeria	NG	NGA	566	234	t
162	Niue	NU	NIU	570	683	t
163	Norfolk Island	NF	NFK	574	672	t
164	Norway	NO	NOR	578	047	t
165	Oman	OM	OMN	512	968	t
166	Pakistan	PK	PAK	586	092	t
167	Palau	PW	PLW	585	680	t
168	Palestine	PS	PSE	275	970	t
169	Panama	PA	PAN	591	507	t
170	Papua New Guinea	PG	PNG	598	675	t
171	Paraguay	PY	PRY	600	595	t
172	Peru	PE	PER	604	051	t
173	Philippines	PH	PHL	608	063	t
174	Poland	PL	POL	616	048	t
175	Puerto Rico	PR	PRI	630	787	t
176	Qatar	QA	QAT	634	974	t
177	Reunion Island	RE	REU	638	262	t
178	Romania	RO	ROU	642	040	t
179	Rwanda	RW	RWA	646	250	t
180	St. Helena	SH	SHN	654	290	t
181	St. Kitts	KN	KNA	659	869	t
182	St. Lucia	LC	LCA	662	758	t
183	St. Pierre & Miquelon	PM	SPM	666	508	t
184	St. Vincent	VC	VCT	670	784	t
185	San Marino	SM	SMR	674	378	t
186	Sao Tome & Principe	ST	STP	678	239	t
187	Saudi Arabia	SA	SAU	682	966	t
188	Senegal	SN	SEN	686	221	t
189	Serbia	RS	SRB	688	381	t
190	Seychelles	SC	SYC	690	248	t
191	Sierra Leone	SL	SLE	694	249	t
192	Slovakia	SK	SVK	703	421	t
193	Slovenia	SI	SVN	705	386	t
194	Solomon Islands	SB	SLB	90	677	t
195	Somalia	SO	SOM	706	252	t
196	South Africa	ZA	ZAF	710	027	t
197	Sri Lanka	LK	LKA	144	094	t
198	Sudan	SD	SDN	736	095	t
199	Suriname	SR	SUR	740	597	t
200	Swaziland	SZ	SWZ	748	268	t
201	Sweden	SE	SWE	752	046	t
202	Switzerland	CH	CHE	756	041	t
203	Syria	SY	SYR	760	963	t
204	Taiwan	TW	TWN	158	886	t
205	Tajikistan	TJ	TJK	762	992	t
206	Tanzania	TZ	TZA	834	255	t
207	Thailand	TH	THA	764	066	t
208	Togo	TG	TGO	768	228	t
209	Tonga	TO	TON	776	676	t
210	Trinidad & Tobago	TT	TTO	780	868	t
211	Tunisia	TN	TUN	788	216	t
212	Turkmenistan	TM	TKM	795	993	t
213	Turks & Caicos	TC	TCA	796	649	t
214	Tuvalu	TV	TUV	798	688	t
215	Uganda	UG	UGA	800	256	t
216	Ukraine	UA	UKR	804	380	t
217	United Arab Emirates	AE	ARE	784	971	t
218	Uruguay	UY	URY	858	598	t
219	Uzbekistan	UZ	UZB	860	998	t
220	Vanuatu	VU	VUT	548	678	t
221	Vatican City	VA	VAT	336	039	t
222	Venezuela	VE	VEN	862	058	t
223	Wallis & Futuna	WF	WLF	876	681	t
224	Western Samoa	EH	ESH	732	685	t
225	Yemen	YE	YEM	887	967	t
226	Zambia	ZM	ZMB	894	260	t
227	Zimbabwe	ZW	ZWE	716	263	t
\.


--
-- Data for Name: cyrususer; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY cyrususer (userid, password_) FROM stdin;
\.


--
-- Data for Name: cyrusvirtual; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY cyrusvirtual (emailaddress, userid) FROM stdin;
\.


--
-- Data for Name: dlfileentry; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY dlfileentry (uuid_, fileentryid, groupid, companyid, userid, username, versionuserid, versionusername, createdate, modifieddate, folderid, name, extension, title, description, extrasettings, version, size_, readcount) FROM stdin;
81237207-67c1-47fe-86ff-9abebe8e2a00	10309	10157	10132	10169	Test Test	10169	Test Test	2015-12-03 01:25:08.247	2015-12-03 01:25:08.247	0	1	doc	Document1			1.0	22016	0
\.


--
-- Data for Name: dlfilerank; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY dlfilerank (filerankid, groupid, companyid, userid, createdate, folderid, name) FROM stdin;
\.


--
-- Data for Name: dlfileshortcut; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY dlfileshortcut (uuid_, fileshortcutid, groupid, companyid, userid, username, createdate, modifieddate, folderid, tofolderid, toname, status, statusbyuserid, statusbyusername, statusdate) FROM stdin;
\.


--
-- Data for Name: dlfileversion; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY dlfileversion (fileversionid, groupid, companyid, userid, username, createdate, folderid, name, extension, title, description, changelog, extrasettings, version, size_, status, statusbyuserid, statusbyusername, statusdate) FROM stdin;
10310	10157	10132	10169	Test Test	2015-12-03 01:25:08.247	0	1	doc	Document1				1.0	22016	0	10169	Test Test	2015-12-03 01:25:08.548
\.


--
-- Data for Name: dlfolder; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY dlfolder (uuid_, folderid, groupid, companyid, userid, username, createdate, modifieddate, parentfolderid, name, description, lastpostdate) FROM stdin;
\.


--
-- Data for Name: emailaddress; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY emailaddress (emailaddressid, companyid, userid, username, createdate, modifieddate, classnameid, classpk, address, typeid, primary_) FROM stdin;
\.


--
-- Data for Name: expandocolumn; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY expandocolumn (columnid, companyid, tableid, name, type_, defaultdata, typesettings) FROM stdin;
\.


--
-- Data for Name: expandorow; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY expandorow (rowid_, companyid, tableid, classpk) FROM stdin;
\.


--
-- Data for Name: expandotable; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY expandotable (tableid, companyid, classnameid, name) FROM stdin;
\.


--
-- Data for Name: expandovalue; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY expandovalue (valueid, companyid, tableid, columnid, rowid_, classnameid, classpk, data_) FROM stdin;
\.


--
-- Data for Name: group_; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY group_ (groupid, companyid, creatoruserid, classnameid, classpk, parentgroupid, livegroupid, name, description, type_, typesettings, friendlyurl, active_) FROM stdin;
10149	10132	10135	10012	10149	0	0	Control Panel		3		/control_panel	t
10157	10132	10135	10012	10157	0	0	Guest		1		/guest	t
10165	10132	10135	10008	10132	0	0	10132		0		/null	t
10171	10132	10169	10046	10169	0	0	10169		0		/test	t
10374	10132	10169	10012	10374	0	0	Site Name		1		/site-name	t
10388	10132	10386	10046	10386	0	0	10386		0		/usersn	t
\.


--
-- Data for Name: groups_orgs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY groups_orgs (groupid, organizationid) FROM stdin;
\.


--
-- Data for Name: groups_permissions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY groups_permissions (groupid, permissionid) FROM stdin;
\.


--
-- Data for Name: groups_roles; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY groups_roles (groupid, roleid) FROM stdin;
\.


--
-- Data for Name: groups_usergroups; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY groups_usergroups (groupid, usergroupid) FROM stdin;
\.


--
-- Data for Name: igfolder; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY igfolder (uuid_, folderid, groupid, companyid, userid, createdate, modifieddate, parentfolderid, name, description) FROM stdin;
\.


--
-- Data for Name: igimage; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY igimage (uuid_, imageid, groupid, companyid, userid, createdate, modifieddate, folderid, name, description, smallimageid, largeimageid, custom1imageid, custom2imageid) FROM stdin;
\.


--
-- Data for Name: image; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY image (imageid, modifieddate, text_, type_, height, width, size_) FROM stdin;
\.


--
-- Data for Name: journalarticle; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY journalarticle (uuid_, id_, resourceprimkey, groupid, companyid, userid, username, createdate, modifieddate, articleid, version, title, urltitle, description, content, type_, structureid, templateid, displaydate, expirationdate, reviewdate, indexable, smallimage, smallimageid, smallimageurl, status, statusbyuserid, statusbyusername, statusdate) FROM stdin;
3c57c9c0-aa51-4fda-a3be-7aef0958745b	10290	10291	10157	10132	10169	Test Test	2015-12-03 01:24:20.774	2015-12-03 01:24:20.924	10289	1	Web Content Title	web-content-title		<?xml version='1.0' encoding='UTF-8'?><root><static-content><![CDATA[<p>\n\tWeb Content Content</p>]]></static-content></root>	general			2015-12-03 01:24:00	\N	\N	t	f	10292		0	10169	Test Test	2015-12-03 01:24:20.924
\.


--
-- Data for Name: journalarticleimage; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY journalarticleimage (articleimageid, groupid, articleid, version, elinstanceid, elname, languageid, tempimage) FROM stdin;
\.


--
-- Data for Name: journalarticleresource; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY journalarticleresource (uuid_, resourceprimkey, groupid, articleid) FROM stdin;
a8f57f5f-2e49-4136-9bf5-d90cc80beebc	10291	10157	10289
\.


--
-- Data for Name: journalcontentsearch; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY journalcontentsearch (contentsearchid, groupid, companyid, privatelayout, layoutid, portletid, articleid) FROM stdin;
10299	10157	10132	f	2	56_INSTANCE_I9Fr	10289
\.


--
-- Data for Name: journalfeed; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY journalfeed (uuid_, id_, groupid, companyid, userid, username, createdate, modifieddate, feedid, name, description, type_, structureid, templateid, renderertemplateid, delta, orderbycol, orderbytype, targetlayoutfriendlyurl, targetportletid, contentfield, feedtype, feedversion) FROM stdin;
\.


--
-- Data for Name: journalstructure; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY journalstructure (uuid_, id_, groupid, companyid, userid, username, createdate, modifieddate, structureid, parentstructureid, name, description, xsd) FROM stdin;
\.


--
-- Data for Name: journaltemplate; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY journaltemplate (uuid_, id_, groupid, companyid, userid, username, createdate, modifieddate, templateid, structureid, name, description, xsl, langtype, cacheable, smallimage, smallimageid, smallimageurl) FROM stdin;
\.


--
-- Data for Name: layout; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY layout (uuid_, plid, groupid, companyid, privatelayout, layoutid, parentlayoutid, name, title, description, type_, typesettings, hidden_, friendlyurl, iconimage, iconimageid, themeid, colorschemeid, wapthemeid, wapcolorschemeid, css, priority, layoutprototypeid, dlfolderid) FROM stdin;
b1f48a7e-6e95-4949-ae7a-142186c14d08	10152	10149	10132	t	1	0	<?xml version='1.0' encoding='UTF-8'?><root available-locales="en_US" default-locale="en_US"><name language-id="en_US">Control Panel</name></root>			control_panel		f	/manage	f	0						0	0	0
570e6de4-b4fc-434b-bc3e-3fc498fe8cb1	10160	10157	10132	f	1	0	<?xml version='1.0' encoding='UTF-8'?><root available-locales="en_US" default-locale="en_US"><name language-id="en_US">Welcome</name></root>			portlet	layout-template-id=2_columns_ii\ncolumn-2=47,\ncolumn-1=58,\n	f	/home	f	0						0	0	0
c3473965-c45a-45c9-899a-9b17e223cb61	10265	10171	10132	t	1	0	<?xml version='1.0' encoding='UTF-8'?><root available-locales="en_US" default-locale="en_US"><name language-id="en_US">Welcome</name></root>			portlet	layout-template-id=2_columns_ii\ncolumn-2=29,8,\ncolumn-1=82,23,11,\n	f	/home	f	0						0	0	0
95afcf32-3cbe-412c-add2-4484d1c1572a	10270	10171	10132	f	1	0	<?xml version='1.0' encoding='UTF-8'?><root available-locales="en_US" default-locale="en_US"><name language-id="en_US">Welcome</name></root>			portlet	layout-template-id=2_columns_ii\ncolumn-2=33,\ncolumn-1=82,3,\n	f	/home	f	0						0	0	0
c4a70a91-2d0a-45d2-a268-4249c3144c2c	10278	10157	10132	f	2	0	<?xml version='1.0' encoding='UTF-8'?><root available-locales="en_US" default-locale="en_US"><name language-id="en_US">Web Content</name></root>			portlet	layout-template-id=2_columns_ii\ncolumn-1=56_INSTANCE_I9Fr\n	f	/web-content	f	0						1	0	0
10fb3d38-3285-421d-bafc-d9c2bed04ba9	10300	10157	10132	f	3	0	<?xml version='1.0' encoding='UTF-8'?><root available-locales="en_US" default-locale="en_US"><name language-id="en_US">Document</name></root>			portlet	layout-template-id=2_columns_ii\ncolumn-1=20\n	f	/document	f	0						2	0	0
3d47e3c5-c61a-4034-ab3f-302f305febaa	10319	10157	10132	f	4	0	<?xml version='1.0' encoding='UTF-8'?><root available-locales="en_US" default-locale="en_US"><name language-id="en_US">Message Boards</name></root>			portlet	layout-template-id=2_columns_ii\ncolumn-1=19\n	f	/message-boards	f	0						3	0	0
ae4fed8d-b11a-4569-ad05-b3c827029673	10334	10157	10132	f	5	0	<?xml version='1.0' encoding='UTF-8'?><root available-locales="en_US" default-locale="en_US"><name language-id="en_US">Wiki</name></root>			portlet	layout-template-id=2_columns_ii\ncolumn-1=36\n	f	/wiki	f	0						4	0	0
14670d22-7093-4ac1-8e56-d1df605b4441	10354	10157	10132	f	6	0	<?xml version='1.0' encoding='UTF-8'?><root available-locales="en_US" default-locale="en_US"><name language-id="en_US">Blogs</name></root>			portlet	layout-template-id=2_columns_ii\ncolumn-1=33\n	f	/blogs	f	0						5	0	0
00c17e06-1269-4c9a-8fc1-1655ef0f1934	10378	10374	10132	f	1	0	<?xml version='1.0' encoding='UTF-8'?><root available-locales="en_US" default-locale="en_US"><name language-id="en_US">Site Page</name></root>			portlet	layout-template-id=2_columns_ii\n	f	/site-page	f	0						0	0	0
abcb317b-4118-461f-a5d2-8a240d37daac	10395	10388	10132	t	1	0	<?xml version='1.0' encoding='UTF-8'?><root available-locales="en_US" default-locale="en_US"><name language-id="en_US">Welcome</name></root>			portlet	layout-template-id=2_columns_ii\ncolumn-2=29,8,\ncolumn-1=82,23,11,\n	f	/home	f	0						0	0	0
2f6374fc-4d56-46da-88b9-5830438a20fa	10400	10388	10132	f	1	0	<?xml version='1.0' encoding='UTF-8'?><root available-locales="en_US" default-locale="en_US"><name language-id="en_US">Welcome</name></root>			portlet	layout-template-id=2_columns_ii\ncolumn-2=33,\ncolumn-1=82,3,\n	f	/home	f	0						0	0	0
\.


--
-- Data for Name: layoutprototype; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY layoutprototype (layoutprototypeid, companyid, name, description, settings_, active_) FROM stdin;
\.


--
-- Data for Name: layoutset; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY layoutset (layoutsetid, groupid, companyid, privatelayout, logo, logoid, themeid, colorschemeid, wapthemeid, wapcolorschemeid, css, pagecount, virtualhost, settings_, layoutsetprototypeid) FROM stdin;
10151	10149	10132	f	f	0	classic	01	mobile	01		0			0
10150	10149	10132	t	f	0	classic	01	mobile	01		1			0
10158	10157	10132	t	f	0	classic	01	mobile	01		0			0
10166	10165	10132	t	f	0	classic	01	mobile	01		0			0
10167	10165	10132	f	f	0	classic	01	mobile	01		0			0
10172	10171	10132	t	f	0	classic	01	mobile	01		1			0
10173	10171	10132	f	f	0	classic	01	mobile	01		1			0
10159	10157	10132	f	f	0	classic	01	mobile	01		6			0
10375	10374	10132	t	f	0	classic	01	mobile	01		0			0
10376	10374	10132	f	f	0	classic	01	mobile	01		1			0
10389	10388	10132	t	f	0	classic	01	mobile	01		1			0
10390	10388	10132	f	f	0	classic	01	mobile	01		1			0
\.


--
-- Data for Name: layoutsetprototype; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY layoutsetprototype (layoutsetprototypeid, companyid, name, description, settings_, active_) FROM stdin;
\.


--
-- Data for Name: listtype; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY listtype (listtypeid, name, type_) FROM stdin;
10000	Billing	com.liferay.portal.model.Account.address
10001	Other	com.liferay.portal.model.Account.address
10002	P.O. Box	com.liferay.portal.model.Account.address
10003	Shipping	com.liferay.portal.model.Account.address
10004	E-mail	com.liferay.portal.model.Account.emailAddress
10005	E-mail 2	com.liferay.portal.model.Account.emailAddress
10006	E-mail 3	com.liferay.portal.model.Account.emailAddress
10007	Fax	com.liferay.portal.model.Account.phone
10008	Local	com.liferay.portal.model.Account.phone
10009	Other	com.liferay.portal.model.Account.phone
10010	Toll-Free	com.liferay.portal.model.Account.phone
10011	TTY	com.liferay.portal.model.Account.phone
10012	Intranet	com.liferay.portal.model.Account.website
10013	Public	com.liferay.portal.model.Account.website
11000	Business	com.liferay.portal.model.Contact.address
11001	Other	com.liferay.portal.model.Contact.address
11002	Personal	com.liferay.portal.model.Contact.address
11003	E-mail	com.liferay.portal.model.Contact.emailAddress
11004	E-mail 2	com.liferay.portal.model.Contact.emailAddress
11005	E-mail 3	com.liferay.portal.model.Contact.emailAddress
11006	Business	com.liferay.portal.model.Contact.phone
11007	Business Fax	com.liferay.portal.model.Contact.phone
11008	Mobile	com.liferay.portal.model.Contact.phone
11009	Other	com.liferay.portal.model.Contact.phone
11010	Pager	com.liferay.portal.model.Contact.phone
11011	Personal	com.liferay.portal.model.Contact.phone
11012	Personal Fax	com.liferay.portal.model.Contact.phone
11013	TTY	com.liferay.portal.model.Contact.phone
11014	Dr.	com.liferay.portal.model.Contact.prefix
11015	Mr.	com.liferay.portal.model.Contact.prefix
11016	Mrs.	com.liferay.portal.model.Contact.prefix
11017	Ms.	com.liferay.portal.model.Contact.prefix
11020	II	com.liferay.portal.model.Contact.suffix
11021	III	com.liferay.portal.model.Contact.suffix
11022	IV	com.liferay.portal.model.Contact.suffix
11023	Jr.	com.liferay.portal.model.Contact.suffix
11024	PhD.	com.liferay.portal.model.Contact.suffix
11025	Sr.	com.liferay.portal.model.Contact.suffix
11026	Blog	com.liferay.portal.model.Contact.website
11027	Business	com.liferay.portal.model.Contact.website
11028	Other	com.liferay.portal.model.Contact.website
11029	Personal	com.liferay.portal.model.Contact.website
12000	Billing	com.liferay.portal.model.Organization.address
12001	Other	com.liferay.portal.model.Organization.address
12002	P.O. Box	com.liferay.portal.model.Organization.address
12003	Shipping	com.liferay.portal.model.Organization.address
12004	E-mail	com.liferay.portal.model.Organization.emailAddress
12005	E-mail 2	com.liferay.portal.model.Organization.emailAddress
12006	E-mail 3	com.liferay.portal.model.Organization.emailAddress
12007	Fax	com.liferay.portal.model.Organization.phone
12008	Local	com.liferay.portal.model.Organization.phone
12009	Other	com.liferay.portal.model.Organization.phone
12010	Toll-Free	com.liferay.portal.model.Organization.phone
12011	TTY	com.liferay.portal.model.Organization.phone
12012	Administrative	com.liferay.portal.model.Organization.service
12013	Contracts	com.liferay.portal.model.Organization.service
12014	Donation	com.liferay.portal.model.Organization.service
12015	Retail	com.liferay.portal.model.Organization.service
12016	Training	com.liferay.portal.model.Organization.service
12017	Full Member	com.liferay.portal.model.Organization.status
12018	Provisional Member	com.liferay.portal.model.Organization.status
12019	Intranet	com.liferay.portal.model.Organization.website
12020	Public	com.liferay.portal.model.Organization.website
\.


--
-- Data for Name: lock_; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY lock_ (uuid_, lockid, companyid, userid, username, createdate, classname, key_, owner, inheritable, expirationdate) FROM stdin;
\.


--
-- Data for Name: mbban; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY mbban (banid, groupid, companyid, userid, username, createdate, modifieddate, banuserid) FROM stdin;
\.


--
-- Data for Name: mbcategory; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY mbcategory (uuid_, categoryid, groupid, companyid, userid, username, createdate, modifieddate, parentcategoryid, name, description, threadcount, messagecount, lastpostdate) FROM stdin;
\.


--
-- Data for Name: mbdiscussion; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY mbdiscussion (discussionid, classnameid, classpk, threadid) FROM stdin;
10156	10014	10152	10154
10164	10014	10160	10162
10269	10014	10265	10267
10274	10014	10270	10272
10282	10014	10278	10280
10297	10084	10291	10295
10304	10014	10300	10302
10315	10073	10309	10313
10323	10014	10319	10321
10338	10014	10334	10336
10350	10129	10345	10348
10358	10014	10354	10356
10368	10068	10363	10366
10382	10014	10378	10380
10399	10014	10395	10397
10404	10014	10400	10402
\.


--
-- Data for Name: mbmailinglist; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY mbmailinglist (uuid_, mailinglistid, groupid, companyid, userid, username, createdate, modifieddate, categoryid, emailaddress, inprotocol, inservername, inserverport, inusessl, inusername, inpassword, inreadinterval, outemailaddress, outcustom, outservername, outserverport, outusessl, outusername, outpassword, active_) FROM stdin;
\.


--
-- Data for Name: mbmessage; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY mbmessage (uuid_, messageid, groupid, companyid, userid, username, createdate, modifieddate, classnameid, classpk, categoryid, threadid, rootmessageid, parentmessageid, subject, body, attachments, anonymous, priority, allowpingbacks, status, statusbyuserid, statusbyusername, statusdate) FROM stdin;
16e8f319-c2cd-4b9a-bff3-a299b0478648	10153	10149	10132	10135	 	2015-12-03 01:22:41.623	2015-12-03 01:22:41.623	10014	10152	-1	10154	10153	0	10152	10152	f	t	0	f	0	10135	 	2015-12-03 01:22:41.743
e5622196-c37a-4c99-9a45-2eb92464d937	10161	10157	10132	10135	 	2015-12-03 01:22:41.842	2015-12-03 01:22:41.842	10014	10160	-1	10162	10161	0	10160	10160	f	t	0	f	0	10135	 	2015-12-03 01:22:41.851
95aa411c-683f-4de5-92b1-2d73df720f32	10266	10171	10132	10169	Test Test	2015-12-03 01:23:31.956	2015-12-03 01:23:31.956	10014	10265	-1	10267	10266	0	10265	10265	f	f	0	f	0	10169	Test Test	2015-12-03 01:23:31.96
5af9300f-eaff-4656-a09e-b42a2a97e778	10271	10171	10132	10169	Test Test	2015-12-03 01:23:31.99	2015-12-03 01:23:31.99	10014	10270	-1	10272	10271	0	10270	10270	f	f	0	f	0	10169	Test Test	2015-12-03 01:23:31.993
7c3438b1-c7dc-4da5-835f-a0ed5d968843	10279	10157	10132	10169	Test Test	2015-12-03 01:23:54.369	2015-12-03 01:23:54.369	10014	10278	-1	10280	10279	0	10278	10278	f	f	0	f	0	10169	Test Test	2015-12-03 01:23:54.375
4e574dc3-9eb8-4da1-a8a1-8cc111a1d58b	10294	10157	10132	10169	Test Test	2015-12-03 01:24:20.901	2015-12-03 01:24:20.901	10084	10291	-1	10295	10294	0	10291	10291	f	f	0	f	0	10169	Test Test	2015-12-03 01:24:20.909
3941031b-0f34-40c9-965e-d3ca0139b189	10301	10157	10132	10169	Test Test	2015-12-03 01:24:43.059	2015-12-03 01:24:43.059	10014	10300	-1	10302	10301	0	10300	10300	f	f	0	f	0	10169	Test Test	2015-12-03 01:24:43.065
6bda6825-5c36-4773-8976-2c975b865f7d	10312	10157	10132	10169	Test Test	2015-12-03 01:25:08.361	2015-12-03 01:25:08.361	10073	10309	-1	10313	10312	0	10309	10309	f	f	0	f	0	10169	Test Test	2015-12-03 01:25:08.364
983a655e-f0c8-4939-a21e-cb69d28c5009	10320	10157	10132	10169	Test Test	2015-12-03 01:25:36.553	2015-12-03 01:25:36.553	10014	10319	-1	10321	10320	0	10319	10319	f	f	0	f	0	10169	Test Test	2015-12-03 01:25:36.557
988f6c87-79bb-43b7-b012-ead980730f89	10328	10157	10132	10169	Test Test	2015-12-03 01:26:26.033	2015-12-03 01:26:26.033	0	0	0	10329	10328	0	Message Boards Subject	Message Boards Body	f	f	0	t	0	10169	Test Test	2015-12-03 01:26:26.065
8ec4078d-39ab-4634-8096-9eeda55eab43	10335	10157	10132	10169	Test Test	2015-12-03 01:26:59.909	2015-12-03 01:26:59.909	10014	10334	-1	10336	10335	0	10334	10334	f	f	0	f	0	10169	Test Test	2015-12-03 01:26:59.914
4402e794-fed5-419c-a444-7b9d4a9dc873	10347	10157	10132	10169	Test Test	2015-12-03 01:27:15.137	2015-12-03 01:27:15.137	10129	10345	-1	10348	10347	0	10345	10345	f	f	0	f	0	10169	Test Test	2015-12-03 01:27:15.144
77932504-293f-47f9-8db2-de626b23053b	10355	10157	10132	10169	Test Test	2015-12-03 01:27:45.661	2015-12-03 01:27:45.661	10014	10354	-1	10356	10355	0	10354	10354	f	f	0	f	0	10169	Test Test	2015-12-03 01:27:45.665
45f1b6ac-cfb7-499f-85a2-19491c6e6ba9	10365	10157	10132	10169	Test Test	2015-12-03 01:28:15.453	2015-12-03 01:28:15.453	10068	10363	-1	10366	10365	0	10363	10363	f	f	0	f	0	10169	Test Test	2015-12-03 01:28:15.459
f39e6547-30cb-4f02-9fc8-83788af62852	10379	10374	10132	10169	Test Test	2015-12-03 01:31:09.013	2015-12-03 01:31:09.013	10014	10378	-1	10380	10379	0	10378	10378	f	f	0	f	0	10169	Test Test	2015-12-03 01:31:09.101
91260f20-91d9-49db-871c-dc7a062508e2	10396	10388	10132	10386	Userfn Userln	2015-12-03 01:33:32.117	2015-12-03 01:33:32.117	10014	10395	-1	10397	10396	0	10395	10395	f	f	0	f	0	10386	Userfn Userln	2015-12-03 01:33:32.124
55011292-5444-4ea0-b332-c5d8ab4c5fed	10401	10388	10132	10386	Userfn Userln	2015-12-03 01:33:32.164	2015-12-03 01:33:32.164	10014	10400	-1	10402	10401	0	10400	10400	f	f	0	f	0	10386	Userfn Userln	2015-12-03 01:33:32.173
\.


--
-- Data for Name: mbmessageflag; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY mbmessageflag (messageflagid, userid, modifieddate, threadid, messageid, flag) FROM stdin;
10333	10169	2015-12-03 01:26:26.065	10329	10328	1
\.


--
-- Data for Name: mbstatsuser; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY mbstatsuser (statsuserid, groupid, userid, messagecount, lastpostdate) FROM stdin;
10331	10157	10169	1	2015-12-03 01:26:26.065
\.


--
-- Data for Name: mbthread; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY mbthread (threadid, groupid, categoryid, rootmessageid, messagecount, viewcount, lastpostbyuserid, lastpostdate, priority, status, statusbyuserid, statusbyusername, statusdate) FROM stdin;
10154	10149	-1	10153	1	0	0	2015-12-03 01:22:41.743	0	0	10135	 	2015-12-03 01:22:41.743
10162	10157	-1	10161	1	0	0	2015-12-03 01:22:41.851	0	0	10135	 	2015-12-03 01:22:41.851
10267	10171	-1	10266	1	0	10169	2015-12-03 01:23:31.96	0	0	10169	Test Test	2015-12-03 01:23:31.96
10272	10171	-1	10271	1	0	10169	2015-12-03 01:23:31.993	0	0	10169	Test Test	2015-12-03 01:23:31.993
10280	10157	-1	10279	1	0	10169	2015-12-03 01:23:54.375	0	0	10169	Test Test	2015-12-03 01:23:54.375
10295	10157	-1	10294	1	0	10169	2015-12-03 01:24:20.909	0	0	10169	Test Test	2015-12-03 01:24:20.909
10302	10157	-1	10301	1	0	10169	2015-12-03 01:24:43.065	0	0	10169	Test Test	2015-12-03 01:24:43.065
10313	10157	-1	10312	1	0	10169	2015-12-03 01:25:08.364	0	0	10169	Test Test	2015-12-03 01:25:08.364
10321	10157	-1	10320	1	0	10169	2015-12-03 01:25:36.557	0	0	10169	Test Test	2015-12-03 01:25:36.557
10329	10157	0	10328	1	1	10169	2015-12-03 01:26:26.065	0	0	10169	Test Test	2015-12-03 01:26:26.065
10336	10157	-1	10335	1	0	10169	2015-12-03 01:26:59.914	0	0	10169	Test Test	2015-12-03 01:26:59.914
10348	10157	-1	10347	1	0	10169	2015-12-03 01:27:15.144	0	0	10169	Test Test	2015-12-03 01:27:15.144
10356	10157	-1	10355	1	0	10169	2015-12-03 01:27:45.665	0	0	10169	Test Test	2015-12-03 01:27:45.665
10366	10157	-1	10365	1	0	10169	2015-12-03 01:28:15.459	0	0	10169	Test Test	2015-12-03 01:28:15.459
10380	10374	-1	10379	1	0	10169	2015-12-03 01:31:09.101	0	0	10169	Test Test	2015-12-03 01:31:09.101
10397	10388	-1	10396	1	0	10386	2015-12-03 01:33:32.124	0	0	10386	Userfn Userln	2015-12-03 01:33:32.124
10402	10388	-1	10401	1	0	10386	2015-12-03 01:33:32.173	0	0	10386	Userfn Userln	2015-12-03 01:33:32.173
\.


--
-- Data for Name: membershiprequest; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY membershiprequest (membershiprequestid, companyid, userid, createdate, groupid, comments, replycomments, replydate, replieruserid, statusid) FROM stdin;
\.


--
-- Data for Name: organization_; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY organization_ (organizationid, companyid, parentorganizationid, leftorganizationid, rightorganizationid, name, type_, recursable, regionid, countryid, statusid, comments) FROM stdin;
\.


--
-- Data for Name: orggrouppermission; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY orggrouppermission (organizationid, groupid, permissionid) FROM stdin;
\.


--
-- Data for Name: orggrouprole; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY orggrouprole (organizationid, groupid, roleid) FROM stdin;
\.


--
-- Data for Name: orglabor; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY orglabor (orglaborid, organizationid, typeid, sunopen, sunclose, monopen, monclose, tueopen, tueclose, wedopen, wedclose, thuopen, thuclose, friopen, friclose, satopen, satclose) FROM stdin;
\.


--
-- Data for Name: passwordpolicy; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY passwordpolicy (passwordpolicyid, companyid, userid, username, createdate, modifieddate, defaultpolicy, name, description, changeable, changerequired, minage, checksyntax, allowdictionarywords, minalphanumeric, minlength, minlowercase, minnumbers, minsymbols, minuppercase, history, historycount, expireable, maxage, warningtime, gracelimit, lockout, maxfailure, lockoutduration, requireunlock, resetfailurecount, resetticketmaxage) FROM stdin;
10168	10132	10135	 	2015-12-03 01:22:41.894	2015-12-03 01:22:41.894	t	Default Password Policy	Default Password Policy	t	f	0	f	t	0	6	0	1	0	1	f	6	f	8640000	86400	0	f	3	0	t	600	86400
\.


--
-- Data for Name: passwordpolicyrel; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY passwordpolicyrel (passwordpolicyrelid, passwordpolicyid, classnameid, classpk) FROM stdin;
\.


--
-- Data for Name: passwordtracker; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY passwordtracker (passwordtrackerid, userid, createdate, password_) FROM stdin;
\.


--
-- Data for Name: permission_; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY permission_ (permissionid, companyid, actionid, resourceid) FROM stdin;
\.


--
-- Data for Name: phone; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY phone (phoneid, companyid, userid, username, createdate, modifieddate, classnameid, classpk, number_, extension, typeid, primary_) FROM stdin;
\.


--
-- Data for Name: pluginsetting; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY pluginsetting (pluginsettingid, companyid, pluginid, plugintype, roles, active_) FROM stdin;
\.


--
-- Data for Name: pollschoice; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY pollschoice (uuid_, choiceid, questionid, name, description) FROM stdin;
\.


--
-- Data for Name: pollsquestion; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY pollsquestion (uuid_, questionid, groupid, companyid, userid, username, createdate, modifieddate, title, description, expirationdate, lastvotedate) FROM stdin;
\.


--
-- Data for Name: pollsvote; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY pollsvote (voteid, userid, questionid, choiceid, votedate) FROM stdin;
\.


--
-- Data for Name: portlet; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY portlet (id_, companyid, portletid, roles, active_) FROM stdin;
10175	10132	98		t
10176	10132	66		t
10177	10132	27		t
10178	10132	152		t
10179	10132	134		t
10180	10132	130		t
10181	10132	122		t
10182	10132	36		t
10183	10132	26		t
10184	10132	104		t
10185	10132	153		t
10186	10132	64		t
10187	10132	129		t
10188	10132	100		t
10189	10132	19		t
10190	10132	157		t
10191	10132	128		t
10192	10132	154		t
10193	10132	148		t
10194	10132	11		t
10195	10132	29		t
10196	10132	158		t
10197	10132	8		t
10198	10132	58		t
10199	10132	155		t
10200	10132	71		t
10201	10132	97		t
10202	10132	39		t
10203	10132	85		t
10204	10132	118		t
10205	10132	79		t
10206	10132	107		t
10207	10132	30		t
10208	10132	147		t
10209	10132	48		t
10210	10132	125		t
10211	10132	146		t
10212	10132	62		t
10213	10132	159		t
10214	10132	108		t
10215	10132	84		t
10216	10132	101		t
10217	10132	121		t
10218	10132	37		t
10219	10132	143		t
10220	10132	77		t
10221	10132	115		t
10222	10132	56		t
10223	10132	16		t
10224	10132	111		t
10225	10132	3		t
10226	10132	23		t
10227	10132	20		t
10228	10132	83		t
10229	10132	99		t
10230	10132	70		t
10231	10132	141		t
10232	10132	9		t
10233	10132	28		t
10234	10132	137		t
10235	10132	47		t
10236	10132	15		t
10237	10132	116		t
10238	10132	82		t
10239	10132	151		t
10240	10132	54		t
10241	10132	132		t
10242	10132	34		t
10243	10132	61		t
10244	10132	73		t
10245	10132	31		t
10246	10132	136		t
10247	10132	50		t
10248	10132	127		t
10249	10132	25		t
10250	10132	33		t
10251	10132	150		t
10252	10132	126		t
10253	10132	114		t
10254	10132	149		t
10255	10132	67		t
10256	10132	110		t
10257	10132	59		t
10258	10132	135		t
10259	10132	131		t
10260	10132	102		t
\.


--
-- Data for Name: portletitem; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY portletitem (portletitemid, groupid, companyid, userid, username, createdate, modifieddate, name, portletid, classnameid) FROM stdin;
\.


--
-- Data for Name: portletpreferences; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY portletpreferences (portletpreferencesid, ownerid, ownertype, plid, portletid, preferences) FROM stdin;
10131	0	1	0	LIFERAY_PORTAL	<portlet-preferences />
10137	10132	1	0	LIFERAY_PORTAL	<portlet-preferences />
10261	0	3	10160	103	<portlet-preferences />
10262	0	3	10160	47	<portlet-preferences />
10263	0	3	10160	58	<portlet-preferences />
10264	10135	4	0	LIFERAY_PORTAL	<portlet-preferences />
10276	0	3	10160	145	<portlet-preferences />
10277	0	3	10160	88	<portlet-preferences />
10283	0	3	10278	103	<portlet-preferences />
10284	0	3	10278	145	<portlet-preferences />
10285	0	3	10278	87	<portlet-preferences />
10287	0	3	10278	15	<portlet-preferences />
10288	10157	2	0	15	<portlet-preferences />
10298	0	3	10278	56	<portlet-preferences />
10286	0	3	10278	56_INSTANCE_I9Fr	<portlet-preferences><preference><name>group-id</name><value>10157</value></preference><preference><name>article-id</name><value>10289</value></preference></portlet-preferences>
10305	0	3	10300	103	<portlet-preferences />
10306	0	3	10300	145	<portlet-preferences />
10307	0	3	10300	87	<portlet-preferences />
10308	0	3	10300	20	<portlet-preferences />
10324	0	3	10319	103	<portlet-preferences />
10325	0	3	10319	145	<portlet-preferences />
10326	0	3	10319	87	<portlet-preferences />
10327	0	3	10319	19	<portlet-preferences xmlns="http://java.sun.com/xml/ns/portlet/portlet-app_2_0.xsd">\n\t\t\t<preference>\n\t\t\t\t<name>priorities</name>\n\t\t\t\t<value>Urgent,/message_boards/priority_urgent.png,3.0</value>\n\t\t\t\t<value>Sticky,/message_boards/priority_sticky.png,2.0</value>\n\t\t\t\t<value>Announcement,/message_boards/priority_announcement.png,1.0</value>\n\t\t\t</preference>\n\t\t\t<preference>\n\t\t\t\t<name>ranks</name>\n\t\t\t\t<value>Youngling=0</value>\n\t\t\t\t<value>Padawan=25</value>\n\t\t\t\t<value>Jedi Knight=100</value>\n\t\t\t\t<value>Jedi Master=250</value>\n\t\t\t\t<value>Jedi Council Member=500</value>\n\t\t\t\t<value>Yoda=1000</value>\n\t\t\t\t<value>Moderator=community-role:Message Boards Administrator</value>\n\t\t\t\t<value>Moderator=organization:Message Boards Administrator</value>\n\t\t\t\t<value>Moderator=organization-role:Message Boards Administrator</value>\n\t\t\t\t<value>Moderator=regular-role:Message Boards Administrator</value>\n\t\t\t\t<value>Moderator=user-group:Message Boards Administrator</value>\n\t\t\t</preference>\n\t\t</portlet-preferences>
10339	0	3	10334	103	<portlet-preferences />
10340	0	3	10334	145	<portlet-preferences />
10341	0	3	10334	87	<portlet-preferences />
10342	0	3	10334	36	<portlet-preferences />
10359	0	3	10354	103	<portlet-preferences />
10360	0	3	10354	145	<portlet-preferences />
10361	0	3	10354	87	<portlet-preferences />
10362	0	3	10354	33	<portlet-preferences />
10371	0	3	10152	160	<portlet-preferences />
10372	0	3	10152	145	<portlet-preferences />
10373	0	3	10152	134	<portlet-preferences />
10383	0	3	10378	103	<portlet-preferences />
10384	0	3	10378	145	<portlet-preferences />
10385	0	3	10152	125	<portlet-preferences />
10275	10169	4	0	LIFERAY_PORTAL	<portlet-preferences><preference><name>com.liferay.portal.util.SessionTreeJSClicks#layoutsTree</name><value>layoutsTree_layoutId_0_plid_0,</value></preference><preference><name>com.liferay.portal.util.SessionClicks#show-portlet-description-134</name><value>false</value></preference><preference><name>com.liferay.portal.util.SessionClicks#show-portlet-description-125</name><value>false</value></preference></portlet-preferences>
10405	10386	4	0	LIFERAY_PORTAL	<portlet-preferences />
\.


--
-- Data for Name: quartz_blob_triggers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY quartz_blob_triggers (trigger_name, trigger_group, blob_data) FROM stdin;
\.


--
-- Data for Name: quartz_calendars; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY quartz_calendars (calendar_name, calendar) FROM stdin;
\.


--
-- Data for Name: quartz_cron_triggers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY quartz_cron_triggers (trigger_name, trigger_group, cron_expression, time_zone_id) FROM stdin;
\.


--
-- Data for Name: quartz_fired_triggers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY quartz_fired_triggers (entry_id, trigger_name, trigger_group, is_volatile, instance_name, fired_time, priority, state, job_name, job_group, is_stateful, requests_recovery) FROM stdin;
\.


--
-- Data for Name: quartz_job_details; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY quartz_job_details (job_name, job_group, description, job_class_name, is_durable, is_volatile, is_stateful, requests_recovery, job_data) FROM stdin;
com.liferay.portlet.social.messaging.CheckEquityLogMessageListener	com.liferay.portlet.social.messaging.CheckEquityLogMessageListener	\N	com.liferay.portal.scheduler.job.MessageSenderJob	f	f	f	f	\\254\\355\\000\\005sr\\000\\025org.quartz.JobDataMap\\237\\260\\203\\350\\277\\251\\260\\313\\002\\000\\000xr\\000&org.quartz.utils.StringKeyDirtyFlagMap\\202\\010\\350\\303\\373\\305](\\002\\000\\001Z\\000\\023allowsTransientDataxr\\000\\035org.quartz.utils.DirtyFlagMap\\023\\346.\\255(v\\012\\316\\002\\000\\002Z\\000\\005dirtyL\\000\\003mapt\\000\\017Ljava/util/Map;xp\\001sr\\000\\021java.util.HashMap\\005\\007\\332\\301\\303\\026`\\321\\003\\000\\002F\\000\\012loadFactorI\\000\\011thresholdxp?@\\000\\000\\000\\000\\000\\014w\\010\\000\\000\\000\\020\\000\\000\\000\\003t\\000\\007messagesr\\000+com.liferay.portal.kernel.messaging.Message\\231\\273Aofg\\204^\\002\\000\\005L\\000\\020_destinationNamet\\000\\022Ljava/lang/String;L\\000\\010_payloadt\\000\\022Ljava/lang/Object;L\\000\\030_responseDestinationNameq\\000~\\000\\011L\\000\\013_responseIdq\\000~\\000\\011L\\000\\007_valuesq\\000~\\000\\003xpppppsq\\000~\\000\\005?@\\000\\000\\000\\000\\000\\014w\\010\\000\\000\\000\\020\\000\\000\\000\\001t\\000\\014receiver_keyt\\000\\205com.liferay.portlet.social.messaging.CheckEquityLogMessageListener:com.liferay.portlet.social.messaging.CheckEquityLogMessageListenerxt\\000\\013descriptionpt\\000\\013destinationt\\000\\032liferay/scheduler_dispatchx\\000
\.


--
-- Data for Name: quartz_job_listeners; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY quartz_job_listeners (job_name, job_group, job_listener) FROM stdin;
\.


--
-- Data for Name: quartz_locks; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY quartz_locks (lock_name) FROM stdin;
TRIGGER_ACCESS
JOB_ACCESS
CALENDAR_ACCESS
STATE_ACCESS
MISFIRE_ACCESS
\.


--
-- Data for Name: quartz_paused_trigger_grps; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY quartz_paused_trigger_grps (trigger_group) FROM stdin;
\.


--
-- Data for Name: quartz_scheduler_state; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY quartz_scheduler_state (instance_name, last_checkin_time, checkin_interval) FROM stdin;
\.


--
-- Data for Name: quartz_simple_triggers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY quartz_simple_triggers (trigger_name, trigger_group, repeat_count, repeat_interval, times_triggered) FROM stdin;
com.liferay.portlet.social.messaging.CheckEquityLogMessageListener	com.liferay.portlet.social.messaging.CheckEquityLogMessageListener	-1	86400000	1
\.


--
-- Data for Name: quartz_trigger_listeners; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY quartz_trigger_listeners (trigger_name, trigger_group, trigger_listener) FROM stdin;
\.


--
-- Data for Name: quartz_triggers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY quartz_triggers (trigger_name, trigger_group, job_name, job_group, is_volatile, description, next_fire_time, prev_fire_time, priority, trigger_state, trigger_type, start_time, end_time, calendar_name, misfire_instr, job_data) FROM stdin;
com.liferay.portlet.social.messaging.CheckEquityLogMessageListener	com.liferay.portlet.social.messaging.CheckEquityLogMessageListener	com.liferay.portlet.social.messaging.CheckEquityLogMessageListener	com.liferay.portlet.social.messaging.CheckEquityLogMessageListener	f	\N	1449192159204	1449105759204	5	WAITING	SIMPLE	1449105759204	0	\N	0	
\.


--
-- Data for Name: ratingsentry; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY ratingsentry (entryid, companyid, userid, username, createdate, modifieddate, classnameid, classpk, score) FROM stdin;
\.


--
-- Data for Name: ratingsstats; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY ratingsstats (statsid, classnameid, classpk, totalentries, totalscore, averagescore) FROM stdin;
10318	10073	10309	0	0	0
10332	10095	10328	0	0	0
10353	10129	10345	0	0	0
10370	10068	10363	0	0	0
\.


--
-- Data for Name: region; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY region (regionid, countryid, regioncode, name, active_) FROM stdin;
1001	1	AB	Alberta	t
1002	1	BC	British Columbia	t
1003	1	MB	Manitoba	t
1004	1	NB	New Brunswick	t
1005	1	NL	Newfoundland and Labrador	t
1006	1	NT	Northwest Territories	t
1007	1	NS	Nova Scotia	t
1008	1	NU	Nunavut	t
1009	1	ON	Ontario	t
1010	1	PE	Prince Edward Island	t
1011	1	QC	Quebec	t
1012	1	SK	Saskatchewan	t
1013	1	YT	Yukon	t
3001	3	A	Alsace	t
3002	3	B	Aquitaine	t
3003	3	C	Auvergne	t
3004	3	P	Basse-Normandie	t
3005	3	D	Bourgogne	t
3006	3	E	Bretagne	t
3007	3	F	Centre	t
3008	3	G	Champagne-Ardenne	t
3009	3	H	Corse	t
3010	3	GF	Guyane	t
3011	3	I	Franche Comté	t
3012	3	GP	Guadeloupe	t
3013	3	Q	Haute-Normandie	t
3014	3	J	Île-de-France	t
3015	3	K	Languedoc-Roussillon	t
3016	3	L	Limousin	t
3017	3	M	Lorraine	t
3018	3	MQ	Martinique	t
3019	3	N	Midi-Pyrénées	t
3020	3	O	Nord Pas de Calais	t
3021	3	R	Pays de la Loire	t
3022	3	S	Picardie	t
3023	3	T	Poitou-Charentes	t
3024	3	U	Provence-Alpes-Côte-d'Azur	t
3025	3	RE	Réunion	t
3026	3	V	Rhône-Alpes	t
4001	4	BW	Baden-Württemberg	t
4002	4	BY	Bayern	t
4003	4	BE	Berlin	t
4004	4	BR	Brandenburg	t
4005	4	HB	Bremen	t
4006	4	HH	Hamburg	t
4007	4	HE	Hessen	t
4008	4	MV	Mecklenburg-Vorpommern	t
4009	4	NI	Niedersachsen	t
4010	4	NW	Nordrhein-Westfalen	t
4011	4	RP	Rheinland-Pfalz	t
4012	4	SL	Saarland	t
4013	4	SN	Sachsen	t
4014	4	ST	Sachsen-Anhalt	t
4015	4	SH	Schleswig-Holstein	t
4016	4	TH	Thüringen	t
8001	8	AG	Agrigento	t
8002	8	AL	Alessandria	t
8003	8	AN	Ancona	t
8004	8	AO	Aosta	t
8005	8	AR	Arezzo	t
8006	8	AP	Ascoli Piceno	t
8007	8	AT	Asti	t
8008	8	AV	Avellino	t
8009	8	BA	Bari	t
8010	8	BT	Barletta-Andria-Trani	t
8011	8	BL	Belluno	t
8012	8	BN	Benevento	t
8013	8	BG	Bergamo	t
8014	8	BI	Biella	t
8015	8	BO	Bologna	t
8016	8	BZ	Bolzano	t
8017	8	BS	Brescia	t
8018	8	BR	Brindisi	t
8019	8	CA	Cagliari	t
8020	8	CL	Caltanissetta	t
8021	8	CB	Campobasso	t
8022	8	CI	Carbonia-Iglesias	t
8023	8	CE	Caserta	t
8024	8	CT	Catania	t
8025	8	CZ	Catanzaro	t
8026	8	CH	Chieti	t
8027	8	CO	Como	t
8028	8	CS	Cosenza	t
8029	8	CR	Cremona	t
8030	8	KR	Crotone	t
8031	8	CN	Cuneo	t
8032	8	EN	Enna	t
8033	8	FM	Fermo	t
8034	8	FE	Ferrara	t
8035	8	FI	Firenze	t
8036	8	FG	Foggia	t
8037	8	FC	Forli-Cesena	t
8038	8	FR	Frosinone	t
8039	8	GE	Genova	t
8040	8	GO	Gorizia	t
8041	8	GR	Grosseto	t
8042	8	IM	Imperia	t
8043	8	IS	Isernia	t
8044	8	AQ	L'Aquila	t
8045	8	SP	La Spezia	t
8046	8	LT	Latina	t
8047	8	LE	Lecce	t
8048	8	LC	Lecco	t
8049	8	LI	Livorno	t
8050	8	LO	Lodi	t
8051	8	LU	Lucca	t
8052	8	MC	Macerata	t
8053	8	MN	Mantova	t
8054	8	MS	Massa-Carrara	t
8055	8	MT	Matera	t
8056	8	MA	Medio Campidano	t
8057	8	ME	Messina	t
8058	8	MI	Milano	t
8059	8	MO	Modena	t
8060	8	MZ	Monza	t
8061	8	NA	Napoli	t
8062	8	NO	Novara	t
8063	8	NU	Nuoro	t
8064	8	OG	Ogliastra	t
8065	8	OT	Olbia-Tempio	t
8066	8	OR	Oristano	t
8067	8	PD	Padova	t
8068	8	PA	Palermo	t
8069	8	PR	Parma	t
8070	8	PV	Pavia	t
8071	8	PG	Perugia	t
8072	8	PU	Pesaro e Urbino	t
8073	8	PE	Pescara	t
8074	8	PC	Piacenza	t
8075	8	PI	Pisa	t
8076	8	PT	Pistoia	t
8077	8	PN	Pordenone	t
8078	8	PZ	Potenza	t
8079	8	PO	Prato	t
8080	8	RG	Ragusa	t
8081	8	RA	Ravenna	t
8082	8	RC	Reggio Calabria	t
8083	8	RE	Reggio Emilia	t
8084	8	RI	Rieti	t
8085	8	RN	Rimini	t
8086	8	RM	Roma	t
8087	8	RO	Rovigo	t
8088	8	SA	Salerno	t
8089	8	SS	Sassari	t
8090	8	SV	Savona	t
8091	8	SI	Siena	t
8092	8	SR	Siracusa	t
8093	8	SO	Sondrio	t
8094	8	TA	Taranto	t
8095	8	TE	Teramo	t
8096	8	TR	Terni	t
8097	8	TO	Torino	t
8098	8	TP	Trapani	t
8099	8	TN	Trento	t
8100	8	TV	Treviso	t
8101	8	TS	Trieste	t
8102	8	UD	Udine	t
8103	8	VA	Varese	t
8104	8	VE	Venezia	t
8105	8	VB	Verbano-Cusio-Ossola	t
8106	8	VC	Vercelli	t
8107	8	VR	Verona	t
8108	8	VV	Vibo Valentia	t
8109	8	VI	Vicenza	t
8110	8	VT	Viterbo	t
15001	15	AN	Andalusia	t
15002	15	AR	Aragon	t
15003	15	AS	Asturias	t
15004	15	IB	Balearic Islands	t
15005	15	PV	Basque Country	t
15006	15	CN	Canary Islands	t
15007	15	CB	Cantabria	t
15008	15	CL	Castile and Leon	t
15009	15	CM	Castile-La Mancha	t
15010	15	CT	Catalonia	t
15011	15	CE	Ceuta	t
15012	15	EX	Extremadura	t
15013	15	GA	Galicia	t
15014	15	LO	La Rioja	t
15015	15	M	Madrid	t
15016	15	ML	Melilla	t
15017	15	MU	Murcia	t
15018	15	NA	Navarra	t
15019	15	VC	Valencia	t
19001	19	AL	Alabama	t
19002	19	AK	Alaska	t
19003	19	AZ	Arizona	t
19004	19	AR	Arkansas	t
19005	19	CA	California	t
19006	19	CO	Colorado	t
19007	19	CT	Connecticut	t
19008	19	DC	District of Columbia	t
19009	19	DE	Delaware	t
19010	19	FL	Florida	t
19011	19	GA	Georgia	t
19012	19	HI	Hawaii	t
19013	19	ID	Idaho	t
19014	19	IL	Illinois	t
19015	19	IN	Indiana	t
19016	19	IA	Iowa	t
19017	19	KS	Kansas	t
19018	19	KY	Kentucky 	t
19019	19	LA	Louisiana 	t
19020	19	ME	Maine	t
19021	19	MD	Maryland	t
19022	19	MA	Massachusetts	t
19023	19	MI	Michigan	t
19024	19	MN	Minnesota	t
19025	19	MS	Mississippi	t
19026	19	MO	Missouri	t
19027	19	MT	Montana	t
19028	19	NE	Nebraska	t
19029	19	NV	Nevada	t
19030	19	NH	New Hampshire	t
19031	19	NJ	New Jersey	t
19032	19	NM	New Mexico	t
19033	19	NY	New York	t
19034	19	NC	North Carolina	t
19035	19	ND	North Dakota	t
19036	19	OH	Ohio	t
19037	19	OK	Oklahoma 	t
19038	19	OR	Oregon	t
19039	19	PA	Pennsylvania	t
19040	19	PR	Puerto Rico	t
19041	19	RI	Rhode Island	t
19042	19	SC	South Carolina	t
19043	19	SD	South Dakota	t
19044	19	TN	Tennessee	t
19045	19	TX	Texas	t
19046	19	UT	Utah	t
19047	19	VT	Vermont	t
19048	19	VA	Virginia	t
19049	19	WA	Washington	t
19050	19	WV	West Virginia	t
19051	19	WI	Wisconsin	t
19052	19	WY	Wyoming	t
32001	32	ACT	Australian Capital Territory	t
32002	32	NSW	New South Wales	t
32003	32	NT	Northern Territory	t
32004	32	QLD	Queensland	t
32005	32	SA	South Australia	t
32006	32	TAS	Tasmania	t
32007	32	VIC	Victoria	t
32008	32	WA	Western Australia	t
202001	202	AG	Aargau	t
202002	202	AR	Appenzell Ausserrhoden	t
202003	202	AI	Appenzell Innerrhoden	t
202004	202	BL	Basel-Landschaft	t
202005	202	BS	Basel-Stadt	t
202006	202	BE	Bern	t
202007	202	FR	Fribourg	t
202008	202	GE	Geneva	t
202009	202	GL	Glarus	t
202010	202	GR	Graubünden	t
202011	202	JU	Jura	t
202012	202	LU	Lucerne	t
202013	202	NE	Neuchâtel	t
202014	202	NW	Nidwalden	t
202015	202	OW	Obwalden	t
202016	202	SH	Schaffhausen	t
202017	202	SZ	Schwyz	t
202018	202	SO	Solothurn	t
202019	202	SG	St. Gallen	t
202020	202	TG	Thurgau	t
202021	202	TI	Ticino	t
202022	202	UR	Uri	t
202023	202	VS	Valais	t
202024	202	VD	Vaud	t
202025	202	ZG	Zug	t
202026	202	ZH	Zürich	t
\.


--
-- Data for Name: release_; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY release_ (releaseid, createdate, modifieddate, servletcontextname, buildnumber, builddate, verified, teststring) FROM stdin;
1	2015-12-02 17:22:31.772	2015-12-03 01:22:34.107	portal	6006	2011-02-17 00:00:00	t	You take the blue pill, the story ends, you wake up in your bed and believe whatever you want to believe. You take the red pill, you stay in Wonderland, and I show you how deep the rabbit hole goes.
\.


--
-- Data for Name: resource_; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY resource_ (resourceid, codeid, primkey) FROM stdin;
\.


--
-- Data for Name: resourceaction; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY resourceaction (resourceactionid, name, actionid, bitwisevalue) FROM stdin;
1	98	ACCESS_IN_CONTROL_PANEL	2
2	98	ADD_TO_PAGE	4
3	98	CONFIGURATION	8
4	98	VIEW	1
5	com.liferay.portlet.softwarecatalog.model.SCFrameworkVersion	DELETE	2
6	com.liferay.portlet.softwarecatalog.model.SCFrameworkVersion	PERMISSIONS	4
7	com.liferay.portlet.softwarecatalog.model.SCFrameworkVersion	UPDATE	8
8	com.liferay.portlet.softwarecatalog	ADD_FRAMEWORK_VERSION	2
9	com.liferay.portlet.softwarecatalog	ADD_PRODUCT_ENTRY	4
10	com.liferay.portlet.softwarecatalog	PERMISSIONS	8
11	com.liferay.portlet.softwarecatalog.model.SCLicense	DELETE	2
12	com.liferay.portlet.softwarecatalog.model.SCLicense	PERMISSIONS	4
13	com.liferay.portlet.softwarecatalog.model.SCLicense	UPDATE	8
14	com.liferay.portlet.softwarecatalog.model.SCLicense	VIEW	1
15	com.liferay.portlet.softwarecatalog.model.SCProductEntry	ADD_DISCUSSION	2
16	com.liferay.portlet.softwarecatalog.model.SCProductEntry	DELETE	4
17	com.liferay.portlet.softwarecatalog.model.SCProductEntry	DELETE_DISCUSSION	8
18	com.liferay.portlet.softwarecatalog.model.SCProductEntry	PERMISSIONS	16
19	com.liferay.portlet.softwarecatalog.model.SCProductEntry	UPDATE	32
20	com.liferay.portlet.softwarecatalog.model.SCProductEntry	UPDATE_DISCUSSION	64
21	com.liferay.portlet.softwarecatalog.model.SCProductEntry	VIEW	1
22	66	VIEW	1
23	66	ADD_TO_PAGE	2
24	66	CONFIGURATION	4
25	156	VIEW	1
26	156	ADD_TO_PAGE	2
27	156	CONFIGURATION	4
28	152	ACCESS_IN_CONTROL_PANEL	2
29	152	CONFIGURATION	4
30	152	VIEW	1
31	27	VIEW	1
32	27	ADD_TO_PAGE	2
33	27	CONFIGURATION	4
34	88	VIEW	1
35	88	ADD_TO_PAGE	2
36	88	CONFIGURATION	4
37	87	VIEW	1
38	87	ADD_TO_PAGE	2
39	87	CONFIGURATION	4
40	134	ACCESS_IN_CONTROL_PANEL	2
41	134	CONFIGURATION	4
42	134	VIEW	1
43	com.liferay.portal.model.Layout	ADD_DISCUSSION	2
44	com.liferay.portal.model.Layout	DELETE	4
45	com.liferay.portal.model.Layout	DELETE_DISCUSSION	8
46	com.liferay.portal.model.Layout	UPDATE	16
47	com.liferay.portal.model.Layout	UPDATE_DISCUSSION	32
48	com.liferay.portal.model.Layout	VIEW	1
49	com.liferay.portal.model.Layout	PERMISSIONS	64
50	com.liferay.portal.model.LayoutSetPrototype	DELETE	2
51	com.liferay.portal.model.LayoutSetPrototype	PERMISSIONS	4
52	com.liferay.portal.model.LayoutSetPrototype	UPDATE	8
53	com.liferay.portal.model.LayoutSetPrototype	VIEW	1
54	com.liferay.portal.model.LayoutPrototype	DELETE	2
55	com.liferay.portal.model.LayoutPrototype	PERMISSIONS	4
56	com.liferay.portal.model.LayoutPrototype	UPDATE	8
57	com.liferay.portal.model.LayoutPrototype	VIEW	1
58	com.liferay.portal.model.Team	ASSIGN_MEMBERS	2
59	com.liferay.portal.model.Team	DELETE	4
60	com.liferay.portal.model.Team	PERMISSIONS	8
61	com.liferay.portal.model.Team	UPDATE	16
62	com.liferay.portal.model.Team	VIEW	1
63	com.liferay.portal.model.Group	APPROVE_PROPOSAL	2
64	com.liferay.portal.model.Group	ASSIGN_MEMBERS	4
65	com.liferay.portal.model.Group	ASSIGN_REVIEWER	8
66	com.liferay.portal.model.Group	ASSIGN_USER_ROLES	16
67	com.liferay.portal.model.Group	DELETE	32
68	com.liferay.portal.model.Group	MANAGE_ANNOUNCEMENTS	64
69	com.liferay.portal.model.Group	MANAGE_ARCHIVED_SETUPS	128
70	com.liferay.portal.model.Group	MANAGE_LAYOUTS	256
71	com.liferay.portal.model.Group	MANAGE_STAGING	512
72	com.liferay.portal.model.Group	MANAGE_TEAMS	1024
73	com.liferay.portal.model.Group	PERMISSIONS	2048
74	com.liferay.portal.model.Group	PUBLISH_STAGING	4096
75	com.liferay.portal.model.Group	PUBLISH_TO_REMOTE	8192
76	com.liferay.portal.model.Group	UPDATE	16384
77	com.liferay.portlet.tasks.model.TasksProposal	ADD_DISCUSSION	2
78	com.liferay.portlet.tasks.model.TasksProposal	DELETE	4
79	com.liferay.portlet.tasks.model.TasksProposal	DELETE_DISCUSSION	8
80	com.liferay.portlet.tasks.model.TasksProposal	UPDATE	16
81	com.liferay.portlet.tasks.model.TasksProposal	UPDATE_DISCUSSION	32
82	com.liferay.portlet.tasks.model.TasksProposal	VIEW	1
83	com.liferay.portlet.tasks.model.TasksProposal	PERMISSIONS	64
84	130	ACCESS_IN_CONTROL_PANEL	2
85	130	CONFIGURATION	4
86	130	VIEW	1
87	122	VIEW	1
88	122	ADD_TO_PAGE	2
89	122	CONFIGURATION	4
90	36	ADD_TO_PAGE	2
91	36	CONFIGURATION	4
92	36	VIEW	1
93	com.liferay.portlet.wiki.model.WikiPage	ADD_DISCUSSION	2
94	com.liferay.portlet.wiki.model.WikiPage	DELETE	4
95	com.liferay.portlet.wiki.model.WikiPage	DELETE_DISCUSSION	8
96	com.liferay.portlet.wiki.model.WikiPage	PERMISSIONS	16
97	com.liferay.portlet.wiki.model.WikiPage	SUBSCRIBE	32
98	com.liferay.portlet.wiki.model.WikiPage	UPDATE	64
99	com.liferay.portlet.wiki.model.WikiPage	UPDATE_DISCUSSION	128
100	com.liferay.portlet.wiki.model.WikiPage	VIEW	1
101	com.liferay.portlet.wiki.model.WikiNode	ADD_ATTACHMENT	2
102	com.liferay.portlet.wiki.model.WikiNode	ADD_PAGE	4
103	com.liferay.portlet.wiki.model.WikiNode	DELETE	8
104	com.liferay.portlet.wiki.model.WikiNode	IMPORT	16
105	com.liferay.portlet.wiki.model.WikiNode	PERMISSIONS	32
106	com.liferay.portlet.wiki.model.WikiNode	SUBSCRIBE	64
107	com.liferay.portlet.wiki.model.WikiNode	UPDATE	128
108	com.liferay.portlet.wiki.model.WikiNode	VIEW	1
109	com.liferay.portlet.wiki	ADD_NODE	2
110	com.liferay.portlet.wiki	PERMISSIONS	4
111	26	VIEW	1
112	26	ADD_TO_PAGE	2
113	26	CONFIGURATION	4
114	104	VIEW	1
115	104	ADD_TO_PAGE	2
116	104	CONFIGURATION	4
117	64	VIEW	1
118	64	ADD_TO_PAGE	2
119	64	CONFIGURATION	4
120	153	ACCESS_IN_CONTROL_PANEL	2
121	153	CONFIGURATION	4
122	153	VIEW	1
123	129	ACCESS_IN_CONTROL_PANEL	2
124	129	CONFIGURATION	4
125	129	VIEW	1
126	com.liferay.portal.model.PasswordPolicy	ASSIGN_MEMBERS	2
127	com.liferay.portal.model.PasswordPolicy	DELETE	4
128	com.liferay.portal.model.PasswordPolicy	PERMISSIONS	8
129	com.liferay.portal.model.PasswordPolicy	UPDATE	16
130	com.liferay.portal.model.PasswordPolicy	VIEW	1
131	100	VIEW	1
132	100	ADD_TO_PAGE	2
133	100	CONFIGURATION	4
134	157	ACCESS_IN_CONTROL_PANEL	2
135	157	CONFIGURATION	4
136	157	VIEW	1
137	19	ACCESS_IN_CONTROL_PANEL	2
138	19	ADD_TO_PAGE	4
139	19	CONFIGURATION	8
140	19	VIEW	1
141	com.liferay.portlet.messageboards.model.MBCategory	ADD_FILE	2
142	com.liferay.portlet.messageboards.model.MBCategory	ADD_MESSAGE	4
143	com.liferay.portlet.messageboards.model.MBCategory	ADD_SUBCATEGORY	8
144	com.liferay.portlet.messageboards.model.MBCategory	DELETE	16
145	com.liferay.portlet.messageboards.model.MBCategory	LOCK_THREAD	32
146	com.liferay.portlet.messageboards.model.MBCategory	MOVE_THREAD	64
147	com.liferay.portlet.messageboards.model.MBCategory	PERMISSIONS	128
148	com.liferay.portlet.messageboards.model.MBCategory	REPLY_TO_MESSAGE	256
149	com.liferay.portlet.messageboards.model.MBCategory	SUBSCRIBE	512
150	com.liferay.portlet.messageboards.model.MBCategory	UPDATE	1024
151	com.liferay.portlet.messageboards.model.MBCategory	UPDATE_THREAD_PRIORITY	2048
152	com.liferay.portlet.messageboards.model.MBCategory	VIEW	1
153	com.liferay.portlet.messageboards	ADD_CATEGORY	2
154	com.liferay.portlet.messageboards	ADD_FILE	4
155	com.liferay.portlet.messageboards	ADD_MESSAGE	8
156	com.liferay.portlet.messageboards	BAN_USER	16
157	com.liferay.portlet.messageboards	MOVE_THREAD	32
158	com.liferay.portlet.messageboards	LOCK_THREAD	64
159	com.liferay.portlet.messageboards	PERMISSIONS	128
160	com.liferay.portlet.messageboards	REPLY_TO_MESSAGE	256
161	com.liferay.portlet.messageboards	SUBSCRIBE	512
162	com.liferay.portlet.messageboards	UPDATE_THREAD_PRIORITY	1024
163	com.liferay.portlet.messageboards.model.MBMessage	DELETE	2
164	com.liferay.portlet.messageboards.model.MBMessage	PERMISSIONS	4
165	com.liferay.portlet.messageboards.model.MBMessage	SUBSCRIBE	8
166	com.liferay.portlet.messageboards.model.MBMessage	UPDATE	16
167	com.liferay.portlet.messageboards.model.MBMessage	VIEW	1
168	160	VIEW	1
169	160	ADD_TO_PAGE	2
170	160	CONFIGURATION	4
171	128	ACCESS_IN_CONTROL_PANEL	2
172	128	CONFIGURATION	4
173	128	VIEW	1
174	com.liferay.portal.model.Role	ASSIGN_MEMBERS	2
175	com.liferay.portal.model.Role	DEFINE_PERMISSIONS	4
176	com.liferay.portal.model.Role	DELETE	8
177	com.liferay.portal.model.Role	MANAGE_ANNOUNCEMENTS	16
178	com.liferay.portal.model.Role	PERMISSIONS	32
179	com.liferay.portal.model.Role	UPDATE	64
180	com.liferay.portal.model.Role	VIEW	1
181	86	VIEW	1
182	86	ADD_TO_PAGE	2
183	86	CONFIGURATION	4
184	154	ACCESS_IN_CONTROL_PANEL	2
185	154	CONFIGURATION	4
186	154	VIEW	1
187	148	VIEW	1
188	148	ADD_TO_PAGE	2
189	148	CONFIGURATION	4
190	11	ADD_TO_PAGE	2
191	11	CONFIGURATION	4
192	11	VIEW	1
193	120	VIEW	1
194	120	ADD_TO_PAGE	2
195	120	CONFIGURATION	4
196	29	ADD_TO_PAGE	2
197	29	CONFIGURATION	4
198	29	VIEW	1
199	158	ACCESS_IN_CONTROL_PANEL	2
200	158	CONFIGURATION	4
201	158	VIEW	1
202	124	VIEW	1
203	124	ADD_TO_PAGE	2
204	124	CONFIGURATION	4
205	8	ACCESS_IN_CONTROL_PANEL	2
206	8	ADD_TO_PAGE	4
207	8	CONFIGURATION	8
208	8	VIEW	1
209	com.liferay.portlet.calendar	ADD_EVENT	2
210	com.liferay.portlet.calendar	EXPORT_ALL_EVENTS	4
211	com.liferay.portlet.calendar	PERMISSIONS	8
212	com.liferay.portlet.calendar.model.CalEvent	ADD_DISCUSSION	2
213	com.liferay.portlet.calendar.model.CalEvent	DELETE	4
214	com.liferay.portlet.calendar.model.CalEvent	DELETE_DISCUSSION	8
215	com.liferay.portlet.calendar.model.CalEvent	PERMISSIONS	16
216	com.liferay.portlet.calendar.model.CalEvent	UPDATE	32
217	com.liferay.portlet.calendar.model.CalEvent	UPDATE_DISCUSSION	64
218	com.liferay.portlet.calendar.model.CalEvent	VIEW	1
219	58	ADD_TO_PAGE	2
220	58	CONFIGURATION	4
221	58	VIEW	1
222	155	ACCESS_IN_CONTROL_PANEL	2
223	155	VIEW	1
224	155	CONFIGURATION	4
225	97	VIEW	1
226	97	ADD_TO_PAGE	2
227	97	CONFIGURATION	4
228	71	ADD_TO_PAGE	2
229	71	CONFIGURATION	4
230	71	VIEW	1
231	39	VIEW	1
232	39	ADD_TO_PAGE	2
233	39	CONFIGURATION	4
234	85	ADD_TO_PAGE	2
235	85	CONFIGURATION	4
236	85	VIEW	1
237	118	VIEW	1
238	118	ADD_TO_PAGE	2
239	118	CONFIGURATION	4
240	107	VIEW	1
241	107	ADD_TO_PAGE	2
242	107	CONFIGURATION	4
243	79	CONFIGURATION	2
244	79	VIEW	1
245	79	ADD_TO_PAGE	4
246	30	VIEW	1
247	30	ADD_TO_PAGE	2
248	30	CONFIGURATION	4
249	147	ACCESS_IN_CONTROL_PANEL	2
250	147	CONFIGURATION	4
251	147	VIEW	1
252	48	VIEW	1
253	48	ADD_TO_PAGE	2
254	48	CONFIGURATION	4
255	125	ACCESS_IN_CONTROL_PANEL	2
256	125	CONFIGURATION	4
257	125	EXPORT_USER	8
258	125	VIEW	1
259	com.liferay.portal.model.User	DELETE	2
260	com.liferay.portal.model.User	IMPERSONATE	4
261	com.liferay.portal.model.User	PERMISSIONS	8
262	com.liferay.portal.model.User	UPDATE	16
263	com.liferay.portal.model.User	VIEW	1
264	144	VIEW	1
265	144	ADD_TO_PAGE	2
266	144	CONFIGURATION	4
267	146	ACCESS_IN_CONTROL_PANEL	2
268	146	CONFIGURATION	4
269	146	VIEW	1
270	62	VIEW	1
271	62	ADD_TO_PAGE	2
272	62	CONFIGURATION	4
273	159	VIEW	1
274	159	ADD_TO_PAGE	2
275	159	CONFIGURATION	4
276	108	VIEW	1
277	108	ADD_TO_PAGE	2
278	108	CONFIGURATION	4
279	139	ADD_EXPANDO	2
280	139	CONFIGURATION	4
281	139	VIEW	1
282	139	ADD_TO_PAGE	8
283	com.liferay.portlet.expando.model.ExpandoColumn	DELETE	2
284	com.liferay.portlet.expando.model.ExpandoColumn	PERMISSIONS	4
285	com.liferay.portlet.expando.model.ExpandoColumn	UPDATE	8
286	com.liferay.portlet.expando.model.ExpandoColumn	VIEW	1
287	84	ADD_ENTRY	2
288	84	ADD_TO_PAGE	4
289	84	CONFIGURATION	8
290	84	VIEW	1
291	com.liferay.portlet.announcements.model.AnnouncementsEntry	DELETE	2
292	com.liferay.portlet.announcements.model.AnnouncementsEntry	UPDATE	4
293	com.liferay.portlet.announcements.model.AnnouncementsEntry	VIEW	1
294	com.liferay.portlet.announcements.model.AnnouncementsEntry	PERMISSIONS	8
295	101	VIEW	1
296	101	ADD_TO_PAGE	2
297	101	CONFIGURATION	4
298	121	VIEW	1
299	121	ADD_TO_PAGE	2
300	121	CONFIGURATION	4
301	49	VIEW	1
302	49	ADD_TO_PAGE	2
303	49	CONFIGURATION	4
304	143	VIEW	1
305	143	ADD_TO_PAGE	2
306	143	CONFIGURATION	4
307	37	VIEW	1
308	37	ADD_TO_PAGE	2
309	37	CONFIGURATION	4
310	77	VIEW	1
311	77	ADD_TO_PAGE	2
312	77	CONFIGURATION	4
313	115	VIEW	1
314	115	ADD_TO_PAGE	2
315	115	CONFIGURATION	4
316	56	ADD_TO_PAGE	2
317	56	CONFIGURATION	4
318	56	VIEW	1
319	142	VIEW	1
320	142	ADD_TO_PAGE	2
321	142	CONFIGURATION	4
322	111	VIEW	1
323	111	ADD_TO_PAGE	2
324	111	CONFIGURATION	4
325	16	PREFERENCES	2
326	16	GUEST_PREFERENCES	4
327	16	VIEW	1
328	16	ADD_TO_PAGE	8
329	16	CONFIGURATION	16
330	3	VIEW	1
331	3	ADD_TO_PAGE	2
332	3	CONFIGURATION	4
333	20	ACCESS_IN_CONTROL_PANEL	2
334	20	ADD_TO_PAGE	4
335	20	CONFIGURATION	8
336	20	VIEW	1
337	com.liferay.portlet.documentlibrary.model.DLFolder	ACCESS	2
338	com.liferay.portlet.documentlibrary.model.DLFolder	ADD_DOCUMENT	4
339	com.liferay.portlet.documentlibrary.model.DLFolder	ADD_SHORTCUT	8
340	com.liferay.portlet.documentlibrary.model.DLFolder	ADD_SUBFOLDER	16
341	com.liferay.portlet.documentlibrary.model.DLFolder	DELETE	32
342	com.liferay.portlet.documentlibrary.model.DLFolder	PERMISSIONS	64
343	com.liferay.portlet.documentlibrary.model.DLFolder	UPDATE	128
344	com.liferay.portlet.documentlibrary.model.DLFolder	VIEW	1
345	com.liferay.portlet.documentlibrary	ADD_DOCUMENT	2
346	com.liferay.portlet.documentlibrary	ADD_FOLDER	4
347	com.liferay.portlet.documentlibrary	ADD_SHORTCUT	8
348	com.liferay.portlet.documentlibrary	PERMISSIONS	16
349	com.liferay.portlet.documentlibrary	VIEW	1
350	com.liferay.portlet.documentlibrary.model.DLFileEntry	ADD_DISCUSSION	2
351	com.liferay.portlet.documentlibrary.model.DLFileEntry	DELETE	4
352	com.liferay.portlet.documentlibrary.model.DLFileEntry	DELETE_DISCUSSION	8
353	com.liferay.portlet.documentlibrary.model.DLFileEntry	PERMISSIONS	16
354	com.liferay.portlet.documentlibrary.model.DLFileEntry	UPDATE	32
355	com.liferay.portlet.documentlibrary.model.DLFileEntry	UPDATE_DISCUSSION	64
356	com.liferay.portlet.documentlibrary.model.DLFileEntry	VIEW	1
357	com.liferay.portlet.documentlibrary.model.DLFileShortcut	ADD_DISCUSSION	2
358	com.liferay.portlet.documentlibrary.model.DLFileShortcut	DELETE	4
359	com.liferay.portlet.documentlibrary.model.DLFileShortcut	DELETE_DISCUSSION	8
360	com.liferay.portlet.documentlibrary.model.DLFileShortcut	PERMISSIONS	16
361	com.liferay.portlet.documentlibrary.model.DLFileShortcut	UPDATE	32
362	com.liferay.portlet.documentlibrary.model.DLFileShortcut	UPDATE_DISCUSSION	64
363	com.liferay.portlet.documentlibrary.model.DLFileShortcut	VIEW	1
364	23	VIEW	1
365	23	ADD_TO_PAGE	2
366	23	CONFIGURATION	4
367	145	VIEW	1
368	145	ADD_TO_PAGE	2
369	145	CONFIGURATION	4
370	com.liferay.portlet.asset	ADD_CATEGORY	2
371	com.liferay.portlet.asset	ADD_VOCABULARY	4
372	com.liferay.portlet.asset	ADD_TAG	8
373	com.liferay.portlet.asset	PERMISSIONS	16
374	com.liferay.portlet.asset.model.AssetCategory	ADD_CATEGORY	2
375	com.liferay.portlet.asset.model.AssetCategory	DELETE	4
376	com.liferay.portlet.asset.model.AssetCategory	PERMISSIONS	8
377	com.liferay.portlet.asset.model.AssetCategory	UPDATE	16
378	com.liferay.portlet.asset.model.AssetCategory	VIEW	1
379	com.liferay.portlet.asset.model.AssetVocabulary	DELETE	2
380	com.liferay.portlet.asset.model.AssetVocabulary	PERMISSIONS	4
381	com.liferay.portlet.asset.model.AssetVocabulary	UPDATE	8
382	com.liferay.portlet.asset.model.AssetVocabulary	VIEW	1
383	83	ADD_ENTRY	2
384	83	ADD_TO_PAGE	4
385	83	CONFIGURATION	8
386	83	VIEW	1
387	99	VIEW	1
388	99	ADD_TO_PAGE	2
389	99	CONFIGURATION	4
390	com.liferay.portlet.asset.model.AssetTag	DELETE	2
391	com.liferay.portlet.asset.model.AssetTag	PERMISSIONS	4
392	com.liferay.portlet.asset.model.AssetTag	UPDATE	8
393	com.liferay.portlet.asset.model.AssetTag	VIEW	1
394	70	VIEW	1
395	70	ADD_TO_PAGE	2
396	70	CONFIGURATION	4
397	141	VIEW	1
398	141	ADD_TO_PAGE	2
399	141	CONFIGURATION	4
400	9	VIEW	1
401	9	ADD_TO_PAGE	2
402	9	CONFIGURATION	4
403	137	ACCESS_IN_CONTROL_PANEL	2
404	137	CONFIGURATION	4
405	137	VIEW	1
406	28	ACCESS_IN_CONTROL_PANEL	2
407	28	ADD_TO_PAGE	4
408	28	CONFIGURATION	8
409	28	VIEW	1
503	61	VIEW	1
410	com.liferay.portlet.bookmarks.model.BookmarksFolder	ACCESS	2
411	com.liferay.portlet.bookmarks.model.BookmarksFolder	ADD_ENTRY	4
412	com.liferay.portlet.bookmarks.model.BookmarksFolder	ADD_SUBFOLDER	8
413	com.liferay.portlet.bookmarks.model.BookmarksFolder	DELETE	16
414	com.liferay.portlet.bookmarks.model.BookmarksFolder	PERMISSIONS	32
415	com.liferay.portlet.bookmarks.model.BookmarksFolder	UPDATE	64
416	com.liferay.portlet.bookmarks.model.BookmarksFolder	VIEW	1
417	com.liferay.portlet.bookmarks	ADD_ENTRY	2
418	com.liferay.portlet.bookmarks	ADD_FOLDER	4
419	com.liferay.portlet.bookmarks	PERMISSIONS	8
420	com.liferay.portlet.bookmarks.model.BookmarksEntry	DELETE	2
421	com.liferay.portlet.bookmarks.model.BookmarksEntry	PERMISSIONS	4
422	com.liferay.portlet.bookmarks.model.BookmarksEntry	UPDATE	8
423	com.liferay.portlet.bookmarks.model.BookmarksEntry	VIEW	1
424	133	VIEW	1
425	133	ADD_TO_PAGE	2
426	133	CONFIGURATION	4
427	116	VIEW	1
428	116	ADD_TO_PAGE	2
429	116	CONFIGURATION	4
430	15	ACCESS_IN_CONTROL_PANEL	2
431	15	ADD_TO_PAGE	4
432	15	CONFIGURATION	8
433	15	VIEW	1
434	com.liferay.portlet.journal.model.JournalFeed	DELETE	2
435	com.liferay.portlet.journal.model.JournalFeed	PERMISSIONS	4
436	com.liferay.portlet.journal.model.JournalFeed	UPDATE	8
437	com.liferay.portlet.journal.model.JournalFeed	VIEW	1
438	com.liferay.portlet.journal.model.JournalArticle	ADD_DISCUSSION	2
439	com.liferay.portlet.journal.model.JournalArticle	DELETE	4
440	com.liferay.portlet.journal.model.JournalArticle	DELETE_DISCUSSION	8
441	com.liferay.portlet.journal.model.JournalArticle	EXPIRE	16
442	com.liferay.portlet.journal.model.JournalArticle	PERMISSIONS	32
443	com.liferay.portlet.journal.model.JournalArticle	UPDATE	64
444	com.liferay.portlet.journal.model.JournalArticle	UPDATE_DISCUSSION	128
445	com.liferay.portlet.journal.model.JournalArticle	VIEW	1
446	com.liferay.portlet.journal	ADD_ARTICLE	2
447	com.liferay.portlet.journal	ADD_FEED	4
448	com.liferay.portlet.journal	ADD_STRUCTURE	8
449	com.liferay.portlet.journal	ADD_TEMPLATE	16
450	com.liferay.portlet.journal	SUBSCRIBE	32
451	com.liferay.portlet.journal	PERMISSIONS	64
452	com.liferay.portlet.journal.model.JournalStructure	DELETE	2
453	com.liferay.portlet.journal.model.JournalStructure	PERMISSIONS	4
454	com.liferay.portlet.journal.model.JournalStructure	UPDATE	8
455	com.liferay.portlet.journal.model.JournalStructure	VIEW	1
456	com.liferay.portlet.journal.model.JournalTemplate	DELETE	2
457	com.liferay.portlet.journal.model.JournalTemplate	PERMISSIONS	4
458	com.liferay.portlet.journal.model.JournalTemplate	UPDATE	8
459	com.liferay.portlet.journal.model.JournalTemplate	VIEW	1
460	47	VIEW	1
461	47	ADD_TO_PAGE	2
462	47	CONFIGURATION	4
463	82	VIEW	1
464	82	ADD_TO_PAGE	2
465	82	CONFIGURATION	4
466	103	VIEW	1
467	103	ADD_TO_PAGE	2
468	103	CONFIGURATION	4
469	151	ACCESS_IN_CONTROL_PANEL	2
470	151	CONFIGURATION	4
471	151	VIEW	1
472	140	VIEW	1
473	140	ADD_TO_PAGE	2
474	140	CONFIGURATION	4
475	54	VIEW	1
476	54	ADD_TO_PAGE	2
477	54	CONFIGURATION	4
478	132	ACCESS_IN_CONTROL_PANEL	2
479	132	CONFIGURATION	4
480	132	VIEW	1
481	34	ADD_TO_PAGE	2
482	34	CONFIGURATION	4
483	34	VIEW	1
484	com.liferay.portlet.shopping	ADD_CATEGORY	2
485	com.liferay.portlet.shopping	ADD_ITEM	4
486	com.liferay.portlet.shopping	MANAGE_COUPONS	8
487	com.liferay.portlet.shopping	MANAGE_ORDERS	16
488	com.liferay.portlet.shopping	PERMISSIONS	32
489	com.liferay.portlet.shopping.model.ShoppingCategory	ADD_ITEM	2
490	com.liferay.portlet.shopping.model.ShoppingCategory	ADD_SUBCATEGORY	4
491	com.liferay.portlet.shopping.model.ShoppingCategory	DELETE	8
492	com.liferay.portlet.shopping.model.ShoppingCategory	PERMISSIONS	16
493	com.liferay.portlet.shopping.model.ShoppingCategory	UPDATE	32
494	com.liferay.portlet.shopping.model.ShoppingCategory	VIEW	1
495	com.liferay.portlet.shopping.model.ShoppingOrder	DELETE	2
496	com.liferay.portlet.shopping.model.ShoppingOrder	PERMISSIONS	4
497	com.liferay.portlet.shopping.model.ShoppingOrder	UPDATE	8
498	com.liferay.portlet.shopping.model.ShoppingOrder	VIEW	1
499	com.liferay.portlet.shopping.model.ShoppingItem	DELETE	2
500	com.liferay.portlet.shopping.model.ShoppingItem	PERMISSIONS	4
501	com.liferay.portlet.shopping.model.ShoppingItem	UPDATE	8
502	com.liferay.portlet.shopping.model.ShoppingItem	VIEW	1
504	61	ADD_TO_PAGE	2
505	61	CONFIGURATION	4
506	73	ADD_TO_PAGE	2
507	73	CONFIGURATION	4
508	73	VIEW	1
509	31	ACCESS_IN_CONTROL_PANEL	2
510	31	ADD_TO_PAGE	4
511	31	CONFIGURATION	8
512	31	VIEW	1
513	com.liferay.portlet.imagegallery.model.IGImage	DELETE	2
514	com.liferay.portlet.imagegallery.model.IGImage	PERMISSIONS	4
515	com.liferay.portlet.imagegallery.model.IGImage	UPDATE	8
516	com.liferay.portlet.imagegallery.model.IGImage	VIEW	1
517	com.liferay.portlet.imagegallery.model.IGFolder	ACCESS	2
518	com.liferay.portlet.imagegallery.model.IGFolder	ADD_IMAGE	4
519	com.liferay.portlet.imagegallery.model.IGFolder	ADD_SUBFOLDER	8
520	com.liferay.portlet.imagegallery.model.IGFolder	DELETE	16
521	com.liferay.portlet.imagegallery.model.IGFolder	PERMISSIONS	32
522	com.liferay.portlet.imagegallery.model.IGFolder	UPDATE	64
523	com.liferay.portlet.imagegallery.model.IGFolder	VIEW	1
524	com.liferay.portlet.imagegallery	ADD_FOLDER	2
525	com.liferay.portlet.imagegallery	ADD_IMAGE	4
526	com.liferay.portlet.imagegallery	PERMISSIONS	8
527	com.liferay.portlet.imagegallery	VIEW	1
528	136	ACCESS_IN_CONTROL_PANEL	2
529	136	CONFIGURATION	4
530	136	VIEW	1
531	127	ACCESS_IN_CONTROL_PANEL	2
532	127	CONFIGURATION	4
533	127	VIEW	1
534	com.liferay.portal.model.UserGroup	ASSIGN_MEMBERS	2
535	com.liferay.portal.model.UserGroup	DELETE	4
536	com.liferay.portal.model.UserGroup	MANAGE_ANNOUNCEMENTS	8
537	com.liferay.portal.model.UserGroup	PERMISSIONS	16
538	com.liferay.portal.model.UserGroup	MANAGE_LAYOUTS	32
539	com.liferay.portal.model.UserGroup	UPDATE	64
540	com.liferay.portal.model.UserGroup	VIEW	1
541	50	VIEW	1
542	50	ADD_TO_PAGE	2
543	50	CONFIGURATION	4
544	25	ACCESS_IN_CONTROL_PANEL	2
545	25	CONFIGURATION	4
546	25	VIEW	1
547	com.liferay.portlet.polls	ADD_QUESTION	2
548	com.liferay.portlet.polls	PERMISSIONS	4
549	com.liferay.portlet.polls.model.PollsQuestion	ADD_VOTE	2
550	com.liferay.portlet.polls.model.PollsQuestion	DELETE	4
551	com.liferay.portlet.polls.model.PollsQuestion	PERMISSIONS	8
552	com.liferay.portlet.polls.model.PollsQuestion	UPDATE	16
553	com.liferay.portlet.polls.model.PollsQuestion	VIEW	1
554	90	ADD_COMMUNITY	2
555	90	ADD_LAYOUT_PROTOTYPE	4
556	90	ADD_LAYOUT_SET_PROTOTYPE	8
557	90	ADD_LICENSE	16
558	90	ADD_ORGANIZATION	32
559	90	ADD_PASSWORD_POLICY	64
560	90	ADD_ROLE	128
561	90	ADD_USER	256
562	90	ADD_USER_GROUP	512
563	90	CONFIGURATION	1024
564	90	EXPORT_USER	2048
565	150	ACCESS_IN_CONTROL_PANEL	2
566	150	CONFIGURATION	4
567	150	VIEW	1
568	113	VIEW	1
569	113	ADD_TO_PAGE	2
570	113	CONFIGURATION	4
571	33	ACCESS_IN_CONTROL_PANEL	2
572	33	ADD_TO_PAGE	4
573	33	CONFIGURATION	8
574	33	VIEW	1
575	com.liferay.portlet.blogs	ADD_ENTRY	2
576	com.liferay.portlet.blogs	PERMISSIONS	4
577	com.liferay.portlet.blogs	SUBSCRIBE	8
578	com.liferay.portlet.blogs.model.BlogsEntry	ADD_DISCUSSION	2
579	com.liferay.portlet.blogs.model.BlogsEntry	DELETE	4
580	com.liferay.portlet.blogs.model.BlogsEntry	DELETE_DISCUSSION	8
581	com.liferay.portlet.blogs.model.BlogsEntry	PERMISSIONS	16
582	com.liferay.portlet.blogs.model.BlogsEntry	UPDATE	32
583	com.liferay.portlet.blogs.model.BlogsEntry	UPDATE_DISCUSSION	64
584	com.liferay.portlet.blogs.model.BlogsEntry	VIEW	1
585	2	VIEW	1
586	2	ADD_TO_PAGE	2
587	2	CONFIGURATION	4
588	119	VIEW	1
589	119	ADD_TO_PAGE	2
590	119	CONFIGURATION	4
591	126	ACCESS_IN_CONTROL_PANEL	2
592	126	CONFIGURATION	4
593	126	VIEW	1
594	com.liferay.portal.model.Organization	APPROVE_PROPOSAL	2
595	com.liferay.portal.model.Organization	ASSIGN_MEMBERS	4
596	com.liferay.portal.model.Organization	ASSIGN_REVIEWER	8
597	com.liferay.portal.model.Organization	ASSIGN_USER_ROLES	16
598	com.liferay.portal.model.Organization	DELETE	32
599	com.liferay.portal.model.Organization	MANAGE_ANNOUNCEMENTS	64
600	com.liferay.portal.model.Organization	MANAGE_ARCHIVED_SETUPS	128
601	com.liferay.portal.model.Organization	MANAGE_LAYOUTS	256
602	com.liferay.portal.model.Organization	MANAGE_STAGING	512
603	com.liferay.portal.model.Organization	MANAGE_SUBORGANIZATIONS	1024
604	com.liferay.portal.model.Organization	MANAGE_TEAMS	2048
605	com.liferay.portal.model.Organization	MANAGE_USERS	4096
606	com.liferay.portal.model.Organization	PERMISSIONS	8192
607	com.liferay.portal.model.Organization	PUBLISH_STAGING	16384
608	com.liferay.portal.model.Organization	UPDATE	32768
609	com.liferay.portal.model.Organization	VIEW	1
610	114	VIEW	1
611	114	ADD_TO_PAGE	2
612	114	CONFIGURATION	4
613	149	ACCESS_IN_CONTROL_PANEL	2
614	149	CONFIGURATION	4
615	149	VIEW	1
616	67	VIEW	1
617	67	ADD_TO_PAGE	2
618	67	CONFIGURATION	4
619	110	VIEW	1
620	110	ADD_TO_PAGE	2
621	110	CONFIGURATION	4
622	135	ACCESS_IN_CONTROL_PANEL	2
623	135	CONFIGURATION	4
624	135	VIEW	1
625	59	VIEW	1
626	59	ADD_TO_PAGE	2
627	59	CONFIGURATION	4
628	131	ACCESS_IN_CONTROL_PANEL	2
629	131	CONFIGURATION	4
630	131	VIEW	1
631	102	VIEW	1
632	102	ADD_TO_PAGE	2
633	102	CONFIGURATION	4
\.


--
-- Data for Name: resourcecode; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY resourcecode (codeid, companyid, name, scope) FROM stdin;
\.


--
-- Data for Name: resourcepermission; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY resourcepermission (resourcepermissionid, companyid, name, scope, primkey, roleid, actionids) FROM stdin;
1	10132	com.liferay.portal.model.Layout	4	10152	10140	127
2	10132	com.liferay.portal.model.Layout	4	10152	10144	3
3	10132	com.liferay.portal.model.Layout	4	10152	10139	1
4	10132	com.liferay.portal.model.Layout	4	10160	10140	127
5	10132	com.liferay.portal.model.Layout	4	10160	10144	3
6	10132	com.liferay.portal.model.Layout	4	10160	10139	1
7	10132	com.liferay.portal.model.User	4	10169	10140	31
8	10132	98	1	10132	10141	4
9	10132	98	1	10132	10142	4
10	10132	66	1	10132	10141	2
11	10132	66	1	10132	10142	2
12	10132	27	1	10132	10141	2
13	10132	27	1	10132	10142	2
14	10132	122	1	10132	10139	2
15	10132	122	1	10132	10141	2
16	10132	122	1	10132	10142	2
17	10132	36	1	10132	10141	2
18	10132	36	1	10132	10142	2
19	10132	26	1	10132	10141	2
20	10132	26	1	10132	10142	2
21	10132	104	1	10132	10138	2
22	10132	64	1	10132	10139	2
23	10132	64	1	10132	10141	2
24	10132	64	1	10132	10142	2
25	10132	100	1	10132	10141	2
26	10132	100	1	10132	10142	2
27	10132	19	1	10132	10141	4
28	10132	19	1	10132	10142	4
29	10132	148	1	10132	10139	2
30	10132	148	1	10132	10141	2
31	10132	148	1	10132	10142	2
32	10132	11	1	10132	10141	2
33	10132	11	1	10132	10142	2
34	10132	29	1	10132	10141	2
35	10132	29	1	10132	10142	2
36	10132	8	1	10132	10141	4
37	10132	8	1	10132	10142	4
38	10132	58	1	10132	10139	2
39	10132	58	1	10132	10141	2
40	10132	58	1	10132	10142	2
41	10132	71	1	10132	10139	2
42	10132	71	1	10132	10141	2
43	10132	71	1	10132	10142	2
44	10132	97	1	10132	10141	2
45	10132	97	1	10132	10142	2
46	10132	39	1	10132	10141	2
47	10132	39	1	10132	10142	2
48	10132	85	1	10132	10139	2
49	10132	85	1	10132	10141	2
50	10132	85	1	10132	10142	2
51	10132	118	1	10132	10139	2
52	10132	118	1	10132	10141	2
53	10132	118	1	10132	10142	2
54	10132	79	1	10132	10138	4
55	10132	107	1	10132	10141	2
56	10132	107	1	10132	10142	2
57	10132	30	1	10132	10141	2
58	10132	30	1	10132	10142	2
59	10132	48	1	10132	10141	2
60	10132	48	1	10132	10142	2
61	10132	62	1	10132	10141	2
62	10132	62	1	10132	10142	2
63	10132	159	1	10132	10139	2
64	10132	159	1	10132	10141	2
65	10132	159	1	10132	10142	2
66	10132	108	1	10132	10141	2
67	10132	108	1	10132	10142	2
68	10132	84	1	10132	10141	4
69	10132	84	1	10132	10142	4
70	10132	101	1	10132	10139	2
71	10132	101	1	10132	10141	2
72	10132	101	1	10132	10142	2
73	10132	121	1	10132	10139	2
74	10132	121	1	10132	10141	2
75	10132	121	1	10132	10142	2
76	10132	37	1	10132	10141	2
77	10132	37	1	10132	10142	2
78	10132	143	1	10132	10139	2
79	10132	143	1	10132	10141	2
80	10132	143	1	10132	10142	2
81	10132	77	1	10132	10139	2
82	10132	77	1	10132	10141	2
83	10132	77	1	10132	10142	2
84	10132	115	1	10132	10139	2
85	10132	115	1	10132	10141	2
86	10132	115	1	10132	10142	2
87	10132	56	1	10132	10139	2
88	10132	56	1	10132	10141	2
89	10132	56	1	10132	10142	2
90	10132	16	1	10132	10141	8
91	10132	16	1	10132	10142	8
92	10132	111	1	10132	10138	2
93	10132	3	1	10132	10139	2
94	10132	3	1	10132	10141	2
95	10132	3	1	10132	10142	2
96	10132	23	1	10132	10141	2
97	10132	23	1	10132	10142	2
98	10132	20	1	10132	10139	4
99	10132	20	1	10132	10141	4
100	10132	20	1	10132	10142	4
101	10132	83	1	10132	10141	4
102	10132	83	1	10132	10142	4
103	10132	99	1	10132	10138	2
104	10132	70	1	10132	10141	2
105	10132	70	1	10132	10142	2
106	10132	141	1	10132	10139	2
107	10132	141	1	10132	10141	2
108	10132	141	1	10132	10142	2
109	10132	9	1	10132	10138	2
110	10132	28	1	10132	10141	4
111	10132	28	1	10132	10142	4
112	10132	47	1	10132	10139	2
113	10132	47	1	10132	10141	2
114	10132	47	1	10132	10142	2
115	10132	15	1	10132	10141	4
116	10132	15	1	10132	10142	4
117	10132	116	1	10132	10139	2
118	10132	116	1	10132	10141	2
119	10132	116	1	10132	10142	2
120	10132	82	1	10132	10139	2
121	10132	82	1	10132	10141	2
122	10132	82	1	10132	10142	2
123	10132	54	1	10132	10141	2
124	10132	54	1	10132	10142	2
125	10132	34	1	10132	10141	2
126	10132	34	1	10132	10142	2
127	10132	61	1	10132	10141	2
128	10132	61	1	10132	10142	2
129	10132	73	1	10132	10139	2
130	10132	73	1	10132	10141	2
131	10132	73	1	10132	10142	2
132	10132	31	1	10132	10139	4
133	10132	31	1	10132	10141	4
134	10132	31	1	10132	10142	4
135	10132	50	1	10132	10139	2
136	10132	50	1	10132	10141	2
137	10132	50	1	10132	10142	2
138	10132	33	1	10132	10139	4
139	10132	33	1	10132	10141	4
140	10132	33	1	10132	10142	4
141	10132	114	1	10132	10139	2
142	10132	114	1	10132	10141	2
143	10132	114	1	10132	10142	2
144	10132	67	1	10132	10141	2
145	10132	67	1	10132	10142	2
146	10132	110	1	10132	10141	2
147	10132	110	1	10132	10142	2
148	10132	59	1	10132	10141	2
149	10132	59	1	10132	10142	2
150	10132	102	1	10132	10139	2
151	10132	102	1	10132	10141	2
152	10132	102	1	10132	10142	2
153	10132	103	4	10160_LAYOUT_103	10140	7
154	10132	103	4	10160_LAYOUT_103	10144	1
155	10132	103	4	10160_LAYOUT_103	10139	1
156	10132	47	4	10160_LAYOUT_47	10140	7
157	10132	47	4	10160_LAYOUT_47	10144	1
158	10132	47	4	10160_LAYOUT_47	10139	1
159	10132	58	4	10160_LAYOUT_58	10140	7
160	10132	58	4	10160_LAYOUT_58	10144	1
161	10132	58	4	10160_LAYOUT_58	10139	1
162	10132	com.liferay.portal.model.Layout	4	10265	10140	127
163	10132	com.liferay.portal.model.Layout	4	10265	10141	3
164	10132	com.liferay.portal.model.Layout	4	10265	10139	1
165	10132	com.liferay.portal.model.Layout	4	10270	10140	127
166	10132	com.liferay.portal.model.Layout	4	10270	10141	3
167	10132	com.liferay.portal.model.Layout	4	10270	10139	1
168	10132	145	4	10160_LAYOUT_145	10140	7
169	10132	145	4	10160_LAYOUT_145	10144	1
170	10132	145	4	10160_LAYOUT_145	10139	1
171	10132	com.liferay.portlet.asset	4	10157	10140	30
172	10132	com.liferay.portal.model.Layout	4	10278	10140	127
173	10132	com.liferay.portal.model.Layout	4	10278	10144	3
174	10132	com.liferay.portal.model.Layout	4	10278	10139	1
175	10132	103	4	10278_LAYOUT_103	10140	7
176	10132	103	4	10278_LAYOUT_103	10144	1
177	10132	103	4	10278_LAYOUT_103	10139	1
178	10132	145	4	10278_LAYOUT_145	10140	7
179	10132	145	4	10278_LAYOUT_145	10144	1
180	10132	145	4	10278_LAYOUT_145	10139	1
181	10132	87	4	10278_LAYOUT_87	10140	7
182	10132	87	4	10278_LAYOUT_87	10144	1
183	10132	87	4	10278_LAYOUT_87	10139	1
184	10132	56	4	10278_LAYOUT_56_INSTANCE_I9Fr	10140	7
185	10132	56	4	10278_LAYOUT_56_INSTANCE_I9Fr	10144	1
186	10132	56	4	10278_LAYOUT_56_INSTANCE_I9Fr	10139	1
187	10132	15	4	10278_LAYOUT_15	10140	15
188	10132	15	4	10278_LAYOUT_15	10144	1
189	10132	15	4	10278_LAYOUT_15	10139	1
190	10132	com.liferay.portlet.journal	4	10157	10140	126
191	10132	com.liferay.portlet.journal.model.JournalArticle	4	10291	10140	255
192	10132	com.liferay.portlet.journal.model.JournalArticle	4	10291	10144	3
193	10132	com.liferay.portlet.journal.model.JournalArticle	4	10291	10139	1
194	10132	com.liferay.portal.model.Layout	4	10300	10140	127
195	10132	com.liferay.portal.model.Layout	4	10300	10144	3
196	10132	com.liferay.portal.model.Layout	4	10300	10139	1
197	10132	103	4	10300_LAYOUT_103	10140	7
198	10132	103	4	10300_LAYOUT_103	10144	1
199	10132	103	4	10300_LAYOUT_103	10139	1
200	10132	145	4	10300_LAYOUT_145	10140	7
201	10132	145	4	10300_LAYOUT_145	10144	1
202	10132	145	4	10300_LAYOUT_145	10139	1
203	10132	87	4	10300_LAYOUT_87	10140	7
204	10132	87	4	10300_LAYOUT_87	10144	1
205	10132	87	4	10300_LAYOUT_87	10139	1
206	10132	20	4	10300_LAYOUT_20	10140	15
207	10132	20	4	10300_LAYOUT_20	10144	1
208	10132	20	4	10300_LAYOUT_20	10139	1
209	10132	com.liferay.portlet.documentlibrary	4	10157	10140	31
210	10132	com.liferay.portlet.documentlibrary	4	10157	10144	1
211	10132	com.liferay.portlet.documentlibrary.model.DLFileEntry	4	10309	10140	127
212	10132	com.liferay.portlet.documentlibrary.model.DLFileEntry	4	10309	10144	3
213	10132	com.liferay.portlet.documentlibrary.model.DLFileEntry	4	10309	10139	1
214	10132	com.liferay.portlet.asset.model.AssetVocabulary	4	10316	10140	15
215	10132	com.liferay.portlet.asset.model.AssetVocabulary	4	10317	10140	15
216	10132	com.liferay.portal.model.Layout	4	10319	10140	127
217	10132	com.liferay.portal.model.Layout	4	10319	10144	3
218	10132	com.liferay.portal.model.Layout	4	10319	10139	1
219	10132	103	4	10319_LAYOUT_103	10140	7
220	10132	103	4	10319_LAYOUT_103	10144	1
221	10132	103	4	10319_LAYOUT_103	10139	1
222	10132	145	4	10319_LAYOUT_145	10140	7
223	10132	145	4	10319_LAYOUT_145	10144	1
224	10132	145	4	10319_LAYOUT_145	10139	1
225	10132	87	4	10319_LAYOUT_87	10140	7
226	10132	87	4	10319_LAYOUT_87	10144	1
227	10132	87	4	10319_LAYOUT_87	10139	1
228	10132	19	4	10319_LAYOUT_19	10140	15
229	10132	19	4	10319_LAYOUT_19	10144	1
230	10132	19	4	10319_LAYOUT_19	10139	1
231	10132	com.liferay.portlet.messageboards	4	10157	10140	2046
232	10132	com.liferay.portlet.messageboards.model.MBMessage	4	10328	10140	31
233	10132	com.liferay.portlet.messageboards.model.MBMessage	4	10328	10144	9
234	10132	com.liferay.portlet.messageboards.model.MBMessage	4	10328	10139	1
235	10132	com.liferay.portal.model.Layout	4	10334	10140	127
236	10132	com.liferay.portal.model.Layout	4	10334	10144	3
237	10132	com.liferay.portal.model.Layout	4	10334	10139	1
238	10132	103	4	10334_LAYOUT_103	10140	7
239	10132	103	4	10334_LAYOUT_103	10144	1
240	10132	103	4	10334_LAYOUT_103	10139	1
241	10132	145	4	10334_LAYOUT_145	10140	7
242	10132	145	4	10334_LAYOUT_145	10144	1
243	10132	145	4	10334_LAYOUT_145	10139	1
244	10132	87	4	10334_LAYOUT_87	10140	7
245	10132	87	4	10334_LAYOUT_87	10144	1
246	10132	87	4	10334_LAYOUT_87	10139	1
247	10132	36	4	10334_LAYOUT_36	10140	7
248	10132	36	4	10334_LAYOUT_36	10144	1
249	10132	36	4	10334_LAYOUT_36	10139	1
250	10132	com.liferay.portlet.wiki	4	10157	10140	6
251	10132	com.liferay.portlet.wiki.model.WikiNode	4	10343	10140	255
252	10132	com.liferay.portlet.wiki.model.WikiNode	4	10343	10144	71
253	10132	com.liferay.portlet.wiki.model.WikiNode	4	10343	10139	1
254	10132	com.liferay.portlet.wiki.model.WikiPage	4	10345	10140	255
255	10132	com.liferay.portlet.wiki.model.WikiPage	4	10345	10144	99
256	10132	com.liferay.portlet.wiki.model.WikiPage	4	10345	10139	1
257	10132	com.liferay.portal.model.Layout	4	10354	10140	127
258	10132	com.liferay.portal.model.Layout	4	10354	10144	3
259	10132	com.liferay.portal.model.Layout	4	10354	10139	1
260	10132	103	4	10354_LAYOUT_103	10140	7
261	10132	103	4	10354_LAYOUT_103	10144	1
262	10132	103	4	10354_LAYOUT_103	10139	1
263	10132	145	4	10354_LAYOUT_145	10140	7
264	10132	145	4	10354_LAYOUT_145	10144	1
265	10132	145	4	10354_LAYOUT_145	10139	1
266	10132	87	4	10354_LAYOUT_87	10140	7
267	10132	87	4	10354_LAYOUT_87	10144	1
268	10132	87	4	10354_LAYOUT_87	10139	1
269	10132	33	4	10354_LAYOUT_33	10140	15
270	10132	33	4	10354_LAYOUT_33	10144	1
271	10132	33	4	10354_LAYOUT_33	10139	1
272	10132	com.liferay.portlet.blogs	4	10157	10140	14
273	10132	com.liferay.portlet.blogs.model.BlogsEntry	4	10363	10140	127
274	10132	com.liferay.portlet.blogs.model.BlogsEntry	4	10363	10144	3
275	10132	com.liferay.portlet.blogs.model.BlogsEntry	4	10363	10139	1
276	10132	160	4	10152_LAYOUT_160	10140	7
277	10132	160	4	10152_LAYOUT_160	10144	1
278	10132	160	4	10152_LAYOUT_160	10139	1
279	10132	145	4	10152_LAYOUT_145	10140	7
280	10132	145	4	10152_LAYOUT_145	10144	1
281	10132	145	4	10152_LAYOUT_145	10139	1
282	10132	com.liferay.portlet.asset	4	10149	10140	30
283	10132	134	4	10152_LAYOUT_134	10140	7
284	10132	134	4	10152_LAYOUT_134	10144	1
285	10132	134	4	10152_LAYOUT_134	10139	1
286	10132	com.liferay.portal.model.Group	4	10374	10140	32766
287	10132	com.liferay.portal.model.Layout	4	10378	10140	127
288	10132	com.liferay.portal.model.Layout	4	10378	10144	3
289	10132	com.liferay.portal.model.Layout	4	10378	10139	1
290	10132	103	4	10378_LAYOUT_103	10140	7
291	10132	103	4	10378_LAYOUT_103	10144	1
292	10132	103	4	10378_LAYOUT_103	10139	1
293	10132	145	4	10378_LAYOUT_145	10140	7
294	10132	145	4	10378_LAYOUT_145	10144	1
295	10132	145	4	10378_LAYOUT_145	10139	1
296	10132	com.liferay.portlet.asset	4	10374	10140	30
297	10132	125	4	10152_LAYOUT_125	10140	15
298	10132	125	4	10152_LAYOUT_125	10144	1
299	10132	125	4	10152_LAYOUT_125	10139	1
300	10132	com.liferay.portal.model.User	4	10386	10140	31
301	10132	com.liferay.portal.model.Layout	4	10395	10140	127
302	10132	com.liferay.portal.model.Layout	4	10395	10141	3
303	10132	com.liferay.portal.model.Layout	4	10395	10139	1
304	10132	com.liferay.portal.model.Layout	4	10400	10140	127
305	10132	com.liferay.portal.model.Layout	4	10400	10141	3
306	10132	com.liferay.portal.model.Layout	4	10400	10139	1
\.


--
-- Data for Name: role_; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY role_ (roleid, companyid, classnameid, classpk, name, title, description, type_, subtype) FROM stdin;
10138	10132	10040	10138	Administrator		Administrators are super users who can do anything.	1	
10139	10132	10040	10139	Guest		Unauthenticated users always have this role.	1	
10140	10132	10040	10140	Owner		This is an implied role with respect to the objects users create.	1	
10141	10132	10040	10141	Power User		Power Users have their own public and private pages.	1	
10142	10132	10040	10142	User		Authenticated users should be assigned this role.	1	
10143	10132	10040	10143	Community Administrator		Community Administrators are super users of their community but cannot make other users into Community Administrators.	2	
10144	10132	10040	10144	Community Member		All users who belong to a community have this role within that community.	2	
10145	10132	10040	10145	Community Owner		Community Owners are super users of their community and can assign community roles to users.	2	
10146	10132	10040	10146	Organization Administrator		Organization Administrators are super users of their organization but cannot make other users into Organization Administrators.	3	
10147	10132	10040	10147	Organization Member		All users who belong to an organization have this role within that organization.	3	
10148	10132	10040	10148	Organization Owner		Organization Owners are super users of their organization and can assign organization roles to users.	3	
\.


--
-- Data for Name: roles_permissions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY roles_permissions (roleid, permissionid) FROM stdin;
\.


--
-- Data for Name: scframeworkversi_scproductvers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY scframeworkversi_scproductvers (frameworkversionid, productversionid) FROM stdin;
\.


--
-- Data for Name: scframeworkversion; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY scframeworkversion (frameworkversionid, groupid, companyid, userid, username, createdate, modifieddate, name, url, active_, priority) FROM stdin;
\.


--
-- Data for Name: sclicense; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY sclicense (licenseid, name, url, opensource, active_, recommended) FROM stdin;
\.


--
-- Data for Name: sclicenses_scproductentries; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY sclicenses_scproductentries (licenseid, productentryid) FROM stdin;
\.


--
-- Data for Name: scproductentry; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY scproductentry (productentryid, groupid, companyid, userid, username, createdate, modifieddate, name, type_, tags, shortdescription, longdescription, pageurl, author, repogroupid, repoartifactid) FROM stdin;
\.


--
-- Data for Name: scproductscreenshot; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY scproductscreenshot (productscreenshotid, companyid, groupid, productentryid, thumbnailid, fullimageid, priority) FROM stdin;
\.


--
-- Data for Name: scproductversion; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY scproductversion (productversionid, companyid, userid, username, createdate, modifieddate, productentryid, version, changelog, downloadpageurl, directdownloadurl, repostoreartifact) FROM stdin;
\.


--
-- Data for Name: servicecomponent; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY servicecomponent (servicecomponentid, buildnamespace, buildnumber, builddate, data_) FROM stdin;
\.


--
-- Data for Name: shard; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY shard (shardid, classnameid, classpk, name) FROM stdin;
10133	10008	10132	default
\.


--
-- Data for Name: shoppingcart; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY shoppingcart (cartid, groupid, companyid, userid, username, createdate, modifieddate, itemids, couponcodes, altshipping, insure) FROM stdin;
\.


--
-- Data for Name: shoppingcategory; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY shoppingcategory (categoryid, groupid, companyid, userid, username, createdate, modifieddate, parentcategoryid, name, description) FROM stdin;
\.


--
-- Data for Name: shoppingcoupon; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY shoppingcoupon (couponid, groupid, companyid, userid, username, createdate, modifieddate, code_, name, description, startdate, enddate, active_, limitcategories, limitskus, minorder, discount, discounttype) FROM stdin;
\.


--
-- Data for Name: shoppingitem; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY shoppingitem (itemid, groupid, companyid, userid, username, createdate, modifieddate, categoryid, sku, name, description, properties, fields_, fieldsquantities, minquantity, maxquantity, price, discount, taxable, shipping, useshippingformula, requiresshipping, stockquantity, featured_, sale_, smallimage, smallimageid, smallimageurl, mediumimage, mediumimageid, mediumimageurl, largeimage, largeimageid, largeimageurl) FROM stdin;
\.


--
-- Data for Name: shoppingitemfield; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY shoppingitemfield (itemfieldid, itemid, name, values_, description) FROM stdin;
\.


--
-- Data for Name: shoppingitemprice; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY shoppingitemprice (itempriceid, itemid, minquantity, maxquantity, price, discount, taxable, shipping, useshippingformula, status) FROM stdin;
\.


--
-- Data for Name: shoppingorder; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY shoppingorder (orderid, groupid, companyid, userid, username, createdate, modifieddate, number_, tax, shipping, altshipping, requiresshipping, insure, insurance, couponcodes, coupondiscount, billingfirstname, billinglastname, billingemailaddress, billingcompany, billingstreet, billingcity, billingstate, billingzip, billingcountry, billingphone, shiptobilling, shippingfirstname, shippinglastname, shippingemailaddress, shippingcompany, shippingstreet, shippingcity, shippingstate, shippingzip, shippingcountry, shippingphone, ccname, cctype, ccnumber, ccexpmonth, ccexpyear, ccvernumber, comments, pptxnid, pppaymentstatus, pppaymentgross, ppreceiveremail, pppayeremail, sendorderemail, sendshippingemail) FROM stdin;
\.


--
-- Data for Name: shoppingorderitem; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY shoppingorderitem (orderitemid, orderid, itemid, sku, name, description, properties, price, quantity, shippeddate) FROM stdin;
\.


--
-- Data for Name: socialactivity; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY socialactivity (activityid, groupid, companyid, userid, createdate, mirroractivityid, classnameid, classpk, type_, extradata, receiveruserid) FROM stdin;
1	10157	10132	10169	1449105908247	0	10073	10309	1		0
2	10157	10132	10169	1449105986070	0	10095	10328	1		0
3	10157	10132	10169	1449106035167	0	10129	10345	1		0
4	10157	10132	10169	1449106042293	0	10129	10345	1		0
5	10157	10132	10169	1449106095534	0	10068	10363	2		0
\.


--
-- Data for Name: socialequityassetentry; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY socialequityassetentry (equityassetentryid, groupid, companyid, userid, assetentryid, informationk, informationb) FROM stdin;
\.


--
-- Data for Name: socialequitygroupsetting; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY socialequitygroupsetting (equitygroupsettingid, groupid, companyid, classnameid, type_, enabled) FROM stdin;
\.


--
-- Data for Name: socialequityhistory; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY socialequityhistory (equityhistoryid, groupid, companyid, userid, createdate, personalequity) FROM stdin;
\.


--
-- Data for Name: socialequitylog; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY socialequitylog (equitylogid, groupid, companyid, userid, assetentryid, actionid, actiondate, active_, expiration, type_, value) FROM stdin;
\.


--
-- Data for Name: socialequitysetting; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY socialequitysetting (equitysettingid, groupid, companyid, classnameid, actionid, dailylimit, lifespan, type_, uniqueentry, value) FROM stdin;
\.


--
-- Data for Name: socialequityuser; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY socialequityuser (equityuserid, groupid, companyid, userid, contributionk, contributionb, participationk, participationb, rank) FROM stdin;
\.


--
-- Data for Name: socialrelation; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY socialrelation (uuid_, relationid, companyid, createdate, userid1, userid2, type_) FROM stdin;
\.


--
-- Data for Name: socialrequest; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY socialrequest (uuid_, requestid, groupid, companyid, userid, createdate, modifieddate, classnameid, classpk, type_, extradata, receiveruserid, status) FROM stdin;
\.


--
-- Data for Name: subscription; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY subscription (subscriptionid, companyid, userid, username, createdate, modifieddate, classnameid, classpk, frequency) FROM stdin;
\.


--
-- Data for Name: tasksproposal; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY tasksproposal (proposalid, groupid, companyid, userid, username, createdate, modifieddate, classnameid, classpk, name, description, publishdate, duedate) FROM stdin;
\.


--
-- Data for Name: tasksreview; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY tasksreview (reviewid, groupid, companyid, userid, username, createdate, modifieddate, proposalid, assignedbyuserid, assignedbyusername, stage, completed, rejected) FROM stdin;
\.


--
-- Data for Name: team; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY team (teamid, companyid, userid, username, createdate, modifieddate, groupid, name, description) FROM stdin;
\.


--
-- Data for Name: ticket; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY ticket (ticketid, companyid, createdate, classnameid, classpk, key_, expirationdate) FROM stdin;
\.


--
-- Data for Name: user_; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY user_ (uuid_, userid, companyid, createdate, modifieddate, defaultuser, contactid, password_, passwordencrypted, passwordreset, passwordmodifieddate, digest, reminderqueryquestion, reminderqueryanswer, gracelogincount, screenname, emailaddress, facebookid, openid, portraitid, languageid, timezoneid, greeting, comments, firstname, middlename, lastname, jobtitle, logindate, loginip, lastlogindate, lastloginip, lastfailedlogindate, failedloginattempts, lockout, lockoutdate, agreedtotermsofuse, active_) FROM stdin;
2cce6c88-6350-4af0-927d-446c9bda7763	10135	10132	2015-12-03 01:22:40.773	2015-12-03 01:22:40.773	t	10136	password	f	f	\N	5533ed38b5e33c076a804bb4bca644f9,4b2c83b9c14991181b3134f9975c6229,4b2c83b9c14991181b3134f9975c6229			0	10135	default@liferay.com	0		0	en_US	UTC	Welcome!						2015-12-03 01:22:40.773		\N		\N	0	f	\N	t	t
d93c3ccb-b3fb-42d7-b2b9-e67aefd61a9f	10386	10132	2015-12-03 01:32:09.278	2015-12-03 01:32:56.581	f	10387	qUqP5cyxm6YcTAhz05Hph5gvu9M=	t	f	2015-12-03 01:33:45.307	6d0012355176af07f1a9fa596037fae6,0145c26fd5666e901b643bd4728ea297,a968507a4d4e58aae7d89e9a516a23b3	what-is-your-father's-middle-name	test	0	usersn	user@liferay.com	0		0	en_US	UTC	Welcome Userfn Userln!		Userfn		Userln		2015-12-03 01:35:02.202	127.0.0.1	2015-12-03 01:33:32.079	127.0.0.1	\N	0	f	\N	t	t
a7e72c6d-3283-47d9-8add-eb2cbb333f32	10169	10132	2015-12-03 01:22:41.931	2015-12-03 01:22:41.931	f	10170	qUqP5cyxm6YcTAhz05Hph5gvu9M=	t	f	\N	e5d86c6f3672e52795891c3597f20de0,751da756639bc033b572ba2e7849b589,96dc35369e5f37bdf80cb3bda0e8fb3b	what-is-your-father's-middle-name	test	0	test	test@liferay.com	0		0	en_US	UTC	Welcome Test Test!		Test		Test		2015-12-03 01:35:40.91	127.0.0.1	2015-12-03 01:34:25.829	127.0.0.1	\N	0	f	\N	t	t
\.


--
-- Data for Name: usergroup; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY usergroup (usergroupid, companyid, parentusergroupid, name, description) FROM stdin;
\.


--
-- Data for Name: usergroupgrouprole; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY usergroupgrouprole (usergroupid, groupid, roleid) FROM stdin;
\.


--
-- Data for Name: usergrouprole; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY usergrouprole (userid, groupid, roleid) FROM stdin;
10169	10374	10145
\.


--
-- Data for Name: useridmapper; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY useridmapper (useridmapperid, userid, type_, description, externaluserid) FROM stdin;
\.


--
-- Data for Name: users_groups; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY users_groups (userid, groupid) FROM stdin;
10169	10157
10169	10374
\.


--
-- Data for Name: users_orgs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY users_orgs (userid, organizationid) FROM stdin;
\.


--
-- Data for Name: users_permissions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY users_permissions (userid, permissionid) FROM stdin;
\.


--
-- Data for Name: users_roles; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY users_roles (userid, roleid) FROM stdin;
10135	10139
10169	10141
10169	10142
10169	10138
10386	10141
10386	10142
\.


--
-- Data for Name: users_teams; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY users_teams (userid, teamid) FROM stdin;
\.


--
-- Data for Name: users_usergroups; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY users_usergroups (usergroupid, userid) FROM stdin;
\.


--
-- Data for Name: usertracker; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY usertracker (usertrackerid, companyid, userid, modifieddate, sessionid, remoteaddr, remotehost, useragent) FROM stdin;
\.


--
-- Data for Name: usertrackerpath; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY usertrackerpath (usertrackerpathid, usertrackerid, path_, pathdate) FROM stdin;
\.


--
-- Data for Name: vocabulary; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY vocabulary (vocabularyid, groupid, companyid, userid, username, createdate, modifieddate, name, description, folksonomy) FROM stdin;
\.


--
-- Data for Name: webdavprops; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY webdavprops (webdavpropsid, companyid, createdate, modifieddate, classnameid, classpk, props) FROM stdin;
\.


--
-- Data for Name: website; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY website (websiteid, companyid, userid, username, createdate, modifieddate, classnameid, classpk, url, typeid, primary_) FROM stdin;
\.


--
-- Data for Name: wikinode; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY wikinode (uuid_, nodeid, groupid, companyid, userid, username, createdate, modifieddate, name, description, lastpostdate) FROM stdin;
317d2565-7d85-4f82-94d7-4c29cbc58561	10343	10157	10132	10169	Test Test	2015-12-03 01:27:14.961	2015-12-03 01:27:14.961	Main		2015-12-03 01:27:22.242
\.


--
-- Data for Name: wikipage; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY wikipage (uuid_, pageid, resourceprimkey, groupid, companyid, userid, username, createdate, modifieddate, nodeid, title, version, minoredit, content, summary, format, head, parenttitle, redirecttitle, status, statusbyuserid, statusbyusername, statusdate) FROM stdin;
855bc875-b286-49a5-88ce-4b1c22fd5eb9	10351	10345	10157	10132	10169	Test Test	2015-12-03 01:27:22.242	2015-12-03 01:27:22.242	10343	FrontPage	1.1000000000000001	f	Wiki Front Page Content		creole	t			0	10169	Test Test	2015-12-03 01:27:22.283
7803d80b-06be-46a5-848d-791a3409cc3d	10344	10345	10157	10132	10169	Test Test	2015-12-03 01:27:15.032	2015-12-03 01:27:15.032	10343	FrontPage	1	t		New	creole	f			0	10169	Test Test	2015-12-03 01:27:15.166
\.


--
-- Data for Name: wikipageresource; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY wikipageresource (uuid_, resourceprimkey, nodeid, title) FROM stdin;
b82bdc40-ecc0-486f-8d3d-f257fc98b163	10345	10343	FrontPage
\.


--
-- Data for Name: workflowdefinitionlink; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY workflowdefinitionlink (workflowdefinitionlinkid, groupid, companyid, userid, username, createdate, modifieddate, classnameid, workflowdefinitionname, workflowdefinitionversion) FROM stdin;
\.


--
-- Data for Name: workflowinstancelink; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY workflowinstancelink (workflowinstancelinkid, groupid, companyid, userid, username, createdate, modifieddate, classnameid, classpk, workflowinstanceid) FROM stdin;
\.


--
-- Name: account__pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY account_
    ADD CONSTRAINT account__pkey PRIMARY KEY (accountid);


--
-- Name: address_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY address
    ADD CONSTRAINT address_pkey PRIMARY KEY (addressid);


--
-- Name: announcementsdelivery_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY announcementsdelivery
    ADD CONSTRAINT announcementsdelivery_pkey PRIMARY KEY (deliveryid);


--
-- Name: announcementsentry_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY announcementsentry
    ADD CONSTRAINT announcementsentry_pkey PRIMARY KEY (entryid);


--
-- Name: announcementsflag_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY announcementsflag
    ADD CONSTRAINT announcementsflag_pkey PRIMARY KEY (flagid);


--
-- Name: assetcategory_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY assetcategory
    ADD CONSTRAINT assetcategory_pkey PRIMARY KEY (categoryid);


--
-- Name: assetcategoryproperty_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY assetcategoryproperty
    ADD CONSTRAINT assetcategoryproperty_pkey PRIMARY KEY (categorypropertyid);


--
-- Name: assetentries_assetcategories_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY assetentries_assetcategories
    ADD CONSTRAINT assetentries_assetcategories_pkey PRIMARY KEY (entryid, categoryid);


--
-- Name: assetentries_assettags_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY assetentries_assettags
    ADD CONSTRAINT assetentries_assettags_pkey PRIMARY KEY (entryid, tagid);


--
-- Name: assetentry_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY assetentry
    ADD CONSTRAINT assetentry_pkey PRIMARY KEY (entryid);


--
-- Name: assetlink_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY assetlink
    ADD CONSTRAINT assetlink_pkey PRIMARY KEY (linkid);


--
-- Name: assettag_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY assettag
    ADD CONSTRAINT assettag_pkey PRIMARY KEY (tagid);


--
-- Name: assettagproperty_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY assettagproperty
    ADD CONSTRAINT assettagproperty_pkey PRIMARY KEY (tagpropertyid);


--
-- Name: assettagstats_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY assettagstats
    ADD CONSTRAINT assettagstats_pkey PRIMARY KEY (tagstatsid);


--
-- Name: assetvocabulary_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY assetvocabulary
    ADD CONSTRAINT assetvocabulary_pkey PRIMARY KEY (vocabularyid);


--
-- Name: blogsentry_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY blogsentry
    ADD CONSTRAINT blogsentry_pkey PRIMARY KEY (entryid);


--
-- Name: blogsstatsuser_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY blogsstatsuser
    ADD CONSTRAINT blogsstatsuser_pkey PRIMARY KEY (statsuserid);


--
-- Name: bookmarksentry_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY bookmarksentry
    ADD CONSTRAINT bookmarksentry_pkey PRIMARY KEY (entryid);


--
-- Name: bookmarksfolder_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY bookmarksfolder
    ADD CONSTRAINT bookmarksfolder_pkey PRIMARY KEY (folderid);


--
-- Name: browsertracker_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY browsertracker
    ADD CONSTRAINT browsertracker_pkey PRIMARY KEY (browsertrackerid);


--
-- Name: calevent_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY calevent
    ADD CONSTRAINT calevent_pkey PRIMARY KEY (eventid);


--
-- Name: classname__pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY classname_
    ADD CONSTRAINT classname__pkey PRIMARY KEY (classnameid);


--
-- Name: clustergroup_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY clustergroup
    ADD CONSTRAINT clustergroup_pkey PRIMARY KEY (clustergroupid);


--
-- Name: company_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY company
    ADD CONSTRAINT company_pkey PRIMARY KEY (companyid);


--
-- Name: contact__pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY contact_
    ADD CONSTRAINT contact__pkey PRIMARY KEY (contactid);


--
-- Name: counter_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY counter
    ADD CONSTRAINT counter_pkey PRIMARY KEY (name);


--
-- Name: country_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY country
    ADD CONSTRAINT country_pkey PRIMARY KEY (countryid);


--
-- Name: cyrususer_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY cyrususer
    ADD CONSTRAINT cyrususer_pkey PRIMARY KEY (userid);


--
-- Name: cyrusvirtual_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY cyrusvirtual
    ADD CONSTRAINT cyrusvirtual_pkey PRIMARY KEY (emailaddress);


--
-- Name: dlfileentry_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY dlfileentry
    ADD CONSTRAINT dlfileentry_pkey PRIMARY KEY (fileentryid);


--
-- Name: dlfilerank_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY dlfilerank
    ADD CONSTRAINT dlfilerank_pkey PRIMARY KEY (filerankid);


--
-- Name: dlfileshortcut_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY dlfileshortcut
    ADD CONSTRAINT dlfileshortcut_pkey PRIMARY KEY (fileshortcutid);


--
-- Name: dlfileversion_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY dlfileversion
    ADD CONSTRAINT dlfileversion_pkey PRIMARY KEY (fileversionid);


--
-- Name: dlfolder_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY dlfolder
    ADD CONSTRAINT dlfolder_pkey PRIMARY KEY (folderid);


--
-- Name: emailaddress_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY emailaddress
    ADD CONSTRAINT emailaddress_pkey PRIMARY KEY (emailaddressid);


--
-- Name: expandocolumn_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY expandocolumn
    ADD CONSTRAINT expandocolumn_pkey PRIMARY KEY (columnid);


--
-- Name: expandorow_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY expandorow
    ADD CONSTRAINT expandorow_pkey PRIMARY KEY (rowid_);


--
-- Name: expandotable_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY expandotable
    ADD CONSTRAINT expandotable_pkey PRIMARY KEY (tableid);


--
-- Name: expandovalue_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY expandovalue
    ADD CONSTRAINT expandovalue_pkey PRIMARY KEY (valueid);


--
-- Name: group__pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY group_
    ADD CONSTRAINT group__pkey PRIMARY KEY (groupid);


--
-- Name: groups_orgs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY groups_orgs
    ADD CONSTRAINT groups_orgs_pkey PRIMARY KEY (groupid, organizationid);


--
-- Name: groups_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY groups_permissions
    ADD CONSTRAINT groups_permissions_pkey PRIMARY KEY (groupid, permissionid);


--
-- Name: groups_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY groups_roles
    ADD CONSTRAINT groups_roles_pkey PRIMARY KEY (groupid, roleid);


--
-- Name: groups_usergroups_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY groups_usergroups
    ADD CONSTRAINT groups_usergroups_pkey PRIMARY KEY (groupid, usergroupid);


--
-- Name: igfolder_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY igfolder
    ADD CONSTRAINT igfolder_pkey PRIMARY KEY (folderid);


--
-- Name: igimage_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY igimage
    ADD CONSTRAINT igimage_pkey PRIMARY KEY (imageid);


--
-- Name: image_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY image
    ADD CONSTRAINT image_pkey PRIMARY KEY (imageid);


--
-- Name: journalarticle_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY journalarticle
    ADD CONSTRAINT journalarticle_pkey PRIMARY KEY (id_);


--
-- Name: journalarticleimage_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY journalarticleimage
    ADD CONSTRAINT journalarticleimage_pkey PRIMARY KEY (articleimageid);


--
-- Name: journalarticleresource_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY journalarticleresource
    ADD CONSTRAINT journalarticleresource_pkey PRIMARY KEY (resourceprimkey);


--
-- Name: journalcontentsearch_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY journalcontentsearch
    ADD CONSTRAINT journalcontentsearch_pkey PRIMARY KEY (contentsearchid);


--
-- Name: journalfeed_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY journalfeed
    ADD CONSTRAINT journalfeed_pkey PRIMARY KEY (id_);


--
-- Name: journalstructure_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY journalstructure
    ADD CONSTRAINT journalstructure_pkey PRIMARY KEY (id_);


--
-- Name: journaltemplate_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY journaltemplate
    ADD CONSTRAINT journaltemplate_pkey PRIMARY KEY (id_);


--
-- Name: layout_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY layout
    ADD CONSTRAINT layout_pkey PRIMARY KEY (plid);


--
-- Name: layoutprototype_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY layoutprototype
    ADD CONSTRAINT layoutprototype_pkey PRIMARY KEY (layoutprototypeid);


--
-- Name: layoutset_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY layoutset
    ADD CONSTRAINT layoutset_pkey PRIMARY KEY (layoutsetid);


--
-- Name: layoutsetprototype_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY layoutsetprototype
    ADD CONSTRAINT layoutsetprototype_pkey PRIMARY KEY (layoutsetprototypeid);


--
-- Name: listtype_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY listtype
    ADD CONSTRAINT listtype_pkey PRIMARY KEY (listtypeid);


--
-- Name: lock__pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY lock_
    ADD CONSTRAINT lock__pkey PRIMARY KEY (lockid);


--
-- Name: mbban_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY mbban
    ADD CONSTRAINT mbban_pkey PRIMARY KEY (banid);


--
-- Name: mbcategory_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY mbcategory
    ADD CONSTRAINT mbcategory_pkey PRIMARY KEY (categoryid);


--
-- Name: mbdiscussion_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY mbdiscussion
    ADD CONSTRAINT mbdiscussion_pkey PRIMARY KEY (discussionid);


--
-- Name: mbmailinglist_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY mbmailinglist
    ADD CONSTRAINT mbmailinglist_pkey PRIMARY KEY (mailinglistid);


--
-- Name: mbmessage_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY mbmessage
    ADD CONSTRAINT mbmessage_pkey PRIMARY KEY (messageid);


--
-- Name: mbmessageflag_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY mbmessageflag
    ADD CONSTRAINT mbmessageflag_pkey PRIMARY KEY (messageflagid);


--
-- Name: mbstatsuser_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY mbstatsuser
    ADD CONSTRAINT mbstatsuser_pkey PRIMARY KEY (statsuserid);


--
-- Name: mbthread_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY mbthread
    ADD CONSTRAINT mbthread_pkey PRIMARY KEY (threadid);


--
-- Name: membershiprequest_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY membershiprequest
    ADD CONSTRAINT membershiprequest_pkey PRIMARY KEY (membershiprequestid);


--
-- Name: organization__pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY organization_
    ADD CONSTRAINT organization__pkey PRIMARY KEY (organizationid);


--
-- Name: orggrouppermission_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY orggrouppermission
    ADD CONSTRAINT orggrouppermission_pkey PRIMARY KEY (organizationid, groupid, permissionid);


--
-- Name: orggrouprole_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY orggrouprole
    ADD CONSTRAINT orggrouprole_pkey PRIMARY KEY (organizationid, groupid, roleid);


--
-- Name: orglabor_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY orglabor
    ADD CONSTRAINT orglabor_pkey PRIMARY KEY (orglaborid);


--
-- Name: passwordpolicy_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY passwordpolicy
    ADD CONSTRAINT passwordpolicy_pkey PRIMARY KEY (passwordpolicyid);


--
-- Name: passwordpolicyrel_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY passwordpolicyrel
    ADD CONSTRAINT passwordpolicyrel_pkey PRIMARY KEY (passwordpolicyrelid);


--
-- Name: passwordtracker_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY passwordtracker
    ADD CONSTRAINT passwordtracker_pkey PRIMARY KEY (passwordtrackerid);


--
-- Name: permission__pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY permission_
    ADD CONSTRAINT permission__pkey PRIMARY KEY (permissionid);


--
-- Name: phone_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY phone
    ADD CONSTRAINT phone_pkey PRIMARY KEY (phoneid);


--
-- Name: pluginsetting_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY pluginsetting
    ADD CONSTRAINT pluginsetting_pkey PRIMARY KEY (pluginsettingid);


--
-- Name: pollschoice_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY pollschoice
    ADD CONSTRAINT pollschoice_pkey PRIMARY KEY (choiceid);


--
-- Name: pollsquestion_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY pollsquestion
    ADD CONSTRAINT pollsquestion_pkey PRIMARY KEY (questionid);


--
-- Name: pollsvote_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY pollsvote
    ADD CONSTRAINT pollsvote_pkey PRIMARY KEY (voteid);


--
-- Name: portlet_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY portlet
    ADD CONSTRAINT portlet_pkey PRIMARY KEY (id_);


--
-- Name: portletitem_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY portletitem
    ADD CONSTRAINT portletitem_pkey PRIMARY KEY (portletitemid);


--
-- Name: portletpreferences_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY portletpreferences
    ADD CONSTRAINT portletpreferences_pkey PRIMARY KEY (portletpreferencesid);


--
-- Name: quartz_blob_triggers_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY quartz_blob_triggers
    ADD CONSTRAINT quartz_blob_triggers_pkey PRIMARY KEY (trigger_name, trigger_group);


--
-- Name: quartz_calendars_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY quartz_calendars
    ADD CONSTRAINT quartz_calendars_pkey PRIMARY KEY (calendar_name);


--
-- Name: quartz_cron_triggers_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY quartz_cron_triggers
    ADD CONSTRAINT quartz_cron_triggers_pkey PRIMARY KEY (trigger_name, trigger_group);


--
-- Name: quartz_fired_triggers_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY quartz_fired_triggers
    ADD CONSTRAINT quartz_fired_triggers_pkey PRIMARY KEY (entry_id);


--
-- Name: quartz_job_details_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY quartz_job_details
    ADD CONSTRAINT quartz_job_details_pkey PRIMARY KEY (job_name, job_group);


--
-- Name: quartz_job_listeners_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY quartz_job_listeners
    ADD CONSTRAINT quartz_job_listeners_pkey PRIMARY KEY (job_name, job_group, job_listener);


--
-- Name: quartz_locks_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY quartz_locks
    ADD CONSTRAINT quartz_locks_pkey PRIMARY KEY (lock_name);


--
-- Name: quartz_paused_trigger_grps_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY quartz_paused_trigger_grps
    ADD CONSTRAINT quartz_paused_trigger_grps_pkey PRIMARY KEY (trigger_group);


--
-- Name: quartz_scheduler_state_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY quartz_scheduler_state
    ADD CONSTRAINT quartz_scheduler_state_pkey PRIMARY KEY (instance_name);


--
-- Name: quartz_simple_triggers_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY quartz_simple_triggers
    ADD CONSTRAINT quartz_simple_triggers_pkey PRIMARY KEY (trigger_name, trigger_group);


--
-- Name: quartz_trigger_listeners_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY quartz_trigger_listeners
    ADD CONSTRAINT quartz_trigger_listeners_pkey PRIMARY KEY (trigger_name, trigger_group, trigger_listener);


--
-- Name: quartz_triggers_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY quartz_triggers
    ADD CONSTRAINT quartz_triggers_pkey PRIMARY KEY (trigger_name, trigger_group);


--
-- Name: ratingsentry_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY ratingsentry
    ADD CONSTRAINT ratingsentry_pkey PRIMARY KEY (entryid);


--
-- Name: ratingsstats_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY ratingsstats
    ADD CONSTRAINT ratingsstats_pkey PRIMARY KEY (statsid);


--
-- Name: region_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY region
    ADD CONSTRAINT region_pkey PRIMARY KEY (regionid);


--
-- Name: release__pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY release_
    ADD CONSTRAINT release__pkey PRIMARY KEY (releaseid);


--
-- Name: resource__pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY resource_
    ADD CONSTRAINT resource__pkey PRIMARY KEY (resourceid);


--
-- Name: resourceaction_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY resourceaction
    ADD CONSTRAINT resourceaction_pkey PRIMARY KEY (resourceactionid);


--
-- Name: resourcecode_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY resourcecode
    ADD CONSTRAINT resourcecode_pkey PRIMARY KEY (codeid);


--
-- Name: resourcepermission_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY resourcepermission
    ADD CONSTRAINT resourcepermission_pkey PRIMARY KEY (resourcepermissionid);


--
-- Name: role__pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY role_
    ADD CONSTRAINT role__pkey PRIMARY KEY (roleid);


--
-- Name: roles_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY roles_permissions
    ADD CONSTRAINT roles_permissions_pkey PRIMARY KEY (roleid, permissionid);


--
-- Name: scframeworkversi_scproductvers_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY scframeworkversi_scproductvers
    ADD CONSTRAINT scframeworkversi_scproductvers_pkey PRIMARY KEY (frameworkversionid, productversionid);


--
-- Name: scframeworkversion_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY scframeworkversion
    ADD CONSTRAINT scframeworkversion_pkey PRIMARY KEY (frameworkversionid);


--
-- Name: sclicense_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY sclicense
    ADD CONSTRAINT sclicense_pkey PRIMARY KEY (licenseid);


--
-- Name: sclicenses_scproductentries_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY sclicenses_scproductentries
    ADD CONSTRAINT sclicenses_scproductentries_pkey PRIMARY KEY (licenseid, productentryid);


--
-- Name: scproductentry_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY scproductentry
    ADD CONSTRAINT scproductentry_pkey PRIMARY KEY (productentryid);


--
-- Name: scproductscreenshot_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY scproductscreenshot
    ADD CONSTRAINT scproductscreenshot_pkey PRIMARY KEY (productscreenshotid);


--
-- Name: scproductversion_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY scproductversion
    ADD CONSTRAINT scproductversion_pkey PRIMARY KEY (productversionid);


--
-- Name: servicecomponent_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY servicecomponent
    ADD CONSTRAINT servicecomponent_pkey PRIMARY KEY (servicecomponentid);


--
-- Name: shard_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY shard
    ADD CONSTRAINT shard_pkey PRIMARY KEY (shardid);


--
-- Name: shoppingcart_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY shoppingcart
    ADD CONSTRAINT shoppingcart_pkey PRIMARY KEY (cartid);


--
-- Name: shoppingcategory_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY shoppingcategory
    ADD CONSTRAINT shoppingcategory_pkey PRIMARY KEY (categoryid);


--
-- Name: shoppingcoupon_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY shoppingcoupon
    ADD CONSTRAINT shoppingcoupon_pkey PRIMARY KEY (couponid);


--
-- Name: shoppingitem_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY shoppingitem
    ADD CONSTRAINT shoppingitem_pkey PRIMARY KEY (itemid);


--
-- Name: shoppingitemfield_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY shoppingitemfield
    ADD CONSTRAINT shoppingitemfield_pkey PRIMARY KEY (itemfieldid);


--
-- Name: shoppingitemprice_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY shoppingitemprice
    ADD CONSTRAINT shoppingitemprice_pkey PRIMARY KEY (itempriceid);


--
-- Name: shoppingorder_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY shoppingorder
    ADD CONSTRAINT shoppingorder_pkey PRIMARY KEY (orderid);


--
-- Name: shoppingorderitem_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY shoppingorderitem
    ADD CONSTRAINT shoppingorderitem_pkey PRIMARY KEY (orderitemid);


--
-- Name: socialactivity_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY socialactivity
    ADD CONSTRAINT socialactivity_pkey PRIMARY KEY (activityid);


--
-- Name: socialequityassetentry_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY socialequityassetentry
    ADD CONSTRAINT socialequityassetentry_pkey PRIMARY KEY (equityassetentryid);


--
-- Name: socialequitygroupsetting_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY socialequitygroupsetting
    ADD CONSTRAINT socialequitygroupsetting_pkey PRIMARY KEY (equitygroupsettingid);


--
-- Name: socialequityhistory_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY socialequityhistory
    ADD CONSTRAINT socialequityhistory_pkey PRIMARY KEY (equityhistoryid);


--
-- Name: socialequitylog_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY socialequitylog
    ADD CONSTRAINT socialequitylog_pkey PRIMARY KEY (equitylogid);


--
-- Name: socialequitysetting_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY socialequitysetting
    ADD CONSTRAINT socialequitysetting_pkey PRIMARY KEY (equitysettingid);


--
-- Name: socialequityuser_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY socialequityuser
    ADD CONSTRAINT socialequityuser_pkey PRIMARY KEY (equityuserid);


--
-- Name: socialrelation_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY socialrelation
    ADD CONSTRAINT socialrelation_pkey PRIMARY KEY (relationid);


--
-- Name: socialrequest_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY socialrequest
    ADD CONSTRAINT socialrequest_pkey PRIMARY KEY (requestid);


--
-- Name: subscription_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY subscription
    ADD CONSTRAINT subscription_pkey PRIMARY KEY (subscriptionid);


--
-- Name: tasksproposal_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY tasksproposal
    ADD CONSTRAINT tasksproposal_pkey PRIMARY KEY (proposalid);


--
-- Name: tasksreview_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY tasksreview
    ADD CONSTRAINT tasksreview_pkey PRIMARY KEY (reviewid);


--
-- Name: team_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY team
    ADD CONSTRAINT team_pkey PRIMARY KEY (teamid);


--
-- Name: ticket_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY ticket
    ADD CONSTRAINT ticket_pkey PRIMARY KEY (ticketid);


--
-- Name: user__pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY user_
    ADD CONSTRAINT user__pkey PRIMARY KEY (userid);


--
-- Name: usergroup_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY usergroup
    ADD CONSTRAINT usergroup_pkey PRIMARY KEY (usergroupid);


--
-- Name: usergroupgrouprole_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY usergroupgrouprole
    ADD CONSTRAINT usergroupgrouprole_pkey PRIMARY KEY (usergroupid, groupid, roleid);


--
-- Name: usergrouprole_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY usergrouprole
    ADD CONSTRAINT usergrouprole_pkey PRIMARY KEY (userid, groupid, roleid);


--
-- Name: useridmapper_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY useridmapper
    ADD CONSTRAINT useridmapper_pkey PRIMARY KEY (useridmapperid);


--
-- Name: users_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY users_groups
    ADD CONSTRAINT users_groups_pkey PRIMARY KEY (userid, groupid);


--
-- Name: users_orgs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY users_orgs
    ADD CONSTRAINT users_orgs_pkey PRIMARY KEY (userid, organizationid);


--
-- Name: users_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY users_permissions
    ADD CONSTRAINT users_permissions_pkey PRIMARY KEY (userid, permissionid);


--
-- Name: users_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY users_roles
    ADD CONSTRAINT users_roles_pkey PRIMARY KEY (userid, roleid);


--
-- Name: users_teams_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY users_teams
    ADD CONSTRAINT users_teams_pkey PRIMARY KEY (userid, teamid);


--
-- Name: users_usergroups_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY users_usergroups
    ADD CONSTRAINT users_usergroups_pkey PRIMARY KEY (usergroupid, userid);


--
-- Name: usertracker_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY usertracker
    ADD CONSTRAINT usertracker_pkey PRIMARY KEY (usertrackerid);


--
-- Name: usertrackerpath_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY usertrackerpath
    ADD CONSTRAINT usertrackerpath_pkey PRIMARY KEY (usertrackerpathid);


--
-- Name: vocabulary_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY vocabulary
    ADD CONSTRAINT vocabulary_pkey PRIMARY KEY (vocabularyid);


--
-- Name: webdavprops_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY webdavprops
    ADD CONSTRAINT webdavprops_pkey PRIMARY KEY (webdavpropsid);


--
-- Name: website_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY website
    ADD CONSTRAINT website_pkey PRIMARY KEY (websiteid);


--
-- Name: wikinode_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY wikinode
    ADD CONSTRAINT wikinode_pkey PRIMARY KEY (nodeid);


--
-- Name: wikipage_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY wikipage
    ADD CONSTRAINT wikipage_pkey PRIMARY KEY (pageid);


--
-- Name: wikipageresource_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY wikipageresource
    ADD CONSTRAINT wikipageresource_pkey PRIMARY KEY (resourceprimkey);


--
-- Name: workflowdefinitionlink_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY workflowdefinitionlink
    ADD CONSTRAINT workflowdefinitionlink_pkey PRIMARY KEY (workflowdefinitionlinkid);


--
-- Name: workflowinstancelink_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY workflowinstancelink
    ADD CONSTRAINT workflowinstancelink_pkey PRIMARY KEY (workflowinstancelinkid);


--
-- Name: ix_103d6207; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE UNIQUE INDEX ix_103d6207 ON journalarticleimage USING btree (groupid, articleid, version, elinstanceid, elname, languageid);


--
-- Name: ix_1073ab9f; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_1073ab9f ON mbmessage USING btree (groupid, categoryid);


--
-- Name: ix_119b5630; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_119b5630 ON shoppingorder USING btree (groupid, userid, pppaymentstatus);


--
-- Name: ix_11fb3e42; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_11fb3e42 ON region USING btree (countryid, active_);


--
-- Name: ix_12112599; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_12112599 ON pollsvote USING btree (questionid);


--
-- Name: ix_121ca3cb; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_121ca3cb ON socialactivity USING btree (receiveruserid);


--
-- Name: ix_12566ec2; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_12566ec2 ON company USING btree (mx);


--
-- Name: ix_1271f25f; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_1271f25f ON socialactivity USING btree (mirroractivityid);


--
-- Name: ix_128516c8; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_128516c8 ON assetlink USING btree (entryid1);


--
-- Name: ix_12851a89; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_12851a89 ON assetlink USING btree (entryid2);


--
-- Name: ix_12a92145; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE UNIQUE INDEX ix_12a92145 ON socialrelation USING btree (userid1, userid2, type_);


--
-- Name: ix_12b5e51d; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE UNIQUE INDEX ix_12b5e51d ON portlet USING btree (companyid, portletid);


--
-- Name: ix_12ee4898; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_12ee4898 ON calevent USING btree (groupid);


--
-- Name: ix_13805bf7; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_13805bf7 ON assettagproperty USING btree (companyid, key_);


--
-- Name: ix_13c5cd3a; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_13c5cd3a ON lock_ USING btree (uuid_);


--
-- Name: ix_143dc786; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE UNIQUE INDEX ix_143dc786 ON team USING btree (groupid, name);


--
-- Name: ix_14d5a20d; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_14d5a20d ON assetlink USING btree (entryid1, type_);


--
-- Name: ix_14d8bcc0; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_14d8bcc0 ON usertrackerpath USING btree (usertrackerid);


--
-- Name: ix_14f06a6b; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_14f06a6b ON announcementsentry USING btree (classnameid, classpk, alert);


--
-- Name: ix_158b526f; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_158b526f ON journalarticleimage USING btree (groupid, articleid, version);


--
-- Name: ix_15a017b; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_15a017b ON socialequitylog USING btree (userid, actionid, actiondate, active_, type_);


--
-- Name: ix_16184d57; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_16184d57 ON ratingsentry USING btree (classnameid, classpk);


--
-- Name: ix_16218a38; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_16218a38 ON group_ USING btree (livegroupid);


--
-- Name: ix_166a8f03; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_166a8f03 ON socialequityuser USING btree (rank);


--
-- Name: ix_16d87ca7; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_16d87ca7 ON region USING btree (countryid);


--
-- Name: ix_1701cb2b; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_1701cb2b ON journaltemplate USING btree (groupid, structureid);


--
-- Name: ix_181a4a1b; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE UNIQUE INDEX ix_181a4a1b ON tasksproposal USING btree (classnameid, classpk);


--
-- Name: ix_1894b29a; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_1894b29a ON tasksreview USING btree (proposalid, stage, completed);


--
-- Name: ix_19da007b; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE UNIQUE INDEX ix_19da007b ON country USING btree (name);


--
-- Name: ix_1a1b61d2; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_1a1b61d2 ON layout USING btree (groupid, privatelayout, type_);


--
-- Name: ix_1a605e9f; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_1a605e9f ON igfolder USING btree (groupid, parentfolderid);


--
-- Name: ix_1aa07a6d; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_1aa07a6d ON website USING btree (companyid, classnameid, classpk, primary_);


--
-- Name: ix_1ad93c16; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_1ad93c16 ON mbmessage USING btree (companyid, status);


--
-- Name: ix_1afbde08; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_1afbde08 ON announcementsentry USING btree (uuid_);


--
-- Name: ix_1b1040fd; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE UNIQUE INDEX ix_1b1040fd ON blogsentry USING btree (uuid_, groupid);


--
-- Name: ix_1b12ca20; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_1b12ca20 ON journaltemplate USING btree (templateid);


--
-- Name: ix_1b2b8792; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE UNIQUE INDEX ix_1b2b8792 ON assetvocabulary USING btree (uuid_, groupid);


--
-- Name: ix_1b988d7a; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_1b988d7a ON usergrouprole USING btree (groupid);


--
-- Name: ix_1bb072ca; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_1bb072ca ON emailaddress USING btree (companyid);


--
-- Name: ix_1bbfd4d3; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE UNIQUE INDEX ix_1bbfd4d3 ON pollsvote USING btree (questionid, userid);


--
-- Name: ix_1bd3f4c; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_1bd3f4c ON expandovalue USING btree (tableid, classpk);


--
-- Name: ix_1c717ca6; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE UNIQUE INDEX ix_1c717ca6 ON shoppingitem USING btree (companyid, sku);


--
-- Name: ix_1c841592; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_1c841592 ON sclicense USING btree (active_);


--
-- Name: ix_1cdf88c; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_1cdf88c ON usergroupgrouprole USING btree (roleid);


--
-- Name: ix_1d15553e; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_1d15553e ON shoppingorder USING btree (groupid);


--
-- Name: ix_1d731f03; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_1d731f03 ON user_ USING btree (companyid, facebookid);


--
-- Name: ix_1e6464f5; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_1e6464f5 ON shoppingcategory USING btree (groupid, parentcategoryid);


--
-- Name: ix_1e9d371d; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE UNIQUE INDEX ix_1e9d371d ON assetentry USING btree (classnameid, classpk);


--
-- Name: ix_1eba6821; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_1eba6821 ON assetentry USING btree (groupid, classuuid);


--
-- Name: ix_1ecc7656; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_1ecc7656 ON wikipage USING btree (nodeid, redirecttitle);


--
-- Name: ix_1efd8ee9; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_1efd8ee9 ON blogsentry USING btree (groupid, status);


--
-- Name: ix_1f00c374; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_1f00c374 ON socialactivity USING btree (mirroractivityid, classnameid, classpk);


--
-- Name: ix_206498f8; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_206498f8 ON igfolder USING btree (groupid);


--
-- Name: ix_20962903; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_20962903 ON journalcontentsearch USING btree (groupid, privatelayout);


--
-- Name: ix_20d8706c; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_20d8706c ON quartz_fired_triggers USING btree (trigger_name, trigger_group);


--
-- Name: ix_21277664; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE UNIQUE INDEX ix_21277664 ON wikipageresource USING btree (nodeid, title);


--
-- Name: ix_2200aa69; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_2200aa69 ON resourcepermission USING btree (companyid, name, scope, primkey);


--
-- Name: ix_228562ad; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_228562ad ON lock_ USING btree (classname, key_);


--
-- Name: ix_22882d02; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_22882d02 ON journalarticle USING btree (groupid, urltitle);


--
-- Name: ix_22f6b5cb; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE UNIQUE INDEX ix_22f6b5cb ON socialequityassetentry USING btree (assetentryid);


--
-- Name: ix_23922f7d; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_23922f7d ON layout USING btree (iconimageid);


--
-- Name: ix_23ead0d; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE UNIQUE INDEX ix_23ead0d ON usergroup USING btree (companyid, name);


--
-- Name: ix_2578fbd3; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_2578fbd3 ON resource_ USING btree (codeid);


--
-- Name: ix_25d734cd; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_25d734cd ON country USING btree (active_);


--
-- Name: ix_25ffb6fa; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_25ffb6fa ON journaltemplate USING btree (smallimageid);


--
-- Name: ix_265bb0f1; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_265bb0f1 ON igimage USING btree (uuid_);


--
-- Name: ix_27006638; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_27006638 ON sclicenses_scproductentries USING btree (licenseid);


--
-- Name: ix_272991fa; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_272991fa ON scframeworkversion USING btree (groupid);


--
-- Name: ix_2857419d; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_2857419d ON journaltemplate USING btree (uuid_);


--
-- Name: ix_287b1f89; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_287b1f89 ON assetcategory USING btree (vocabularyid);


--
-- Name: ix_28c78d5c; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_28c78d5c ON blogsstatsuser USING btree (groupid, entrycount);


--
-- Name: ix_2932dd37; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_2932dd37 ON listtype USING btree (type_);


--
-- Name: ix_29ba1cf5; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_29ba1cf5 ON usertracker USING btree (companyid);


--
-- Name: ix_2a2468; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_2a2468 ON socialactivity USING btree (groupid);


--
-- Name: ix_2a2cb130; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_2a2cb130 ON emailaddress USING btree (companyid, classnameid, classpk, primary_);


--
-- Name: ix_2aba25d7; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_2aba25d7 ON bookmarksfolder USING btree (companyid);


--
-- Name: ix_2c1142e; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_2c1142e ON passwordpolicy USING btree (companyid, defaultpolicy);


--
-- Name: ix_2c61314e; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_2c61314e ON portletitem USING btree (groupid, portletid);


--
-- Name: ix_2c944354; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE UNIQUE INDEX ix_2c944354 ON assettagproperty USING btree (tagid, key_);


--
-- Name: ix_2cd67c81; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE UNIQUE INDEX ix_2cd67c81 ON wikipage USING btree (resourceprimkey, nodeid, version);


--
-- Name: ix_2d9a426f; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_2d9a426f ON region USING btree (active_);


--
-- Name: ix_2e1a92d4; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE UNIQUE INDEX ix_2e1a92d4 ON subscription USING btree (companyid, userid, classnameid, classpk);


--
-- Name: ix_2e207659; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_2e207659 ON journalarticle USING btree (groupid, structureid);


--
-- Name: ix_2ea537d7; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_2ea537d7 ON mbmessageflag USING btree (userid, threadid, flag);


--
-- Name: ix_2ed82cad; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_2ed82cad ON assetentries_assettags USING btree (entryid);


--
-- Name: ix_2f80c17c; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_2f80c17c ON resourcepermission USING btree (roleid, scope);


--
-- Name: ix_2f8fed9c; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE UNIQUE INDEX ix_2f8fed9c ON dlfileversion USING btree (groupid, folderid, name, version);


--
-- Name: ix_301d024b; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_301d024b ON journalarticle USING btree (groupid, status);


--
-- Name: ix_30616aaa; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_30616aaa ON layoutprototype USING btree (companyid);


--
-- Name: ix_3103ef3d; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_3103ef3d ON groups_roles USING btree (roleid);


--
-- Name: ix_31fb749a; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_31fb749a ON groups_usergroups USING btree (groupid);


--
-- Name: ix_32292ed1; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_32292ed1 ON socialrequest USING btree (receiveruserid);


--
-- Name: ix_323df109; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_323df109 ON journalarticle USING btree (companyid, status);


--
-- Name: ix_3251af16; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_3251af16 ON shoppingcoupon USING btree (groupid);


--
-- Name: ix_3269e180; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_3269e180 ON assettagproperty USING btree (tagid);


--
-- Name: ix_326f75bd; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_326f75bd ON passwordtracker USING btree (userid);


--
-- Name: ix_33a4de38; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE UNIQUE INDEX ix_33a4de38 ON mbdiscussion USING btree (classnameid, classpk);


--
-- Name: ix_33b8ce8d; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_33b8ce8d ON portletitem USING btree (groupid, portletid, name);


--
-- Name: ix_33f49d16; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_33f49d16 ON journalarticle USING btree (resourceprimkey);


--
-- Name: ix_3463d95b; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE UNIQUE INDEX ix_3463d95b ON journalarticle USING btree (uuid_, groupid);


--
-- Name: ix_346a0992; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_346a0992 ON dlfileshortcut USING btree (groupid, tofolderid, toname, status);


--
-- Name: ix_3504b8bc; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_3504b8bc ON socialactivity USING btree (userid);


--
-- Name: ix_3525a383; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_3525a383 ON socialequitylog USING btree (userid, actionid, active_, type_);


--
-- Name: ix_35a2db2f; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_35a2db2f ON journalfeed USING btree (groupid);


--
-- Name: ix_35e3e7c6; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_35e3e7c6 ON company USING btree (system);


--
-- Name: ix_36a90ca7; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE UNIQUE INDEX ix_36a90ca7 ON socialrequest USING btree (userid, classnameid, classpk, type_, receiveruserid);


--
-- Name: ix_36f512e6; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_36f512e6 ON tasksreview USING btree (userid);


--
-- Name: ix_37562284; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE UNIQUE INDEX ix_37562284 ON expandotable USING btree (companyid, classnameid, name);


--
-- Name: ix_377858d2; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_377858d2 ON mbmessage USING btree (groupid, userid, status);


--
-- Name: ix_385e123e; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_385e123e ON mbmessage USING btree (groupid, categoryid, threadid, status);


--
-- Name: ix_38efe3fd; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_38efe3fd ON company USING btree (logoid);


--
-- Name: ix_39031f51; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE UNIQUE INDEX ix_39031f51 ON journalfeed USING btree (uuid_, groupid);


--
-- Name: ix_3a1e834e; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_3a1e834e ON user_ USING btree (companyid);


--
-- Name: ix_3b51bb68; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_3b51bb68 ON journalarticleimage USING btree (groupid);


--
-- Name: ix_3b69160f; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_3b69160f ON groups_usergroups USING btree (usergroupid);


--
-- Name: ix_3bb93eca; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_3bb93eca ON scframeworkversi_scproductvers USING btree (frameworkversionid);


--
-- Name: ix_3cc1ded2; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE UNIQUE INDEX ix_3cc1ded2 ON dlfolder USING btree (uuid_, groupid);


--
-- Name: ix_3cfd579d; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_3cfd579d ON mbmessageflag USING btree (threadid, flag);


--
-- Name: ix_3d4af476; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE UNIQUE INDEX ix_3d4af476 ON wikipage USING btree (nodeid, title, version);


--
-- Name: ix_3e2765fc; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_3e2765fc ON journalarticle USING btree (resourceprimkey, status);


--
-- Name: ix_3f9c2fa8; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_3f9c2fa8 ON socialrelation USING btree (userid2, type_);


--
-- Name: ix_3fbfa9f4; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE UNIQUE INDEX ix_3fbfa9f4 ON passwordpolicy USING btree (companyid, name);


--
-- Name: ix_40b56512; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_40b56512 ON dlfilerank USING btree (folderid, name);


--
-- Name: ix_4115ec7a; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_4115ec7a ON mbmailinglist USING btree (uuid_);


--
-- Name: ix_415a7007; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_415a7007 ON workflowinstancelink USING btree (groupid, companyid, classnameid, classpk);


--
-- Name: ix_418e4522; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_418e4522 ON organization_ USING btree (companyid, parentorganizationid);


--
-- Name: ix_41a32e0d; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE UNIQUE INDEX ix_41a32e0d ON useridmapper USING btree (type_, externaluserid);


--
-- Name: ix_41afc20c; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_41afc20c ON tasksreview USING btree (proposalid, stage, completed, rejected);


--
-- Name: ix_41f6dc8a; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_41f6dc8a ON mbthread USING btree (categoryid, priority);


--
-- Name: ix_4257db85; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_4257db85 ON mbmessage USING btree (groupid, categoryid, status);


--
-- Name: ix_42e86e58; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE UNIQUE INDEX ix_42e86e58 ON journalstructure USING btree (uuid_, groupid);


--
-- Name: ix_430d791f; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_430d791f ON blogsentry USING btree (companyid, displaydate);


--
-- Name: ix_43261870; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_43261870 ON dlfileentry USING btree (groupid, userid);


--
-- Name: ix_432f0ab0; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_432f0ab0 ON wikipage USING btree (nodeid, head, status);


--
-- Name: ix_43840eeb; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_43840eeb ON blogsstatsuser USING btree (groupid);


--
-- Name: ix_449a10b9; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_449a10b9 ON role_ USING btree (companyid);


--
-- Name: ix_451e7ae3; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_451e7ae3 ON bookmarksfolder USING btree (uuid_);


--
-- Name: ix_4539a99c; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE UNIQUE INDEX ix_4539a99c ON announcementsflag USING btree (userid, entryid, value);


--
-- Name: ix_467956fd; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_467956fd ON scproductscreenshot USING btree (productentryid);


--
-- Name: ix_46b0ae8e; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_46b0ae8e ON usertracker USING btree (sessionid);


--
-- Name: ix_46eef3c8; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_46eef3c8 ON wikipage USING btree (nodeid, parenttitle);


--
-- Name: ix_4831ebe4; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_4831ebe4 ON dlfileshortcut USING btree (uuid_);


--
-- Name: ix_48550691; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE UNIQUE INDEX ix_48550691 ON layoutset USING btree (groupid, privatelayout);


--
-- Name: ix_485f7e98; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_485f7e98 ON mbthread USING btree (groupid, categoryid, status);


--
-- Name: ix_48814bba; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_48814bba ON mbban USING btree (userid);


--
-- Name: ix_49c37475; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_49c37475 ON dlfolder USING btree (groupid, parentfolderid);


--
-- Name: ix_49d2dec4; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_49d2dec4 ON emailaddress USING btree (companyid, classnameid);


--
-- Name: ix_49d5872c; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_49d5872c ON socialrequest USING btree (uuid_);


--
-- Name: ix_49e15a23; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_49e15a23 ON blogsentry USING btree (groupid, userid, status);


--
-- Name: ix_4a527dd3; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_4a527dd3 ON orggrouprole USING btree (groupid);


--
-- Name: ix_4b52be89; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_4b52be89 ON socialrelation USING btree (userid1, type_);


--
-- Name: ix_4cb1b2b4; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_4cb1b2b4 ON dlfileentry USING btree (companyid);


--
-- Name: ix_4d040680; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_4d040680 ON usergrouprole USING btree (userid, groupid);


--
-- Name: ix_4d06ad51; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_4d06ad51 ON users_teams USING btree (teamid);


--
-- Name: ix_4d0c7f8d; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_4d0c7f8d ON tasksreview USING btree (proposalid);


--
-- Name: ix_4d19c2b8; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE UNIQUE INDEX ix_4d19c2b8 ON permission_ USING btree (actionid, resourceid);


--
-- Name: ix_4d37bb00; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_4d37bb00 ON assetcategory USING btree (uuid_);


--
-- Name: ix_4d5cd982; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_4d5cd982 ON journalarticle USING btree (groupid, articleid, status);


--
-- Name: ix_4f0315b8; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE UNIQUE INDEX ix_4f0315b8 ON servicecomponent USING btree (buildnamespace, buildnumber);


--
-- Name: ix_4f0f0ca7; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_4f0f0ca7 ON website USING btree (companyid, classnameid);


--
-- Name: ix_4f973efe; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE UNIQUE INDEX ix_4f973efe ON socialrequest USING btree (uuid_, groupid);


--
-- Name: ix_4fddd2bf; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_4fddd2bf ON calevent USING btree (groupid, repeating);


--
-- Name: ix_50702693; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_50702693 ON assettagstats USING btree (classnameid);


--
-- Name: ix_507ba031; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_507ba031 ON blogsstatsuser USING btree (userid, lastpostdate);


--
-- Name: ix_50c36d79; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_50c36d79 ON journalfeed USING btree (uuid_);


--
-- Name: ix_50f1904a; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_50f1904a ON mbthread USING btree (groupid, categoryid, lastpostdate);


--
-- Name: ix_51556082; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_51556082 ON dlfolder USING btree (parentfolderid, name);


--
-- Name: ix_51a8d44d; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_51a8d44d ON mbmessage USING btree (classnameid, classpk);


--
-- Name: ix_51f087f4; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_51f087f4 ON pollsquestion USING btree (uuid_);


--
-- Name: ix_5200100c; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_5200100c ON bookmarksentry USING btree (groupid, folderid);


--
-- Name: ix_5204c37b; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_5204c37b ON user_ USING btree (companyid, active_);


--
-- Name: ix_52340033; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_52340033 ON assetcategoryproperty USING btree (companyid, key_);


--
-- Name: ix_524fefce; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_524fefce ON usergroup USING btree (companyid);


--
-- Name: ix_5327bb79; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_5327bb79 ON sclicense USING btree (active_, recommended);


--
-- Name: ix_5391712; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE UNIQUE INDEX ix_5391712 ON dlfileentry USING btree (groupid, folderid, name);


--
-- Name: ix_54101cc8; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_54101cc8 ON shoppingcart USING btree (userid);


--
-- Name: ix_54243afd; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_54243afd ON subscription USING btree (userid);


--
-- Name: ix_546f2d5c; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_546f2d5c ON wikipage USING btree (nodeid, status);


--
-- Name: ix_551a519f; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_551a519f ON emailaddress USING btree (companyid, classnameid, classpk);


--
-- Name: ix_557a639f; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_557a639f ON layoutprototype USING btree (companyid, active_);


--
-- Name: ix_55b2f00c; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE UNIQUE INDEX ix_55b2f00c ON socialequitylog USING btree (userid, assetentryid, actionid, actiondate, active_, type_);


--
-- Name: ix_55c736ac; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_55c736ac ON dlfileshortcut USING btree (groupid, tofolderid, toname);


--
-- Name: ix_55f58818; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_55f58818 ON assetvocabulary USING btree (uuid_);


--
-- Name: ix_55f63d98; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_55f63d98 ON layoutsetprototype USING btree (companyid);


--
-- Name: ix_56682cc4; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE UNIQUE INDEX ix_56682cc4 ON assettagstats USING btree (tagid, classnameid);


--
-- Name: ix_56e0ab21; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_56e0ab21 ON assetlink USING btree (entryid1, entryid2);


--
-- Name: ix_5a40cdcc; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_5a40cdcc ON socialrelation USING btree (userid1);


--
-- Name: ix_5a40d18d; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_5a40d18d ON socialrelation USING btree (userid2);


--
-- Name: ix_5aa68501; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE UNIQUE INDEX ix_5aa68501 ON group_ USING btree (companyid, name);


--
-- Name: ix_5abc2905; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_5abc2905 ON layoutset USING btree (virtualhost);


--
-- Name: ix_5adbe171; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE UNIQUE INDEX ix_5adbe171 ON user_ USING btree (contactid);


--
-- Name: ix_5b153fb2; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_5b153fb2 ON mbmessage USING btree (groupid);


--
-- Name: ix_5bc8b0d4; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_5bc8b0d4 ON address USING btree (userid);


--
-- Name: ix_5bddb872; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE UNIQUE INDEX ix_5bddb872 ON group_ USING btree (companyid, friendlyurl);


--
-- Name: ix_5c3ff12a; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_5c3ff12a ON mbban USING btree (groupid);


--
-- Name: ix_5c6be4c7; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE UNIQUE INDEX ix_5c6be4c7 ON tasksreview USING btree (userid, proposalid);


--
-- Name: ix_5cce79c8; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE UNIQUE INDEX ix_5cce79c8 ON calevent USING btree (uuid_, groupid);


--
-- Name: ix_5d25244f; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_5d25244f ON scproductentry USING btree (companyid);


--
-- Name: ix_5d6fe3f0; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_5d6fe3f0 ON wikinode USING btree (companyid);


--
-- Name: ix_5de0be11; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE UNIQUE INDEX ix_5de0be11 ON group_ USING btree (companyid, classnameid, livegroupid, name);


--
-- Name: ix_5eb4e2fb; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_5eb4e2fb ON role_ USING btree (subtype);


--
-- Name: ix_5f615d3e; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_5f615d3e ON shoppingcategory USING btree (groupid);


--
-- Name: ix_5feabbc; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_5feabbc ON quartz_fired_triggers USING btree (trigger_name);


--
-- Name: ix_60214cf6; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_60214cf6 ON igfolder USING btree (companyid);


--
-- Name: ix_60b99860; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_60b99860 ON resourcepermission USING btree (companyid, name, scope);


--
-- Name: ix_61171e99; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_61171e99 ON socialrelation USING btree (companyid);


--
-- Name: ix_615e9f7a; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE UNIQUE INDEX ix_615e9f7a ON user_ USING btree (companyid, emailaddress);


--
-- Name: ix_621e19d; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_621e19d ON blogsentry USING btree (groupid, displaydate);


--
-- Name: ix_62d1b3ad; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE UNIQUE INDEX ix_62d1b3ad ON journaltemplate USING btree (uuid_, groupid);


--
-- Name: ix_63820a7; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_63820a7 ON igimage USING btree (groupid);


--
-- Name: ix_64b194f2; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_64b194f2 ON quartz_fired_triggers USING btree (trigger_group);


--
-- Name: ix_64b1bc66; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_64b1bc66 ON socialactivity USING btree (companyid);


--
-- Name: ix_64f0b572; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_64f0b572 ON igimage USING btree (largeimageid);


--
-- Name: ix_64f0fe40; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_64f0fe40 ON dlfileentry USING btree (uuid_);


--
-- Name: ix_65576cbc; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE UNIQUE INDEX ix_65576cbc ON journalfeed USING btree (groupid, feedid);


--
-- Name: ix_65e84af4; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_65e84af4 ON wikipage USING btree (nodeid, head, parenttitle);


--
-- Name: ix_6660b399; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_6660b399 ON pollschoice USING btree (uuid_);


--
-- Name: ix_66d496a3; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_66d496a3 ON contact_ USING btree (companyid);


--
-- Name: ix_66d70879; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_66d70879 ON membershiprequest USING btree (userid);


--
-- Name: ix_66ff2503; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_66ff2503 ON users_usergroups USING btree (usergroupid);


--
-- Name: ix_6702ca92; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_6702ca92 ON journalstructure USING btree (uuid_);


--
-- Name: ix_67de7856; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE UNIQUE INDEX ix_67de7856 ON resource_ USING btree (codeid, primkey);


--
-- Name: ix_6838e427; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_6838e427 ON journalcontentsearch USING btree (groupid, articleid);


--
-- Name: ix_68c0f69c; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_68c0f69c ON journalarticle USING btree (groupid, articleid);


--
-- Name: ix_69157a4d; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_69157a4d ON blogsentry USING btree (uuid_);


--
-- Name: ix_69771487; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_69771487 ON usergroup USING btree (companyid, parentusergroupid);


--
-- Name: ix_69951a25; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_69951a25 ON mbban USING btree (banuserid);


--
-- Name: ix_6a925a4d; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_6a925a4d ON image USING btree (size_);


--
-- Name: ix_6af0d434; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_6af0d434 ON orglabor USING btree (organizationid);


--
-- Name: ix_6b42b3e7; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_6b42b3e7 ON socialequityuser USING btree (groupid);


--
-- Name: ix_6bbb7682; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_6bbb7682 ON groups_orgs USING btree (organizationid);


--
-- Name: ix_6c112d7c; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_6c112d7c ON wikinode USING btree (uuid_);


--
-- Name: ix_6c53da4e; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_6c53da4e ON orggrouppermission USING btree (permissionid);


--
-- Name: ix_6c572dac; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_6c572dac ON scproductscreenshot USING btree (thumbnailid);


--
-- Name: ix_6d5f9b87; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_6d5f9b87 ON shoppingitemfield USING btree (itemid);


--
-- Name: ix_6de88b06; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_6de88b06 ON layout USING btree (groupid, privatelayout, parentlayoutid);


--
-- Name: ix_6e1764f; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_6e1764f ON scframeworkversion USING btree (groupid, active_);


--
-- Name: ix_6ecbd5d; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_6ecbd5d ON socialequityuser USING btree (userid);


--
-- Name: ix_6edb9600; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_6edb9600 ON announcementsdelivery USING btree (userid);


--
-- Name: ix_6eec675e; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_6eec675e ON tasksproposal USING btree (groupid, userid);


--
-- Name: ix_6ef03e4e; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_6ef03e4e ON user_ USING btree (companyid, defaultuser);


--
-- Name: ix_7020130f; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_7020130f ON scproductversion USING btree (directdownloadurl);


--
-- Name: ix_705f5aa3; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_705f5aa3 ON layout USING btree (groupid, privatelayout);


--
-- Name: ix_70afea01; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_70afea01 ON tasksreview USING btree (proposalid, stage);


--
-- Name: ix_7162c27c; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE UNIQUE INDEX ix_7162c27c ON layout USING btree (groupid, privatelayout, layoutid);


--
-- Name: ix_7171b2e8; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE UNIQUE INDEX ix_7171b2e8 ON pluginsetting USING btree (companyid, pluginid, plugintype);


--
-- Name: ix_717b97e1; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE UNIQUE INDEX ix_717b97e1 ON country USING btree (a2);


--
-- Name: ix_717b9ba2; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE UNIQUE INDEX ix_717b9ba2 ON country USING btree (a3);


--
-- Name: ix_717fdd47; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_717fdd47 ON resourcecode USING btree (companyid);


--
-- Name: ix_71cb1123; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_71cb1123 ON address USING btree (companyid, classnameid, classpk);


--
-- Name: ix_72ef6041; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_72ef6041 ON blogsentry USING btree (companyid);


--
-- Name: ix_72f87291; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_72f87291 ON scproductentry USING btree (groupid);


--
-- Name: ix_7306c60; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_7306c60 ON assetentry USING btree (companyid);


--
-- Name: ix_7311e812; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_7311e812 ON scproductentry USING btree (repogroupid, repoartifactid);


--
-- Name: ix_7338606f; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_7338606f ON servicecomponent USING btree (buildnamespace);


--
-- Name: ix_73c52252; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_73c52252 ON usergroupgrouprole USING btree (usergroupid, groupid);


--
-- Name: ix_75267dca; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_75267dca ON groups_orgs USING btree (groupid);


--
-- Name: ix_75b95071; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_75b95071 ON mbmessage USING btree (threadid);


--
-- Name: ix_7609b2ae; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE UNIQUE INDEX ix_7609b2ae ON wikinode USING btree (uuid_, groupid);


--
-- Name: ix_762f63c6; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_762f63c6 ON user_ USING btree (emailaddress);


--
-- Name: ix_76ce9cdd; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE UNIQUE INDEX ix_76ce9cdd ON mbmailinglist USING btree (groupid, categoryid);


--
-- Name: ix_77923653; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_77923653 ON journaltemplate USING btree (groupid);


--
-- Name: ix_786d171a; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_786d171a ON subscription USING btree (companyid, classnameid, classpk);


--
-- Name: ix_79d0120b; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_79d0120b ON mbdiscussion USING btree (classnameid);


--
-- Name: ix_7a040c32; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_7a040c32 ON mbmessage USING btree (userid);


--
-- Name: ix_7a3619c6; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_7a3619c6 ON roles_permissions USING btree (permissionid);


--
-- Name: ix_7acc74c9; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_7acc74c9 ON journalcontentsearch USING btree (groupid, privatelayout, layoutid, portletid);


--
-- Name: ix_7b2917be; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_7b2917be ON mbmessageflag USING btree (userid);


--
-- Name: ix_7b43cd8; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_7b43cd8 ON emailaddress USING btree (userid);


--
-- Name: ix_7b590a7a; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_7b590a7a ON group_ USING btree (type_, active_);


--
-- Name: ix_7bb1826b; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_7bb1826b ON assetcategory USING btree (parentcategoryid);


--
-- Name: ix_7c9e46ba; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_7c9e46ba ON assettag USING btree (groupid);


--
-- Name: ix_7cc7d73e; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_7cc7d73e ON journalcontentsearch USING btree (groupid, privatelayout, articleid);


--
-- Name: ix_7ef4ec0e; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_7ef4ec0e ON users_orgs USING btree (organizationid);


--
-- Name: ix_7f703619; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_7f703619 ON bookmarksfolder USING btree (groupid);


--
-- Name: ix_7fb27324; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_7fb27324 ON tasksproposal USING btree (groupid);


--
-- Name: ix_8040c593; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_8040c593 ON quartz_triggers USING btree (trigger_state, next_fire_time);


--
-- Name: ix_804154af; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_804154af ON quartz_fired_triggers USING btree (instance_name);


--
-- Name: ix_80cc9508; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_80cc9508 ON portlet USING btree (companyid);


--
-- Name: ix_80f7a9c2; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_80f7a9c2 ON socialrequest USING btree (userid);


--
-- Name: ix_812ce07a; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_812ce07a ON phone USING btree (companyid, classnameid, classpk, primary_);


--
-- Name: ix_81a50303; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_81a50303 ON blogsentry USING btree (groupid);


--
-- Name: ix_81efbff5; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE UNIQUE INDEX ix_81efbff5 ON expandorow USING btree (tableid, classpk);


--
-- Name: ix_81f2db09; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_81f2db09 ON resourceaction USING btree (name);


--
-- Name: ix_82254c25; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE UNIQUE INDEX ix_82254c25 ON blogsstatsuser USING btree (groupid, userid);


--
-- Name: ix_82e39a0c; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_82e39a0c ON socialactivity USING btree (classnameid);


--
-- Name: ix_834bceb6; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_834bceb6 ON organization_ USING btree (companyid);


--
-- Name: ix_8377a211; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_8377a211 ON scproductversion USING btree (productentryid);


--
-- Name: ix_84471fd2; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_84471fd2 ON groups_roles USING btree (groupid);


--
-- Name: ix_847f92b5; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_847f92b5 ON mbstatsuser USING btree (userid);


--
-- Name: ix_84ab0309; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE UNIQUE INDEX ix_84ab0309 ON journalarticleresource USING btree (uuid_, groupid);


--
-- Name: ix_85c52eec; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE UNIQUE INDEX ix_85c52eec ON journalarticle USING btree (groupid, articleid, version);


--
-- Name: ix_8654719f; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_8654719f ON assetcategoryproperty USING btree (companyid);


--
-- Name: ix_871412df; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_871412df ON usergrouprole USING btree (groupid, roleid);


--
-- Name: ix_8831e4fc; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_8831e4fc ON journalstructure USING btree (structureid);


--
-- Name: ix_887a2c95; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_887a2c95 ON usergrouprole USING btree (roleid);


--
-- Name: ix_887be56a; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_887be56a ON usergrouprole USING btree (userid);


--
-- Name: ix_88df994a; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE UNIQUE INDEX ix_88df994a ON journalarticleresource USING btree (groupid, articleid);


--
-- Name: ix_89509087; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_89509087 ON user_ USING btree (companyid, openid);


--
-- Name: ix_8956b2c4; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_8956b2c4 ON igimage USING btree (groupid, folderid);


--
-- Name: ix_899d3dfb; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE UNIQUE INDEX ix_899d3dfb ON wikipage USING btree (uuid_, groupid);


--
-- Name: ix_8a1cc4b; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_8a1cc4b ON membershiprequest USING btree (groupid);


--
-- Name: ix_8abc4e3b; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE UNIQUE INDEX ix_8abc4e3b ON mbban USING btree (groupid, banuserid);


--
-- Name: ix_8ae58a91; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_8ae58a91 ON users_permissions USING btree (permissionid);


--
-- Name: ix_8bd6bca7; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_8bd6bca7 ON release_ USING btree (servletcontextname);


--
-- Name: ix_8cace77b; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_8cace77b ON blogsentry USING btree (companyid, userid);


--
-- Name: ix_8d12316e; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE UNIQUE INDEX ix_8d12316e ON mbmessage USING btree (uuid_, groupid);


--
-- Name: ix_8d83d0ce; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE UNIQUE INDEX ix_8d83d0ce ON resourcepermission USING btree (companyid, name, scope, primkey, roleid);


--
-- Name: ix_8deae14e; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_8deae14e ON journalarticle USING btree (groupid, templateid);


--
-- Name: ix_8e71167f; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_8e71167f ON portletitem USING btree (groupid, portletid, classnameid, name);


--
-- Name: ix_8eb8c5ec; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_8eb8c5ec ON mbmessage USING btree (groupid, userid);


--
-- Name: ix_8f32dec9; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE UNIQUE INDEX ix_8f32dec9 ON socialactivity USING btree (groupid, userid, createdate, classnameid, classpk, type_, receiveruserid);


--
-- Name: ix_8f542794; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_8f542794 ON assetlink USING btree (entryid1, entryid2, type_);


--
-- Name: ix_902fd874; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE UNIQUE INDEX ix_902fd874 ON dlfolder USING btree (groupid, parentfolderid, name);


--
-- Name: ix_903c1b28; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE UNIQUE INDEX ix_903c1b28 ON socialequitysetting USING btree (groupid, classnameid, actionid, type_);


--
-- Name: ix_903dc750; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_903dc750 ON shoppingitem USING btree (largeimageid);


--
-- Name: ix_90cda39a; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_90cda39a ON blogsstatsuser USING btree (companyid, entrycount);


--
-- Name: ix_9112a7a0; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_9112a7a0 ON expandovalue USING btree (rowid_);


--
-- Name: ix_9168e2c9; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE UNIQUE INDEX ix_9168e2c9 ON mbstatsuser USING btree (groupid, userid);


--
-- Name: ix_9178fc71; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_9178fc71 ON layoutsetprototype USING btree (companyid, active_);


--
-- Name: ix_91f132c; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_91f132c ON assetlink USING btree (entryid2, type_);


--
-- Name: ix_9207cb31; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_9207cb31 ON journalcontentsearch USING btree (articleid);


--
-- Name: ix_920cd8b1; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE UNIQUE INDEX ix_920cd8b1 ON wikinode USING btree (groupid, name);


--
-- Name: ix_9226dbb4; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_9226dbb4 ON address USING btree (companyid, classnameid, classpk, primary_);


--
-- Name: ix_923bd178; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_923bd178 ON address USING btree (companyid, classnameid, classpk, mailing);


--
-- Name: ix_9356f865; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_9356f865 ON journalarticle USING btree (groupid);


--
-- Name: ix_93cf8193; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_93cf8193 ON dlfileentry USING btree (groupid, folderid);


--
-- Name: ix_93d5ad4e; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_93d5ad4e ON address USING btree (companyid);


--
-- Name: ix_941ba8c3; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_941ba8c3 ON shard USING btree (name);


--
-- Name: ix_945e27c7; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_945e27c7 ON socialequityuser USING btree (groupid, rank);


--
-- Name: ix_9464ca; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_9464ca ON assettagstats USING btree (tagid);


--
-- Name: ix_94d1054d; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_94d1054d ON wikipage USING btree (resourceprimkey, nodeid, status);


--
-- Name: ix_94e784d2; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_94e784d2 ON dlfileversion USING btree (groupid, folderid, name, status);


--
-- Name: ix_95135d1c; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_95135d1c ON socialrelation USING btree (companyid, type_);


--
-- Name: ix_95c0ea45; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_95c0ea45 ON mbthread USING btree (groupid);


--
-- Name: ix_967799c0; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_967799c0 ON bookmarksfolder USING btree (groupid, parentfolderid);


--
-- Name: ix_96bdd537; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_96bdd537 ON portletitem USING btree (groupid, classnameid);


--
-- Name: ix_96f07007; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_96f07007 ON website USING btree (companyid);


--
-- Name: ix_975996c0; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE UNIQUE INDEX ix_975996c0 ON company USING btree (virtualhost);


--
-- Name: ix_9782ad88; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE UNIQUE INDEX ix_9782ad88 ON user_ USING btree (companyid, userid);


--
-- Name: ix_97dfa146; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE UNIQUE INDEX ix_97dfa146 ON webdavprops USING btree (classnameid, classpk);


--
-- Name: ix_98e6a9cb; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_98e6a9cb ON scproductentry USING btree (groupid, userid);


--
-- Name: ix_9955efb5; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_9955efb5 ON quartz_triggers USING btree (trigger_state);


--
-- Name: ix_997eedd2; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_997eedd2 ON wikipage USING btree (nodeid, title);


--
-- Name: ix_99da856; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_99da856 ON assetcategoryproperty USING btree (categoryid);


--
-- Name: ix_9a2d11b2; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_9a2d11b2 ON mbthread USING btree (groupid, categoryid);


--
-- Name: ix_9a53569; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_9a53569 ON phone USING btree (companyid, classnameid, classpk);


--
-- Name: ix_9bbafb1e; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE UNIQUE INDEX ix_9bbafb1e ON igfolder USING btree (groupid, parentfolderid, name);


--
-- Name: ix_9c0e478f; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_9c0e478f ON wikipage USING btree (uuid_);


--
-- Name: ix_9c7eb9f; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_9c7eb9f ON announcementsflag USING btree (entryid);


--
-- Name: ix_9dc8e57; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_9dc8e57 ON mbmessage USING btree (threadid, status);


--
-- Name: ix_9ddd15ea; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_9ddd15ea ON assetcategory USING btree (parentcategoryid, name);


--
-- Name: ix_9ddd21e5; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE UNIQUE INDEX ix_9ddd21e5 ON expandovalue USING btree (columnid, rowid_);


--
-- Name: ix_9f704a14; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_9f704a14 ON phone USING btree (companyid);


--
-- Name: ix_9f7655da; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_9f7655da ON wikipage USING btree (nodeid, head, parenttitle, status);


--
-- Name: ix_9ff342ea; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_9ff342ea ON pollsquestion USING btree (groupid);


--
-- Name: ix_a00a898f; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_a00a898f ON mbstatsuser USING btree (groupid);


--
-- Name: ix_a098efbf; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_a098efbf ON users_teams USING btree (userid);


--
-- Name: ix_a18034a4; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_a18034a4 ON user_ USING btree (portraitid);


--
-- Name: ix_a188f560; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_a188f560 ON assetentries_assetcategories USING btree (categoryid);


--
-- Name: ix_a2001730; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_a2001730 ON wikipage USING btree (format);


--
-- Name: ix_a2e4afba; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_a2e4afba ON phone USING btree (companyid, classnameid);


--
-- Name: ix_a32c097e; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE UNIQUE INDEX ix_a32c097e ON resourcecode USING btree (companyid, name, scope);


--
-- Name: ix_a37a0588; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_a37a0588 ON resourcepermission USING btree (roleid);


--
-- Name: ix_a40b8bec; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_a40b8bec ON layoutset USING btree (groupid);


--
-- Name: ix_a425f71a; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_a425f71a ON orggrouppermission USING btree (groupid);


--
-- Name: ix_a4db1f0f; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_a4db1f0f ON workflowdefinitionlink USING btree (companyid, workflowdefinitionname, workflowdefinitionversion);


--
-- Name: ix_a5f57b61; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_a5f57b61 ON blogsentry USING btree (companyid, userid, status);


--
-- Name: ix_a6973a8e; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_a6973a8e ON mbmessageflag USING btree (messageid, flag);


--
-- Name: ix_a6e99284; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE UNIQUE INDEX ix_a6e99284 ON ratingsstats USING btree (classnameid, classpk);


--
-- Name: ix_a6ef0b81; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_a6ef0b81 ON announcementsentry USING btree (classnameid, classpk);


--
-- Name: ix_a7038cd7; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_a7038cd7 ON mbmessage USING btree (threadid, parentmessageid);


--
-- Name: ix_a74db14c; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_a74db14c ON dlfolder USING btree (companyid);


--
-- Name: ix_a853c757; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_a853c757 ON socialactivity USING btree (classnameid, classpk);


--
-- Name: ix_a88e424e; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE UNIQUE INDEX ix_a88e424e ON role_ USING btree (companyid, classnameid, classpk);


--
-- Name: ix_a8b0d276; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_a8b0d276 ON workflowdefinitionlink USING btree (companyid);


--
-- Name: ix_a8c0cbe8; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_a8c0cbe8 ON expandocolumn USING btree (tableid);


--
-- Name: ix_a90fe5a0; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_a90fe5a0 ON socialrequest USING btree (companyid);


--
-- Name: ix_aacaff40; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_aacaff40 ON resourcecode USING btree (name);


--
-- Name: ix_aae8df83; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_aae8df83 ON igimage USING btree (groupid, folderid, name);


--
-- Name: ix_ab044d1c; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_ab044d1c ON orggrouprole USING btree (roleid);


--
-- Name: ix_ab5906a8; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_ab5906a8 ON socialrequest USING btree (userid, status);


--
-- Name: ix_ab6e9996; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE UNIQUE INDEX ix_ab6e9996 ON journalstructure USING btree (groupid, structureid);


--
-- Name: ix_aba5cec2; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_aba5cec2 ON group_ USING btree (companyid);


--
-- Name: ix_abd7dac0; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_abd7dac0 ON address USING btree (companyid, classnameid);


--
-- Name: ix_adee6a17; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_adee6a17 ON quartz_fired_triggers USING btree (job_name);


--
-- Name: ix_ae6e9907; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_ae6e9907 ON team USING btree (groupid);


--
-- Name: ix_ae8224cc; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_ae8224cc ON scproductscreenshot USING btree (fullimageid);


--
-- Name: ix_b0051937; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_b0051937 ON dlfileshortcut USING btree (groupid, folderid);


--
-- Name: ix_b10efd68; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE UNIQUE INDEX ix_b10efd68 ON igfolder USING btree (uuid_, groupid);


--
-- Name: ix_b1432d30; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_b1432d30 ON mbmessage USING btree (companyid);


--
-- Name: ix_b185e980; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_b185e980 ON assetcategory USING btree (parentcategoryid, vocabularyid);


--
-- Name: ix_b22d908c; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_b22d908c ON assetvocabulary USING btree (companyid);


--
-- Name: ix_b2468446; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_b2468446 ON ticket USING btree (key_);


--
-- Name: ix_b27a301f; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE UNIQUE INDEX ix_b27a301f ON classname_ USING btree (value);


--
-- Name: ix_b29fef17; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_b29fef17 ON expandovalue USING btree (classnameid, classpk);


--
-- Name: ix_b2a61b55; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_b2a61b55 ON assetentries_assettags USING btree (tagid);


--
-- Name: ix_b3b318dc; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_b3b318dc ON journalcontentsearch USING btree (groupid, privatelayout, layoutid);


--
-- Name: ix_b413f1ec; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_b413f1ec ON dlfileversion USING btree (groupid, folderid, name);


--
-- Name: ix_b47e3c11; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE UNIQUE INDEX ix_b47e3c11 ON ratingsentry USING btree (userid, classnameid, classpk);


--
-- Name: ix_b480a672; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_b480a672 ON wikinode USING btree (groupid);


--
-- Name: ix_b5ae8a85; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_b5ae8a85 ON expandotable USING btree (companyid, classnameid);


--
-- Name: ix_b5ca2dc; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE UNIQUE INDEX ix_b5ca2dc ON mbdiscussion USING btree (threadid);


--
-- Name: ix_b5f82c7a; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_b5f82c7a ON shoppingorderitem USING btree (orderid);


--
-- Name: ix_b670ba39; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_b670ba39 ON bookmarksentry USING btree (uuid_);


--
-- Name: ix_b674ab58; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_b674ab58 ON mbmessage USING btree (groupid, categoryid, threadid);


--
-- Name: ix_b6b8ca0e; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_b6b8ca0e ON assetvocabulary USING btree (groupid);


--
-- Name: ix_b6ee8c9e; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_b6ee8c9e ON workflowdefinitionlink USING btree (groupid, companyid, classnameid);


--
-- Name: ix_b71e92d5; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_b71e92d5 ON expandovalue USING btree (tableid, rowid_);


--
-- Name: ix_b771d67; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_b771d67 ON wikipage USING btree (resourceprimkey, nodeid);


--
-- Name: ix_b9746445; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_b9746445 ON pluginsetting USING btree (companyid);


--
-- Name: ix_b97f5608; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_b97f5608 ON journalstructure USING btree (groupid);


--
-- Name: ix_ba4413d5; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE UNIQUE INDEX ix_ba4413d5 ON announcementsdelivery USING btree (userid, type_);


--
-- Name: ix_bab9a1f7; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_bab9a1f7 ON quartz_fired_triggers USING btree (job_group);


--
-- Name: ix_bafb116e; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_bafb116e ON dlfilerank USING btree (groupid, userid);


--
-- Name: ix_bb0c2905; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_bb0c2905 ON blogsentry USING btree (companyid, displaydate, status);


--
-- Name: ix_bb51f1d9; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_bb51f1d9 ON blogsstatsuser USING btree (userid);


--
-- Name: ix_bb870c11; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_bb870c11 ON mbcategory USING btree (groupid);


--
-- Name: ix_bbca55b; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE UNIQUE INDEX ix_bbca55b ON group_ USING btree (companyid, livegroupid, name);


--
-- Name: ix_bc2c4231; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE UNIQUE INDEX ix_bc2c4231 ON layout USING btree (groupid, privatelayout, friendlyurl);


--
-- Name: ix_bc2e7e6a; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE UNIQUE INDEX ix_bc2e7e6a ON dlfileentry USING btree (uuid_, groupid);


--
-- Name: ix_bc735dcf; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_bc735dcf ON mbcategory USING btree (companyid);


--
-- Name: ix_be4df2bf; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE UNIQUE INDEX ix_be4df2bf ON assetcategory USING btree (parentcategoryid, name, vocabularyid);


--
-- Name: ix_be79e1e1; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_be79e1e1 ON igimage USING btree (groupid, userid);


--
-- Name: ix_be8102d6; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_be8102d6 ON users_usergroups USING btree (userid);


--
-- Name: ix_be898221; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_be898221 ON wikipageresource USING btree (uuid_);


--
-- Name: ix_bea33ab8; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_bea33ab8 ON wikipage USING btree (nodeid, title, status);


--
-- Name: ix_bfeb984f; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_bfeb984f ON mbmailinglist USING btree (active_);


--
-- Name: ix_c099d61a; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_c099d61a ON layout USING btree (groupid);


--
-- Name: ix_c0aad74d; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE UNIQUE INDEX ix_c0aad74d ON assetvocabulary USING btree (groupid, name);


--
-- Name: ix_c19e5f31; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_c19e5f31 ON users_roles USING btree (roleid);


--
-- Name: ix_c1a01806; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_c1a01806 ON users_roles USING btree (userid);


--
-- Name: ix_c1ad2122; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_c1ad2122 ON calevent USING btree (uuid_);


--
-- Name: ix_c1c9a8fd; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_c1c9a8fd ON mbmessageflag USING btree (threadid);


--
-- Name: ix_c2626edb; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_c2626edb ON mbcategory USING btree (uuid_);


--
-- Name: ix_c26aa64d; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_c26aa64d ON users_permissions USING btree (userid);


--
-- Name: ix_c28b41dc; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_c28b41dc ON shoppingcart USING btree (groupid);


--
-- Name: ix_c28c72ec; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_c28c72ec ON membershiprequest USING btree (groupid, statusid);


--
-- Name: ix_c31a64c6; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_c31a64c6 ON socialrelation USING btree (type_);


--
-- Name: ix_c3a17327; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_c3a17327 ON passwordpolicyrel USING btree (classnameid, classpk);


--
-- Name: ix_c3aa93b8; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE UNIQUE INDEX ix_c3aa93b8 ON journalcontentsearch USING btree (groupid, privatelayout, layoutid, portletid, articleid);


--
-- Name: ix_c48736b; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_c48736b ON groups_permissions USING btree (groupid);


--
-- Name: ix_c4f9e699; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_c4f9e699 ON users_groups USING btree (groupid);


--
-- Name: ix_c57b16bc; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_c57b16bc ON mbmessage USING btree (uuid_);


--
-- Name: ix_c5806019; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE UNIQUE INDEX ix_c5806019 ON user_ USING btree (companyid, screenname);


--
-- Name: ix_c7057ff7; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE UNIQUE INDEX ix_c7057ff7 ON portletpreferences USING btree (ownerid, ownertype, plid, portletid);


--
-- Name: ix_c7fbc998; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_c7fbc998 ON layout USING btree (companyid);


--
-- Name: ix_c8a9c476; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_c8a9c476 ON wikipage USING btree (nodeid);


--
-- Name: ix_c98c0d78; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_c98c0d78 ON scframeworkversion USING btree (companyid);


--
-- Name: ix_ca0bd48c; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_ca0bd48c ON journalstructure USING btree (groupid, parentstructureid);


--
-- Name: ix_ca9afb7c; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_ca9afb7c ON expandovalue USING btree (tableid, columnid);


--
-- Name: ix_cab0ccc8; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_cab0ccc8 ON usergroupgrouprole USING btree (groupid, roleid);


--
-- Name: ix_cbc408d8; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_cbc408d8 ON dlfolder USING btree (uuid_);


--
-- Name: ix_cbe204; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_cbe204 ON role_ USING btree (type_, subtype);


--
-- Name: ix_cc86a444; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_cc86a444 ON socialrequest USING btree (userid, classnameid, classpk, type_, status);


--
-- Name: ix_ccbe4063; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_ccbe4063 ON usergroupgrouprole USING btree (groupid);


--
-- Name: ix_cd25266e; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_cd25266e ON passwordpolicyrel USING btree (passwordpolicyid);


--
-- Name: ix_ce705d48; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE UNIQUE INDEX ix_ce705d48 ON dlfilerank USING btree (companyid, userid, folderid, name);


--
-- Name: ix_ced31606; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE UNIQUE INDEX ix_ced31606 ON layout USING btree (uuid_, groupid);


--
-- Name: ix_d0822724; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_d0822724 ON layout USING btree (uuid_);


--
-- Name: ix_d0d5e397; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE UNIQUE INDEX ix_d0d5e397 ON group_ USING btree (companyid, classnameid, classpk);


--
-- Name: ix_d180d4ae; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_d180d4ae ON mbmessageflag USING btree (messageid);


--
-- Name: ix_d1c44a6e; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE UNIQUE INDEX ix_d1c44a6e ON useridmapper USING btree (userid, type_);


--
-- Name: ix_d20c434d; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_d20c434d ON dlfileentry USING btree (groupid, userid, folderid);


--
-- Name: ix_d217ab30; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_d217ab30 ON shoppingitem USING btree (mediumimageid);


--
-- Name: ix_d27b03e7; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE UNIQUE INDEX ix_d27b03e7 ON expandovalue USING btree (tableid, columnid, classpk);


--
-- Name: ix_d2d249e8; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_d2d249e8 ON journalarticle USING btree (groupid, urltitle, status);


--
-- Name: ix_d340db76; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_d340db76 ON portletpreferences USING btree (plid, portletid);


--
-- Name: ix_d3425487; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_d3425487 ON socialrequest USING btree (classnameid, classpk, type_, receiveruserid, status);


--
-- Name: ix_d3d32126; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_d3d32126 ON igimage USING btree (smallimageid);


--
-- Name: ix_d3f5d7ae; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_d3f5d7ae ON expandorow USING btree (tableid);


--
-- Name: ix_d4121315; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_d4121315 ON journalarticleimage USING btree (tempimage);


--
-- Name: ix_d49c2e66; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_d49c2e66 ON announcementsentry USING btree (userid);


--
-- Name: ix_d5df7b54; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_d5df7b54 ON pollsvote USING btree (choiceid);


--
-- Name: ix_d61abe08; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_d61abe08 ON assetcategory USING btree (name, vocabularyid);


--
-- Name: ix_d65d3521; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE UNIQUE INDEX ix_d65d3521 ON socialequityuser USING btree (groupid, userid);


--
-- Name: ix_d699243f; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_d699243f ON portletitem USING btree (groupid, name, portletid, classnameid);


--
-- Name: ix_d6fd9496; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_d6fd9496 ON calevent USING btree (companyid);


--
-- Name: ix_d76dd2cf; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE UNIQUE INDEX ix_d76dd2cf ON pollschoice USING btree (questionid, name);


--
-- Name: ix_d7710a66; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_d7710a66 ON sclicenses_scproductentries USING btree (productentryid);


--
-- Name: ix_d7d6e87a; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE UNIQUE INDEX ix_d7d6e87a ON shoppingorder USING btree (number_);


--
-- Name: ix_d9380cb7; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_d9380cb7 ON socialrequest USING btree (receiveruserid, status);


--
-- Name: ix_d9e0a34c; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_d9e0a34c ON igimage USING btree (custom2imageid);


--
-- Name: ix_da04f689; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_da04f689 ON blogsentry USING btree (groupid, userid, displaydate, status);


--
-- Name: ix_da5f4359; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_da5f4359 ON shard USING btree (classnameid, classpk);


--
-- Name: ix_da913a55; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_da913a55 ON scproductscreenshot USING btree (productentryid, priority);


--
-- Name: ix_db6958d2; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_db6958d2 ON socialequitylog USING btree (assetentryid, actionid, actiondate, active_, type_);


--
-- Name: ix_db780a20; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE UNIQUE INDEX ix_db780a20 ON blogsentry USING btree (groupid, urltitle);


--
-- Name: ix_dbd111aa; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE UNIQUE INDEX ix_dbd111aa ON assetcategoryproperty USING btree (categoryid, key_);


--
-- Name: ix_dc2f8927; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE UNIQUE INDEX ix_dc2f8927 ON bookmarksfolder USING btree (uuid_, groupid);


--
-- Name: ix_dc60cfae; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE UNIQUE INDEX ix_dc60cfae ON shoppingcoupon USING btree (code_);


--
-- Name: ix_dcd1fac1; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_dcd1fac1 ON journalarticleresource USING btree (uuid_);


--
-- Name: ix_dcded558; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_dcded558 ON usergroupgrouprole USING btree (usergroupid);


--
-- Name: ix_dff1f063; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_dff1f063 ON assettagproperty USING btree (companyid);


--
-- Name: ix_dff98523; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_dff98523 ON journalarticle USING btree (companyid);


--
-- Name: ix_e0422bda; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_e0422bda ON user_ USING btree (uuid_);


--
-- Name: ix_e04e486d; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_e04e486d ON roles_permissions USING btree (roleid);


--
-- Name: ix_e119938a; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_e119938a ON assetentries_assetcategories USING btree (entryid);


--
-- Name: ix_e1e7142b; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_e1e7142b ON mbthread USING btree (groupid, status);


--
-- Name: ix_e2e9f129; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_e2e9f129 ON bookmarksentry USING btree (groupid, userid);


--
-- Name: ix_e301bdf5; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE UNIQUE INDEX ix_e301bdf5 ON organization_ USING btree (companyid, name);


--
-- Name: ix_e3f1286b; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_e3f1286b ON lock_ USING btree (expirationdate);


--
-- Name: ix_e4efba8d; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_e4efba8d ON usertracker USING btree (userid);


--
-- Name: ix_e4f13e6e; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_e4f13e6e ON portletpreferences USING btree (ownerid, ownertype, plid);


--
-- Name: ix_e4f84168; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE UNIQUE INDEX ix_e4f84168 ON socialequitygroupsetting USING btree (groupid, classnameid, type_);


--
-- Name: ix_e52ff7ef; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_e52ff7ef ON bookmarksentry USING btree (groupid);


--
-- Name: ix_e597322d; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_e597322d ON igimage USING btree (custom1imageid);


--
-- Name: ix_e60ea987; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_e60ea987 ON useridmapper USING btree (userid);


--
-- Name: ix_e639e2f6; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_e639e2f6 ON assetcategory USING btree (groupid);


--
-- Name: ix_e745ea26; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_e745ea26 ON wikipage USING btree (nodeid, title, head);


--
-- Name: ix_e7b95510; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE UNIQUE INDEX ix_e7b95510 ON browsertracker USING btree (userid);


--
-- Name: ix_e7f635ca; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_e7f635ca ON wikipage USING btree (nodeid, head);


--
-- Name: ix_e802aa3c; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE UNIQUE INDEX ix_e802aa3c ON journaltemplate USING btree (groupid, templateid);


--
-- Name: ix_e858f170; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE UNIQUE INDEX ix_e858f170 ON mbmailinglist USING btree (uuid_, groupid);


--
-- Name: ix_e8d019aa; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE UNIQUE INDEX ix_e8d019aa ON assetcategory USING btree (uuid_, groupid);


--
-- Name: ix_e8d33ff9; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_e8d33ff9 ON scframeworkversi_scproductvers USING btree (productversionid);


--
-- Name: ix_e8da181d; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_e8da181d ON socialequitylog USING btree (assetentryid, type_, active_);


--
-- Name: ix_e8f34171; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_e8f34171 ON subscription USING btree (userid, classnameid);


--
-- Name: ix_e922d6c0; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_e922d6c0 ON portletitem USING btree (groupid, portletid, classnameid);


--
-- Name: ix_e97342d9; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE UNIQUE INDEX ix_e97342d9 ON igimage USING btree (uuid_, groupid);


--
-- Name: ix_e9eb6194; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE UNIQUE INDEX ix_e9eb6194 ON mbmessageflag USING btree (userid, messageid, flag);


--
-- Name: ix_ea6fd516; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_ea6fd516 ON shoppingitemprice USING btree (itemid);


--
-- Name: ix_eaa02a91; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE UNIQUE INDEX ix_eaa02a91 ON bookmarksentry USING btree (uuid_, groupid);


--
-- Name: ix_eb2dce27; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_eb2dce27 ON blogsentry USING btree (companyid, status);


--
-- Name: ix_ebc931b8; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE UNIQUE INDEX ix_ebc931b8 ON role_ USING btree (companyid, name);


--
-- Name: ix_ec00543c; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE UNIQUE INDEX ix_ec00543c ON company USING btree (webid);


--
-- Name: ix_ec370f10; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_ec370f10 ON pollschoice USING btree (questionid);


--
-- Name: ix_ec97689d; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_ec97689d ON groups_permissions USING btree (permissionid);


--
-- Name: ix_ecce311d; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_ecce311d ON dlfileshortcut USING btree (groupid, folderid, status);


--
-- Name: ix_ed292508; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_ed292508 ON mbcategory USING btree (groupid, parentcategoryid);


--
-- Name: ix_ed39ac98; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_ed39ac98 ON mbmessage USING btree (groupid, status);


--
-- Name: ix_ed5ca615; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE UNIQUE INDEX ix_ed5ca615 ON dlfileentry USING btree (groupid, folderid, title);


--
-- Name: ix_ed7cf243; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_ed7cf243 ON passwordpolicyrel USING btree (passwordpolicyid, classnameid, classpk);


--
-- Name: ix_edb9986e; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE UNIQUE INDEX ix_edb9986e ON resourceaction USING btree (name, actionid);


--
-- Name: ix_eed06670; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_eed06670 ON dlfilerank USING btree (userid);


--
-- Name: ix_ef9b7028; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_ef9b7028 ON journalarticle USING btree (smallimageid);


--
-- Name: ix_f029602f; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_f029602f ON journalarticle USING btree (uuid_);


--
-- Name: ix_f0566a77; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_f0566a77 ON expandovalue USING btree (tableid);


--
-- Name: ix_f090c113; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_f090c113 ON permission_ USING btree (resourceid);


--
-- Name: ix_f0ca24a5; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_f0ca24a5 ON socialrelation USING btree (uuid_);


--
-- Name: ix_f0e73383; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_f0e73383 ON blogsentry USING btree (groupid, displaydate, status);


--
-- Name: ix_f10b6c6b; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_f10b6c6b ON users_groups USING btree (userid);


--
-- Name: ix_f15c1c4f; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_f15c1c4f ON portletpreferences USING btree (plid);


--
-- Name: ix_f202b9ce; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_f202b9ce ON phone USING btree (userid);


--
-- Name: ix_f2ea1ace; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_f2ea1ace ON dlfolder USING btree (groupid);


--
-- Name: ix_f3aad60d; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_f3aad60d ON socialequitysetting USING btree (groupid, classnameid, actionid);


--
-- Name: ix_f3c9f36; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE UNIQUE INDEX ix_f3c9f36 ON pollsquestion USING btree (uuid_, groupid);


--
-- Name: ix_f474fd89; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_f474fd89 ON shoppingorder USING btree (pptxnid);


--
-- Name: ix_f4af5636; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_f4af5636 ON dlfileentry USING btree (groupid);


--
-- Name: ix_f6006202; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_f6006202 ON calevent USING btree (remindby);


--
-- Name: ix_f6687633; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_f6687633 ON mbmessage USING btree (classnameid, classpk, status);


--
-- Name: ix_f73c0982; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_f73c0982 ON igfolder USING btree (uuid_);


--
-- Name: ix_f75690bb; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_f75690bb ON website USING btree (userid);


--
-- Name: ix_f7655cc3; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_f7655cc3 ON quartz_triggers USING btree (next_fire_time);


--
-- Name: ix_f7d28c2f; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE UNIQUE INDEX ix_f7d28c2f ON mbcategory USING btree (uuid_, groupid);


--
-- Name: ix_f7dd0987; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_f7dd0987 ON expandovalue USING btree (columnid);


--
-- Name: ix_f8433677; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_f8433677 ON journalarticleresource USING btree (groupid);


--
-- Name: ix_f960131c; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_f960131c ON website USING btree (companyid, classnameid, classpk);


--
-- Name: ix_fab5a88b; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_fab5a88b ON mbstatsuser USING btree (groupid, messagecount);


--
-- Name: ix_fad05595; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_fad05595 ON layout USING btree (dlfolderid);


--
-- Name: ix_fb646ca6; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_fb646ca6 ON users_orgs USING btree (userid);


--
-- Name: ix_fbbe7c96; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_fbbe7c96 ON wikipage USING btree (userid, nodeid, status);


--
-- Name: ix_fbde0aa3; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_fbde0aa3 ON blogsentry USING btree (groupid, userid, displaydate);


--
-- Name: ix_fc1f9c7b; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_fc1f9c7b ON assetentry USING btree (classuuid);


--
-- Name: ix_fc46fe16; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE UNIQUE INDEX ix_fc46fe16 ON shoppingcart USING btree (groupid, userid);


--
-- Name: ix_fcd7c63d; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_fcd7c63d ON calevent USING btree (groupid, type_);


--
-- Name: ix_fdb4a946; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE UNIQUE INDEX ix_fdb4a946 ON dlfileshortcut USING btree (uuid_, groupid);


--
-- Name: ix_feb4055a; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_feb4055a ON socialequitylog USING btree (assetentryid, actionid, active_, type_);


--
-- Name: ix_fefc8da7; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE UNIQUE INDEX ix_fefc8da7 ON expandocolumn USING btree (tableid, name);


--
-- Name: ix_fefe7d76; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_fefe7d76 ON shoppingitem USING btree (groupid, categoryid);


--
-- Name: ix_ff203304; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ix_ff203304 ON shoppingitem USING btree (smallimageid);


--
-- Name: public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

