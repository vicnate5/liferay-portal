--
-- PostgreSQL database dump
--

SET statement_timeout = 0;
SET lock_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;

--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: account_; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE account_ (
    accountid bigint NOT NULL,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    parentaccountid bigint,
    name character varying(75),
    legalname character varying(75),
    legalid character varying(75),
    legaltype character varying(75),
    siccode character varying(75),
    tickersymbol character varying(75),
    industry character varying(75),
    type_ character varying(75),
    size_ character varying(75)
);


ALTER TABLE account_ OWNER TO root;

--
-- Name: address; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE address (
    addressid bigint NOT NULL,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    classnameid bigint,
    classpk bigint,
    street1 character varying(75),
    street2 character varying(75),
    street3 character varying(75),
    city character varying(75),
    zip character varying(75),
    regionid bigint,
    countryid bigint,
    typeid integer,
    mailing boolean,
    primary_ boolean
);


ALTER TABLE address OWNER TO root;

--
-- Name: announcementsdelivery; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE announcementsdelivery (
    deliveryid bigint NOT NULL,
    companyid bigint,
    userid bigint,
    type_ character varying(75),
    email boolean,
    sms boolean,
    website boolean
);


ALTER TABLE announcementsdelivery OWNER TO root;

--
-- Name: announcementsentry; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE announcementsentry (
    uuid_ character varying(75),
    entryid bigint NOT NULL,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    classnameid bigint,
    classpk bigint,
    title character varying(75),
    content text,
    url text,
    type_ character varying(75),
    displaydate timestamp without time zone,
    expirationdate timestamp without time zone,
    priority integer,
    alert boolean
);


ALTER TABLE announcementsentry OWNER TO root;

--
-- Name: announcementsflag; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE announcementsflag (
    flagid bigint NOT NULL,
    userid bigint,
    createdate timestamp without time zone,
    entryid bigint,
    value integer
);


ALTER TABLE announcementsflag OWNER TO root;

--
-- Name: assetcategory; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE assetcategory (
    uuid_ character varying(75),
    categoryid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    parentcategoryid bigint,
    leftcategoryid bigint,
    rightcategoryid bigint,
    name character varying(75),
    title text,
    description text,
    vocabularyid bigint
);


ALTER TABLE assetcategory OWNER TO root;

--
-- Name: assetcategoryproperty; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE assetcategoryproperty (
    categorypropertyid bigint NOT NULL,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    categoryid bigint,
    key_ character varying(75),
    value character varying(75)
);


ALTER TABLE assetcategoryproperty OWNER TO root;

--
-- Name: assetentries_assetcategories; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE assetentries_assetcategories (
    categoryid bigint NOT NULL,
    entryid bigint NOT NULL
);


ALTER TABLE assetentries_assetcategories OWNER TO root;

--
-- Name: assetentries_assettags; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE assetentries_assettags (
    entryid bigint NOT NULL,
    tagid bigint NOT NULL
);


ALTER TABLE assetentries_assettags OWNER TO root;

--
-- Name: assetentry; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE assetentry (
    entryid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    classnameid bigint,
    classpk bigint,
    classuuid character varying(75),
    classtypeid bigint,
    visible boolean,
    startdate timestamp without time zone,
    enddate timestamp without time zone,
    publishdate timestamp without time zone,
    expirationdate timestamp without time zone,
    mimetype character varying(75),
    title text,
    description text,
    summary text,
    url text,
    layoutuuid character varying(75),
    height integer,
    width integer,
    priority double precision,
    viewcount integer
);


ALTER TABLE assetentry OWNER TO root;

--
-- Name: assetlink; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE assetlink (
    linkid bigint NOT NULL,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    entryid1 bigint,
    entryid2 bigint,
    type_ integer,
    weight integer
);


ALTER TABLE assetlink OWNER TO root;

--
-- Name: assettag; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE assettag (
    tagid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    name character varying(75),
    assetcount integer
);


ALTER TABLE assettag OWNER TO root;

--
-- Name: assettagproperty; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE assettagproperty (
    tagpropertyid bigint NOT NULL,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    tagid bigint,
    key_ character varying(75),
    value character varying(255)
);


ALTER TABLE assettagproperty OWNER TO root;

--
-- Name: assettagstats; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE assettagstats (
    tagstatsid bigint NOT NULL,
    tagid bigint,
    classnameid bigint,
    assetcount integer
);


ALTER TABLE assettagstats OWNER TO root;

--
-- Name: assetvocabulary; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE assetvocabulary (
    uuid_ character varying(75),
    vocabularyid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    name character varying(75),
    title text,
    description text,
    settings_ text
);


ALTER TABLE assetvocabulary OWNER TO root;

--
-- Name: blogsentry; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE blogsentry (
    uuid_ character varying(75),
    entryid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    title character varying(150),
    urltitle character varying(150),
    description character varying(75),
    content text,
    displaydate timestamp without time zone,
    allowpingbacks boolean,
    allowtrackbacks boolean,
    trackbacks text,
    smallimage boolean,
    smallimageid bigint,
    smallimageurl text,
    status integer,
    statusbyuserid bigint,
    statusbyusername character varying(75),
    statusdate timestamp without time zone
);


ALTER TABLE blogsentry OWNER TO root;

--
-- Name: blogsstatsuser; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE blogsstatsuser (
    statsuserid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    userid bigint,
    entrycount integer,
    lastpostdate timestamp without time zone,
    ratingstotalentries integer,
    ratingstotalscore double precision,
    ratingsaveragescore double precision
);


ALTER TABLE blogsstatsuser OWNER TO root;

--
-- Name: bookmarksentry; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE bookmarksentry (
    uuid_ character varying(75),
    entryid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    resourceblockid bigint,
    folderid bigint,
    name character varying(255),
    url text,
    description text,
    visits integer,
    priority integer
);


ALTER TABLE bookmarksentry OWNER TO root;

--
-- Name: bookmarksfolder; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE bookmarksfolder (
    uuid_ character varying(75),
    folderid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    resourceblockid bigint,
    parentfolderid bigint,
    name character varying(75),
    description text
);


ALTER TABLE bookmarksfolder OWNER TO root;

--
-- Name: browsertracker; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE browsertracker (
    browsertrackerid bigint NOT NULL,
    userid bigint,
    browserkey bigint
);


ALTER TABLE browsertracker OWNER TO root;

--
-- Name: calevent; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE calevent (
    uuid_ character varying(75),
    eventid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    title character varying(75),
    description text,
    location text,
    startdate timestamp without time zone,
    enddate timestamp without time zone,
    durationhour integer,
    durationminute integer,
    allday boolean,
    timezonesensitive boolean,
    type_ character varying(75),
    repeating boolean,
    recurrence text,
    remindby integer,
    firstreminder integer,
    secondreminder integer
);


ALTER TABLE calevent OWNER TO root;

--
-- Name: classname_; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE classname_ (
    classnameid bigint NOT NULL,
    value character varying(200)
);


ALTER TABLE classname_ OWNER TO root;

--
-- Name: clustergroup; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE clustergroup (
    clustergroupid bigint NOT NULL,
    name character varying(75),
    clusternodeids character varying(75),
    wholecluster boolean
);


ALTER TABLE clustergroup OWNER TO root;

--
-- Name: company; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE company (
    companyid bigint NOT NULL,
    accountid bigint,
    webid character varying(75),
    key_ text,
    mx character varying(75),
    homeurl text,
    logoid bigint,
    system boolean,
    maxusers integer,
    active_ boolean
);


ALTER TABLE company OWNER TO root;

--
-- Name: contact_; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE contact_ (
    contactid bigint NOT NULL,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    accountid bigint,
    parentcontactid bigint,
    firstname character varying(75),
    middlename character varying(75),
    lastname character varying(75),
    prefixid integer,
    suffixid integer,
    male boolean,
    birthday timestamp without time zone,
    smssn character varying(75),
    aimsn character varying(75),
    facebooksn character varying(75),
    icqsn character varying(75),
    jabbersn character varying(75),
    msnsn character varying(75),
    myspacesn character varying(75),
    skypesn character varying(75),
    twittersn character varying(75),
    ymsn character varying(75),
    employeestatusid character varying(75),
    employeenumber character varying(75),
    jobtitle character varying(100),
    jobclass character varying(75),
    hoursofoperation character varying(75)
);


ALTER TABLE contact_ OWNER TO root;

--
-- Name: counter; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE counter (
    name character varying(75) NOT NULL,
    currentid bigint
);


ALTER TABLE counter OWNER TO root;

--
-- Name: country; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE country (
    countryid bigint NOT NULL,
    name character varying(75),
    a2 character varying(75),
    a3 character varying(75),
    number_ character varying(75),
    idd_ character varying(75),
    ziprequired boolean,
    active_ boolean
);


ALTER TABLE country OWNER TO root;

--
-- Name: cyrususer; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE cyrususer (
    userid character varying(75) NOT NULL,
    password_ character varying(75) NOT NULL
);


ALTER TABLE cyrususer OWNER TO root;

--
-- Name: cyrusvirtual; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE cyrusvirtual (
    emailaddress character varying(75) NOT NULL,
    userid character varying(75) NOT NULL
);


ALTER TABLE cyrusvirtual OWNER TO root;

--
-- Name: ddlrecord; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE ddlrecord (
    uuid_ character varying(75),
    recordid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    userid bigint,
    username character varying(75),
    versionuserid bigint,
    versionusername character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    ddmstorageid bigint,
    recordsetid bigint,
    version character varying(75),
    displayindex integer
);


ALTER TABLE ddlrecord OWNER TO root;

--
-- Name: ddlrecordset; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE ddlrecordset (
    uuid_ character varying(75),
    recordsetid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    ddmstructureid bigint,
    recordsetkey character varying(75),
    name text,
    description text,
    mindisplayrows integer,
    scope integer
);


ALTER TABLE ddlrecordset OWNER TO root;

--
-- Name: ddlrecordversion; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE ddlrecordversion (
    recordversionid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    ddmstorageid bigint,
    recordsetid bigint,
    recordid bigint,
    version character varying(75),
    displayindex integer,
    status integer,
    statusbyuserid bigint,
    statusbyusername character varying(75),
    statusdate timestamp without time zone
);


ALTER TABLE ddlrecordversion OWNER TO root;

--
-- Name: ddmcontent; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE ddmcontent (
    uuid_ character varying(75),
    contentid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    name text,
    description text,
    xml text
);


ALTER TABLE ddmcontent OWNER TO root;

--
-- Name: ddmstoragelink; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE ddmstoragelink (
    uuid_ character varying(75),
    storagelinkid bigint NOT NULL,
    classnameid bigint,
    classpk bigint,
    structureid bigint
);


ALTER TABLE ddmstoragelink OWNER TO root;

--
-- Name: ddmstructure; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE ddmstructure (
    uuid_ character varying(75),
    structureid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    classnameid bigint,
    structurekey character varying(75),
    name text,
    description text,
    xsd text,
    storagetype character varying(75),
    type_ integer
);


ALTER TABLE ddmstructure OWNER TO root;

--
-- Name: ddmstructurelink; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE ddmstructurelink (
    structurelinkid bigint NOT NULL,
    classnameid bigint,
    classpk bigint,
    structureid bigint
);


ALTER TABLE ddmstructurelink OWNER TO root;

--
-- Name: ddmtemplate; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE ddmtemplate (
    uuid_ character varying(75),
    templateid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    structureid bigint,
    name text,
    description text,
    type_ character varying(75),
    mode_ character varying(75),
    language character varying(75),
    script text
);


ALTER TABLE ddmtemplate OWNER TO root;

--
-- Name: dlcontent; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE dlcontent (
    contentid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    repositoryid bigint,
    path_ character varying(255),
    version character varying(75),
    data_ oid,
    size_ bigint
);


ALTER TABLE dlcontent OWNER TO root;

--
-- Name: dlfileentry; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE dlfileentry (
    uuid_ character varying(75),
    fileentryid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    userid bigint,
    username character varying(75),
    versionuserid bigint,
    versionusername character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    repositoryid bigint,
    folderid bigint,
    name character varying(255),
    extension character varying(75),
    mimetype character varying(75),
    title character varying(255),
    description text,
    extrasettings text,
    fileentrytypeid bigint,
    version character varying(75),
    size_ bigint,
    readcount integer,
    smallimageid bigint,
    largeimageid bigint,
    custom1imageid bigint,
    custom2imageid bigint
);


ALTER TABLE dlfileentry OWNER TO root;

--
-- Name: dlfileentrymetadata; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE dlfileentrymetadata (
    uuid_ character varying(75),
    fileentrymetadataid bigint NOT NULL,
    ddmstorageid bigint,
    ddmstructureid bigint,
    fileentrytypeid bigint,
    fileentryid bigint,
    fileversionid bigint
);


ALTER TABLE dlfileentrymetadata OWNER TO root;

--
-- Name: dlfileentrytype; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE dlfileentrytype (
    uuid_ character varying(75),
    fileentrytypeid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    name character varying(75),
    description text
);


ALTER TABLE dlfileentrytype OWNER TO root;

--
-- Name: dlfileentrytypes_ddmstructures; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE dlfileentrytypes_ddmstructures (
    structureid bigint NOT NULL,
    fileentrytypeid bigint NOT NULL
);


ALTER TABLE dlfileentrytypes_ddmstructures OWNER TO root;

--
-- Name: dlfileentrytypes_dlfolders; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE dlfileentrytypes_dlfolders (
    fileentrytypeid bigint NOT NULL,
    folderid bigint NOT NULL
);


ALTER TABLE dlfileentrytypes_dlfolders OWNER TO root;

--
-- Name: dlfilerank; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE dlfilerank (
    filerankid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    userid bigint,
    createdate timestamp without time zone,
    fileentryid bigint
);


ALTER TABLE dlfilerank OWNER TO root;

--
-- Name: dlfileshortcut; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE dlfileshortcut (
    uuid_ character varying(75),
    fileshortcutid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    repositoryid bigint,
    folderid bigint,
    tofileentryid bigint,
    status integer,
    statusbyuserid bigint,
    statusbyusername character varying(75),
    statusdate timestamp without time zone
);


ALTER TABLE dlfileshortcut OWNER TO root;

--
-- Name: dlfileversion; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE dlfileversion (
    uuid_ character varying(75),
    fileversionid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    repositoryid bigint,
    folderid bigint,
    fileentryid bigint,
    extension character varying(75),
    mimetype character varying(75),
    title character varying(255),
    description text,
    changelog character varying(75),
    extrasettings text,
    fileentrytypeid bigint,
    version character varying(75),
    size_ bigint,
    status integer,
    statusbyuserid bigint,
    statusbyusername character varying(75),
    statusdate timestamp without time zone
);


ALTER TABLE dlfileversion OWNER TO root;

--
-- Name: dlfolder; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE dlfolder (
    uuid_ character varying(75),
    folderid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    repositoryid bigint,
    mountpoint boolean,
    parentfolderid bigint,
    name character varying(100),
    description text,
    lastpostdate timestamp without time zone,
    defaultfileentrytypeid bigint,
    overridefileentrytypes boolean
);


ALTER TABLE dlfolder OWNER TO root;

--
-- Name: dlsync; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE dlsync (
    syncid bigint NOT NULL,
    companyid bigint,
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    fileid bigint,
    fileuuid character varying(75),
    repositoryid bigint,
    parentfolderid bigint,
    name character varying(255),
    description text,
    event character varying(75),
    type_ character varying(75),
    version character varying(75)
);


ALTER TABLE dlsync OWNER TO root;

--
-- Name: emailaddress; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE emailaddress (
    emailaddressid bigint NOT NULL,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    classnameid bigint,
    classpk bigint,
    address character varying(75),
    typeid integer,
    primary_ boolean
);


ALTER TABLE emailaddress OWNER TO root;

--
-- Name: expandocolumn; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE expandocolumn (
    columnid bigint NOT NULL,
    companyid bigint,
    tableid bigint,
    name character varying(75),
    type_ integer,
    defaultdata text,
    typesettings text
);


ALTER TABLE expandocolumn OWNER TO root;

--
-- Name: expandorow; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE expandorow (
    rowid_ bigint NOT NULL,
    companyid bigint,
    tableid bigint,
    classpk bigint
);


ALTER TABLE expandorow OWNER TO root;

--
-- Name: expandotable; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE expandotable (
    tableid bigint NOT NULL,
    companyid bigint,
    classnameid bigint,
    name character varying(75)
);


ALTER TABLE expandotable OWNER TO root;

--
-- Name: expandovalue; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE expandovalue (
    valueid bigint NOT NULL,
    companyid bigint,
    tableid bigint,
    columnid bigint,
    rowid_ bigint,
    classnameid bigint,
    classpk bigint,
    data_ text
);


ALTER TABLE expandovalue OWNER TO root;

--
-- Name: group_; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE group_ (
    groupid bigint NOT NULL,
    companyid bigint,
    creatoruserid bigint,
    classnameid bigint,
    classpk bigint,
    parentgroupid bigint,
    livegroupid bigint,
    name character varying(150),
    description text,
    type_ integer,
    typesettings text,
    friendlyurl character varying(100),
    site boolean,
    active_ boolean
);


ALTER TABLE group_ OWNER TO root;

--
-- Name: groups_orgs; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE groups_orgs (
    groupid bigint NOT NULL,
    organizationid bigint NOT NULL
);


ALTER TABLE groups_orgs OWNER TO root;

--
-- Name: groups_permissions; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE groups_permissions (
    groupid bigint NOT NULL,
    permissionid bigint NOT NULL
);


ALTER TABLE groups_permissions OWNER TO root;

--
-- Name: groups_roles; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE groups_roles (
    groupid bigint NOT NULL,
    roleid bigint NOT NULL
);


ALTER TABLE groups_roles OWNER TO root;

--
-- Name: groups_usergroups; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE groups_usergroups (
    groupid bigint NOT NULL,
    usergroupid bigint NOT NULL
);


ALTER TABLE groups_usergroups OWNER TO root;

--
-- Name: image; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE image (
    imageid bigint NOT NULL,
    modifieddate timestamp without time zone,
    text_ text,
    type_ character varying(75),
    height integer,
    width integer,
    size_ integer
);


ALTER TABLE image OWNER TO root;

--
-- Name: journalarticle; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE journalarticle (
    uuid_ character varying(75),
    id_ bigint NOT NULL,
    resourceprimkey bigint,
    groupid bigint,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    classnameid bigint,
    classpk bigint,
    articleid character varying(75),
    version double precision,
    title text,
    urltitle character varying(150),
    description text,
    content text,
    type_ character varying(75),
    structureid character varying(75),
    templateid character varying(75),
    layoutuuid character varying(75),
    displaydate timestamp without time zone,
    expirationdate timestamp without time zone,
    reviewdate timestamp without time zone,
    indexable boolean,
    smallimage boolean,
    smallimageid bigint,
    smallimageurl text,
    status integer,
    statusbyuserid bigint,
    statusbyusername character varying(75),
    statusdate timestamp without time zone
);


ALTER TABLE journalarticle OWNER TO root;

--
-- Name: journalarticleimage; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE journalarticleimage (
    articleimageid bigint NOT NULL,
    groupid bigint,
    articleid character varying(75),
    version double precision,
    elinstanceid character varying(75),
    elname character varying(75),
    languageid character varying(75),
    tempimage boolean
);


ALTER TABLE journalarticleimage OWNER TO root;

--
-- Name: journalarticleresource; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE journalarticleresource (
    uuid_ character varying(75),
    resourceprimkey bigint NOT NULL,
    groupid bigint,
    articleid character varying(75)
);


ALTER TABLE journalarticleresource OWNER TO root;

--
-- Name: journalcontentsearch; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE journalcontentsearch (
    contentsearchid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    privatelayout boolean,
    layoutid bigint,
    portletid character varying(200),
    articleid character varying(75)
);


ALTER TABLE journalcontentsearch OWNER TO root;

--
-- Name: journalfeed; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE journalfeed (
    uuid_ character varying(75),
    id_ bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    feedid character varying(75),
    name character varying(75),
    description text,
    type_ character varying(75),
    structureid character varying(75),
    templateid character varying(75),
    renderertemplateid character varying(75),
    delta integer,
    orderbycol character varying(75),
    orderbytype character varying(75),
    targetlayoutfriendlyurl character varying(255),
    targetportletid character varying(75),
    contentfield character varying(75),
    feedtype character varying(75),
    feedversion double precision
);


ALTER TABLE journalfeed OWNER TO root;

--
-- Name: journalstructure; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE journalstructure (
    uuid_ character varying(75),
    id_ bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    structureid character varying(75),
    parentstructureid character varying(75),
    name text,
    description text,
    xsd text
);


ALTER TABLE journalstructure OWNER TO root;

--
-- Name: journaltemplate; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE journaltemplate (
    uuid_ character varying(75),
    id_ bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    templateid character varying(75),
    structureid character varying(75),
    name text,
    description text,
    xsl text,
    langtype character varying(75),
    cacheable boolean,
    smallimage boolean,
    smallimageid bigint,
    smallimageurl text
);


ALTER TABLE journaltemplate OWNER TO root;

--
-- Name: layout; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE layout (
    uuid_ character varying(75),
    plid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    privatelayout boolean,
    layoutid bigint,
    parentlayoutid bigint,
    name text,
    title text,
    description text,
    keywords text,
    robots text,
    type_ character varying(75),
    typesettings text,
    hidden_ boolean,
    friendlyurl character varying(255),
    iconimage boolean,
    iconimageid bigint,
    themeid character varying(75),
    colorschemeid character varying(75),
    wapthemeid character varying(75),
    wapcolorschemeid character varying(75),
    css text,
    priority integer,
    layoutprototypeuuid character varying(75),
    layoutprototypelinkenabled boolean,
    sourceprototypelayoutuuid character varying(75)
);


ALTER TABLE layout OWNER TO root;

--
-- Name: layoutbranch; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE layoutbranch (
    layoutbranchid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    userid bigint,
    username character varying(75),
    layoutsetbranchid bigint,
    plid bigint,
    name character varying(75),
    description text,
    master boolean
);


ALTER TABLE layoutbranch OWNER TO root;

--
-- Name: layoutprototype; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE layoutprototype (
    uuid_ character varying(75),
    layoutprototypeid bigint NOT NULL,
    companyid bigint,
    name text,
    description text,
    settings_ text,
    active_ boolean
);


ALTER TABLE layoutprototype OWNER TO root;

--
-- Name: layoutrevision; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE layoutrevision (
    layoutrevisionid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    layoutsetbranchid bigint,
    layoutbranchid bigint,
    parentlayoutrevisionid bigint,
    head boolean,
    major boolean,
    plid bigint,
    privatelayout boolean,
    name text,
    title text,
    description text,
    keywords text,
    robots text,
    typesettings text,
    iconimage boolean,
    iconimageid bigint,
    themeid character varying(75),
    colorschemeid character varying(75),
    wapthemeid character varying(75),
    wapcolorschemeid character varying(75),
    css text,
    status integer,
    statusbyuserid bigint,
    statusbyusername character varying(75),
    statusdate timestamp without time zone
);


ALTER TABLE layoutrevision OWNER TO root;

--
-- Name: layoutset; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE layoutset (
    layoutsetid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    privatelayout boolean,
    logo boolean,
    logoid bigint,
    themeid character varying(75),
    colorschemeid character varying(75),
    wapthemeid character varying(75),
    wapcolorschemeid character varying(75),
    css text,
    pagecount integer,
    settings_ text,
    layoutsetprototypeuuid character varying(75),
    layoutsetprototypelinkenabled boolean
);


ALTER TABLE layoutset OWNER TO root;

--
-- Name: layoutsetbranch; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE layoutsetbranch (
    layoutsetbranchid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    privatelayout boolean,
    name character varying(75),
    description text,
    master boolean,
    logo boolean,
    logoid bigint,
    themeid character varying(75),
    colorschemeid character varying(75),
    wapthemeid character varying(75),
    wapcolorschemeid character varying(75),
    css text,
    settings_ text,
    layoutsetprototypeuuid character varying(75),
    layoutsetprototypelinkenabled boolean
);


ALTER TABLE layoutsetbranch OWNER TO root;

--
-- Name: layoutsetprototype; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE layoutsetprototype (
    uuid_ character varying(75),
    layoutsetprototypeid bigint NOT NULL,
    companyid bigint,
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    name text,
    description text,
    settings_ text,
    active_ boolean
);


ALTER TABLE layoutsetprototype OWNER TO root;

--
-- Name: listtype; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE listtype (
    listtypeid integer NOT NULL,
    name character varying(75),
    type_ character varying(75)
);


ALTER TABLE listtype OWNER TO root;

--
-- Name: lock_; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE lock_ (
    uuid_ character varying(75),
    lockid bigint NOT NULL,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    classname character varying(75),
    key_ character varying(200),
    owner character varying(255),
    inheritable boolean,
    expirationdate timestamp without time zone
);


ALTER TABLE lock_ OWNER TO root;

--
-- Name: marketplace_app; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE marketplace_app (
    uuid_ character varying(75),
    appid bigint NOT NULL,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    remoteappid bigint,
    version character varying(75)
);


ALTER TABLE marketplace_app OWNER TO root;

--
-- Name: marketplace_module; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE marketplace_module (
    uuid_ character varying(75),
    moduleid bigint NOT NULL,
    appid bigint,
    contextname character varying(75)
);


ALTER TABLE marketplace_module OWNER TO root;

--
-- Name: mbban; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE mbban (
    banid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    banuserid bigint
);


ALTER TABLE mbban OWNER TO root;

--
-- Name: mbcategory; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE mbcategory (
    uuid_ character varying(75),
    categoryid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    parentcategoryid bigint,
    name character varying(75),
    description text,
    displaystyle character varying(75),
    threadcount integer,
    messagecount integer,
    lastpostdate timestamp without time zone
);


ALTER TABLE mbcategory OWNER TO root;

--
-- Name: mbdiscussion; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE mbdiscussion (
    discussionid bigint NOT NULL,
    classnameid bigint,
    classpk bigint,
    threadid bigint
);


ALTER TABLE mbdiscussion OWNER TO root;

--
-- Name: mbmailinglist; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE mbmailinglist (
    uuid_ character varying(75),
    mailinglistid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    categoryid bigint,
    emailaddress character varying(75),
    inprotocol character varying(75),
    inservername character varying(75),
    inserverport integer,
    inusessl boolean,
    inusername character varying(75),
    inpassword character varying(75),
    inreadinterval integer,
    outemailaddress character varying(75),
    outcustom boolean,
    outservername character varying(75),
    outserverport integer,
    outusessl boolean,
    outusername character varying(75),
    outpassword character varying(75),
    allowanonymous boolean,
    active_ boolean
);


ALTER TABLE mbmailinglist OWNER TO root;

--
-- Name: mbmessage; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE mbmessage (
    uuid_ character varying(75),
    messageid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    classnameid bigint,
    classpk bigint,
    categoryid bigint,
    threadid bigint,
    rootmessageid bigint,
    parentmessageid bigint,
    subject character varying(75),
    body text,
    format character varying(75),
    attachments boolean,
    anonymous boolean,
    priority double precision,
    allowpingbacks boolean,
    answer boolean,
    status integer,
    statusbyuserid bigint,
    statusbyusername character varying(75),
    statusdate timestamp without time zone
);


ALTER TABLE mbmessage OWNER TO root;

--
-- Name: mbstatsuser; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE mbstatsuser (
    statsuserid bigint NOT NULL,
    groupid bigint,
    userid bigint,
    messagecount integer,
    lastpostdate timestamp without time zone
);


ALTER TABLE mbstatsuser OWNER TO root;

--
-- Name: mbthread; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE mbthread (
    threadid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    categoryid bigint,
    rootmessageid bigint,
    rootmessageuserid bigint,
    messagecount integer,
    viewcount integer,
    lastpostbyuserid bigint,
    lastpostdate timestamp without time zone,
    priority double precision,
    question boolean,
    status integer,
    statusbyuserid bigint,
    statusbyusername character varying(75),
    statusdate timestamp without time zone
);


ALTER TABLE mbthread OWNER TO root;

--
-- Name: mbthreadflag; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE mbthreadflag (
    threadflagid bigint NOT NULL,
    userid bigint,
    modifieddate timestamp without time zone,
    threadid bigint
);


ALTER TABLE mbthreadflag OWNER TO root;

--
-- Name: mdraction; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE mdraction (
    uuid_ character varying(75),
    actionid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    classnameid bigint,
    classpk bigint,
    rulegroupinstanceid bigint,
    name text,
    description text,
    type_ character varying(255),
    typesettings text
);


ALTER TABLE mdraction OWNER TO root;

--
-- Name: mdrrule; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE mdrrule (
    uuid_ character varying(75),
    ruleid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    rulegroupid bigint,
    name text,
    description text,
    type_ character varying(255),
    typesettings text
);


ALTER TABLE mdrrule OWNER TO root;

--
-- Name: mdrrulegroup; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE mdrrulegroup (
    uuid_ character varying(75),
    rulegroupid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    name text,
    description text
);


ALTER TABLE mdrrulegroup OWNER TO root;

--
-- Name: mdrrulegroupinstance; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE mdrrulegroupinstance (
    uuid_ character varying(75),
    rulegroupinstanceid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    classnameid bigint,
    classpk bigint,
    rulegroupid bigint,
    priority integer
);


ALTER TABLE mdrrulegroupinstance OWNER TO root;

--
-- Name: membershiprequest; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE membershiprequest (
    membershiprequestid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    userid bigint,
    createdate timestamp without time zone,
    comments text,
    replycomments text,
    replydate timestamp without time zone,
    replieruserid bigint,
    statusid integer
);


ALTER TABLE membershiprequest OWNER TO root;

--
-- Name: organization_; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE organization_ (
    organizationid bigint NOT NULL,
    companyid bigint,
    parentorganizationid bigint,
    treepath text,
    name character varying(100),
    type_ character varying(75),
    recursable boolean,
    regionid bigint,
    countryid bigint,
    statusid integer,
    comments text
);


ALTER TABLE organization_ OWNER TO root;

--
-- Name: orggrouppermission; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE orggrouppermission (
    organizationid bigint NOT NULL,
    groupid bigint NOT NULL,
    permissionid bigint NOT NULL
);


ALTER TABLE orggrouppermission OWNER TO root;

--
-- Name: orggrouprole; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE orggrouprole (
    organizationid bigint NOT NULL,
    groupid bigint NOT NULL,
    roleid bigint NOT NULL
);


ALTER TABLE orggrouprole OWNER TO root;

--
-- Name: orglabor; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE orglabor (
    orglaborid bigint NOT NULL,
    organizationid bigint,
    typeid integer,
    sunopen integer,
    sunclose integer,
    monopen integer,
    monclose integer,
    tueopen integer,
    tueclose integer,
    wedopen integer,
    wedclose integer,
    thuopen integer,
    thuclose integer,
    friopen integer,
    friclose integer,
    satopen integer,
    satclose integer
);


ALTER TABLE orglabor OWNER TO root;

--
-- Name: passwordpolicy; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE passwordpolicy (
    passwordpolicyid bigint NOT NULL,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    defaultpolicy boolean,
    name character varying(75),
    description text,
    changeable boolean,
    changerequired boolean,
    minage bigint,
    checksyntax boolean,
    allowdictionarywords boolean,
    minalphanumeric integer,
    minlength integer,
    minlowercase integer,
    minnumbers integer,
    minsymbols integer,
    minuppercase integer,
    history boolean,
    historycount integer,
    expireable boolean,
    maxage bigint,
    warningtime bigint,
    gracelimit integer,
    lockout boolean,
    maxfailure integer,
    lockoutduration bigint,
    requireunlock boolean,
    resetfailurecount bigint,
    resetticketmaxage bigint
);


ALTER TABLE passwordpolicy OWNER TO root;

--
-- Name: passwordpolicyrel; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE passwordpolicyrel (
    passwordpolicyrelid bigint NOT NULL,
    passwordpolicyid bigint,
    classnameid bigint,
    classpk bigint
);


ALTER TABLE passwordpolicyrel OWNER TO root;

--
-- Name: passwordtracker; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE passwordtracker (
    passwordtrackerid bigint NOT NULL,
    userid bigint,
    createdate timestamp without time zone,
    password_ character varying(75)
);


ALTER TABLE passwordtracker OWNER TO root;

--
-- Name: permission_; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE permission_ (
    permissionid bigint NOT NULL,
    companyid bigint,
    actionid character varying(75),
    resourceid bigint
);


ALTER TABLE permission_ OWNER TO root;

--
-- Name: phone; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE phone (
    phoneid bigint NOT NULL,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    classnameid bigint,
    classpk bigint,
    number_ character varying(75),
    extension character varying(75),
    typeid integer,
    primary_ boolean
);


ALTER TABLE phone OWNER TO root;

--
-- Name: pluginsetting; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE pluginsetting (
    pluginsettingid bigint NOT NULL,
    companyid bigint,
    pluginid character varying(75),
    plugintype character varying(75),
    roles text,
    active_ boolean
);


ALTER TABLE pluginsetting OWNER TO root;

--
-- Name: pollschoice; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE pollschoice (
    uuid_ character varying(75),
    choiceid bigint NOT NULL,
    questionid bigint,
    name character varying(75),
    description text
);


ALTER TABLE pollschoice OWNER TO root;

--
-- Name: pollsquestion; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE pollsquestion (
    uuid_ character varying(75),
    questionid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    title text,
    description text,
    expirationdate timestamp without time zone,
    lastvotedate timestamp without time zone
);


ALTER TABLE pollsquestion OWNER TO root;

--
-- Name: pollsvote; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE pollsvote (
    voteid bigint NOT NULL,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    questionid bigint,
    choiceid bigint,
    votedate timestamp without time zone
);


ALTER TABLE pollsvote OWNER TO root;

--
-- Name: portalpreferences; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE portalpreferences (
    portalpreferencesid bigint NOT NULL,
    ownerid bigint,
    ownertype integer,
    preferences text
);


ALTER TABLE portalpreferences OWNER TO root;

--
-- Name: portlet; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE portlet (
    id_ bigint NOT NULL,
    companyid bigint,
    portletid character varying(200),
    roles text,
    active_ boolean
);


ALTER TABLE portlet OWNER TO root;

--
-- Name: portletitem; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE portletitem (
    portletitemid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    name character varying(75),
    portletid character varying(75),
    classnameid bigint
);


ALTER TABLE portletitem OWNER TO root;

--
-- Name: portletpreferences; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE portletpreferences (
    portletpreferencesid bigint NOT NULL,
    ownerid bigint,
    ownertype integer,
    plid bigint,
    portletid character varying(200),
    preferences text
);


ALTER TABLE portletpreferences OWNER TO root;

--
-- Name: quartz_blob_triggers; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE quartz_blob_triggers (
    sched_name character varying(120) NOT NULL,
    trigger_name character varying(200) NOT NULL,
    trigger_group character varying(200) NOT NULL,
    blob_data bytea
);


ALTER TABLE quartz_blob_triggers OWNER TO root;

--
-- Name: quartz_calendars; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE quartz_calendars (
    sched_name character varying(120) NOT NULL,
    calendar_name character varying(200) NOT NULL,
    calendar bytea NOT NULL
);


ALTER TABLE quartz_calendars OWNER TO root;

--
-- Name: quartz_cron_triggers; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE quartz_cron_triggers (
    sched_name character varying(120) NOT NULL,
    trigger_name character varying(200) NOT NULL,
    trigger_group character varying(200) NOT NULL,
    cron_expression character varying(200) NOT NULL,
    time_zone_id character varying(80)
);


ALTER TABLE quartz_cron_triggers OWNER TO root;

--
-- Name: quartz_fired_triggers; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE quartz_fired_triggers (
    sched_name character varying(120) NOT NULL,
    entry_id character varying(95) NOT NULL,
    trigger_name character varying(200) NOT NULL,
    trigger_group character varying(200) NOT NULL,
    instance_name character varying(200) NOT NULL,
    fired_time bigint NOT NULL,
    priority integer NOT NULL,
    state character varying(16) NOT NULL,
    job_name character varying(200),
    job_group character varying(200),
    is_nonconcurrent boolean,
    requests_recovery boolean
);


ALTER TABLE quartz_fired_triggers OWNER TO root;

--
-- Name: quartz_job_details; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE quartz_job_details (
    sched_name character varying(120) NOT NULL,
    job_name character varying(200) NOT NULL,
    job_group character varying(200) NOT NULL,
    description character varying(250),
    job_class_name character varying(250) NOT NULL,
    is_durable boolean NOT NULL,
    is_nonconcurrent boolean NOT NULL,
    is_update_data boolean NOT NULL,
    requests_recovery boolean NOT NULL,
    job_data bytea
);


ALTER TABLE quartz_job_details OWNER TO root;

--
-- Name: quartz_locks; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE quartz_locks (
    sched_name character varying(120) NOT NULL,
    lock_name character varying(40) NOT NULL
);


ALTER TABLE quartz_locks OWNER TO root;

--
-- Name: quartz_paused_trigger_grps; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE quartz_paused_trigger_grps (
    sched_name character varying(120) NOT NULL,
    trigger_group character varying(200) NOT NULL
);


ALTER TABLE quartz_paused_trigger_grps OWNER TO root;

--
-- Name: quartz_scheduler_state; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE quartz_scheduler_state (
    sched_name character varying(120) NOT NULL,
    instance_name character varying(200) NOT NULL,
    last_checkin_time bigint NOT NULL,
    checkin_interval bigint NOT NULL
);


ALTER TABLE quartz_scheduler_state OWNER TO root;

--
-- Name: quartz_simple_triggers; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE quartz_simple_triggers (
    sched_name character varying(120) NOT NULL,
    trigger_name character varying(200) NOT NULL,
    trigger_group character varying(200) NOT NULL,
    repeat_count bigint NOT NULL,
    repeat_interval bigint NOT NULL,
    times_triggered bigint NOT NULL
);


ALTER TABLE quartz_simple_triggers OWNER TO root;

--
-- Name: quartz_simprop_triggers; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE quartz_simprop_triggers (
    sched_name character varying(120) NOT NULL,
    trigger_name character varying(200) NOT NULL,
    trigger_group character varying(200) NOT NULL,
    str_prop_1 character varying(512),
    str_prop_2 character varying(512),
    str_prop_3 character varying(512),
    int_prop_1 integer,
    int_prop_2 integer,
    long_prop_1 bigint,
    long_prop_2 bigint,
    dec_prop_1 numeric(13,4),
    dec_prop_2 numeric(13,4),
    bool_prop_1 boolean,
    bool_prop_2 boolean
);


ALTER TABLE quartz_simprop_triggers OWNER TO root;

--
-- Name: quartz_triggers; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE quartz_triggers (
    sched_name character varying(120) NOT NULL,
    trigger_name character varying(200) NOT NULL,
    trigger_group character varying(200) NOT NULL,
    job_name character varying(200) NOT NULL,
    job_group character varying(200) NOT NULL,
    description character varying(250),
    next_fire_time bigint,
    prev_fire_time bigint,
    priority integer,
    trigger_state character varying(16) NOT NULL,
    trigger_type character varying(8) NOT NULL,
    start_time bigint NOT NULL,
    end_time bigint,
    calendar_name character varying(200),
    misfire_instr integer,
    job_data bytea
);


ALTER TABLE quartz_triggers OWNER TO root;

--
-- Name: ratingsentry; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE ratingsentry (
    entryid bigint NOT NULL,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    classnameid bigint,
    classpk bigint,
    score double precision
);


ALTER TABLE ratingsentry OWNER TO root;

--
-- Name: ratingsstats; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE ratingsstats (
    statsid bigint NOT NULL,
    classnameid bigint,
    classpk bigint,
    totalentries integer,
    totalscore double precision,
    averagescore double precision
);


ALTER TABLE ratingsstats OWNER TO root;

--
-- Name: region; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE region (
    regionid bigint NOT NULL,
    countryid bigint,
    regioncode character varying(75),
    name character varying(75),
    active_ boolean
);


ALTER TABLE region OWNER TO root;

--
-- Name: release_; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE release_ (
    releaseid bigint NOT NULL,
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    servletcontextname character varying(75),
    buildnumber integer,
    builddate timestamp without time zone,
    verified boolean,
    state_ integer,
    teststring character varying(1024)
);


ALTER TABLE release_ OWNER TO root;

--
-- Name: repository; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE repository (
    uuid_ character varying(75),
    repositoryid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    classnameid bigint,
    name character varying(75),
    description text,
    portletid character varying(75),
    typesettings text,
    dlfolderid bigint
);


ALTER TABLE repository OWNER TO root;

--
-- Name: repositoryentry; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE repositoryentry (
    uuid_ character varying(75),
    repositoryentryid bigint NOT NULL,
    groupid bigint,
    repositoryid bigint,
    mappedid character varying(75)
);


ALTER TABLE repositoryentry OWNER TO root;

--
-- Name: resource_; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE resource_ (
    resourceid bigint NOT NULL,
    codeid bigint,
    primkey character varying(255)
);


ALTER TABLE resource_ OWNER TO root;

--
-- Name: resourceaction; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE resourceaction (
    resourceactionid bigint NOT NULL,
    name character varying(255),
    actionid character varying(75),
    bitwisevalue bigint
);


ALTER TABLE resourceaction OWNER TO root;

--
-- Name: resourceblock; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE resourceblock (
    resourceblockid bigint NOT NULL,
    companyid bigint,
    groupid bigint,
    name character varying(75),
    permissionshash character varying(75),
    referencecount bigint
);


ALTER TABLE resourceblock OWNER TO root;

--
-- Name: resourceblockpermission; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE resourceblockpermission (
    resourceblockpermissionid bigint NOT NULL,
    resourceblockid bigint,
    roleid bigint,
    actionids bigint
);


ALTER TABLE resourceblockpermission OWNER TO root;

--
-- Name: resourcecode; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE resourcecode (
    codeid bigint NOT NULL,
    companyid bigint,
    name character varying(255),
    scope integer
);


ALTER TABLE resourcecode OWNER TO root;

--
-- Name: resourcepermission; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE resourcepermission (
    resourcepermissionid bigint NOT NULL,
    companyid bigint,
    name character varying(255),
    scope integer,
    primkey character varying(255),
    roleid bigint,
    ownerid bigint,
    actionids bigint
);


ALTER TABLE resourcepermission OWNER TO root;

--
-- Name: resourcetypepermission; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE resourcetypepermission (
    resourcetypepermissionid bigint NOT NULL,
    companyid bigint,
    groupid bigint,
    name character varying(75),
    roleid bigint,
    actionids bigint
);


ALTER TABLE resourcetypepermission OWNER TO root;

--
-- Name: role_; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE role_ (
    roleid bigint NOT NULL,
    companyid bigint,
    classnameid bigint,
    classpk bigint,
    name character varying(75),
    title text,
    description text,
    type_ integer,
    subtype character varying(75)
);


ALTER TABLE role_ OWNER TO root;

--
-- Name: roles_permissions; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE roles_permissions (
    permissionid bigint NOT NULL,
    roleid bigint NOT NULL
);


ALTER TABLE roles_permissions OWNER TO root;

--
-- Name: scframeworkversi_scproductvers; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE scframeworkversi_scproductvers (
    frameworkversionid bigint NOT NULL,
    productversionid bigint NOT NULL
);


ALTER TABLE scframeworkversi_scproductvers OWNER TO root;

--
-- Name: scframeworkversion; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE scframeworkversion (
    frameworkversionid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    name character varying(75),
    url text,
    active_ boolean,
    priority integer
);


ALTER TABLE scframeworkversion OWNER TO root;

--
-- Name: sclicense; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE sclicense (
    licenseid bigint NOT NULL,
    name character varying(75),
    url text,
    opensource boolean,
    active_ boolean,
    recommended boolean
);


ALTER TABLE sclicense OWNER TO root;

--
-- Name: sclicenses_scproductentries; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE sclicenses_scproductentries (
    licenseid bigint NOT NULL,
    productentryid bigint NOT NULL
);


ALTER TABLE sclicenses_scproductentries OWNER TO root;

--
-- Name: scproductentry; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE scproductentry (
    productentryid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    name character varying(75),
    type_ character varying(75),
    tags character varying(255),
    shortdescription text,
    longdescription text,
    pageurl text,
    author character varying(75),
    repogroupid character varying(75),
    repoartifactid character varying(75)
);


ALTER TABLE scproductentry OWNER TO root;

--
-- Name: scproductscreenshot; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE scproductscreenshot (
    productscreenshotid bigint NOT NULL,
    companyid bigint,
    groupid bigint,
    productentryid bigint,
    thumbnailid bigint,
    fullimageid bigint,
    priority integer
);


ALTER TABLE scproductscreenshot OWNER TO root;

--
-- Name: scproductversion; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE scproductversion (
    productversionid bigint NOT NULL,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    productentryid bigint,
    version character varying(75),
    changelog text,
    downloadpageurl text,
    directdownloadurl character varying(2000),
    repostoreartifact boolean
);


ALTER TABLE scproductversion OWNER TO root;

--
-- Name: servicecomponent; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE servicecomponent (
    servicecomponentid bigint NOT NULL,
    buildnamespace character varying(75),
    buildnumber bigint,
    builddate bigint,
    data_ text
);


ALTER TABLE servicecomponent OWNER TO root;

--
-- Name: shard; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE shard (
    shardid bigint NOT NULL,
    classnameid bigint,
    classpk bigint,
    name character varying(75)
);


ALTER TABLE shard OWNER TO root;

--
-- Name: shoppingcart; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE shoppingcart (
    cartid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    itemids text,
    couponcodes character varying(75),
    altshipping integer,
    insure boolean
);


ALTER TABLE shoppingcart OWNER TO root;

--
-- Name: shoppingcategory; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE shoppingcategory (
    categoryid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    parentcategoryid bigint,
    name character varying(75),
    description text
);


ALTER TABLE shoppingcategory OWNER TO root;

--
-- Name: shoppingcoupon; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE shoppingcoupon (
    couponid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    code_ character varying(75),
    name character varying(75),
    description text,
    startdate timestamp without time zone,
    enddate timestamp without time zone,
    active_ boolean,
    limitcategories text,
    limitskus text,
    minorder double precision,
    discount double precision,
    discounttype character varying(75)
);


ALTER TABLE shoppingcoupon OWNER TO root;

--
-- Name: shoppingitem; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE shoppingitem (
    itemid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    categoryid bigint,
    sku character varying(75),
    name character varying(200),
    description text,
    properties text,
    fields_ boolean,
    fieldsquantities text,
    minquantity integer,
    maxquantity integer,
    price double precision,
    discount double precision,
    taxable boolean,
    shipping double precision,
    useshippingformula boolean,
    requiresshipping boolean,
    stockquantity integer,
    featured_ boolean,
    sale_ boolean,
    smallimage boolean,
    smallimageid bigint,
    smallimageurl text,
    mediumimage boolean,
    mediumimageid bigint,
    mediumimageurl text,
    largeimage boolean,
    largeimageid bigint,
    largeimageurl text
);


ALTER TABLE shoppingitem OWNER TO root;

--
-- Name: shoppingitemfield; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE shoppingitemfield (
    itemfieldid bigint NOT NULL,
    itemid bigint,
    name character varying(75),
    values_ text,
    description text
);


ALTER TABLE shoppingitemfield OWNER TO root;

--
-- Name: shoppingitemprice; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE shoppingitemprice (
    itempriceid bigint NOT NULL,
    itemid bigint,
    minquantity integer,
    maxquantity integer,
    price double precision,
    discount double precision,
    taxable boolean,
    shipping double precision,
    useshippingformula boolean,
    status integer
);


ALTER TABLE shoppingitemprice OWNER TO root;

--
-- Name: shoppingorder; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE shoppingorder (
    orderid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    number_ character varying(75),
    tax double precision,
    shipping double precision,
    altshipping character varying(75),
    requiresshipping boolean,
    insure boolean,
    insurance double precision,
    couponcodes character varying(75),
    coupondiscount double precision,
    billingfirstname character varying(75),
    billinglastname character varying(75),
    billingemailaddress character varying(75),
    billingcompany character varying(75),
    billingstreet character varying(75),
    billingcity character varying(75),
    billingstate character varying(75),
    billingzip character varying(75),
    billingcountry character varying(75),
    billingphone character varying(75),
    shiptobilling boolean,
    shippingfirstname character varying(75),
    shippinglastname character varying(75),
    shippingemailaddress character varying(75),
    shippingcompany character varying(75),
    shippingstreet character varying(75),
    shippingcity character varying(75),
    shippingstate character varying(75),
    shippingzip character varying(75),
    shippingcountry character varying(75),
    shippingphone character varying(75),
    ccname character varying(75),
    cctype character varying(75),
    ccnumber character varying(75),
    ccexpmonth integer,
    ccexpyear integer,
    ccvernumber character varying(75),
    comments text,
    pptxnid character varying(75),
    pppaymentstatus character varying(75),
    pppaymentgross double precision,
    ppreceiveremail character varying(75),
    pppayeremail character varying(75),
    sendorderemail boolean,
    sendshippingemail boolean
);


ALTER TABLE shoppingorder OWNER TO root;

--
-- Name: shoppingorderitem; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE shoppingorderitem (
    orderitemid bigint NOT NULL,
    orderid bigint,
    itemid character varying(75),
    sku character varying(75),
    name character varying(200),
    description text,
    properties text,
    price double precision,
    quantity integer,
    shippeddate timestamp without time zone
);


ALTER TABLE shoppingorderitem OWNER TO root;

--
-- Name: socialactivity; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE socialactivity (
    activityid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    userid bigint,
    createdate bigint,
    mirroractivityid bigint,
    classnameid bigint,
    classpk bigint,
    type_ integer,
    extradata text,
    receiveruserid bigint
);


ALTER TABLE socialactivity OWNER TO root;

--
-- Name: socialactivityachievement; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE socialactivityachievement (
    activityachievementid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    userid bigint,
    createdate bigint,
    name character varying(75),
    firstingroup boolean
);


ALTER TABLE socialactivityachievement OWNER TO root;

--
-- Name: socialactivitycounter; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE socialactivitycounter (
    activitycounterid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    classnameid bigint,
    classpk bigint,
    name character varying(75),
    ownertype integer,
    currentvalue integer,
    totalvalue integer,
    gracevalue integer,
    startperiod integer,
    endperiod integer
);


ALTER TABLE socialactivitycounter OWNER TO root;

--
-- Name: socialactivitylimit; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE socialactivitylimit (
    activitylimitid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    userid bigint,
    classnameid bigint,
    classpk bigint,
    activitytype integer,
    activitycountername character varying(75),
    value character varying(75)
);


ALTER TABLE socialactivitylimit OWNER TO root;

--
-- Name: socialactivitysetting; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE socialactivitysetting (
    activitysettingid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    classnameid bigint,
    activitytype integer,
    name character varying(75),
    value character varying(1024)
);


ALTER TABLE socialactivitysetting OWNER TO root;

--
-- Name: socialrelation; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE socialrelation (
    uuid_ character varying(75),
    relationid bigint NOT NULL,
    companyid bigint,
    createdate bigint,
    userid1 bigint,
    userid2 bigint,
    type_ integer
);


ALTER TABLE socialrelation OWNER TO root;

--
-- Name: socialrequest; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE socialrequest (
    uuid_ character varying(75),
    requestid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    userid bigint,
    createdate bigint,
    modifieddate bigint,
    classnameid bigint,
    classpk bigint,
    type_ integer,
    extradata text,
    receiveruserid bigint,
    status integer
);


ALTER TABLE socialrequest OWNER TO root;

--
-- Name: subscription; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE subscription (
    subscriptionid bigint NOT NULL,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    classnameid bigint,
    classpk bigint,
    frequency character varying(75)
);


ALTER TABLE subscription OWNER TO root;

--
-- Name: team; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE team (
    teamid bigint NOT NULL,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    groupid bigint,
    name character varying(75),
    description text
);


ALTER TABLE team OWNER TO root;

--
-- Name: ticket; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE ticket (
    ticketid bigint NOT NULL,
    companyid bigint,
    createdate timestamp without time zone,
    classnameid bigint,
    classpk bigint,
    key_ character varying(75),
    type_ integer,
    extrainfo text,
    expirationdate timestamp without time zone
);


ALTER TABLE ticket OWNER TO root;

--
-- Name: user_; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE user_ (
    uuid_ character varying(75),
    userid bigint NOT NULL,
    companyid bigint,
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    defaultuser boolean,
    contactid bigint,
    password_ character varying(75),
    passwordencrypted boolean,
    passwordreset boolean,
    passwordmodifieddate timestamp without time zone,
    digest character varying(255),
    reminderqueryquestion character varying(75),
    reminderqueryanswer character varying(75),
    gracelogincount integer,
    screenname character varying(75),
    emailaddress character varying(75),
    facebookid bigint,
    openid character varying(1024),
    portraitid bigint,
    languageid character varying(75),
    timezoneid character varying(75),
    greeting character varying(255),
    comments text,
    firstname character varying(75),
    middlename character varying(75),
    lastname character varying(75),
    jobtitle character varying(100),
    logindate timestamp without time zone,
    loginip character varying(75),
    lastlogindate timestamp without time zone,
    lastloginip character varying(75),
    lastfailedlogindate timestamp without time zone,
    failedloginattempts integer,
    lockout boolean,
    lockoutdate timestamp without time zone,
    agreedtotermsofuse boolean,
    emailaddressverified boolean,
    status integer
);


ALTER TABLE user_ OWNER TO root;

--
-- Name: usergroup; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE usergroup (
    usergroupid bigint NOT NULL,
    companyid bigint,
    parentusergroupid bigint,
    name character varying(75),
    description text,
    addedbyldapimport boolean
);


ALTER TABLE usergroup OWNER TO root;

--
-- Name: usergroupgrouprole; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE usergroupgrouprole (
    usergroupid bigint NOT NULL,
    groupid bigint NOT NULL,
    roleid bigint NOT NULL
);


ALTER TABLE usergroupgrouprole OWNER TO root;

--
-- Name: usergrouprole; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE usergrouprole (
    userid bigint NOT NULL,
    groupid bigint NOT NULL,
    roleid bigint NOT NULL
);


ALTER TABLE usergrouprole OWNER TO root;

--
-- Name: usergroups_teams; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE usergroups_teams (
    teamid bigint NOT NULL,
    usergroupid bigint NOT NULL
);


ALTER TABLE usergroups_teams OWNER TO root;

--
-- Name: useridmapper; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE useridmapper (
    useridmapperid bigint NOT NULL,
    userid bigint,
    type_ character varying(75),
    description character varying(75),
    externaluserid character varying(75)
);


ALTER TABLE useridmapper OWNER TO root;

--
-- Name: usernotificationevent; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE usernotificationevent (
    uuid_ character varying(75),
    usernotificationeventid bigint NOT NULL,
    companyid bigint,
    userid bigint,
    type_ character varying(75),
    "timestamp" bigint,
    deliverby bigint,
    payload text,
    archived boolean
);


ALTER TABLE usernotificationevent OWNER TO root;

--
-- Name: users_groups; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE users_groups (
    groupid bigint NOT NULL,
    userid bigint NOT NULL
);


ALTER TABLE users_groups OWNER TO root;

--
-- Name: users_orgs; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE users_orgs (
    organizationid bigint NOT NULL,
    userid bigint NOT NULL
);


ALTER TABLE users_orgs OWNER TO root;

--
-- Name: users_permissions; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE users_permissions (
    permissionid bigint NOT NULL,
    userid bigint NOT NULL
);


ALTER TABLE users_permissions OWNER TO root;

--
-- Name: users_roles; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE users_roles (
    roleid bigint NOT NULL,
    userid bigint NOT NULL
);


ALTER TABLE users_roles OWNER TO root;

--
-- Name: users_teams; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE users_teams (
    teamid bigint NOT NULL,
    userid bigint NOT NULL
);


ALTER TABLE users_teams OWNER TO root;

--
-- Name: users_usergroups; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE users_usergroups (
    userid bigint NOT NULL,
    usergroupid bigint NOT NULL
);


ALTER TABLE users_usergroups OWNER TO root;

--
-- Name: usertracker; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE usertracker (
    usertrackerid bigint NOT NULL,
    companyid bigint,
    userid bigint,
    modifieddate timestamp without time zone,
    sessionid character varying(200),
    remoteaddr character varying(75),
    remotehost character varying(75),
    useragent character varying(200)
);


ALTER TABLE usertracker OWNER TO root;

--
-- Name: usertrackerpath; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE usertrackerpath (
    usertrackerpathid bigint NOT NULL,
    usertrackerid bigint,
    path_ text,
    pathdate timestamp without time zone
);


ALTER TABLE usertrackerpath OWNER TO root;

--
-- Name: virtualhost; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE virtualhost (
    virtualhostid bigint NOT NULL,
    companyid bigint,
    layoutsetid bigint,
    hostname character varying(75)
);


ALTER TABLE virtualhost OWNER TO root;

--
-- Name: webdavprops; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE webdavprops (
    webdavpropsid bigint NOT NULL,
    companyid bigint,
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    classnameid bigint,
    classpk bigint,
    props text
);


ALTER TABLE webdavprops OWNER TO root;

--
-- Name: website; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE website (
    websiteid bigint NOT NULL,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    classnameid bigint,
    classpk bigint,
    url text,
    typeid integer,
    primary_ boolean
);


ALTER TABLE website OWNER TO root;

--
-- Name: wikinode; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE wikinode (
    uuid_ character varying(75),
    nodeid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    name character varying(75),
    description text,
    lastpostdate timestamp without time zone
);


ALTER TABLE wikinode OWNER TO root;

--
-- Name: wikipage; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE wikipage (
    uuid_ character varying(75),
    pageid bigint NOT NULL,
    resourceprimkey bigint,
    groupid bigint,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    nodeid bigint,
    title character varying(255),
    version double precision,
    minoredit boolean,
    content text,
    summary text,
    format character varying(75),
    head boolean,
    parenttitle character varying(255),
    redirecttitle character varying(255),
    status integer,
    statusbyuserid bigint,
    statusbyusername character varying(75),
    statusdate timestamp without time zone
);


ALTER TABLE wikipage OWNER TO root;

--
-- Name: wikipageresource; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE wikipageresource (
    uuid_ character varying(75),
    resourceprimkey bigint NOT NULL,
    nodeid bigint,
    title character varying(255)
);


ALTER TABLE wikipageresource OWNER TO root;

--
-- Name: workflowdefinitionlink; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE workflowdefinitionlink (
    workflowdefinitionlinkid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    classnameid bigint,
    classpk bigint,
    typepk bigint,
    workflowdefinitionname character varying(75),
    workflowdefinitionversion integer
);


ALTER TABLE workflowdefinitionlink OWNER TO root;

--
-- Name: workflowinstancelink; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE workflowinstancelink (
    workflowinstancelinkid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    classnameid bigint,
    classpk bigint,
    workflowinstanceid bigint
);


ALTER TABLE workflowinstancelink OWNER TO root;

--
-- Data for Name: account_; Type: TABLE DATA; Schema: public; Owner: root
--

COPY account_ (accountid, companyid, userid, username, createdate, modifieddate, parentaccountid, name, legalname, legalid, legaltype, siccode, tickersymbol, industry, type_, size_) FROM stdin;
10255	10253	0		2017-03-10 17:05:21.659	2017-03-10 17:05:21.659	0	Liferay								
\.


--
-- Data for Name: address; Type: TABLE DATA; Schema: public; Owner: root
--

COPY address (addressid, companyid, userid, username, createdate, modifieddate, classnameid, classpk, street1, street2, street3, city, zip, regionid, countryid, typeid, mailing, primary_) FROM stdin;
\.


--
-- Data for Name: announcementsdelivery; Type: TABLE DATA; Schema: public; Owner: root
--

COPY announcementsdelivery (deliveryid, companyid, userid, type_, email, sms, website) FROM stdin;
\.


--
-- Data for Name: announcementsentry; Type: TABLE DATA; Schema: public; Owner: root
--

COPY announcementsentry (uuid_, entryid, companyid, userid, username, createdate, modifieddate, classnameid, classpk, title, content, url, type_, displaydate, expirationdate, priority, alert) FROM stdin;
\.


--
-- Data for Name: announcementsflag; Type: TABLE DATA; Schema: public; Owner: root
--

COPY announcementsflag (flagid, userid, createdate, entryid, value) FROM stdin;
\.


--
-- Data for Name: assetcategory; Type: TABLE DATA; Schema: public; Owner: root
--

COPY assetcategory (uuid_, categoryid, groupid, companyid, userid, username, createdate, modifieddate, parentcategoryid, leftcategoryid, rightcategoryid, name, title, description, vocabularyid) FROM stdin;
\.


--
-- Data for Name: assetcategoryproperty; Type: TABLE DATA; Schema: public; Owner: root
--

COPY assetcategoryproperty (categorypropertyid, companyid, userid, username, createdate, modifieddate, categoryid, key_, value) FROM stdin;
\.


--
-- Data for Name: assetentries_assetcategories; Type: TABLE DATA; Schema: public; Owner: root
--

COPY assetentries_assetcategories (categoryid, entryid) FROM stdin;
\.


--
-- Data for Name: assetentries_assettags; Type: TABLE DATA; Schema: public; Owner: root
--

COPY assetentries_assettags (entryid, tagid) FROM stdin;
\.


--
-- Data for Name: assetentry; Type: TABLE DATA; Schema: public; Owner: root
--

COPY assetentry (entryid, groupid, companyid, userid, username, createdate, modifieddate, classnameid, classpk, classuuid, classtypeid, visible, startdate, enddate, publishdate, expirationdate, mimetype, title, description, summary, url, layoutuuid, height, width, priority, viewcount) FROM stdin;
10277	10271	10253	10257		2017-03-10 17:05:22.832	2017-03-10 17:05:22.832	10217	10275	22a75647-9a8a-4d85-a818-9291a5c09d59	0	f	\N	\N	\N	\N	text/html	10274					0	0	0	0
10285	10279	10253	10257		2017-03-10 17:05:23.147	2017-03-10 17:05:23.147	10217	10283	7c2e79ce-8a32-4dac-b9f8-c922866592dc	0	f	\N	\N	\N	\N	text/html	10282					0	0	0	0
10301	10291	10253	10295	Test Test	2017-03-10 17:05:23.656	2017-03-10 17:05:23.656	10105	10295	08cd5606-630f-4638-9c6c-cd6f1f7f4ff3	0	f	\N	\N	\N	\N		Test Test					0	0	0	0
10417	10410	10253	10257		2017-03-10 17:05:25.474	2017-03-10 17:05:25.474	10217	10414	3fa48104-83c6-433e-93a8-9b75c6636da8	0	f	\N	\N	\N	\N	text/html	10413					0	0	0	0
10426	10420	10253	10257		2017-03-10 17:05:25.661	2017-03-10 17:05:25.661	10217	10424	34a976ce-bc77-4fd9-bb54-062edc16e09a	0	f	\N	\N	\N	\N	text/html	10423					0	0	0	0
10435	10429	10253	10257		2017-03-10 17:05:25.78	2017-03-10 17:05:25.78	10217	10433	6adb8b29-6599-4752-88e7-f28b33ebb5c8	0	f	\N	\N	\N	\N	text/html	10432					0	0	0	0
10449	10438	10253	10257		2017-03-10 17:05:26.282	2017-03-10 17:05:26.282	10217	10447	9a5e1725-0815-420a-b7c1-2106ebb236f9	0	f	\N	\N	\N	\N	text/html	10446					0	0	0	0
10455	10438	10253	10257		2017-03-10 17:05:26.46	2017-03-10 17:05:26.46	10217	10453	573f7ad3-4f27-44a5-8bab-c86f0b9abe98	0	f	\N	\N	\N	\N	text/html	10452					0	0	0	0
10461	10438	10253	10257		2017-03-10 17:05:26.561	2017-03-10 17:05:26.561	10217	10459	a29bb1f5-9ba4-4204-bc3f-357b715d9dbe	0	f	\N	\N	\N	\N	text/html	10458					0	0	0	0
10475	10464	10253	10257		2017-03-10 17:05:26.772	2017-03-10 17:05:26.772	10217	10473	a8ed1218-027b-439d-9ead-6e691d6c1002	0	f	\N	\N	\N	\N	text/html	10472					0	0	0	0
10483	10464	10253	10257		2017-03-10 17:05:26.875	2017-03-10 17:05:26.875	10217	10481	10eb2cf1-6178-4780-8b2a-c1a19778ca3a	0	f	\N	\N	\N	\N	text/html	10480					0	0	0	0
10489	10464	10253	10257		2017-03-10 17:05:26.949	2017-03-10 17:05:26.949	10217	10487	580db483-30b6-463d-a8e9-cc9865955ef5	0	f	\N	\N	\N	\N	text/html	10486					0	0	0	0
10495	10464	10253	10257		2017-03-10 17:05:27.038	2017-03-10 17:05:27.038	10217	10493	8178e9bc-31b8-4c86-b91e-21267ce644aa	0	f	\N	\N	\N	\N	text/html	10492					0	0	0	0
10520	10298	10253	10295	Test Test	2017-03-10 17:06:13.687	2017-03-10 17:06:13.687	10217	10518	4cb13faa-ee43-49f4-8e30-f3d1bc0554ca	0	f	\N	\N	\N	\N	text/html	10517					0	0	0	0
10525	10298	10253	10295	Test Test	2017-03-10 17:06:13.724	2017-03-10 17:06:13.724	10217	10523	104e298a-0a05-4b92-82d7-836281ee0a0f	0	f	\N	\N	\N	\N	text/html	10522					0	0	0	0
10540	10532	10253	10295	Test Test	2017-03-10 17:06:44.527	2017-03-10 17:06:44.527	10217	10538	6efb9fdf-62a2-4eed-b5a2-edd6ec8503e7	0	f	\N	\N	\N	\N	text/html	10537					0	0	0	0
10535	10291	10253	10295	Test Test	2017-03-10 17:06:29.978	2017-03-10 17:07:06.951	10101	10532		0	f	\N	\N	\N	\N		Staging Site					0	0	0	0
10546	10291	10253	10295	Test Test	2017-03-10 17:07:06.988	2017-03-10 17:07:06.988	10101	10543		0	f	\N	\N	\N	\N		Staging Site (Staging)					0	0	0	0
10577	10543	10253	10295	Test Test	2017-03-10 17:07:25.495	2017-03-10 17:07:25.495	10217	10575	b97e57cf-76b2-4b17-8db6-d8f7a18b7d39	0	f	\N	\N	\N	\N	text/html	10572					0	0	0	0
10574	10543	10253	10295	Test Test	2017-03-10 17:07:25.411	2017-03-10 17:07:25.411	10208	10572	6d0f5b38-eb73-4a3b-9930-fb4fe3917ceb	0	t	\N	\N	2017-03-10 17:07:00	\N	text/html	<?xml version='1.0' encoding='UTF-8'?><root available-locales="en_US" default-locale="en_US"><Title language-id="en_US">Web Content Title</Title></root>					0	0	0	1
\.


--
-- Data for Name: assetlink; Type: TABLE DATA; Schema: public; Owner: root
--

COPY assetlink (linkid, companyid, userid, username, createdate, entryid1, entryid2, type_, weight) FROM stdin;
\.


--
-- Data for Name: assettag; Type: TABLE DATA; Schema: public; Owner: root
--

COPY assettag (tagid, groupid, companyid, userid, username, createdate, modifieddate, name, assetcount) FROM stdin;
\.


--
-- Data for Name: assettagproperty; Type: TABLE DATA; Schema: public; Owner: root
--

COPY assettagproperty (tagpropertyid, companyid, userid, username, createdate, modifieddate, tagid, key_, value) FROM stdin;
\.


--
-- Data for Name: assettagstats; Type: TABLE DATA; Schema: public; Owner: root
--

COPY assettagstats (tagstatsid, tagid, classnameid, assetcount) FROM stdin;
\.


--
-- Data for Name: assetvocabulary; Type: TABLE DATA; Schema: public; Owner: root
--

COPY assetvocabulary (uuid_, vocabularyid, groupid, companyid, userid, username, createdate, modifieddate, name, title, description, settings_) FROM stdin;
61812103-7c3d-4b9e-a770-f7c6357a3b1f	10416	10291	10253	10257		2017-03-10 17:05:25.479	2017-03-10 17:05:25.479	Topic	<?xml version='1.0' encoding='UTF-8'?><root available-locales="en_US" default-locale="en_US"><Title language-id="en_US">Topic</Title></root>		
fb0e8044-dc99-4cc7-92ad-56125753a63d	10547	10532	10253	10257		2017-03-10 17:07:07.766	2017-03-10 17:07:07.766	Topic	<?xml version='1.0' encoding='UTF-8'?><root available-locales="en_US" default-locale="en_US"><Title language-id="en_US">Topic</Title></root>		
fb0e8044-dc99-4cc7-92ad-56125753a63d	10548	10543	10253	10257		2017-03-10 17:07:07.888	2017-03-10 17:07:07.888	Topic	<?xml version='1.0' encoding='UTF-8'?><root available-locales="en_US" default-locale="en_US"><Title language-id="en_US">Topic</Title></root>		
\.


--
-- Data for Name: blogsentry; Type: TABLE DATA; Schema: public; Owner: root
--

COPY blogsentry (uuid_, entryid, groupid, companyid, userid, username, createdate, modifieddate, title, urltitle, description, content, displaydate, allowpingbacks, allowtrackbacks, trackbacks, smallimage, smallimageid, smallimageurl, status, statusbyuserid, statusbyusername, statusdate) FROM stdin;
\.


--
-- Data for Name: blogsstatsuser; Type: TABLE DATA; Schema: public; Owner: root
--

COPY blogsstatsuser (statsuserid, groupid, companyid, userid, entrycount, lastpostdate, ratingstotalentries, ratingstotalscore, ratingsaveragescore) FROM stdin;
\.


--
-- Data for Name: bookmarksentry; Type: TABLE DATA; Schema: public; Owner: root
--

COPY bookmarksentry (uuid_, entryid, groupid, companyid, userid, username, createdate, modifieddate, resourceblockid, folderid, name, url, description, visits, priority) FROM stdin;
\.


--
-- Data for Name: bookmarksfolder; Type: TABLE DATA; Schema: public; Owner: root
--

COPY bookmarksfolder (uuid_, folderid, groupid, companyid, userid, username, createdate, modifieddate, resourceblockid, parentfolderid, name, description) FROM stdin;
\.


--
-- Data for Name: browsertracker; Type: TABLE DATA; Schema: public; Owner: root
--

COPY browsertracker (browsertrackerid, userid, browserkey) FROM stdin;
\.


--
-- Data for Name: calevent; Type: TABLE DATA; Schema: public; Owner: root
--

COPY calevent (uuid_, eventid, groupid, companyid, userid, username, createdate, modifieddate, title, description, location, startdate, enddate, durationhour, durationminute, allday, timezonesensitive, type_, repeating, recurrence, remindby, firstreminder, secondreminder) FROM stdin;
\.


--
-- Data for Name: classname_; Type: TABLE DATA; Schema: public; Owner: root
--

COPY classname_ (classnameid, value) FROM stdin;
10101	com.liferay.portal.model.Group
10102	com.liferay.portal.model.Layout
10103	com.liferay.portal.model.Organization
10104	com.liferay.portal.model.Role
10105	com.liferay.portal.model.User
10106	com.liferay.portal.model.UserGroup
10107	com.liferay.portlet.blogs.model.BlogsEntry
10108	com.liferay.portlet.bookmarks.model.BookmarksEntry
10109	com.liferay.portlet.calendar.model.CalEvent
10110	com.liferay.portlet.documentlibrary.model.DLFileEntry
10111	com.liferay.portlet.messageboards.model.MBMessage
10112	com.liferay.portlet.messageboards.model.MBThread
10113	com.liferay.portlet.wiki.model.WikiPage
10114	com.liferay.counter.model.Counter
10115	com.liferay.portal.kernel.workflow.WorkflowTask
10116	com.liferay.portal.model.Account
10117	com.liferay.portal.model.Address
10118	com.liferay.portal.model.BrowserTracker
10119	com.liferay.portal.model.ClassName
10120	com.liferay.portal.model.ClusterGroup
10121	com.liferay.portal.model.Company
10122	com.liferay.portal.model.Contact
10123	com.liferay.portal.model.Country
10124	com.liferay.portal.model.EmailAddress
10125	com.liferay.portal.model.Image
10126	com.liferay.portal.model.LayoutBranch
10127	com.liferay.portal.model.LayoutPrototype
10128	com.liferay.portal.model.LayoutRevision
10129	com.liferay.portal.model.LayoutSet
10130	com.liferay.portal.model.LayoutSetBranch
10131	com.liferay.portal.model.LayoutSetPrototype
10132	com.liferay.portal.model.ListType
10133	com.liferay.portal.model.Lock
10134	com.liferay.portal.model.MembershipRequest
10135	com.liferay.portal.model.OrgGroupPermission
10136	com.liferay.portal.model.OrgGroupRole
10137	com.liferay.portal.model.OrgLabor
10138	com.liferay.portal.model.PasswordPolicy
10139	com.liferay.portal.model.PasswordPolicyRel
10140	com.liferay.portal.model.PasswordTracker
10141	com.liferay.portal.model.Permission
10142	com.liferay.portal.model.Phone
10143	com.liferay.portal.model.PluginSetting
10144	com.liferay.portal.model.PortalPreferences
10145	com.liferay.portal.model.Portlet
10146	com.liferay.portal.model.PortletItem
10147	com.liferay.portal.model.PortletPreferences
10148	com.liferay.portal.model.Region
10149	com.liferay.portal.model.Release
10150	com.liferay.portal.model.Repository
10151	com.liferay.portal.model.RepositoryEntry
10152	com.liferay.portal.model.Resource
10153	com.liferay.portal.model.ResourceAction
10154	com.liferay.portal.model.ResourceBlock
10155	com.liferay.portal.model.ResourceBlockPermission
10156	com.liferay.portal.model.ResourceCode
10157	com.liferay.portal.model.ResourcePermission
10158	com.liferay.portal.model.ResourceTypePermission
10159	com.liferay.portal.model.ServiceComponent
10160	com.liferay.portal.model.Shard
10161	com.liferay.portal.model.Subscription
10162	com.liferay.portal.model.Team
10163	com.liferay.portal.model.Ticket
10164	com.liferay.portal.model.UserGroupGroupRole
10165	com.liferay.portal.model.UserGroupRole
10166	com.liferay.portal.model.UserIdMapper
10167	com.liferay.portal.model.UserNotificationEvent
10168	com.liferay.portal.model.UserTracker
10169	com.liferay.portal.model.UserTrackerPath
10170	com.liferay.portal.model.VirtualHost
10171	com.liferay.portal.model.WebDAVProps
10172	com.liferay.portal.model.Website
10173	com.liferay.portal.model.WorkflowDefinitionLink
10174	com.liferay.portal.model.WorkflowInstanceLink
10175	com.liferay.portlet.announcements.model.AnnouncementsDelivery
10176	com.liferay.portlet.announcements.model.AnnouncementsEntry
10177	com.liferay.portlet.announcements.model.AnnouncementsFlag
10178	com.liferay.portlet.asset.model.AssetCategory
10179	com.liferay.portlet.asset.model.AssetCategoryProperty
10180	com.liferay.portlet.asset.model.AssetEntry
10181	com.liferay.portlet.asset.model.AssetLink
10182	com.liferay.portlet.asset.model.AssetTag
10183	com.liferay.portlet.asset.model.AssetTagProperty
10184	com.liferay.portlet.asset.model.AssetTagStats
10185	com.liferay.portlet.asset.model.AssetVocabulary
10186	com.liferay.portlet.blogs.model.BlogsStatsUser
10187	com.liferay.portlet.bookmarks.model.BookmarksFolder
10188	com.liferay.portlet.documentlibrary.model.DLContent
10189	com.liferay.portlet.documentlibrary.model.DLFileEntryMetadata
10190	com.liferay.portlet.documentlibrary.model.DLFileEntryType
10191	com.liferay.portlet.documentlibrary.model.DLFileRank
10192	com.liferay.portlet.documentlibrary.model.DLFileShortcut
10193	com.liferay.portlet.documentlibrary.model.DLFileVersion
10194	com.liferay.portlet.documentlibrary.model.DLFolder
10195	com.liferay.portlet.documentlibrary.model.DLSync
10196	com.liferay.portlet.dynamicdatalists.model.DDLRecord
10197	com.liferay.portlet.dynamicdatalists.model.DDLRecordSet
10198	com.liferay.portlet.dynamicdatalists.model.DDLRecordVersion
10199	com.liferay.portlet.dynamicdatamapping.model.DDMContent
10200	com.liferay.portlet.dynamicdatamapping.model.DDMStorageLink
10201	com.liferay.portlet.dynamicdatamapping.model.DDMStructure
10202	com.liferay.portlet.dynamicdatamapping.model.DDMStructureLink
10203	com.liferay.portlet.dynamicdatamapping.model.DDMTemplate
10204	com.liferay.portlet.expando.model.ExpandoColumn
10205	com.liferay.portlet.expando.model.ExpandoRow
10206	com.liferay.portlet.expando.model.ExpandoTable
10207	com.liferay.portlet.expando.model.ExpandoValue
10208	com.liferay.portlet.journal.model.JournalArticle
10209	com.liferay.portlet.journal.model.JournalArticleImage
10210	com.liferay.portlet.journal.model.JournalArticleResource
10211	com.liferay.portlet.journal.model.JournalContentSearch
10212	com.liferay.portlet.journal.model.JournalFeed
10213	com.liferay.portlet.journal.model.JournalStructure
10214	com.liferay.portlet.journal.model.JournalTemplate
10215	com.liferay.portlet.messageboards.model.MBBan
10216	com.liferay.portlet.messageboards.model.MBCategory
10217	com.liferay.portlet.messageboards.model.MBDiscussion
10218	com.liferay.portlet.messageboards.model.MBMailingList
10219	com.liferay.portlet.messageboards.model.MBStatsUser
10220	com.liferay.portlet.messageboards.model.MBThreadFlag
10221	com.liferay.portlet.mobiledevicerules.model.MDRAction
10222	com.liferay.portlet.mobiledevicerules.model.MDRRule
10223	com.liferay.portlet.mobiledevicerules.model.MDRRuleGroup
10224	com.liferay.portlet.mobiledevicerules.model.MDRRuleGroupInstance
10225	com.liferay.portlet.polls.model.PollsChoice
10226	com.liferay.portlet.polls.model.PollsQuestion
10227	com.liferay.portlet.polls.model.PollsVote
10228	com.liferay.portlet.ratings.model.RatingsEntry
10229	com.liferay.portlet.ratings.model.RatingsStats
10230	com.liferay.portlet.shopping.model.ShoppingCart
10231	com.liferay.portlet.shopping.model.ShoppingCategory
10232	com.liferay.portlet.shopping.model.ShoppingCoupon
10233	com.liferay.portlet.shopping.model.ShoppingItem
10234	com.liferay.portlet.shopping.model.ShoppingItemField
10235	com.liferay.portlet.shopping.model.ShoppingItemPrice
10236	com.liferay.portlet.shopping.model.ShoppingOrder
10237	com.liferay.portlet.shopping.model.ShoppingOrderItem
10238	com.liferay.portlet.social.model.SocialActivity
10239	com.liferay.portlet.social.model.SocialActivityAchievement
10240	com.liferay.portlet.social.model.SocialActivityCounter
10241	com.liferay.portlet.social.model.SocialActivityLimit
10242	com.liferay.portlet.social.model.SocialActivitySetting
10243	com.liferay.portlet.social.model.SocialRelation
10244	com.liferay.portlet.social.model.SocialRequest
10245	com.liferay.portlet.softwarecatalog.model.SCFrameworkVersion
10246	com.liferay.portlet.softwarecatalog.model.SCLicense
10247	com.liferay.portlet.softwarecatalog.model.SCProductEntry
10248	com.liferay.portlet.softwarecatalog.model.SCProductScreenshot
10249	com.liferay.portlet.softwarecatalog.model.SCProductVersion
10250	com.liferay.portlet.usernotifications.model.UserNotificationEvent
10251	com.liferay.portlet.wiki.model.WikiNode
10252	com.liferay.portlet.wiki.model.WikiPageResource
10287	com.liferay.portal.model.UserPersonalSite
10507	com.liferay.marketplace.model.App
10508	com.liferay.marketplace.model.Module
\.


--
-- Data for Name: clustergroup; Type: TABLE DATA; Schema: public; Owner: root
--

COPY clustergroup (clustergroupid, name, clusternodeids, wholecluster) FROM stdin;
\.


--
-- Data for Name: company; Type: TABLE DATA; Schema: public; Owner: root
--

COPY company (companyid, accountid, webid, key_, mx, homeurl, logoid, system, maxusers, active_) FROM stdin;
10253	10255	liferay.com	rO0ABXNyABRqYXZhLnNlY3VyaXR5LktleVJlcL35T7OImqVDAgAETAAJYWxnb3JpdGhtdAASTGphdmEvbGFuZy9TdHJpbmc7WwAHZW5jb2RlZHQAAltCTAAGZm9ybWF0cQB+AAFMAAR0eXBldAAbTGphdmEvc2VjdXJpdHkvS2V5UmVwJFR5cGU7eHB0AANERVN1cgACW0Ks8xf4BghU4AIAAHhwAAAACDdXy1hFSpjqdAADUkFXfnIAGWphdmEuc2VjdXJpdHkuS2V5UmVwJFR5cGUAAAAAAAAAABIAAHhyAA5qYXZhLmxhbmcuRW51bQAAAAAAAAAAEgAAeHB0AAZTRUNSRVQ=	liferay.com		0	f	0	t
\.


--
-- Data for Name: contact_; Type: TABLE DATA; Schema: public; Owner: root
--

COPY contact_ (contactid, companyid, userid, username, createdate, modifieddate, accountid, parentcontactid, firstname, middlename, lastname, prefixid, suffixid, male, birthday, smssn, aimsn, facebooksn, icqsn, jabbersn, msnsn, myspacesn, skypesn, twittersn, ymsn, employeestatusid, employeenumber, jobtitle, jobclass, hoursofoperation) FROM stdin;
10258	10253	10257		2017-03-10 17:05:21.612	2017-03-10 17:05:21.612	10255	0				0	0	t	2017-03-10 17:05:21.612															
10296	10253	10295		2017-03-10 17:05:23.656	2017-03-10 17:05:23.656	10255	0	Test		Test	0	0	t	1970-01-01 00:00:00															
\.


--
-- Data for Name: counter; Type: TABLE DATA; Schema: public; Owner: root
--

COPY counter (name, currentid) FROM stdin;
com.liferay.portal.model.Resource	100
com.liferay.portal.model.Permission	100
com.liferay.portal.model.ResourceAction	900
com.liferay.portal.model.Layout#10271#true	1
com.liferay.portal.model.Layout#10279#false	1
com.liferay.portal.model.Layout#10410#true	1
com.liferay.portal.model.Layout#10420#true	1
com.liferay.portal.model.Layout#10429#true	1
com.liferay.portal.model.Layout#10438#true	3
com.liferay.portal.model.Layout#10464#true	4
com.liferay.counter.model.Counter	10600
com.liferay.portal.model.Layout#10298#true	1
com.liferay.portal.model.Layout#10298#false	1
com.liferay.portal.model.Layout#10532#false	1
com.liferay.portal.model.Layout#10543#false	1
com.liferay.portal.model.ResourcePermission	600
\.


--
-- Data for Name: country; Type: TABLE DATA; Schema: public; Owner: root
--

COPY country (countryid, name, a2, a3, number_, idd_, ziprequired, active_) FROM stdin;
1	Canada	CA	CAN	124	001	t	t
2	China	CN	CHN	156	086	t	t
3	France	FR	FRA	250	033	t	t
4	Germany	DE	DEU	276	049	t	t
5	Hong Kong	HK	HKG	344	852	t	t
6	Hungary	HU	HUN	348	036	t	t
7	Israel	IL	ISR	376	972	t	t
8	Italy	IT	ITA	380	039	t	t
9	Japan	JP	JPN	392	081	t	t
10	South Korea	KR	KOR	410	082	t	t
11	Netherlands	NL	NLD	528	031	t	t
12	Portugal	PT	PRT	620	351	t	t
13	Russia	RU	RUS	643	007	t	t
14	Singapore	SG	SGP	702	065	t	t
15	Spain	ES	ESP	724	034	t	t
16	Turkey	TR	TUR	792	090	t	t
17	Vietnam	VN	VNM	704	084	t	t
18	United Kingdom	GB	GBR	826	044	t	t
19	United States	US	USA	840	001	t	t
20	Afghanistan	AF	AFG	4	093	t	t
21	Albania	AL	ALB	8	355	t	t
22	Algeria	DZ	DZA	12	213	t	t
23	American Samoa	AS	ASM	16	684	t	t
24	Andorra	AD	AND	20	376	t	t
25	Angola	AO	AGO	24	244	f	t
26	Anguilla	AI	AIA	660	264	t	t
27	Antarctica	AQ	ATA	10	672	t	t
28	Antigua	AG	ATG	28	268	f	t
29	Argentina	AR	ARG	32	054	t	t
30	Armenia	AM	ARM	51	374	t	t
31	Aruba	AW	ABW	533	297	f	t
32	Australia	AU	AUS	36	061	t	t
33	Austria	AT	AUT	40	043	t	t
34	Azerbaijan	AZ	AZE	31	994	t	t
35	Bahamas	BS	BHS	44	242	f	t
36	Bahrain	BH	BHR	48	973	t	t
37	Bangladesh	BD	BGD	50	880	t	t
38	Barbados	BB	BRB	52	246	t	t
39	Belarus	BY	BLR	112	375	t	t
40	Belgium	BE	BEL	56	032	t	t
41	Belize	BZ	BLZ	84	501	f	t
42	Benin	BJ	BEN	204	229	f	t
43	Bermuda	BM	BMU	60	441	t	t
44	Bhutan	BT	BTN	64	975	t	t
45	Bolivia	BO	BOL	68	591	t	t
46	Bosnia-Herzegovina	BA	BIH	70	387	t	t
47	Botswana	BW	BWA	72	267	f	t
48	Brazil	BR	BRA	76	055	t	t
49	British Virgin Islands	VG	VGB	92	284	t	t
50	Brunei	BN	BRN	96	673	t	t
51	Bulgaria	BG	BGR	100	359	t	t
52	Burkina Faso	BF	BFA	854	226	f	t
53	Burma (Myanmar)	MM	MMR	104	095	t	t
54	Burundi	BI	BDI	108	257	f	t
55	Cambodia	KH	KHM	116	855	t	t
56	Cameroon	CM	CMR	120	237	t	t
57	Cape Verde Island	CV	CPV	132	238	t	t
58	Cayman Islands	KY	CYM	136	345	t	t
59	Central African Republic	CF	CAF	140	236	f	t
60	Chad	TD	TCD	148	235	t	t
61	Chile	CL	CHL	152	056	t	t
62	Christmas Island	CX	CXR	162	061	t	t
63	Cocos Islands	CC	CCK	166	061	t	t
64	Colombia	CO	COL	170	057	t	t
65	Comoros	KM	COM	174	269	f	t
66	Republic of Congo	CD	COD	180	242	f	t
67	Democratic Republic of Congo	CG	COG	178	243	f	t
68	Cook Islands	CK	COK	184	682	f	t
69	Costa Rica	CR	CRI	188	506	t	t
70	Croatia	HR	HRV	191	385	t	t
71	Cuba	CU	CUB	192	053	t	t
72	Cyprus	CY	CYP	196	357	t	t
73	Czech Republic	CZ	CZE	203	420	t	t
74	Denmark	DK	DNK	208	045	t	t
75	Djibouti	DJ	DJI	262	253	f	t
76	Dominica	DM	DMA	212	767	f	t
77	Dominican Republic	DO	DOM	214	809	t	t
78	Ecuador	EC	ECU	218	593	t	t
79	Egypt	EG	EGY	818	020	t	t
80	El Salvador	SV	SLV	222	503	t	t
81	Equatorial Guinea	GQ	GNQ	226	240	f	t
82	Eritrea	ER	ERI	232	291	f	t
83	Estonia	EE	EST	233	372	t	t
84	Ethiopia	ET	ETH	231	251	t	t
85	Faeroe Islands	FO	FRO	234	298	t	t
86	Falkland Islands	FK	FLK	238	500	t	t
87	Fiji Islands	FJ	FJI	242	679	f	t
88	Finland	FI	FIN	246	358	t	t
89	French Guiana	GF	GUF	254	594	t	t
90	French Polynesia	PF	PYF	258	689	t	t
91	Gabon	GA	GAB	266	241	t	t
92	Gambia	GM	GMB	270	220	f	t
93	Georgia	GE	GEO	268	995	t	t
94	Ghana	GH	GHA	288	233	f	t
95	Gibraltar	GI	GIB	292	350	t	t
96	Greece	GR	GRC	300	030	t	t
97	Greenland	GL	GRL	304	299	t	t
98	Grenada	GD	GRD	308	473	f	t
99	Guadeloupe	GP	GLP	312	590	t	t
100	Guam	GU	GUM	316	671	t	t
101	Guatemala	GT	GTM	320	502	t	t
102	Guinea	GN	GIN	324	224	f	t
103	Guinea-Bissau	GW	GNB	624	245	t	t
104	Guyana	GY	GUY	328	592	f	t
105	Haiti	HT	HTI	332	509	t	t
106	Honduras	HN	HND	340	504	t	t
107	Iceland	IS	ISL	352	354	t	t
108	India	IN	IND	356	091	t	t
109	Indonesia	ID	IDN	360	062	t	t
110	Iran	IR	IRN	364	098	t	t
111	Iraq	IQ	IRQ	368	964	t	t
112	Ireland	IE	IRL	372	353	f	t
113	Ivory Coast	CI	CIV	384	225	t	t
114	Jamaica	JM	JAM	388	876	t	t
115	Jordan	JO	JOR	400	962	t	t
116	Kazakhstan	KZ	KAZ	398	007	t	t
117	Kenya	KE	KEN	404	254	t	t
118	Kiribati	KI	KIR	408	686	f	t
119	Kuwait	KW	KWT	414	965	t	t
120	North Korea	KP	PRK	408	850	f	t
121	Kyrgyzstan	KG	KGZ	471	996	t	t
122	Laos	LA	LAO	418	856	t	t
123	Latvia	LV	LVA	428	371	t	t
124	Lebanon	LB	LBN	422	961	t	t
125	Lesotho	LS	LSO	426	266	t	t
126	Liberia	LR	LBR	430	231	t	t
127	Libya	LY	LBY	434	218	t	t
128	Liechtenstein	LI	LIE	438	423	t	t
129	Lithuania	LT	LTU	440	370	t	t
130	Luxembourg	LU	LUX	442	352	t	t
131	Macau	MO	MAC	446	853	f	t
132	Macedonia	MK	MKD	807	389	t	t
133	Madagascar	MG	MDG	450	261	t	t
134	Malawi	MW	MWI	454	265	f	t
135	Malaysia	MY	MYS	458	060	t	t
136	Maldives	MV	MDV	462	960	t	t
137	Mali	ML	MLI	466	223	f	t
138	Malta	MT	MLT	470	356	t	t
139	Marshall Islands	MH	MHL	584	692	t	t
140	Martinique	MQ	MTQ	474	596	t	t
141	Mauritania	MR	MRT	478	222	f	t
142	Mauritius	MU	MUS	480	230	f	t
143	Mayotte Island	YT	MYT	175	269	t	t
144	Mexico	MX	MEX	484	052	t	t
145	Micronesia	FM	FSM	583	691	t	t
146	Moldova	MD	MDA	498	373	t	t
147	Monaco	MC	MCO	492	377	t	t
148	Mongolia	MN	MNG	496	976	t	t
149	Montenegro	ME	MNE	499	382	t	t
150	Montserrat	MS	MSR	500	664	f	t
151	Morocco	MA	MAR	504	212	t	t
152	Mozambique	MZ	MOZ	508	258	t	t
153	Namibia	NA	NAM	516	264	t	t
154	Nauru	NR	NRU	520	674	f	t
155	Nepal	NP	NPL	524	977	t	t
156	Netherlands Antilles	AN	ANT	530	599	t	t
157	New Caledonia	NC	NCL	540	687	t	t
158	New Zealand	NZ	NZL	554	064	t	t
159	Nicaragua	NI	NIC	558	505	t	t
160	Niger	NE	NER	562	227	t	t
161	Nigeria	NG	NGA	566	234	t	t
162	Niue	NU	NIU	570	683	f	t
163	Norfolk Island	NF	NFK	574	672	t	t
164	Norway	NO	NOR	578	047	t	t
165	Oman	OM	OMN	512	968	t	t
166	Pakistan	PK	PAK	586	092	t	t
167	Palau	PW	PLW	585	680	t	t
168	Palestine	PS	PSE	275	970	t	t
169	Panama	PA	PAN	591	507	t	t
170	Papua New Guinea	PG	PNG	598	675	t	t
171	Paraguay	PY	PRY	600	595	t	t
172	Peru	PE	PER	604	051	t	t
173	Philippines	PH	PHL	608	063	t	t
174	Poland	PL	POL	616	048	t	t
175	Puerto Rico	PR	PRI	630	787	t	t
176	Qatar	QA	QAT	634	974	f	t
177	Reunion Island	RE	REU	638	262	t	t
178	Romania	RO	ROU	642	040	t	t
179	Rwanda	RW	RWA	646	250	f	t
180	St. Helena	SH	SHN	654	290	t	t
181	St. Kitts	KN	KNA	659	869	f	t
182	St. Lucia	LC	LCA	662	758	f	t
183	St. Pierre & Miquelon	PM	SPM	666	508	t	t
184	St. Vincent	VC	VCT	670	784	t	t
185	San Marino	SM	SMR	674	378	t	t
186	Sao Tome & Principe	ST	STP	678	239	f	t
187	Saudi Arabia	SA	SAU	682	966	t	t
188	Senegal	SN	SEN	686	221	t	t
189	Serbia	RS	SRB	688	381	t	t
190	Seychelles	SC	SYC	690	248	f	t
191	Sierra Leone	SL	SLE	694	249	f	t
192	Slovakia	SK	SVK	703	421	t	t
193	Slovenia	SI	SVN	705	386	t	t
194	Solomon Islands	SB	SLB	90	677	f	t
195	Somalia	SO	SOM	706	252	f	t
196	South Africa	ZA	ZAF	710	027	t	t
197	Sri Lanka	LK	LKA	144	094	t	t
198	Sudan	SD	SDN	736	095	t	t
199	Suriname	SR	SUR	740	597	f	t
200	Swaziland	SZ	SWZ	748	268	t	t
201	Sweden	SE	SWE	752	046	t	t
202	Switzerland	CH	CHE	756	041	t	t
203	Syria	SY	SYR	760	963	f	t
204	Taiwan	TW	TWN	158	886	t	t
205	Tajikistan	TJ	TJK	762	992	t	t
206	Tanzania	TZ	TZA	834	255	f	t
207	Thailand	TH	THA	764	066	t	t
208	Togo	TG	TGO	768	228	t	t
209	Tonga	TO	TON	776	676	f	t
210	Trinidad & Tobago	TT	TTO	780	868	f	t
211	Tunisia	TN	TUN	788	216	t	t
212	Turkmenistan	TM	TKM	795	993	t	t
213	Turks & Caicos	TC	TCA	796	649	t	t
214	Tuvalu	TV	TUV	798	688	f	t
215	Uganda	UG	UGA	800	256	f	t
216	Ukraine	UA	UKR	804	380	t	t
217	United Arab Emirates	AE	ARE	784	971	f	t
218	Uruguay	UY	URY	858	598	t	t
219	Uzbekistan	UZ	UZB	860	998	t	t
220	Vanuatu	VU	VUT	548	678	f	t
221	Vatican City	VA	VAT	336	039	t	t
222	Venezuela	VE	VEN	862	058	t	t
223	Wallis & Futuna	WF	WLF	876	681	t	t
224	Western Samoa	EH	ESH	732	685	t	t
225	Yemen	YE	YEM	887	967	f	t
226	Zambia	ZM	ZMB	894	260	t	t
227	Zimbabwe	ZW	ZWE	716	263	f	t
\.


--
-- Data for Name: cyrususer; Type: TABLE DATA; Schema: public; Owner: root
--

COPY cyrususer (userid, password_) FROM stdin;
\.


--
-- Data for Name: cyrusvirtual; Type: TABLE DATA; Schema: public; Owner: root
--

COPY cyrusvirtual (emailaddress, userid) FROM stdin;
\.


--
-- Data for Name: ddlrecord; Type: TABLE DATA; Schema: public; Owner: root
--

COPY ddlrecord (uuid_, recordid, groupid, companyid, userid, username, versionuserid, versionusername, createdate, modifieddate, ddmstorageid, recordsetid, version, displayindex) FROM stdin;
\.


--
-- Data for Name: ddlrecordset; Type: TABLE DATA; Schema: public; Owner: root
--

COPY ddlrecordset (uuid_, recordsetid, groupid, companyid, userid, username, createdate, modifieddate, ddmstructureid, recordsetkey, name, description, mindisplayrows, scope) FROM stdin;
\.


--
-- Data for Name: ddlrecordversion; Type: TABLE DATA; Schema: public; Owner: root
--

COPY ddlrecordversion (recordversionid, groupid, companyid, userid, username, createdate, ddmstorageid, recordsetid, recordid, version, displayindex, status, statusbyuserid, statusbyusername, statusdate) FROM stdin;
\.


--
-- Data for Name: ddmcontent; Type: TABLE DATA; Schema: public; Owner: root
--

COPY ddmcontent (uuid_, contentid, groupid, companyid, userid, username, createdate, modifieddate, name, description, xml) FROM stdin;
\.


--
-- Data for Name: ddmstoragelink; Type: TABLE DATA; Schema: public; Owner: root
--

COPY ddmstoragelink (uuid_, storagelinkid, classnameid, classpk, structureid) FROM stdin;
\.


--
-- Data for Name: ddmstructure; Type: TABLE DATA; Schema: public; Owner: root
--

COPY ddmstructure (uuid_, structureid, groupid, companyid, userid, username, createdate, modifieddate, classnameid, structurekey, name, description, xsd, storagetype, type_) FROM stdin;
42292845-e13c-4b8e-a063-361309c4c878	10397	10291	10253	10257		2017-03-10 17:05:25.1	2017-03-10 17:05:25.1	10189	Learning Module Metadata	<?xml version='1.0' encoding='UTF-8'?><root available-locales="en_US" default-locale="en_US"><Name language-id="en_US">Learning Module Metadata</Name></root>	<?xml version='1.0' encoding='UTF-8'?><root available-locales="en_US" default-locale="en_US"><Description language-id="en_US">Learning Module Metadata</Description></root>	<?xml version="1.0"?>\n\n<root available-locales="en_US" default-locale="en_US">\n\t<dynamic-element dataType="string" name="select2235" type="select">\n\t\t<dynamic-element name="home_edition" type="option" value="HE">\n\t\t\t<meta-data locale="en_US">\n\t\t\t\t<entry name="label"><![CDATA[Home Edition]]></entry>\n\t\t\t\t<entry name="multiple"><![CDATA[false]]></entry>\n\t\t\t</meta-data>\n\t\t</dynamic-element>\n\t\t<dynamic-element name="business_edition" type="option" value="BE">\n\t\t\t<meta-data locale="en_US">\n\t\t\t\t<entry name="label"><![CDATA[Business Edition]]></entry>\n\t\t\t</meta-data>\n\t\t</dynamic-element>\n\t\t<dynamic-element name="enterprise_edition" type="option" value="EE">\n\t\t\t<meta-data locale="en_US">\n\t\t\t\t<entry name="label"><![CDATA[Enterprise Edition]]></entry>\n\t\t\t</meta-data>\n\t\t</dynamic-element>\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="displayChildLabelAsValue"><![CDATA[true]]></entry>\n\t\t\t<entry name="label"><![CDATA[Product]]></entry>\n\t\t\t<entry name="multiple"><![CDATA[true]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="readOnly"><![CDATA[false]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t\t<entry name="tip"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="select3212" type="select">\n\t\t<dynamic-element name="1_0" type="option" value="1">\n\t\t\t<meta-data locale="en_US">\n\t\t\t\t<entry name="label"><![CDATA[1.0]]></entry>\n\t\t\t\t<entry name="multiple"><![CDATA[false]]></entry>\n\t\t\t</meta-data>\n\t\t</dynamic-element>\n\t\t<dynamic-element name="2_0" type="option" value="2">\n\t\t\t<meta-data locale="en_US">\n\t\t\t\t<entry name="label"><![CDATA[2.0]]></entry>\n\t\t\t</meta-data>\n\t\t</dynamic-element>\n\t\t<dynamic-element name="3_0" type="option" value="3">\n\t\t\t<meta-data locale="en_US">\n\t\t\t\t<entry name="label"><![CDATA[3.0]]></entry>\n\t\t\t</meta-data>\n\t\t</dynamic-element>\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="displayChildLabelAsValue"><![CDATA[true]]></entry>\n\t\t\t<entry name="label"><![CDATA[Version]]></entry>\n\t\t\t<entry name="multiple"><![CDATA[true]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="readOnly"><![CDATA[false]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t\t<entry name="tip"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="select4115" type="select">\n\t\t<dynamic-element name="administration" type="option" value="admin">\n\t\t\t<meta-data locale="en_US">\n\t\t\t\t<entry name="label"><![CDATA[Administration]]></entry>\n\t\t\t\t<entry name="multiple"><![CDATA[false]]></entry>\n\t\t\t</meta-data>\n\t\t</dynamic-element>\n\t\t<dynamic-element name="installation" type="option" value="install">\n\t\t\t<meta-data locale="en_US">\n\t\t\t\t<entry name="label"><![CDATA[Installation]]></entry>\n\t\t\t</meta-data>\n\t\t</dynamic-element>\n\t\t<dynamic-element name="configuration" type="option" value="config">\n\t\t\t<meta-data locale="en_US">\n\t\t\t\t<entry name="label"><![CDATA[Configuration]]></entry>\n\t\t\t</meta-data>\n\t\t</dynamic-element>\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="displayChildLabelAsValue"><![CDATA[true]]></entry>\n\t\t\t<entry name="label"><![CDATA[Topics]]></entry>\n\t\t\t<entry name="multiple"><![CDATA[true]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="readOnly"><![CDATA[false]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t\t<entry name="tip"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="select5069" type="select">\n\t\t<dynamic-element name="beginner" type="option" value="beginner">\n\t\t\t<meta-data locale="en_US">\n\t\t\t\t<entry name="label"><![CDATA[Beginner]]></entry>\n\t\t\t\t<entry name="multiple"><![CDATA[false]]></entry>\n\t\t\t</meta-data>\n\t\t</dynamic-element>\n\t\t<dynamic-element name="intermediate" type="option" value="intermediate">\n\t\t\t<meta-data locale="en_US">\n\t\t\t\t<entry name="label"><![CDATA[Intermediate]]></entry>\n\t\t\t</meta-data>\n\t\t</dynamic-element>\n\t\t<dynamic-element name="advanced" type="option" value="advanced">\n\t\t\t<meta-data locale="en_US">\n\t\t\t\t<entry name="label"><![CDATA[Advanced]]></entry>\n\t\t\t</meta-data>\n\t\t</dynamic-element>\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="displayChildLabelAsValue"><![CDATA[true]]></entry>\n\t\t\t<entry name="label"><![CDATA[Level]]></entry>\n\t\t\t<entry name="multiple"><![CDATA[false]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="readOnly"><![CDATA[false]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t\t<entry name="tip"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n</root>	xml	0
6572f143-9214-4ab7-a837-c18a186625a5	10398	10291	10253	10257		2017-03-10 17:05:25.126	2017-03-10 17:05:25.126	10189	Marketing Campaign Theme Metadata	<?xml version='1.0' encoding='UTF-8'?><root available-locales="en_US" default-locale="en_US"><Name language-id="en_US">Marketing Campaign Theme Metadata</Name></root>	<?xml version='1.0' encoding='UTF-8'?><root available-locales="en_US" default-locale="en_US"><Description language-id="en_US">Marketing Campaign Theme Metadata</Description></root>	<?xml version="1.0"?>\n\n<root available-locales="en_US" default-locale="en_US">\n\t<dynamic-element dataType="string" name="select2305" type="select">\n\t\t<dynamic-element name="strong_company" type="option" value="strong">\n\t\t\t<meta-data locale="en_US">\n\t\t\t\t<entry name="label"><![CDATA[Strong Company]]></entry>\n\t\t\t\t<entry name="multiple"><![CDATA[false]]></entry>\n\t\t\t</meta-data>\n\t\t</dynamic-element>\n\t\t<dynamic-element name="new_product_launch" type="option" value="product">\n\t\t\t<meta-data locale="en_US">\n\t\t\t\t<entry name="label"><![CDATA[New Product Launch]]></entry>\n\t\t\t</meta-data>\n\t\t</dynamic-element>\n\t\t<dynamic-element name="company_philosophy" type="option" value="philosophy">\n\t\t\t<meta-data locale="en_US">\n\t\t\t\t<entry name="label"><![CDATA[Company Philosophy]]></entry>\n\t\t\t</meta-data>\n\t\t</dynamic-element>\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="displayChildLabelAsValue"><![CDATA[true]]></entry>\n\t\t\t<entry name="label"><![CDATA[Select]]></entry>\n\t\t\t<entry name="multiple"><![CDATA[false]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="readOnly"><![CDATA[false]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t\t<entry name="tip"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="select3229" type="select">\n\t\t<dynamic-element name="your_trusted_advisor" type="option" value="advisor">\n\t\t\t<meta-data locale="en_US">\n\t\t\t\t<entry name="label"><![CDATA[Your Trusted Advisor]]></entry>\n\t\t\t\t<entry name="multiple"><![CDATA[false]]></entry>\n\t\t\t</meta-data>\n\t\t</dynamic-element>\n\t\t<dynamic-element name="10_years_of_customer_solutions" type="option" value="solutions">\n\t\t\t<meta-data locale="en_US">\n\t\t\t\t<entry name="label"><![CDATA[10 Years of Customer Solutions]]></entry>\n\t\t\t</meta-data>\n\t\t</dynamic-element>\n\t\t<dynamic-element name="making_a_difference" type="option" value="difference">\n\t\t\t<meta-data locale="en_US">\n\t\t\t\t<entry name="label"><![CDATA[Making a Difference]]></entry>\n\t\t\t</meta-data>\n\t\t</dynamic-element>\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="displayChildLabelAsValue"><![CDATA[true]]></entry>\n\t\t\t<entry name="label"><![CDATA[Campaign Theme]]></entry>\n\t\t\t<entry name="multiple"><![CDATA[false]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="readOnly"><![CDATA[false]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t\t<entry name="tip"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="select4282" type="select">\n\t\t<dynamic-element name="awareness" type="option" value="awareness">\n\t\t\t<meta-data locale="en_US">\n\t\t\t\t<entry name="label"><![CDATA[Awareness]]></entry>\n\t\t\t\t<entry name="multiple"><![CDATA[false]]></entry>\n\t\t\t</meta-data>\n\t\t</dynamic-element>\n\t\t<dynamic-element name="lead_generation" type="option" value="leads">\n\t\t\t<meta-data locale="en_US">\n\t\t\t\t<entry name="label"><![CDATA[Lead Generation]]></entry>\n\t\t\t</meta-data>\n\t\t</dynamic-element>\n\t\t<dynamic-element name="customer_service" type="option" value="service">\n\t\t\t<meta-data locale="en_US">\n\t\t\t\t<entry name="label"><![CDATA[Customer Service]]></entry>\n\t\t\t</meta-data>\n\t\t</dynamic-element>\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="displayChildLabelAsValue"><![CDATA[true]]></entry>\n\t\t\t<entry name="label"><![CDATA[Business Goal]]></entry>\n\t\t\t<entry name="multiple"><![CDATA[false]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="readOnly"><![CDATA[false]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t\t<entry name="tip"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n</root>	xml	0
59206de2-7774-4ec2-8fda-53d9a39e660c	10399	10291	10253	10257		2017-03-10 17:05:25.151	2017-03-10 17:05:25.151	10189	Meeting Metadata	<?xml version='1.0' encoding='UTF-8'?><root available-locales="en_US" default-locale="en_US"><Name language-id="en_US">Meeting Metadata</Name></root>	<?xml version='1.0' encoding='UTF-8'?><root available-locales="en_US" default-locale="en_US"><Description language-id="en_US">Metadata for meeting</Description></root>	<?xml version="1.0"?>\n\n<root available-locales="en_US" default-locale="en_US">\n\t<dynamic-element dataType="date" fieldNamespace="ddm" name="ddm-date3054" type="ddm-date">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="fieldCssClass"><![CDATA[aui-w25]]></entry>\n\t\t\t<entry name="label"><![CDATA[Date]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="readOnly"><![CDATA[false]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t\t<entry name="tip"><![CDATA[]]></entry>\n\t\t\t<entry name="width"><![CDATA[25]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="text2217" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="fieldCssClass"><![CDATA[aui-w25]]></entry>\n\t\t\t<entry name="label"><![CDATA[Meeting Name]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="readOnly"><![CDATA[false]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t\t<entry name="tip"><![CDATA[]]></entry>\n\t\t\t<entry name="width"><![CDATA[25]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="text4569" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="fieldCssClass"><![CDATA[aui-w25]]></entry>\n\t\t\t<entry name="label"><![CDATA[Time]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="readOnly"><![CDATA[false]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t\t<entry name="tip"><![CDATA[]]></entry>\n\t\t\t<entry name="width"><![CDATA[25]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="text5638" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="fieldCssClass"><![CDATA[aui-w25]]></entry>\n\t\t\t<entry name="label"><![CDATA[Location]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="readOnly"><![CDATA[false]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t\t<entry name="tip"><![CDATA[]]></entry>\n\t\t\t<entry name="width"><![CDATA[25]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="textarea6584" type="textarea">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="fieldCssClass"><![CDATA[aui-w25]]></entry>\n\t\t\t<entry name="label"><![CDATA[Description]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="readOnly"><![CDATA[false]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t\t<entry name="tip"><![CDATA[]]></entry>\n\t\t\t<entry name="width"><![CDATA[25]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="textarea7502" type="textarea">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="fieldCssClass"><![CDATA[aui-w25]]></entry>\n\t\t\t<entry name="label"><![CDATA[Participants]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="readOnly"><![CDATA[false]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t\t<entry name="tip"><![CDATA[]]></entry>\n\t\t\t<entry name="width"><![CDATA[25]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n</root>	xml	0
fa94a5e8-ccbe-41d1-bc3d-d9443425241d	10401	10291	10253	10257		2017-03-10 17:05:25.203	2017-03-10 17:05:25.203	10189	auto_67e88d49-a22d-4760-aa45-c791c50e81a5	<?xml version='1.0' encoding='UTF-8'?><root available-locales="en_US" default-locale="en_US"><Name language-id="en_US">Contract</Name></root>	<?xml version='1.0' encoding='UTF-8'?><root available-locales="en_US" default-locale="en_US"><Description language-id="en_US">Contract</Description></root>	<?xml version="1.0"?>\n\n<root available-locales="en_US" default-locale="en_US">\n\t<dynamic-element dataType="date" fieldNamespace="ddm" name="ddm-date18949" type="ddm-date">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="fieldCssClass"><![CDATA[aui-w25]]></entry>\n\t\t\t<entry name="label"><![CDATA[Effective Date]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="readOnly"><![CDATA[false]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t\t<entry name="tip"><![CDATA[]]></entry>\n\t\t\t<entry name="width"><![CDATA[25]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="date" fieldNamespace="ddm" name="ddm-date20127" type="ddm-date">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="fieldCssClass"><![CDATA[aui-w25]]></entry>\n\t\t\t<entry name="label"><![CDATA[Expiration Date]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="readOnly"><![CDATA[false]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t\t<entry name="tip"><![CDATA[]]></entry>\n\t\t\t<entry name="width"><![CDATA[25]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="select10264" type="select">\n\t\t<dynamic-element name="nda" type="option" value="NDA">\n\t\t\t<meta-data locale="en_US">\n\t\t\t\t<entry name="label"><![CDATA[NDA]]></entry>\n\t\t\t\t<entry name="multiple"><![CDATA[false]]></entry>\n\t\t\t</meta-data>\n\t\t</dynamic-element>\n\t\t<dynamic-element name="msa" type="option" value="MSA">\n\t\t\t<meta-data locale="en_US">\n\t\t\t\t<entry name="label"><![CDATA[MSA]]></entry>\n\t\t\t</meta-data>\n\t\t</dynamic-element>\n\t\t<dynamic-element name="license_agreement" type="option" value="License">\n\t\t\t<meta-data locale="en_US">\n\t\t\t\t<entry name="label"><![CDATA[License Agreement]]></entry>\n\t\t\t</meta-data>\n\t\t</dynamic-element>\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="displayChildLabelAsValue"><![CDATA[true]]></entry>\n\t\t\t<entry name="label"><![CDATA[Contract Type]]></entry>\n\t\t\t<entry name="multiple"><![CDATA[false]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="readOnly"><![CDATA[false]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t\t<entry name="tip"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="select4893" type="select">\n\t\t<dynamic-element name="draft" type="option" value="Draft">\n\t\t\t<meta-data locale="en_US">\n\t\t\t\t<entry name="label"><![CDATA[Draft]]></entry>\n\t\t\t\t<entry name="multiple"><![CDATA[false]]></entry>\n\t\t\t</meta-data>\n\t\t</dynamic-element>\n\t\t<dynamic-element name="in_review" type="option" value="Review">\n\t\t\t<meta-data locale="en_US">\n\t\t\t\t<entry name="label"><![CDATA[In Review]]></entry>\n\t\t\t</meta-data>\n\t\t</dynamic-element>\n\t\t<dynamic-element name="suspended" type="option" value="Suspended">\n\t\t\t<meta-data locale="en_US">\n\t\t\t\t<entry name="label"><![CDATA[Suspended]]></entry>\n\t\t\t</meta-data>\n\t\t</dynamic-element>\n\t\t<dynamic-element name="signed" type="option" value="Signed">\n\t\t\t<meta-data locale="en_US">\n\t\t\t\t<entry name="label"><![CDATA[Signed]]></entry>\n\t\t\t</meta-data>\n\t\t</dynamic-element>\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="displayChildLabelAsValue"><![CDATA[true]]></entry>\n\t\t\t<entry name="label"><![CDATA[Status]]></entry>\n\t\t\t<entry name="multiple"><![CDATA[false]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="readOnly"><![CDATA[false]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t\t<entry name="tip"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="text14822" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="fieldCssClass"><![CDATA[aui-w25]]></entry>\n\t\t\t<entry name="label"><![CDATA[Legal Reviewer]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="readOnly"><![CDATA[false]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t\t<entry name="tip"><![CDATA[]]></entry>\n\t\t\t<entry name="width"><![CDATA[25]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="text17700" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="fieldCssClass"><![CDATA[aui-w25]]></entry>\n\t\t\t<entry name="label"><![CDATA[Signing Authority]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="readOnly"><![CDATA[false]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t\t<entry name="tip"><![CDATA[]]></entry>\n\t\t\t<entry name="width"><![CDATA[25]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="text2087" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="fieldCssClass"><![CDATA[aui-w25]]></entry>\n\t\t\t<entry name="label"><![CDATA[Deal Name]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="readOnly"><![CDATA[false]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t\t<entry name="tip"><![CDATA[]]></entry>\n\t\t\t<entry name="width"><![CDATA[25]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n</root>	xml	1
3b5ed819-5106-4ef8-a60a-9dd0d93fd7ae	10403	10291	10253	10257		2017-03-10 17:05:25.254	2017-03-10 17:05:25.254	10189	auto_c8fa47e9-5255-46f3-87ac-39a418dd4482	<?xml version='1.0' encoding='UTF-8'?><root available-locales="en_US" default-locale="en_US"><Name language-id="en_US">Marketing Banner</Name></root>	<?xml version='1.0' encoding='UTF-8'?><root available-locales="en_US" default-locale="en_US"><Description language-id="en_US">Marketing Banner</Description></root>	<?xml version="1.0"?>\n\n<root available-locales="en_US" default-locale="en_US">\n\t<dynamic-element dataType="string" name="radio5547" type="radio">\n\t\t<dynamic-element name="yes" type="option" value="yes">\n\t\t\t<meta-data locale="en_US">\n\t\t\t\t<entry name="label"><![CDATA[Yes]]></entry>\n\t\t\t</meta-data>\n\t\t</dynamic-element>\n\t\t<dynamic-element name="no" type="option" value="no">\n\t\t\t<meta-data locale="en_US">\n\t\t\t\t<entry name="label"><![CDATA[No]]></entry>\n\t\t\t</meta-data>\n\t\t</dynamic-element>\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="displayChildLabelAsValue"><![CDATA[true]]></entry>\n\t\t\t<entry name="label"><![CDATA[Needs Legal Review]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="readOnly"><![CDATA[false]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t\t<entry name="tip"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="text2033" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="fieldCssClass"><![CDATA[aui-w25]]></entry>\n\t\t\t<entry name="label"><![CDATA[Banner Name]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="readOnly"><![CDATA[false]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t\t<entry name="tip"><![CDATA[]]></entry>\n\t\t\t<entry name="width"><![CDATA[25]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="textarea2873" type="textarea">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="fieldCssClass"><![CDATA[aui-w25]]></entry>\n\t\t\t<entry name="label"><![CDATA[Description]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="readOnly"><![CDATA[false]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t\t<entry name="tip"><![CDATA[]]></entry>\n\t\t\t<entry name="width"><![CDATA[25]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n</root>	xml	1
e6677947-46fb-43a1-9d69-12f8aabb0d98	10405	10291	10253	10257		2017-03-10 17:05:25.283	2017-03-10 17:05:25.283	10189	auto_0ee46dea-8c29-42f9-87a1-1b55b587548a	<?xml version='1.0' encoding='UTF-8'?><root available-locales="en_US" default-locale="en_US"><Name language-id="en_US">Online Training</Name></root>	<?xml version='1.0' encoding='UTF-8'?><root available-locales="en_US" default-locale="en_US"><Description language-id="en_US">Online Training</Description></root>	<?xml version="1.0"?>\n\n<root available-locales="en_US" default-locale="en_US">\n\t<dynamic-element dataType="string" name="text2082" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="fieldCssClass"><![CDATA[aui-w25]]></entry>\n\t\t\t<entry name="label"><![CDATA[Lesson Title]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="readOnly"><![CDATA[false]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t\t<entry name="tip"><![CDATA[]]></entry>\n\t\t\t<entry name="width"><![CDATA[25]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="text2979" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="fieldCssClass"><![CDATA[aui-w25]]></entry>\n\t\t\t<entry name="label"><![CDATA[Author]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="readOnly"><![CDATA[false]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t\t<entry name="tip"><![CDATA[]]></entry>\n\t\t\t<entry name="width"><![CDATA[25]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n</root>	xml	1
6986c7ff-dffa-48de-a8e7-704de93e0b25	10407	10291	10253	10257		2017-03-10 17:05:25.312	2017-03-10 17:05:25.312	10189	auto_b00fb30c-2c8a-4bfa-83ec-e6259801d5e4	<?xml version='1.0' encoding='UTF-8'?><root available-locales="en_US" default-locale="en_US"><Name language-id="en_US">Sales Presentation</Name></root>	<?xml version='1.0' encoding='UTF-8'?><root available-locales="en_US" default-locale="en_US"><Description language-id="en_US">Sales Presentation</Description></root>	<?xml version="1.0"?>\n\n<root available-locales="en_US" default-locale="en_US">\n\t<dynamic-element dataType="string" name="select2890" type="select">\n\t\t<dynamic-element name="home_edition" type="option" value="HE">\n\t\t\t<meta-data locale="en_US">\n\t\t\t\t<entry name="label"><![CDATA[Home Edition]]></entry>\n\t\t\t\t<entry name="multiple"><![CDATA[false]]></entry>\n\t\t\t</meta-data>\n\t\t</dynamic-element>\n\t\t<dynamic-element name="business_edition" type="option" value="BE">\n\t\t\t<meta-data locale="en_US">\n\t\t\t\t<entry name="label"><![CDATA[Business Edition]]></entry>\n\t\t\t</meta-data>\n\t\t</dynamic-element>\n\t\t<dynamic-element name="enterprise_edition" type="option" value="EE">\n\t\t\t<meta-data locale="en_US">\n\t\t\t\t<entry name="label"><![CDATA[Enterprise Edition]]></entry>\n\t\t\t</meta-data>\n\t\t</dynamic-element>\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="displayChildLabelAsValue"><![CDATA[true]]></entry>\n\t\t\t<entry name="label"><![CDATA[Product]]></entry>\n\t\t\t<entry name="multiple"><![CDATA[false]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="readOnly"><![CDATA[false]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t\t<entry name="tip"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="select3864" type="select">\n\t\t<dynamic-element name="1_0" type="option" value="1">\n\t\t\t<meta-data locale="en_US">\n\t\t\t\t<entry name="label"><![CDATA[1.0]]></entry>\n\t\t\t\t<entry name="multiple"><![CDATA[false]]></entry>\n\t\t\t</meta-data>\n\t\t</dynamic-element>\n\t\t<dynamic-element name="2_0" type="option" value="2">\n\t\t\t<meta-data locale="en_US">\n\t\t\t\t<entry name="label"><![CDATA[2.0]]></entry>\n\t\t\t</meta-data>\n\t\t</dynamic-element>\n\t\t<dynamic-element name="3_0" type="option" value="3">\n\t\t\t<meta-data locale="en_US">\n\t\t\t\t<entry name="label"><![CDATA[3.0]]></entry>\n\t\t\t</meta-data>\n\t\t</dynamic-element>\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="displayChildLabelAsValue"><![CDATA[true]]></entry>\n\t\t\t<entry name="label"><![CDATA[Version]]></entry>\n\t\t\t<entry name="multiple"><![CDATA[false]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="readOnly"><![CDATA[false]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t\t<entry name="tip"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="select4831" type="select">\n\t\t<dynamic-element name="website" type="option" value="website">\n\t\t\t<meta-data locale="en_US">\n\t\t\t\t<entry name="label"><![CDATA[Website]]></entry>\n\t\t\t\t<entry name="multiple"><![CDATA[false]]></entry>\n\t\t\t</meta-data>\n\t\t</dynamic-element>\n\t\t<dynamic-element name="collaboration" type="option" value="collaboration">\n\t\t\t<meta-data locale="en_US">\n\t\t\t\t<entry name="label"><![CDATA[Collaboration]]></entry>\n\t\t\t</meta-data>\n\t\t</dynamic-element>\n\t\t<dynamic-element name="intranet" type="option" value="intranet">\n\t\t\t<meta-data locale="en_US">\n\t\t\t\t<entry name="label"><![CDATA[Intranet]]></entry>\n\t\t\t</meta-data>\n\t\t</dynamic-element>\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="displayChildLabelAsValue"><![CDATA[true]]></entry>\n\t\t\t<entry name="label"><![CDATA[Areas of Interest]]></entry>\n\t\t\t<entry name="multiple"><![CDATA[true]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="readOnly"><![CDATA[false]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t\t<entry name="tip"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="select5929" type="select">\n\t\t<dynamic-element name="acme" type="option" value="acme">\n\t\t\t<meta-data locale="en_US">\n\t\t\t\t<entry name="label"><![CDATA[ACME]]></entry>\n\t\t\t\t<entry name="multiple"><![CDATA[false]]></entry>\n\t\t\t</meta-data>\n\t\t</dynamic-element>\n\t\t<dynamic-element name="sevencogs" type="option" value="sevencogs">\n\t\t\t<meta-data locale="en_US">\n\t\t\t\t<entry name="label"><![CDATA[SevenCogs]]></entry>\n\t\t\t</meta-data>\n\t\t</dynamic-element>\n\t\t<dynamic-element name="freeplus" type="option" value="freeplus">\n\t\t\t<meta-data locale="en_US">\n\t\t\t\t<entry name="label"><![CDATA[FreePlus]]></entry>\n\t\t\t</meta-data>\n\t\t</dynamic-element>\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="displayChildLabelAsValue"><![CDATA[true]]></entry>\n\t\t\t<entry name="label"><![CDATA[Competitors]]></entry>\n\t\t\t<entry name="multiple"><![CDATA[true]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="readOnly"><![CDATA[false]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t\t<entry name="tip"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="text1993" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="fieldCssClass"><![CDATA[aui-w25]]></entry>\n\t\t\t<entry name="label"><![CDATA[Prospect Name]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="readOnly"><![CDATA[false]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t\t<entry name="tip"><![CDATA[]]></entry>\n\t\t\t<entry name="width"><![CDATA[25]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n</root>	xml	1
ea987324-034c-4f3e-8aee-68ae102179b8	10408	10291	10253	10257		2017-03-10 17:05:25.361	2017-03-10 17:05:25.361	10110	TikaRawMetadata	<?xml version='1.0' encoding='UTF-8'?><root available-locales="en_US" default-locale="en_US"><Name language-id="en_US">TikaRawMetadata</Name></root>	<?xml version='1.0' encoding='UTF-8'?><root available-locales="en_US" default-locale="en_US"><Description language-id="en_US">TikaRawMetadata</Description></root>	<?xml version="1.0"?>\n\n<root available-locales="en_US" default-locale="en_US">\n\t<dynamic-element dataType="string" name="ClimateForcast_PROGRAM_ID" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.ClimateForcast.PROGRAM_ID]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="ClimateForcast_COMMAND_LINE" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.ClimateForcast.COMMAND_LINE]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="ClimateForcast_HISTORY" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.ClimateForcast.HISTORY]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="ClimateForcast_TABLE_ID" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.ClimateForcast.TABLE_ID]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="ClimateForcast_INSTITUTION" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.ClimateForcast.INSTITUTION]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="ClimateForcast_SOURCE" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.ClimateForcast.SOURCE]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="ClimateForcast_CONTACT" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.ClimateForcast.CONTACT]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="ClimateForcast_PROJECT_ID" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.ClimateForcast.PROJECT_ID]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="ClimateForcast_CONVENTIONS" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.ClimateForcast.CONVENTIONS]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="ClimateForcast_REFERENCES" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.ClimateForcast.REFERENCES]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="ClimateForcast_ACKNOWLEDGEMENT" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.ClimateForcast.ACKNOWLEDGEMENT]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="ClimateForcast_REALIZATION" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.ClimateForcast.REALIZATION]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="ClimateForcast_EXPERIMENT_ID" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.ClimateForcast.EXPERIMENT_ID]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="ClimateForcast_COMMENT" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.ClimateForcast.COMMENT]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="ClimateForcast_MODEL_NAME_ENGLISH" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.ClimateForcast.MODEL_NAME_ENGLISH]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="CreativeCommons_LICENSE_URL" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.CreativeCommons.LICENSE_URL]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="CreativeCommons_LICENSE_LOCATION" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.CreativeCommons.LICENSE_LOCATION]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="CreativeCommons_WORK_TYPE" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.CreativeCommons.WORK_TYPE]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="DublinCore_NAMESPACE_URI_DC" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.DublinCore.NAMESPACE_URI_DC]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="DublinCore_NAMESPACE_URI_DC_TERMS" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.DublinCore.NAMESPACE_URI_DC_TERMS]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="DublinCore_PREFIX_DC" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.DublinCore.PREFIX_DC]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="DublinCore_PREFIX_DC_TERMS" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.DublinCore.PREFIX_DC_TERMS]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="DublinCore_FORMAT" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.DublinCore.FORMAT]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="DublinCore_IDENTIFIER" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.DublinCore.IDENTIFIER]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="DublinCore_MODIFIED" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.DublinCore.MODIFIED]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="DublinCore_CONTRIBUTOR" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.DublinCore.CONTRIBUTOR]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="DublinCore_COVERAGE" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.DublinCore.COVERAGE]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="DublinCore_CREATOR" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.DublinCore.CREATOR]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="DublinCore_CREATED" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.DublinCore.CREATED]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="DublinCore_DATE" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.DublinCore.DATE]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="DublinCore_DESCRIPTION" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.DublinCore.DESCRIPTION]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="DublinCore_LANGUAGE" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.DublinCore.LANGUAGE]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="DublinCore_PUBLISHER" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.DublinCore.PUBLISHER]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="DublinCore_RELATION" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.DublinCore.RELATION]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="DublinCore_RIGHTS" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.DublinCore.RIGHTS]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="DublinCore_SOURCE" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.DublinCore.SOURCE]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="DublinCore_SUBJECT" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.DublinCore.SUBJECT]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="DublinCore_TITLE" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.DublinCore.TITLE]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="DublinCore_TYPE" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.DublinCore.TYPE]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="Geographic_LATITUDE" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.Geographic.LATITUDE]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="Geographic_LONGITUDE" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.Geographic.LONGITUDE]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="Geographic_ALTITUDE" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.Geographic.ALTITUDE]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="HttpHeaders_CONTENT_ENCODING" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.HttpHeaders.CONTENT_ENCODING]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="HttpHeaders_CONTENT_LANGUAGE" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.HttpHeaders.CONTENT_LANGUAGE]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="HttpHeaders_CONTENT_LENGTH" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.HttpHeaders.CONTENT_LENGTH]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="HttpHeaders_CONTENT_LOCATION" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.HttpHeaders.CONTENT_LOCATION]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="HttpHeaders_CONTENT_DISPOSITION" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.HttpHeaders.CONTENT_DISPOSITION]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="HttpHeaders_CONTENT_MD5" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.HttpHeaders.CONTENT_MD5]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="HttpHeaders_CONTENT_TYPE" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.HttpHeaders.CONTENT_TYPE]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="HttpHeaders_LAST_MODIFIED" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.HttpHeaders.LAST_MODIFIED]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="HttpHeaders_LOCATION" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.HttpHeaders.LOCATION]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="Message_MESSAGE_RECIPIENT_ADDRESS" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.Message.MESSAGE_RECIPIENT_ADDRESS]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="Message_MESSAGE_FROM" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.Message.MESSAGE_FROM]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="Message_MESSAGE_TO" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.Message.MESSAGE_TO]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="Message_MESSAGE_CC" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.Message.MESSAGE_CC]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="Message_MESSAGE_BCC" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.Message.MESSAGE_BCC]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="MSOffice_KEYWORDS" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.MSOffice.KEYWORDS]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="MSOffice_COMMENTS" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.MSOffice.COMMENTS]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="MSOffice_LAST_AUTHOR" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.MSOffice.LAST_AUTHOR]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="MSOffice_AUTHOR" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.MSOffice.AUTHOR]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="MSOffice_APPLICATION_NAME" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.MSOffice.APPLICATION_NAME]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="MSOffice_REVISION_NUMBER" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.MSOffice.REVISION_NUMBER]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="MSOffice_TEMPLATE" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.MSOffice.TEMPLATE]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="MSOffice_TOTAL_TIME" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.MSOffice.TOTAL_TIME]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="MSOffice_PRESENTATION_FORMAT" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.MSOffice.PRESENTATION_FORMAT]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="MSOffice_NOTES" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.MSOffice.NOTES]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="MSOffice_MANAGER" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.MSOffice.MANAGER]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="MSOffice_APPLICATION_VERSION" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.MSOffice.APPLICATION_VERSION]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="MSOffice_VERSION" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.MSOffice.VERSION]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="MSOffice_CONTENT_STATUS" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.MSOffice.CONTENT_STATUS]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="MSOffice_CATEGORY" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.MSOffice.CATEGORY]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="MSOffice_COMPANY" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.MSOffice.COMPANY]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="MSOffice_SECURITY" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.MSOffice.SECURITY]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="MSOffice_SLIDE_COUNT" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.MSOffice.SLIDE_COUNT]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="MSOffice_PAGE_COUNT" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.MSOffice.PAGE_COUNT]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="MSOffice_PARAGRAPH_COUNT" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.MSOffice.PARAGRAPH_COUNT]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="MSOffice_LINE_COUNT" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.MSOffice.LINE_COUNT]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="MSOffice_WORD_COUNT" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.MSOffice.WORD_COUNT]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="MSOffice_CHARACTER_COUNT" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.MSOffice.CHARACTER_COUNT]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="MSOffice_CHARACTER_COUNT_WITH_SPACES" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.MSOffice.CHARACTER_COUNT_WITH_SPACES]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="MSOffice_TABLE_COUNT" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.MSOffice.TABLE_COUNT]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="MSOffice_IMAGE_COUNT" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.MSOffice.IMAGE_COUNT]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="MSOffice_OBJECT_COUNT" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.MSOffice.OBJECT_COUNT]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="MSOffice_EDIT_TIME" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.MSOffice.EDIT_TIME]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="MSOffice_CREATION_DATE" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.MSOffice.CREATION_DATE]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="MSOffice_LAST_SAVED" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.MSOffice.LAST_SAVED]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="MSOffice_LAST_PRINTED" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.MSOffice.LAST_PRINTED]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="MSOffice_USER_DEFINED_METADATA_NAME_PREFIX" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.MSOffice.USER_DEFINED_METADATA_NAME_PREFIX]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="TIFF_BITS_PER_SAMPLE" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.TIFF.BITS_PER_SAMPLE]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="TIFF_IMAGE_LENGTH" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.TIFF.IMAGE_LENGTH]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="TIFF_IMAGE_WIDTH" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.TIFF.IMAGE_WIDTH]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="TIFF_SAMPLES_PER_PIXEL" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.TIFF.SAMPLES_PER_PIXEL]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="TIFF_FLASH_FIRED" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.TIFF.FLASH_FIRED]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="TIFF_EXPOSURE_TIME" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.TIFF.EXPOSURE_TIME]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="TIFF_F_NUMBER" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.TIFF.F_NUMBER]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="TIFF_FOCAL_LENGTH" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.TIFF.FOCAL_LENGTH]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="TIFF_ISO_SPEED_RATINGS" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.TIFF.ISO_SPEED_RATINGS]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="TIFF_EQUIPMENT_MAKE" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.TIFF.EQUIPMENT_MAKE]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="TIFF_EQUIPMENT_MODEL" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.TIFF.EQUIPMENT_MODEL]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="TIFF_SOFTWARE" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.TIFF.SOFTWARE]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="TIFF_ORIENTATION" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.TIFF.ORIENTATION]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="TIFF_RESOLUTION_HORIZONTAL" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.TIFF.RESOLUTION_HORIZONTAL]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="TIFF_RESOLUTION_VERTICAL" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.TIFF.RESOLUTION_VERTICAL]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="TIFF_RESOLUTION_UNIT" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.TIFF.RESOLUTION_UNIT]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="TIFF_ORIGINAL_DATE" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.TIFF.ORIGINAL_DATE]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="TikaMetadataKeys_RESOURCE_NAME_KEY" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.TikaMetadataKeys.RESOURCE_NAME_KEY]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="TikaMetadataKeys_PROTECTED" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.TikaMetadataKeys.PROTECTED]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="TikaMetadataKeys_EMBEDDED_RELATIONSHIP_ID" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.TikaMetadataKeys.EMBEDDED_RELATIONSHIP_ID]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="TikaMimeKeys_TIKA_MIME_FILE" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.TikaMimeKeys.TIKA_MIME_FILE]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="TikaMimeKeys_MIME_TYPE_MAGIC" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.TikaMimeKeys.MIME_TYPE_MAGIC]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="XMPDM_DURATION" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.XMPDM.DURATION]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="XMPDM_ABS_PEAK_AUDIO_FILE_PATH" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.XMPDM.ABS_PEAK_AUDIO_FILE_PATH]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="XMPDM_ALBUM" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.XMPDM.ALBUM]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="XMPDM_ALT_TAPE_NAME" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.XMPDM.ALT_TAPE_NAME]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="XMPDM_ARTIST" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.XMPDM.ARTIST]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="XMPDM_AUDIO_MOD_DATE" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.XMPDM.AUDIO_MOD_DATE]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="XMPDM_AUDIO_SAMPLE_RATE" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.XMPDM.AUDIO_SAMPLE_RATE]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="XMPDM_AUDIO_SAMPLE_TYPE" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.XMPDM.AUDIO_SAMPLE_TYPE]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="XMPDM_AUDIO_CHANNEL_TYPE" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.XMPDM.AUDIO_CHANNEL_TYPE]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="XMPDM_AUDIO_COMPRESSOR" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.XMPDM.AUDIO_COMPRESSOR]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="XMPDM_COMPOSER" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.XMPDM.COMPOSER]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="XMPDM_COPYRIGHT" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.XMPDM.COPYRIGHT]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="XMPDM_ENGINEER" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.XMPDM.ENGINEER]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="XMPDM_FILE_DATA_RATE" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.XMPDM.FILE_DATA_RATE]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="XMPDM_GENRE" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.XMPDM.GENRE]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="XMPDM_INSTRUMENT" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.XMPDM.INSTRUMENT]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="XMPDM_KEY" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.XMPDM.KEY]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="XMPDM_LOG_COMMENT" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.XMPDM.LOG_COMMENT]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="XMPDM_LOOP" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.XMPDM.LOOP]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="XMPDM_NUMBER_OF_BEATS" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.XMPDM.NUMBER_OF_BEATS]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="XMPDM_METADATA_MOD_DATE" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.XMPDM.METADATA_MOD_DATE]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="XMPDM_PULL_DOWN" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.XMPDM.PULL_DOWN]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="XMPDM_RELATIVE_PEAK_AUDIO_FILE_PATH" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.XMPDM.RELATIVE_PEAK_AUDIO_FILE_PATH]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="XMPDM_RELEASE_DATE" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.XMPDM.RELEASE_DATE]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="XMPDM_SCALE_TYPE" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.XMPDM.SCALE_TYPE]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="XMPDM_SCENE" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.XMPDM.SCENE]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="XMPDM_SHOT_DATE" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.XMPDM.SHOT_DATE]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="XMPDM_SHOT_LOCATION" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.XMPDM.SHOT_LOCATION]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="XMPDM_SHOT_NAME" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.XMPDM.SHOT_NAME]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="XMPDM_SPEAKER_PLACEMENT" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.XMPDM.SPEAKER_PLACEMENT]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="XMPDM_STRETCH_MODE" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.XMPDM.STRETCH_MODE]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="XMPDM_TAPE_NAME" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.XMPDM.TAPE_NAME]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="XMPDM_TEMPO" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.XMPDM.TEMPO]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="XMPDM_TIME_SIGNATURE" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.XMPDM.TIME_SIGNATURE]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="XMPDM_TRACK_NUMBER" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.XMPDM.TRACK_NUMBER]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="XMPDM_VIDEO_ALPHA_MODE" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.XMPDM.VIDEO_ALPHA_MODE]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="XMPDM_VIDEO_ALPHA_UNITY_IS_TRANSPARENT" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.XMPDM.VIDEO_ALPHA_UNITY_IS_TRANSPARENT]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="XMPDM_VIDEO_COLOR_SPACE" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.XMPDM.VIDEO_COLOR_SPACE]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="XMPDM_VIDEO_COMPRESSOR" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.XMPDM.VIDEO_COMPRESSOR]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="XMPDM_VIDEO_FIELD_ORDER" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.XMPDM.VIDEO_FIELD_ORDER]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="XMPDM_VIDEO_FRAME_RATE" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.XMPDM.VIDEO_FRAME_RATE]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="XMPDM_VIDEO_MOD_DATE" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.XMPDM.VIDEO_MOD_DATE]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="XMPDM_VIDEO_PIXEL_DEPTH" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.XMPDM.VIDEO_PIXEL_DEPTH]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="XMPDM_VIDEO_PIXEL_ASPECT_RATIO" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.XMPDM.VIDEO_PIXEL_ASPECT_RATIO]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n</root>	xml	0
20d0ec49-ba2c-4d25-99ca-012dcaa1ea2b	10499	10279	10253	10257		2017-03-10 17:05:27.139	2017-03-10 17:05:27.139	10197	Contacts	<?xml version='1.0' encoding='UTF-8'?><root available-locales="en_US" default-locale="en_US"><Name language-id="en_US">Contacts</Name></root>	<?xml version='1.0' encoding='UTF-8'?><root available-locales="en_US" default-locale="en_US"><Description language-id="en_US">Contacts</Description></root>	<?xml version="1.0"?>\n\n<root available-locales="en_US" default-locale="en_US">\n\t<dynamic-element dataType="string" name="company" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="fieldCssClass"><![CDATA[aui-w50]]></entry>\n\t\t\t<entry name="label"><![CDATA[Company]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t\t<entry name="width"><![CDATA[50]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="email" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="fieldCssClass"><![CDATA[aui-w50]]></entry>\n\t\t\t<entry name="label"><![CDATA[Email]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t\t<entry name="width"><![CDATA[50]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="firstName" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="fieldCssClass"><![CDATA[aui-w50]]></entry>\n\t\t\t<entry name="label"><![CDATA[First Name]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t\t<entry name="width"><![CDATA[50]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="imService" type="select">\n\t\t<dynamic-element name="aol" type="option" value="aol">\n\t\t\t<meta-data locale="en_US">\n\t\t\t\t<entry name="label"><![CDATA[AOL]]></entry>\n\t\t\t\t<entry name="multiple"><![CDATA[false]]></entry>\n\t\t\t</meta-data>\n\t\t</dynamic-element>\n\t\t<dynamic-element name="yahoo" type="option" value="yahoo">\n\t\t\t<meta-data locale="en_US">\n\t\t\t\t<entry name="label"><![CDATA[Yahoo]]></entry>\n\t\t\t</meta-data>\n\t\t</dynamic-element>\n\t\t<dynamic-element name="gtalk" type="option" value="gtalk">\n\t\t\t<meta-data locale="en_US">\n\t\t\t\t<entry name="label"><![CDATA[GTalk]]></entry>\n\t\t\t</meta-data>\n\t\t</dynamic-element>\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[Instant Messenger Service]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[["gtalk"]]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="imUserName" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="fieldCssClass"><![CDATA[aui-w50]]></entry>\n\t\t\t<entry name="label"><![CDATA[Instant Messenger]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t\t<entry name="width"><![CDATA[50]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="jobTitle" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="fieldCssClass"><![CDATA[aui-w50]]></entry>\n\t\t\t<entry name="label"><![CDATA[Job Title]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t\t<entry name="width"><![CDATA[50]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="lastName" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="fieldCssClass"><![CDATA[aui-w50]]></entry>\n\t\t\t<entry name="label"><![CDATA[Last Name]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t\t<entry name="width"><![CDATA[50]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="notes" type="textarea">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="fieldCssClass"><![CDATA[aui-w100]]></entry>\n\t\t\t<entry name="label"><![CDATA[Notes]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t\t<entry name="width"><![CDATA[100]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="phoneMobile" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="fieldCssClass"><![CDATA[aui-w50]]></entry>\n\t\t\t<entry name="label"><![CDATA[Phone (Mobile)]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t\t<entry name="width"><![CDATA[50]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="phoneOffice" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="fieldCssClass"><![CDATA[aui-w50]]></entry>\n\t\t\t<entry name="label"><![CDATA[Phone (Office)]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t\t<entry name="width"><![CDATA[50]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n</root>	xml	0
afba0965-e0b1-47cf-87d0-6d2fcbdad9f7	10500	10279	10253	10257		2017-03-10 17:05:27.174	2017-03-10 17:05:27.174	10197	Events	<?xml version='1.0' encoding='UTF-8'?><root available-locales="en_US" default-locale="en_US"><Name language-id="en_US">Events</Name></root>	<?xml version='1.0' encoding='UTF-8'?><root available-locales="en_US" default-locale="en_US"><Description language-id="en_US">Events</Description></root>	<?xml version="1.0"?>\n\n<root available-locales="en_US" default-locale="en_US">\n\t<dynamic-element dataType="file-upload" fieldNamespace="ddm" name="attachment" type="ddm-fileupload">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="acceptFiles"><![CDATA[*]]></entry>\n\t\t\t<entry name="folder"><![CDATA[{"folderId":0,"folderName":"Documents Home"}]]></entry>\n\t\t\t<entry name="label"><![CDATA[Attachment]]></entry>\n\t\t\t<entry name="name"><![CDATA[attachment]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t\t<entry name="tip"><![CDATA[Upload documents no larger than 3,000k.]]></entry>\n\t\t\t<entry name="type"><![CDATA[ddm-fileupload]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="double" fieldNamespace="ddm" name="cost" type="ddm-number">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="fieldCssClass"><![CDATA[aui-w25]]></entry>\n\t\t\t<entry name="label"><![CDATA[Cost]]></entry>\n\t\t\t<entry name="name"><![CDATA[cost]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t\t<entry name="tip"><![CDATA[]]></entry>\n\t\t\t<entry name="type"><![CDATA[ddm-number]]></entry>\n\t\t\t<entry name="width"><![CDATA[25]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="description" type="textarea">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="fieldCssClass"><![CDATA[aui-w100]]></entry>\n\t\t\t<entry name="label"><![CDATA[Description]]></entry>\n\t\t\t<entry name="name"><![CDATA[description]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t\t<entry name="tip"><![CDATA[]]></entry>\n\t\t\t<entry name="type"><![CDATA[textarea]]></entry>\n\t\t\t<entry name="width"><![CDATA[100]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="date" fieldNamespace="ddm" name="eventDate" type="ddm-date">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="fieldCssClass"><![CDATA[aui-w25]]></entry>\n\t\t\t<entry name="label"><![CDATA[Date]]></entry>\n\t\t\t<entry name="name"><![CDATA[eventDate]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t\t<entry name="tip"><![CDATA[]]></entry>\n\t\t\t<entry name="type"><![CDATA[ddm-date]]></entry>\n\t\t\t<entry name="width"><![CDATA[25]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="eventName" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="fieldCssClass"><![CDATA[aui-w50]]></entry>\n\t\t\t<entry name="label"><![CDATA[Event Name]]></entry>\n\t\t\t<entry name="name"><![CDATA[eventName]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t\t<entry name="tip"><![CDATA[]]></entry>\n\t\t\t<entry name="type"><![CDATA[text]]></entry>\n\t\t\t<entry name="width"><![CDATA[50]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="eventTime" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="fieldCssClass"><![CDATA[aui-w25]]></entry>\n\t\t\t<entry name="label"><![CDATA[Time]]></entry>\n\t\t\t<entry name="name"><![CDATA[eventTime]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t\t<entry name="tip"><![CDATA[]]></entry>\n\t\t\t<entry name="type"><![CDATA[text]]></entry>\n\t\t\t<entry name="width"><![CDATA[25]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="location" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="fieldCssClass"><![CDATA[aui-w50]]></entry>\n\t\t\t<entry name="label"><![CDATA[Location]]></entry>\n\t\t\t<entry name="name"><![CDATA[location]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t\t<entry name="tip"><![CDATA[]]></entry>\n\t\t\t<entry name="type"><![CDATA[text]]></entry>\n\t\t\t<entry name="width"><![CDATA[50]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n</root>	xml	0
89781566-1be9-4d5c-8c30-11966dcd5dc0	10501	10279	10253	10257		2017-03-10 17:05:27.246	2017-03-10 17:05:27.246	10197	Inventory	<?xml version='1.0' encoding='UTF-8'?><root available-locales="en_US" default-locale="en_US"><Name language-id="en_US">Inventory</Name></root>	<?xml version='1.0' encoding='UTF-8'?><root available-locales="en_US" default-locale="en_US"><Description language-id="en_US">Inventory</Description></root>	<?xml version="1.0"?>\n\n<root available-locales="en_US" default-locale="en_US">\n\t<dynamic-element dataType="string" name="description" type="textarea">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="fieldCssClass"><![CDATA[aui-w100]]></entry>\n\t\t\t<entry name="label"><![CDATA[Description]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t\t<entry name="style"><![CDATA[]]></entry>\n\t\t\t<entry name="tip"><![CDATA[]]></entry>\n\t\t\t<entry name="width"><![CDATA[100]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="item" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="fieldCssClass"><![CDATA[aui-w25]]></entry>\n\t\t\t<entry name="label"><![CDATA[Item]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t\t<entry name="style"><![CDATA[]]></entry>\n\t\t\t<entry name="tip"><![CDATA[]]></entry>\n\t\t\t<entry name="width"><![CDATA[25]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="location" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="fieldCssClass"><![CDATA[aui-w25]]></entry>\n\t\t\t<entry name="label"><![CDATA[Location]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t\t<entry name="style"><![CDATA[]]></entry>\n\t\t\t<entry name="tip"><![CDATA[]]></entry>\n\t\t\t<entry name="width"><![CDATA[25]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="date" fieldNamespace="ddm" name="purchaseDate" type="ddm-date">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="fieldCssClass"><![CDATA[aui-w25]]></entry>\n\t\t\t<entry name="label"><![CDATA[Purchase Date]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t\t<entry name="style"><![CDATA[]]></entry>\n\t\t\t<entry name="tip"><![CDATA[]]></entry>\n\t\t\t<entry name="width"><![CDATA[25]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="double" fieldNamespace="ddm" name="purchasePrice" type="ddm-number">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="fieldCssClass"><![CDATA[aui-w25]]></entry>\n\t\t\t<entry name="label"><![CDATA[Purchase Price]]></entry>\n\t\t\t<entry name="name"><![CDATA[purchasePrice]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t\t<entry name="tip"><![CDATA[]]></entry>\n\t\t\t<entry name="type"><![CDATA[ddm-number]]></entry>\n\t\t\t<entry name="width"><![CDATA[25]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="double" fieldNamespace="ddm" name="quantity" type="ddm-number">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="fieldCssClass"><![CDATA[aui-w25]]></entry>\n\t\t\t<entry name="label"><![CDATA[Quantity]]></entry>\n\t\t\t<entry name="name"><![CDATA[quantity]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t\t<entry name="tip"><![CDATA[]]></entry>\n\t\t\t<entry name="type"><![CDATA[ddm-number]]></entry>\n\t\t\t<entry name="width"><![CDATA[25]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n</root>	xml	0
6cd74de1-e722-4e7d-83d8-359b4f2591bf	10502	10279	10253	10257		2017-03-10 17:05:27.275	2017-03-10 17:05:27.275	10197	Issues Tracking	<?xml version='1.0' encoding='UTF-8'?><root available-locales="en_US" default-locale="en_US"><Name language-id="en_US">Issues Tracking</Name></root>	<?xml version='1.0' encoding='UTF-8'?><root available-locales="en_US" default-locale="en_US"><Description language-id="en_US">Issue Tracking</Description></root>	<?xml version="1.0"?>\n\n<root available-locales="en_US" default-locale="en_US">\n\t<dynamic-element dataType="string" name="assignedTo" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="fieldCssClass"><![CDATA[aui-w25]]></entry>\n\t\t\t<entry name="label"><![CDATA[Assigned To]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t\t<entry name="width"><![CDATA[25]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="file-upload" fieldNamespace="ddm" name="attachment" type="ddm-fileupload">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="acceptFiles"><![CDATA[*]]></entry>\n\t\t\t<entry name="folder"><![CDATA[{"folderId":0,"folderName":"Documents Home"}]]></entry>\n\t\t\t<entry name="label"><![CDATA[Attachment]]></entry>\n\t\t\t<entry name="name"><![CDATA[attachment]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t\t<entry name="tip"><![CDATA[Upload documents no larger than 3,000k.]]></entry>\n\t\t\t<entry name="type"><![CDATA[ddm-fileupload]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="comments" type="textarea">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="fieldCssClass"><![CDATA[aui-w100]]></entry>\n\t\t\t<entry name="label"><![CDATA[Comments]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t\t<entry name="width"><![CDATA[100]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="description" type="textarea">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="fieldCssClass"><![CDATA[aui-w100]]></entry>\n\t\t\t<entry name="label"><![CDATA[Description]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t\t<entry name="width"><![CDATA[100]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="date" fieldNamespace="ddm" name="dueDate" type="ddm-date">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[Due Date]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="issueId" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="fieldCssClass"><![CDATA[aui-w25]]></entry>\n\t\t\t<entry name="label"><![CDATA[Issue ID]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t\t<entry name="width"><![CDATA[25]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="severity" type="select">\n\t\t<dynamic-element name="critical" type="option" value="critical">\n\t\t\t<meta-data locale="en_US">\n\t\t\t\t<entry name="label"><![CDATA[Critical]]></entry>\n\t\t\t\t<entry name="multiple"><![CDATA[false]]></entry>\n\t\t\t</meta-data>\n\t\t</dynamic-element>\n\t\t<dynamic-element name="major" type="option" value="major">\n\t\t\t<meta-data locale="en_US">\n\t\t\t\t<entry name="label"><![CDATA[Major]]></entry>\n\t\t\t</meta-data>\n\t\t</dynamic-element>\n\t\t<dynamic-element name="minor" type="option" value="minor">\n\t\t\t<meta-data locale="en_US">\n\t\t\t\t<entry name="label"><![CDATA[Minor]]></entry>\n\t\t\t</meta-data>\n\t\t</dynamic-element>\n\t\t<dynamic-element name="trivial" type="option" value="trivial">\n\t\t\t<meta-data locale="en_US">\n\t\t\t\t<entry name="label"><![CDATA[Trivial]]></entry>\n\t\t\t</meta-data>\n\t\t</dynamic-element>\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[Severity]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[["minor"]]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="status" type="select">\n\t\t<dynamic-element name="open" type="option" value="open">\n\t\t\t<meta-data locale="en_US">\n\t\t\t\t<entry name="label"><![CDATA[Open]]></entry>\n\t\t\t\t<entry name="multiple"><![CDATA[false]]></entry>\n\t\t\t</meta-data>\n\t\t</dynamic-element>\n\t\t<dynamic-element name="pending" type="option" value="pending">\n\t\t\t<meta-data locale="en_US">\n\t\t\t\t<entry name="label"><![CDATA[Pending]]></entry>\n\t\t\t</meta-data>\n\t\t</dynamic-element>\n\t\t<dynamic-element name="completed" type="option" value="completed">\n\t\t\t<meta-data locale="en_US">\n\t\t\t\t<entry name="label"><![CDATA[Completed]]></entry>\n\t\t\t</meta-data>\n\t\t</dynamic-element>\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[Status]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[["open"]]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="title" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="fieldCssClass"><![CDATA[aui-w100]]></entry>\n\t\t\t<entry name="label"><![CDATA[Title]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t\t<entry name="width"><![CDATA[100]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n</root>	xml	0
54f0cb6a-8d9b-4805-a82b-db5038863256	10503	10279	10253	10257		2017-03-10 17:05:27.312	2017-03-10 17:05:27.312	10197	Meeting Minutes	<?xml version='1.0' encoding='UTF-8'?><root available-locales="en_US" default-locale="en_US"><Name language-id="en_US">Meeting Minutes</Name></root>	<?xml version='1.0' encoding='UTF-8'?><root available-locales="en_US" default-locale="en_US"><Description language-id="en_US">Meeting Minutes</Description></root>	<?xml version="1.0"?>\n\n<root available-locales="en_US" default-locale="en_US">\n\t<dynamic-element dataType="file-upload" fieldNamespace="ddm" name="attachment" type="ddm-fileupload">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="acceptFiles"><![CDATA[*]]></entry>\n\t\t\t<entry name="folder"><![CDATA[{"folderId":0,"folderName":"Documents Home"}]]></entry>\n\t\t\t<entry name="label"><![CDATA[Attachment]]></entry>\n\t\t\t<entry name="name"><![CDATA[attachment]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t\t<entry name="tip"><![CDATA[Upload documents no larger than 3,000k.]]></entry>\n\t\t\t<entry name="type"><![CDATA[ddm-fileupload]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="author" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[Author]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="description" type="textarea">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="fieldCssClass"><![CDATA[aui-w100]]></entry>\n\t\t\t<entry name="label"><![CDATA[Description]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t\t<entry name="width"><![CDATA[100]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="duration" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[Meeting Duration]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="date" fieldNamespace="ddm" name="meetingDate" type="ddm-date">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[Meeting Date]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="minutes" type="textarea">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="fieldCssClass"><![CDATA[aui-w100]]></entry>\n\t\t\t<entry name="label"><![CDATA[Minutes]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t\t<entry name="width"><![CDATA[100]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="title" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="fieldCssClass"><![CDATA[aui-w100]]></entry>\n\t\t\t<entry name="label"><![CDATA[Title]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t\t<entry name="width"><![CDATA[100]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n</root>	xml	0
99854863-1040-4c37-82f2-68bcd5e54ec8	10504	10279	10253	10257		2017-03-10 17:05:27.383	2017-03-10 17:05:27.383	10197	To Do	<?xml version='1.0' encoding='UTF-8'?><root available-locales="en_US" default-locale="en_US"><Name language-id="en_US">To Do</Name></root>	<?xml version='1.0' encoding='UTF-8'?><root available-locales="en_US" default-locale="en_US"><Description language-id="en_US">To Do</Description></root>	<?xml version="1.0"?>\n\n<root available-locales="en_US" default-locale="en_US">\n\t<dynamic-element dataType="string" name="assignedTo" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="fieldCssClass"><![CDATA[aui-w50]]></entry>\n\t\t\t<entry name="label"><![CDATA[Assigned To]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t\t<entry name="width"><![CDATA[50]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="file-upload" fieldNamespace="ddm" name="attachment" type="ddm-fileupload">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="acceptFiles"><![CDATA[*]]></entry>\n\t\t\t<entry name="folder"><![CDATA[{"folderId":0,"folderName":"Documents Home"}]]></entry>\n\t\t\t<entry name="label"><![CDATA[Attachment]]></entry>\n\t\t\t<entry name="name"><![CDATA[attachment]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t\t<entry name="tip"><![CDATA[Upload documents no larger than 3,000k.]]></entry>\n\t\t\t<entry name="type"><![CDATA[ddm-fileupload]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="comments" type="textarea">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="fieldCssClass"><![CDATA[aui-w100]]></entry>\n\t\t\t<entry name="label"><![CDATA[Comments]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t\t<entry name="width"><![CDATA[100]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="description" type="textarea">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="fieldCssClass"><![CDATA[aui-w100]]></entry>\n\t\t\t<entry name="label"><![CDATA[Description]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t\t<entry name="width"><![CDATA[100]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="date" fieldNamespace="ddm" name="endDate" type="ddm-date">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[End Date]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="integer" fieldNamespace="ddm" name="percentComplete" type="ddm-integer">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="fieldCssClass"><![CDATA[aui-w25]]></entry>\n\t\t\t<entry name="label"><![CDATA[% Complete]]></entry>\n\t\t\t<entry name="name"><![CDATA[percentComplete]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[0]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t\t<entry name="tip"><![CDATA[]]></entry>\n\t\t\t<entry name="type"><![CDATA[ddm-integer]]></entry>\n\t\t\t<entry name="width"><![CDATA[25]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="severity" type="select">\n\t\t<dynamic-element name="critical" type="option" value="critical">\n\t\t\t<meta-data locale="en_US">\n\t\t\t\t<entry name="label"><![CDATA[Critical]]></entry>\n\t\t\t\t<entry name="multiple"><![CDATA[false]]></entry>\n\t\t\t</meta-data>\n\t\t</dynamic-element>\n\t\t<dynamic-element name="major" type="option" value="major">\n\t\t\t<meta-data locale="en_US">\n\t\t\t\t<entry name="label"><![CDATA[Major]]></entry>\n\t\t\t</meta-data>\n\t\t</dynamic-element>\n\t\t<dynamic-element name="minor" type="option" value="minor">\n\t\t\t<meta-data locale="en_US">\n\t\t\t\t<entry name="label"><![CDATA[Minor]]></entry>\n\t\t\t</meta-data>\n\t\t</dynamic-element>\n\t\t<dynamic-element name="trivial" type="option" value="trivial">\n\t\t\t<meta-data locale="en_US">\n\t\t\t\t<entry name="label"><![CDATA[Trivial]]></entry>\n\t\t\t</meta-data>\n\t\t</dynamic-element>\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[Severity]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[["minor"]]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="date" fieldNamespace="ddm" name="startDate" type="ddm-date">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[Start Date]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="status" type="select">\n\t\t<dynamic-element name="open" type="option" value="open">\n\t\t\t<meta-data locale="en_US">\n\t\t\t\t<entry name="label"><![CDATA[Open]]></entry>\n\t\t\t\t<entry name="multiple"><![CDATA[false]]></entry>\n\t\t\t</meta-data>\n\t\t</dynamic-element>\n\t\t<dynamic-element name="pending" type="option" value="pending">\n\t\t\t<meta-data locale="en_US">\n\t\t\t\t<entry name="label"><![CDATA[Pending]]></entry>\n\t\t\t</meta-data>\n\t\t</dynamic-element>\n\t\t<dynamic-element name="completed" type="option" value="completed">\n\t\t\t<meta-data locale="en_US">\n\t\t\t\t<entry name="label"><![CDATA[Completed]]></entry>\n\t\t\t</meta-data>\n\t\t</dynamic-element>\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[Status]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[["open"]]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="title" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="fieldCssClass"><![CDATA[aui-w50]]></entry>\n\t\t\t<entry name="label"><![CDATA[Title]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t\t<entry name="width"><![CDATA[50]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n</root>	xml	0
fa94a5e8-ccbe-41d1-bc3d-d9443425241d	10553	10543	10253	10257		2017-03-10 17:05:25.203	2017-03-10 17:05:25.203	10189	auto_67e88d49-a22d-4760-aa45-c791c50e81a5	<?xml version='1.0' encoding='UTF-8'?><root available-locales="en_US" default-locale="en_US"><Name language-id="en_US">Contract</Name></root>	<?xml version='1.0' encoding='UTF-8'?><root available-locales="en_US" default-locale="en_US"><Description language-id="en_US">Contract</Description></root>	<?xml version="1.0"?>\n\n<root available-locales="en_US" default-locale="en_US">\n\t<dynamic-element dataType="date" fieldNamespace="ddm" name="ddm-date18949" type="ddm-date">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="fieldCssClass"><![CDATA[aui-w25]]></entry>\n\t\t\t<entry name="label"><![CDATA[Effective Date]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="readOnly"><![CDATA[false]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t\t<entry name="tip"><![CDATA[]]></entry>\n\t\t\t<entry name="width"><![CDATA[25]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="date" fieldNamespace="ddm" name="ddm-date20127" type="ddm-date">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="fieldCssClass"><![CDATA[aui-w25]]></entry>\n\t\t\t<entry name="label"><![CDATA[Expiration Date]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="readOnly"><![CDATA[false]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t\t<entry name="tip"><![CDATA[]]></entry>\n\t\t\t<entry name="width"><![CDATA[25]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="select10264" type="select">\n\t\t<dynamic-element name="nda" type="option" value="NDA">\n\t\t\t<meta-data locale="en_US">\n\t\t\t\t<entry name="label"><![CDATA[NDA]]></entry>\n\t\t\t\t<entry name="multiple"><![CDATA[false]]></entry>\n\t\t\t</meta-data>\n\t\t</dynamic-element>\n\t\t<dynamic-element name="msa" type="option" value="MSA">\n\t\t\t<meta-data locale="en_US">\n\t\t\t\t<entry name="label"><![CDATA[MSA]]></entry>\n\t\t\t</meta-data>\n\t\t</dynamic-element>\n\t\t<dynamic-element name="license_agreement" type="option" value="License">\n\t\t\t<meta-data locale="en_US">\n\t\t\t\t<entry name="label"><![CDATA[License Agreement]]></entry>\n\t\t\t</meta-data>\n\t\t</dynamic-element>\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="displayChildLabelAsValue"><![CDATA[true]]></entry>\n\t\t\t<entry name="label"><![CDATA[Contract Type]]></entry>\n\t\t\t<entry name="multiple"><![CDATA[false]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="readOnly"><![CDATA[false]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t\t<entry name="tip"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="select4893" type="select">\n\t\t<dynamic-element name="draft" type="option" value="Draft">\n\t\t\t<meta-data locale="en_US">\n\t\t\t\t<entry name="label"><![CDATA[Draft]]></entry>\n\t\t\t\t<entry name="multiple"><![CDATA[false]]></entry>\n\t\t\t</meta-data>\n\t\t</dynamic-element>\n\t\t<dynamic-element name="in_review" type="option" value="Review">\n\t\t\t<meta-data locale="en_US">\n\t\t\t\t<entry name="label"><![CDATA[In Review]]></entry>\n\t\t\t</meta-data>\n\t\t</dynamic-element>\n\t\t<dynamic-element name="suspended" type="option" value="Suspended">\n\t\t\t<meta-data locale="en_US">\n\t\t\t\t<entry name="label"><![CDATA[Suspended]]></entry>\n\t\t\t</meta-data>\n\t\t</dynamic-element>\n\t\t<dynamic-element name="signed" type="option" value="Signed">\n\t\t\t<meta-data locale="en_US">\n\t\t\t\t<entry name="label"><![CDATA[Signed]]></entry>\n\t\t\t</meta-data>\n\t\t</dynamic-element>\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="displayChildLabelAsValue"><![CDATA[true]]></entry>\n\t\t\t<entry name="label"><![CDATA[Status]]></entry>\n\t\t\t<entry name="multiple"><![CDATA[false]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="readOnly"><![CDATA[false]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t\t<entry name="tip"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="text14822" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="fieldCssClass"><![CDATA[aui-w25]]></entry>\n\t\t\t<entry name="label"><![CDATA[Legal Reviewer]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="readOnly"><![CDATA[false]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t\t<entry name="tip"><![CDATA[]]></entry>\n\t\t\t<entry name="width"><![CDATA[25]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="text17700" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="fieldCssClass"><![CDATA[aui-w25]]></entry>\n\t\t\t<entry name="label"><![CDATA[Signing Authority]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="readOnly"><![CDATA[false]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t\t<entry name="tip"><![CDATA[]]></entry>\n\t\t\t<entry name="width"><![CDATA[25]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="text2087" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="fieldCssClass"><![CDATA[aui-w25]]></entry>\n\t\t\t<entry name="label"><![CDATA[Deal Name]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="readOnly"><![CDATA[false]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t\t<entry name="tip"><![CDATA[]]></entry>\n\t\t\t<entry name="width"><![CDATA[25]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n</root>	xml	1
6572f143-9214-4ab7-a837-c18a186625a5	10554	10543	10253	10257		2017-03-10 17:05:25.126	2017-03-10 17:05:25.126	10189	Marketing Campaign Theme Metadata	<?xml version='1.0' encoding='UTF-8'?><root available-locales="en_US" default-locale="en_US"><Name language-id="en_US">Marketing Campaign Theme Metadata</Name></root>	<?xml version='1.0' encoding='UTF-8'?><root available-locales="en_US" default-locale="en_US"><Description language-id="en_US">Marketing Campaign Theme Metadata</Description></root>	<?xml version="1.0"?>\n\n<root available-locales="en_US" default-locale="en_US">\n\t<dynamic-element dataType="string" name="select2305" type="select">\n\t\t<dynamic-element name="strong_company" type="option" value="strong">\n\t\t\t<meta-data locale="en_US">\n\t\t\t\t<entry name="label"><![CDATA[Strong Company]]></entry>\n\t\t\t\t<entry name="multiple"><![CDATA[false]]></entry>\n\t\t\t</meta-data>\n\t\t</dynamic-element>\n\t\t<dynamic-element name="new_product_launch" type="option" value="product">\n\t\t\t<meta-data locale="en_US">\n\t\t\t\t<entry name="label"><![CDATA[New Product Launch]]></entry>\n\t\t\t</meta-data>\n\t\t</dynamic-element>\n\t\t<dynamic-element name="company_philosophy" type="option" value="philosophy">\n\t\t\t<meta-data locale="en_US">\n\t\t\t\t<entry name="label"><![CDATA[Company Philosophy]]></entry>\n\t\t\t</meta-data>\n\t\t</dynamic-element>\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="displayChildLabelAsValue"><![CDATA[true]]></entry>\n\t\t\t<entry name="label"><![CDATA[Select]]></entry>\n\t\t\t<entry name="multiple"><![CDATA[false]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="readOnly"><![CDATA[false]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t\t<entry name="tip"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="select3229" type="select">\n\t\t<dynamic-element name="your_trusted_advisor" type="option" value="advisor">\n\t\t\t<meta-data locale="en_US">\n\t\t\t\t<entry name="label"><![CDATA[Your Trusted Advisor]]></entry>\n\t\t\t\t<entry name="multiple"><![CDATA[false]]></entry>\n\t\t\t</meta-data>\n\t\t</dynamic-element>\n\t\t<dynamic-element name="10_years_of_customer_solutions" type="option" value="solutions">\n\t\t\t<meta-data locale="en_US">\n\t\t\t\t<entry name="label"><![CDATA[10 Years of Customer Solutions]]></entry>\n\t\t\t</meta-data>\n\t\t</dynamic-element>\n\t\t<dynamic-element name="making_a_difference" type="option" value="difference">\n\t\t\t<meta-data locale="en_US">\n\t\t\t\t<entry name="label"><![CDATA[Making a Difference]]></entry>\n\t\t\t</meta-data>\n\t\t</dynamic-element>\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="displayChildLabelAsValue"><![CDATA[true]]></entry>\n\t\t\t<entry name="label"><![CDATA[Campaign Theme]]></entry>\n\t\t\t<entry name="multiple"><![CDATA[false]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="readOnly"><![CDATA[false]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t\t<entry name="tip"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="select4282" type="select">\n\t\t<dynamic-element name="awareness" type="option" value="awareness">\n\t\t\t<meta-data locale="en_US">\n\t\t\t\t<entry name="label"><![CDATA[Awareness]]></entry>\n\t\t\t\t<entry name="multiple"><![CDATA[false]]></entry>\n\t\t\t</meta-data>\n\t\t</dynamic-element>\n\t\t<dynamic-element name="lead_generation" type="option" value="leads">\n\t\t\t<meta-data locale="en_US">\n\t\t\t\t<entry name="label"><![CDATA[Lead Generation]]></entry>\n\t\t\t</meta-data>\n\t\t</dynamic-element>\n\t\t<dynamic-element name="customer_service" type="option" value="service">\n\t\t\t<meta-data locale="en_US">\n\t\t\t\t<entry name="label"><![CDATA[Customer Service]]></entry>\n\t\t\t</meta-data>\n\t\t</dynamic-element>\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="displayChildLabelAsValue"><![CDATA[true]]></entry>\n\t\t\t<entry name="label"><![CDATA[Business Goal]]></entry>\n\t\t\t<entry name="multiple"><![CDATA[false]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="readOnly"><![CDATA[false]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t\t<entry name="tip"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n</root>	xml	0
3b5ed819-5106-4ef8-a60a-9dd0d93fd7ae	10555	10543	10253	10257		2017-03-10 17:05:25.254	2017-03-10 17:05:25.254	10189	auto_c8fa47e9-5255-46f3-87ac-39a418dd4482	<?xml version='1.0' encoding='UTF-8'?><root available-locales="en_US" default-locale="en_US"><Name language-id="en_US">Marketing Banner</Name></root>	<?xml version='1.0' encoding='UTF-8'?><root available-locales="en_US" default-locale="en_US"><Description language-id="en_US">Marketing Banner</Description></root>	<?xml version="1.0"?>\n\n<root available-locales="en_US" default-locale="en_US">\n\t<dynamic-element dataType="string" name="radio5547" type="radio">\n\t\t<dynamic-element name="yes" type="option" value="yes">\n\t\t\t<meta-data locale="en_US">\n\t\t\t\t<entry name="label"><![CDATA[Yes]]></entry>\n\t\t\t</meta-data>\n\t\t</dynamic-element>\n\t\t<dynamic-element name="no" type="option" value="no">\n\t\t\t<meta-data locale="en_US">\n\t\t\t\t<entry name="label"><![CDATA[No]]></entry>\n\t\t\t</meta-data>\n\t\t</dynamic-element>\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="displayChildLabelAsValue"><![CDATA[true]]></entry>\n\t\t\t<entry name="label"><![CDATA[Needs Legal Review]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="readOnly"><![CDATA[false]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t\t<entry name="tip"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="text2033" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="fieldCssClass"><![CDATA[aui-w25]]></entry>\n\t\t\t<entry name="label"><![CDATA[Banner Name]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="readOnly"><![CDATA[false]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t\t<entry name="tip"><![CDATA[]]></entry>\n\t\t\t<entry name="width"><![CDATA[25]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="textarea2873" type="textarea">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="fieldCssClass"><![CDATA[aui-w25]]></entry>\n\t\t\t<entry name="label"><![CDATA[Description]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="readOnly"><![CDATA[false]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t\t<entry name="tip"><![CDATA[]]></entry>\n\t\t\t<entry name="width"><![CDATA[25]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n</root>	xml	1
42292845-e13c-4b8e-a063-361309c4c878	10556	10543	10253	10257		2017-03-10 17:05:25.1	2017-03-10 17:05:25.1	10189	Learning Module Metadata	<?xml version='1.0' encoding='UTF-8'?><root available-locales="en_US" default-locale="en_US"><Name language-id="en_US">Learning Module Metadata</Name></root>	<?xml version='1.0' encoding='UTF-8'?><root available-locales="en_US" default-locale="en_US"><Description language-id="en_US">Learning Module Metadata</Description></root>	<?xml version="1.0"?>\n\n<root available-locales="en_US" default-locale="en_US">\n\t<dynamic-element dataType="string" name="select2235" type="select">\n\t\t<dynamic-element name="home_edition" type="option" value="HE">\n\t\t\t<meta-data locale="en_US">\n\t\t\t\t<entry name="label"><![CDATA[Home Edition]]></entry>\n\t\t\t\t<entry name="multiple"><![CDATA[false]]></entry>\n\t\t\t</meta-data>\n\t\t</dynamic-element>\n\t\t<dynamic-element name="business_edition" type="option" value="BE">\n\t\t\t<meta-data locale="en_US">\n\t\t\t\t<entry name="label"><![CDATA[Business Edition]]></entry>\n\t\t\t</meta-data>\n\t\t</dynamic-element>\n\t\t<dynamic-element name="enterprise_edition" type="option" value="EE">\n\t\t\t<meta-data locale="en_US">\n\t\t\t\t<entry name="label"><![CDATA[Enterprise Edition]]></entry>\n\t\t\t</meta-data>\n\t\t</dynamic-element>\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="displayChildLabelAsValue"><![CDATA[true]]></entry>\n\t\t\t<entry name="label"><![CDATA[Product]]></entry>\n\t\t\t<entry name="multiple"><![CDATA[true]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="readOnly"><![CDATA[false]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t\t<entry name="tip"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="select3212" type="select">\n\t\t<dynamic-element name="1_0" type="option" value="1">\n\t\t\t<meta-data locale="en_US">\n\t\t\t\t<entry name="label"><![CDATA[1.0]]></entry>\n\t\t\t\t<entry name="multiple"><![CDATA[false]]></entry>\n\t\t\t</meta-data>\n\t\t</dynamic-element>\n\t\t<dynamic-element name="2_0" type="option" value="2">\n\t\t\t<meta-data locale="en_US">\n\t\t\t\t<entry name="label"><![CDATA[2.0]]></entry>\n\t\t\t</meta-data>\n\t\t</dynamic-element>\n\t\t<dynamic-element name="3_0" type="option" value="3">\n\t\t\t<meta-data locale="en_US">\n\t\t\t\t<entry name="label"><![CDATA[3.0]]></entry>\n\t\t\t</meta-data>\n\t\t</dynamic-element>\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="displayChildLabelAsValue"><![CDATA[true]]></entry>\n\t\t\t<entry name="label"><![CDATA[Version]]></entry>\n\t\t\t<entry name="multiple"><![CDATA[true]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="readOnly"><![CDATA[false]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t\t<entry name="tip"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="select4115" type="select">\n\t\t<dynamic-element name="administration" type="option" value="admin">\n\t\t\t<meta-data locale="en_US">\n\t\t\t\t<entry name="label"><![CDATA[Administration]]></entry>\n\t\t\t\t<entry name="multiple"><![CDATA[false]]></entry>\n\t\t\t</meta-data>\n\t\t</dynamic-element>\n\t\t<dynamic-element name="installation" type="option" value="install">\n\t\t\t<meta-data locale="en_US">\n\t\t\t\t<entry name="label"><![CDATA[Installation]]></entry>\n\t\t\t</meta-data>\n\t\t</dynamic-element>\n\t\t<dynamic-element name="configuration" type="option" value="config">\n\t\t\t<meta-data locale="en_US">\n\t\t\t\t<entry name="label"><![CDATA[Configuration]]></entry>\n\t\t\t</meta-data>\n\t\t</dynamic-element>\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="displayChildLabelAsValue"><![CDATA[true]]></entry>\n\t\t\t<entry name="label"><![CDATA[Topics]]></entry>\n\t\t\t<entry name="multiple"><![CDATA[true]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="readOnly"><![CDATA[false]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t\t<entry name="tip"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="select5069" type="select">\n\t\t<dynamic-element name="beginner" type="option" value="beginner">\n\t\t\t<meta-data locale="en_US">\n\t\t\t\t<entry name="label"><![CDATA[Beginner]]></entry>\n\t\t\t\t<entry name="multiple"><![CDATA[false]]></entry>\n\t\t\t</meta-data>\n\t\t</dynamic-element>\n\t\t<dynamic-element name="intermediate" type="option" value="intermediate">\n\t\t\t<meta-data locale="en_US">\n\t\t\t\t<entry name="label"><![CDATA[Intermediate]]></entry>\n\t\t\t</meta-data>\n\t\t</dynamic-element>\n\t\t<dynamic-element name="advanced" type="option" value="advanced">\n\t\t\t<meta-data locale="en_US">\n\t\t\t\t<entry name="label"><![CDATA[Advanced]]></entry>\n\t\t\t</meta-data>\n\t\t</dynamic-element>\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="displayChildLabelAsValue"><![CDATA[true]]></entry>\n\t\t\t<entry name="label"><![CDATA[Level]]></entry>\n\t\t\t<entry name="multiple"><![CDATA[false]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="readOnly"><![CDATA[false]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t\t<entry name="tip"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n</root>	xml	0
e6677947-46fb-43a1-9d69-12f8aabb0d98	10557	10543	10253	10257		2017-03-10 17:05:25.283	2017-03-10 17:05:25.283	10189	auto_0ee46dea-8c29-42f9-87a1-1b55b587548a	<?xml version='1.0' encoding='UTF-8'?><root available-locales="en_US" default-locale="en_US"><Name language-id="en_US">Online Training</Name></root>	<?xml version='1.0' encoding='UTF-8'?><root available-locales="en_US" default-locale="en_US"><Description language-id="en_US">Online Training</Description></root>	<?xml version="1.0"?>\n\n<root available-locales="en_US" default-locale="en_US">\n\t<dynamic-element dataType="string" name="text2082" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="fieldCssClass"><![CDATA[aui-w25]]></entry>\n\t\t\t<entry name="label"><![CDATA[Lesson Title]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="readOnly"><![CDATA[false]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t\t<entry name="tip"><![CDATA[]]></entry>\n\t\t\t<entry name="width"><![CDATA[25]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="text2979" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="fieldCssClass"><![CDATA[aui-w25]]></entry>\n\t\t\t<entry name="label"><![CDATA[Author]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="readOnly"><![CDATA[false]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t\t<entry name="tip"><![CDATA[]]></entry>\n\t\t\t<entry name="width"><![CDATA[25]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n</root>	xml	1
59206de2-7774-4ec2-8fda-53d9a39e660c	10558	10543	10253	10257		2017-03-10 17:05:25.151	2017-03-10 17:05:25.151	10189	Meeting Metadata	<?xml version='1.0' encoding='UTF-8'?><root available-locales="en_US" default-locale="en_US"><Name language-id="en_US">Meeting Metadata</Name></root>	<?xml version='1.0' encoding='UTF-8'?><root available-locales="en_US" default-locale="en_US"><Description language-id="en_US">Metadata for meeting</Description></root>	<?xml version="1.0"?>\n\n<root available-locales="en_US" default-locale="en_US">\n\t<dynamic-element dataType="date" fieldNamespace="ddm" name="ddm-date3054" type="ddm-date">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="fieldCssClass"><![CDATA[aui-w25]]></entry>\n\t\t\t<entry name="label"><![CDATA[Date]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="readOnly"><![CDATA[false]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t\t<entry name="tip"><![CDATA[]]></entry>\n\t\t\t<entry name="width"><![CDATA[25]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="text2217" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="fieldCssClass"><![CDATA[aui-w25]]></entry>\n\t\t\t<entry name="label"><![CDATA[Meeting Name]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="readOnly"><![CDATA[false]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t\t<entry name="tip"><![CDATA[]]></entry>\n\t\t\t<entry name="width"><![CDATA[25]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="text4569" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="fieldCssClass"><![CDATA[aui-w25]]></entry>\n\t\t\t<entry name="label"><![CDATA[Time]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="readOnly"><![CDATA[false]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t\t<entry name="tip"><![CDATA[]]></entry>\n\t\t\t<entry name="width"><![CDATA[25]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="text5638" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="fieldCssClass"><![CDATA[aui-w25]]></entry>\n\t\t\t<entry name="label"><![CDATA[Location]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="readOnly"><![CDATA[false]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t\t<entry name="tip"><![CDATA[]]></entry>\n\t\t\t<entry name="width"><![CDATA[25]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="textarea6584" type="textarea">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="fieldCssClass"><![CDATA[aui-w25]]></entry>\n\t\t\t<entry name="label"><![CDATA[Description]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="readOnly"><![CDATA[false]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t\t<entry name="tip"><![CDATA[]]></entry>\n\t\t\t<entry name="width"><![CDATA[25]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="textarea7502" type="textarea">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="fieldCssClass"><![CDATA[aui-w25]]></entry>\n\t\t\t<entry name="label"><![CDATA[Participants]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="readOnly"><![CDATA[false]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t\t<entry name="tip"><![CDATA[]]></entry>\n\t\t\t<entry name="width"><![CDATA[25]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n</root>	xml	0
6986c7ff-dffa-48de-a8e7-704de93e0b25	10559	10543	10253	10257		2017-03-10 17:05:25.312	2017-03-10 17:05:25.312	10189	auto_b00fb30c-2c8a-4bfa-83ec-e6259801d5e4	<?xml version='1.0' encoding='UTF-8'?><root available-locales="en_US" default-locale="en_US"><Name language-id="en_US">Sales Presentation</Name></root>	<?xml version='1.0' encoding='UTF-8'?><root available-locales="en_US" default-locale="en_US"><Description language-id="en_US">Sales Presentation</Description></root>	<?xml version="1.0"?>\n\n<root available-locales="en_US" default-locale="en_US">\n\t<dynamic-element dataType="string" name="select2890" type="select">\n\t\t<dynamic-element name="home_edition" type="option" value="HE">\n\t\t\t<meta-data locale="en_US">\n\t\t\t\t<entry name="label"><![CDATA[Home Edition]]></entry>\n\t\t\t\t<entry name="multiple"><![CDATA[false]]></entry>\n\t\t\t</meta-data>\n\t\t</dynamic-element>\n\t\t<dynamic-element name="business_edition" type="option" value="BE">\n\t\t\t<meta-data locale="en_US">\n\t\t\t\t<entry name="label"><![CDATA[Business Edition]]></entry>\n\t\t\t</meta-data>\n\t\t</dynamic-element>\n\t\t<dynamic-element name="enterprise_edition" type="option" value="EE">\n\t\t\t<meta-data locale="en_US">\n\t\t\t\t<entry name="label"><![CDATA[Enterprise Edition]]></entry>\n\t\t\t</meta-data>\n\t\t</dynamic-element>\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="displayChildLabelAsValue"><![CDATA[true]]></entry>\n\t\t\t<entry name="label"><![CDATA[Product]]></entry>\n\t\t\t<entry name="multiple"><![CDATA[false]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="readOnly"><![CDATA[false]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t\t<entry name="tip"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="select3864" type="select">\n\t\t<dynamic-element name="1_0" type="option" value="1">\n\t\t\t<meta-data locale="en_US">\n\t\t\t\t<entry name="label"><![CDATA[1.0]]></entry>\n\t\t\t\t<entry name="multiple"><![CDATA[false]]></entry>\n\t\t\t</meta-data>\n\t\t</dynamic-element>\n\t\t<dynamic-element name="2_0" type="option" value="2">\n\t\t\t<meta-data locale="en_US">\n\t\t\t\t<entry name="label"><![CDATA[2.0]]></entry>\n\t\t\t</meta-data>\n\t\t</dynamic-element>\n\t\t<dynamic-element name="3_0" type="option" value="3">\n\t\t\t<meta-data locale="en_US">\n\t\t\t\t<entry name="label"><![CDATA[3.0]]></entry>\n\t\t\t</meta-data>\n\t\t</dynamic-element>\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="displayChildLabelAsValue"><![CDATA[true]]></entry>\n\t\t\t<entry name="label"><![CDATA[Version]]></entry>\n\t\t\t<entry name="multiple"><![CDATA[false]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="readOnly"><![CDATA[false]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t\t<entry name="tip"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="select4831" type="select">\n\t\t<dynamic-element name="website" type="option" value="website">\n\t\t\t<meta-data locale="en_US">\n\t\t\t\t<entry name="label"><![CDATA[Website]]></entry>\n\t\t\t\t<entry name="multiple"><![CDATA[false]]></entry>\n\t\t\t</meta-data>\n\t\t</dynamic-element>\n\t\t<dynamic-element name="collaboration" type="option" value="collaboration">\n\t\t\t<meta-data locale="en_US">\n\t\t\t\t<entry name="label"><![CDATA[Collaboration]]></entry>\n\t\t\t</meta-data>\n\t\t</dynamic-element>\n\t\t<dynamic-element name="intranet" type="option" value="intranet">\n\t\t\t<meta-data locale="en_US">\n\t\t\t\t<entry name="label"><![CDATA[Intranet]]></entry>\n\t\t\t</meta-data>\n\t\t</dynamic-element>\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="displayChildLabelAsValue"><![CDATA[true]]></entry>\n\t\t\t<entry name="label"><![CDATA[Areas of Interest]]></entry>\n\t\t\t<entry name="multiple"><![CDATA[true]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="readOnly"><![CDATA[false]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t\t<entry name="tip"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="select5929" type="select">\n\t\t<dynamic-element name="acme" type="option" value="acme">\n\t\t\t<meta-data locale="en_US">\n\t\t\t\t<entry name="label"><![CDATA[ACME]]></entry>\n\t\t\t\t<entry name="multiple"><![CDATA[false]]></entry>\n\t\t\t</meta-data>\n\t\t</dynamic-element>\n\t\t<dynamic-element name="sevencogs" type="option" value="sevencogs">\n\t\t\t<meta-data locale="en_US">\n\t\t\t\t<entry name="label"><![CDATA[SevenCogs]]></entry>\n\t\t\t</meta-data>\n\t\t</dynamic-element>\n\t\t<dynamic-element name="freeplus" type="option" value="freeplus">\n\t\t\t<meta-data locale="en_US">\n\t\t\t\t<entry name="label"><![CDATA[FreePlus]]></entry>\n\t\t\t</meta-data>\n\t\t</dynamic-element>\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="displayChildLabelAsValue"><![CDATA[true]]></entry>\n\t\t\t<entry name="label"><![CDATA[Competitors]]></entry>\n\t\t\t<entry name="multiple"><![CDATA[true]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="readOnly"><![CDATA[false]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t\t<entry name="tip"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="text1993" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="fieldCssClass"><![CDATA[aui-w25]]></entry>\n\t\t\t<entry name="label"><![CDATA[Prospect Name]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="readOnly"><![CDATA[false]]></entry>\n\t\t\t<entry name="required"><![CDATA[false]]></entry>\n\t\t\t<entry name="showLabel"><![CDATA[true]]></entry>\n\t\t\t<entry name="tip"><![CDATA[]]></entry>\n\t\t\t<entry name="width"><![CDATA[25]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n</root>	xml	1
\.


--
-- Data for Name: ddmstructurelink; Type: TABLE DATA; Schema: public; Owner: root
--

COPY ddmstructurelink (structurelinkid, classnameid, classpk, structureid) FROM stdin;
\.


--
-- Data for Name: ddmtemplate; Type: TABLE DATA; Schema: public; Owner: root
--

COPY ddmtemplate (uuid_, templateid, groupid, companyid, userid, username, createdate, modifieddate, structureid, name, description, type_, mode_, language, script) FROM stdin;
\.


--
-- Data for Name: dlcontent; Type: TABLE DATA; Schema: public; Owner: root
--

COPY dlcontent (contentid, groupid, companyid, repositoryid, path_, version, data_, size_) FROM stdin;
\.


--
-- Data for Name: dlfileentry; Type: TABLE DATA; Schema: public; Owner: root
--

COPY dlfileentry (uuid_, fileentryid, groupid, companyid, userid, username, versionuserid, versionusername, createdate, modifieddate, repositoryid, folderid, name, extension, mimetype, title, description, extrasettings, fileentrytypeid, version, size_, readcount, smallimageid, largeimageid, custom1imageid, custom2imageid) FROM stdin;
\.


--
-- Data for Name: dlfileentrymetadata; Type: TABLE DATA; Schema: public; Owner: root
--

COPY dlfileentrymetadata (uuid_, fileentrymetadataid, ddmstorageid, ddmstructureid, fileentrytypeid, fileentryid, fileversionid) FROM stdin;
\.


--
-- Data for Name: dlfileentrytype; Type: TABLE DATA; Schema: public; Owner: root
--

COPY dlfileentrytype (uuid_, fileentrytypeid, groupid, companyid, userid, username, createdate, modifieddate, name, description) FROM stdin;
5bd37ebc-17ff-477e-a295-182c67a98b57	0	0	0	0		2017-03-10 17:05:15.551	2017-03-10 17:05:15.551	Basic Document	
67e88d49-a22d-4760-aa45-c791c50e81a5	10400	10291	10253	10257		2017-03-10 17:05:25.235	2017-03-10 17:05:25.235	Contract	Contract
c8fa47e9-5255-46f3-87ac-39a418dd4482	10402	10291	10253	10257		2017-03-10 17:05:25.271	2017-03-10 17:05:25.271	Marketing Banner	Marketing Banner
0ee46dea-8c29-42f9-87a1-1b55b587548a	10404	10291	10253	10257		2017-03-10 17:05:25.297	2017-03-10 17:05:25.297	Online Training	Online Training
b00fb30c-2c8a-4bfa-83ec-e6259801d5e4	10406	10291	10253	10257		2017-03-10 17:05:25.33	2017-03-10 17:05:25.33	Sales Presentation	Sales Presentation
\.


--
-- Data for Name: dlfileentrytypes_ddmstructures; Type: TABLE DATA; Schema: public; Owner: root
--

COPY dlfileentrytypes_ddmstructures (structureid, fileentrytypeid) FROM stdin;
10401	10400
10398	10402
10403	10402
10397	10404
10405	10404
10399	10406
10407	10406
\.


--
-- Data for Name: dlfileentrytypes_dlfolders; Type: TABLE DATA; Schema: public; Owner: root
--

COPY dlfileentrytypes_dlfolders (fileentrytypeid, folderid) FROM stdin;
\.


--
-- Data for Name: dlfilerank; Type: TABLE DATA; Schema: public; Owner: root
--

COPY dlfilerank (filerankid, groupid, companyid, userid, createdate, fileentryid) FROM stdin;
\.


--
-- Data for Name: dlfileshortcut; Type: TABLE DATA; Schema: public; Owner: root
--

COPY dlfileshortcut (uuid_, fileshortcutid, groupid, companyid, userid, username, createdate, modifieddate, repositoryid, folderid, tofileentryid, status, statusbyuserid, statusbyusername, statusdate) FROM stdin;
\.


--
-- Data for Name: dlfileversion; Type: TABLE DATA; Schema: public; Owner: root
--

COPY dlfileversion (uuid_, fileversionid, groupid, companyid, userid, username, createdate, modifieddate, repositoryid, folderid, fileentryid, extension, mimetype, title, description, changelog, extrasettings, fileentrytypeid, version, size_, status, statusbyuserid, statusbyusername, statusdate) FROM stdin;
\.


--
-- Data for Name: dlfolder; Type: TABLE DATA; Schema: public; Owner: root
--

COPY dlfolder (uuid_, folderid, groupid, companyid, userid, username, createdate, modifieddate, repositoryid, mountpoint, parentfolderid, name, description, lastpostdate, defaultfileentrytypeid, overridefileentrytypes) FROM stdin;
\.


--
-- Data for Name: dlsync; Type: TABLE DATA; Schema: public; Owner: root
--

COPY dlsync (syncid, companyid, createdate, modifieddate, fileid, fileuuid, repositoryid, parentfolderid, name, description, event, type_, version) FROM stdin;
\.


--
-- Data for Name: emailaddress; Type: TABLE DATA; Schema: public; Owner: root
--

COPY emailaddress (emailaddressid, companyid, userid, username, createdate, modifieddate, classnameid, classpk, address, typeid, primary_) FROM stdin;
\.


--
-- Data for Name: expandocolumn; Type: TABLE DATA; Schema: public; Owner: root
--

COPY expandocolumn (columnid, companyid, tableid, name, type_, defaultdata, typesettings) FROM stdin;
10506	10253	10505	manualCheckInRequired	1		hidden=true\n
10512	10253	10511	clientId	15		
\.


--
-- Data for Name: expandorow; Type: TABLE DATA; Schema: public; Owner: root
--

COPY expandorow (rowid_, companyid, tableid, classpk) FROM stdin;
\.


--
-- Data for Name: expandotable; Type: TABLE DATA; Schema: public; Owner: root
--

COPY expandotable (tableid, companyid, classnameid, name) FROM stdin;
10505	10253	10110	CUSTOM_FIELDS
10511	10253	10105	MP
10549	10253	10102	CUSTOM_FIELDS
10550	10253	10201	CUSTOM_FIELDS
10551	10253	10190	CUSTOM_FIELDS
\.


--
-- Data for Name: expandovalue; Type: TABLE DATA; Schema: public; Owner: root
--

COPY expandovalue (valueid, companyid, tableid, columnid, rowid_, classnameid, classpk, data_) FROM stdin;
\.


--
-- Data for Name: group_; Type: TABLE DATA; Schema: public; Owner: root
--

COPY group_ (groupid, companyid, creatoruserid, classnameid, classpk, parentgroupid, livegroupid, name, description, type_, typesettings, friendlyurl, site, active_) FROM stdin;
10271	10253	10257	10101	10271	0	0	Control Panel		3		/control_panel	f	t
10279	10253	10257	10101	10279	0	0	Guest		1		/guest	t	t
10288	10253	10257	10287	10257	0	0	User Personal Site		3		/personal_site	f	t
10291	10253	10257	10121	10253	0	0	10253		0		/global	f	t
10298	10253	10295	10105	10295	0	0	10295		0		/test	f	t
10410	10253	10257	10127	10409	0	0	10409		0		/template-10409	f	t
10420	10253	10257	10127	10419	0	0	10419		0		/template-10419	f	t
10429	10253	10257	10127	10428	0	0	10428		0		/template-10428	f	t
10438	10253	10257	10131	10437	0	0	10437		0		/template-10437	f	t
10464	10253	10257	10131	10463	0	0	10463		0		/template-10463	f	t
10532	10253	10295	10101	10532	0	0	Staging Site		1	staged-portlet_178=true\nstaged-portlet_166=true\nstaged-portlet_8=true\nstaged-portlet_167=true\nbranchingPublic=false\nstaged-portlet_161=true\nstaged-portlet_108=true\nstagedRemotely=false\nstaged-portlet_107=true\nbranchingPrivate=false\nstaged-portlet_56=true\nstaged-portlet_15=true\nstaged-portlet_28=true\nstaged-portlet_169=true\nstaged-portlet_39=true\nstaged-portlet_54=true\nstaged-portlet_110=true\nstaged-portlet_19=true\nstaged-portlet_36=true\nstaged-portlet_20=true\nstaged-portlet_59=true\nstaged-portlet_25=true\nstaged=true\n	/staging-site	t	t
10543	10253	10295	10101	10543	0	10532	Staging Site (Staging)		1		/staging-site-staging	f	t
\.


--
-- Data for Name: groups_orgs; Type: TABLE DATA; Schema: public; Owner: root
--

COPY groups_orgs (groupid, organizationid) FROM stdin;
\.


--
-- Data for Name: groups_permissions; Type: TABLE DATA; Schema: public; Owner: root
--

COPY groups_permissions (groupid, permissionid) FROM stdin;
\.


--
-- Data for Name: groups_roles; Type: TABLE DATA; Schema: public; Owner: root
--

COPY groups_roles (groupid, roleid) FROM stdin;
\.


--
-- Data for Name: groups_usergroups; Type: TABLE DATA; Schema: public; Owner: root
--

COPY groups_usergroups (groupid, usergroupid) FROM stdin;
\.


--
-- Data for Name: image; Type: TABLE DATA; Schema: public; Owner: root
--

COPY image (imageid, modifieddate, text_, type_, height, width, size_) FROM stdin;
\.


--
-- Data for Name: journalarticle; Type: TABLE DATA; Schema: public; Owner: root
--

COPY journalarticle (uuid_, id_, resourceprimkey, groupid, companyid, userid, username, createdate, modifieddate, classnameid, classpk, articleid, version, title, urltitle, description, content, type_, structureid, templateid, layoutuuid, displaydate, expirationdate, reviewdate, indexable, smallimage, smallimageid, smallimageurl, status, statusbyuserid, statusbyusername, statusdate) FROM stdin;
3bd2fea7-ecbb-4c8a-8dd9-626fee43c39d	10571	10572	10543	10253	10295	Test Test	2017-03-10 17:07:25.411	2017-03-10 17:07:25.505	0	0	10570	1	<?xml version='1.0' encoding='UTF-8'?><root available-locales="en_US" default-locale="en_US"><Title language-id="en_US">Web Content Title</Title></root>	web-content-title		<?xml version="1.0"?>\n\n<root available-locales="en_US" default-locale="en_US">\n\t<static-content language-id="en_US"><![CDATA[Web Content Content]]></static-content>\n</root>	general				2017-03-10 17:07:00	\N	\N	t	f	10573		0	10295	Test Test	2017-03-10 17:07:25.505
\.


--
-- Data for Name: journalarticleimage; Type: TABLE DATA; Schema: public; Owner: root
--

COPY journalarticleimage (articleimageid, groupid, articleid, version, elinstanceid, elname, languageid, tempimage) FROM stdin;
\.


--
-- Data for Name: journalarticleresource; Type: TABLE DATA; Schema: public; Owner: root
--

COPY journalarticleresource (uuid_, resourceprimkey, groupid, articleid) FROM stdin;
6d0f5b38-eb73-4a3b-9930-fb4fe3917ceb	10572	10543	10570
\.


--
-- Data for Name: journalcontentsearch; Type: TABLE DATA; Schema: public; Owner: root
--

COPY journalcontentsearch (contentsearchid, groupid, companyid, privatelayout, layoutid, portletid, articleid) FROM stdin;
10579	10543	10253	f	1	56_INSTANCE_boWWn8HG3Ulm	10570
\.


--
-- Data for Name: journalfeed; Type: TABLE DATA; Schema: public; Owner: root
--

COPY journalfeed (uuid_, id_, groupid, companyid, userid, username, createdate, modifieddate, feedid, name, description, type_, structureid, templateid, renderertemplateid, delta, orderbycol, orderbytype, targetlayoutfriendlyurl, targetportletid, contentfield, feedtype, feedversion) FROM stdin;
\.


--
-- Data for Name: journalstructure; Type: TABLE DATA; Schema: public; Owner: root
--

COPY journalstructure (uuid_, id_, groupid, companyid, userid, username, createdate, modifieddate, structureid, parentstructureid, name, description, xsd) FROM stdin;
\.


--
-- Data for Name: journaltemplate; Type: TABLE DATA; Schema: public; Owner: root
--

COPY journaltemplate (uuid_, id_, groupid, companyid, userid, username, createdate, modifieddate, templateid, structureid, name, description, xsl, langtype, cacheable, smallimage, smallimageid, smallimageurl) FROM stdin;
\.


--
-- Data for Name: layout; Type: TABLE DATA; Schema: public; Owner: root
--

COPY layout (uuid_, plid, groupid, companyid, createdate, modifieddate, privatelayout, layoutid, parentlayoutid, name, title, description, keywords, robots, type_, typesettings, hidden_, friendlyurl, iconimage, iconimageid, themeid, colorschemeid, wapthemeid, wapcolorschemeid, css, priority, layoutprototypeuuid, layoutprototypelinkenabled, sourceprototypelayoutuuid) FROM stdin;
c1ad484e-6fb6-4c9f-b33d-123495a1d08c	10274	10271	10253	2017-03-10 17:05:22.736	2017-03-10 17:05:22.736	t	1	0	<?xml version='1.0' encoding='UTF-8'?><root available-locales="en_US" default-locale="en_US"><Name language-id="en_US">Control Panel</Name></root>					control_panel		f	/manage	f	0						0		f	
de1dbdd6-d600-4a5e-88ec-79fcfd82b817	10282	10279	10253	2017-03-10 17:05:23.107	2017-03-10 17:05:23.222	f	1	0	<?xml version='1.0' encoding='UTF-8'?><root available-locales="en_US" default-locale="en_US"><Name language-id="en_US">Welcome</Name></root>					portlet	layout-template-id=2_columns_ii\ncolumn-2=47,\ncolumn-1=58,\n	f	/home	f	0						0		f	
47dc8a94-acae-448f-aba8-058407db7c12	10480	10464	10253	2017-03-10 17:05:26.86	2017-03-10 17:05:26.918	t	2	0	<?xml version='1.0' encoding='UTF-8'?><root available-locales="en_US" default-locale="en_US"><Name language-id="en_US">Documents and Media</Name></root>					portlet	layout-template-id=1_column\ncolumn-1=20,\n	f	/documents	f	0						1		f	
0963eb62-140a-45c4-b014-e666bab0dee6	10413	10410	10253	2017-03-10 17:05:25.45	2017-03-10 17:05:25.615	t	1	0	<?xml version='1.0' encoding='UTF-8'?><root available-locales="en_US" default-locale="en_US"><Name language-id="en_US">Blog</Name></root>					portlet	layout-template-id=2_columns_iii\ncolumn-2=148_INSTANCE_aZWjS4vM0nuU,114,\ncolumn-1=33,\n	f	/layout	f	0						0		f	
28214bcd-4ec5-4303-ae81-3d1f555a6b5f	10492	10464	10253	2017-03-10 17:05:27.019	2017-03-10 17:05:27.122	t	4	0	<?xml version='1.0' encoding='UTF-8'?><root available-locales="en_US" default-locale="en_US"><Name language-id="en_US">News</Name></root>					portlet	layout-template-id=2_columns_iii\ncolumn-2=39_INSTANCE_4bhYHCNT0KW1,\ncolumn-1=39_INSTANCE_antTeGz671qI,\n	f	/news	f	0						3		f	
2d03479d-3066-4a81-9dda-504e481559ca	10446	10438	10253	2017-03-10 17:05:26.258	2017-03-10 17:05:26.413	t	1	0	<?xml version='1.0' encoding='UTF-8'?><root available-locales="en_US" default-locale="en_US"><Name language-id="en_US">Home</Name></root>					portlet	layout-template-id=2_columns_iii\ncolumn-2=3,59_INSTANCE_2C28N68835iy,180,\ncolumn-1=19,\n	f	/home	f	0						0		f	
95e284b9-87eb-4772-8dd8-2a784baeb9bd	10423	10420	10253	2017-03-10 17:05:25.647	2017-03-10 17:05:25.737	t	1	0	<?xml version='1.0' encoding='UTF-8'?><root available-locales="en_US" default-locale="en_US"><Name language-id="en_US">Content Display Page</Name></root>					portlet	default-asset-publisher-portlet-id=101_INSTANCE_M9kwDXHMGGhu\nlayout-template-id=2_columns_ii\ncolumn-2=3,101_INSTANCE_M9kwDXHMGGhu,\ncolumn-1=141_INSTANCE_WWalkjJ71IUF,122_INSTANCE_Nri1pyDR8zEN,\n	f	/layout	f	0						0		f	
2ef9d0f8-f784-4520-95b9-eafc3c6bee8d	10486	10464	10253	2017-03-10 17:05:26.931	2017-03-10 17:05:27.005	t	3	0	<?xml version='1.0' encoding='UTF-8'?><root available-locales="en_US" default-locale="en_US"><Name language-id="en_US">Calendar</Name></root>					portlet	layout-template-id=2_columns_iii\ncolumn-2=101_INSTANCE_We5LrTgiQkYg,\ncolumn-1=8,\n	f	/calendar	f	0						2		f	
ac6faa86-7870-470a-b0e5-438d2deac6f8	10432	10429	10253	2017-03-10 17:05:25.766	2017-03-10 17:05:25.828	t	1	0	<?xml version='1.0' encoding='UTF-8'?><root available-locales="en_US" default-locale="en_US"><Name language-id="en_US">Wiki</Name></root>					portlet	layout-template-id=2_columns_iii\ncolumn-2=122_INSTANCE_lMr0KV3z5FuN,141_INSTANCE_hXpkne8EiJkJ,\ncolumn-1=36,\n	f	/layout	f	0						0		f	
d5826dad-5a50-4885-9cde-3829079adf6a	10452	10438	10253	2017-03-10 17:05:26.437	2017-03-10 17:05:26.531	t	2	0	<?xml version='1.0' encoding='UTF-8'?><root available-locales="en_US" default-locale="en_US"><Name language-id="en_US">Calendar</Name></root>					portlet	layout-template-id=2_columns_iii\ncolumn-2=101_INSTANCE_qTe3aLnxiq7q,\ncolumn-1=8,\n	f	/calendar	f	0						1		f	
ce68d68a-62a4-4cb2-94f7-958bde05c60d	10472	10464	10253	2017-03-10 17:05:26.756	2017-03-10 17:05:26.851	t	1	0	<?xml version='1.0' encoding='UTF-8'?><root available-locales="en_US" default-locale="en_US"><Name language-id="en_US">Home</Name></root>					portlet	layout-template-id=2_columns_i\ncolumn-2=3,82,101_INSTANCE_6ACzn2Dhha8M,\ncolumn-1=116,\n	f	/home	f	0						0		f	
1c2031e0-0267-4448-a9d1-276fdcac67c6	10458	10438	10253	2017-03-10 17:05:26.543	2017-03-10 17:05:26.637	t	3	0	<?xml version='1.0' encoding='UTF-8'?><root available-locales="en_US" default-locale="en_US"><Name language-id="en_US">Wiki</Name></root>					portlet	layout-template-id=2_columns_iii\ncolumn-2=122_INSTANCE_tfh1moA2SExq,148_INSTANCE_la4xhdCy815q,\ncolumn-1=36,\n	f	/wiki	f	0						2		f	
838c20a4-ce98-41ab-83dd-731e643113ce	10517	10298	10253	2017-03-10 17:06:13.679	2017-03-10 17:06:13.704	t	1	0	<?xml version='1.0' encoding='UTF-8'?><root available-locales="en_US" default-locale="en_US"><Name language-id="en_US">Welcome</Name></root>					portlet	layout-template-id=2_columns_ii\ncolumn-2=29,8,\ncolumn-1=82,23,11,\n	f	/home	f	0						0		f	
77180190-5fef-40a3-a223-4b7235292074	10522	10298	10253	2017-03-10 17:06:13.714	2017-03-10 17:06:13.738	f	1	0	<?xml version='1.0' encoding='UTF-8'?><root available-locales="en_US" default-locale="en_US"><Name language-id="en_US">Welcome</Name></root>					portlet	layout-template-id=2_columns_ii\ncolumn-2=33,\ncolumn-1=82,3,\n	f	/home	f	0						0		f	
a9015e6b-7e42-46b9-aac0-21cf4beab41c	10537	10532	10253	2017-03-10 17:06:44.513	2017-03-10 17:06:44.513	f	1	0	<?xml version='1.0' encoding='UTF-8'?><root available-locales="en_US" default-locale="en_US"><Name language-id="en_US">Staging Site Page</Name></root>					portlet	layout-template-id=2_columns_ii\n	f	/staging-site-page	f	0						0		f	
a9015e6b-7e42-46b9-aac0-21cf4beab41c	10552	10543	10253	2017-03-10 17:06:44.513	2017-03-10 17:07:25.559	f	1	0	<?xml version='1.0' encoding='UTF-8'?><root available-locales="en_US" default-locale="en_US"><Name language-id="en_US">Staging Site Page</Name></root>					portlet	layout-template-id=2_columns_ii\ncolumn-1=56_INSTANCE_boWWn8HG3Ulm\n	f	/staging-site-page	f	0						0		f	
\.


--
-- Data for Name: layoutbranch; Type: TABLE DATA; Schema: public; Owner: root
--

COPY layoutbranch (layoutbranchid, groupid, companyid, userid, username, layoutsetbranchid, plid, name, description, master) FROM stdin;
\.


--
-- Data for Name: layoutprototype; Type: TABLE DATA; Schema: public; Owner: root
--

COPY layoutprototype (uuid_, layoutprototypeid, companyid, name, description, settings_, active_) FROM stdin;
498fd640-243c-4096-b8c4-a39b9d239d4d	10409	10253	<?xml version='1.0' encoding='UTF-8'?><root available-locales="en_US" default-locale="en_US"><Name language-id="en_US">Blog</Name></root>	Create, edit, and view blogs from this page. Explore topics using tags, and connect with other members that blog.		t
3a159bfe-cd1c-487f-b9a2-2edb9110e8f5	10419	10253	<?xml version='1.0' encoding='UTF-8'?><root available-locales="en_US" default-locale="en_US"><Name language-id="en_US">Content Display Page</Name></root>	Create, edit, and explore web content with this page. Search available content, explore related content with tags, and browse content categories.		t
ca97b536-0bff-469c-8ec6-4740e3ff1f84	10428	10253	<?xml version='1.0' encoding='UTF-8'?><root available-locales="en_US" default-locale="en_US"><Name language-id="en_US">Wiki</Name></root>	Collaborate with members through the wiki on this page. Discover related content through tags, and navigate quickly and easily with categories.		t
\.


--
-- Data for Name: layoutrevision; Type: TABLE DATA; Schema: public; Owner: root
--

COPY layoutrevision (layoutrevisionid, groupid, companyid, userid, username, createdate, modifieddate, layoutsetbranchid, layoutbranchid, parentlayoutrevisionid, head, major, plid, privatelayout, name, title, description, keywords, robots, typesettings, iconimage, iconimageid, themeid, colorschemeid, wapthemeid, wapcolorschemeid, css, status, statusbyuserid, statusbyusername, statusdate) FROM stdin;
\.


--
-- Data for Name: layoutset; Type: TABLE DATA; Schema: public; Owner: root
--

COPY layoutset (layoutsetid, groupid, companyid, createdate, modifieddate, privatelayout, logo, logoid, themeid, colorschemeid, wapthemeid, wapcolorschemeid, css, pagecount, settings_, layoutsetprototypeuuid, layoutsetprototypelinkenabled) FROM stdin;
10273	10271	10253	2017-03-10 17:05:22.671	2017-03-10 17:05:22.671	f	f	0	classic	01	mobile	01		0			f
10272	10271	10253	2017-03-10 17:05:22.652	2017-03-10 17:05:22.804	t	f	0	classic	01	mobile	01		1			f
10280	10279	10253	2017-03-10 17:05:23.085	2017-03-10 17:05:23.085	t	f	0	classic	01	mobile	01		0			f
10281	10279	10253	2017-03-10 17:05:23.088	2017-03-10 17:05:23.141	f	f	0	classic	01	mobile	01		1			f
10289	10288	10253	2017-03-10 17:05:23.252	2017-03-10 17:05:23.252	t	f	0	classic	01	mobile	01		0			f
10290	10288	10253	2017-03-10 17:05:23.254	2017-03-10 17:05:23.254	f	f	0	classic	01	mobile	01		0			f
10292	10291	10253	2017-03-10 17:05:23.603	2017-03-10 17:05:23.603	t	f	0	classic	01	mobile	01		0			f
10293	10291	10253	2017-03-10 17:05:23.605	2017-03-10 17:05:23.605	f	f	0	classic	01	mobile	01		0			f
10412	10410	10253	2017-03-10 17:05:25.429	2017-03-10 17:05:25.429	f	f	0	classic	01	mobile	01		0			f
10411	10410	10253	2017-03-10 17:05:25.427	2017-03-10 17:05:25.472	t	f	0	classic	01	mobile	01		1			f
10422	10420	10253	2017-03-10 17:05:25.639	2017-03-10 17:05:25.639	f	f	0	classic	01	mobile	01		0			f
10421	10420	10253	2017-03-10 17:05:25.638	2017-03-10 17:05:25.659	t	f	0	classic	01	mobile	01		1			f
10431	10429	10253	2017-03-10 17:05:25.757	2017-03-10 17:05:25.757	f	f	0	classic	01	mobile	01		0			f
10430	10429	10253	2017-03-10 17:05:25.754	2017-03-10 17:05:25.778	t	f	0	classic	01	mobile	01		1			f
10440	10438	10253	2017-03-10 17:05:25.87	2017-03-10 17:05:25.87	f	f	0	classic	01	mobile	01		0			f
10465	10464	10253	2017-03-10 17:05:26.663	2017-03-10 17:05:27.122	t	f	0	classic	01	mobile	01		4			f
10299	10298	10253	2017-03-10 17:05:23.88	2017-03-10 17:06:13.685	t	f	0	classic	01	mobile	01		1			f
10300	10298	10253	2017-03-10 17:05:23.882	2017-03-10 17:06:13.723	f	f	0	classic	01	mobile	01		1			f
10533	10532	10253	2017-03-10 17:06:29.96	2017-03-10 17:07:06.968	t	f	0	classic	01	mobile	01		0			f
10544	10543	10253	2017-03-10 17:07:06.978	2017-03-10 17:07:06.978	t	f	0	classic	01	mobile	01		0			f
10534	10532	10253	2017-03-10 17:06:29.961	2017-03-10 17:07:07.806	f	f	0	classic	01	mobile	01		1	last-publish-date=1489165626999\n		f
10439	10438	10253	2017-03-10 17:05:25.858	2017-03-10 17:05:26.637	t	f	0	classic	01	mobile	01		3			f
10466	10464	10253	2017-03-10 17:05:26.666	2017-03-10 17:05:26.666	f	f	0	classic	01	mobile	01		0			f
10545	10543	10253	2017-03-10 17:07:06.979	2017-03-10 17:07:08.273	f	f	0	classic	01	mobile	01		1			f
\.


--
-- Data for Name: layoutsetbranch; Type: TABLE DATA; Schema: public; Owner: root
--

COPY layoutsetbranch (layoutsetbranchid, groupid, companyid, userid, username, createdate, modifieddate, privatelayout, name, description, master, logo, logoid, themeid, colorschemeid, wapthemeid, wapcolorschemeid, css, settings_, layoutsetprototypeuuid, layoutsetprototypelinkenabled) FROM stdin;
\.


--
-- Data for Name: layoutsetprototype; Type: TABLE DATA; Schema: public; Owner: root
--

COPY layoutsetprototype (uuid_, layoutsetprototypeid, companyid, createdate, modifieddate, name, description, settings_, active_) FROM stdin;
e624558f-1d72-4c00-95e6-92558c76bb7c	10437	10253	2017-03-10 17:05:25.845	2017-03-10 17:05:26.637	<?xml version='1.0' encoding='UTF-8'?><root available-locales="en_US" default-locale="en_US"><Name language-id="en_US">Community Site</Name></root>	Site with Forums, Calendar and Wiki	layoutsUpdateable=true\n	t
3413e9eb-9fc5-46df-b6b5-d4d81ac29294	10463	10253	2017-03-10 17:05:26.65	2017-03-10 17:05:27.122	<?xml version='1.0' encoding='UTF-8'?><root available-locales="en_US" default-locale="en_US"><Name language-id="en_US">Intranet Site</Name></root>	Site with Documents, Calendar and News	layoutsUpdateable=true\n	t
\.


--
-- Data for Name: listtype; Type: TABLE DATA; Schema: public; Owner: root
--

COPY listtype (listtypeid, name, type_) FROM stdin;
10000	billing	com.liferay.portal.model.Account.address
10001	other	com.liferay.portal.model.Account.address
10002	p-o-box	com.liferay.portal.model.Account.address
10003	shipping	com.liferay.portal.model.Account.address
10004	email-address	com.liferay.portal.model.Account.emailAddress
10005	email-address-2	com.liferay.portal.model.Account.emailAddress
10006	email-address-3	com.liferay.portal.model.Account.emailAddress
10007	fax	com.liferay.portal.model.Account.phone
10008	local	com.liferay.portal.model.Account.phone
10009	other	com.liferay.portal.model.Account.phone
10010	toll-free	com.liferay.portal.model.Account.phone
10011	tty	com.liferay.portal.model.Account.phone
10012	intranet	com.liferay.portal.model.Account.website
10013	public	com.liferay.portal.model.Account.website
11000	business	com.liferay.portal.model.Contact.address
11001	other	com.liferay.portal.model.Contact.address
11002	personal	com.liferay.portal.model.Contact.address
11003	email-address	com.liferay.portal.model.Contact.emailAddress
11004	email-address-2	com.liferay.portal.model.Contact.emailAddress
11005	email-address-3	com.liferay.portal.model.Contact.emailAddress
11006	business	com.liferay.portal.model.Contact.phone
11007	business-fax	com.liferay.portal.model.Contact.phone
11008	mobile-phone	com.liferay.portal.model.Contact.phone
11009	other	com.liferay.portal.model.Contact.phone
11010	pager	com.liferay.portal.model.Contact.phone
11011	personal	com.liferay.portal.model.Contact.phone
11012	personal-fax	com.liferay.portal.model.Contact.phone
11013	tty	com.liferay.portal.model.Contact.phone
11014	dr	com.liferay.portal.model.Contact.prefix
11015	mr	com.liferay.portal.model.Contact.prefix
11016	mrs	com.liferay.portal.model.Contact.prefix
11017	ms	com.liferay.portal.model.Contact.prefix
11020	ii	com.liferay.portal.model.Contact.suffix
11021	iii	com.liferay.portal.model.Contact.suffix
11022	iv	com.liferay.portal.model.Contact.suffix
11023	jr	com.liferay.portal.model.Contact.suffix
11024	phd	com.liferay.portal.model.Contact.suffix
11025	sr	com.liferay.portal.model.Contact.suffix
11026	blog	com.liferay.portal.model.Contact.website
11027	business	com.liferay.portal.model.Contact.website
11028	other	com.liferay.portal.model.Contact.website
11029	personal	com.liferay.portal.model.Contact.website
12000	billing	com.liferay.portal.model.Organization.address
12001	other	com.liferay.portal.model.Organization.address
12002	p-o-box	com.liferay.portal.model.Organization.address
12003	shipping	com.liferay.portal.model.Organization.address
12004	email-address	com.liferay.portal.model.Organization.emailAddress
12005	email-address-2	com.liferay.portal.model.Organization.emailAddress
12006	email-address-3	com.liferay.portal.model.Organization.emailAddress
12007	fax	com.liferay.portal.model.Organization.phone
12008	local	com.liferay.portal.model.Organization.phone
12009	other	com.liferay.portal.model.Organization.phone
12010	toll-free	com.liferay.portal.model.Organization.phone
12011	tty	com.liferay.portal.model.Organization.phone
12012	administrative	com.liferay.portal.model.Organization.service
12013	contracts	com.liferay.portal.model.Organization.service
12014	donation	com.liferay.portal.model.Organization.service
12015	retail	com.liferay.portal.model.Organization.service
12016	training	com.liferay.portal.model.Organization.service
12017	full-member	com.liferay.portal.model.Organization.status
12018	provisional-member	com.liferay.portal.model.Organization.status
12019	intranet	com.liferay.portal.model.Organization.website
12020	public	com.liferay.portal.model.Organization.website
\.


--
-- Data for Name: lock_; Type: TABLE DATA; Schema: public; Owner: root
--

COPY lock_ (uuid_, lockid, companyid, userid, username, createdate, classname, key_, owner, inheritable, expirationdate) FROM stdin;
\.


--
-- Data for Name: marketplace_app; Type: TABLE DATA; Schema: public; Owner: root
--

COPY marketplace_app (uuid_, appid, companyid, userid, username, createdate, modifieddate, remoteappid, version) FROM stdin;
\.


--
-- Data for Name: marketplace_module; Type: TABLE DATA; Schema: public; Owner: root
--

COPY marketplace_module (uuid_, moduleid, appid, contextname) FROM stdin;
\.


--
-- Data for Name: mbban; Type: TABLE DATA; Schema: public; Owner: root
--

COPY mbban (banid, groupid, companyid, userid, username, createdate, modifieddate, banuserid) FROM stdin;
\.


--
-- Data for Name: mbcategory; Type: TABLE DATA; Schema: public; Owner: root
--

COPY mbcategory (uuid_, categoryid, groupid, companyid, userid, username, createdate, modifieddate, parentcategoryid, name, description, displaystyle, threadcount, messagecount, lastpostdate) FROM stdin;
\.


--
-- Data for Name: mbdiscussion; Type: TABLE DATA; Schema: public; Owner: root
--

COPY mbdiscussion (discussionid, classnameid, classpk, threadid) FROM stdin;
10278	10102	10274	10276
10286	10102	10282	10284
10418	10102	10413	10415
10427	10102	10423	10425
10436	10102	10432	10434
10450	10102	10446	10448
10456	10102	10452	10454
10462	10102	10458	10460
10476	10102	10472	10474
10484	10102	10480	10482
10490	10102	10486	10488
10496	10102	10492	10494
10521	10102	10517	10519
10526	10102	10522	10524
10541	10102	10537	10539
10578	10208	10572	10576
\.


--
-- Data for Name: mbmailinglist; Type: TABLE DATA; Schema: public; Owner: root
--

COPY mbmailinglist (uuid_, mailinglistid, groupid, companyid, userid, username, createdate, modifieddate, categoryid, emailaddress, inprotocol, inservername, inserverport, inusessl, inusername, inpassword, inreadinterval, outemailaddress, outcustom, outservername, outserverport, outusessl, outusername, outpassword, allowanonymous, active_) FROM stdin;
\.


--
-- Data for Name: mbmessage; Type: TABLE DATA; Schema: public; Owner: root
--

COPY mbmessage (uuid_, messageid, groupid, companyid, userid, username, createdate, modifieddate, classnameid, classpk, categoryid, threadid, rootmessageid, parentmessageid, subject, body, format, attachments, anonymous, priority, allowpingbacks, answer, status, statusbyuserid, statusbyusername, statusdate) FROM stdin;
22a75647-9a8a-4d85-a818-9291a5c09d59	10275	10271	10253	10257		2017-03-10 17:05:22.832	2017-03-10 17:05:22.832	10102	10274	-1	10276	10275	0	10274	10274	bbcode	f	t	0	f	f	0	10257		2017-03-10 17:05:23.023
7c2e79ce-8a32-4dac-b9f8-c922866592dc	10283	10279	10253	10257		2017-03-10 17:05:23.147	2017-03-10 17:05:23.147	10102	10282	-1	10284	10283	0	10282	10282	bbcode	f	t	0	f	f	0	10257		2017-03-10 17:05:23.167
3fa48104-83c6-433e-93a8-9b75c6636da8	10414	10410	10253	10257		2017-03-10 17:05:25.474	2017-03-10 17:05:25.474	10102	10413	-1	10415	10414	0	10413	10413	bbcode	f	t	0	f	f	0	10257		2017-03-10 17:05:25.514
34a976ce-bc77-4fd9-bb54-062edc16e09a	10424	10420	10253	10257		2017-03-10 17:05:25.661	2017-03-10 17:05:25.661	10102	10423	-1	10425	10424	0	10423	10423	bbcode	f	t	0	f	f	0	10257		2017-03-10 17:05:25.666
6adb8b29-6599-4752-88e7-f28b33ebb5c8	10433	10429	10253	10257		2017-03-10 17:05:25.78	2017-03-10 17:05:25.78	10102	10432	-1	10434	10433	0	10432	10432	bbcode	f	t	0	f	f	0	10257		2017-03-10 17:05:25.784
9a5e1725-0815-420a-b7c1-2106ebb236f9	10447	10438	10253	10257		2017-03-10 17:05:26.282	2017-03-10 17:05:26.282	10102	10446	-1	10448	10447	0	10446	10446	bbcode	f	t	0	f	f	0	10257		2017-03-10 17:05:26.287
573f7ad3-4f27-44a5-8bab-c86f0b9abe98	10453	10438	10253	10257		2017-03-10 17:05:26.46	2017-03-10 17:05:26.46	10102	10452	-1	10454	10453	0	10452	10452	bbcode	f	t	0	f	f	0	10257		2017-03-10 17:05:26.466
a29bb1f5-9ba4-4204-bc3f-357b715d9dbe	10459	10438	10253	10257		2017-03-10 17:05:26.561	2017-03-10 17:05:26.561	10102	10458	-1	10460	10459	0	10458	10458	bbcode	f	t	0	f	f	0	10257		2017-03-10 17:05:26.57
a8ed1218-027b-439d-9ead-6e691d6c1002	10473	10464	10253	10257		2017-03-10 17:05:26.772	2017-03-10 17:05:26.772	10102	10472	-1	10474	10473	0	10472	10472	bbcode	f	t	0	f	f	0	10257		2017-03-10 17:05:26.775
10eb2cf1-6178-4780-8b2a-c1a19778ca3a	10481	10464	10253	10257		2017-03-10 17:05:26.875	2017-03-10 17:05:26.875	10102	10480	-1	10482	10481	0	10480	10480	bbcode	f	t	0	f	f	0	10257		2017-03-10 17:05:26.88
580db483-30b6-463d-a8e9-cc9865955ef5	10487	10464	10253	10257		2017-03-10 17:05:26.949	2017-03-10 17:05:26.949	10102	10486	-1	10488	10487	0	10486	10486	bbcode	f	t	0	f	f	0	10257		2017-03-10 17:05:26.954
8178e9bc-31b8-4c86-b91e-21267ce644aa	10493	10464	10253	10257		2017-03-10 17:05:27.038	2017-03-10 17:05:27.038	10102	10492	-1	10494	10493	0	10492	10492	bbcode	f	t	0	f	f	0	10257		2017-03-10 17:05:27.043
4cb13faa-ee43-49f4-8e30-f3d1bc0554ca	10518	10298	10253	10295	Test Test	2017-03-10 17:06:13.687	2017-03-10 17:06:13.687	10102	10517	-1	10519	10518	0	10517	10517	bbcode	f	f	0	f	f	0	10295	Test Test	2017-03-10 17:06:13.693
104e298a-0a05-4b92-82d7-836281ee0a0f	10523	10298	10253	10295	Test Test	2017-03-10 17:06:13.724	2017-03-10 17:06:13.724	10102	10522	-1	10524	10523	0	10522	10522	bbcode	f	f	0	f	f	0	10295	Test Test	2017-03-10 17:06:13.729
6efb9fdf-62a2-4eed-b5a2-edd6ec8503e7	10538	10532	10253	10295	Test Test	2017-03-10 17:06:44.527	2017-03-10 17:06:44.527	10102	10537	-1	10539	10538	0	10537	10537	bbcode	f	f	0	f	f	0	10295	Test Test	2017-03-10 17:06:44.533
b97e57cf-76b2-4b17-8db6-d8f7a18b7d39	10575	10543	10253	10295	Test Test	2017-03-10 17:07:25.495	2017-03-10 17:07:25.495	10208	10572	-1	10576	10575	0	10572	10572	bbcode	f	f	0	f	f	0	10295	Test Test	2017-03-10 17:07:25.499
\.


--
-- Data for Name: mbstatsuser; Type: TABLE DATA; Schema: public; Owner: root
--

COPY mbstatsuser (statsuserid, groupid, userid, messagecount, lastpostdate) FROM stdin;
\.


--
-- Data for Name: mbthread; Type: TABLE DATA; Schema: public; Owner: root
--

COPY mbthread (threadid, groupid, companyid, categoryid, rootmessageid, rootmessageuserid, messagecount, viewcount, lastpostbyuserid, lastpostdate, priority, question, status, statusbyuserid, statusbyusername, statusdate) FROM stdin;
10276	10271	10253	-1	10275	10257	1	0	0	2017-03-10 17:05:23.023	0	f	0	10257		2017-03-10 17:05:23.023
10284	10279	10253	-1	10283	10257	1	0	0	2017-03-10 17:05:23.167	0	f	0	10257		2017-03-10 17:05:23.167
10415	10410	10253	-1	10414	10257	1	0	0	2017-03-10 17:05:25.514	0	f	0	10257		2017-03-10 17:05:25.514
10425	10420	10253	-1	10424	10257	1	0	0	2017-03-10 17:05:25.666	0	f	0	10257		2017-03-10 17:05:25.666
10434	10429	10253	-1	10433	10257	1	0	0	2017-03-10 17:05:25.784	0	f	0	10257		2017-03-10 17:05:25.784
10448	10438	10253	-1	10447	10257	1	0	0	2017-03-10 17:05:26.287	0	f	0	10257		2017-03-10 17:05:26.287
10454	10438	10253	-1	10453	10257	1	0	0	2017-03-10 17:05:26.466	0	f	0	10257		2017-03-10 17:05:26.466
10460	10438	10253	-1	10459	10257	1	0	0	2017-03-10 17:05:26.57	0	f	0	10257		2017-03-10 17:05:26.57
10576	10543	10253	-1	10575	10295	1	0	10295	2017-03-10 17:07:25.499	0	f	0	10295	Test Test	2017-03-10 17:07:25.499
10474	10464	10253	-1	10473	10257	1	0	0	2017-03-10 17:05:26.775	0	f	0	10257		2017-03-10 17:05:26.775
10482	10464	10253	-1	10481	10257	1	0	0	2017-03-10 17:05:26.88	0	f	0	10257		2017-03-10 17:05:26.88
10488	10464	10253	-1	10487	10257	1	0	0	2017-03-10 17:05:26.954	0	f	0	10257		2017-03-10 17:05:26.954
10494	10464	10253	-1	10493	10257	1	0	0	2017-03-10 17:05:27.043	0	f	0	10257		2017-03-10 17:05:27.043
10519	10298	10253	-1	10518	10295	1	0	10295	2017-03-10 17:06:13.693	0	f	0	10295	Test Test	2017-03-10 17:06:13.693
10524	10298	10253	-1	10523	10295	1	0	10295	2017-03-10 17:06:13.729	0	f	0	10295	Test Test	2017-03-10 17:06:13.729
10539	10532	10253	-1	10538	10295	1	0	10295	2017-03-10 17:06:44.533	0	f	0	10295	Test Test	2017-03-10 17:06:44.533
\.


--
-- Data for Name: mbthreadflag; Type: TABLE DATA; Schema: public; Owner: root
--

COPY mbthreadflag (threadflagid, userid, modifieddate, threadid) FROM stdin;
\.


--
-- Data for Name: mdraction; Type: TABLE DATA; Schema: public; Owner: root
--

COPY mdraction (uuid_, actionid, groupid, companyid, userid, username, createdate, modifieddate, classnameid, classpk, rulegroupinstanceid, name, description, type_, typesettings) FROM stdin;
\.


--
-- Data for Name: mdrrule; Type: TABLE DATA; Schema: public; Owner: root
--

COPY mdrrule (uuid_, ruleid, groupid, companyid, userid, username, createdate, modifieddate, rulegroupid, name, description, type_, typesettings) FROM stdin;
\.


--
-- Data for Name: mdrrulegroup; Type: TABLE DATA; Schema: public; Owner: root
--

COPY mdrrulegroup (uuid_, rulegroupid, groupid, companyid, userid, username, createdate, modifieddate, name, description) FROM stdin;
\.


--
-- Data for Name: mdrrulegroupinstance; Type: TABLE DATA; Schema: public; Owner: root
--

COPY mdrrulegroupinstance (uuid_, rulegroupinstanceid, groupid, companyid, userid, username, createdate, modifieddate, classnameid, classpk, rulegroupid, priority) FROM stdin;
\.


--
-- Data for Name: membershiprequest; Type: TABLE DATA; Schema: public; Owner: root
--

COPY membershiprequest (membershiprequestid, groupid, companyid, userid, createdate, comments, replycomments, replydate, replieruserid, statusid) FROM stdin;
\.


--
-- Data for Name: organization_; Type: TABLE DATA; Schema: public; Owner: root
--

COPY organization_ (organizationid, companyid, parentorganizationid, treepath, name, type_, recursable, regionid, countryid, statusid, comments) FROM stdin;
\.


--
-- Data for Name: orggrouppermission; Type: TABLE DATA; Schema: public; Owner: root
--

COPY orggrouppermission (organizationid, groupid, permissionid) FROM stdin;
\.


--
-- Data for Name: orggrouprole; Type: TABLE DATA; Schema: public; Owner: root
--

COPY orggrouprole (organizationid, groupid, roleid) FROM stdin;
\.


--
-- Data for Name: orglabor; Type: TABLE DATA; Schema: public; Owner: root
--

COPY orglabor (orglaborid, organizationid, typeid, sunopen, sunclose, monopen, monclose, tueopen, tueclose, wedopen, wedclose, thuopen, thuclose, friopen, friclose, satopen, satclose) FROM stdin;
\.


--
-- Data for Name: passwordpolicy; Type: TABLE DATA; Schema: public; Owner: root
--

COPY passwordpolicy (passwordpolicyid, companyid, userid, username, createdate, modifieddate, defaultpolicy, name, description, changeable, changerequired, minage, checksyntax, allowdictionarywords, minalphanumeric, minlength, minlowercase, minnumbers, minsymbols, minuppercase, history, historycount, expireable, maxage, warningtime, gracelimit, lockout, maxfailure, lockoutduration, requireunlock, resetfailurecount, resetticketmaxage) FROM stdin;
10294	10253	10257		2017-03-10 17:05:23.617	2017-03-10 17:05:23.617	t	Default Password Policy	Default Password Policy	t	t	0	f	t	0	6	0	1	0	1	f	6	f	8640000	86400	0	f	3	0	t	600	86400
\.


--
-- Data for Name: passwordpolicyrel; Type: TABLE DATA; Schema: public; Owner: root
--

COPY passwordpolicyrel (passwordpolicyrelid, passwordpolicyid, classnameid, classpk) FROM stdin;
10297	10294	10105	10295
\.


--
-- Data for Name: passwordtracker; Type: TABLE DATA; Schema: public; Owner: root
--

COPY passwordtracker (passwordtrackerid, userid, createdate, password_) FROM stdin;
\.


--
-- Data for Name: permission_; Type: TABLE DATA; Schema: public; Owner: root
--

COPY permission_ (permissionid, companyid, actionid, resourceid) FROM stdin;
\.


--
-- Data for Name: phone; Type: TABLE DATA; Schema: public; Owner: root
--

COPY phone (phoneid, companyid, userid, username, createdate, modifieddate, classnameid, classpk, number_, extension, typeid, primary_) FROM stdin;
\.


--
-- Data for Name: pluginsetting; Type: TABLE DATA; Schema: public; Owner: root
--

COPY pluginsetting (pluginsettingid, companyid, pluginid, plugintype, roles, active_) FROM stdin;
\.


--
-- Data for Name: pollschoice; Type: TABLE DATA; Schema: public; Owner: root
--

COPY pollschoice (uuid_, choiceid, questionid, name, description) FROM stdin;
\.


--
-- Data for Name: pollsquestion; Type: TABLE DATA; Schema: public; Owner: root
--

COPY pollsquestion (uuid_, questionid, groupid, companyid, userid, username, createdate, modifieddate, title, description, expirationdate, lastvotedate) FROM stdin;
\.


--
-- Data for Name: pollsvote; Type: TABLE DATA; Schema: public; Owner: root
--

COPY pollsvote (voteid, companyid, userid, username, createdate, modifieddate, questionid, choiceid, votedate) FROM stdin;
\.


--
-- Data for Name: portalpreferences; Type: TABLE DATA; Schema: public; Owner: root
--

COPY portalpreferences (portalpreferencesid, ownerid, ownertype, preferences) FROM stdin;
10001	0	1	<portlet-preferences />
10259	10253	1	<portlet-preferences />
10516	10257	4	<portlet-preferences />
10527	10295	4	<portlet-preferences><preference><name>com.liferay.portal.util.SessionClicks#layoutsTreeRootNode</name><value>1</value></preference></portlet-preferences>
\.


--
-- Data for Name: portlet; Type: TABLE DATA; Schema: public; Owner: root
--

COPY portlet (id_, companyid, portletid, roles, active_) FROM stdin;
10302	10253	98		t
10303	10253	66		t
10304	10253	180		t
10305	10253	27		t
10306	10253	152		t
10307	10253	134		t
10308	10253	130		t
10309	10253	122		t
10310	10253	36		t
10311	10253	26		t
10312	10253	104		t
10313	10253	175		t
10314	10253	64		t
10315	10253	153		t
10316	10253	129		t
10317	10253	179		t
10318	10253	173		t
10319	10253	100		t
10320	10253	19		t
10321	10253	157		t
10322	10253	181		t
10323	10253	128		t
10324	10253	154		t
10325	10253	148		t
10326	10253	11		t
10327	10253	29		t
10328	10253	158		t
10329	10253	178		t
10330	10253	8		t
10331	10253	58		t
10332	10253	71		t
10333	10253	97		t
10334	10253	39		t
10335	10253	177		t
10336	10253	85		t
10337	10253	118		t
10338	10253	107		t
10339	10253	30		t
10340	10253	147		t
10341	10253	48		t
10342	10253	125		t
10343	10253	161		t
10344	10253	146		t
10345	10253	62		t
10346	10253	162		t
10347	10253	176		t
10348	10253	108		t
10349	10253	84		t
10350	10253	101		t
10351	10253	121		t
10352	10253	143		t
10353	10253	77		t
10354	10253	167		t
10355	10253	115		t
10356	10253	56		t
10357	10253	111		t
10358	10253	3		t
10359	10253	20		t
10360	10253	16		t
10361	10253	23		t
10362	10253	83		t
10363	10253	99		t
10364	10253	70		t
10365	10253	164		t
10366	10253	141		t
10367	10253	9		t
10368	10253	28		t
10369	10253	137		t
10370	10253	15		t
10371	10253	47		t
10372	10253	116		t
10373	10253	82		t
10374	10253	151		t
10375	10253	54		t
10376	10253	34		t
10377	10253	132		t
10378	10253	169		t
10379	10253	61		t
10380	10253	73		t
10381	10253	136		t
10382	10253	50		t
10383	10253	127		t
10384	10253	31		t
10385	10253	25		t
10386	10253	166		t
10387	10253	33		t
10388	10253	150		t
10389	10253	114		t
10390	10253	149		t
10391	10253	67		t
10392	10253	110		t
10393	10253	59		t
10394	10253	135		t
10395	10253	131		t
10396	10253	102		t
\.


--
-- Data for Name: portletitem; Type: TABLE DATA; Schema: public; Owner: root
--

COPY portletitem (portletitemid, groupid, companyid, userid, username, createdate, modifieddate, name, portletid, classnameid) FROM stdin;
\.


--
-- Data for Name: portletpreferences; Type: TABLE DATA; Schema: public; Owner: root
--

COPY portletpreferences (portletpreferencesid, ownerid, ownertype, plid, portletid, preferences) FROM stdin;
10451	0	3	10446	3	<portlet-preferences><preference><name>portletSetupShowBorders</name><value>false</value></preference></portlet-preferences>
10457	0	3	10452	101_INSTANCE_qTe3aLnxiq7q	<portlet-preferences><preference><name>portletSetupUseCustomTitle</name><value>true</value></preference><preference><name>anyAssetType</name><value>false</value></preference><preference><name>classNameIds</name><value>10109</value></preference><preference><name>portletSetupTitle_en_US</name><value>Upcoming Events</value></preference></portlet-preferences>
10477	0	3	10472	3	<portlet-preferences><preference><name>portletSetupShowBorders</name><value>false</value></preference></portlet-preferences>
10478	0	3	10472	82	<portlet-preferences><preference><name>displayStyle</name><value>3</value></preference></portlet-preferences>
10479	0	3	10472	101_INSTANCE_6ACzn2Dhha8M	<portlet-preferences><preference><name>portletSetupUseCustomTitle</name><value>true</value></preference><preference><name>portletSetupTitle_en_US</name><value>Recent Content</value></preference></portlet-preferences>
10485	0	3	10480	20	<portlet-preferences><preference><name>portletSetupShowBorders</name><value>false</value></preference></portlet-preferences>
10491	0	3	10486	101_INSTANCE_We5LrTgiQkYg	<portlet-preferences><preference><name>portletSetupUseCustomTitle</name><value>true</value></preference><preference><name>anyAssetType</name><value>false</value></preference><preference><name>classNameIds</name><value>10109</value></preference><preference><name>portletSetupTitle_en_US</name><value>Upcoming Events</value></preference></portlet-preferences>
10497	0	3	10492	39_INSTANCE_antTeGz671qI	<portlet-preferences><preference><name>portletSetupUseCustomTitle</name><value>true</value></preference><preference><name>expandedEntriesPerFeed</name><value>3</value></preference><preference><name>urls</name><value>http://partners.userland.com/nytRss/technology.xml</value></preference><preference><name>items-per-channel</name><value>2</value></preference><preference><name>portletSetupTitle_en_US</name><value>Technology news</value></preference></portlet-preferences>
10498	0	3	10492	39_INSTANCE_4bhYHCNT0KW1	<portlet-preferences><preference><name>portletSetupUseCustomTitle</name><value>true</value></preference><preference><name>expandedEntriesPerFeed</name><value>0</value></preference><preference><name>urls</name><value>http://www.liferay.com/en/about-us/news/-/blogs/rss</value></preference><preference><name>titles</name><value>Liferay Press Releases</value></preference><preference><name>items-per-channel</name><value>2</value></preference><preference><name>portletSetupTitle_en_US</name><value>Liferay news</value></preference></portlet-preferences>
10513	0	3	10282	103	<portlet-preferences />
10514	0	3	10282	47	<portlet-preferences />
10515	0	3	10282	58	<portlet-preferences />
10528	0	3	10282	145	<portlet-preferences />
10529	0	3	10274	160	<portlet-preferences />
10530	0	3	10274	145	<portlet-preferences />
10531	0	3	10274	134	<portlet-preferences />
10536	0	3	10274	156	<portlet-preferences />
10542	0	3	10274	165	<portlet-preferences />
10560	0	3	10282	49	<portlet-preferences />
10561	0	3	10537	103	<portlet-preferences />
10562	0	3	10537	145	<portlet-preferences />
10563	0	3	10537	170	<portlet-preferences />
10564	0	3	10552	103	<portlet-preferences />
10565	0	3	10552	145	<portlet-preferences />
10566	0	3	10552	170	<portlet-preferences />
10567	0	3	10552	87	<portlet-preferences />
10569	10543	2	0	15	<portlet-preferences />
10568	0	3	10552	56_INSTANCE_boWWn8HG3Ulm	<portlet-preferences><preference><name>articleId</name><value>10570</value></preference><preference><name>groupId</name><value>10543</value></preference></portlet-preferences>
\.


--
-- Data for Name: quartz_blob_triggers; Type: TABLE DATA; Schema: public; Owner: root
--

COPY quartz_blob_triggers (sched_name, trigger_name, trigger_group, blob_data) FROM stdin;
\.


--
-- Data for Name: quartz_calendars; Type: TABLE DATA; Schema: public; Owner: root
--

COPY quartz_calendars (sched_name, calendar_name, calendar) FROM stdin;
\.


--
-- Data for Name: quartz_cron_triggers; Type: TABLE DATA; Schema: public; Owner: root
--

COPY quartz_cron_triggers (sched_name, trigger_name, trigger_group, cron_expression, time_zone_id) FROM stdin;
\.


--
-- Data for Name: quartz_fired_triggers; Type: TABLE DATA; Schema: public; Owner: root
--

COPY quartz_fired_triggers (sched_name, entry_id, trigger_name, trigger_group, instance_name, fired_time, priority, state, job_name, job_group, is_nonconcurrent, requests_recovery) FROM stdin;
\.


--
-- Data for Name: quartz_job_details; Type: TABLE DATA; Schema: public; Owner: root
--

COPY quartz_job_details (sched_name, job_name, job_group, description, job_class_name, is_durable, is_nonconcurrent, is_update_data, requests_recovery, job_data) FROM stdin;
\.


--
-- Data for Name: quartz_locks; Type: TABLE DATA; Schema: public; Owner: root
--

COPY quartz_locks (sched_name, lock_name) FROM stdin;
\.


--
-- Data for Name: quartz_paused_trigger_grps; Type: TABLE DATA; Schema: public; Owner: root
--

COPY quartz_paused_trigger_grps (sched_name, trigger_group) FROM stdin;
\.


--
-- Data for Name: quartz_scheduler_state; Type: TABLE DATA; Schema: public; Owner: root
--

COPY quartz_scheduler_state (sched_name, instance_name, last_checkin_time, checkin_interval) FROM stdin;
\.


--
-- Data for Name: quartz_simple_triggers; Type: TABLE DATA; Schema: public; Owner: root
--

COPY quartz_simple_triggers (sched_name, trigger_name, trigger_group, repeat_count, repeat_interval, times_triggered) FROM stdin;
\.


--
-- Data for Name: quartz_simprop_triggers; Type: TABLE DATA; Schema: public; Owner: root
--

COPY quartz_simprop_triggers (sched_name, trigger_name, trigger_group, str_prop_1, str_prop_2, str_prop_3, int_prop_1, int_prop_2, long_prop_1, long_prop_2, dec_prop_1, dec_prop_2, bool_prop_1, bool_prop_2) FROM stdin;
\.


--
-- Data for Name: quartz_triggers; Type: TABLE DATA; Schema: public; Owner: root
--

COPY quartz_triggers (sched_name, trigger_name, trigger_group, job_name, job_group, description, next_fire_time, prev_fire_time, priority, trigger_state, trigger_type, start_time, end_time, calendar_name, misfire_instr, job_data) FROM stdin;
\.


--
-- Data for Name: ratingsentry; Type: TABLE DATA; Schema: public; Owner: root
--

COPY ratingsentry (entryid, companyid, userid, username, createdate, modifieddate, classnameid, classpk, score) FROM stdin;
\.


--
-- Data for Name: ratingsstats; Type: TABLE DATA; Schema: public; Owner: root
--

COPY ratingsstats (statsid, classnameid, classpk, totalentries, totalscore, averagescore) FROM stdin;
\.


--
-- Data for Name: region; Type: TABLE DATA; Schema: public; Owner: root
--

COPY region (regionid, countryid, regioncode, name, active_) FROM stdin;
1001	1	AB	Alberta	t
1002	1	BC	British Columbia	t
1003	1	MB	Manitoba	t
1004	1	NB	New Brunswick	t
1005	1	NL	Newfoundland and Labrador	t
1006	1	NT	Northwest Territories	t
1007	1	NS	Nova Scotia	t
1008	1	NU	Nunavut	t
1009	1	ON	Ontario	t
1010	1	PE	Prince Edward Island	t
1011	1	QC	Quebec	t
1012	1	SK	Saskatchewan	t
1013	1	YT	Yukon	t
2001	2	CN-34	Anhui	t
2002	2	CN-92	Aomen	t
2003	2	CN-11	Beijing	t
2004	2	CN-50	Chongqing	t
2005	2	CN-35	Fujian	t
2006	2	CN-62	Gansu	t
2007	2	CN-44	Guangdong	t
2008	2	CN-45	Guangxi	t
2009	2	CN-52	Guizhou	t
2010	2	CN-46	Hainan	t
2011	2	CN-13	Hebei	t
2012	2	CN-23	Heilongjiang	t
2013	2	CN-41	Henan	t
2014	2	CN-42	Hubei	t
2015	2	CN-43	Hunan	t
2016	2	CN-32	Jiangsu	t
2017	2	CN-36	Jiangxi	t
2018	2	CN-22	Jilin	t
2019	2	CN-21	Liaoning	t
2020	2	CN-15	Nei Mongol	t
2021	2	CN-64	Ningxia	t
2022	2	CN-63	Qinghai	t
2023	2	CN-61	Shaanxi	t
2024	2	CN-37	Shandong	t
2025	2	CN-31	Shanghai	t
2026	2	CN-14	Shanxi	t
2027	2	CN-51	Sichuan	t
2028	2	CN-71	Taiwan	t
2029	2	CN-12	Tianjin	t
2030	2	CN-91	Xianggang	t
2031	2	CN-65	Xinjiang	t
2032	2	CN-54	Xizang	t
2033	2	CN-53	Yunnan	t
2034	2	CN-33	Zhejiang	t
3001	3	A	Alsace	t
3002	3	B	Aquitaine	t
3003	3	C	Auvergne	t
3004	3	P	Basse-Normandie	t
3005	3	D	Bourgogne	t
3006	3	E	Bretagne	t
3007	3	F	Centre	t
3008	3	G	Champagne-Ardenne	t
3009	3	H	Corse	t
3010	3	GF	Guyane	t
3011	3	I	Franche Comté	t
3012	3	GP	Guadeloupe	t
3013	3	Q	Haute-Normandie	t
3014	3	J	Île-de-France	t
3015	3	K	Languedoc-Roussillon	t
3016	3	L	Limousin	t
3017	3	M	Lorraine	t
3018	3	MQ	Martinique	t
3019	3	N	Midi-Pyrénées	t
3020	3	O	Nord Pas de Calais	t
3021	3	R	Pays de la Loire	t
3022	3	S	Picardie	t
3023	3	T	Poitou-Charentes	t
3024	3	U	Provence-Alpes-Côte-d'Azur	t
3025	3	RE	Réunion	t
3026	3	V	Rhône-Alpes	t
4001	4	BW	Baden-Württemberg	t
4002	4	BY	Bayern	t
4003	4	BE	Berlin	t
4004	4	BR	Brandenburg	t
4005	4	HB	Bremen	t
4006	4	HH	Hamburg	t
4007	4	HE	Hessen	t
4008	4	MV	Mecklenburg-Vorpommern	t
4009	4	NI	Niedersachsen	t
4010	4	NW	Nordrhein-Westfalen	t
4011	4	RP	Rheinland-Pfalz	t
4012	4	SL	Saarland	t
4013	4	SN	Sachsen	t
4014	4	ST	Sachsen-Anhalt	t
4015	4	SH	Schleswig-Holstein	t
4016	4	TH	Thüringen	t
8001	8	AG	Agrigento	t
8002	8	AL	Alessandria	t
8003	8	AN	Ancona	t
8004	8	AO	Aosta	t
8005	8	AR	Arezzo	t
8006	8	AP	Ascoli Piceno	t
8007	8	AT	Asti	t
8008	8	AV	Avellino	t
8009	8	BA	Bari	t
8010	8	BT	Barletta-Andria-Trani	t
8011	8	BL	Belluno	t
8012	8	BN	Benevento	t
8013	8	BG	Bergamo	t
8014	8	BI	Biella	t
8015	8	BO	Bologna	t
8016	8	BZ	Bolzano	t
8017	8	BS	Brescia	t
8018	8	BR	Brindisi	t
8019	8	CA	Cagliari	t
8020	8	CL	Caltanissetta	t
8021	8	CB	Campobasso	t
8022	8	CI	Carbonia-Iglesias	t
8023	8	CE	Caserta	t
8024	8	CT	Catania	t
8025	8	CZ	Catanzaro	t
8026	8	CH	Chieti	t
8027	8	CO	Como	t
8028	8	CS	Cosenza	t
8029	8	CR	Cremona	t
8030	8	KR	Crotone	t
8031	8	CN	Cuneo	t
8032	8	EN	Enna	t
8033	8	FM	Fermo	t
8034	8	FE	Ferrara	t
8035	8	FI	Firenze	t
8036	8	FG	Foggia	t
8037	8	FC	Forli-Cesena	t
8038	8	FR	Frosinone	t
8039	8	GE	Genova	t
8040	8	GO	Gorizia	t
8041	8	GR	Grosseto	t
8042	8	IM	Imperia	t
8043	8	IS	Isernia	t
8044	8	AQ	L'Aquila	t
8045	8	SP	La Spezia	t
8046	8	LT	Latina	t
8047	8	LE	Lecce	t
8048	8	LC	Lecco	t
8049	8	LI	Livorno	t
8050	8	LO	Lodi	t
8051	8	LU	Lucca	t
8052	8	MC	Macerata	t
8053	8	MN	Mantova	t
8054	8	MS	Massa-Carrara	t
8055	8	MT	Matera	t
8056	8	MA	Medio Campidano	t
8057	8	ME	Messina	t
8058	8	MI	Milano	t
8059	8	MO	Modena	t
8060	8	MZ	Monza	t
8061	8	NA	Napoli	t
8062	8	NO	Novara	t
8063	8	NU	Nuoro	t
8064	8	OG	Ogliastra	t
8065	8	OT	Olbia-Tempio	t
8066	8	OR	Oristano	t
8067	8	PD	Padova	t
8068	8	PA	Palermo	t
8069	8	PR	Parma	t
8070	8	PV	Pavia	t
8071	8	PG	Perugia	t
8072	8	PU	Pesaro e Urbino	t
8073	8	PE	Pescara	t
8074	8	PC	Piacenza	t
8075	8	PI	Pisa	t
8076	8	PT	Pistoia	t
8077	8	PN	Pordenone	t
8078	8	PZ	Potenza	t
8079	8	PO	Prato	t
8080	8	RG	Ragusa	t
8081	8	RA	Ravenna	t
8082	8	RC	Reggio Calabria	t
8083	8	RE	Reggio Emilia	t
8084	8	RI	Rieti	t
8085	8	RN	Rimini	t
8086	8	RM	Roma	t
8087	8	RO	Rovigo	t
8088	8	SA	Salerno	t
8089	8	SS	Sassari	t
8090	8	SV	Savona	t
8091	8	SI	Siena	t
8092	8	SR	Siracusa	t
8093	8	SO	Sondrio	t
8094	8	TA	Taranto	t
8095	8	TE	Teramo	t
8096	8	TR	Terni	t
8097	8	TO	Torino	t
8098	8	TP	Trapani	t
8099	8	TN	Trento	t
8100	8	TV	Treviso	t
8101	8	TS	Trieste	t
8102	8	UD	Udine	t
8103	8	VA	Varese	t
8104	8	VE	Venezia	t
8105	8	VB	Verbano-Cusio-Ossola	t
8106	8	VC	Vercelli	t
8107	8	VR	Verona	t
8108	8	VV	Vibo Valentia	t
8109	8	VI	Vicenza	t
8110	8	VT	Viterbo	t
11001	11	DR	Drenthe	t
11002	11	FL	Flevoland	t
11003	11	FR	Friesland	t
11004	11	GE	Gelderland	t
11005	11	GR	Groningen	t
11006	11	LI	Limburg	t
11007	11	NB	Noord-Brabant	t
11008	11	NH	Noord-Holland	t
11009	11	OV	Overijssel	t
11010	11	UT	Utrecht	t
11011	11	ZE	Zeeland	t
11012	11	ZH	Zuid-Holland	t
15001	15	AN	Andalusia	t
15002	15	AR	Aragon	t
15003	15	AS	Asturias	t
15004	15	IB	Balearic Islands	t
15005	15	PV	Basque Country	t
15006	15	CN	Canary Islands	t
15007	15	CB	Cantabria	t
15008	15	CL	Castile and Leon	t
15009	15	CM	Castile-La Mancha	t
15010	15	CT	Catalonia	t
15011	15	CE	Ceuta	t
15012	15	EX	Extremadura	t
15013	15	GA	Galicia	t
15014	15	LO	La Rioja	t
15015	15	M	Madrid	t
15016	15	ML	Melilla	t
15017	15	MU	Murcia	t
15018	15	NA	Navarra	t
15019	15	VC	Valencia	t
19001	19	AL	Alabama	t
19002	19	AK	Alaska	t
19003	19	AZ	Arizona	t
19004	19	AR	Arkansas	t
19005	19	CA	California	t
19006	19	CO	Colorado	t
19007	19	CT	Connecticut	t
19008	19	DC	District of Columbia	t
19009	19	DE	Delaware	t
19010	19	FL	Florida	t
19011	19	GA	Georgia	t
19012	19	HI	Hawaii	t
19013	19	ID	Idaho	t
19014	19	IL	Illinois	t
19015	19	IN	Indiana	t
19016	19	IA	Iowa	t
19017	19	KS	Kansas	t
19018	19	KY	Kentucky 	t
19019	19	LA	Louisiana 	t
19020	19	ME	Maine	t
19021	19	MD	Maryland	t
19022	19	MA	Massachusetts	t
19023	19	MI	Michigan	t
19024	19	MN	Minnesota	t
19025	19	MS	Mississippi	t
19026	19	MO	Missouri	t
19027	19	MT	Montana	t
19028	19	NE	Nebraska	t
19029	19	NV	Nevada	t
19030	19	NH	New Hampshire	t
19031	19	NJ	New Jersey	t
19032	19	NM	New Mexico	t
19033	19	NY	New York	t
19034	19	NC	North Carolina	t
19035	19	ND	North Dakota	t
19036	19	OH	Ohio	t
19037	19	OK	Oklahoma 	t
19038	19	OR	Oregon	t
19039	19	PA	Pennsylvania	t
19040	19	PR	Puerto Rico	t
19041	19	RI	Rhode Island	t
19042	19	SC	South Carolina	t
19043	19	SD	South Dakota	t
19044	19	TN	Tennessee	t
19045	19	TX	Texas	t
19046	19	UT	Utah	t
19047	19	VT	Vermont	t
19048	19	VA	Virginia	t
19049	19	WA	Washington	t
19050	19	WV	West Virginia	t
19051	19	WI	Wisconsin	t
19052	19	WY	Wyoming	t
32001	32	ACT	Australian Capital Territory	t
32002	32	NSW	New South Wales	t
32003	32	NT	Northern Territory	t
32004	32	QLD	Queensland	t
32005	32	SA	South Australia	t
32006	32	TAS	Tasmania	t
32007	32	VIC	Victoria	t
32008	32	WA	Western Australia	t
144001	144	MX-AGS	Aguascalientes	t
144002	144	MX-BCN	Baja California	t
144003	144	MX-BCS	Baja California Sur	t
144004	144	MX-CAM	Campeche	t
144005	144	MX-CHP	Chiapas	t
144006	144	MX-CHI	Chihuahua	t
144007	144	MX-COA	Coahuila	t
144008	144	MX-COL	Colima	t
144009	144	MX-DUR	Durango	t
144010	144	MX-GTO	Guanajuato	t
144011	144	MX-GRO	Guerrero	t
144012	144	MX-HGO	Hidalgo	t
144013	144	MX-JAL	Jalisco	t
144014	144	MX-MEX	Mexico	t
144015	144	MX-MIC	Michoacan	t
144016	144	MX-MOR	Morelos	t
144017	144	MX-NAY	Nayarit	t
144018	144	MX-NLE	Nuevo Leon	t
144019	144	MX-OAX	Oaxaca	t
144020	144	MX-PUE	Puebla	t
144021	144	MX-QRO	Queretaro	t
144023	144	MX-ROO	Quintana Roo	t
144024	144	MX-SLP	San Luis Potosí	t
144025	144	MX-SIN	Sinaloa	t
144026	144	MX-SON	Sonora	t
144027	144	MX-TAB	Tabasco	t
144028	144	MX-TAM	Tamaulipas	t
144029	144	MX-TLX	Tlaxcala	t
144030	144	MX-VER	Veracruz	t
144031	144	MX-YUC	Yucatan	t
144032	144	MX-ZAC	Zacatecas	t
164001	164	01	Østfold	t
164002	164	02	Akershus	t
164003	164	03	Oslo	t
164004	164	04	Hedmark	t
164005	164	05	Oppland	t
164006	164	06	Buskerud	t
164007	164	07	Vestfold	t
164008	164	08	Telemark	t
164009	164	09	Aust-Agder	t
164010	164	10	Vest-Agder	t
164011	164	11	Rogaland	t
164012	164	12	Hordaland	t
164013	164	14	Sogn og Fjordane	t
164014	164	15	Møre of Romsdal	t
164015	164	16	Sør-Trøndelag	t
164016	164	17	Nord-Trøndelag	t
164017	164	18	Nordland	t
164018	164	19	Troms	t
164019	164	20	Finnmark	t
202001	202	AG	Aargau	t
202002	202	AR	Appenzell Ausserrhoden	t
202003	202	AI	Appenzell Innerrhoden	t
202004	202	BL	Basel-Landschaft	t
202005	202	BS	Basel-Stadt	t
202006	202	BE	Bern	t
202007	202	FR	Fribourg	t
202008	202	GE	Geneva	t
202009	202	GL	Glarus	t
202010	202	GR	Graubünden	t
202011	202	JU	Jura	t
202012	202	LU	Lucerne	t
202013	202	NE	Neuchâtel	t
202014	202	NW	Nidwalden	t
202015	202	OW	Obwalden	t
202016	202	SH	Schaffhausen	t
202017	202	SZ	Schwyz	t
202018	202	SO	Solothurn	t
202019	202	SG	St. Gallen	t
202020	202	TG	Thurgau	t
202021	202	TI	Ticino	t
202022	202	UR	Uri	t
202023	202	VS	Valais	t
202024	202	VD	Vaud	t
202025	202	ZG	Zug	t
202026	202	ZH	Zürich	t
\.


--
-- Data for Name: release_; Type: TABLE DATA; Schema: public; Owner: root
--

COPY release_ (releaseid, createdate, modifieddate, servletcontextname, buildnumber, builddate, verified, state_, teststring) FROM stdin;
1	2017-03-10 09:04:33.780089	2017-03-10 17:05:15.632	portal	6102	2013-08-02 00:00:00	t	0	You take the blue pill, the story ends, you wake up in your bed and believe whatever you want to believe. You take the red pill, you stay in Wonderland, and I show you how deep the rabbit hole goes.
10510	2017-03-10 17:05:32.7	2017-03-10 17:05:32.71	marketplace-portlet	100	\N	t	0	
\.


--
-- Data for Name: repository; Type: TABLE DATA; Schema: public; Owner: root
--

COPY repository (uuid_, repositoryid, groupid, companyid, userid, username, createdate, modifieddate, classnameid, name, description, portletid, typesettings, dlfolderid) FROM stdin;
\.


--
-- Data for Name: repositoryentry; Type: TABLE DATA; Schema: public; Owner: root
--

COPY repositoryentry (uuid_, repositoryentryid, groupid, repositoryid, mappedid) FROM stdin;
\.


--
-- Data for Name: resource_; Type: TABLE DATA; Schema: public; Owner: root
--

COPY resource_ (resourceid, codeid, primkey) FROM stdin;
\.


--
-- Data for Name: resourceaction; Type: TABLE DATA; Schema: public; Owner: root
--

COPY resourceaction (resourceactionid, name, actionid, bitwisevalue) FROM stdin;
1	com.liferay.portlet.softwarecatalog	ADD_FRAMEWORK_VERSION	2
2	com.liferay.portlet.softwarecatalog	ADD_PRODUCT_ENTRY	4
3	com.liferay.portlet.softwarecatalog	PERMISSIONS	8
4	com.liferay.portal.model.Team	ASSIGN_MEMBERS	2
5	com.liferay.portal.model.Team	DELETE	4
6	com.liferay.portal.model.Team	PERMISSIONS	8
7	com.liferay.portal.model.Team	UPDATE	16
8	com.liferay.portal.model.Team	VIEW	1
9	com.liferay.portal.model.PasswordPolicy	ASSIGN_MEMBERS	2
10	com.liferay.portal.model.PasswordPolicy	DELETE	4
11	com.liferay.portal.model.PasswordPolicy	PERMISSIONS	8
12	com.liferay.portal.model.PasswordPolicy	UPDATE	16
13	com.liferay.portal.model.PasswordPolicy	VIEW	1
14	com.liferay.portlet.blogs.model.BlogsEntry	ADD_DISCUSSION	2
15	com.liferay.portlet.blogs.model.BlogsEntry	DELETE	4
16	com.liferay.portlet.blogs.model.BlogsEntry	DELETE_DISCUSSION	8
17	com.liferay.portlet.blogs.model.BlogsEntry	PERMISSIONS	16
18	com.liferay.portlet.blogs.model.BlogsEntry	UPDATE	32
19	com.liferay.portlet.blogs.model.BlogsEntry	UPDATE_DISCUSSION	64
20	com.liferay.portlet.blogs.model.BlogsEntry	VIEW	1
21	com.liferay.portlet.dynamicdatamapping.model.DDMTemplate	DELETE	2
22	com.liferay.portlet.dynamicdatamapping.model.DDMTemplate	PERMISSIONS	4
23	com.liferay.portlet.dynamicdatamapping.model.DDMTemplate	UPDATE	8
24	com.liferay.portlet.dynamicdatamapping.model.DDMTemplate	VIEW	1
25	com.liferay.portlet.journal.model.JournalFeed	DELETE	2
26	com.liferay.portlet.journal.model.JournalFeed	PERMISSIONS	4
27	com.liferay.portlet.journal.model.JournalFeed	UPDATE	8
28	com.liferay.portlet.journal.model.JournalFeed	VIEW	1
29	com.liferay.portlet.wiki.model.WikiNode	ADD_ATTACHMENT	2
30	com.liferay.portlet.wiki.model.WikiNode	ADD_PAGE	4
31	com.liferay.portlet.wiki.model.WikiNode	DELETE	8
32	com.liferay.portlet.wiki.model.WikiNode	IMPORT	16
33	com.liferay.portlet.wiki.model.WikiNode	PERMISSIONS	32
34	com.liferay.portlet.wiki.model.WikiNode	SUBSCRIBE	64
35	com.liferay.portlet.wiki.model.WikiNode	UPDATE	128
36	com.liferay.portlet.wiki.model.WikiNode	VIEW	1
37	com.liferay.portlet.announcements.model.AnnouncementsEntry	DELETE	2
38	com.liferay.portlet.announcements.model.AnnouncementsEntry	UPDATE	4
39	com.liferay.portlet.announcements.model.AnnouncementsEntry	VIEW	1
40	com.liferay.portlet.announcements.model.AnnouncementsEntry	PERMISSIONS	8
41	com.liferay.portlet.bookmarks	ADD_ENTRY	2
42	com.liferay.portlet.bookmarks	ADD_FOLDER	4
43	com.liferay.portlet.bookmarks	PERMISSIONS	8
44	com.liferay.portlet.bookmarks	VIEW	1
45	com.liferay.portlet.mobiledevicerules.model.MDRRuleGroupInstance	DELETE	2
46	com.liferay.portlet.mobiledevicerules.model.MDRRuleGroupInstance	PERMISSIONS	4
47	com.liferay.portlet.mobiledevicerules.model.MDRRuleGroupInstance	UPDATE	8
48	com.liferay.portlet.mobiledevicerules.model.MDRRuleGroupInstance	VIEW	1
49	com.liferay.portlet.asset.model.AssetVocabulary	DELETE	2
50	com.liferay.portlet.asset.model.AssetVocabulary	PERMISSIONS	4
51	com.liferay.portlet.asset.model.AssetVocabulary	UPDATE	8
52	com.liferay.portlet.asset.model.AssetVocabulary	VIEW	1
53	com.liferay.portlet.documentlibrary.model.DLFolder	ACCESS	2
54	com.liferay.portlet.documentlibrary.model.DLFolder	ADD_DOCUMENT	4
55	com.liferay.portlet.documentlibrary.model.DLFolder	ADD_SHORTCUT	8
56	com.liferay.portlet.documentlibrary.model.DLFolder	ADD_SUBFOLDER	16
57	com.liferay.portlet.documentlibrary.model.DLFolder	DELETE	32
58	com.liferay.portlet.documentlibrary.model.DLFolder	PERMISSIONS	64
59	com.liferay.portlet.documentlibrary.model.DLFolder	UPDATE	128
60	com.liferay.portlet.documentlibrary.model.DLFolder	VIEW	1
61	com.liferay.portlet.expando.model.ExpandoColumn	DELETE	2
62	com.liferay.portlet.expando.model.ExpandoColumn	PERMISSIONS	4
63	com.liferay.portlet.expando.model.ExpandoColumn	UPDATE	8
64	com.liferay.portlet.expando.model.ExpandoColumn	VIEW	1
65	com.liferay.portlet.documentlibrary	ADD_DOCUMENT	2
66	com.liferay.portlet.documentlibrary	ADD_DOCUMENT_TYPE	4
67	com.liferay.portlet.documentlibrary	ADD_FOLDER	8
68	com.liferay.portlet.documentlibrary	ADD_REPOSITORY	16
69	com.liferay.portlet.documentlibrary	ADD_STRUCTURE	32
70	com.liferay.portlet.documentlibrary	ADD_SHORTCUT	64
71	com.liferay.portlet.documentlibrary	PERMISSIONS	128
72	com.liferay.portlet.documentlibrary	UPDATE	256
73	com.liferay.portlet.documentlibrary	VIEW	1
74	com.liferay.portlet.calendar.model.CalEvent	ADD_DISCUSSION	2
75	com.liferay.portlet.calendar.model.CalEvent	DELETE	4
76	com.liferay.portlet.calendar.model.CalEvent	DELETE_DISCUSSION	8
77	com.liferay.portlet.calendar.model.CalEvent	PERMISSIONS	16
78	com.liferay.portlet.calendar.model.CalEvent	UPDATE	32
79	com.liferay.portlet.calendar.model.CalEvent	UPDATE_DISCUSSION	64
80	com.liferay.portlet.calendar.model.CalEvent	VIEW	1
439	86	VIEW	1
81	com.liferay.portlet.shopping.model.ShoppingCategory	ADD_ITEM	2
82	com.liferay.portlet.shopping.model.ShoppingCategory	ADD_SUBCATEGORY	4
83	com.liferay.portlet.shopping.model.ShoppingCategory	DELETE	8
84	com.liferay.portlet.shopping.model.ShoppingCategory	PERMISSIONS	16
85	com.liferay.portlet.shopping.model.ShoppingCategory	UPDATE	32
86	com.liferay.portlet.shopping.model.ShoppingCategory	VIEW	1
87	com.liferay.portlet.documentlibrary.model.DLFileShortcut	ADD_DISCUSSION	2
88	com.liferay.portlet.documentlibrary.model.DLFileShortcut	DELETE	4
89	com.liferay.portlet.documentlibrary.model.DLFileShortcut	DELETE_DISCUSSION	8
90	com.liferay.portlet.documentlibrary.model.DLFileShortcut	PERMISSIONS	16
91	com.liferay.portlet.documentlibrary.model.DLFileShortcut	UPDATE	32
92	com.liferay.portlet.documentlibrary.model.DLFileShortcut	UPDATE_DISCUSSION	64
93	com.liferay.portlet.documentlibrary.model.DLFileShortcut	VIEW	1
94	com.liferay.portlet.journal	ADD_ARTICLE	2
95	com.liferay.portlet.journal	ADD_FEED	4
96	com.liferay.portlet.journal	ADD_STRUCTURE	8
97	com.liferay.portlet.journal	ADD_TEMPLATE	16
98	com.liferay.portlet.journal	SUBSCRIBE	32
99	com.liferay.portlet.journal	PERMISSIONS	64
100	com.liferay.portlet.calendar	ADD_EVENT	2
101	com.liferay.portlet.calendar	EXPORT_ALL_EVENTS	4
102	com.liferay.portlet.calendar	PERMISSIONS	8
103	com.liferay.portal.model.LayoutPrototype	DELETE	2
104	com.liferay.portal.model.LayoutPrototype	PERMISSIONS	4
105	com.liferay.portal.model.LayoutPrototype	UPDATE	8
106	com.liferay.portal.model.LayoutPrototype	VIEW	1
107	com.liferay.portlet.dynamicdatalists.model.DDLRecordSet	ADD_RECORD	2
108	com.liferay.portlet.dynamicdatalists.model.DDLRecordSet	DELETE	4
109	com.liferay.portlet.dynamicdatalists.model.DDLRecordSet	PERMISSIONS	8
110	com.liferay.portlet.dynamicdatalists.model.DDLRecordSet	UPDATE	16
111	com.liferay.portlet.dynamicdatalists.model.DDLRecordSet	VIEW	1
112	com.liferay.portal.model.Organization	ASSIGN_MEMBERS	2
113	com.liferay.portal.model.Organization	ASSIGN_USER_ROLES	4
114	com.liferay.portal.model.Organization	DELETE	8
115	com.liferay.portal.model.Organization	MANAGE_ANNOUNCEMENTS	16
116	com.liferay.portal.model.Organization	MANAGE_SUBORGANIZATIONS	32
117	com.liferay.portal.model.Organization	MANAGE_USERS	64
118	com.liferay.portal.model.Organization	PERMISSIONS	128
119	com.liferay.portal.model.Organization	UPDATE	256
120	com.liferay.portal.model.Organization	VIEW	1
121	com.liferay.portal.model.Organization	VIEW_MEMBERS	512
122	com.liferay.portlet.softwarecatalog.model.SCLicense	DELETE	2
123	com.liferay.portlet.softwarecatalog.model.SCLicense	PERMISSIONS	4
124	com.liferay.portlet.softwarecatalog.model.SCLicense	UPDATE	8
125	com.liferay.portlet.softwarecatalog.model.SCLicense	VIEW	1
126	com.liferay.portlet.documentlibrary.model.DLFileEntryType	DELETE	2
127	com.liferay.portlet.documentlibrary.model.DLFileEntryType	PERMISSIONS	4
128	com.liferay.portlet.documentlibrary.model.DLFileEntryType	UPDATE	8
129	com.liferay.portlet.documentlibrary.model.DLFileEntryType	VIEW	1
130	com.liferay.portlet.journal.model.JournalTemplate	DELETE	2
131	com.liferay.portlet.journal.model.JournalTemplate	PERMISSIONS	4
132	com.liferay.portlet.journal.model.JournalTemplate	UPDATE	8
133	com.liferay.portlet.journal.model.JournalTemplate	VIEW	1
134	com.liferay.portlet.journal.model.JournalArticle	ADD_DISCUSSION	2
135	com.liferay.portlet.journal.model.JournalArticle	DELETE	4
136	com.liferay.portlet.journal.model.JournalArticle	DELETE_DISCUSSION	8
137	com.liferay.portlet.journal.model.JournalArticle	EXPIRE	16
138	com.liferay.portlet.journal.model.JournalArticle	PERMISSIONS	32
139	com.liferay.portlet.journal.model.JournalArticle	UPDATE	64
140	com.liferay.portlet.journal.model.JournalArticle	UPDATE_DISCUSSION	128
141	com.liferay.portlet.journal.model.JournalArticle	VIEW	1
142	com.liferay.portlet.dynamicdatalists	ADD_RECORD_SET	2
143	com.liferay.portlet.dynamicdatalists	ADD_STRUCTURE	4
144	com.liferay.portlet.dynamicdatalists	ADD_TEMPLATE	8
145	com.liferay.portlet.dynamicdatalists	PERMISSIONS	16
146	com.liferay.portlet.bookmarks.model.BookmarksFolder	ACCESS	2
147	com.liferay.portlet.bookmarks.model.BookmarksFolder	ADD_ENTRY	4
148	com.liferay.portlet.bookmarks.model.BookmarksFolder	ADD_SUBFOLDER	8
149	com.liferay.portlet.bookmarks.model.BookmarksFolder	DELETE	16
150	com.liferay.portlet.bookmarks.model.BookmarksFolder	PERMISSIONS	32
151	com.liferay.portlet.bookmarks.model.BookmarksFolder	UPDATE	64
152	com.liferay.portlet.bookmarks.model.BookmarksFolder	VIEW	1
153	com.liferay.portal.model.Group	ADD_LAYOUT	2
154	com.liferay.portal.model.Group	ADD_LAYOUT_BRANCH	4
155	com.liferay.portal.model.Group	ADD_LAYOUT_SET_BRANCH	8
156	com.liferay.portal.model.Group	ASSIGN_MEMBERS	16
157	com.liferay.portal.model.Group	ASSIGN_USER_ROLES	32
158	com.liferay.portal.model.Group	CONFIGURE_PORTLETS	64
159	com.liferay.portal.model.Group	DELETE	128
160	com.liferay.portal.model.Group	EXPORT_IMPORT_LAYOUTS	256
161	com.liferay.portal.model.Group	EXPORT_IMPORT_PORTLET_INFO	512
162	com.liferay.portal.model.Group	MANAGE_ANNOUNCEMENTS	1024
163	com.liferay.portal.model.Group	MANAGE_ARCHIVED_SETUPS	2048
164	com.liferay.portal.model.Group	MANAGE_LAYOUTS	4096
165	com.liferay.portal.model.Group	MANAGE_STAGING	8192
166	com.liferay.portal.model.Group	MANAGE_TEAMS	16384
167	com.liferay.portal.model.Group	PERMISSIONS	32768
168	com.liferay.portal.model.Group	PUBLISH_STAGING	65536
169	com.liferay.portal.model.Group	PUBLISH_TO_REMOTE	131072
170	com.liferay.portal.model.Group	UPDATE	262144
171	com.liferay.portal.model.Group	VIEW	1
172	com.liferay.portal.model.Group	VIEW_MEMBERS	524288
173	com.liferay.portal.model.Group	VIEW_STAGING	1048576
174	com.liferay.portlet.journal.model.JournalStructure	DELETE	2
175	com.liferay.portlet.journal.model.JournalStructure	PERMISSIONS	4
176	com.liferay.portlet.journal.model.JournalStructure	UPDATE	8
177	com.liferay.portlet.journal.model.JournalStructure	VIEW	1
178	com.liferay.portlet.asset.model.AssetTag	DELETE	2
179	com.liferay.portlet.asset.model.AssetTag	PERMISSIONS	4
180	com.liferay.portlet.asset.model.AssetTag	UPDATE	8
181	com.liferay.portlet.asset.model.AssetTag	VIEW	1
182	com.liferay.portal.model.Layout	ADD_DISCUSSION	2
183	com.liferay.portal.model.Layout	ADD_LAYOUT	4
184	com.liferay.portal.model.Layout	CONFIGURE_PORTLETS	8
185	com.liferay.portal.model.Layout	CUSTOMIZE	16
186	com.liferay.portal.model.Layout	DELETE	32
187	com.liferay.portal.model.Layout	DELETE_DISCUSSION	64
188	com.liferay.portal.model.Layout	PERMISSIONS	128
236	com.liferay.portal.model.LayoutSetPrototype	DELETE	2
237	com.liferay.portal.model.LayoutSetPrototype	PERMISSIONS	4
238	com.liferay.portal.model.LayoutSetPrototype	UPDATE	8
239	com.liferay.portal.model.LayoutSetPrototype	VIEW	1
240	com.liferay.portlet.shopping	ADD_CATEGORY	2
241	com.liferay.portlet.shopping	ADD_ITEM	4
242	com.liferay.portlet.shopping	MANAGE_COUPONS	8
243	com.liferay.portlet.shopping	MANAGE_ORDERS	16
244	com.liferay.portlet.shopping	PERMISSIONS	32
245	com.liferay.portlet.shopping	VIEW	1
329	98	ACCESS_IN_CONTROL_PANEL	2
330	98	ADD_TO_PAGE	4
331	98	CONFIGURATION	8
332	98	VIEW	1
333	98	PERMISSIONS	16
334	66	VIEW	1
335	66	ADD_TO_PAGE	2
336	66	CONFIGURATION	4
337	66	PERMISSIONS	8
338	156	VIEW	1
339	156	ADD_TO_PAGE	2
340	156	ACCESS_IN_CONTROL_PANEL	4
341	156	CONFIGURATION	8
342	156	PERMISSIONS	16
343	180	VIEW	1
344	180	ADD_TO_PAGE	2
345	180	CONFIGURATION	4
346	180	PERMISSIONS	8
347	152	ACCESS_IN_CONTROL_PANEL	2
348	152	CONFIGURATION	4
349	152	VIEW	1
350	152	PERMISSIONS	8
351	27	VIEW	1
352	27	ADD_TO_PAGE	2
353	27	CONFIGURATION	4
354	27	PERMISSIONS	8
359	87	VIEW	1
360	87	ADD_TO_PAGE	2
361	87	CONFIGURATION	4
362	87	PERMISSIONS	8
363	134	ACCESS_IN_CONTROL_PANEL	2
364	134	CONFIGURATION	4
365	134	VIEW	1
366	134	PERMISSIONS	8
367	130	ACCESS_IN_CONTROL_PANEL	2
368	130	CONFIGURATION	4
369	130	VIEW	1
370	130	PERMISSIONS	8
371	122	VIEW	1
372	122	ADD_TO_PAGE	2
373	122	CONFIGURATION	4
374	122	PERMISSIONS	8
375	36	ADD_TO_PAGE	2
376	36	CONFIGURATION	4
377	36	VIEW	1
378	36	PERMISSIONS	8
379	26	VIEW	1
380	26	ADD_TO_PAGE	2
381	26	CONFIGURATION	4
382	26	PERMISSIONS	8
383	104	VIEW	1
384	104	ADD_TO_PAGE	2
385	104	ACCESS_IN_CONTROL_PANEL	4
386	104	CONFIGURATION	8
387	104	PERMISSIONS	16
388	175	VIEW	1
389	175	ADD_TO_PAGE	2
390	175	CONFIGURATION	4
391	175	PERMISSIONS	8
451	11	ADD_TO_PAGE	2
452	11	CONFIGURATION	4
453	11	VIEW	1
454	11	PERMISSIONS	8
455	29	ADD_TO_PAGE	2
456	29	CONFIGURATION	4
457	29	VIEW	1
458	29	PERMISSIONS	8
483	58	ADD_TO_PAGE	2
484	58	CONFIGURATION	4
485	58	VIEW	1
486	58	PERMISSIONS	8
189	com.liferay.portal.model.Layout	UPDATE	256
190	com.liferay.portal.model.Layout	UPDATE_DISCUSSION	512
191	com.liferay.portal.model.Layout	VIEW	1
192	com.liferay.portlet.asset	ADD_TAG	2
193	com.liferay.portlet.asset	PERMISSIONS	4
194	com.liferay.portlet.asset	ADD_CATEGORY	8
195	com.liferay.portlet.asset	ADD_VOCABULARY	16
196	com.liferay.portal.model.LayoutBranch	DELETE	2
197	com.liferay.portal.model.LayoutBranch	PERMISSIONS	4
198	com.liferay.portal.model.LayoutBranch	UPDATE	8
199	com.liferay.portal.model.LayoutSetBranch	DELETE	2
200	com.liferay.portal.model.LayoutSetBranch	MERGE	4
201	com.liferay.portal.model.LayoutSetBranch	PERMISSIONS	8
202	com.liferay.portal.model.LayoutSetBranch	UPDATE	16
203	com.liferay.portlet.messageboards	ADD_CATEGORY	2
204	com.liferay.portlet.messageboards	ADD_FILE	4
205	com.liferay.portlet.messageboards	ADD_MESSAGE	8
206	com.liferay.portlet.messageboards	BAN_USER	16
207	com.liferay.portlet.messageboards	MOVE_THREAD	32
208	com.liferay.portlet.messageboards	LOCK_THREAD	64
209	com.liferay.portlet.messageboards	PERMISSIONS	128
210	com.liferay.portlet.messageboards	REPLY_TO_MESSAGE	256
211	com.liferay.portlet.messageboards	SUBSCRIBE	512
212	com.liferay.portlet.messageboards	UPDATE_THREAD_PRIORITY	1024
213	com.liferay.portlet.messageboards	VIEW	1
214	com.liferay.portlet.polls	ADD_QUESTION	2
215	com.liferay.portlet.polls	PERMISSIONS	4
216	com.liferay.portlet.shopping.model.ShoppingItem	DELETE	2
217	com.liferay.portlet.shopping.model.ShoppingItem	PERMISSIONS	4
218	com.liferay.portlet.shopping.model.ShoppingItem	UPDATE	8
219	com.liferay.portlet.shopping.model.ShoppingItem	VIEW	1
220	com.liferay.portlet.bookmarks.model.BookmarksEntry	DELETE	2
221	com.liferay.portlet.bookmarks.model.BookmarksEntry	PERMISSIONS	4
222	com.liferay.portlet.bookmarks.model.BookmarksEntry	UPDATE	8
223	com.liferay.portlet.bookmarks.model.BookmarksEntry	VIEW	1
224	com.liferay.portlet.softwarecatalog.model.SCProductEntry	ADD_DISCUSSION	2
225	com.liferay.portlet.softwarecatalog.model.SCProductEntry	DELETE	4
226	com.liferay.portlet.softwarecatalog.model.SCProductEntry	DELETE_DISCUSSION	8
227	com.liferay.portlet.softwarecatalog.model.SCProductEntry	PERMISSIONS	16
228	com.liferay.portlet.softwarecatalog.model.SCProductEntry	UPDATE	32
229	com.liferay.portlet.softwarecatalog.model.SCProductEntry	UPDATE_DISCUSSION	64
230	com.liferay.portlet.softwarecatalog.model.SCProductEntry	VIEW	1
231	com.liferay.portal.model.User	DELETE	2
232	com.liferay.portal.model.User	IMPERSONATE	4
233	com.liferay.portal.model.User	PERMISSIONS	8
234	com.liferay.portal.model.User	UPDATE	16
235	com.liferay.portal.model.User	VIEW	1
246	com.liferay.portlet.softwarecatalog.model.SCFrameworkVersion	DELETE	2
247	com.liferay.portlet.softwarecatalog.model.SCFrameworkVersion	PERMISSIONS	4
248	com.liferay.portlet.softwarecatalog.model.SCFrameworkVersion	UPDATE	8
249	com.liferay.portlet.wiki	ADD_NODE	2
250	com.liferay.portlet.wiki	PERMISSIONS	4
251	com.liferay.portlet.polls.model.PollsQuestion	ADD_VOTE	2
252	com.liferay.portlet.polls.model.PollsQuestion	DELETE	4
253	com.liferay.portlet.polls.model.PollsQuestion	PERMISSIONS	8
254	com.liferay.portlet.polls.model.PollsQuestion	UPDATE	16
255	com.liferay.portlet.polls.model.PollsQuestion	VIEW	1
256	com.liferay.portlet.shopping.model.ShoppingOrder	DELETE	2
257	com.liferay.portlet.shopping.model.ShoppingOrder	PERMISSIONS	4
258	com.liferay.portlet.shopping.model.ShoppingOrder	UPDATE	8
259	com.liferay.portlet.shopping.model.ShoppingOrder	VIEW	1
260	com.liferay.portal.model.UserGroup	ASSIGN_MEMBERS	2
261	com.liferay.portal.model.UserGroup	DELETE	4
262	com.liferay.portal.model.UserGroup	MANAGE_ANNOUNCEMENTS	8
263	com.liferay.portal.model.UserGroup	PERMISSIONS	16
264	com.liferay.portal.model.UserGroup	UPDATE	32
265	com.liferay.portal.model.UserGroup	VIEW	1
266	com.liferay.portal.model.Role	ASSIGN_MEMBERS	2
267	com.liferay.portal.model.Role	DEFINE_PERMISSIONS	4
268	com.liferay.portal.model.Role	DELETE	8
269	com.liferay.portal.model.Role	MANAGE_ANNOUNCEMENTS	16
270	com.liferay.portal.model.Role	PERMISSIONS	32
271	com.liferay.portal.model.Role	UPDATE	64
272	com.liferay.portal.model.Role	VIEW	1
273	com.liferay.portlet.messageboards.model.MBCategory	ADD_FILE	2
274	com.liferay.portlet.messageboards.model.MBCategory	ADD_MESSAGE	4
275	com.liferay.portlet.messageboards.model.MBCategory	ADD_SUBCATEGORY	8
276	com.liferay.portlet.messageboards.model.MBCategory	DELETE	16
277	com.liferay.portlet.messageboards.model.MBCategory	LOCK_THREAD	32
278	com.liferay.portlet.messageboards.model.MBCategory	MOVE_THREAD	64
279	com.liferay.portlet.messageboards.model.MBCategory	PERMISSIONS	128
280	com.liferay.portlet.messageboards.model.MBCategory	REPLY_TO_MESSAGE	256
281	com.liferay.portlet.messageboards.model.MBCategory	SUBSCRIBE	512
282	com.liferay.portlet.messageboards.model.MBCategory	UPDATE	1024
283	com.liferay.portlet.messageboards.model.MBCategory	UPDATE_THREAD_PRIORITY	2048
284	com.liferay.portlet.messageboards.model.MBCategory	VIEW	1
285	com.liferay.portlet.mobiledevicerules	ADD_RULE_GROUP	2
286	com.liferay.portlet.mobiledevicerules	ADD_RULE_GROUP_INSTANCE	4
287	com.liferay.portlet.mobiledevicerules	CONFIGURATION	8
288	com.liferay.portlet.mobiledevicerules	VIEW	1
289	com.liferay.portlet.mobiledevicerules	PERMISSIONS	16
290	com.liferay.portlet.dynamicdatamapping.model.DDMStructure	DELETE	2
291	com.liferay.portlet.dynamicdatamapping.model.DDMStructure	PERMISSIONS	4
292	com.liferay.portlet.dynamicdatamapping.model.DDMStructure	UPDATE	8
293	com.liferay.portlet.dynamicdatamapping.model.DDMStructure	VIEW	1
294	com.liferay.portlet.wiki.model.WikiPage	ADD_DISCUSSION	2
295	com.liferay.portlet.wiki.model.WikiPage	DELETE	4
296	com.liferay.portlet.wiki.model.WikiPage	DELETE_DISCUSSION	8
297	com.liferay.portlet.wiki.model.WikiPage	PERMISSIONS	16
298	com.liferay.portlet.wiki.model.WikiPage	SUBSCRIBE	32
299	com.liferay.portlet.wiki.model.WikiPage	UPDATE	64
300	com.liferay.portlet.wiki.model.WikiPage	UPDATE_DISCUSSION	128
301	com.liferay.portlet.wiki.model.WikiPage	VIEW	1
302	com.liferay.portlet.asset.model.AssetCategory	ADD_CATEGORY	2
303	com.liferay.portlet.asset.model.AssetCategory	DELETE	4
304	com.liferay.portlet.asset.model.AssetCategory	PERMISSIONS	8
305	com.liferay.portlet.asset.model.AssetCategory	UPDATE	16
306	com.liferay.portlet.asset.model.AssetCategory	VIEW	1
307	com.liferay.portlet.mobiledevicerules.model.MDRRuleGroup	DELETE	2
308	com.liferay.portlet.mobiledevicerules.model.MDRRuleGroup	PERMISSIONS	4
309	com.liferay.portlet.mobiledevicerules.model.MDRRuleGroup	UPDATE	8
310	com.liferay.portlet.mobiledevicerules.model.MDRRuleGroup	VIEW	1
311	com.liferay.portlet.messageboards.model.MBMessage	DELETE	2
312	com.liferay.portlet.messageboards.model.MBMessage	PERMISSIONS	4
313	com.liferay.portlet.messageboards.model.MBMessage	SUBSCRIBE	8
314	com.liferay.portlet.messageboards.model.MBMessage	UPDATE	16
315	com.liferay.portlet.messageboards.model.MBMessage	VIEW	1
316	com.liferay.portlet.messageboards.model.MBThread	SUBSCRIBE	2
317	com.liferay.portlet.messageboards.model.MBThread	PERMISSIONS	4
318	com.liferay.portlet.blogs	ADD_ENTRY	2
319	com.liferay.portlet.blogs	PERMISSIONS	4
320	com.liferay.portlet.blogs	SUBSCRIBE	8
321	com.liferay.portlet.documentlibrary.model.DLFileEntry	ADD_DISCUSSION	2
322	com.liferay.portlet.documentlibrary.model.DLFileEntry	DELETE	4
323	com.liferay.portlet.documentlibrary.model.DLFileEntry	DELETE_DISCUSSION	8
324	com.liferay.portlet.documentlibrary.model.DLFileEntry	OVERRIDE_CHECKOUT	16
325	com.liferay.portlet.documentlibrary.model.DLFileEntry	PERMISSIONS	32
326	com.liferay.portlet.documentlibrary.model.DLFileEntry	UPDATE	64
327	com.liferay.portlet.documentlibrary.model.DLFileEntry	UPDATE_DISCUSSION	128
328	com.liferay.portlet.documentlibrary.model.DLFileEntry	VIEW	1
355	88	VIEW	1
356	88	ADD_TO_PAGE	2
357	88	CONFIGURATION	4
358	88	PERMISSIONS	8
392	153	ACCESS_IN_CONTROL_PANEL	2
393	153	ADD_TO_PAGE	4
394	153	CONFIGURATION	8
395	153	VIEW	1
396	153	PERMISSIONS	16
397	64	VIEW	1
398	64	ADD_TO_PAGE	2
399	64	CONFIGURATION	4
400	64	PERMISSIONS	8
401	129	ACCESS_IN_CONTROL_PANEL	2
402	129	CONFIGURATION	4
403	129	VIEW	1
404	129	PERMISSIONS	8
405	179	VIEW	1
406	179	ADD_TO_PAGE	2
407	179	ACCESS_IN_CONTROL_PANEL	4
408	179	CONFIGURATION	8
409	179	PERMISSIONS	16
410	173	VIEW	1
411	173	ADD_TO_PAGE	2
412	173	ACCESS_IN_CONTROL_PANEL	4
413	173	CONFIGURATION	8
414	173	PERMISSIONS	16
415	100	VIEW	1
416	100	ADD_TO_PAGE	2
417	100	CONFIGURATION	4
418	100	PERMISSIONS	8
419	157	ACCESS_IN_CONTROL_PANEL	2
420	157	CONFIGURATION	4
421	157	VIEW	1
422	157	PERMISSIONS	8
423	19	ADD_TO_PAGE	2
424	19	CONFIGURATION	4
425	19	VIEW	1
426	19	PERMISSIONS	8
427	160	VIEW	1
428	160	ADD_TO_PAGE	2
429	160	CONFIGURATION	4
430	160	PERMISSIONS	8
431	181	VIEW	1
432	181	ADD_TO_PAGE	2
433	181	CONFIGURATION	4
434	181	PERMISSIONS	8
435	128	ACCESS_IN_CONTROL_PANEL	2
436	128	CONFIGURATION	4
437	128	VIEW	1
438	128	PERMISSIONS	8
440	86	ADD_TO_PAGE	2
441	86	CONFIGURATION	4
442	86	PERMISSIONS	8
443	154	ACCESS_IN_CONTROL_PANEL	2
444	154	CONFIGURATION	4
445	154	VIEW	1
446	154	PERMISSIONS	8
447	148	VIEW	1
448	148	ADD_TO_PAGE	2
449	148	CONFIGURATION	4
450	148	PERMISSIONS	8
459	174	VIEW	1
460	174	ADD_TO_PAGE	2
461	174	ACCESS_IN_CONTROL_PANEL	4
462	174	CONFIGURATION	8
463	174	PERMISSIONS	16
464	158	ACCESS_IN_CONTROL_PANEL	2
465	158	ADD_TO_PAGE	4
466	158	CONFIGURATION	8
467	158	VIEW	1
468	158	PERMISSIONS	16
469	178	VIEW	1
470	178	ADD_TO_PAGE	2
471	178	ACCESS_IN_CONTROL_PANEL	4
472	178	CONFIGURATION	8
473	178	PERMISSIONS	16
474	124	VIEW	1
475	124	ADD_TO_PAGE	2
476	124	CONFIGURATION	4
477	124	PERMISSIONS	8
478	8	ACCESS_IN_CONTROL_PANEL	2
479	8	ADD_TO_PAGE	4
480	8	CONFIGURATION	8
481	8	VIEW	1
482	8	PERMISSIONS	16
528	48	VIEW	1
529	48	ADD_TO_PAGE	2
530	48	CONFIGURATION	4
531	48	PERMISSIONS	8
532	125	ACCESS_IN_CONTROL_PANEL	2
533	125	CONFIGURATION	4
534	125	EXPORT_USER	8
535	125	VIEW	1
536	125	PERMISSIONS	16
537	161	ACCESS_IN_CONTROL_PANEL	2
538	161	CONFIGURATION	4
539	161	VIEW	1
540	161	PERMISSIONS	8
545	146	ACCESS_IN_CONTROL_PANEL	2
546	146	CONFIGURATION	4
547	146	VIEW	1
548	146	PERMISSIONS	8
761	166	ACCESS_IN_CONTROL_PANEL	2
762	166	ADD_TO_PAGE	4
763	166	CONFIGURATION	8
764	166	VIEW	1
765	166	PERMISSIONS	16
766	90	ADD_COMMUNITY	2
767	90	ADD_LAYOUT_PROTOTYPE	4
768	90	ADD_LAYOUT_SET_PROTOTYPE	8
769	90	ADD_LICENSE	16
770	90	ADD_ORGANIZATION	32
771	90	ADD_PASSWORD_POLICY	64
772	90	ADD_ROLE	128
773	90	ADD_USER	256
774	90	ADD_USER_GROUP	512
775	90	CONFIGURATION	1024
776	90	EXPORT_USER	2048
777	90	IMPERSONATE	4096
778	90	UNLINK_LAYOUT_SET_PROTOTYPE	8192
779	90	VIEW_CONTROL_PANEL	16384
780	90	ADD_TO_PAGE	32768
781	90	PERMISSIONS	65536
782	90	VIEW	1
783	150	ACCESS_IN_CONTROL_PANEL	2
784	150	CONFIGURATION	4
785	150	VIEW	1
786	150	PERMISSIONS	8
787	113	VIEW	1
788	113	ADD_TO_PAGE	2
789	113	CONFIGURATION	4
790	113	PERMISSIONS	8
791	33	ADD_TO_PAGE	2
792	33	CONFIGURATION	4
793	33	VIEW	1
794	33	PERMISSIONS	8
835	1_WAR_marketplaceportlet	VIEW	1
836	1_WAR_marketplaceportlet	ADD_TO_PAGE	2
837	1_WAR_marketplaceportlet	ACCESS_IN_CONTROL_PANEL	4
838	1_WAR_marketplaceportlet	CONFIGURATION	8
839	1_WAR_marketplaceportlet	PERMISSIONS	16
840	2_WAR_marketplaceportlet	VIEW	1
841	2_WAR_marketplaceportlet	ADD_TO_PAGE	2
842	2_WAR_marketplaceportlet	ACCESS_IN_CONTROL_PANEL	4
843	2_WAR_marketplaceportlet	CONFIGURATION	8
844	2_WAR_marketplaceportlet	PERMISSIONS	16
487	97	VIEW	1
488	97	ADD_TO_PAGE	2
489	97	CONFIGURATION	4
490	97	PERMISSIONS	8
491	71	ADD_TO_PAGE	2
492	71	CONFIGURATION	4
493	71	VIEW	1
494	71	PERMISSIONS	8
495	39	VIEW	1
496	39	ADD_TO_PAGE	2
497	39	CONFIGURATION	4
498	39	PERMISSIONS	8
499	177	CONFIGURATION	2
500	177	VIEW	1
501	177	ADD_TO_PAGE	4
502	177	PERMISSIONS	8
503	177	ACCESS_IN_CONTROL_PANEL	16
504	170	VIEW	1
505	170	ADD_TO_PAGE	2
506	170	CONFIGURATION	4
507	170	PERMISSIONS	8
508	85	ADD_TO_PAGE	2
509	85	CONFIGURATION	4
510	85	VIEW	1
511	85	PERMISSIONS	8
512	118	VIEW	1
513	118	ADD_TO_PAGE	2
514	118	CONFIGURATION	4
515	118	PERMISSIONS	8
516	107	VIEW	1
517	107	ADD_TO_PAGE	2
518	107	CONFIGURATION	4
519	107	PERMISSIONS	8
520	30	VIEW	1
521	30	ADD_TO_PAGE	2
522	30	CONFIGURATION	4
523	30	PERMISSIONS	8
524	147	ACCESS_IN_CONTROL_PANEL	2
525	147	CONFIGURATION	4
526	147	VIEW	1
527	147	PERMISSIONS	8
541	144	VIEW	1
542	144	ADD_TO_PAGE	2
543	144	CONFIGURATION	4
544	144	PERMISSIONS	8
549	62	VIEW	1
550	62	ADD_TO_PAGE	2
551	62	CONFIGURATION	4
552	62	PERMISSIONS	8
553	162	ACCESS_IN_CONTROL_PANEL	2
554	162	CONFIGURATION	4
555	162	VIEW	1
556	162	PERMISSIONS	8
557	176	VIEW	1
558	176	ADD_TO_PAGE	2
559	176	ACCESS_IN_CONTROL_PANEL	4
560	176	CONFIGURATION	8
561	176	PERMISSIONS	16
562	172	VIEW	1
563	172	ADD_TO_PAGE	2
564	172	CONFIGURATION	4
565	172	PERMISSIONS	8
566	108	VIEW	1
567	108	ADD_TO_PAGE	2
568	108	CONFIGURATION	4
569	108	PERMISSIONS	8
570	139	ACCESS_IN_CONTROL_PANEL	2
571	139	ADD_EXPANDO	4
572	139	CONFIGURATION	8
573	139	VIEW	1
574	139	PERMISSIONS	16
575	84	ADD_ENTRY	2
576	84	ADD_TO_PAGE	4
577	84	CONFIGURATION	8
578	84	VIEW	1
579	84	PERMISSIONS	16
580	101	VIEW	1
581	101	ADD_TO_PAGE	2
582	101	CONFIGURATION	4
583	101	PERMISSIONS	8
584	121	VIEW	1
585	121	ADD_TO_PAGE	2
586	121	CONFIGURATION	4
587	121	PERMISSIONS	8
588	49	VIEW	1
589	49	ADD_TO_PAGE	2
590	49	CONFIGURATION	4
591	49	PERMISSIONS	8
592	143	VIEW	1
593	143	ADD_TO_PAGE	2
594	143	CONFIGURATION	4
595	143	PERMISSIONS	8
596	167	ACCESS_IN_CONTROL_PANEL	2
597	167	ADD_TO_PAGE	4
598	167	CONFIGURATION	8
599	167	VIEW	1
600	167	PERMISSIONS	16
601	77	VIEW	1
602	77	ADD_TO_PAGE	2
603	77	CONFIGURATION	4
604	77	PERMISSIONS	8
605	115	VIEW	1
606	115	ADD_TO_PAGE	2
607	115	CONFIGURATION	4
608	115	PERMISSIONS	8
609	56	ADD_TO_PAGE	2
610	56	CONFIGURATION	4
611	56	VIEW	1
612	56	PERMISSIONS	8
613	111	VIEW	1
614	111	ADD_TO_PAGE	2
615	111	CONFIGURATION	4
616	111	PERMISSIONS	8
617	142	VIEW	1
618	142	ADD_TO_PAGE	2
619	142	CONFIGURATION	4
620	142	PERMISSIONS	8
621	3	VIEW	1
622	3	ADD_TO_PAGE	2
623	3	CONFIGURATION	4
624	3	PERMISSIONS	8
625	20	ACCESS_IN_CONTROL_PANEL	2
626	20	ADD_TO_PAGE	4
627	20	CONFIGURATION	8
628	20	VIEW	1
629	20	PERMISSIONS	16
630	145	VIEW	1
631	145	ADD_TO_PAGE	2
632	145	CONFIGURATION	4
633	145	PERMISSIONS	8
634	16	PREFERENCES	2
653	70	VIEW	1
635	16	GUEST_PREFERENCES	4
636	16	VIEW	1
637	16	ADD_TO_PAGE	8
638	16	CONFIGURATION	16
639	16	PERMISSIONS	32
640	23	VIEW	1
641	23	ADD_TO_PAGE	2
642	23	CONFIGURATION	4
643	23	PERMISSIONS	8
644	83	ADD_ENTRY	2
645	83	ADD_TO_PAGE	4
646	83	CONFIGURATION	8
647	83	VIEW	1
648	83	PERMISSIONS	16
649	99	ACCESS_IN_CONTROL_PANEL	2
650	99	CONFIGURATION	4
651	99	VIEW	1
652	99	PERMISSIONS	8
678	133	VIEW	1
679	133	ADD_TO_PAGE	2
680	133	CONFIGURATION	4
681	133	PERMISSIONS	8
795	2	ACCESS_IN_CONTROL_PANEL	2
796	2	CONFIGURATION	4
797	2	VIEW	1
798	2	PERMISSIONS	8
799	119	VIEW	1
800	119	ADD_TO_PAGE	2
801	119	CONFIGURATION	4
802	119	PERMISSIONS	8
803	114	VIEW	1
804	114	ADD_TO_PAGE	2
805	114	CONFIGURATION	4
806	114	PERMISSIONS	8
807	149	ACCESS_IN_CONTROL_PANEL	2
808	149	CONFIGURATION	4
809	149	VIEW	1
810	149	PERMISSIONS	8
811	67	VIEW	1
812	67	ADD_TO_PAGE	2
813	67	CONFIGURATION	4
814	67	PERMISSIONS	8
815	110	VIEW	1
816	110	ADD_TO_PAGE	2
817	110	CONFIGURATION	4
818	110	PERMISSIONS	8
819	135	ACCESS_IN_CONTROL_PANEL	2
820	135	CONFIGURATION	4
821	135	VIEW	1
822	135	PERMISSIONS	8
823	59	VIEW	1
824	59	ADD_TO_PAGE	2
825	59	CONFIGURATION	4
826	59	PERMISSIONS	8
827	131	ACCESS_IN_CONTROL_PANEL	2
828	131	CONFIGURATION	4
829	131	VIEW	1
830	131	PERMISSIONS	8
831	102	VIEW	1
832	102	ADD_TO_PAGE	2
833	102	CONFIGURATION	4
834	102	PERMISSIONS	8
654	70	ADD_TO_PAGE	2
655	70	CONFIGURATION	4
656	70	PERMISSIONS	8
657	164	VIEW	1
658	164	ADD_TO_PAGE	2
659	164	CONFIGURATION	4
660	164	PERMISSIONS	8
661	141	VIEW	1
662	141	ADD_TO_PAGE	2
663	141	CONFIGURATION	4
664	141	PERMISSIONS	8
665	9	VIEW	1
666	9	ADD_TO_PAGE	2
667	9	CONFIGURATION	4
668	9	PERMISSIONS	8
669	137	ACCESS_IN_CONTROL_PANEL	2
670	137	CONFIGURATION	4
671	137	VIEW	1
672	137	PERMISSIONS	8
673	28	ACCESS_IN_CONTROL_PANEL	2
674	28	ADD_TO_PAGE	4
675	28	CONFIGURATION	8
676	28	VIEW	1
677	28	PERMISSIONS	16
682	116	VIEW	1
683	116	ADD_TO_PAGE	2
684	116	CONFIGURATION	4
685	116	PERMISSIONS	8
686	47	VIEW	1
687	47	ADD_TO_PAGE	2
688	47	CONFIGURATION	4
689	47	PERMISSIONS	8
690	15	ACCESS_IN_CONTROL_PANEL	2
691	15	ADD_TO_PAGE	4
692	15	CONFIGURATION	8
693	15	VIEW	1
694	15	PERMISSIONS	16
695	82	VIEW	1
696	82	ADD_TO_PAGE	2
697	82	CONFIGURATION	4
698	82	PERMISSIONS	8
699	103	VIEW	1
700	103	ADD_TO_PAGE	2
701	103	CONFIGURATION	4
702	103	PERMISSIONS	8
703	151	ACCESS_IN_CONTROL_PANEL	2
704	151	CONFIGURATION	4
705	151	VIEW	1
706	151	PERMISSIONS	8
707	140	ACCESS_IN_CONTROL_PANEL	2
708	140	CONFIGURATION	4
709	140	VIEW	1
710	140	PERMISSIONS	8
711	54	VIEW	1
712	54	ADD_TO_PAGE	2
713	54	CONFIGURATION	4
714	54	PERMISSIONS	8
715	169	VIEW	1
716	169	ADD_TO_PAGE	2
717	169	CONFIGURATION	4
718	169	PERMISSIONS	8
719	132	ACCESS_IN_CONTROL_PANEL	2
720	132	CONFIGURATION	4
721	132	VIEW	1
722	132	PERMISSIONS	8
723	34	ADD_TO_PAGE	2
724	34	CONFIGURATION	4
725	34	VIEW	1
726	34	PERMISSIONS	8
727	61	VIEW	1
728	61	ADD_TO_PAGE	2
729	61	CONFIGURATION	4
730	61	PERMISSIONS	8
731	73	ADD_TO_PAGE	2
732	73	CONFIGURATION	4
733	73	VIEW	1
734	73	PERMISSIONS	8
735	136	ACCESS_IN_CONTROL_PANEL	2
736	136	CONFIGURATION	4
737	136	VIEW	1
738	136	PERMISSIONS	8
739	127	VIEW	1
740	127	ADD_TO_PAGE	2
741	127	ACCESS_IN_CONTROL_PANEL	4
742	127	CONFIGURATION	8
743	127	PERMISSIONS	16
744	50	VIEW	1
745	50	ADD_TO_PAGE	2
746	50	CONFIGURATION	4
747	50	PERMISSIONS	8
748	31	VIEW	1
749	31	ADD_TO_PAGE	2
750	31	CONFIGURATION	4
751	31	PERMISSIONS	8
752	165	VIEW	1
753	165	ADD_TO_PAGE	2
754	165	ACCESS_IN_CONTROL_PANEL	4
755	165	CONFIGURATION	8
756	165	PERMISSIONS	16
757	25	ACCESS_IN_CONTROL_PANEL	2
758	25	CONFIGURATION	4
759	25	VIEW	1
760	25	PERMISSIONS	8
\.


--
-- Data for Name: resourceblock; Type: TABLE DATA; Schema: public; Owner: root
--

COPY resourceblock (resourceblockid, companyid, groupid, name, permissionshash, referencecount) FROM stdin;
\.


--
-- Data for Name: resourceblockpermission; Type: TABLE DATA; Schema: public; Owner: root
--

COPY resourceblockpermission (resourceblockpermissionid, resourceblockid, roleid, actionids) FROM stdin;
\.


--
-- Data for Name: resourcecode; Type: TABLE DATA; Schema: public; Owner: root
--

COPY resourcecode (codeid, companyid, name, scope) FROM stdin;
\.


--
-- Data for Name: resourcepermission; Type: TABLE DATA; Schema: public; Owner: root
--

COPY resourcepermission (resourcepermissionid, companyid, name, scope, primkey, roleid, ownerid, actionids) FROM stdin;
1	10253	2	1	10253	10264	0	2
2	10253	140	1	10253	10264	0	2
5	10253	com.liferay.portal.model.Layout	4	10274	10262	10257	1023
6	10253	com.liferay.portal.model.Layout	4	10274	10269	0	19
7	10253	com.liferay.portal.model.Layout	4	10274	10261	0	1
8	10253	com.liferay.portal.model.Layout	4	10282	10262	10257	1023
9	10253	com.liferay.portal.model.Layout	4	10282	10269	0	19
10	10253	com.liferay.portal.model.Layout	4	10282	10261	0	1
11	10253	90	1	10253	10264	0	16384
12	10253	98	2	10288	10264	0	1
13	10253	66	2	10288	10264	0	1
14	10253	180	2	10288	10264	0	1
15	10253	27	2	10288	10264	0	1
16	10253	152	2	10288	10264	0	1
17	10253	134	2	10288	10264	0	1
18	10253	130	2	10288	10264	0	1
19	10253	122	2	10288	10264	0	1
20	10253	36	2	10288	10264	0	1
21	10253	26	2	10288	10264	0	1
22	10253	104	2	10288	10264	0	1
23	10253	175	2	10288	10264	0	1
24	10253	64	2	10288	10264	0	1
25	10253	153	2	10288	10264	0	1
26	10253	129	2	10288	10264	0	1
27	10253	179	2	10288	10264	0	1
28	10253	173	2	10288	10264	0	1
29	10253	100	2	10288	10264	0	1
30	10253	19	2	10288	10264	0	1
31	10253	157	2	10288	10264	0	1
32	10253	181	2	10288	10264	0	1
33	10253	128	2	10288	10264	0	1
34	10253	154	2	10288	10264	0	1
35	10253	148	2	10288	10264	0	1
36	10253	11	2	10288	10264	0	1
37	10253	29	2	10288	10264	0	1
38	10253	158	2	10288	10264	0	1
39	10253	178	2	10288	10264	0	1
40	10253	8	2	10288	10264	0	1
41	10253	58	2	10288	10264	0	1
42	10253	71	2	10288	10264	0	1
43	10253	97	2	10288	10264	0	1
44	10253	39	2	10288	10264	0	1
45	10253	177	2	10288	10264	0	1
46	10253	85	2	10288	10264	0	1
47	10253	118	2	10288	10264	0	1
48	10253	107	2	10288	10264	0	1
49	10253	30	2	10288	10264	0	1
50	10253	147	2	10288	10264	0	1
51	10253	48	2	10288	10264	0	1
52	10253	125	2	10288	10264	0	1
53	10253	161	2	10288	10264	0	1
54	10253	146	2	10288	10264	0	1
55	10253	62	2	10288	10264	0	1
56	10253	162	2	10288	10264	0	1
57	10253	176	2	10288	10264	0	1
58	10253	108	2	10288	10264	0	1
59	10253	84	2	10288	10264	0	1
60	10253	101	2	10288	10264	0	1
61	10253	121	2	10288	10264	0	1
62	10253	143	2	10288	10264	0	1
63	10253	77	2	10288	10264	0	1
64	10253	167	2	10288	10264	0	1
65	10253	115	2	10288	10264	0	1
66	10253	56	2	10288	10264	0	1
67	10253	111	2	10288	10264	0	1
68	10253	3	2	10288	10264	0	1
69	10253	20	2	10288	10264	0	1
70	10253	16	2	10288	10264	0	1
71	10253	23	2	10288	10264	0	1
72	10253	83	2	10288	10264	0	1
73	10253	99	2	10288	10264	0	1
74	10253	70	2	10288	10264	0	1
75	10253	164	2	10288	10264	0	1
76	10253	141	2	10288	10264	0	1
77	10253	9	2	10288	10264	0	1
78	10253	28	2	10288	10264	0	1
79	10253	137	2	10288	10264	0	1
80	10253	15	2	10288	10264	0	1
81	10253	47	2	10288	10264	0	1
82	10253	116	2	10288	10264	0	1
83	10253	82	2	10288	10264	0	1
84	10253	151	2	10288	10264	0	1
85	10253	54	2	10288	10264	0	1
86	10253	34	2	10288	10264	0	1
87	10253	132	2	10288	10264	0	1
88	10253	169	2	10288	10264	0	1
89	10253	61	2	10288	10264	0	1
90	10253	73	2	10288	10264	0	1
91	10253	136	2	10288	10264	0	1
92	10253	50	2	10288	10264	0	1
93	10253	127	2	10288	10264	0	1
94	10253	31	2	10288	10264	0	1
95	10253	25	2	10288	10264	0	1
96	10253	166	2	10288	10264	0	1
97	10253	33	2	10288	10264	0	1
98	10253	150	2	10288	10264	0	1
99	10253	114	2	10288	10264	0	1
100	10253	149	2	10288	10264	0	1
101	10253	67	2	10288	10264	0	1
102	10253	110	2	10288	10264	0	1
103	10253	59	2	10288	10264	0	1
104	10253	135	2	10288	10264	0	1
105	10253	131	2	10288	10264	0	1
106	10253	102	2	10288	10264	0	1
107	10253	com.liferay.portal.model.Layout	2	10288	10264	0	1
108	10253	com.liferay.portlet.blogs	2	10288	10264	0	14
109	10253	com.liferay.portlet.calendar	2	10288	10264	0	14
110	10253	98	2	10288	10263	0	2
111	10253	152	2	10288	10263	0	2
112	10253	179	2	10288	10263	0	4
113	10253	173	2	10288	10263	0	4
114	10253	154	2	10288	10263	0	2
115	10253	178	2	10288	10263	0	4
116	10253	8	2	10288	10263	0	2
117	10253	147	2	10288	10263	0	2
118	10253	161	2	10288	10263	0	2
119	10253	162	2	10288	10263	0	2
120	10253	167	2	10288	10263	0	2
121	10253	20	2	10288	10263	0	2
122	10253	99	2	10288	10263	0	2
123	10253	28	2	10288	10263	0	2
124	10253	15	2	10288	10263	0	2
125	10253	25	2	10288	10263	0	2
126	10253	com.liferay.portal.model.Group	2	10288	10263	0	4096
127	10253	com.liferay.portlet.asset	2	10288	10263	0	30
128	10253	com.liferay.portlet.blogs	2	10288	10263	0	14
129	10253	com.liferay.portlet.bookmarks	2	10288	10263	0	15
130	10253	com.liferay.portlet.calendar	2	10288	10263	0	14
131	10253	com.liferay.portlet.documentlibrary	2	10288	10263	0	511
132	10253	com.liferay.portlet.messageboards	2	10288	10263	0	2047
133	10253	com.liferay.portlet.polls	2	10288	10263	0	6
134	10253	com.liferay.portlet.wiki	2	10288	10263	0	6
135	10253	com.liferay.portal.model.User	4	10295	10262	10295	31
136	10253	98	1	10253	10263	0	4
137	10253	98	1	10253	10264	0	4
138	10253	66	1	10253	10263	0	2
139	10253	66	1	10253	10264	0	2
140	10253	180	1	10253	10261	0	2
141	10253	180	1	10253	10263	0	2
142	10253	180	1	10253	10264	0	2
143	10253	27	1	10253	10263	0	2
144	10253	27	1	10253	10264	0	2
145	10253	122	1	10253	10261	0	2
146	10253	122	1	10253	10263	0	2
147	10253	122	1	10253	10264	0	2
148	10253	36	1	10253	10263	0	2
149	10253	36	1	10253	10264	0	2
150	10253	26	1	10253	10263	0	2
151	10253	26	1	10253	10264	0	2
152	10253	104	1	10253	10260	0	2
153	10253	175	1	10253	10261	0	2
154	10253	175	1	10253	10263	0	2
155	10253	175	1	10253	10264	0	2
156	10253	64	1	10253	10261	0	2
157	10253	64	1	10253	10263	0	2
158	10253	64	1	10253	10264	0	2
159	10253	153	1	10253	10263	0	4
4	10253	153	1	10253	10264	0	6
160	10253	179	1	10253	10260	0	2
161	10253	173	1	10253	10261	0	2
162	10253	173	1	10253	10263	0	2
163	10253	173	1	10253	10264	0	2
164	10253	100	1	10253	10263	0	2
165	10253	100	1	10253	10264	0	2
166	10253	19	1	10253	10263	0	2
167	10253	19	1	10253	10264	0	2
168	10253	181	1	10253	10261	0	2
169	10253	181	1	10253	10263	0	2
170	10253	181	1	10253	10264	0	2
171	10253	148	1	10253	10261	0	2
172	10253	148	1	10253	10263	0	2
173	10253	148	1	10253	10264	0	2
174	10253	11	1	10253	10263	0	2
175	10253	11	1	10253	10264	0	2
176	10253	29	1	10253	10263	0	2
177	10253	29	1	10253	10264	0	2
178	10253	158	1	10253	10263	0	4
3	10253	158	1	10253	10264	0	6
179	10253	178	1	10253	10263	0	2
180	10253	178	1	10253	10264	0	2
181	10253	8	1	10253	10263	0	4
182	10253	8	1	10253	10264	0	4
183	10253	58	1	10253	10261	0	2
184	10253	58	1	10253	10263	0	2
185	10253	58	1	10253	10264	0	2
186	10253	71	1	10253	10261	0	2
187	10253	71	1	10253	10263	0	2
188	10253	71	1	10253	10264	0	2
189	10253	97	1	10253	10263	0	2
190	10253	97	1	10253	10264	0	2
191	10253	39	1	10253	10263	0	2
192	10253	39	1	10253	10264	0	2
193	10253	177	1	10253	10263	0	4
194	10253	177	1	10253	10264	0	4
195	10253	85	1	10253	10261	0	2
196	10253	85	1	10253	10263	0	2
197	10253	85	1	10253	10264	0	2
198	10253	118	1	10253	10261	0	2
199	10253	118	1	10253	10263	0	2
200	10253	118	1	10253	10264	0	2
201	10253	107	1	10253	10263	0	2
202	10253	107	1	10253	10264	0	2
203	10253	30	1	10253	10263	0	2
204	10253	30	1	10253	10264	0	2
205	10253	48	1	10253	10263	0	2
206	10253	48	1	10253	10264	0	2
207	10253	62	1	10253	10263	0	2
208	10253	62	1	10253	10264	0	2
209	10253	176	1	10253	10260	0	2
210	10253	108	1	10253	10263	0	2
211	10253	108	1	10253	10264	0	2
212	10253	84	1	10253	10263	0	4
213	10253	84	1	10253	10264	0	4
214	10253	101	1	10253	10261	0	2
215	10253	101	1	10253	10263	0	2
216	10253	101	1	10253	10264	0	2
217	10253	121	1	10253	10261	0	2
218	10253	121	1	10253	10263	0	2
219	10253	121	1	10253	10264	0	2
220	10253	143	1	10253	10261	0	2
221	10253	143	1	10253	10263	0	2
222	10253	143	1	10253	10264	0	2
223	10253	77	1	10253	10261	0	2
224	10253	77	1	10253	10263	0	2
225	10253	77	1	10253	10264	0	2
226	10253	167	1	10253	10263	0	4
227	10253	167	1	10253	10264	0	4
228	10253	115	1	10253	10261	0	2
229	10253	115	1	10253	10263	0	2
230	10253	115	1	10253	10264	0	2
231	10253	56	1	10253	10261	0	2
232	10253	56	1	10253	10263	0	2
233	10253	56	1	10253	10264	0	2
234	10253	111	1	10253	10260	0	2
235	10253	3	1	10253	10261	0	2
236	10253	3	1	10253	10263	0	2
237	10253	3	1	10253	10264	0	2
238	10253	20	1	10253	10261	0	4
239	10253	20	1	10253	10263	0	4
240	10253	20	1	10253	10264	0	4
241	10253	16	1	10253	10263	0	8
242	10253	16	1	10253	10264	0	8
243	10253	23	1	10253	10263	0	2
244	10253	23	1	10253	10264	0	2
245	10253	83	1	10253	10263	0	4
246	10253	83	1	10253	10264	0	4
247	10253	70	1	10253	10263	0	2
248	10253	70	1	10253	10264	0	2
249	10253	164	1	10253	10261	0	2
250	10253	164	1	10253	10263	0	2
251	10253	164	1	10253	10264	0	2
252	10253	141	1	10253	10261	0	2
253	10253	141	1	10253	10263	0	2
254	10253	141	1	10253	10264	0	2
255	10253	9	1	10253	10260	0	2
256	10253	28	1	10253	10263	0	4
257	10253	28	1	10253	10264	0	4
258	10253	15	1	10253	10263	0	4
259	10253	15	1	10253	10264	0	4
260	10253	47	1	10253	10261	0	2
261	10253	47	1	10253	10263	0	2
262	10253	47	1	10253	10264	0	2
263	10253	116	1	10253	10261	0	2
264	10253	116	1	10253	10263	0	2
265	10253	116	1	10253	10264	0	2
266	10253	82	1	10253	10261	0	2
267	10253	82	1	10253	10263	0	2
268	10253	82	1	10253	10264	0	2
269	10253	54	1	10253	10263	0	2
270	10253	54	1	10253	10264	0	2
271	10253	34	1	10253	10263	0	2
272	10253	34	1	10253	10264	0	2
273	10253	169	1	10253	10263	0	2
274	10253	169	1	10253	10264	0	2
275	10253	61	1	10253	10263	0	2
276	10253	61	1	10253	10264	0	2
277	10253	73	1	10253	10261	0	2
278	10253	73	1	10253	10263	0	2
279	10253	73	1	10253	10264	0	2
280	10253	50	1	10253	10261	0	2
281	10253	50	1	10253	10263	0	2
282	10253	50	1	10253	10264	0	2
283	10253	127	1	10253	10260	0	2
284	10253	31	1	10253	10261	0	2
285	10253	31	1	10253	10263	0	2
286	10253	31	1	10253	10264	0	2
287	10253	166	1	10253	10263	0	4
288	10253	166	1	10253	10264	0	4
289	10253	33	1	10253	10261	0	2
290	10253	33	1	10253	10263	0	2
291	10253	33	1	10253	10264	0	2
292	10253	114	1	10253	10261	0	2
293	10253	114	1	10253	10263	0	2
294	10253	114	1	10253	10264	0	2
295	10253	67	1	10253	10263	0	2
296	10253	67	1	10253	10264	0	2
297	10253	110	1	10253	10263	0	2
298	10253	110	1	10253	10264	0	2
299	10253	59	1	10253	10263	0	2
300	10253	59	1	10253	10264	0	2
301	10253	102	1	10253	10261	0	2
302	10253	102	1	10253	10263	0	2
303	10253	102	1	10253	10264	0	2
304	10253	com.liferay.portlet.dynamicdatamapping.model.DDMStructure	4	10397	10262	10257	15
305	10253	com.liferay.portlet.dynamicdatamapping.model.DDMStructure	4	10398	10262	10257	15
306	10253	com.liferay.portlet.dynamicdatamapping.model.DDMStructure	4	10399	10262	10257	15
307	10253	com.liferay.portlet.dynamicdatamapping.model.DDMStructure	4	10401	10262	10257	15
308	10253	com.liferay.portlet.documentlibrary.model.DLFileEntryType	4	10400	10262	10257	15
309	10253	com.liferay.portlet.dynamicdatamapping.model.DDMStructure	4	10403	10262	10257	15
310	10253	com.liferay.portlet.documentlibrary.model.DLFileEntryType	4	10402	10262	10257	15
311	10253	com.liferay.portlet.dynamicdatamapping.model.DDMStructure	4	10405	10262	10257	15
312	10253	com.liferay.portlet.documentlibrary.model.DLFileEntryType	4	10404	10262	10257	15
313	10253	com.liferay.portlet.dynamicdatamapping.model.DDMStructure	4	10407	10262	10257	15
314	10253	com.liferay.portlet.documentlibrary.model.DLFileEntryType	4	10406	10262	10257	15
315	10253	com.liferay.portlet.dynamicdatamapping.model.DDMStructure	4	10408	10262	10257	15
316	10253	com.liferay.portal.model.LayoutPrototype	4	10409	10262	10257	15
317	10253	com.liferay.portal.model.Layout	4	10413	10262	10257	1023
318	10253	com.liferay.portal.model.Layout	4	10413	10269	0	19
319	10253	com.liferay.portlet.asset.model.AssetVocabulary	4	10416	10262	10257	15
320	10253	33	4	10413_LAYOUT_33	10262	0	15
321	10253	33	4	10413_LAYOUT_33	10269	0	1
322	10253	33	4	10413_LAYOUT_33	10261	0	1
323	10253	com.liferay.portlet.blogs	4	10410	10262	0	14
324	10253	148	4	10413_LAYOUT_148_INSTANCE_aZWjS4vM0nuU	10262	0	15
325	10253	148	4	10413_LAYOUT_148_INSTANCE_aZWjS4vM0nuU	10269	0	1
326	10253	148	4	10413_LAYOUT_148_INSTANCE_aZWjS4vM0nuU	10261	0	1
327	10253	114	4	10413_LAYOUT_114	10262	0	15
328	10253	114	4	10413_LAYOUT_114	10269	0	1
329	10253	114	4	10413_LAYOUT_114	10261	0	1
330	10253	com.liferay.portal.model.LayoutPrototype	4	10419	10262	10257	15
331	10253	com.liferay.portal.model.Layout	4	10423	10262	10257	1023
332	10253	com.liferay.portal.model.Layout	4	10423	10269	0	19
333	10253	141	4	10423_LAYOUT_141_INSTANCE_WWalkjJ71IUF	10262	0	15
334	10253	141	4	10423_LAYOUT_141_INSTANCE_WWalkjJ71IUF	10269	0	1
335	10253	141	4	10423_LAYOUT_141_INSTANCE_WWalkjJ71IUF	10261	0	1
336	10253	122	4	10423_LAYOUT_122_INSTANCE_Nri1pyDR8zEN	10262	0	15
337	10253	122	4	10423_LAYOUT_122_INSTANCE_Nri1pyDR8zEN	10269	0	1
338	10253	122	4	10423_LAYOUT_122_INSTANCE_Nri1pyDR8zEN	10261	0	1
339	10253	3	4	10423_LAYOUT_3	10262	0	15
340	10253	3	4	10423_LAYOUT_3	10269	0	1
341	10253	3	4	10423_LAYOUT_3	10261	0	1
342	10253	101	4	10423_LAYOUT_101_INSTANCE_M9kwDXHMGGhu	10262	0	15
343	10253	101	4	10423_LAYOUT_101_INSTANCE_M9kwDXHMGGhu	10269	0	1
344	10253	101	4	10423_LAYOUT_101_INSTANCE_M9kwDXHMGGhu	10261	0	1
345	10253	com.liferay.portal.model.LayoutPrototype	4	10428	10262	10257	15
346	10253	com.liferay.portal.model.Layout	4	10432	10262	10257	1023
347	10253	com.liferay.portal.model.Layout	4	10432	10269	0	19
348	10253	36	4	10432_LAYOUT_36	10262	0	15
349	10253	36	4	10432_LAYOUT_36	10269	0	1
350	10253	36	4	10432_LAYOUT_36	10261	0	1
351	10253	com.liferay.portlet.wiki	4	10429	10262	0	6
352	10253	122	4	10432_LAYOUT_122_INSTANCE_lMr0KV3z5FuN	10262	0	15
353	10253	122	4	10432_LAYOUT_122_INSTANCE_lMr0KV3z5FuN	10269	0	1
354	10253	122	4	10432_LAYOUT_122_INSTANCE_lMr0KV3z5FuN	10261	0	1
355	10253	141	4	10432_LAYOUT_141_INSTANCE_hXpkne8EiJkJ	10262	0	15
356	10253	141	4	10432_LAYOUT_141_INSTANCE_hXpkne8EiJkJ	10269	0	1
357	10253	141	4	10432_LAYOUT_141_INSTANCE_hXpkne8EiJkJ	10261	0	1
358	10253	com.liferay.portal.model.LayoutSetPrototype	4	10437	10262	10257	15
362	10253	com.liferay.portal.model.Layout	4	10446	10262	10257	1023
363	10253	com.liferay.portal.model.Layout	4	10446	10269	0	19
364	10253	com.liferay.portal.model.Layout	4	10446	10261	0	1
365	10253	19	4	10446_LAYOUT_19	10262	0	15
366	10253	19	4	10446_LAYOUT_19	10269	0	1
367	10253	com.liferay.portlet.messageboards	4	10438	10262	0	2047
368	10253	com.liferay.portlet.messageboards	4	10438	10269	0	781
369	10253	com.liferay.portlet.messageboards	4	10438	10261	0	1
370	10253	3	4	10446_LAYOUT_3	10262	0	15
371	10253	3	4	10446_LAYOUT_3	10269	0	1
372	10253	59	4	10446_LAYOUT_59_INSTANCE_2C28N68835iy	10262	0	15
373	10253	59	4	10446_LAYOUT_59_INSTANCE_2C28N68835iy	10269	0	1
374	10253	180	4	10446_LAYOUT_180	10262	0	15
375	10253	180	4	10446_LAYOUT_180	10269	0	1
376	10253	com.liferay.portal.model.Layout	4	10452	10262	10257	1023
377	10253	com.liferay.portal.model.Layout	4	10452	10269	0	19
378	10253	com.liferay.portal.model.Layout	4	10452	10261	0	1
379	10253	8	4	10452_LAYOUT_8	10262	0	31
380	10253	8	4	10452_LAYOUT_8	10269	0	1
381	10253	com.liferay.portlet.calendar	4	10438	10262	0	14
382	10253	101	4	10452_LAYOUT_101_INSTANCE_qTe3aLnxiq7q	10262	0	15
383	10253	101	4	10452_LAYOUT_101_INSTANCE_qTe3aLnxiq7q	10269	0	1
384	10253	com.liferay.portal.model.Layout	4	10458	10262	10257	1023
385	10253	com.liferay.portal.model.Layout	4	10458	10269	0	19
386	10253	com.liferay.portal.model.Layout	4	10458	10261	0	1
387	10253	36	4	10458_LAYOUT_36	10262	0	15
388	10253	36	4	10458_LAYOUT_36	10269	0	1
389	10253	com.liferay.portlet.wiki	4	10438	10262	0	6
390	10253	122	4	10458_LAYOUT_122_INSTANCE_tfh1moA2SExq	10262	0	15
391	10253	122	4	10458_LAYOUT_122_INSTANCE_tfh1moA2SExq	10269	0	1
392	10253	148	4	10458_LAYOUT_148_INSTANCE_la4xhdCy815q	10262	0	15
393	10253	148	4	10458_LAYOUT_148_INSTANCE_la4xhdCy815q	10269	0	1
394	10253	com.liferay.portal.model.LayoutSetPrototype	4	10463	10262	10257	15
398	10253	com.liferay.portal.model.Layout	4	10472	10262	10257	1023
399	10253	com.liferay.portal.model.Layout	4	10472	10269	0	19
400	10253	com.liferay.portal.model.Layout	4	10472	10261	0	1
401	10253	116	4	10472_LAYOUT_116	10262	0	15
402	10253	116	4	10472_LAYOUT_116	10269	0	1
403	10253	3	4	10472_LAYOUT_3	10262	0	15
404	10253	3	4	10472_LAYOUT_3	10269	0	1
405	10253	82	4	10472_LAYOUT_82	10262	0	15
406	10253	82	4	10472_LAYOUT_82	10269	0	1
407	10253	101	4	10472_LAYOUT_101_INSTANCE_6ACzn2Dhha8M	10262	0	15
408	10253	101	4	10472_LAYOUT_101_INSTANCE_6ACzn2Dhha8M	10269	0	1
409	10253	com.liferay.portal.model.Layout	4	10480	10262	10257	1023
410	10253	com.liferay.portal.model.Layout	4	10480	10269	0	19
411	10253	com.liferay.portal.model.Layout	4	10480	10261	0	1
412	10253	20	4	10480_LAYOUT_20	10262	0	31
413	10253	20	4	10480_LAYOUT_20	10269	0	1
414	10253	com.liferay.portlet.documentlibrary	4	10464	10262	0	511
415	10253	com.liferay.portlet.documentlibrary	4	10464	10269	0	1
416	10253	com.liferay.portlet.documentlibrary	4	10464	10261	0	1
417	10253	com.liferay.portal.model.Layout	4	10486	10262	10257	1023
418	10253	com.liferay.portal.model.Layout	4	10486	10269	0	19
419	10253	com.liferay.portal.model.Layout	4	10486	10261	0	1
420	10253	8	4	10486_LAYOUT_8	10262	0	31
421	10253	8	4	10486_LAYOUT_8	10269	0	1
422	10253	com.liferay.portlet.calendar	4	10464	10262	0	14
423	10253	101	4	10486_LAYOUT_101_INSTANCE_We5LrTgiQkYg	10262	0	15
424	10253	101	4	10486_LAYOUT_101_INSTANCE_We5LrTgiQkYg	10269	0	1
425	10253	com.liferay.portal.model.Layout	4	10492	10262	10257	1023
426	10253	com.liferay.portal.model.Layout	4	10492	10269	0	19
427	10253	com.liferay.portal.model.Layout	4	10492	10261	0	1
428	10253	39	4	10492_LAYOUT_39_INSTANCE_antTeGz671qI	10262	0	15
429	10253	39	4	10492_LAYOUT_39_INSTANCE_antTeGz671qI	10269	0	1
430	10253	39	4	10492_LAYOUT_39_INSTANCE_4bhYHCNT0KW1	10262	0	15
431	10253	39	4	10492_LAYOUT_39_INSTANCE_4bhYHCNT0KW1	10269	0	1
432	10253	com.liferay.portlet.dynamicdatamapping.model.DDMStructure	4	10499	10262	10257	15
433	10253	com.liferay.portlet.dynamicdatamapping.model.DDMStructure	4	10500	10262	10257	15
434	10253	com.liferay.portlet.dynamicdatamapping.model.DDMStructure	4	10501	10262	10257	15
435	10253	com.liferay.portlet.dynamicdatamapping.model.DDMStructure	4	10502	10262	10257	15
438	10253	com.liferay.portlet.expando.model.ExpandoColumn	4	10506	10262	0	15
436	10253	com.liferay.portlet.dynamicdatamapping.model.DDMStructure	4	10503	10262	10257	15
437	10253	com.liferay.portlet.dynamicdatamapping.model.DDMStructure	4	10504	10262	10257	15
439	10253	com.liferay.portlet.expando.model.ExpandoColumn	4	10512	10262	0	15
440	10253	103	4	10282_LAYOUT_103	10262	0	15
441	10253	103	4	10282_LAYOUT_103	10269	0	1
442	10253	103	4	10282_LAYOUT_103	10261	0	1
443	10253	47	4	10282_LAYOUT_47	10262	0	15
444	10253	47	4	10282_LAYOUT_47	10269	0	1
445	10253	47	4	10282_LAYOUT_47	10261	0	1
446	10253	58	4	10282_LAYOUT_58	10262	0	15
447	10253	58	4	10282_LAYOUT_58	10269	0	1
448	10253	58	4	10282_LAYOUT_58	10261	0	1
449	10253	com.liferay.portal.model.Layout	4	10517	10262	10295	1023
450	10253	com.liferay.portal.model.Layout	4	10522	10262	10295	1023
451	10253	com.liferay.portal.model.Layout	4	10522	10263	0	19
452	10253	com.liferay.portal.model.Layout	4	10522	10261	0	1
453	10253	145	4	10282_LAYOUT_145	10262	0	15
454	10253	145	4	10282_LAYOUT_145	10269	0	1
455	10253	145	4	10282_LAYOUT_145	10261	0	1
456	10253	160	4	10274_LAYOUT_160	10262	0	15
457	10253	160	4	10274_LAYOUT_160	10269	0	1
458	10253	145	4	10274_LAYOUT_145	10262	0	15
459	10253	145	4	10274_LAYOUT_145	10269	0	1
460	10253	134	4	10274_LAYOUT_134	10262	0	15
461	10253	134	4	10274_LAYOUT_134	10269	0	1
462	10253	com.liferay.portal.model.Group	4	10532	10262	0	2097151
463	10253	156	4	10274_LAYOUT_156	10262	0	31
464	10253	156	4	10274_LAYOUT_156	10269	0	1
465	10253	com.liferay.portal.model.Layout	4	10537	10262	10295	1023
466	10253	com.liferay.portal.model.Layout	4	10537	10269	0	19
467	10253	com.liferay.portal.model.Layout	4	10537	10261	0	1
468	10253	165	4	10274_LAYOUT_165	10262	0	31
469	10253	165	4	10274_LAYOUT_165	10269	0	1
470	10253	com.liferay.portal.model.Group	4	10543	10262	0	2097151
471	10253	com.liferay.portlet.asset.model.AssetVocabulary	4	10547	10262	10257	15
472	10253	com.liferay.portlet.asset.model.AssetVocabulary	4	10548	10262	10257	15
474	10253	com.liferay.portlet.asset.model.AssetVocabulary	4	10548	10261	0	0
473	10253	com.liferay.portlet.asset.model.AssetVocabulary	4	10548	10269	0	0
475	10253	com.liferay.portal.model.Layout	4	10552	10262	10295	1023
476	10253	com.liferay.portal.model.Layout	4	10552	10269	0	19
477	10253	com.liferay.portal.model.Layout	4	10552	10261	0	1
478	10253	com.liferay.portlet.dynamicdatamapping.model.DDMStructure	4	10553	10262	10257	15
479	10253	com.liferay.portlet.dynamicdatamapping.model.DDMStructure	4	10554	10262	10257	15
480	10253	com.liferay.portlet.dynamicdatamapping.model.DDMStructure	4	10555	10262	10257	15
481	10253	com.liferay.portlet.dynamicdatamapping.model.DDMStructure	4	10556	10262	10257	15
482	10253	com.liferay.portlet.dynamicdatamapping.model.DDMStructure	4	10557	10262	10257	15
483	10253	com.liferay.portlet.dynamicdatamapping.model.DDMStructure	4	10558	10262	10257	15
484	10253	com.liferay.portlet.dynamicdatamapping.model.DDMStructure	4	10559	10262	10257	15
485	10253	49	4	10282_LAYOUT_49	10262	0	15
486	10253	49	4	10282_LAYOUT_49	10269	0	1
487	10253	49	4	10282_LAYOUT_49	10261	0	1
488	10253	103	4	10537_LAYOUT_103	10262	0	15
489	10253	103	4	10537_LAYOUT_103	10269	0	1
490	10253	103	4	10537_LAYOUT_103	10261	0	1
491	10253	145	4	10537_LAYOUT_145	10262	0	15
492	10253	145	4	10537_LAYOUT_145	10269	0	1
493	10253	145	4	10537_LAYOUT_145	10261	0	1
494	10253	170	4	10537_LAYOUT_170	10262	0	15
495	10253	170	4	10537_LAYOUT_170	10269	0	1
496	10253	170	4	10537_LAYOUT_170	10261	0	1
497	10253	103	4	10552_LAYOUT_103	10262	0	15
498	10253	103	4	10552_LAYOUT_103	10269	0	1
499	10253	103	4	10552_LAYOUT_103	10261	0	1
500	10253	145	4	10552_LAYOUT_145	10262	0	15
501	10253	145	4	10552_LAYOUT_145	10269	0	1
502	10253	145	4	10552_LAYOUT_145	10261	0	1
503	10253	170	4	10552_LAYOUT_170	10262	0	15
504	10253	170	4	10552_LAYOUT_170	10269	0	1
505	10253	170	4	10552_LAYOUT_170	10261	0	1
506	10253	87	4	10552_LAYOUT_87	10262	0	15
507	10253	87	4	10552_LAYOUT_87	10269	0	1
508	10253	87	4	10552_LAYOUT_87	10261	0	1
509	10253	56	4	10552_LAYOUT_56_INSTANCE_boWWn8HG3Ulm	10262	0	15
510	10253	56	4	10552_LAYOUT_56_INSTANCE_boWWn8HG3Ulm	10269	0	1
511	10253	56	4	10552_LAYOUT_56_INSTANCE_boWWn8HG3Ulm	10261	0	1
512	10253	15	4	10552_LAYOUT_15	10262	0	31
513	10253	15	4	10552_LAYOUT_15	10269	0	1
514	10253	15	4	10552_LAYOUT_15	10261	0	1
515	10253	com.liferay.portlet.journal	4	10543	10262	0	126
516	10253	com.liferay.portlet.journal.model.JournalArticle	4	10572	10262	10295	255
517	10253	com.liferay.portlet.journal.model.JournalArticle	4	10572	10269	0	3
518	10253	com.liferay.portlet.journal.model.JournalArticle	4	10572	10261	0	3
\.


--
-- Data for Name: resourcetypepermission; Type: TABLE DATA; Schema: public; Owner: root
--

COPY resourcetypepermission (resourcetypepermissionid, companyid, groupid, name, roleid, actionids) FROM stdin;
\.


--
-- Data for Name: role_; Type: TABLE DATA; Schema: public; Owner: root
--

COPY role_ (roleid, companyid, classnameid, classpk, name, title, description, type_, subtype) FROM stdin;
10260	10253	10104	10260	Administrator		<?xml version='1.0' encoding='UTF-8'?><root available-locales="en_US" default-locale="en_US"><Description language-id="en_US">Administrators are super users who can do anything.</Description></root>	1	
10261	10253	10104	10261	Guest		<?xml version='1.0' encoding='UTF-8'?><root available-locales="en_US" default-locale="en_US"><Description language-id="en_US">Unauthenticated users always have this role.</Description></root>	1	
10262	10253	10104	10262	Owner		<?xml version='1.0' encoding='UTF-8'?><root available-locales="en_US" default-locale="en_US"><Description language-id="en_US">This is an implied role with respect to the objects users create.</Description></root>	1	
10263	10253	10104	10263	Power User		<?xml version='1.0' encoding='UTF-8'?><root available-locales="en_US" default-locale="en_US"><Description language-id="en_US">Power Users have their own personal site.</Description></root>	1	
10264	10253	10104	10264	User		<?xml version='1.0' encoding='UTF-8'?><root available-locales="en_US" default-locale="en_US"><Description language-id="en_US">Authenticated users should be assigned this role.</Description></root>	1	
10265	10253	10104	10265	Organization Administrator		<?xml version='1.0' encoding='UTF-8'?><root available-locales="en_US" default-locale="en_US"><Description language-id="en_US">Organization Administrators are super users of their organization but cannot make other users into Organization Administrators.</Description></root>	3	
10266	10253	10104	10266	Organization Owner		<?xml version='1.0' encoding='UTF-8'?><root available-locales="en_US" default-locale="en_US"><Description language-id="en_US">Organization Owners are super users of their organization and can assign organization roles to users.</Description></root>	3	
10267	10253	10104	10267	Organization User		<?xml version='1.0' encoding='UTF-8'?><root available-locales="en_US" default-locale="en_US"><Description language-id="en_US">All users who belong to an organization have this role within that organization.</Description></root>	3	
10268	10253	10104	10268	Site Administrator		<?xml version='1.0' encoding='UTF-8'?><root available-locales="en_US" default-locale="en_US"><Description language-id="en_US">Site Administrators are super users of their site but cannot make other users into Site Administrators.</Description></root>	2	
10269	10253	10104	10269	Site Member		<?xml version='1.0' encoding='UTF-8'?><root available-locales="en_US" default-locale="en_US"><Description language-id="en_US">All users who belong to a site have this role within that site.</Description></root>	2	
10270	10253	10104	10270	Site Owner		<?xml version='1.0' encoding='UTF-8'?><root available-locales="en_US" default-locale="en_US"><Description language-id="en_US">Site Owners are super users of their site and can assign site roles to users.</Description></root>	2	
\.


--
-- Data for Name: roles_permissions; Type: TABLE DATA; Schema: public; Owner: root
--

COPY roles_permissions (permissionid, roleid) FROM stdin;
\.


--
-- Data for Name: scframeworkversi_scproductvers; Type: TABLE DATA; Schema: public; Owner: root
--

COPY scframeworkversi_scproductvers (frameworkversionid, productversionid) FROM stdin;
\.


--
-- Data for Name: scframeworkversion; Type: TABLE DATA; Schema: public; Owner: root
--

COPY scframeworkversion (frameworkversionid, groupid, companyid, userid, username, createdate, modifieddate, name, url, active_, priority) FROM stdin;
\.


--
-- Data for Name: sclicense; Type: TABLE DATA; Schema: public; Owner: root
--

COPY sclicense (licenseid, name, url, opensource, active_, recommended) FROM stdin;
\.


--
-- Data for Name: sclicenses_scproductentries; Type: TABLE DATA; Schema: public; Owner: root
--

COPY sclicenses_scproductentries (licenseid, productentryid) FROM stdin;
\.


--
-- Data for Name: scproductentry; Type: TABLE DATA; Schema: public; Owner: root
--

COPY scproductentry (productentryid, groupid, companyid, userid, username, createdate, modifieddate, name, type_, tags, shortdescription, longdescription, pageurl, author, repogroupid, repoartifactid) FROM stdin;
\.


--
-- Data for Name: scproductscreenshot; Type: TABLE DATA; Schema: public; Owner: root
--

COPY scproductscreenshot (productscreenshotid, companyid, groupid, productentryid, thumbnailid, fullimageid, priority) FROM stdin;
\.


--
-- Data for Name: scproductversion; Type: TABLE DATA; Schema: public; Owner: root
--

COPY scproductversion (productversionid, companyid, userid, username, createdate, modifieddate, productentryid, version, changelog, downloadpageurl, directdownloadurl, repostoreartifact) FROM stdin;
\.


--
-- Data for Name: servicecomponent; Type: TABLE DATA; Schema: public; Owner: root
--

COPY servicecomponent (servicecomponentid, buildnamespace, buildnumber, builddate, data_) FROM stdin;
10509	Marketplace	2	1343264386388	<?xml version="1.0"?>\n\n<data>\n\t<tables-sql><![CDATA[create table Marketplace_App (\n\tuuid_ VARCHAR(75) null,\n\tappId LONG not null primary key,\n\tcompanyId LONG,\n\tuserId LONG,\n\tuserName VARCHAR(75) null,\n\tcreateDate DATE null,\n\tmodifiedDate DATE null,\n\tremoteAppId LONG,\n\tversion VARCHAR(75) null\n);\n\ncreate table Marketplace_Module (\n\tuuid_ VARCHAR(75) null,\n\tmoduleId LONG not null primary key,\n\tappId LONG,\n\tcontextName VARCHAR(75) null\n);]]></tables-sql>\n\t<sequences-sql><![CDATA[]]></sequences-sql>\n\t<indexes-sql><![CDATA[create index IX_865B7BD5 on Marketplace_App (companyId);\ncreate index IX_20F14D93 on Marketplace_App (remoteAppId);\ncreate index IX_3E667FE1 on Marketplace_App (uuid_);\n\ncreate index IX_7DC16D26 on Marketplace_Module (appId);\ncreate index IX_C6938724 on Marketplace_Module (appId, contextName);\ncreate index IX_F2F1E964 on Marketplace_Module (contextName);\ncreate index IX_A7EFD80E on Marketplace_Module (uuid_);]]></indexes-sql>\n</data>
\.


--
-- Data for Name: shard; Type: TABLE DATA; Schema: public; Owner: root
--

COPY shard (shardid, classnameid, classpk, name) FROM stdin;
10254	10121	10253	default
\.


--
-- Data for Name: shoppingcart; Type: TABLE DATA; Schema: public; Owner: root
--

COPY shoppingcart (cartid, groupid, companyid, userid, username, createdate, modifieddate, itemids, couponcodes, altshipping, insure) FROM stdin;
\.


--
-- Data for Name: shoppingcategory; Type: TABLE DATA; Schema: public; Owner: root
--

COPY shoppingcategory (categoryid, groupid, companyid, userid, username, createdate, modifieddate, parentcategoryid, name, description) FROM stdin;
\.


--
-- Data for Name: shoppingcoupon; Type: TABLE DATA; Schema: public; Owner: root
--

COPY shoppingcoupon (couponid, groupid, companyid, userid, username, createdate, modifieddate, code_, name, description, startdate, enddate, active_, limitcategories, limitskus, minorder, discount, discounttype) FROM stdin;
\.


--
-- Data for Name: shoppingitem; Type: TABLE DATA; Schema: public; Owner: root
--

COPY shoppingitem (itemid, groupid, companyid, userid, username, createdate, modifieddate, categoryid, sku, name, description, properties, fields_, fieldsquantities, minquantity, maxquantity, price, discount, taxable, shipping, useshippingformula, requiresshipping, stockquantity, featured_, sale_, smallimage, smallimageid, smallimageurl, mediumimage, mediumimageid, mediumimageurl, largeimage, largeimageid, largeimageurl) FROM stdin;
\.


--
-- Data for Name: shoppingitemfield; Type: TABLE DATA; Schema: public; Owner: root
--

COPY shoppingitemfield (itemfieldid, itemid, name, values_, description) FROM stdin;
\.


--
-- Data for Name: shoppingitemprice; Type: TABLE DATA; Schema: public; Owner: root
--

COPY shoppingitemprice (itempriceid, itemid, minquantity, maxquantity, price, discount, taxable, shipping, useshippingformula, status) FROM stdin;
\.


--
-- Data for Name: shoppingorder; Type: TABLE DATA; Schema: public; Owner: root
--

COPY shoppingorder (orderid, groupid, companyid, userid, username, createdate, modifieddate, number_, tax, shipping, altshipping, requiresshipping, insure, insurance, couponcodes, coupondiscount, billingfirstname, billinglastname, billingemailaddress, billingcompany, billingstreet, billingcity, billingstate, billingzip, billingcountry, billingphone, shiptobilling, shippingfirstname, shippinglastname, shippingemailaddress, shippingcompany, shippingstreet, shippingcity, shippingstate, shippingzip, shippingcountry, shippingphone, ccname, cctype, ccnumber, ccexpmonth, ccexpyear, ccvernumber, comments, pptxnid, pppaymentstatus, pppaymentgross, ppreceiveremail, pppayeremail, sendorderemail, sendshippingemail) FROM stdin;
\.


--
-- Data for Name: shoppingorderitem; Type: TABLE DATA; Schema: public; Owner: root
--

COPY shoppingorderitem (orderitemid, orderid, itemid, sku, name, description, properties, price, quantity, shippeddate) FROM stdin;
\.


--
-- Data for Name: socialactivity; Type: TABLE DATA; Schema: public; Owner: root
--

COPY socialactivity (activityid, groupid, companyid, userid, createdate, mirroractivityid, classnameid, classpk, type_, extradata, receiveruserid) FROM stdin;
\.


--
-- Data for Name: socialactivityachievement; Type: TABLE DATA; Schema: public; Owner: root
--

COPY socialactivityachievement (activityachievementid, groupid, companyid, userid, createdate, name, firstingroup) FROM stdin;
\.


--
-- Data for Name: socialactivitycounter; Type: TABLE DATA; Schema: public; Owner: root
--

COPY socialactivitycounter (activitycounterid, groupid, companyid, classnameid, classpk, name, ownertype, currentvalue, totalvalue, gracevalue, startperiod, endperiod) FROM stdin;
\.


--
-- Data for Name: socialactivitylimit; Type: TABLE DATA; Schema: public; Owner: root
--

COPY socialactivitylimit (activitylimitid, groupid, companyid, userid, classnameid, classpk, activitytype, activitycountername, value) FROM stdin;
\.


--
-- Data for Name: socialactivitysetting; Type: TABLE DATA; Schema: public; Owner: root
--

COPY socialactivitysetting (activitysettingid, groupid, companyid, classnameid, activitytype, name, value) FROM stdin;
\.


--
-- Data for Name: socialrelation; Type: TABLE DATA; Schema: public; Owner: root
--

COPY socialrelation (uuid_, relationid, companyid, createdate, userid1, userid2, type_) FROM stdin;
\.


--
-- Data for Name: socialrequest; Type: TABLE DATA; Schema: public; Owner: root
--

COPY socialrequest (uuid_, requestid, groupid, companyid, userid, createdate, modifieddate, classnameid, classpk, type_, extradata, receiveruserid, status) FROM stdin;
\.


--
-- Data for Name: subscription; Type: TABLE DATA; Schema: public; Owner: root
--

COPY subscription (subscriptionid, companyid, userid, username, createdate, modifieddate, classnameid, classpk, frequency) FROM stdin;
\.


--
-- Data for Name: team; Type: TABLE DATA; Schema: public; Owner: root
--

COPY team (teamid, companyid, userid, username, createdate, modifieddate, groupid, name, description) FROM stdin;
\.


--
-- Data for Name: ticket; Type: TABLE DATA; Schema: public; Owner: root
--

COPY ticket (ticketid, companyid, createdate, classnameid, classpk, key_, type_, extrainfo, expirationdate) FROM stdin;
\.


--
-- Data for Name: user_; Type: TABLE DATA; Schema: public; Owner: root
--

COPY user_ (uuid_, userid, companyid, createdate, modifieddate, defaultuser, contactid, password_, passwordencrypted, passwordreset, passwordmodifieddate, digest, reminderqueryquestion, reminderqueryanswer, gracelogincount, screenname, emailaddress, facebookid, openid, portraitid, languageid, timezoneid, greeting, comments, firstname, middlename, lastname, jobtitle, logindate, loginip, lastlogindate, lastloginip, lastfailedlogindate, failedloginattempts, lockout, lockoutdate, agreedtotermsofuse, emailaddressverified, status) FROM stdin;
fe9e9bf4-5714-497b-ba7e-c6843aca84bc	10257	10253	2017-03-10 17:05:21.612	2017-03-10 17:05:21.612	t	10258	password	f	f	\N	5533ed38b5e33c076a804bb4bca644f9,7c493c1781eaa795ae648c5dc1d2be70,7c493c1781eaa795ae648c5dc1d2be70			0	10257	default@liferay.com	0		0	en_US	UTC	Welcome!						2017-03-10 17:05:21.612		\N		\N	0	f	\N	t	f	0
08cd5606-630f-4638-9c6c-cd6f1f7f4ff3	10295	10253	2017-03-10 17:05:23.656	2017-03-10 17:05:23.656	f	10296	qUqP5cyxm6YcTAhz05Hph5gvu9M=	t	f	\N	e5d86c6f3672e52795891c3597f20de0,751da756639bc033b572ba2e7849b589,453dd5da3e1aa48fc37bfadd3c67c3e6	what-is-your-father's-middle-name	test	0	test	test@liferay.com	0		0	en_US	UTC	Welcome Test Test!		Test		Test		2017-03-10 17:06:13.664	127.0.0.1	2017-03-10 17:05:23.949	127.0.0.1	\N	0	f	\N	t	t	0
\.


--
-- Data for Name: usergroup; Type: TABLE DATA; Schema: public; Owner: root
--

COPY usergroup (usergroupid, companyid, parentusergroupid, name, description, addedbyldapimport) FROM stdin;
\.


--
-- Data for Name: usergroupgrouprole; Type: TABLE DATA; Schema: public; Owner: root
--

COPY usergroupgrouprole (usergroupid, groupid, roleid) FROM stdin;
\.


--
-- Data for Name: usergrouprole; Type: TABLE DATA; Schema: public; Owner: root
--

COPY usergrouprole (userid, groupid, roleid) FROM stdin;
10295	10532	10270
10295	10543	10270
\.


--
-- Data for Name: usergroups_teams; Type: TABLE DATA; Schema: public; Owner: root
--

COPY usergroups_teams (teamid, usergroupid) FROM stdin;
\.


--
-- Data for Name: useridmapper; Type: TABLE DATA; Schema: public; Owner: root
--

COPY useridmapper (useridmapperid, userid, type_, description, externaluserid) FROM stdin;
\.


--
-- Data for Name: usernotificationevent; Type: TABLE DATA; Schema: public; Owner: root
--

COPY usernotificationevent (uuid_, usernotificationeventid, companyid, userid, type_, "timestamp", deliverby, payload, archived) FROM stdin;
\.


--
-- Data for Name: users_groups; Type: TABLE DATA; Schema: public; Owner: root
--

COPY users_groups (groupid, userid) FROM stdin;
10279	10295
10532	10295
10543	10295
\.


--
-- Data for Name: users_orgs; Type: TABLE DATA; Schema: public; Owner: root
--

COPY users_orgs (organizationid, userid) FROM stdin;
\.


--
-- Data for Name: users_permissions; Type: TABLE DATA; Schema: public; Owner: root
--

COPY users_permissions (permissionid, userid) FROM stdin;
\.


--
-- Data for Name: users_roles; Type: TABLE DATA; Schema: public; Owner: root
--

COPY users_roles (roleid, userid) FROM stdin;
10261	10257
10263	10295
10264	10295
10260	10295
\.


--
-- Data for Name: users_teams; Type: TABLE DATA; Schema: public; Owner: root
--

COPY users_teams (teamid, userid) FROM stdin;
\.


--
-- Data for Name: users_usergroups; Type: TABLE DATA; Schema: public; Owner: root
--

COPY users_usergroups (userid, usergroupid) FROM stdin;
\.


--
-- Data for Name: usertracker; Type: TABLE DATA; Schema: public; Owner: root
--

COPY usertracker (usertrackerid, companyid, userid, modifieddate, sessionid, remoteaddr, remotehost, useragent) FROM stdin;
\.


--
-- Data for Name: usertrackerpath; Type: TABLE DATA; Schema: public; Owner: root
--

COPY usertrackerpath (usertrackerpathid, usertrackerid, path_, pathdate) FROM stdin;
\.


--
-- Data for Name: virtualhost; Type: TABLE DATA; Schema: public; Owner: root
--

COPY virtualhost (virtualhostid, companyid, layoutsetid, hostname) FROM stdin;
10256	10253	0	localhost
\.


--
-- Data for Name: webdavprops; Type: TABLE DATA; Schema: public; Owner: root
--

COPY webdavprops (webdavpropsid, companyid, createdate, modifieddate, classnameid, classpk, props) FROM stdin;
\.


--
-- Data for Name: website; Type: TABLE DATA; Schema: public; Owner: root
--

COPY website (websiteid, companyid, userid, username, createdate, modifieddate, classnameid, classpk, url, typeid, primary_) FROM stdin;
\.


--
-- Data for Name: wikinode; Type: TABLE DATA; Schema: public; Owner: root
--

COPY wikinode (uuid_, nodeid, groupid, companyid, userid, username, createdate, modifieddate, name, description, lastpostdate) FROM stdin;
\.


--
-- Data for Name: wikipage; Type: TABLE DATA; Schema: public; Owner: root
--

COPY wikipage (uuid_, pageid, resourceprimkey, groupid, companyid, userid, username, createdate, modifieddate, nodeid, title, version, minoredit, content, summary, format, head, parenttitle, redirecttitle, status, statusbyuserid, statusbyusername, statusdate) FROM stdin;
\.


--
-- Data for Name: wikipageresource; Type: TABLE DATA; Schema: public; Owner: root
--

COPY wikipageresource (uuid_, resourceprimkey, nodeid, title) FROM stdin;
\.


--
-- Data for Name: workflowdefinitionlink; Type: TABLE DATA; Schema: public; Owner: root
--

COPY workflowdefinitionlink (workflowdefinitionlinkid, groupid, companyid, userid, username, createdate, modifieddate, classnameid, classpk, typepk, workflowdefinitionname, workflowdefinitionversion) FROM stdin;
\.


--
-- Data for Name: workflowinstancelink; Type: TABLE DATA; Schema: public; Owner: root
--

COPY workflowinstancelink (workflowinstancelinkid, groupid, companyid, userid, username, createdate, modifieddate, classnameid, classpk, workflowinstanceid) FROM stdin;
\.


--
-- Name: account__pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY account_
    ADD CONSTRAINT account__pkey PRIMARY KEY (accountid);


--
-- Name: address_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY address
    ADD CONSTRAINT address_pkey PRIMARY KEY (addressid);


--
-- Name: announcementsdelivery_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY announcementsdelivery
    ADD CONSTRAINT announcementsdelivery_pkey PRIMARY KEY (deliveryid);


--
-- Name: announcementsentry_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY announcementsentry
    ADD CONSTRAINT announcementsentry_pkey PRIMARY KEY (entryid);


--
-- Name: announcementsflag_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY announcementsflag
    ADD CONSTRAINT announcementsflag_pkey PRIMARY KEY (flagid);


--
-- Name: assetcategory_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY assetcategory
    ADD CONSTRAINT assetcategory_pkey PRIMARY KEY (categoryid);


--
-- Name: assetcategoryproperty_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY assetcategoryproperty
    ADD CONSTRAINT assetcategoryproperty_pkey PRIMARY KEY (categorypropertyid);


--
-- Name: assetentries_assetcategories_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY assetentries_assetcategories
    ADD CONSTRAINT assetentries_assetcategories_pkey PRIMARY KEY (categoryid, entryid);


--
-- Name: assetentries_assettags_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY assetentries_assettags
    ADD CONSTRAINT assetentries_assettags_pkey PRIMARY KEY (entryid, tagid);


--
-- Name: assetentry_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY assetentry
    ADD CONSTRAINT assetentry_pkey PRIMARY KEY (entryid);


--
-- Name: assetlink_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY assetlink
    ADD CONSTRAINT assetlink_pkey PRIMARY KEY (linkid);


--
-- Name: assettag_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY assettag
    ADD CONSTRAINT assettag_pkey PRIMARY KEY (tagid);


--
-- Name: assettagproperty_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY assettagproperty
    ADD CONSTRAINT assettagproperty_pkey PRIMARY KEY (tagpropertyid);


--
-- Name: assettagstats_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY assettagstats
    ADD CONSTRAINT assettagstats_pkey PRIMARY KEY (tagstatsid);


--
-- Name: assetvocabulary_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY assetvocabulary
    ADD CONSTRAINT assetvocabulary_pkey PRIMARY KEY (vocabularyid);


--
-- Name: blogsentry_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY blogsentry
    ADD CONSTRAINT blogsentry_pkey PRIMARY KEY (entryid);


--
-- Name: blogsstatsuser_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY blogsstatsuser
    ADD CONSTRAINT blogsstatsuser_pkey PRIMARY KEY (statsuserid);


--
-- Name: bookmarksentry_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY bookmarksentry
    ADD CONSTRAINT bookmarksentry_pkey PRIMARY KEY (entryid);


--
-- Name: bookmarksfolder_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY bookmarksfolder
    ADD CONSTRAINT bookmarksfolder_pkey PRIMARY KEY (folderid);


--
-- Name: browsertracker_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY browsertracker
    ADD CONSTRAINT browsertracker_pkey PRIMARY KEY (browsertrackerid);


--
-- Name: calevent_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY calevent
    ADD CONSTRAINT calevent_pkey PRIMARY KEY (eventid);


--
-- Name: classname__pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY classname_
    ADD CONSTRAINT classname__pkey PRIMARY KEY (classnameid);


--
-- Name: clustergroup_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY clustergroup
    ADD CONSTRAINT clustergroup_pkey PRIMARY KEY (clustergroupid);


--
-- Name: company_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY company
    ADD CONSTRAINT company_pkey PRIMARY KEY (companyid);


--
-- Name: contact__pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY contact_
    ADD CONSTRAINT contact__pkey PRIMARY KEY (contactid);


--
-- Name: counter_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY counter
    ADD CONSTRAINT counter_pkey PRIMARY KEY (name);


--
-- Name: country_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY country
    ADD CONSTRAINT country_pkey PRIMARY KEY (countryid);


--
-- Name: cyrususer_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY cyrususer
    ADD CONSTRAINT cyrususer_pkey PRIMARY KEY (userid);


--
-- Name: cyrusvirtual_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY cyrusvirtual
    ADD CONSTRAINT cyrusvirtual_pkey PRIMARY KEY (emailaddress);


--
-- Name: ddlrecord_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY ddlrecord
    ADD CONSTRAINT ddlrecord_pkey PRIMARY KEY (recordid);


--
-- Name: ddlrecordset_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY ddlrecordset
    ADD CONSTRAINT ddlrecordset_pkey PRIMARY KEY (recordsetid);


--
-- Name: ddlrecordversion_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY ddlrecordversion
    ADD CONSTRAINT ddlrecordversion_pkey PRIMARY KEY (recordversionid);


--
-- Name: ddmcontent_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY ddmcontent
    ADD CONSTRAINT ddmcontent_pkey PRIMARY KEY (contentid);


--
-- Name: ddmstoragelink_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY ddmstoragelink
    ADD CONSTRAINT ddmstoragelink_pkey PRIMARY KEY (storagelinkid);


--
-- Name: ddmstructure_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY ddmstructure
    ADD CONSTRAINT ddmstructure_pkey PRIMARY KEY (structureid);


--
-- Name: ddmstructurelink_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY ddmstructurelink
    ADD CONSTRAINT ddmstructurelink_pkey PRIMARY KEY (structurelinkid);


--
-- Name: ddmtemplate_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY ddmtemplate
    ADD CONSTRAINT ddmtemplate_pkey PRIMARY KEY (templateid);


--
-- Name: dlcontent_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY dlcontent
    ADD CONSTRAINT dlcontent_pkey PRIMARY KEY (contentid);


--
-- Name: dlfileentry_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY dlfileentry
    ADD CONSTRAINT dlfileentry_pkey PRIMARY KEY (fileentryid);


--
-- Name: dlfileentrymetadata_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY dlfileentrymetadata
    ADD CONSTRAINT dlfileentrymetadata_pkey PRIMARY KEY (fileentrymetadataid);


--
-- Name: dlfileentrytype_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY dlfileentrytype
    ADD CONSTRAINT dlfileentrytype_pkey PRIMARY KEY (fileentrytypeid);


--
-- Name: dlfileentrytypes_ddmstructures_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY dlfileentrytypes_ddmstructures
    ADD CONSTRAINT dlfileentrytypes_ddmstructures_pkey PRIMARY KEY (structureid, fileentrytypeid);


--
-- Name: dlfileentrytypes_dlfolders_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY dlfileentrytypes_dlfolders
    ADD CONSTRAINT dlfileentrytypes_dlfolders_pkey PRIMARY KEY (fileentrytypeid, folderid);


--
-- Name: dlfilerank_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY dlfilerank
    ADD CONSTRAINT dlfilerank_pkey PRIMARY KEY (filerankid);


--
-- Name: dlfileshortcut_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY dlfileshortcut
    ADD CONSTRAINT dlfileshortcut_pkey PRIMARY KEY (fileshortcutid);


--
-- Name: dlfileversion_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY dlfileversion
    ADD CONSTRAINT dlfileversion_pkey PRIMARY KEY (fileversionid);


--
-- Name: dlfolder_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY dlfolder
    ADD CONSTRAINT dlfolder_pkey PRIMARY KEY (folderid);


--
-- Name: dlsync_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY dlsync
    ADD CONSTRAINT dlsync_pkey PRIMARY KEY (syncid);


--
-- Name: emailaddress_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY emailaddress
    ADD CONSTRAINT emailaddress_pkey PRIMARY KEY (emailaddressid);


--
-- Name: expandocolumn_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY expandocolumn
    ADD CONSTRAINT expandocolumn_pkey PRIMARY KEY (columnid);


--
-- Name: expandorow_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY expandorow
    ADD CONSTRAINT expandorow_pkey PRIMARY KEY (rowid_);


--
-- Name: expandotable_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY expandotable
    ADD CONSTRAINT expandotable_pkey PRIMARY KEY (tableid);


--
-- Name: expandovalue_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY expandovalue
    ADD CONSTRAINT expandovalue_pkey PRIMARY KEY (valueid);


--
-- Name: group__pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY group_
    ADD CONSTRAINT group__pkey PRIMARY KEY (groupid);


--
-- Name: groups_orgs_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY groups_orgs
    ADD CONSTRAINT groups_orgs_pkey PRIMARY KEY (groupid, organizationid);


--
-- Name: groups_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY groups_permissions
    ADD CONSTRAINT groups_permissions_pkey PRIMARY KEY (groupid, permissionid);


--
-- Name: groups_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY groups_roles
    ADD CONSTRAINT groups_roles_pkey PRIMARY KEY (groupid, roleid);


--
-- Name: groups_usergroups_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY groups_usergroups
    ADD CONSTRAINT groups_usergroups_pkey PRIMARY KEY (groupid, usergroupid);


--
-- Name: image_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY image
    ADD CONSTRAINT image_pkey PRIMARY KEY (imageid);


--
-- Name: journalarticle_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY journalarticle
    ADD CONSTRAINT journalarticle_pkey PRIMARY KEY (id_);


--
-- Name: journalarticleimage_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY journalarticleimage
    ADD CONSTRAINT journalarticleimage_pkey PRIMARY KEY (articleimageid);


--
-- Name: journalarticleresource_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY journalarticleresource
    ADD CONSTRAINT journalarticleresource_pkey PRIMARY KEY (resourceprimkey);


--
-- Name: journalcontentsearch_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY journalcontentsearch
    ADD CONSTRAINT journalcontentsearch_pkey PRIMARY KEY (contentsearchid);


--
-- Name: journalfeed_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY journalfeed
    ADD CONSTRAINT journalfeed_pkey PRIMARY KEY (id_);


--
-- Name: journalstructure_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY journalstructure
    ADD CONSTRAINT journalstructure_pkey PRIMARY KEY (id_);


--
-- Name: journaltemplate_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY journaltemplate
    ADD CONSTRAINT journaltemplate_pkey PRIMARY KEY (id_);


--
-- Name: layout_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY layout
    ADD CONSTRAINT layout_pkey PRIMARY KEY (plid);


--
-- Name: layoutbranch_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY layoutbranch
    ADD CONSTRAINT layoutbranch_pkey PRIMARY KEY (layoutbranchid);


--
-- Name: layoutprototype_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY layoutprototype
    ADD CONSTRAINT layoutprototype_pkey PRIMARY KEY (layoutprototypeid);


--
-- Name: layoutrevision_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY layoutrevision
    ADD CONSTRAINT layoutrevision_pkey PRIMARY KEY (layoutrevisionid);


--
-- Name: layoutset_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY layoutset
    ADD CONSTRAINT layoutset_pkey PRIMARY KEY (layoutsetid);


--
-- Name: layoutsetbranch_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY layoutsetbranch
    ADD CONSTRAINT layoutsetbranch_pkey PRIMARY KEY (layoutsetbranchid);


--
-- Name: layoutsetprototype_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY layoutsetprototype
    ADD CONSTRAINT layoutsetprototype_pkey PRIMARY KEY (layoutsetprototypeid);


--
-- Name: listtype_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY listtype
    ADD CONSTRAINT listtype_pkey PRIMARY KEY (listtypeid);


--
-- Name: lock__pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY lock_
    ADD CONSTRAINT lock__pkey PRIMARY KEY (lockid);


--
-- Name: marketplace_app_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY marketplace_app
    ADD CONSTRAINT marketplace_app_pkey PRIMARY KEY (appid);


--
-- Name: marketplace_module_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY marketplace_module
    ADD CONSTRAINT marketplace_module_pkey PRIMARY KEY (moduleid);


--
-- Name: mbban_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY mbban
    ADD CONSTRAINT mbban_pkey PRIMARY KEY (banid);


--
-- Name: mbcategory_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY mbcategory
    ADD CONSTRAINT mbcategory_pkey PRIMARY KEY (categoryid);


--
-- Name: mbdiscussion_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY mbdiscussion
    ADD CONSTRAINT mbdiscussion_pkey PRIMARY KEY (discussionid);


--
-- Name: mbmailinglist_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY mbmailinglist
    ADD CONSTRAINT mbmailinglist_pkey PRIMARY KEY (mailinglistid);


--
-- Name: mbmessage_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY mbmessage
    ADD CONSTRAINT mbmessage_pkey PRIMARY KEY (messageid);


--
-- Name: mbstatsuser_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY mbstatsuser
    ADD CONSTRAINT mbstatsuser_pkey PRIMARY KEY (statsuserid);


--
-- Name: mbthread_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY mbthread
    ADD CONSTRAINT mbthread_pkey PRIMARY KEY (threadid);


--
-- Name: mbthreadflag_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY mbthreadflag
    ADD CONSTRAINT mbthreadflag_pkey PRIMARY KEY (threadflagid);


--
-- Name: mdraction_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY mdraction
    ADD CONSTRAINT mdraction_pkey PRIMARY KEY (actionid);


--
-- Name: mdrrule_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY mdrrule
    ADD CONSTRAINT mdrrule_pkey PRIMARY KEY (ruleid);


--
-- Name: mdrrulegroup_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY mdrrulegroup
    ADD CONSTRAINT mdrrulegroup_pkey PRIMARY KEY (rulegroupid);


--
-- Name: mdrrulegroupinstance_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY mdrrulegroupinstance
    ADD CONSTRAINT mdrrulegroupinstance_pkey PRIMARY KEY (rulegroupinstanceid);


--
-- Name: membershiprequest_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY membershiprequest
    ADD CONSTRAINT membershiprequest_pkey PRIMARY KEY (membershiprequestid);


--
-- Name: organization__pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY organization_
    ADD CONSTRAINT organization__pkey PRIMARY KEY (organizationid);


--
-- Name: orggrouppermission_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY orggrouppermission
    ADD CONSTRAINT orggrouppermission_pkey PRIMARY KEY (organizationid, groupid, permissionid);


--
-- Name: orggrouprole_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY orggrouprole
    ADD CONSTRAINT orggrouprole_pkey PRIMARY KEY (organizationid, groupid, roleid);


--
-- Name: orglabor_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY orglabor
    ADD CONSTRAINT orglabor_pkey PRIMARY KEY (orglaborid);


--
-- Name: passwordpolicy_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY passwordpolicy
    ADD CONSTRAINT passwordpolicy_pkey PRIMARY KEY (passwordpolicyid);


--
-- Name: passwordpolicyrel_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY passwordpolicyrel
    ADD CONSTRAINT passwordpolicyrel_pkey PRIMARY KEY (passwordpolicyrelid);


--
-- Name: passwordtracker_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY passwordtracker
    ADD CONSTRAINT passwordtracker_pkey PRIMARY KEY (passwordtrackerid);


--
-- Name: permission__pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY permission_
    ADD CONSTRAINT permission__pkey PRIMARY KEY (permissionid);


--
-- Name: phone_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY phone
    ADD CONSTRAINT phone_pkey PRIMARY KEY (phoneid);


--
-- Name: pluginsetting_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY pluginsetting
    ADD CONSTRAINT pluginsetting_pkey PRIMARY KEY (pluginsettingid);


--
-- Name: pollschoice_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY pollschoice
    ADD CONSTRAINT pollschoice_pkey PRIMARY KEY (choiceid);


--
-- Name: pollsquestion_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY pollsquestion
    ADD CONSTRAINT pollsquestion_pkey PRIMARY KEY (questionid);


--
-- Name: pollsvote_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY pollsvote
    ADD CONSTRAINT pollsvote_pkey PRIMARY KEY (voteid);


--
-- Name: portalpreferences_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY portalpreferences
    ADD CONSTRAINT portalpreferences_pkey PRIMARY KEY (portalpreferencesid);


--
-- Name: portlet_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY portlet
    ADD CONSTRAINT portlet_pkey PRIMARY KEY (id_);


--
-- Name: portletitem_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY portletitem
    ADD CONSTRAINT portletitem_pkey PRIMARY KEY (portletitemid);


--
-- Name: portletpreferences_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY portletpreferences
    ADD CONSTRAINT portletpreferences_pkey PRIMARY KEY (portletpreferencesid);


--
-- Name: quartz_blob_triggers_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY quartz_blob_triggers
    ADD CONSTRAINT quartz_blob_triggers_pkey PRIMARY KEY (sched_name, trigger_name, trigger_group);


--
-- Name: quartz_calendars_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY quartz_calendars
    ADD CONSTRAINT quartz_calendars_pkey PRIMARY KEY (sched_name, calendar_name);


--
-- Name: quartz_cron_triggers_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY quartz_cron_triggers
    ADD CONSTRAINT quartz_cron_triggers_pkey PRIMARY KEY (sched_name, trigger_name, trigger_group);


--
-- Name: quartz_fired_triggers_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY quartz_fired_triggers
    ADD CONSTRAINT quartz_fired_triggers_pkey PRIMARY KEY (sched_name, entry_id);


--
-- Name: quartz_job_details_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY quartz_job_details
    ADD CONSTRAINT quartz_job_details_pkey PRIMARY KEY (sched_name, job_name, job_group);


--
-- Name: quartz_locks_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY quartz_locks
    ADD CONSTRAINT quartz_locks_pkey PRIMARY KEY (sched_name, lock_name);


--
-- Name: quartz_paused_trigger_grps_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY quartz_paused_trigger_grps
    ADD CONSTRAINT quartz_paused_trigger_grps_pkey PRIMARY KEY (sched_name, trigger_group);


--
-- Name: quartz_scheduler_state_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY quartz_scheduler_state
    ADD CONSTRAINT quartz_scheduler_state_pkey PRIMARY KEY (sched_name, instance_name);


--
-- Name: quartz_simple_triggers_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY quartz_simple_triggers
    ADD CONSTRAINT quartz_simple_triggers_pkey PRIMARY KEY (sched_name, trigger_name, trigger_group);


--
-- Name: quartz_simprop_triggers_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY quartz_simprop_triggers
    ADD CONSTRAINT quartz_simprop_triggers_pkey PRIMARY KEY (sched_name, trigger_name, trigger_group);


--
-- Name: quartz_triggers_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY quartz_triggers
    ADD CONSTRAINT quartz_triggers_pkey PRIMARY KEY (sched_name, trigger_name, trigger_group);


--
-- Name: ratingsentry_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY ratingsentry
    ADD CONSTRAINT ratingsentry_pkey PRIMARY KEY (entryid);


--
-- Name: ratingsstats_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY ratingsstats
    ADD CONSTRAINT ratingsstats_pkey PRIMARY KEY (statsid);


--
-- Name: region_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY region
    ADD CONSTRAINT region_pkey PRIMARY KEY (regionid);


--
-- Name: release__pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY release_
    ADD CONSTRAINT release__pkey PRIMARY KEY (releaseid);


--
-- Name: repository_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY repository
    ADD CONSTRAINT repository_pkey PRIMARY KEY (repositoryid);


--
-- Name: repositoryentry_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY repositoryentry
    ADD CONSTRAINT repositoryentry_pkey PRIMARY KEY (repositoryentryid);


--
-- Name: resource__pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY resource_
    ADD CONSTRAINT resource__pkey PRIMARY KEY (resourceid);


--
-- Name: resourceaction_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY resourceaction
    ADD CONSTRAINT resourceaction_pkey PRIMARY KEY (resourceactionid);


--
-- Name: resourceblock_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY resourceblock
    ADD CONSTRAINT resourceblock_pkey PRIMARY KEY (resourceblockid);


--
-- Name: resourceblockpermission_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY resourceblockpermission
    ADD CONSTRAINT resourceblockpermission_pkey PRIMARY KEY (resourceblockpermissionid);


--
-- Name: resourcecode_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY resourcecode
    ADD CONSTRAINT resourcecode_pkey PRIMARY KEY (codeid);


--
-- Name: resourcepermission_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY resourcepermission
    ADD CONSTRAINT resourcepermission_pkey PRIMARY KEY (resourcepermissionid);


--
-- Name: resourcetypepermission_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY resourcetypepermission
    ADD CONSTRAINT resourcetypepermission_pkey PRIMARY KEY (resourcetypepermissionid);


--
-- Name: role__pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY role_
    ADD CONSTRAINT role__pkey PRIMARY KEY (roleid);


--
-- Name: roles_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY roles_permissions
    ADD CONSTRAINT roles_permissions_pkey PRIMARY KEY (permissionid, roleid);


--
-- Name: scframeworkversi_scproductvers_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY scframeworkversi_scproductvers
    ADD CONSTRAINT scframeworkversi_scproductvers_pkey PRIMARY KEY (frameworkversionid, productversionid);


--
-- Name: scframeworkversion_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY scframeworkversion
    ADD CONSTRAINT scframeworkversion_pkey PRIMARY KEY (frameworkversionid);


--
-- Name: sclicense_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY sclicense
    ADD CONSTRAINT sclicense_pkey PRIMARY KEY (licenseid);


--
-- Name: sclicenses_scproductentries_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY sclicenses_scproductentries
    ADD CONSTRAINT sclicenses_scproductentries_pkey PRIMARY KEY (licenseid, productentryid);


--
-- Name: scproductentry_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY scproductentry
    ADD CONSTRAINT scproductentry_pkey PRIMARY KEY (productentryid);


--
-- Name: scproductscreenshot_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY scproductscreenshot
    ADD CONSTRAINT scproductscreenshot_pkey PRIMARY KEY (productscreenshotid);


--
-- Name: scproductversion_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY scproductversion
    ADD CONSTRAINT scproductversion_pkey PRIMARY KEY (productversionid);


--
-- Name: servicecomponent_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY servicecomponent
    ADD CONSTRAINT servicecomponent_pkey PRIMARY KEY (servicecomponentid);


--
-- Name: shard_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY shard
    ADD CONSTRAINT shard_pkey PRIMARY KEY (shardid);


--
-- Name: shoppingcart_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY shoppingcart
    ADD CONSTRAINT shoppingcart_pkey PRIMARY KEY (cartid);


--
-- Name: shoppingcategory_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY shoppingcategory
    ADD CONSTRAINT shoppingcategory_pkey PRIMARY KEY (categoryid);


--
-- Name: shoppingcoupon_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY shoppingcoupon
    ADD CONSTRAINT shoppingcoupon_pkey PRIMARY KEY (couponid);


--
-- Name: shoppingitem_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY shoppingitem
    ADD CONSTRAINT shoppingitem_pkey PRIMARY KEY (itemid);


--
-- Name: shoppingitemfield_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY shoppingitemfield
    ADD CONSTRAINT shoppingitemfield_pkey PRIMARY KEY (itemfieldid);


--
-- Name: shoppingitemprice_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY shoppingitemprice
    ADD CONSTRAINT shoppingitemprice_pkey PRIMARY KEY (itempriceid);


--
-- Name: shoppingorder_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY shoppingorder
    ADD CONSTRAINT shoppingorder_pkey PRIMARY KEY (orderid);


--
-- Name: shoppingorderitem_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY shoppingorderitem
    ADD CONSTRAINT shoppingorderitem_pkey PRIMARY KEY (orderitemid);


--
-- Name: socialactivity_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY socialactivity
    ADD CONSTRAINT socialactivity_pkey PRIMARY KEY (activityid);


--
-- Name: socialactivityachievement_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY socialactivityachievement
    ADD CONSTRAINT socialactivityachievement_pkey PRIMARY KEY (activityachievementid);


--
-- Name: socialactivitycounter_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY socialactivitycounter
    ADD CONSTRAINT socialactivitycounter_pkey PRIMARY KEY (activitycounterid);


--
-- Name: socialactivitylimit_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY socialactivitylimit
    ADD CONSTRAINT socialactivitylimit_pkey PRIMARY KEY (activitylimitid);


--
-- Name: socialactivitysetting_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY socialactivitysetting
    ADD CONSTRAINT socialactivitysetting_pkey PRIMARY KEY (activitysettingid);


--
-- Name: socialrelation_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY socialrelation
    ADD CONSTRAINT socialrelation_pkey PRIMARY KEY (relationid);


--
-- Name: socialrequest_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY socialrequest
    ADD CONSTRAINT socialrequest_pkey PRIMARY KEY (requestid);


--
-- Name: subscription_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY subscription
    ADD CONSTRAINT subscription_pkey PRIMARY KEY (subscriptionid);


--
-- Name: team_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY team
    ADD CONSTRAINT team_pkey PRIMARY KEY (teamid);


--
-- Name: ticket_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY ticket
    ADD CONSTRAINT ticket_pkey PRIMARY KEY (ticketid);


--
-- Name: user__pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY user_
    ADD CONSTRAINT user__pkey PRIMARY KEY (userid);


--
-- Name: usergroup_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY usergroup
    ADD CONSTRAINT usergroup_pkey PRIMARY KEY (usergroupid);


--
-- Name: usergroupgrouprole_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY usergroupgrouprole
    ADD CONSTRAINT usergroupgrouprole_pkey PRIMARY KEY (usergroupid, groupid, roleid);


--
-- Name: usergrouprole_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY usergrouprole
    ADD CONSTRAINT usergrouprole_pkey PRIMARY KEY (userid, groupid, roleid);


--
-- Name: usergroups_teams_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY usergroups_teams
    ADD CONSTRAINT usergroups_teams_pkey PRIMARY KEY (teamid, usergroupid);


--
-- Name: useridmapper_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY useridmapper
    ADD CONSTRAINT useridmapper_pkey PRIMARY KEY (useridmapperid);


--
-- Name: usernotificationevent_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY usernotificationevent
    ADD CONSTRAINT usernotificationevent_pkey PRIMARY KEY (usernotificationeventid);


--
-- Name: users_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY users_groups
    ADD CONSTRAINT users_groups_pkey PRIMARY KEY (groupid, userid);


--
-- Name: users_orgs_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY users_orgs
    ADD CONSTRAINT users_orgs_pkey PRIMARY KEY (organizationid, userid);


--
-- Name: users_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY users_permissions
    ADD CONSTRAINT users_permissions_pkey PRIMARY KEY (permissionid, userid);


--
-- Name: users_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY users_roles
    ADD CONSTRAINT users_roles_pkey PRIMARY KEY (roleid, userid);


--
-- Name: users_teams_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY users_teams
    ADD CONSTRAINT users_teams_pkey PRIMARY KEY (teamid, userid);


--
-- Name: users_usergroups_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY users_usergroups
    ADD CONSTRAINT users_usergroups_pkey PRIMARY KEY (userid, usergroupid);


--
-- Name: usertracker_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY usertracker
    ADD CONSTRAINT usertracker_pkey PRIMARY KEY (usertrackerid);


--
-- Name: usertrackerpath_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY usertrackerpath
    ADD CONSTRAINT usertrackerpath_pkey PRIMARY KEY (usertrackerpathid);


--
-- Name: virtualhost_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY virtualhost
    ADD CONSTRAINT virtualhost_pkey PRIMARY KEY (virtualhostid);


--
-- Name: webdavprops_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY webdavprops
    ADD CONSTRAINT webdavprops_pkey PRIMARY KEY (webdavpropsid);


--
-- Name: website_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY website
    ADD CONSTRAINT website_pkey PRIMARY KEY (websiteid);


--
-- Name: wikinode_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY wikinode
    ADD CONSTRAINT wikinode_pkey PRIMARY KEY (nodeid);


--
-- Name: wikipage_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY wikipage
    ADD CONSTRAINT wikipage_pkey PRIMARY KEY (pageid);


--
-- Name: wikipageresource_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY wikipageresource
    ADD CONSTRAINT wikipageresource_pkey PRIMARY KEY (resourceprimkey);


--
-- Name: workflowdefinitionlink_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY workflowdefinitionlink
    ADD CONSTRAINT workflowdefinitionlink_pkey PRIMARY KEY (workflowdefinitionlinkid);


--
-- Name: workflowinstancelink_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY workflowinstancelink
    ADD CONSTRAINT workflowinstancelink_pkey PRIMARY KEY (workflowinstancelinkid);


--
-- Name: ix_103d6207; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_103d6207 ON journalarticleimage USING btree (groupid, articleid, version, elinstanceid, elname, languageid);


--
-- Name: ix_1073ab9f; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_1073ab9f ON mbmessage USING btree (groupid, categoryid);


--
-- Name: ix_11641e26; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_11641e26 ON repository USING btree (uuid_, groupid);


--
-- Name: ix_119b5630; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_119b5630 ON shoppingorder USING btree (groupid, userid, pppaymentstatus);


--
-- Name: ix_11fb3e42; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_11fb3e42 ON region USING btree (countryid, active_);


--
-- Name: ix_12112599; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_12112599 ON pollsvote USING btree (questionid);


--
-- Name: ix_121ca3cb; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_121ca3cb ON socialactivity USING btree (receiveruserid);


--
-- Name: ix_12566ec2; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_12566ec2 ON company USING btree (mx);


--
-- Name: ix_1271f25f; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_1271f25f ON socialactivity USING btree (mirroractivityid);


--
-- Name: ix_128516c8; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_128516c8 ON assetlink USING btree (entryid1);


--
-- Name: ix_12851a89; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_12851a89 ON assetlink USING btree (entryid2);


--
-- Name: ix_12a92145; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_12a92145 ON socialrelation USING btree (userid1, userid2, type_);


--
-- Name: ix_12b5e51d; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_12b5e51d ON portlet USING btree (companyid, portletid);


--
-- Name: ix_12ee4898; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_12ee4898 ON calevent USING btree (groupid);


--
-- Name: ix_13805bf7; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_13805bf7 ON assettagproperty USING btree (companyid, key_);


--
-- Name: ix_13984800; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_13984800 ON layoutrevision USING btree (layoutsetbranchid, layoutbranchid, plid);


--
-- Name: ix_1399d844; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_1399d844 ON dlfileentrytype USING btree (uuid_, groupid);


--
-- Name: ix_13c5cd3a; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_13c5cd3a ON lock_ USING btree (uuid_);


--
-- Name: ix_143dc786; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_143dc786 ON team USING btree (groupid, name);


--
-- Name: ix_14d5a20d; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_14d5a20d ON assetlink USING btree (entryid1, type_);


--
-- Name: ix_14d8bcc0; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_14d8bcc0 ON usertrackerpath USING btree (usertrackerid);


--
-- Name: ix_14f06a6b; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_14f06a6b ON announcementsentry USING btree (classnameid, classpk, alert);


--
-- Name: ix_158b526f; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_158b526f ON journalarticleimage USING btree (groupid, articleid, version);


--
-- Name: ix_16184d57; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_16184d57 ON ratingsentry USING btree (classnameid, classpk);


--
-- Name: ix_16218a38; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_16218a38 ON group_ USING btree (livegroupid);


--
-- Name: ix_16d87ca7; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_16d87ca7 ON region USING btree (countryid);


--
-- Name: ix_16e99b0a; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_16e99b0a ON wikipage USING btree (groupid, nodeid, head);


--
-- Name: ix_1701cb2b; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_1701cb2b ON journaltemplate USING btree (groupid, structureid);


--
-- Name: ix_17692b58; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_17692b58 ON ddmstructurelink USING btree (structureid);


--
-- Name: ix_186442a4; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_186442a4 ON quartz_triggers USING btree (sched_name, trigger_name, trigger_group, trigger_state);


--
-- Name: ix_19da007b; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_19da007b ON country USING btree (name);


--
-- Name: ix_1a1b61d2; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_1a1b61d2 ON layout USING btree (groupid, privatelayout, type_);


--
-- Name: ix_1aa07a6d; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_1aa07a6d ON website USING btree (companyid, classnameid, classpk, primary_);


--
-- Name: ix_1aa75ce3; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_1aa75ce3 ON ddmtemplate USING btree (uuid_, groupid);


--
-- Name: ix_1ad93c16; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_1ad93c16 ON mbmessage USING btree (companyid, status);


--
-- Name: ix_1afbde08; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_1afbde08 ON announcementsentry USING btree (uuid_);


--
-- Name: ix_1b1040fd; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_1b1040fd ON blogsentry USING btree (uuid_, groupid);


--
-- Name: ix_1b12ca20; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_1b12ca20 ON journaltemplate USING btree (templateid);


--
-- Name: ix_1b2b8792; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_1b2b8792 ON assetvocabulary USING btree (uuid_, groupid);


--
-- Name: ix_1b7e3b67; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_1b7e3b67 ON socialactivitycounter USING btree (groupid, classnameid, classpk, name, ownertype, endperiod);


--
-- Name: ix_1b988d7a; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_1b988d7a ON usergrouprole USING btree (groupid);


--
-- Name: ix_1ba1f9dc; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_1ba1f9dc ON quartz_triggers USING btree (sched_name, trigger_group);


--
-- Name: ix_1bb072ca; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_1bb072ca ON emailaddress USING btree (companyid);


--
-- Name: ix_1bbfd4d3; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_1bbfd4d3 ON pollsvote USING btree (questionid, userid);


--
-- Name: ix_1bd3f4c; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_1bd3f4c ON expandovalue USING btree (tableid, classpk);


--
-- Name: ix_1c717ca6; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_1c717ca6 ON shoppingitem USING btree (companyid, sku);


--
-- Name: ix_1c841592; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_1c841592 ON sclicense USING btree (active_);


--
-- Name: ix_1cdf88c; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_1cdf88c ON usergroupgrouprole USING btree (roleid);


--
-- Name: ix_1d15553e; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_1d15553e ON shoppingorder USING btree (groupid);


--
-- Name: ix_1d731f03; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_1d731f03 ON user_ USING btree (companyid, facebookid);


--
-- Name: ix_1e5b9905; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_1e5b9905 ON workflowdefinitionlink USING btree (groupid, companyid, classnameid, classpk);


--
-- Name: ix_1e6464f5; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_1e6464f5 ON shoppingcategory USING btree (groupid, parentcategoryid);


--
-- Name: ix_1e9cf33b; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_1e9cf33b ON socialactivitysetting USING btree (groupid, classnameid, activitytype);


--
-- Name: ix_1e9d371d; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_1e9d371d ON assetentry USING btree (classnameid, classpk);


--
-- Name: ix_1eba6821; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_1eba6821 ON assetentry USING btree (groupid, classuuid);


--
-- Name: ix_1ecc7656; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_1ecc7656 ON wikipage USING btree (nodeid, redirecttitle);


--
-- Name: ix_1efd8ee9; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_1efd8ee9 ON blogsentry USING btree (groupid, status);


--
-- Name: ix_1f00c374; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_1f00c374 ON socialactivity USING btree (mirroractivityid, classnameid, classpk);


--
-- Name: ix_1f92813c; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_1f92813c ON quartz_triggers USING btree (sched_name, next_fire_time, misfire_instr);


--
-- Name: ix_1fe9c04; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_1fe9c04 ON dlfileentrymetadata USING btree (fileversionid);


--
-- Name: ix_2008facb; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_2008facb ON assetcategory USING btree (groupid, vocabularyid);


--
-- Name: ix_204d31e8; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_204d31e8 ON quartz_fired_triggers USING btree (sched_name, instance_name);


--
-- Name: ix_20962903; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_20962903 ON journalcontentsearch USING btree (groupid, privatelayout);


--
-- Name: ix_20f14d93; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_20f14d93 ON marketplace_app USING btree (remoteappid);


--
-- Name: ix_21277664; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_21277664 ON wikipageresource USING btree (nodeid, title);


--
-- Name: ix_2200aa69; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_2200aa69 ON resourcepermission USING btree (companyid, name, scope, primkey);


--
-- Name: ix_228562ad; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_228562ad ON lock_ USING btree (classname, key_);


--
-- Name: ix_22882d02; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_22882d02 ON journalarticle USING btree (groupid, urltitle);


--
-- Name: ix_22dab85c; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_22dab85c ON mdrrulegroupinstance USING btree (groupid, classnameid, classpk);


--
-- Name: ix_23922f7d; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_23922f7d ON layout USING btree (iconimageid);


--
-- Name: ix_23ead0d; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_23ead0d ON usergroup USING btree (companyid, name);


--
-- Name: ix_2578fbd3; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_2578fbd3 ON resource_ USING btree (codeid);


--
-- Name: ix_25d734cd; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_25d734cd ON country USING btree (active_);


--
-- Name: ix_25ffb6fa; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_25ffb6fa ON journaltemplate USING btree (smallimageid);


--
-- Name: ix_26284944; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_26284944 ON resourcepermission USING btree (companyid, primkey);


--
-- Name: ix_2672f77f; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_2672f77f ON blogsentry USING btree (displaydate, status);


--
-- Name: ix_27006638; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_27006638 ON sclicenses_scproductentries USING btree (licenseid);


--
-- Name: ix_270ba5e1; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_270ba5e1 ON ddlrecordset USING btree (uuid_, groupid);


--
-- Name: ix_272991fa; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_272991fa ON scframeworkversion USING btree (groupid);


--
-- Name: ix_2857419d; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_2857419d ON journaltemplate USING btree (uuid_);


--
-- Name: ix_287b1f89; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_287b1f89 ON assetcategory USING btree (vocabularyid);


--
-- Name: ix_28a49bb9; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_28a49bb9 ON bookmarksfolder USING btree (resourceblockid);


--
-- Name: ix_28c78d5c; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_28c78d5c ON blogsstatsuser USING btree (groupid, entrycount);


--
-- Name: ix_2932dd37; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_2932dd37 ON listtype USING btree (type_);


--
-- Name: ix_29ba1cf5; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_29ba1cf5 ON usertracker USING btree (companyid);


--
-- Name: ix_29d0af28; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_29d0af28 ON dlfileentry USING btree (groupid, folderid, fileentrytypeid);


--
-- Name: ix_2a048ea0; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_2a048ea0 ON dlfolder USING btree (groupid, parentfolderid, mountpoint);


--
-- Name: ix_2a2468; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_2a2468 ON socialactivity USING btree (groupid);


--
-- Name: ix_2a2cb130; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_2a2cb130 ON emailaddress USING btree (companyid, classnameid, classpk, primary_);


--
-- Name: ix_2aba25d7; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_2aba25d7 ON bookmarksfolder USING btree (companyid);


--
-- Name: ix_2c1142e; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_2c1142e ON passwordpolicy USING btree (companyid, defaultpolicy);


--
-- Name: ix_2c42603e; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_2c42603e ON layoutbranch USING btree (layoutsetbranchid, plid);


--
-- Name: ix_2c61314e; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_2c61314e ON portletitem USING btree (groupid, portletid);


--
-- Name: ix_2c944354; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_2c944354 ON assettagproperty USING btree (tagid, key_);


--
-- Name: ix_2cd67c81; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_2cd67c81 ON wikipage USING btree (resourceprimkey, nodeid, version);


--
-- Name: ix_2d4cc782; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_2d4cc782 ON resourceblock USING btree (companyid, name);


--
-- Name: ix_2d9a426f; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_2d9a426f ON region USING btree (active_);


--
-- Name: ix_2e1a92d4; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_2e1a92d4 ON subscription USING btree (companyid, userid, classnameid, classpk);


--
-- Name: ix_2e207659; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_2e207659 ON journalarticle USING btree (groupid, structureid);


--
-- Name: ix_2e4e3885; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_2e4e3885 ON assetentry USING btree (publishdate);


--
-- Name: ix_2ed82cad; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_2ed82cad ON assetentries_assettags USING btree (entryid);


--
-- Name: ix_2f4ddfe1; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_2f4ddfe1 ON ddlrecordversion USING btree (recordid);


--
-- Name: ix_301d024b; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_301d024b ON journalarticle USING btree (groupid, status);


--
-- Name: ix_30616aaa; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_30616aaa ON layoutprototype USING btree (companyid);


--
-- Name: ix_3103ef3d; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_3103ef3d ON groups_roles USING btree (roleid);


--
-- Name: ix_314b621a; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_314b621a ON layoutrevision USING btree (layoutsetbranchid);


--
-- Name: ix_31817a62; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_31817a62 ON ddmstructure USING btree (classnameid);


--
-- Name: ix_31fb0b08; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_31fb0b08 ON usergroups_teams USING btree (teamid);


--
-- Name: ix_31fb749a; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_31fb749a ON groups_usergroups USING btree (groupid);


--
-- Name: ix_32292ed1; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_32292ed1 ON socialrequest USING btree (receiveruserid);


--
-- Name: ix_323df109; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_323df109 ON journalarticle USING btree (companyid, status);


--
-- Name: ix_3251af16; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_3251af16 ON shoppingcoupon USING btree (groupid);


--
-- Name: ix_3269e180; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_3269e180 ON assettagproperty USING btree (tagid);


--
-- Name: ix_326f75bd; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_326f75bd ON passwordtracker USING btree (userid);


--
-- Name: ix_32a18526; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_32a18526 ON ddmstoragelink USING btree (uuid_);


--
-- Name: ix_3321f142; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_3321f142 ON mbmessage USING btree (userid, classnameid, status);


--
-- Name: ix_33781904; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_33781904 ON mbthreadflag USING btree (userid, threadid);


--
-- Name: ix_339e078m; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_339e078m ON quartz_fired_triggers USING btree (sched_name, instance_name, requests_recovery);


--
-- Name: ix_33a4de38; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_33a4de38 ON mbdiscussion USING btree (classnameid, classpk);


--
-- Name: ix_33b8ce8d; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_33b8ce8d ON portletitem USING btree (groupid, portletid, name);


--
-- Name: ix_33bef579; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_33bef579 ON ddmtemplate USING btree (language);


--
-- Name: ix_33f49d16; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_33f49d16 ON journalarticle USING btree (resourceprimkey);


--
-- Name: ix_3463d95b; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_3463d95b ON journalarticle USING btree (uuid_, groupid);


--
-- Name: ix_3504b8bc; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_3504b8bc ON socialactivity USING btree (userid);


--
-- Name: ix_354aa664; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_354aa664 ON repositoryentry USING btree (uuid_, groupid);


--
-- Name: ix_35a2db2f; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_35a2db2f ON journalfeed USING btree (groupid);


--
-- Name: ix_35aa8fa6; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_35aa8fa6 ON membershiprequest USING btree (groupid, userid, statusid);


--
-- Name: ix_35e3e7c6; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_35e3e7c6 ON company USING btree (system);


--
-- Name: ix_36a90ca7; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_36a90ca7 ON socialrequest USING btree (userid, classnameid, classpk, type_, receiveruserid);


--
-- Name: ix_374b35ae; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_374b35ae ON socialactivitycounter USING btree (groupid, classnameid, classpk, name, ownertype, startperiod);


--
-- Name: ix_37562284; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_37562284 ON expandotable USING btree (companyid, classnameid, name);


--
-- Name: ix_377858d2; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_377858d2 ON mbmessage USING btree (groupid, userid, status);


--
-- Name: ix_384788cd; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_384788cd ON socialactivitysetting USING btree (groupid, activitytype);


--
-- Name: ix_385e123e; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_385e123e ON mbmessage USING btree (groupid, categoryid, threadid, status);


--
-- Name: ix_38efe3fd; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_38efe3fd ON company USING btree (logoid);


--
-- Name: ix_38f0315; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_38f0315 ON dlfilerank USING btree (companyid, userid, fileentryid);


--
-- Name: ix_39031f51; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_39031f51 ON journalfeed USING btree (uuid_, groupid);


--
-- Name: ix_39a18ecc; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_39a18ecc ON layout USING btree (sourceprototypelayoutuuid);


--
-- Name: ix_3a1e834e; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_3a1e834e ON user_ USING btree (companyid);


--
-- Name: ix_3b51bb68; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_3b51bb68 ON journalarticleimage USING btree (groupid);


--
-- Name: ix_3b69160f; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_3b69160f ON groups_usergroups USING btree (usergroupid);


--
-- Name: ix_3bb93eca; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_3bb93eca ON scframeworkversi_scproductvers USING btree (frameworkversionid);


--
-- Name: ix_3c028c1e; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_3c028c1e ON journalarticle USING btree (groupid, layoutuuid);


--
-- Name: ix_3cc1ded2; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_3cc1ded2 ON dlfolder USING btree (uuid_, groupid);


--
-- Name: ix_3d070845; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_3d070845 ON journalarticle USING btree (companyid, version);


--
-- Name: ix_3d4af476; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_3d4af476 ON wikipage USING btree (nodeid, title, version);


--
-- Name: ix_3dbb361a; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_3dbb361a ON usernotificationevent USING btree (userid, archived);


--
-- Name: ix_3e2765fc; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_3e2765fc ON journalarticle USING btree (resourceprimkey, status);


--
-- Name: ix_3e5d78c4; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_3e5d78c4 ON usernotificationevent USING btree (userid);


--
-- Name: ix_3e667fe1; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_3e667fe1 ON marketplace_app USING btree (uuid_);


--
-- Name: ix_3f1ea19e; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_3f1ea19e ON journalarticle USING btree (layoutuuid);


--
-- Name: ix_3f9c2fa8; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_3f9c2fa8 ON socialrelation USING btree (userid2, type_);


--
-- Name: ix_3fbfa9f4; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_3fbfa9f4 ON passwordpolicy USING btree (companyid, name);


--
-- Name: ix_4115ec7a; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_4115ec7a ON mbmailinglist USING btree (uuid_);


--
-- Name: ix_415a7007; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_415a7007 ON workflowinstancelink USING btree (groupid, companyid, classnameid, classpk);


--
-- Name: ix_418e4522; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_418e4522 ON organization_ USING btree (companyid, parentorganizationid);


--
-- Name: ix_41a32e0d; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_41a32e0d ON useridmapper USING btree (type_, externaluserid);


--
-- Name: ix_41f6dc8a; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_41f6dc8a ON mbthread USING btree (categoryid, priority);


--
-- Name: ix_4257db85; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_4257db85 ON mbmessage USING btree (groupid, categoryid, status);


--
-- Name: ix_42e86e58; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_42e86e58 ON journalstructure USING btree (uuid_, groupid);


--
-- Name: ix_430d791f; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_430d791f ON blogsentry USING btree (companyid, displaydate);


--
-- Name: ix_431a3960; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_431a3960 ON virtualhost USING btree (hostname);


--
-- Name: ix_43261870; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_43261870 ON dlfileentry USING btree (groupid, userid);


--
-- Name: ix_432f0ab0; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_432f0ab0 ON wikipage USING btree (nodeid, head, status);


--
-- Name: ix_43840eeb; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_43840eeb ON blogsstatsuser USING btree (groupid);


--
-- Name: ix_43e8286a; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_43e8286a ON layoutrevision USING btree (head, plid);


--
-- Name: ix_449a10b9; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_449a10b9 ON role_ USING btree (companyid);


--
-- Name: ix_4501fd9c; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_4501fd9c ON dlfileentrytype USING btree (groupid);


--
-- Name: ix_451e7ae3; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_451e7ae3 ON bookmarksfolder USING btree (uuid_);


--
-- Name: ix_4539a99c; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_4539a99c ON announcementsflag USING btree (userid, entryid, value);


--
-- Name: ix_45f5a7c7; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_45f5a7c7 ON journaltemplate USING btree (structureid);


--
-- Name: ix_46665cc4; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_46665cc4 ON mdrrulegroup USING btree (uuid_, groupid);


--
-- Name: ix_467956fd; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_467956fd ON scproductscreenshot USING btree (productentryid);


--
-- Name: ix_46b0ae8e; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_46b0ae8e ON usertracker USING btree (sessionid);


--
-- Name: ix_46eef3c8; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_46eef3c8 ON wikipage USING btree (nodeid, parenttitle);


--
-- Name: ix_4831ebe4; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_4831ebe4 ON dlfileshortcut USING btree (uuid_);


--
-- Name: ix_48550691; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_48550691 ON layoutset USING btree (groupid, privatelayout);


--
-- Name: ix_485f7e98; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_485f7e98 ON mbthread USING btree (groupid, categoryid, status);


--
-- Name: ix_48814bba; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_48814bba ON mbban USING btree (userid);


--
-- Name: ix_490e7a1e; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_490e7a1e ON ddmstructure USING btree (groupid, structurekey);


--
-- Name: ix_49c37475; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_49c37475 ON dlfolder USING btree (groupid, parentfolderid);


--
-- Name: ix_49d2dec4; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_49d2dec4 ON emailaddress USING btree (companyid, classnameid);


--
-- Name: ix_49d5872c; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_49d5872c ON socialrequest USING btree (uuid_);


--
-- Name: ix_49e15a23; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_49e15a23 ON blogsentry USING btree (groupid, userid, status);


--
-- Name: ix_4a1f4402; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_4a1f4402 ON resourcepermission USING btree (companyid, name, scope, primkey, roleid, ownerid, actionids);


--
-- Name: ix_4a4bb4ed; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_4a4bb4ed ON mbmessage USING btree (userid, classnameid, classpk, status);


--
-- Name: ix_4a527dd3; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_4a527dd3 ON orggrouprole USING btree (groupid);


--
-- Name: ix_4a84af43; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_4a84af43 ON layoutrevision USING btree (layoutsetbranchid, parentlayoutrevisionid, plid);


--
-- Name: ix_4ab3756; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_4ab3756 ON resourceblockpermission USING btree (resourceblockid);


--
-- Name: ix_4b52be89; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_4b52be89 ON socialrelation USING btree (userid1, type_);


--
-- Name: ix_4b7247f6; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_4b7247f6 ON dlfileshortcut USING btree (tofileentryid);


--
-- Name: ix_4bd722bm; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_4bd722bm ON quartz_fired_triggers USING btree (sched_name, trigger_group);


--
-- Name: ix_4bfabb9a; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_4bfabb9a ON dlfileversion USING btree (uuid_);


--
-- Name: ix_4cb1b2b4; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_4cb1b2b4 ON dlfileentry USING btree (companyid);


--
-- Name: ix_4d040680; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_4d040680 ON usergrouprole USING btree (userid, groupid);


--
-- Name: ix_4d06ad51; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_4d06ad51 ON users_teams USING btree (teamid);


--
-- Name: ix_4d19c2b8; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_4d19c2b8 ON permission_ USING btree (actionid, resourceid);


--
-- Name: ix_4d37bb00; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_4d37bb00 ON assetcategory USING btree (uuid_);


--
-- Name: ix_4d5cd982; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_4d5cd982 ON journalarticle USING btree (groupid, articleid, status);


--
-- Name: ix_4f0315b8; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_4f0315b8 ON servicecomponent USING btree (buildnamespace, buildnumber);


--
-- Name: ix_4f0f0ca7; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_4f0f0ca7 ON website USING btree (companyid, classnameid);


--
-- Name: ix_4f40fe5e; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_4f40fe5e ON dlfileentrymetadata USING btree (fileentryid);


--
-- Name: ix_4f4293f1; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_4f4293f1 ON mdrrule USING btree (rulegroupid);


--
-- Name: ix_4f973efe; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_4f973efe ON socialrequest USING btree (uuid_, groupid);


--
-- Name: ix_4fa5969f; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_4fa5969f ON ddlrecordset USING btree (groupid);


--
-- Name: ix_4fa67b72; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_4fa67b72 ON journalstructure USING btree (parentstructureid);


--
-- Name: ix_4fbac092; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_4fbac092 ON ddmstructure USING btree (companyid, classnameid);


--
-- Name: ix_4fddd2bf; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_4fddd2bf ON calevent USING btree (groupid, repeating);


--
-- Name: ix_5005e3af; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_5005e3af ON quartz_fired_triggers USING btree (sched_name, job_name, job_group);


--
-- Name: ix_50702693; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_50702693 ON assettagstats USING btree (classnameid);


--
-- Name: ix_507ba031; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_507ba031 ON blogsstatsuser USING btree (userid, lastpostdate);


--
-- Name: ix_50bf1038; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_50bf1038 ON ddmcontent USING btree (groupid);


--
-- Name: ix_50c36d79; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_50c36d79 ON journalfeed USING btree (uuid_);


--
-- Name: ix_50f1904a; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_50f1904a ON mbthread USING btree (groupid, categoryid, lastpostdate);


--
-- Name: ix_51556082; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_51556082 ON dlfolder USING btree (parentfolderid, name);


--
-- Name: ix_51a8d44d; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_51a8d44d ON mbmessage USING btree (classnameid, classpk);


--
-- Name: ix_51f087f4; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_51f087f4 ON pollsquestion USING btree (uuid_);


--
-- Name: ix_5200100c; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_5200100c ON bookmarksentry USING btree (groupid, folderid);


--
-- Name: ix_52340033; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_52340033 ON assetcategoryproperty USING btree (companyid, key_);


--
-- Name: ix_524fefce; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_524fefce ON usergroup USING btree (companyid);


--
-- Name: ix_5253b1fa; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_5253b1fa ON repository USING btree (groupid);


--
-- Name: ix_5327bb79; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_5327bb79 ON sclicense USING btree (active_, recommended);


--
-- Name: ix_5391712; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_5391712 ON dlfileentry USING btree (groupid, folderid, name);


--
-- Name: ix_54101cc8; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_54101cc8 ON shoppingcart USING btree (userid);


--
-- Name: ix_54243afd; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_54243afd ON subscription USING btree (userid);


--
-- Name: ix_546f2d5c; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_546f2d5c ON wikipage USING btree (nodeid, status);


--
-- Name: ix_551a519f; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_551a519f ON emailaddress USING btree (companyid, classnameid, classpk);


--
-- Name: ix_557a639f; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_557a639f ON layoutprototype USING btree (companyid, active_);


--
-- Name: ix_55f58818; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_55f58818 ON assetvocabulary USING btree (uuid_);


--
-- Name: ix_55f63d98; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_55f63d98 ON layoutsetprototype USING btree (companyid);


--
-- Name: ix_561e44e9; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_561e44e9 ON ddlrecordset USING btree (uuid_);


--
-- Name: ix_56682cc4; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_56682cc4 ON assettagstats USING btree (tagid, classnameid);


--
-- Name: ix_56dab121; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_56dab121 ON ddlrecordset USING btree (groupid, recordsetkey);


--
-- Name: ix_56e0ab21; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_56e0ab21 ON assetlink USING btree (entryid1, entryid2);


--
-- Name: ix_5849891c; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_5849891c ON mdrrulegroup USING btree (groupid);


--
-- Name: ix_59f9ce5c; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_59f9ce5c ON mbmessage USING btree (userid, classnameid);


--
-- Name: ix_5a40cdcc; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_5a40cdcc ON socialrelation USING btree (userid1);


--
-- Name: ix_5a40d18d; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_5a40d18d ON socialrelation USING btree (userid2);


--
-- Name: ix_5aa68501; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_5aa68501 ON group_ USING btree (companyid, name);


--
-- Name: ix_5adbe171; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_5adbe171 ON user_ USING btree (contactid);


--
-- Name: ix_5b019fe8; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_5b019fe8 ON ddmtemplate USING btree (structureid, type_, mode_);


--
-- Name: ix_5b153fb2; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_5b153fb2 ON mbmessage USING btree (groupid);


--
-- Name: ix_5bb6ad6c; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_5bb6ad6c ON dlfileentrytypes_dlfolders USING btree (fileentrytypeid);


--
-- Name: ix_5bc0e264; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_5bc0e264 ON ddmtemplate USING btree (structureid, type_);


--
-- Name: ix_5bc8b0d4; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_5bc8b0d4 ON address USING btree (userid);


--
-- Name: ix_5bddb872; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_5bddb872 ON group_ USING btree (companyid, friendlyurl);


--
-- Name: ix_5c3ff12a; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_5c3ff12a ON mbban USING btree (groupid);


--
-- Name: ix_5cce79c8; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_5cce79c8 ON calevent USING btree (uuid_, groupid);


--
-- Name: ix_5d25244f; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_5d25244f ON scproductentry USING btree (companyid);


--
-- Name: ix_5d6fe3f0; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_5d6fe3f0 ON wikinode USING btree (companyid);


--
-- Name: ix_5de0be11; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_5de0be11 ON group_ USING btree (companyid, classnameid, livegroupid, name);


--
-- Name: ix_5eb4e2fb; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_5eb4e2fb ON role_ USING btree (subtype);


--
-- Name: ix_5f076332; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_5f076332 ON resource_ USING btree (primkey);


--
-- Name: ix_5f615d3e; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_5f615d3e ON shoppingcategory USING btree (groupid);


--
-- Name: ix_5ff18552; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_5ff18552 ON layoutsetbranch USING btree (groupid, privatelayout, name);


--
-- Name: ix_5ff21ce6; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_5ff21ce6 ON wikipage USING btree (groupid, nodeid, title, head);


--
-- Name: ix_60b99860; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_60b99860 ON resourcepermission USING btree (companyid, name, scope);


--
-- Name: ix_61171e99; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_61171e99 ON socialrelation USING btree (companyid);


--
-- Name: ix_615e9f7a; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_615e9f7a ON user_ USING btree (companyid, emailaddress);


--
-- Name: ix_621e19d; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_621e19d ON blogsentry USING btree (groupid, displaydate);


--
-- Name: ix_62d1b3ad; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_62d1b3ad ON journaltemplate USING btree (uuid_, groupid);


--
-- Name: ix_64b1bc66; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_64b1bc66 ON socialactivity USING btree (companyid);


--
-- Name: ix_64f0fe40; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_64f0fe40 ON dlfileentry USING btree (uuid_);


--
-- Name: ix_65576cbc; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_65576cbc ON journalfeed USING btree (groupid, feedid);


--
-- Name: ix_65e84af4; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_65e84af4 ON wikipage USING btree (nodeid, head, parenttitle);


--
-- Name: ix_6660b399; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_6660b399 ON pollschoice USING btree (uuid_);


--
-- Name: ix_66d496a3; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_66d496a3 ON contact_ USING btree (companyid);


--
-- Name: ix_66d70879; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_66d70879 ON membershiprequest USING btree (userid);


--
-- Name: ix_66ff2503; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_66ff2503 ON users_usergroups USING btree (usergroupid);


--
-- Name: ix_6702ca92; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_6702ca92 ON journalstructure USING btree (uuid_);


--
-- Name: ix_67de7856; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_67de7856 ON resource_ USING btree (codeid, primkey);


--
-- Name: ix_6838e427; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_6838e427 ON journalcontentsearch USING btree (groupid, articleid);


--
-- Name: ix_68c0f69c; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_68c0f69c ON journalarticle USING btree (groupid, articleid);


--
-- Name: ix_69157a4d; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_69157a4d ON blogsentry USING btree (uuid_);


--
-- Name: ix_69771487; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_69771487 ON usergroup USING btree (companyid, parentusergroupid);


--
-- Name: ix_69951a25; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_69951a25 ON mbban USING btree (banuserid);


--
-- Name: ix_6a83a66a; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_6a83a66a ON dlcontent USING btree (companyid, repositoryid);


--
-- Name: ix_6a925a4d; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_6a925a4d ON image USING btree (size_);


--
-- Name: ix_6af0d434; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_6af0d434 ON orglabor USING btree (organizationid);


--
-- Name: ix_6bbb7682; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_6bbb7682 ON groups_orgs USING btree (organizationid);


--
-- Name: ix_6c112d7c; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_6c112d7c ON wikinode USING btree (uuid_);


--
-- Name: ix_6c226433; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_6c226433 ON layoutbranch USING btree (layoutsetbranchid);


--
-- Name: ix_6c53da4e; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_6c53da4e ON orggrouppermission USING btree (permissionid);


--
-- Name: ix_6c572dac; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_6c572dac ON scproductscreenshot USING btree (thumbnailid);


--
-- Name: ix_6d5f9b87; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_6d5f9b87 ON shoppingitemfield USING btree (itemid);


--
-- Name: ix_6de88b06; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_6de88b06 ON layout USING btree (groupid, privatelayout, parentlayoutid);


--
-- Name: ix_6e00a2ec; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_6e00a2ec ON dlfileentrytypes_dlfolders USING btree (folderid);


--
-- Name: ix_6e1764f; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_6e1764f ON scframeworkversion USING btree (groupid, active_);


--
-- Name: ix_6edb9600; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_6edb9600 ON announcementsdelivery USING btree (userid);


--
-- Name: ix_6ef03e4e; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_6ef03e4e ON user_ USING btree (companyid, defaultuser);


--
-- Name: ix_7020130f; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_7020130f ON scproductversion USING btree (directdownloadurl);


--
-- Name: ix_702d1ad5; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_702d1ad5 ON ddmstoragelink USING btree (classpk);


--
-- Name: ix_705b40ee; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_705b40ee ON workflowdefinitionlink USING btree (groupid, companyid, classnameid, classpk, typepk);


--
-- Name: ix_705f5aa3; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_705f5aa3 ON layout USING btree (groupid, privatelayout);


--
-- Name: ix_70da9ecb; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_70da9ecb ON layoutrevision USING btree (layoutsetbranchid, plid, status);


--
-- Name: ix_7162c27c; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_7162c27c ON layout USING btree (groupid, privatelayout, layoutid);


--
-- Name: ix_7171b2e8; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_7171b2e8 ON pluginsetting USING btree (companyid, pluginid, plugintype);


--
-- Name: ix_717b97e1; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_717b97e1 ON country USING btree (a2);


--
-- Name: ix_717b9ba2; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_717b9ba2 ON country USING btree (a3);


--
-- Name: ix_717fdd47; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_717fdd47 ON resourcecode USING btree (companyid);


--
-- Name: ix_71cb1123; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_71cb1123 ON address USING btree (companyid, classnameid, classpk);


--
-- Name: ix_72bba8b7; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_72bba8b7 ON layoutset USING btree (layoutsetprototypeuuid);


--
-- Name: ix_72ef6041; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_72ef6041 ON blogsentry USING btree (companyid);


--
-- Name: ix_72f87291; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_72f87291 ON scproductentry USING btree (groupid);


--
-- Name: ix_7306c60; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_7306c60 ON assetentry USING btree (companyid);


--
-- Name: ix_7311e812; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_7311e812 ON scproductentry USING btree (repogroupid, repoartifactid);


--
-- Name: ix_7332b44f; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_7332b44f ON dlfileentrymetadata USING btree (ddmstructureid, fileversionid);


--
-- Name: ix_7338606f; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_7338606f ON servicecomponent USING btree (buildnamespace);


--
-- Name: ix_73c52252; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_73c52252 ON usergroupgrouprole USING btree (usergroupid, groupid);


--
-- Name: ix_740c4d0c; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_740c4d0c ON user_ USING btree (companyid, createdate);


--
-- Name: ix_74c17b04; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_74c17b04 ON repository USING btree (uuid_);


--
-- Name: ix_75267dca; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_75267dca ON groups_orgs USING btree (groupid);


--
-- Name: ix_75b95071; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_75b95071 ON mbmessage USING btree (threadid);


--
-- Name: ix_75be36ad; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_75be36ad ON mdraction USING btree (uuid_, groupid);


--
-- Name: ix_75d42ff9; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_75d42ff9 ON assetentry USING btree (expirationdate);


--
-- Name: ix_7609b2ae; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_7609b2ae ON wikinode USING btree (uuid_, groupid);


--
-- Name: ix_762adc7; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_762adc7 ON ddlrecordversion USING btree (recordid, status);


--
-- Name: ix_762f63c6; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_762f63c6 ON user_ USING btree (emailaddress);


--
-- Name: ix_76ce9cdd; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_76ce9cdd ON mbmailinglist USING btree (groupid, categoryid);


--
-- Name: ix_77923653; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_77923653 ON journaltemplate USING btree (groupid);


--
-- Name: ix_779bca37; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_779bca37 ON quartz_job_details USING btree (sched_name, requests_recovery);


--
-- Name: ix_77bb5e9d; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_77bb5e9d ON mdraction USING btree (uuid_);


--
-- Name: ix_786d171a; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_786d171a ON subscription USING btree (companyid, classnameid, classpk);


--
-- Name: ix_79d0120b; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_79d0120b ON mbdiscussion USING btree (classnameid);


--
-- Name: ix_7a040c32; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_7a040c32 ON mbmessage USING btree (userid);


--
-- Name: ix_7a3619c6; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_7a3619c6 ON roles_permissions USING btree (permissionid);


--
-- Name: ix_7acc74c9; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_7acc74c9 ON journalcontentsearch USING btree (groupid, privatelayout, layoutid, portletid);


--
-- Name: ix_7b43cd8; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_7b43cd8 ON emailaddress USING btree (userid);


--
-- Name: ix_7b590a7a; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_7b590a7a ON group_ USING btree (type_, active_);


--
-- Name: ix_7bb1826b; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_7bb1826b ON assetcategory USING btree (parentcategoryid);


--
-- Name: ix_7c9e46ba; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_7c9e46ba ON assettag USING btree (groupid);


--
-- Name: ix_7cc7d73e; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_7cc7d73e ON journalcontentsearch USING btree (groupid, privatelayout, articleid);


--
-- Name: ix_7d81f66f; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_7d81f66f ON resourcetypepermission USING btree (companyid, name, roleid);


--
-- Name: ix_7dc16d26; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_7dc16d26 ON marketplace_module USING btree (appid);


--
-- Name: ix_7ef4ec0e; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_7ef4ec0e ON users_orgs USING btree (organizationid);


--
-- Name: ix_7f187e63; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_7f187e63 ON usergroups_teams USING btree (usergroupid);


--
-- Name: ix_7f26b2a6; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_7f26b2a6 ON mdrrulegroup USING btree (uuid_);


--
-- Name: ix_7f703619; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_7f703619 ON bookmarksfolder USING btree (groupid);


--
-- Name: ix_7ffae700; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_7ffae700 ON layoutrevision USING btree (layoutsetbranchid, status);


--
-- Name: ix_808a0036; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_808a0036 ON mdrrulegroupinstance USING btree (classnameid, classpk, rulegroupid);


--
-- Name: ix_80cc9508; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_80cc9508 ON portlet USING btree (companyid);


--
-- Name: ix_80f7a9c2; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_80f7a9c2 ON socialrequest USING btree (userid);


--
-- Name: ix_812ce07a; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_812ce07a ON phone USING btree (companyid, classnameid, classpk, primary_);


--
-- Name: ix_81776090; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_81776090 ON ddmstoragelink USING btree (structureid);


--
-- Name: ix_81a50303; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_81a50303 ON blogsentry USING btree (groupid);


--
-- Name: ix_81efbff5; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_81efbff5 ON expandorow USING btree (tableid, classpk);


--
-- Name: ix_81f2db09; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_81f2db09 ON resourceaction USING btree (name);


--
-- Name: ix_82254c25; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_82254c25 ON blogsstatsuser USING btree (groupid, userid);


--
-- Name: ix_82e39a0c; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_82e39a0c ON socialactivity USING btree (classnameid);


--
-- Name: ix_834bceb6; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_834bceb6 ON organization_ USING btree (companyid);


--
-- Name: ix_8373ec7c; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_8373ec7c ON dlfileentrytypes_ddmstructures USING btree (fileentrytypeid);


--
-- Name: ix_8377a211; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_8377a211 ON scproductversion USING btree (productentryid);


--
-- Name: ix_83e16f2f; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_83e16f2f ON socialactivityachievement USING btree (groupid, firstingroup);


--
-- Name: ix_84471fd2; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_84471fd2 ON groups_roles USING btree (groupid);


--
-- Name: ix_847f92b5; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_847f92b5 ON mbstatsuser USING btree (userid);


--
-- Name: ix_84ab0309; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_84ab0309 ON journalarticleresource USING btree (uuid_, groupid);


--
-- Name: ix_852ea801; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_852ea801 ON assetcategory USING btree (groupid, parentcategoryid, name, vocabularyid);


--
-- Name: ix_85c52eec; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_85c52eec ON journalarticle USING btree (groupid, articleid, version);


--
-- Name: ix_85c7ebe2; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_85c7ebe2 ON ddmstructure USING btree (uuid_, groupid);


--
-- Name: ix_8654719f; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_8654719f ON assetcategoryproperty USING btree (companyid);


--
-- Name: ix_865b7bd5; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_865b7bd5 ON marketplace_app USING btree (companyid);


--
-- Name: ix_871412df; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_871412df ON usergrouprole USING btree (groupid, roleid);


--
-- Name: ix_87603842; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_87603842 ON assetcategory USING btree (groupid, parentcategoryid, vocabularyid);


--
-- Name: ix_87a6b599; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_87a6b599 ON ddlrecord USING btree (recordsetid);


--
-- Name: ix_8831e4fc; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_8831e4fc ON journalstructure USING btree (structureid);


--
-- Name: ix_88328984; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_88328984 ON quartz_job_details USING btree (sched_name, job_group);


--
-- Name: ix_88705859; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_88705859 ON resourcepermission USING btree (companyid, name, primkey, ownerid);


--
-- Name: ix_887a2c95; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_887a2c95 ON usergrouprole USING btree (roleid);


--
-- Name: ix_887be56a; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_887be56a ON usergrouprole USING btree (userid);


--
-- Name: ix_88df994a; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_88df994a ON journalarticleresource USING btree (groupid, articleid);


--
-- Name: ix_89509087; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_89509087 ON user_ USING btree (companyid, openid);


--
-- Name: ix_899d3dfb; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_899d3dfb ON wikipage USING btree (uuid_, groupid);


--
-- Name: ix_8a1cc4b; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_8a1cc4b ON membershiprequest USING btree (groupid);


--
-- Name: ix_8aa50be1; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_8aa50be1 ON quartz_triggers USING btree (sched_name, job_group);


--
-- Name: ix_8abc4e3b; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_8abc4e3b ON mbban USING btree (groupid, banuserid);


--
-- Name: ix_8ae58a91; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_8ae58a91 ON users_permissions USING btree (permissionid);


--
-- Name: ix_8bc2f891; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_8bc2f891 ON ddlrecord USING btree (uuid_);


--
-- Name: ix_8bd6bca7; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_8bd6bca7 ON release_ USING btree (servletcontextname);


--
-- Name: ix_8cace77b; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_8cace77b ON blogsentry USING btree (companyid, userid);


--
-- Name: ix_8cb0a24a; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_8cb0a24a ON mbthreadflag USING btree (threadid);


--
-- Name: ix_8ce8c0d9; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_8ce8c0d9 ON layout USING btree (groupid, privatelayout, sourceprototypelayoutuuid);


--
-- Name: ix_8d12316e; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_8d12316e ON mbmessage USING btree (uuid_, groupid);


--
-- Name: ix_8d83d0ce; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_8d83d0ce ON resourcepermission USING btree (companyid, name, scope, primkey, roleid);


--
-- Name: ix_8db864a9; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_8db864a9 ON resourcepermission USING btree (companyid, primkey, roleid);


--
-- Name: ix_8deae14e; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_8deae14e ON journalarticle USING btree (groupid, templateid);


--
-- Name: ix_8e6da3a1; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_8e6da3a1 ON portletpreferences USING btree (portletid);


--
-- Name: ix_8e71167f; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_8e71167f ON portletitem USING btree (groupid, portletid, classnameid, name);


--
-- Name: ix_8e8710d9; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_8e8710d9 ON journalarticle USING btree (structureid);


--
-- Name: ix_8eb8c5ec; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_8eb8c5ec ON mbmessage USING btree (groupid, userid);


--
-- Name: ix_8ec3d2bc; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_8ec3d2bc ON layoutrevision USING btree (plid, status);


--
-- Name: ix_8f32dec9; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_8f32dec9 ON socialactivity USING btree (groupid, userid, createdate, classnameid, classpk, type_, receiveruserid);


--
-- Name: ix_8f542794; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_8f542794 ON assetlink USING btree (entryid1, entryid2, type_);


--
-- Name: ix_8f6408f0; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_8f6408f0 ON socialactivityachievement USING btree (groupid, name);


--
-- Name: ix_8f6c75d0; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_8f6c75d0 ON dlfileentry USING btree (folderid, name);


--
-- Name: ix_8ff5d6ea; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_8ff5d6ea ON layoutsetbranch USING btree (groupid);


--
-- Name: ix_9029e15a; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_9029e15a ON assetentry USING btree (visible);


--
-- Name: ix_902fd874; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_902fd874 ON dlfolder USING btree (groupid, parentfolderid, name);


--
-- Name: ix_903dc750; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_903dc750 ON shoppingitem USING btree (largeimageid);


--
-- Name: ix_90724726; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_90724726 ON dlfileentrytype USING btree (uuid_);


--
-- Name: ix_90cda39a; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_90cda39a ON blogsstatsuser USING btree (companyid, entrycount);


--
-- Name: ix_9106f6ce; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_9106f6ce ON journalarticle USING btree (templateid);


--
-- Name: ix_9112a7a0; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_9112a7a0 ON expandovalue USING btree (rowid_);


--
-- Name: ix_9168e2c9; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_9168e2c9 ON mbstatsuser USING btree (groupid, userid);


--
-- Name: ix_9178fc71; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_9178fc71 ON layoutsetprototype USING btree (companyid, active_);


--
-- Name: ix_91ca7cce; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_91ca7cce ON quartz_triggers USING btree (sched_name, trigger_group, next_fire_time, trigger_state, misfire_instr);


--
-- Name: ix_91e78c35; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_91e78c35 ON journalarticle USING btree (groupid, classnameid, structureid);


--
-- Name: ix_91f132c; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_91f132c ON assetlink USING btree (entryid2, type_);


--
-- Name: ix_9207cb31; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_9207cb31 ON journalcontentsearch USING btree (articleid);


--
-- Name: ix_920cd8b1; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_920cd8b1 ON wikinode USING btree (groupid, name);


--
-- Name: ix_9226dbb4; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_9226dbb4 ON address USING btree (companyid, classnameid, classpk, primary_);


--
-- Name: ix_923bd178; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_923bd178 ON address USING btree (companyid, classnameid, classpk, mailing);


--
-- Name: ix_926cdd04; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_926cdd04 ON socialactivitycounter USING btree (groupid, classnameid, classpk, ownertype);


--
-- Name: ix_9329c9d6; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_9329c9d6 ON layoutrevision USING btree (plid);


--
-- Name: ix_9356f865; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_9356f865 ON journalarticle USING btree (groupid);


--
-- Name: ix_93cf8193; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_93cf8193 ON dlfileentry USING btree (groupid, folderid);


--
-- Name: ix_93d5ad4e; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_93d5ad4e ON address USING btree (companyid);


--
-- Name: ix_941ba8c3; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_941ba8c3 ON shard USING btree (name);


--
-- Name: ix_941e429c; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_941e429c ON wikipage USING btree (groupid, nodeid, status);


--
-- Name: ix_9464ca; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_9464ca ON assettagstats USING btree (tagid);


--
-- Name: ix_94d1054d; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_94d1054d ON wikipage USING btree (resourceprimkey, nodeid, status);


--
-- Name: ix_95135d1c; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_95135d1c ON socialrelation USING btree (companyid, type_);


--
-- Name: ix_95c0ea45; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_95c0ea45 ON mbthread USING btree (groupid);


--
-- Name: ix_967799c0; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_967799c0 ON bookmarksfolder USING btree (groupid, parentfolderid);


--
-- Name: ix_96bdd537; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_96bdd537 ON portletitem USING btree (groupid, classnameid);


--
-- Name: ix_96f07007; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_96f07007 ON website USING btree (companyid);


--
-- Name: ix_9782ad88; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_9782ad88 ON user_ USING btree (companyid, userid);


--
-- Name: ix_97dfa146; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_97dfa146 ON webdavprops USING btree (classnameid, classpk);


--
-- Name: ix_98e6a9cb; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_98e6a9cb ON scproductentry USING btree (groupid, userid);


--
-- Name: ix_99108b6e; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_99108b6e ON quartz_triggers USING btree (sched_name, trigger_state);


--
-- Name: ix_997eedd2; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_997eedd2 ON wikipage USING btree (nodeid, title);


--
-- Name: ix_99da856; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_99da856 ON assetcategoryproperty USING btree (categoryid);


--
-- Name: ix_9a2d11b2; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_9a2d11b2 ON mbthread USING btree (groupid, categoryid);


--
-- Name: ix_9a53569; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_9a53569 ON phone USING btree (companyid, classnameid, classpk);


--
-- Name: ix_9bdcf489; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_9bdcf489 ON repositoryentry USING btree (repositoryid, mappedid);


--
-- Name: ix_9be769ed; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_9be769ed ON dlfileversion USING btree (groupid, folderid, title, version);


--
-- Name: ix_9c0e478f; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_9c0e478f ON wikipage USING btree (uuid_);


--
-- Name: ix_9c7eb9f; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_9c7eb9f ON announcementsflag USING btree (entryid);


--
-- Name: ix_9cbc6a39; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_9cbc6a39 ON mdrrulegroupinstance USING btree (uuid_, groupid);


--
-- Name: ix_9ce6e0fa; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_9ce6e0fa ON journalarticle USING btree (groupid, classnameid, classpk);


--
-- Name: ix_9d7c3b23; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_9d7c3b23 ON mbmessage USING btree (threadid, answer);


--
-- Name: ix_9dc8e57; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_9dc8e57 ON mbmessage USING btree (threadid, status);


--
-- Name: ix_9ddd15ea; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_9ddd15ea ON assetcategory USING btree (parentcategoryid, name);


--
-- Name: ix_9ddd21e5; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_9ddd21e5 ON expandovalue USING btree (columnid, rowid_);


--
-- Name: ix_9f704a14; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_9f704a14 ON phone USING btree (companyid);


--
-- Name: ix_9f7655da; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_9f7655da ON wikipage USING btree (nodeid, head, parenttitle, status);


--
-- Name: ix_9ff342ea; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_9ff342ea ON pollsquestion USING btree (groupid);


--
-- Name: ix_a00a898f; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_a00a898f ON mbstatsuser USING btree (groupid);


--
-- Name: ix_a083d394; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_a083d394 ON virtualhost USING btree (companyid, layoutsetid);


--
-- Name: ix_a098efbf; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_a098efbf ON users_teams USING btree (userid);


--
-- Name: ix_a18034a4; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_a18034a4 ON user_ USING btree (portraitid);


--
-- Name: ix_a188f560; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_a188f560 ON assetentries_assetcategories USING btree (categoryid);


--
-- Name: ix_a1a8cb8b; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_a1a8cb8b ON ratingsentry USING btree (classnameid, classpk, score);


--
-- Name: ix_a2001730; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_a2001730 ON wikipage USING btree (format);


--
-- Name: ix_a2534ac2; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_a2534ac2 ON journalarticle USING btree (groupid, classnameid, layoutuuid);


--
-- Name: ix_a2635f5c; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_a2635f5c ON region USING btree (countryid, regioncode);


--
-- Name: ix_a28004b; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_a28004b ON mbthreadflag USING btree (userid);


--
-- Name: ix_a2e4afba; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_a2e4afba ON phone USING btree (companyid, classnameid);


--
-- Name: ix_a32c097e; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_a32c097e ON resourcecode USING btree (companyid, name, scope);


--
-- Name: ix_a37a0588; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_a37a0588 ON resourcepermission USING btree (roleid);


--
-- Name: ix_a40b8bec; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_a40b8bec ON layoutset USING btree (groupid);


--
-- Name: ix_a425f71a; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_a425f71a ON orggrouppermission USING btree (groupid);


--
-- Name: ix_a44636c9; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_a44636c9 ON dlfileentrymetadata USING btree (fileentryid, fileversionid);


--
-- Name: ix_a4b9a23b; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_a4b9a23b ON socialactivitycounter USING btree (classnameid, classpk);


--
-- Name: ix_a4db1f0f; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_a4db1f0f ON workflowdefinitionlink USING btree (companyid, workflowdefinitionname, workflowdefinitionversion);


--
-- Name: ix_a5f57b61; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_a5f57b61 ON blogsentry USING btree (companyid, userid, status);


--
-- Name: ix_a65a1f8b; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_a65a1f8b ON dlfilerank USING btree (fileentryid);


--
-- Name: ix_a6e99284; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_a6e99284 ON ratingsstats USING btree (classnameid, classpk);


--
-- Name: ix_a6ef0b81; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_a6ef0b81 ON announcementsentry USING btree (classnameid, classpk);


--
-- Name: ix_a7038cd7; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_a7038cd7 ON mbmessage USING btree (threadid, parentmessageid);


--
-- Name: ix_a705ff94; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_a705ff94 ON layoutbranch USING btree (layoutsetbranchid, plid, master);


--
-- Name: ix_a74db14c; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_a74db14c ON dlfolder USING btree (companyid);


--
-- Name: ix_a7efd80e; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_a7efd80e ON marketplace_module USING btree (uuid_);


--
-- Name: ix_a82690e2; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_a82690e2 ON resourcetypepermission USING btree (roleid);


--
-- Name: ix_a853c757; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_a853c757 ON socialactivity USING btree (classnameid, classpk);


--
-- Name: ix_a85822a0; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_a85822a0 ON quartz_triggers USING btree (sched_name, job_name, job_group);


--
-- Name: ix_a88e424e; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_a88e424e ON role_ USING btree (companyid, classnameid, classpk);


--
-- Name: ix_a8b0d276; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_a8b0d276 ON workflowdefinitionlink USING btree (companyid);


--
-- Name: ix_a8c0cbe8; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_a8c0cbe8 ON expandocolumn USING btree (tableid);


--
-- Name: ix_a90fe5a0; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_a90fe5a0 ON socialrequest USING btree (companyid);


--
-- Name: ix_a9ac086e; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_a9ac086e ON layoutrevision USING btree (layoutsetbranchid, head);


--
-- Name: ix_aabc18e9; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_aabc18e9 ON socialactivityachievement USING btree (groupid, userid, firstingroup);


--
-- Name: ix_aac564d3; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_aac564d3 ON ddlrecord USING btree (recordsetid, userid);


--
-- Name: ix_aacaff40; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_aacaff40 ON resourcecode USING btree (name);


--
-- Name: ix_ab044d1c; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_ab044d1c ON orggrouprole USING btree (roleid);


--
-- Name: ix_ab5906a8; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_ab5906a8 ON socialrequest USING btree (userid, status);


--
-- Name: ix_ab6e9996; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_ab6e9996 ON journalstructure USING btree (groupid, structureid);


--
-- Name: ix_aba5cec2; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_aba5cec2 ON group_ USING btree (companyid);


--
-- Name: ix_abd7dac0; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_abd7dac0 ON address USING btree (companyid, classnameid);


--
-- Name: ix_abeb6d07; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_abeb6d07 ON mbmessage USING btree (userid, classnameid, classpk);


--
-- Name: ix_ae4b50c2; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_ae4b50c2 ON ddmcontent USING btree (uuid_);


--
-- Name: ix_ae6e9907; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_ae6e9907 ON team USING btree (groupid);


--
-- Name: ix_ae8224cc; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_ae8224cc ON scproductscreenshot USING btree (fullimageid);


--
-- Name: ix_aedd9cb5; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_aedd9cb5 ON mbthread USING btree (lastpostdate, priority);


--
-- Name: ix_aeea209c; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_aeea209c ON resourceblock USING btree (companyid, groupid, name, permissionshash);


--
-- Name: ix_aff28547; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_aff28547 ON mdrrulegroupinstance USING btree (groupid);


--
-- Name: ix_b0051937; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_b0051937 ON dlfileshortcut USING btree (groupid, folderid);


--
-- Name: ix_b1432d30; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_b1432d30 ON mbmessage USING btree (companyid);


--
-- Name: ix_b15863fa; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_b15863fa ON socialactivitylimit USING btree (classnameid, classpk);


--
-- Name: ix_b185e980; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_b185e980 ON assetcategory USING btree (parentcategoryid, vocabularyid);


--
-- Name: ix_b22d908c; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_b22d908c ON assetvocabulary USING btree (companyid);


--
-- Name: ix_b2468446; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_b2468446 ON ticket USING btree (key_);


--
-- Name: ix_b27a301f; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_b27a301f ON classname_ USING btree (value);


--
-- Name: ix_b29fef17; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_b29fef17 ON expandovalue USING btree (classnameid, classpk);


--
-- Name: ix_b2a61b55; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_b2a61b55 ON assetentries_assettags USING btree (tagid);


--
-- Name: ix_b3b318dc; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_b3b318dc ON journalcontentsearch USING btree (groupid, privatelayout, layoutid);


--
-- Name: ix_b4328f39; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_b4328f39 ON ddlrecord USING btree (uuid_, groupid);


--
-- Name: ix_b47e3c11; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_b47e3c11 ON ratingsentry USING btree (userid, classnameid, classpk);


--
-- Name: ix_b480a672; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_b480a672 ON wikinode USING btree (groupid);


--
-- Name: ix_b529bfd3; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_b529bfd3 ON layout USING btree (layoutprototypeuuid);


--
-- Name: ix_b53ec783; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_b53ec783 ON dlsync USING btree (companyid, modifieddate, repositoryid);


--
-- Name: ix_b5ae8a85; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_b5ae8a85 ON expandotable USING btree (companyid, classnameid);


--
-- Name: ix_b5c9c690; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_b5c9c690 ON socialrelation USING btree (userid1, userid2);


--
-- Name: ix_b5ca2dc; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_b5ca2dc ON mbdiscussion USING btree (threadid);


--
-- Name: ix_b5f82c7a; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_b5f82c7a ON shoppingorderitem USING btree (orderid);


--
-- Name: ix_b670ba39; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_b670ba39 ON bookmarksentry USING btree (uuid_);


--
-- Name: ix_b674ab58; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_b674ab58 ON mbmessage USING btree (groupid, categoryid, threadid);


--
-- Name: ix_b6a6bd91; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_b6a6bd91 ON mdrrulegroupinstance USING btree (uuid_);


--
-- Name: ix_b6b8ca0e; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_b6b8ca0e ON assetvocabulary USING btree (groupid);


--
-- Name: ix_b6ee8c9e; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_b6ee8c9e ON workflowdefinitionlink USING btree (groupid, companyid, classnameid);


--
-- Name: ix_b7034b27; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_b7034b27 ON repositoryentry USING btree (repositoryid);


--
-- Name: ix_b71e92d5; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_b71e92d5 ON expandovalue USING btree (tableid, rowid_);


--
-- Name: ix_b771d67; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_b771d67 ON wikipage USING btree (resourceprimkey, nodeid);


--
-- Name: ix_b7b914e5; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_b7b914e5 ON layoutrevision USING btree (layoutsetbranchid, plid);


--
-- Name: ix_b9746445; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_b9746445 ON pluginsetting USING btree (companyid);


--
-- Name: ix_b97f5608; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_b97f5608 ON journalstructure USING btree (groupid);


--
-- Name: ix_b9b1506; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_b9b1506 ON repositoryentry USING btree (uuid_);


--
-- Name: ix_ba4413d5; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_ba4413d5 ON announcementsdelivery USING btree (userid, type_);


--
-- Name: ix_ba497163; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_ba497163 ON resourcetypepermission USING btree (companyid, groupid, name, roleid);


--
-- Name: ix_ba72b89a; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_ba72b89a ON wikipage USING btree (groupid, nodeid, head, parenttitle, status);


--
-- Name: ix_bafb116e; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_bafb116e ON dlfilerank USING btree (groupid, userid);


--
-- Name: ix_bb0c2905; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_bb0c2905 ON blogsentry USING btree (companyid, displaydate, status);


--
-- Name: ix_bb51f1d9; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_bb51f1d9 ON blogsstatsuser USING btree (userid);


--
-- Name: ix_bb870c11; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_bb870c11 ON mbcategory USING btree (groupid);


--
-- Name: ix_bbca55b; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_bbca55b ON group_ USING btree (companyid, livegroupid, name);


--
-- Name: ix_bc2c4231; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_bc2c4231 ON layout USING btree (groupid, privatelayout, friendlyurl);


--
-- Name: ix_bc2e7e6a; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_bc2e7e6a ON dlfileentry USING btree (uuid_, groupid);


--
-- Name: ix_bc2f03b0; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_bc2f03b0 ON quartz_fired_triggers USING btree (sched_name, job_group);


--
-- Name: ix_bc735dcf; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_bc735dcf ON mbcategory USING btree (companyid);


--
-- Name: ix_bcfda257; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_bcfda257 ON user_ USING btree (companyid, createdate, modifieddate);


--
-- Name: ix_be3835e5; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_be3835e5 ON quartz_fired_triggers USING btree (sched_name, trigger_name, trigger_group);


--
-- Name: ix_be4df2bf; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_be4df2bf ON assetcategory USING btree (parentcategoryid, name, vocabularyid);


--
-- Name: ix_be8102d6; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_be8102d6 ON users_usergroups USING btree (userid);


--
-- Name: ix_be898221; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_be898221 ON wikipageresource USING btree (uuid_);


--
-- Name: ix_bea33ab8; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_bea33ab8 ON wikipage USING btree (nodeid, title, status);


--
-- Name: ix_bf3e642b; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_bf3e642b ON mdrrulegroupinstance USING btree (rulegroupid);


--
-- Name: ix_bfeb984f; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_bfeb984f ON mbmailinglist USING btree (active_);


--
-- Name: ix_c099d61a; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_c099d61a ON layout USING btree (groupid);


--
-- Name: ix_c0aad74d; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_c0aad74d ON assetvocabulary USING btree (groupid, name);


--
-- Name: ix_c19e5f31; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_c19e5f31 ON users_roles USING btree (roleid);


--
-- Name: ix_c1a01806; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_c1a01806 ON users_roles USING btree (userid);


--
-- Name: ix_c1ad2122; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_c1ad2122 ON calevent USING btree (uuid_);


--
-- Name: ix_c2626edb; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_c2626edb ON mbcategory USING btree (uuid_);


--
-- Name: ix_c26aa64d; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_c26aa64d ON users_permissions USING btree (userid);


--
-- Name: ix_c28b41dc; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_c28b41dc ON shoppingcart USING btree (groupid);


--
-- Name: ix_c28c72ec; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_c28c72ec ON membershiprequest USING btree (groupid, statusid);


--
-- Name: ix_c31a64c6; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_c31a64c6 ON socialrelation USING btree (type_);


--
-- Name: ix_c3a17327; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_c3a17327 ON passwordpolicyrel USING btree (classnameid, classpk);


--
-- Name: ix_c3aa93b8; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_c3aa93b8 ON journalcontentsearch USING btree (groupid, privatelayout, layoutid, portletid, articleid);


--
-- Name: ix_c4079fd3; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_c4079fd3 ON layoutsetbranch USING btree (groupid, privatelayout);


--
-- Name: ix_c48736b; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_c48736b ON groups_permissions USING btree (groupid);


--
-- Name: ix_c4f283c8; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_c4f283c8 ON ddmtemplate USING btree (type_);


--
-- Name: ix_c4f9e699; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_c4f9e699 ON users_groups USING btree (groupid);


--
-- Name: ix_c57b16bc; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_c57b16bc ON mbmessage USING btree (uuid_);


--
-- Name: ix_c5806019; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_c5806019 ON user_ USING btree (companyid, screenname);


--
-- Name: ix_c5d69b24; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_c5d69b24 ON layoutsetprototype USING btree (uuid_);


--
-- Name: ix_c68dc967; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_c68dc967 ON dlfileversion USING btree (fileentryid);


--
-- Name: ix_c6938724; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_c6938724 ON marketplace_module USING btree (appid, contextname);


--
-- Name: ix_c7057ff7; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_c7057ff7 ON portletpreferences USING btree (ownerid, ownertype, plid, portletid);


--
-- Name: ix_c79e347; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_c79e347 ON ddlrecordversion USING btree (recordid, version);


--
-- Name: ix_c7f39fca; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_c7f39fca ON assetcategory USING btree (groupid, name, vocabularyid);


--
-- Name: ix_c7fbc998; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_c7fbc998 ON layout USING btree (companyid);


--
-- Name: ix_c803899d; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_c803899d ON ddmstructurelink USING btree (classpk);


--
-- Name: ix_c8419fbe; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_c8419fbe ON ddmstructure USING btree (groupid);


--
-- Name: ix_c8a9c476; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_c8a9c476 ON wikipage USING btree (nodeid);


--
-- Name: ix_c8fd892b; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_c8fd892b ON socialactivityachievement USING btree (groupid, userid);


--
-- Name: ix_c94c7708; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_c94c7708 ON resourcepermission USING btree (companyid, name, primkey, roleid, actionids);


--
-- Name: ix_c95a08d8; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_c95a08d8 ON mdrrulegroupinstance USING btree (classnameid, classpk);


--
-- Name: ix_c9757a51; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_c9757a51 ON ddmtemplate USING btree (structureid);


--
-- Name: ix_c98c0d78; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_c98c0d78 ON scframeworkversion USING btree (companyid);


--
-- Name: ix_c99b2650; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_c99b2650 ON dlfileversion USING btree (uuid_, groupid);


--
-- Name: ix_ca0bd48c; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_ca0bd48c ON journalstructure USING btree (groupid, parentstructureid);


--
-- Name: ix_ca9afb7c; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_ca9afb7c ON expandovalue USING btree (tableid, columnid);


--
-- Name: ix_caa451d6; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_caa451d6 ON wikipage USING btree (groupid, userid, nodeid, status);


--
-- Name: ix_cab0ccc8; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_cab0ccc8 ON usergroupgrouprole USING btree (groupid, roleid);


--
-- Name: ix_cbc408d8; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_cbc408d8 ON dlfolder USING btree (uuid_);


--
-- Name: ix_cbe204; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_cbe204 ON role_ USING btree (type_, subtype);


--
-- Name: ix_cbfdbf0a; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_cbfdbf0a ON mbmessage USING btree (groupid, categoryid, threadid, answer);


--
-- Name: ix_cc86a444; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_cc86a444 ON socialrequest USING btree (userid, classnameid, classpk, type_, status);


--
-- Name: ix_cc993ecb; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_cc993ecb ON mbthread USING btree (rootmessageid);


--
-- Name: ix_ccbe4063; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_ccbe4063 ON usergroupgrouprole USING btree (groupid);


--
-- Name: ix_ccf0da29; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_ccf0da29 ON layoutsetbranch USING btree (groupid, privatelayout, master);


--
-- Name: ix_cd25266e; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_cd25266e ON passwordpolicyrel USING btree (passwordpolicyid);


--
-- Name: ix_cd7132d0; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_cd7132d0 ON quartz_triggers USING btree (sched_name, calendar_name);


--
-- Name: ix_cef72136; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_cef72136 ON layoutprototype USING btree (uuid_);


--
-- Name: ix_d0822724; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_d0822724 ON layout USING btree (uuid_);


--
-- Name: ix_d0d5e397; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_d0d5e397 ON group_ USING btree (companyid, classnameid, classpk);


--
-- Name: ix_d1c44a6e; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_d1c44a6e ON useridmapper USING btree (userid, type_);


--
-- Name: ix_d1f795f1; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_d1f795f1 ON portalpreferences USING btree (ownerid, ownertype);


--
-- Name: ix_d20c434d; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_d20c434d ON dlfileentry USING btree (groupid, userid, folderid);


--
-- Name: ix_d217ab30; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_d217ab30 ON shoppingitem USING btree (mediumimageid);


--
-- Name: ix_d219afde; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_d219afde ON quartz_triggers USING btree (sched_name, trigger_group, trigger_state);


--
-- Name: ix_d27b03e7; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_d27b03e7 ON expandovalue USING btree (tableid, columnid, classpk);


--
-- Name: ix_d2d249e8; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_d2d249e8 ON journalarticle USING btree (groupid, urltitle, status);


--
-- Name: ix_d2e2b644; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_d2e2b644 ON resourcepermission USING btree (companyid, name, scope, primkey, roleid, actionids);


--
-- Name: ix_d33a5445; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_d33a5445 ON mbstatsuser USING btree (groupid, userid, messagecount);


--
-- Name: ix_d340db76; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_d340db76 ON portletpreferences USING btree (plid, portletid);


--
-- Name: ix_d3425487; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_d3425487 ON socialrequest USING btree (classnameid, classpk, type_, receiveruserid, status);


--
-- Name: ix_d3f5d7ae; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_d3f5d7ae ON expandorow USING btree (tableid);


--
-- Name: ix_d4121315; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_d4121315 ON journalarticleimage USING btree (tempimage);


--
-- Name: ix_d4390caa; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_d4390caa ON socialactivityachievement USING btree (groupid, userid, name);


--
-- Name: ix_d43e4208; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_d43e4208 ON ddmstructurelink USING btree (classnameid);


--
-- Name: ix_d47bb14d; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_d47bb14d ON dlfileversion USING btree (fileentryid, status);


--
-- Name: ix_d49ab5d1; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_d49ab5d1 ON dlfileentrymetadata USING btree (uuid_);


--
-- Name: ix_d49c2e66; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_d49c2e66 ON announcementsentry USING btree (userid);


--
-- Name: ix_d5df7b54; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_d5df7b54 ON pollsvote USING btree (choiceid);


--
-- Name: ix_d5eda3a1; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_d5eda3a1 ON portletpreferences USING btree (ownertype, plid, portletid);


--
-- Name: ix_d61abe08; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_d61abe08 ON assetcategory USING btree (name, vocabularyid);


--
-- Name: ix_d63322f9; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_d63322f9 ON assettag USING btree (groupid, name);


--
-- Name: ix_d63d20bb; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_d63d20bb ON resourceblockpermission USING btree (resourceblockid, roleid);


--
-- Name: ix_d699243f; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_d699243f ON portletitem USING btree (groupid, name, portletid, classnameid);


--
-- Name: ix_d6fd9496; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_d6fd9496 ON calevent USING btree (companyid);


--
-- Name: ix_d76dd2cf; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_d76dd2cf ON pollschoice USING btree (questionid, name);


--
-- Name: ix_d7710a66; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_d7710a66 ON sclicenses_scproductentries USING btree (productentryid);


--
-- Name: ix_d7d6e87a; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_d7d6e87a ON shoppingorder USING btree (number_);


--
-- Name: ix_d9380cb7; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_d9380cb7 ON socialrequest USING btree (receiveruserid, status);


--
-- Name: ix_d9492cf6; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_d9492cf6 ON dlfileentry USING btree (mimetype);


--
-- Name: ix_d984aaba; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_d984aaba ON socialactivitysetting USING btree (groupid, classnameid, activitytype, name);


--
-- Name: ix_da04f689; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_da04f689 ON blogsentry USING btree (groupid, userid, displaydate, status);


--
-- Name: ix_da30b086; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_da30b086 ON resourceblock USING btree (companyid, groupid, name);


--
-- Name: ix_da5f4359; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_da5f4359 ON shard USING btree (classnameid, classpk);


--
-- Name: ix_da913a55; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_da913a55 ON scproductscreenshot USING btree (productentryid, priority);


--
-- Name: ix_db24dddd; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_db24dddd ON ddmtemplate USING btree (groupid);


--
-- Name: ix_db780a20; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_db780a20 ON blogsentry USING btree (groupid, urltitle);


--
-- Name: ix_dbd111aa; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_dbd111aa ON assetcategoryproperty USING btree (categoryid, key_);


--
-- Name: ix_dc2f8927; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_dc2f8927 ON bookmarksfolder USING btree (uuid_, groupid);


--
-- Name: ix_dc60cfae; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_dc60cfae ON shoppingcoupon USING btree (code_);


--
-- Name: ix_dcd1fac1; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_dcd1fac1 ON journalarticleresource USING btree (uuid_);


--
-- Name: ix_dcded558; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_dcded558 ON usergroupgrouprole USING btree (usergroupid);


--
-- Name: ix_dd635956; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_dd635956 ON lock_ USING btree (classname, key_, owner);


--
-- Name: ix_dfd809d3; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_dfd809d3 ON dlfileversion USING btree (groupid, folderid, status);


--
-- Name: ix_dff1f063; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_dff1f063 ON assettagproperty USING btree (companyid);


--
-- Name: ix_dff98523; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_dff98523 ON journalarticle USING btree (companyid);


--
-- Name: ix_e0092ff0; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_e0092ff0 ON wikipage USING btree (groupid, nodeid, head, status);


--
-- Name: ix_e0422bda; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_e0422bda ON user_ USING btree (uuid_);


--
-- Name: ix_e04e486d; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_e04e486d ON roles_permissions USING btree (roleid);


--
-- Name: ix_e10ac39; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_e10ac39 ON layoutrevision USING btree (layoutsetbranchid, head, plid);


--
-- Name: ix_e118c537; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_e118c537 ON layout USING btree (uuid_, groupid, privatelayout);


--
-- Name: ix_e119938a; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_e119938a ON assetentries_assetcategories USING btree (entryid);


--
-- Name: ix_e14b1f1; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_e14b1f1 ON socialactivityachievement USING btree (groupid);


--
-- Name: ix_e1e7142b; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_e1e7142b ON mbthread USING btree (groupid, status);


--
-- Name: ix_e2815081; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_e2815081 ON dlfileversion USING btree (fileentryid, version);


--
-- Name: ix_e2e9f129; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_e2e9f129 ON bookmarksentry USING btree (groupid, userid);


--
-- Name: ix_e301bdf5; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_e301bdf5 ON organization_ USING btree (companyid, name);


--
-- Name: ix_e3baf436; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_e3baf436 ON ddmcontent USING btree (companyid);


--
-- Name: ix_e3f1286b; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_e3f1286b ON lock_ USING btree (expirationdate);


--
-- Name: ix_e4efba8d; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_e4efba8d ON usertracker USING btree (userid);


--
-- Name: ix_e4f13e6e; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_e4f13e6e ON portletpreferences USING btree (ownerid, ownertype, plid);


--
-- Name: ix_e52ff7ef; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_e52ff7ef ON bookmarksentry USING btree (groupid);


--
-- Name: ix_e60ea987; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_e60ea987 ON useridmapper USING btree (userid);


--
-- Name: ix_e61809c8; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_e61809c8 ON ddmstructure USING btree (uuid_);


--
-- Name: ix_e639e2f6; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_e639e2f6 ON assetcategory USING btree (groupid);


--
-- Name: ix_e745ea26; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_e745ea26 ON wikipage USING btree (nodeid, title, head);


--
-- Name: ix_e7b95510; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_e7b95510 ON browsertracker USING btree (userid);


--
-- Name: ix_e7f635ca; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_e7f635ca ON wikipage USING btree (nodeid, head);


--
-- Name: ix_e802aa3c; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_e802aa3c ON journaltemplate USING btree (groupid, templateid);


--
-- Name: ix_e82f322b; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_e82f322b ON journalarticle USING btree (companyid, version, status);


--
-- Name: ix_e848278f; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_e848278f ON bookmarksentry USING btree (resourceblockid);


--
-- Name: ix_e858f170; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_e858f170 ON mbmailinglist USING btree (uuid_, groupid);


--
-- Name: ix_e8d019aa; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_e8d019aa ON assetcategory USING btree (uuid_, groupid);


--
-- Name: ix_e8d33ff9; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_e8d33ff9 ON scframeworkversi_scproductvers USING btree (productversionid);


--
-- Name: ix_e8f34171; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_e8f34171 ON subscription USING btree (userid, classnameid);


--
-- Name: ix_e922d6c0; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_e922d6c0 ON portletitem USING btree (groupid, portletid, classnameid);


--
-- Name: ix_e9b6a85b; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_e9b6a85b ON dlfileentrytype USING btree (groupid, name);


--
-- Name: ix_ea63b9d7; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_ea63b9d7 ON mdrrule USING btree (uuid_);


--
-- Name: ix_ea6fd516; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_ea6fd516 ON shoppingitemprice USING btree (itemid);


--
-- Name: ix_eaa02a91; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_eaa02a91 ON bookmarksentry USING btree (uuid_, groupid);


--
-- Name: ix_eb2dce27; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_eb2dce27 ON blogsentry USING btree (companyid, status);


--
-- Name: ix_eb531760; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_eb531760 ON dlcontent USING btree (companyid, repositoryid, path_);


--
-- Name: ix_eb9bde28; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_eb9bde28 ON ddmcontent USING btree (uuid_, groupid);


--
-- Name: ix_ebc931b8; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_ebc931b8 ON role_ USING btree (companyid, name);


--
-- Name: ix_ec00543c; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_ec00543c ON company USING btree (webid);


--
-- Name: ix_ec370f10; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_ec370f10 ON pollschoice USING btree (questionid);


--
-- Name: ix_ec97689d; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_ec97689d ON groups_permissions USING btree (permissionid);


--
-- Name: ix_ecce311d; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_ecce311d ON dlfileshortcut USING btree (groupid, folderid, status);


--
-- Name: ix_ecd8cfea; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_ecd8cfea ON usernotificationevent USING btree (uuid_);


--
-- Name: ix_ed292508; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_ed292508 ON mbcategory USING btree (groupid, parentcategoryid);


--
-- Name: ix_ed39ac98; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_ed39ac98 ON mbmessage USING btree (groupid, status);


--
-- Name: ix_ed5ca615; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_ed5ca615 ON dlfileentry USING btree (groupid, folderid, title);


--
-- Name: ix_ed7cf243; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_ed7cf243 ON passwordpolicyrel USING btree (passwordpolicyid, classnameid, classpk);


--
-- Name: ix_edb9986e; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_edb9986e ON resourceaction USING btree (name, actionid);


--
-- Name: ix_ee29c715; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_ee29c715 ON dlfolder USING btree (repositoryid);


--
-- Name: ix_ee8abd19; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_ee8abd19 ON user_ USING btree (companyid, modifieddate);


--
-- Name: ix_eed06670; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_eed06670 ON dlfilerank USING btree (userid);


--
-- Name: ix_eefe382a; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_eefe382a ON quartz_triggers USING btree (sched_name, next_fire_time);


--
-- Name: ix_ef9b7028; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_ef9b7028 ON journalarticle USING btree (smallimageid);


--
-- Name: ix_f026cf4c; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_f026cf4c ON quartz_triggers USING btree (sched_name, next_fire_time, trigger_state);


--
-- Name: ix_f029602f; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_f029602f ON journalarticle USING btree (uuid_);


--
-- Name: ix_f0566a77; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_f0566a77 ON expandovalue USING btree (tableid);


--
-- Name: ix_f090c113; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_f090c113 ON permission_ USING btree (resourceid);


--
-- Name: ix_f0a26b29; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_f0a26b29 ON journalarticle USING btree (groupid, version, status);


--
-- Name: ix_f0ca24a5; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_f0ca24a5 ON socialrelation USING btree (uuid_);


--
-- Name: ix_f0e73383; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_f0e73383 ON blogsentry USING btree (groupid, displaydate, status);


--
-- Name: ix_f10b6c6b; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_f10b6c6b ON users_groups USING btree (userid);


--
-- Name: ix_f147cf3f; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_f147cf3f ON dlfileentrytypes_ddmstructures USING btree (structureid);


--
-- Name: ix_f15c1c4f; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_f15c1c4f ON portletpreferences USING btree (plid);


--
-- Name: ix_f1c1a617; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_f1c1a617 ON socialactivitylimit USING btree (groupid, userid, classnameid, classpk, activitytype, activitycountername);


--
-- Name: ix_f202b9ce; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_f202b9ce ON phone USING btree (userid);


--
-- Name: ix_f2a243a7; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_f2a243a7 ON ddmtemplate USING btree (uuid_);


--
-- Name: ix_f2dd7c7e; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_f2dd7c7e ON quartz_triggers USING btree (sched_name, next_fire_time, trigger_state, misfire_instr);


--
-- Name: ix_f2ea1ace; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_f2ea1ace ON dlfolder USING btree (groupid);


--
-- Name: ix_f2f1e964; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_f2f1e964 ON marketplace_module USING btree (contextname);


--
-- Name: ix_f3c9f36; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_f3c9f36 ON pollsquestion USING btree (uuid_, groupid);


--
-- Name: ix_f3efdcb3; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_f3efdcb3 ON mdrrule USING btree (uuid_, groupid);


--
-- Name: ix_f436ec8e; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_f436ec8e ON role_ USING btree (name);


--
-- Name: ix_f43b9ff2; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_f43b9ff2 ON journalarticle USING btree (groupid, classnameid, templateid);


--
-- Name: ix_f4555981; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_f4555981 ON resourcepermission USING btree (scope);


--
-- Name: ix_f474fd89; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_f474fd89 ON shoppingorder USING btree (pptxnid);


--
-- Name: ix_f4af5636; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_f4af5636 ON dlfileentry USING btree (groupid);


--
-- Name: ix_f6006202; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_f6006202 ON calevent USING btree (remindby);


--
-- Name: ix_f6039434; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_f6039434 ON user_ USING btree (companyid, status);


--
-- Name: ix_f6687633; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_f6687633 ON mbmessage USING btree (classnameid, classpk, status);


--
-- Name: ix_f75690bb; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_f75690bb ON website USING btree (userid);


--
-- Name: ix_f7d28c2f; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_f7d28c2f ON mbcategory USING btree (uuid_, groupid);


--
-- Name: ix_f7dd0987; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_f7dd0987 ON expandovalue USING btree (columnid);


--
-- Name: ix_f8433677; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_f8433677 ON journalarticleresource USING btree (groupid);


--
-- Name: ix_f8e90438; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_f8e90438 ON dlfileentrymetadata USING btree (fileentrytypeid);


--
-- Name: ix_f960131c; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_f960131c ON website USING btree (companyid, classnameid, classpk);


--
-- Name: ix_f9821ab4; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_f9821ab4 ON dlsync USING btree (fileid);


--
-- Name: ix_fb604dc7; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_fb604dc7 ON socialactivity USING btree (groupid, userid, classnameid, classpk, type_, receiveruserid);


--
-- Name: ix_fb646ca6; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_fb646ca6 ON users_orgs USING btree (userid);


--
-- Name: ix_fbbe7c96; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_fbbe7c96 ON wikipage USING btree (userid, nodeid, status);


--
-- Name: ix_fbde0aa3; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_fbde0aa3 ON blogsentry USING btree (groupid, userid, displaydate);


--
-- Name: ix_fc1f9c7b; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_fc1f9c7b ON assetentry USING btree (classuuid);


--
-- Name: ix_fc46fe16; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_fc46fe16 ON shoppingcart USING btree (groupid, userid);


--
-- Name: ix_fcd7c63d; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_fcd7c63d ON calevent USING btree (groupid, type_);


--
-- Name: ix_fd57097d; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_fd57097d ON layoutbranch USING btree (layoutsetbranchid, plid, name);


--
-- Name: ix_fd90786c; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_fd90786c ON mdraction USING btree (rulegroupinstanceid);


--
-- Name: ix_fd93cbfa; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_fd93cbfa ON calevent USING btree (groupid, type_, repeating);


--
-- Name: ix_fdb4a946; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_fdb4a946 ON dlfileshortcut USING btree (uuid_, groupid);


--
-- Name: ix_fdd1aaa8; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_fdd1aaa8 ON dlcontent USING btree (companyid, repositoryid, path_, version);


--
-- Name: ix_fec4a201; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_fec4a201 ON assetentry USING btree (layoutuuid);


--
-- Name: ix_fefc8da7; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_fefc8da7 ON expandocolumn USING btree (tableid, name);


--
-- Name: ix_fefe7d76; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_fefe7d76 ON shoppingitem USING btree (groupid, categoryid);


--
-- Name: ix_ff203304; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_ff203304 ON shoppingitem USING btree (smallimageid);


--
-- Name: ix_ffb3395c; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_ffb3395c ON dlfileversion USING btree (mimetype);


--
-- Name: public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

