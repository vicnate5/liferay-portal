--
-- PostgreSQL database dump
--

SET statement_timeout = 0;
SET lock_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;

--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: account_; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE account_ (
    accountid bigint NOT NULL,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    parentaccountid bigint,
    name character varying(75),
    legalname character varying(75),
    legalid character varying(75),
    legaltype character varying(75),
    siccode character varying(75),
    tickersymbol character varying(75),
    industry character varying(75),
    type_ character varying(75),
    size_ character varying(75)
);


ALTER TABLE account_ OWNER TO root;

--
-- Name: address; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE address (
    addressid bigint NOT NULL,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    classnameid bigint,
    classpk bigint,
    street1 character varying(75),
    street2 character varying(75),
    street3 character varying(75),
    city character varying(75),
    zip character varying(75),
    regionid bigint,
    countryid bigint,
    typeid integer,
    mailing boolean,
    primary_ boolean
);


ALTER TABLE address OWNER TO root;

--
-- Name: announcementsdelivery; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE announcementsdelivery (
    deliveryid bigint NOT NULL,
    companyid bigint,
    userid bigint,
    type_ character varying(75),
    email boolean,
    sms boolean,
    website boolean
);


ALTER TABLE announcementsdelivery OWNER TO root;

--
-- Name: announcementsentry; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE announcementsentry (
    uuid_ character varying(75),
    entryid bigint NOT NULL,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    classnameid bigint,
    classpk bigint,
    title character varying(75),
    content text,
    url text,
    type_ character varying(75),
    displaydate timestamp without time zone,
    expirationdate timestamp without time zone,
    priority integer,
    alert boolean
);


ALTER TABLE announcementsentry OWNER TO root;

--
-- Name: announcementsflag; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE announcementsflag (
    flagid bigint NOT NULL,
    userid bigint,
    createdate timestamp without time zone,
    entryid bigint,
    value integer
);


ALTER TABLE announcementsflag OWNER TO root;

--
-- Name: assetcategory; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE assetcategory (
    uuid_ character varying(75),
    categoryid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    parentcategoryid bigint,
    leftcategoryid bigint,
    rightcategoryid bigint,
    name character varying(75),
    title text,
    vocabularyid bigint
);


ALTER TABLE assetcategory OWNER TO root;

--
-- Name: assetcategoryproperty; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE assetcategoryproperty (
    categorypropertyid bigint NOT NULL,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    categoryid bigint,
    key_ character varying(75),
    value character varying(75)
);


ALTER TABLE assetcategoryproperty OWNER TO root;

--
-- Name: assetentries_assetcategories; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE assetentries_assetcategories (
    entryid bigint NOT NULL,
    categoryid bigint NOT NULL
);


ALTER TABLE assetentries_assetcategories OWNER TO root;

--
-- Name: assetentries_assettags; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE assetentries_assettags (
    entryid bigint NOT NULL,
    tagid bigint NOT NULL
);


ALTER TABLE assetentries_assettags OWNER TO root;

--
-- Name: assetentry; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE assetentry (
    entryid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    classnameid bigint,
    classpk bigint,
    classuuid character varying(75),
    visible boolean,
    startdate timestamp without time zone,
    enddate timestamp without time zone,
    publishdate timestamp without time zone,
    expirationdate timestamp without time zone,
    mimetype character varying(75),
    title text,
    description text,
    summary text,
    url text,
    height integer,
    width integer,
    priority double precision,
    viewcount integer
);


ALTER TABLE assetentry OWNER TO root;

--
-- Name: assetlink; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE assetlink (
    linkid bigint NOT NULL,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    entryid1 bigint,
    entryid2 bigint,
    type_ integer,
    weight integer
);


ALTER TABLE assetlink OWNER TO root;

--
-- Name: assettag; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE assettag (
    tagid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    name character varying(75),
    assetcount integer
);


ALTER TABLE assettag OWNER TO root;

--
-- Name: assettagproperty; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE assettagproperty (
    tagpropertyid bigint NOT NULL,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    tagid bigint,
    key_ character varying(75),
    value character varying(255)
);


ALTER TABLE assettagproperty OWNER TO root;

--
-- Name: assettagstats; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE assettagstats (
    tagstatsid bigint NOT NULL,
    tagid bigint,
    classnameid bigint,
    assetcount integer
);


ALTER TABLE assettagstats OWNER TO root;

--
-- Name: assetvocabulary; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE assetvocabulary (
    uuid_ character varying(75),
    vocabularyid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    name character varying(75),
    title text,
    description text,
    settings_ text
);


ALTER TABLE assetvocabulary OWNER TO root;

--
-- Name: blogsentry; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE blogsentry (
    uuid_ character varying(75),
    entryid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    title character varying(150),
    urltitle character varying(150),
    content text,
    displaydate timestamp without time zone,
    allowpingbacks boolean,
    allowtrackbacks boolean,
    trackbacks text,
    status integer,
    statusbyuserid bigint,
    statusbyusername character varying(75),
    statusdate timestamp without time zone
);


ALTER TABLE blogsentry OWNER TO root;

--
-- Name: blogsstatsuser; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE blogsstatsuser (
    statsuserid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    userid bigint,
    entrycount integer,
    lastpostdate timestamp without time zone,
    ratingstotalentries integer,
    ratingstotalscore double precision,
    ratingsaveragescore double precision
);


ALTER TABLE blogsstatsuser OWNER TO root;

--
-- Name: bookmarksentry; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE bookmarksentry (
    uuid_ character varying(75),
    entryid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    folderid bigint,
    name character varying(255),
    url text,
    comments text,
    visits integer,
    priority integer
);


ALTER TABLE bookmarksentry OWNER TO root;

--
-- Name: bookmarksfolder; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE bookmarksfolder (
    uuid_ character varying(75),
    folderid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    parentfolderid bigint,
    name character varying(75),
    description text
);


ALTER TABLE bookmarksfolder OWNER TO root;

--
-- Name: browsertracker; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE browsertracker (
    browsertrackerid bigint NOT NULL,
    userid bigint,
    browserkey bigint
);


ALTER TABLE browsertracker OWNER TO root;

--
-- Name: calevent; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE calevent (
    uuid_ character varying(75),
    eventid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    title character varying(75),
    description text,
    startdate timestamp without time zone,
    enddate timestamp without time zone,
    durationhour integer,
    durationminute integer,
    allday boolean,
    timezonesensitive boolean,
    type_ character varying(75),
    repeating boolean,
    recurrence text,
    remindby integer,
    firstreminder integer,
    secondreminder integer
);


ALTER TABLE calevent OWNER TO root;

--
-- Name: classname_; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE classname_ (
    classnameid bigint NOT NULL,
    value character varying(200)
);


ALTER TABLE classname_ OWNER TO root;

--
-- Name: clustergroup; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE clustergroup (
    clustergroupid bigint NOT NULL,
    name character varying(75),
    clusternodeids character varying(75),
    wholecluster boolean
);


ALTER TABLE clustergroup OWNER TO root;

--
-- Name: company; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE company (
    companyid bigint NOT NULL,
    accountid bigint,
    webid character varying(75),
    key_ text,
    mx character varying(75),
    homeurl text,
    logoid bigint,
    system boolean,
    maxusers integer
);


ALTER TABLE company OWNER TO root;

--
-- Name: contact_; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE contact_ (
    contactid bigint NOT NULL,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    accountid bigint,
    parentcontactid bigint,
    firstname character varying(75),
    middlename character varying(75),
    lastname character varying(75),
    prefixid integer,
    suffixid integer,
    male boolean,
    birthday timestamp without time zone,
    smssn character varying(75),
    aimsn character varying(75),
    facebooksn character varying(75),
    icqsn character varying(75),
    jabbersn character varying(75),
    msnsn character varying(75),
    myspacesn character varying(75),
    skypesn character varying(75),
    twittersn character varying(75),
    ymsn character varying(75),
    employeestatusid character varying(75),
    employeenumber character varying(75),
    jobtitle character varying(100),
    jobclass character varying(75),
    hoursofoperation character varying(75)
);


ALTER TABLE contact_ OWNER TO root;

--
-- Name: counter; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE counter (
    name character varying(75) NOT NULL,
    currentid bigint
);


ALTER TABLE counter OWNER TO root;

--
-- Name: country; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE country (
    countryid bigint NOT NULL,
    name character varying(75),
    a2 character varying(75),
    a3 character varying(75),
    number_ character varying(75),
    idd_ character varying(75),
    active_ boolean
);


ALTER TABLE country OWNER TO root;

--
-- Name: cyrususer; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE cyrususer (
    userid character varying(75) NOT NULL,
    password_ character varying(75) NOT NULL
);


ALTER TABLE cyrususer OWNER TO root;

--
-- Name: cyrusvirtual; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE cyrusvirtual (
    emailaddress character varying(75) NOT NULL,
    userid character varying(75) NOT NULL
);


ALTER TABLE cyrusvirtual OWNER TO root;

--
-- Name: dlfileentry; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE dlfileentry (
    uuid_ character varying(75),
    fileentryid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    userid bigint,
    username character varying(75),
    versionuserid bigint,
    versionusername character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    folderid bigint,
    name character varying(255),
    extension character varying(75),
    mimetype character varying(75),
    title character varying(255),
    description text,
    extrasettings text,
    version character varying(75),
    size_ bigint,
    readcount integer
);


ALTER TABLE dlfileentry OWNER TO root;

--
-- Name: dlfilerank; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE dlfilerank (
    filerankid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    userid bigint,
    createdate timestamp without time zone,
    fileentryid bigint
);


ALTER TABLE dlfilerank OWNER TO root;

--
-- Name: dlfileshortcut; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE dlfileshortcut (
    uuid_ character varying(75),
    fileshortcutid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    folderid bigint,
    tofileentryid bigint,
    status integer,
    statusbyuserid bigint,
    statusbyusername character varying(75),
    statusdate timestamp without time zone
);


ALTER TABLE dlfileshortcut OWNER TO root;

--
-- Name: dlfileversion; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE dlfileversion (
    fileversionid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    fileentryid bigint,
    extension character varying(75),
    mimetype character varying(75),
    title character varying(255),
    description text,
    changelog character varying(75),
    extrasettings text,
    version character varying(75),
    size_ bigint,
    status integer,
    statusbyuserid bigint,
    statusbyusername character varying(75),
    statusdate timestamp without time zone
);


ALTER TABLE dlfileversion OWNER TO root;

--
-- Name: dlfolder; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE dlfolder (
    uuid_ character varying(75),
    folderid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    parentfolderid bigint,
    name character varying(100),
    description text,
    lastpostdate timestamp without time zone
);


ALTER TABLE dlfolder OWNER TO root;

--
-- Name: emailaddress; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE emailaddress (
    emailaddressid bigint NOT NULL,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    classnameid bigint,
    classpk bigint,
    address character varying(75),
    typeid integer,
    primary_ boolean
);


ALTER TABLE emailaddress OWNER TO root;

--
-- Name: expandocolumn; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE expandocolumn (
    columnid bigint NOT NULL,
    companyid bigint,
    tableid bigint,
    name character varying(75),
    type_ integer,
    defaultdata text,
    typesettings text
);


ALTER TABLE expandocolumn OWNER TO root;

--
-- Name: expandorow; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE expandorow (
    rowid_ bigint NOT NULL,
    companyid bigint,
    tableid bigint,
    classpk bigint
);


ALTER TABLE expandorow OWNER TO root;

--
-- Name: expandotable; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE expandotable (
    tableid bigint NOT NULL,
    companyid bigint,
    classnameid bigint,
    name character varying(75)
);


ALTER TABLE expandotable OWNER TO root;

--
-- Name: expandovalue; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE expandovalue (
    valueid bigint NOT NULL,
    companyid bigint,
    tableid bigint,
    columnid bigint,
    rowid_ bigint,
    classnameid bigint,
    classpk bigint,
    data_ text
);


ALTER TABLE expandovalue OWNER TO root;

--
-- Name: group_; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE group_ (
    groupid bigint NOT NULL,
    companyid bigint,
    creatoruserid bigint,
    classnameid bigint,
    classpk bigint,
    parentgroupid bigint,
    livegroupid bigint,
    name character varying(75),
    description text,
    type_ integer,
    typesettings text,
    friendlyurl character varying(100),
    active_ boolean
);


ALTER TABLE group_ OWNER TO root;

--
-- Name: groups_orgs; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE groups_orgs (
    groupid bigint NOT NULL,
    organizationid bigint NOT NULL
);


ALTER TABLE groups_orgs OWNER TO root;

--
-- Name: groups_permissions; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE groups_permissions (
    groupid bigint NOT NULL,
    permissionid bigint NOT NULL
);


ALTER TABLE groups_permissions OWNER TO root;

--
-- Name: groups_roles; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE groups_roles (
    groupid bigint NOT NULL,
    roleid bigint NOT NULL
);


ALTER TABLE groups_roles OWNER TO root;

--
-- Name: groups_usergroups; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE groups_usergroups (
    groupid bigint NOT NULL,
    usergroupid bigint NOT NULL
);


ALTER TABLE groups_usergroups OWNER TO root;

--
-- Name: igfolder; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE igfolder (
    uuid_ character varying(75),
    folderid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    parentfolderid bigint,
    name character varying(75),
    description text
);


ALTER TABLE igfolder OWNER TO root;

--
-- Name: igimage; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE igimage (
    uuid_ character varying(75),
    imageid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    folderid bigint,
    name character varying(75),
    description text,
    smallimageid bigint,
    largeimageid bigint,
    custom1imageid bigint,
    custom2imageid bigint
);


ALTER TABLE igimage OWNER TO root;

--
-- Name: image; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE image (
    imageid bigint NOT NULL,
    modifieddate timestamp without time zone,
    text_ text,
    type_ character varying(75),
    height integer,
    width integer,
    size_ integer
);


ALTER TABLE image OWNER TO root;

--
-- Name: journalarticle; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE journalarticle (
    uuid_ character varying(75),
    id_ bigint NOT NULL,
    resourceprimkey bigint,
    groupid bigint,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    articleid character varying(75),
    version double precision,
    title character varying(300),
    urltitle character varying(150),
    description text,
    content text,
    type_ character varying(75),
    structureid character varying(75),
    templateid character varying(75),
    displaydate timestamp without time zone,
    expirationdate timestamp without time zone,
    reviewdate timestamp without time zone,
    indexable boolean,
    smallimage boolean,
    smallimageid bigint,
    smallimageurl text,
    status integer,
    statusbyuserid bigint,
    statusbyusername character varying(75),
    statusdate timestamp without time zone
);


ALTER TABLE journalarticle OWNER TO root;

--
-- Name: journalarticleimage; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE journalarticleimage (
    articleimageid bigint NOT NULL,
    groupid bigint,
    articleid character varying(75),
    version double precision,
    elinstanceid character varying(75),
    elname character varying(75),
    languageid character varying(75),
    tempimage boolean
);


ALTER TABLE journalarticleimage OWNER TO root;

--
-- Name: journalarticleresource; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE journalarticleresource (
    uuid_ character varying(75),
    resourceprimkey bigint NOT NULL,
    groupid bigint,
    articleid character varying(75)
);


ALTER TABLE journalarticleresource OWNER TO root;

--
-- Name: journalcontentsearch; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE journalcontentsearch (
    contentsearchid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    privatelayout boolean,
    layoutid bigint,
    portletid character varying(200),
    articleid character varying(75)
);


ALTER TABLE journalcontentsearch OWNER TO root;

--
-- Name: journalfeed; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE journalfeed (
    uuid_ character varying(75),
    id_ bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    feedid character varying(75),
    name character varying(75),
    description text,
    type_ character varying(75),
    structureid character varying(75),
    templateid character varying(75),
    renderertemplateid character varying(75),
    delta integer,
    orderbycol character varying(75),
    orderbytype character varying(75),
    targetlayoutfriendlyurl character varying(255),
    targetportletid character varying(75),
    contentfield character varying(75),
    feedtype character varying(75),
    feedversion double precision
);


ALTER TABLE journalfeed OWNER TO root;

--
-- Name: journalstructure; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE journalstructure (
    uuid_ character varying(75),
    id_ bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    structureid character varying(75),
    parentstructureid character varying(75),
    name character varying(75),
    description text,
    xsd text
);


ALTER TABLE journalstructure OWNER TO root;

--
-- Name: journaltemplate; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE journaltemplate (
    uuid_ character varying(75),
    id_ bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    templateid character varying(75),
    structureid character varying(75),
    name character varying(75),
    description text,
    xsl text,
    langtype character varying(75),
    cacheable boolean,
    smallimage boolean,
    smallimageid bigint,
    smallimageurl text
);


ALTER TABLE journaltemplate OWNER TO root;

--
-- Name: layout; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE layout (
    uuid_ character varying(75),
    plid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    privatelayout boolean,
    layoutid bigint,
    parentlayoutid bigint,
    name text,
    title text,
    description text,
    type_ character varying(75),
    typesettings text,
    hidden_ boolean,
    friendlyurl character varying(255),
    iconimage boolean,
    iconimageid bigint,
    themeid character varying(75),
    colorschemeid character varying(75),
    wapthemeid character varying(75),
    wapcolorschemeid character varying(75),
    css text,
    priority integer,
    layoutprototypeid bigint,
    dlfolderid bigint
);


ALTER TABLE layout OWNER TO root;

--
-- Name: layoutprototype; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE layoutprototype (
    layoutprototypeid bigint NOT NULL,
    companyid bigint,
    name text,
    description text,
    settings_ text,
    active_ boolean
);


ALTER TABLE layoutprototype OWNER TO root;

--
-- Name: layoutset; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE layoutset (
    layoutsetid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    privatelayout boolean,
    logo boolean,
    logoid bigint,
    themeid character varying(75),
    colorschemeid character varying(75),
    wapthemeid character varying(75),
    wapcolorschemeid character varying(75),
    css text,
    pagecount integer,
    settings_ text,
    layoutsetprototypeid bigint
);


ALTER TABLE layoutset OWNER TO root;

--
-- Name: layoutsetprototype; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE layoutsetprototype (
    layoutsetprototypeid bigint NOT NULL,
    companyid bigint,
    name text,
    description text,
    settings_ text,
    active_ boolean
);


ALTER TABLE layoutsetprototype OWNER TO root;

--
-- Name: listtype; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE listtype (
    listtypeid integer NOT NULL,
    name character varying(75),
    type_ character varying(75)
);


ALTER TABLE listtype OWNER TO root;

--
-- Name: lock_; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE lock_ (
    uuid_ character varying(75),
    lockid bigint NOT NULL,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    classname character varying(75),
    key_ character varying(200),
    owner character varying(300),
    inheritable boolean,
    expirationdate timestamp without time zone
);


ALTER TABLE lock_ OWNER TO root;

--
-- Name: mbban; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE mbban (
    banid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    banuserid bigint
);


ALTER TABLE mbban OWNER TO root;

--
-- Name: mbcategory; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE mbcategory (
    uuid_ character varying(75),
    categoryid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    parentcategoryid bigint,
    name character varying(75),
    description text,
    threadcount integer,
    messagecount integer,
    lastpostdate timestamp without time zone
);


ALTER TABLE mbcategory OWNER TO root;

--
-- Name: mbdiscussion; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE mbdiscussion (
    discussionid bigint NOT NULL,
    classnameid bigint,
    classpk bigint,
    threadid bigint
);


ALTER TABLE mbdiscussion OWNER TO root;

--
-- Name: mbmailinglist; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE mbmailinglist (
    uuid_ character varying(75),
    mailinglistid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    categoryid bigint,
    emailaddress character varying(75),
    inprotocol character varying(75),
    inservername character varying(75),
    inserverport integer,
    inusessl boolean,
    inusername character varying(75),
    inpassword character varying(75),
    inreadinterval integer,
    outemailaddress character varying(75),
    outcustom boolean,
    outservername character varying(75),
    outserverport integer,
    outusessl boolean,
    outusername character varying(75),
    outpassword character varying(75),
    allowanonymous boolean,
    active_ boolean
);


ALTER TABLE mbmailinglist OWNER TO root;

--
-- Name: mbmessage; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE mbmessage (
    uuid_ character varying(75),
    messageid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    classnameid bigint,
    classpk bigint,
    categoryid bigint,
    threadid bigint,
    rootmessageid bigint,
    parentmessageid bigint,
    subject character varying(75),
    body text,
    attachments boolean,
    anonymous boolean,
    priority double precision,
    allowpingbacks boolean,
    status integer,
    statusbyuserid bigint,
    statusbyusername character varying(75),
    statusdate timestamp without time zone
);


ALTER TABLE mbmessage OWNER TO root;

--
-- Name: mbmessageflag; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE mbmessageflag (
    messageflagid bigint NOT NULL,
    userid bigint,
    modifieddate timestamp without time zone,
    threadid bigint,
    messageid bigint,
    flag integer
);


ALTER TABLE mbmessageflag OWNER TO root;

--
-- Name: mbstatsuser; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE mbstatsuser (
    statsuserid bigint NOT NULL,
    groupid bigint,
    userid bigint,
    messagecount integer,
    lastpostdate timestamp without time zone
);


ALTER TABLE mbstatsuser OWNER TO root;

--
-- Name: mbthread; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE mbthread (
    threadid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    categoryid bigint,
    rootmessageid bigint,
    rootmessageuserid bigint,
    messagecount integer,
    viewcount integer,
    lastpostbyuserid bigint,
    lastpostdate timestamp without time zone,
    priority double precision,
    status integer,
    statusbyuserid bigint,
    statusbyusername character varying(75),
    statusdate timestamp without time zone
);


ALTER TABLE mbthread OWNER TO root;

--
-- Name: membershiprequest; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE membershiprequest (
    membershiprequestid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    userid bigint,
    createdate timestamp without time zone,
    comments text,
    replycomments text,
    replydate timestamp without time zone,
    replieruserid bigint,
    statusid integer
);


ALTER TABLE membershiprequest OWNER TO root;

--
-- Name: organization_; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE organization_ (
    organizationid bigint NOT NULL,
    companyid bigint,
    parentorganizationid bigint,
    leftorganizationid bigint,
    rightorganizationid bigint,
    name character varying(100),
    type_ character varying(75),
    recursable boolean,
    regionid bigint,
    countryid bigint,
    statusid integer,
    comments text
);


ALTER TABLE organization_ OWNER TO root;

--
-- Name: orggrouppermission; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE orggrouppermission (
    organizationid bigint NOT NULL,
    groupid bigint NOT NULL,
    permissionid bigint NOT NULL
);


ALTER TABLE orggrouppermission OWNER TO root;

--
-- Name: orggrouprole; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE orggrouprole (
    organizationid bigint NOT NULL,
    groupid bigint NOT NULL,
    roleid bigint NOT NULL
);


ALTER TABLE orggrouprole OWNER TO root;

--
-- Name: orglabor; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE orglabor (
    orglaborid bigint NOT NULL,
    organizationid bigint,
    typeid integer,
    sunopen integer,
    sunclose integer,
    monopen integer,
    monclose integer,
    tueopen integer,
    tueclose integer,
    wedopen integer,
    wedclose integer,
    thuopen integer,
    thuclose integer,
    friopen integer,
    friclose integer,
    satopen integer,
    satclose integer
);


ALTER TABLE orglabor OWNER TO root;

--
-- Name: passwordpolicy; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE passwordpolicy (
    passwordpolicyid bigint NOT NULL,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    defaultpolicy boolean,
    name character varying(75),
    description text,
    changeable boolean,
    changerequired boolean,
    minage bigint,
    checksyntax boolean,
    allowdictionarywords boolean,
    minalphanumeric integer,
    minlength integer,
    minlowercase integer,
    minnumbers integer,
    minsymbols integer,
    minuppercase integer,
    history boolean,
    historycount integer,
    expireable boolean,
    maxage bigint,
    warningtime bigint,
    gracelimit integer,
    lockout boolean,
    maxfailure integer,
    lockoutduration bigint,
    requireunlock boolean,
    resetfailurecount bigint,
    resetticketmaxage bigint
);


ALTER TABLE passwordpolicy OWNER TO root;

--
-- Name: passwordpolicyrel; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE passwordpolicyrel (
    passwordpolicyrelid bigint NOT NULL,
    passwordpolicyid bigint,
    classnameid bigint,
    classpk bigint
);


ALTER TABLE passwordpolicyrel OWNER TO root;

--
-- Name: passwordtracker; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE passwordtracker (
    passwordtrackerid bigint NOT NULL,
    userid bigint,
    createdate timestamp without time zone,
    password_ character varying(75)
);


ALTER TABLE passwordtracker OWNER TO root;

--
-- Name: permission_; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE permission_ (
    permissionid bigint NOT NULL,
    companyid bigint,
    actionid character varying(75),
    resourceid bigint
);


ALTER TABLE permission_ OWNER TO root;

--
-- Name: phone; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE phone (
    phoneid bigint NOT NULL,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    classnameid bigint,
    classpk bigint,
    number_ character varying(75),
    extension character varying(75),
    typeid integer,
    primary_ boolean
);


ALTER TABLE phone OWNER TO root;

--
-- Name: pluginsetting; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE pluginsetting (
    pluginsettingid bigint NOT NULL,
    companyid bigint,
    pluginid character varying(75),
    plugintype character varying(75),
    roles text,
    active_ boolean
);


ALTER TABLE pluginsetting OWNER TO root;

--
-- Name: pollschoice; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE pollschoice (
    uuid_ character varying(75),
    choiceid bigint NOT NULL,
    questionid bigint,
    name character varying(75),
    description text
);


ALTER TABLE pollschoice OWNER TO root;

--
-- Name: pollsquestion; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE pollsquestion (
    uuid_ character varying(75),
    questionid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    title text,
    description text,
    expirationdate timestamp without time zone,
    lastvotedate timestamp without time zone
);


ALTER TABLE pollsquestion OWNER TO root;

--
-- Name: pollsvote; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE pollsvote (
    voteid bigint NOT NULL,
    userid bigint,
    questionid bigint,
    choiceid bigint,
    votedate timestamp without time zone
);


ALTER TABLE pollsvote OWNER TO root;

--
-- Name: portalpreferences; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE portalpreferences (
    portalpreferencesid bigint NOT NULL,
    ownerid bigint,
    ownertype integer,
    preferences text
);


ALTER TABLE portalpreferences OWNER TO root;

--
-- Name: portlet; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE portlet (
    id_ bigint NOT NULL,
    companyid bigint,
    portletid character varying(200),
    roles text,
    active_ boolean
);


ALTER TABLE portlet OWNER TO root;

--
-- Name: portletitem; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE portletitem (
    portletitemid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    name character varying(75),
    portletid character varying(75),
    classnameid bigint
);


ALTER TABLE portletitem OWNER TO root;

--
-- Name: portletpreferences; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE portletpreferences (
    portletpreferencesid bigint NOT NULL,
    ownerid bigint,
    ownertype integer,
    plid bigint,
    portletid character varying(200),
    preferences text
);


ALTER TABLE portletpreferences OWNER TO root;

--
-- Name: quartz_blob_triggers; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE quartz_blob_triggers (
    trigger_name character varying(80) NOT NULL,
    trigger_group character varying(80) NOT NULL,
    blob_data oid
);


ALTER TABLE quartz_blob_triggers OWNER TO root;

--
-- Name: quartz_calendars; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE quartz_calendars (
    calendar_name character varying(80) NOT NULL,
    calendar oid NOT NULL
);


ALTER TABLE quartz_calendars OWNER TO root;

--
-- Name: quartz_cron_triggers; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE quartz_cron_triggers (
    trigger_name character varying(80) NOT NULL,
    trigger_group character varying(80) NOT NULL,
    cron_expression character varying(80) NOT NULL,
    time_zone_id character varying(80)
);


ALTER TABLE quartz_cron_triggers OWNER TO root;

--
-- Name: quartz_fired_triggers; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE quartz_fired_triggers (
    entry_id character varying(95) NOT NULL,
    trigger_name character varying(80) NOT NULL,
    trigger_group character varying(80) NOT NULL,
    is_volatile boolean NOT NULL,
    instance_name character varying(80) NOT NULL,
    fired_time bigint NOT NULL,
    priority integer NOT NULL,
    state character varying(16) NOT NULL,
    job_name character varying(80),
    job_group character varying(80),
    is_stateful boolean,
    requests_recovery boolean
);


ALTER TABLE quartz_fired_triggers OWNER TO root;

--
-- Name: quartz_job_details; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE quartz_job_details (
    job_name character varying(80) NOT NULL,
    job_group character varying(80) NOT NULL,
    description character varying(120),
    job_class_name character varying(128) NOT NULL,
    is_durable boolean NOT NULL,
    is_volatile boolean NOT NULL,
    is_stateful boolean NOT NULL,
    requests_recovery boolean NOT NULL,
    job_data oid
);


ALTER TABLE quartz_job_details OWNER TO root;

--
-- Name: quartz_job_listeners; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE quartz_job_listeners (
    job_name character varying(80) NOT NULL,
    job_group character varying(80) NOT NULL,
    job_listener character varying(80) NOT NULL
);


ALTER TABLE quartz_job_listeners OWNER TO root;

--
-- Name: quartz_locks; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE quartz_locks (
    lock_name character varying(40) NOT NULL
);


ALTER TABLE quartz_locks OWNER TO root;

--
-- Name: quartz_paused_trigger_grps; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE quartz_paused_trigger_grps (
    trigger_group character varying(80) NOT NULL
);


ALTER TABLE quartz_paused_trigger_grps OWNER TO root;

--
-- Name: quartz_scheduler_state; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE quartz_scheduler_state (
    instance_name character varying(80) NOT NULL,
    last_checkin_time bigint NOT NULL,
    checkin_interval bigint NOT NULL
);


ALTER TABLE quartz_scheduler_state OWNER TO root;

--
-- Name: quartz_simple_triggers; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE quartz_simple_triggers (
    trigger_name character varying(80) NOT NULL,
    trigger_group character varying(80) NOT NULL,
    repeat_count bigint NOT NULL,
    repeat_interval bigint NOT NULL,
    times_triggered bigint NOT NULL
);


ALTER TABLE quartz_simple_triggers OWNER TO root;

--
-- Name: quartz_trigger_listeners; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE quartz_trigger_listeners (
    trigger_name character varying(80) NOT NULL,
    trigger_group character varying(80) NOT NULL,
    trigger_listener character varying(80) NOT NULL
);


ALTER TABLE quartz_trigger_listeners OWNER TO root;

--
-- Name: quartz_triggers; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE quartz_triggers (
    trigger_name character varying(80) NOT NULL,
    trigger_group character varying(80) NOT NULL,
    job_name character varying(80) NOT NULL,
    job_group character varying(80) NOT NULL,
    is_volatile boolean NOT NULL,
    description character varying(120),
    next_fire_time bigint,
    prev_fire_time bigint,
    priority integer,
    trigger_state character varying(16) NOT NULL,
    trigger_type character varying(8) NOT NULL,
    start_time bigint NOT NULL,
    end_time bigint,
    calendar_name character varying(80),
    misfire_instr integer,
    job_data oid
);


ALTER TABLE quartz_triggers OWNER TO root;

--
-- Name: ratingsentry; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE ratingsentry (
    entryid bigint NOT NULL,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    classnameid bigint,
    classpk bigint,
    score double precision
);


ALTER TABLE ratingsentry OWNER TO root;

--
-- Name: ratingsstats; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE ratingsstats (
    statsid bigint NOT NULL,
    classnameid bigint,
    classpk bigint,
    totalentries integer,
    totalscore double precision,
    averagescore double precision
);


ALTER TABLE ratingsstats OWNER TO root;

--
-- Name: region; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE region (
    regionid bigint NOT NULL,
    countryid bigint,
    regioncode character varying(75),
    name character varying(75),
    active_ boolean
);


ALTER TABLE region OWNER TO root;

--
-- Name: release_; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE release_ (
    releaseid bigint NOT NULL,
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    servletcontextname character varying(75),
    buildnumber integer,
    builddate timestamp without time zone,
    verified boolean,
    teststring character varying(1024)
);


ALTER TABLE release_ OWNER TO root;

--
-- Name: resource_; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE resource_ (
    resourceid bigint NOT NULL,
    codeid bigint,
    primkey character varying(255)
);


ALTER TABLE resource_ OWNER TO root;

--
-- Name: resourceaction; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE resourceaction (
    resourceactionid bigint NOT NULL,
    name character varying(255),
    actionid character varying(75),
    bitwisevalue bigint
);


ALTER TABLE resourceaction OWNER TO root;

--
-- Name: resourcecode; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE resourcecode (
    codeid bigint NOT NULL,
    companyid bigint,
    name character varying(255),
    scope integer
);


ALTER TABLE resourcecode OWNER TO root;

--
-- Name: resourcepermission; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE resourcepermission (
    resourcepermissionid bigint NOT NULL,
    companyid bigint,
    name character varying(255),
    scope integer,
    primkey character varying(255),
    roleid bigint,
    ownerid bigint,
    actionids bigint
);


ALTER TABLE resourcepermission OWNER TO root;

--
-- Name: role_; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE role_ (
    roleid bigint NOT NULL,
    companyid bigint,
    classnameid bigint,
    classpk bigint,
    name character varying(75),
    title text,
    description text,
    type_ integer,
    subtype character varying(75)
);


ALTER TABLE role_ OWNER TO root;

--
-- Name: roles_permissions; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE roles_permissions (
    roleid bigint NOT NULL,
    permissionid bigint NOT NULL
);


ALTER TABLE roles_permissions OWNER TO root;

--
-- Name: scframeworkversi_scproductvers; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE scframeworkversi_scproductvers (
    frameworkversionid bigint NOT NULL,
    productversionid bigint NOT NULL
);


ALTER TABLE scframeworkversi_scproductvers OWNER TO root;

--
-- Name: scframeworkversion; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE scframeworkversion (
    frameworkversionid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    name character varying(75),
    url text,
    active_ boolean,
    priority integer
);


ALTER TABLE scframeworkversion OWNER TO root;

--
-- Name: sclicense; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE sclicense (
    licenseid bigint NOT NULL,
    name character varying(75),
    url text,
    opensource boolean,
    active_ boolean,
    recommended boolean
);


ALTER TABLE sclicense OWNER TO root;

--
-- Name: sclicenses_scproductentries; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE sclicenses_scproductentries (
    licenseid bigint NOT NULL,
    productentryid bigint NOT NULL
);


ALTER TABLE sclicenses_scproductentries OWNER TO root;

--
-- Name: scproductentry; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE scproductentry (
    productentryid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    name character varying(75),
    type_ character varying(75),
    tags character varying(255),
    shortdescription text,
    longdescription text,
    pageurl text,
    author character varying(75),
    repogroupid character varying(75),
    repoartifactid character varying(75)
);


ALTER TABLE scproductentry OWNER TO root;

--
-- Name: scproductscreenshot; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE scproductscreenshot (
    productscreenshotid bigint NOT NULL,
    companyid bigint,
    groupid bigint,
    productentryid bigint,
    thumbnailid bigint,
    fullimageid bigint,
    priority integer
);


ALTER TABLE scproductscreenshot OWNER TO root;

--
-- Name: scproductversion; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE scproductversion (
    productversionid bigint NOT NULL,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    productentryid bigint,
    version character varying(75),
    changelog text,
    downloadpageurl text,
    directdownloadurl character varying(2000),
    repostoreartifact boolean
);


ALTER TABLE scproductversion OWNER TO root;

--
-- Name: servicecomponent; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE servicecomponent (
    servicecomponentid bigint NOT NULL,
    buildnamespace character varying(75),
    buildnumber bigint,
    builddate bigint,
    data_ text
);


ALTER TABLE servicecomponent OWNER TO root;

--
-- Name: shard; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE shard (
    shardid bigint NOT NULL,
    classnameid bigint,
    classpk bigint,
    name character varying(75)
);


ALTER TABLE shard OWNER TO root;

--
-- Name: shoppingcart; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE shoppingcart (
    cartid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    itemids text,
    couponcodes character varying(75),
    altshipping integer,
    insure boolean
);


ALTER TABLE shoppingcart OWNER TO root;

--
-- Name: shoppingcategory; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE shoppingcategory (
    categoryid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    parentcategoryid bigint,
    name character varying(75),
    description text
);


ALTER TABLE shoppingcategory OWNER TO root;

--
-- Name: shoppingcoupon; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE shoppingcoupon (
    couponid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    code_ character varying(75),
    name character varying(75),
    description text,
    startdate timestamp without time zone,
    enddate timestamp without time zone,
    active_ boolean,
    limitcategories text,
    limitskus text,
    minorder double precision,
    discount double precision,
    discounttype character varying(75)
);


ALTER TABLE shoppingcoupon OWNER TO root;

--
-- Name: shoppingitem; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE shoppingitem (
    itemid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    categoryid bigint,
    sku character varying(75),
    name character varying(200),
    description text,
    properties text,
    fields_ boolean,
    fieldsquantities text,
    minquantity integer,
    maxquantity integer,
    price double precision,
    discount double precision,
    taxable boolean,
    shipping double precision,
    useshippingformula boolean,
    requiresshipping boolean,
    stockquantity integer,
    featured_ boolean,
    sale_ boolean,
    smallimage boolean,
    smallimageid bigint,
    smallimageurl text,
    mediumimage boolean,
    mediumimageid bigint,
    mediumimageurl text,
    largeimage boolean,
    largeimageid bigint,
    largeimageurl text
);


ALTER TABLE shoppingitem OWNER TO root;

--
-- Name: shoppingitemfield; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE shoppingitemfield (
    itemfieldid bigint NOT NULL,
    itemid bigint,
    name character varying(75),
    values_ text,
    description text
);


ALTER TABLE shoppingitemfield OWNER TO root;

--
-- Name: shoppingitemprice; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE shoppingitemprice (
    itempriceid bigint NOT NULL,
    itemid bigint,
    minquantity integer,
    maxquantity integer,
    price double precision,
    discount double precision,
    taxable boolean,
    shipping double precision,
    useshippingformula boolean,
    status integer
);


ALTER TABLE shoppingitemprice OWNER TO root;

--
-- Name: shoppingorder; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE shoppingorder (
    orderid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    number_ character varying(75),
    tax double precision,
    shipping double precision,
    altshipping character varying(75),
    requiresshipping boolean,
    insure boolean,
    insurance double precision,
    couponcodes character varying(75),
    coupondiscount double precision,
    billingfirstname character varying(75),
    billinglastname character varying(75),
    billingemailaddress character varying(75),
    billingcompany character varying(75),
    billingstreet character varying(75),
    billingcity character varying(75),
    billingstate character varying(75),
    billingzip character varying(75),
    billingcountry character varying(75),
    billingphone character varying(75),
    shiptobilling boolean,
    shippingfirstname character varying(75),
    shippinglastname character varying(75),
    shippingemailaddress character varying(75),
    shippingcompany character varying(75),
    shippingstreet character varying(75),
    shippingcity character varying(75),
    shippingstate character varying(75),
    shippingzip character varying(75),
    shippingcountry character varying(75),
    shippingphone character varying(75),
    ccname character varying(75),
    cctype character varying(75),
    ccnumber character varying(75),
    ccexpmonth integer,
    ccexpyear integer,
    ccvernumber character varying(75),
    comments text,
    pptxnid character varying(75),
    pppaymentstatus character varying(75),
    pppaymentgross double precision,
    ppreceiveremail character varying(75),
    pppayeremail character varying(75),
    sendorderemail boolean,
    sendshippingemail boolean
);


ALTER TABLE shoppingorder OWNER TO root;

--
-- Name: shoppingorderitem; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE shoppingorderitem (
    orderitemid bigint NOT NULL,
    orderid bigint,
    itemid character varying(75),
    sku character varying(75),
    name character varying(200),
    description text,
    properties text,
    price double precision,
    quantity integer,
    shippeddate timestamp without time zone
);


ALTER TABLE shoppingorderitem OWNER TO root;

--
-- Name: socialactivity; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE socialactivity (
    activityid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    userid bigint,
    createdate bigint,
    mirroractivityid bigint,
    classnameid bigint,
    classpk bigint,
    type_ integer,
    extradata text,
    receiveruserid bigint
);


ALTER TABLE socialactivity OWNER TO root;

--
-- Name: socialequityassetentry; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE socialequityassetentry (
    equityassetentryid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    userid bigint,
    assetentryid bigint,
    informationk double precision,
    informationb double precision
);


ALTER TABLE socialequityassetentry OWNER TO root;

--
-- Name: socialequitygroupsetting; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE socialequitygroupsetting (
    equitygroupsettingid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    classnameid bigint,
    type_ integer,
    enabled boolean
);


ALTER TABLE socialequitygroupsetting OWNER TO root;

--
-- Name: socialequityhistory; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE socialequityhistory (
    equityhistoryid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    userid bigint,
    createdate timestamp without time zone,
    personalequity integer
);


ALTER TABLE socialequityhistory OWNER TO root;

--
-- Name: socialequitylog; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE socialequitylog (
    equitylogid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    userid bigint,
    assetentryid bigint,
    actionid character varying(75),
    actiondate integer,
    active_ boolean,
    expiration integer,
    type_ integer,
    value integer,
    extradata character varying(255)
);


ALTER TABLE socialequitylog OWNER TO root;

--
-- Name: socialequitysetting; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE socialequitysetting (
    equitysettingid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    classnameid bigint,
    actionid character varying(75),
    dailylimit integer,
    lifespan integer,
    type_ integer,
    uniqueentry boolean,
    value integer
);


ALTER TABLE socialequitysetting OWNER TO root;

--
-- Name: socialequityuser; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE socialequityuser (
    equityuserid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    userid bigint,
    contributionk double precision,
    contributionb double precision,
    participationk double precision,
    participationb double precision,
    rank integer
);


ALTER TABLE socialequityuser OWNER TO root;

--
-- Name: socialrelation; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE socialrelation (
    uuid_ character varying(75),
    relationid bigint NOT NULL,
    companyid bigint,
    createdate bigint,
    userid1 bigint,
    userid2 bigint,
    type_ integer
);


ALTER TABLE socialrelation OWNER TO root;

--
-- Name: socialrequest; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE socialrequest (
    uuid_ character varying(75),
    requestid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    userid bigint,
    createdate bigint,
    modifieddate bigint,
    classnameid bigint,
    classpk bigint,
    type_ integer,
    extradata text,
    receiveruserid bigint,
    status integer
);


ALTER TABLE socialrequest OWNER TO root;

--
-- Name: subscription; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE subscription (
    subscriptionid bigint NOT NULL,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    classnameid bigint,
    classpk bigint,
    frequency character varying(75)
);


ALTER TABLE subscription OWNER TO root;

--
-- Name: tasksproposal; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE tasksproposal (
    proposalid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    classnameid bigint,
    classpk character varying(75),
    name character varying(75),
    description text,
    publishdate timestamp without time zone,
    duedate timestamp without time zone
);


ALTER TABLE tasksproposal OWNER TO root;

--
-- Name: tasksreview; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE tasksreview (
    reviewid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    proposalid bigint,
    assignedbyuserid bigint,
    assignedbyusername character varying(75),
    stage integer,
    completed boolean,
    rejected boolean
);


ALTER TABLE tasksreview OWNER TO root;

--
-- Name: team; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE team (
    teamid bigint NOT NULL,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    groupid bigint,
    name character varying(75),
    description text
);


ALTER TABLE team OWNER TO root;

--
-- Name: ticket; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE ticket (
    ticketid bigint NOT NULL,
    companyid bigint,
    createdate timestamp without time zone,
    classnameid bigint,
    classpk bigint,
    key_ character varying(75),
    type_ integer,
    extrainfo character varying(75),
    expirationdate timestamp without time zone
);


ALTER TABLE ticket OWNER TO root;

--
-- Name: user_; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE user_ (
    uuid_ character varying(75),
    userid bigint NOT NULL,
    companyid bigint,
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    defaultuser boolean,
    contactid bigint,
    password_ character varying(75),
    passwordencrypted boolean,
    passwordreset boolean,
    passwordmodifieddate timestamp without time zone,
    digest character varying(255),
    reminderqueryquestion character varying(75),
    reminderqueryanswer character varying(75),
    gracelogincount integer,
    screenname character varying(75),
    emailaddress character varying(75),
    facebookid bigint,
    openid character varying(1024),
    portraitid bigint,
    languageid character varying(75),
    timezoneid character varying(75),
    greeting character varying(255),
    comments text,
    firstname character varying(75),
    middlename character varying(75),
    lastname character varying(75),
    jobtitle character varying(100),
    logindate timestamp without time zone,
    loginip character varying(75),
    lastlogindate timestamp without time zone,
    lastloginip character varying(75),
    lastfailedlogindate timestamp without time zone,
    failedloginattempts integer,
    lockout boolean,
    lockoutdate timestamp without time zone,
    agreedtotermsofuse boolean,
    active_ boolean
);


ALTER TABLE user_ OWNER TO root;

--
-- Name: usergroup; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE usergroup (
    usergroupid bigint NOT NULL,
    companyid bigint,
    parentusergroupid bigint,
    name character varying(75),
    description text,
    addedbyldapimport boolean
);


ALTER TABLE usergroup OWNER TO root;

--
-- Name: usergroupgrouprole; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE usergroupgrouprole (
    usergroupid bigint NOT NULL,
    groupid bigint NOT NULL,
    roleid bigint NOT NULL
);


ALTER TABLE usergroupgrouprole OWNER TO root;

--
-- Name: usergrouprole; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE usergrouprole (
    userid bigint NOT NULL,
    groupid bigint NOT NULL,
    roleid bigint NOT NULL
);


ALTER TABLE usergrouprole OWNER TO root;

--
-- Name: usergroups_teams; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE usergroups_teams (
    usergroupid bigint NOT NULL,
    teamid bigint NOT NULL
);


ALTER TABLE usergroups_teams OWNER TO root;

--
-- Name: useridmapper; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE useridmapper (
    useridmapperid bigint NOT NULL,
    userid bigint,
    type_ character varying(75),
    description character varying(75),
    externaluserid character varying(75)
);


ALTER TABLE useridmapper OWNER TO root;

--
-- Name: usernotificationevent; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE usernotificationevent (
    uuid_ character varying(75),
    usernotificationeventid bigint NOT NULL,
    companyid bigint,
    userid bigint,
    type_ character varying(75),
    "timestamp" bigint,
    deliverby bigint,
    payload text
);


ALTER TABLE usernotificationevent OWNER TO root;

--
-- Name: users_groups; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE users_groups (
    userid bigint NOT NULL,
    groupid bigint NOT NULL
);


ALTER TABLE users_groups OWNER TO root;

--
-- Name: users_orgs; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE users_orgs (
    userid bigint NOT NULL,
    organizationid bigint NOT NULL
);


ALTER TABLE users_orgs OWNER TO root;

--
-- Name: users_permissions; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE users_permissions (
    userid bigint NOT NULL,
    permissionid bigint NOT NULL
);


ALTER TABLE users_permissions OWNER TO root;

--
-- Name: users_roles; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE users_roles (
    userid bigint NOT NULL,
    roleid bigint NOT NULL
);


ALTER TABLE users_roles OWNER TO root;

--
-- Name: users_teams; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE users_teams (
    userid bigint NOT NULL,
    teamid bigint NOT NULL
);


ALTER TABLE users_teams OWNER TO root;

--
-- Name: users_usergroups; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE users_usergroups (
    usergroupid bigint NOT NULL,
    userid bigint NOT NULL
);


ALTER TABLE users_usergroups OWNER TO root;

--
-- Name: usertracker; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE usertracker (
    usertrackerid bigint NOT NULL,
    companyid bigint,
    userid bigint,
    modifieddate timestamp without time zone,
    sessionid character varying(200),
    remoteaddr character varying(75),
    remotehost character varying(75),
    useragent character varying(200)
);


ALTER TABLE usertracker OWNER TO root;

--
-- Name: usertrackerpath; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE usertrackerpath (
    usertrackerpathid bigint NOT NULL,
    usertrackerid bigint,
    path_ text,
    pathdate timestamp without time zone
);


ALTER TABLE usertrackerpath OWNER TO root;

--
-- Name: virtualhost; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE virtualhost (
    virtualhostid bigint NOT NULL,
    companyid bigint,
    layoutsetid bigint,
    hostname character varying(75)
);


ALTER TABLE virtualhost OWNER TO root;

--
-- Name: vocabulary; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE vocabulary (
    vocabularyid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    name character varying(75),
    description character varying(75),
    folksonomy boolean
);


ALTER TABLE vocabulary OWNER TO root;

--
-- Name: webdavprops; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE webdavprops (
    webdavpropsid bigint NOT NULL,
    companyid bigint,
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    classnameid bigint,
    classpk bigint,
    props text
);


ALTER TABLE webdavprops OWNER TO root;

--
-- Name: website; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE website (
    websiteid bigint NOT NULL,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    classnameid bigint,
    classpk bigint,
    url text,
    typeid integer,
    primary_ boolean
);


ALTER TABLE website OWNER TO root;

--
-- Name: wikinode; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE wikinode (
    uuid_ character varying(75),
    nodeid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    name character varying(75),
    description text,
    lastpostdate timestamp without time zone
);


ALTER TABLE wikinode OWNER TO root;

--
-- Name: wikipage; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE wikipage (
    uuid_ character varying(75),
    pageid bigint NOT NULL,
    resourceprimkey bigint,
    groupid bigint,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    nodeid bigint,
    title character varying(255),
    version double precision,
    minoredit boolean,
    content text,
    summary text,
    format character varying(75),
    head boolean,
    parenttitle character varying(255),
    redirecttitle character varying(255),
    status integer,
    statusbyuserid bigint,
    statusbyusername character varying(75),
    statusdate timestamp without time zone
);


ALTER TABLE wikipage OWNER TO root;

--
-- Name: wikipageresource; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE wikipageresource (
    uuid_ character varying(75),
    resourceprimkey bigint NOT NULL,
    nodeid bigint,
    title character varying(255)
);


ALTER TABLE wikipageresource OWNER TO root;

--
-- Name: workflowdefinitionlink; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE workflowdefinitionlink (
    workflowdefinitionlinkid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    classnameid bigint,
    workflowdefinitionname character varying(75),
    workflowdefinitionversion integer
);


ALTER TABLE workflowdefinitionlink OWNER TO root;

--
-- Name: workflowinstancelink; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE workflowinstancelink (
    workflowinstancelinkid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    classnameid bigint,
    classpk bigint,
    workflowinstanceid bigint
);


ALTER TABLE workflowinstancelink OWNER TO root;

--
-- Data for Name: account_; Type: TABLE DATA; Schema: public; Owner: root
--

COPY account_ (accountid, companyid, userid, username, createdate, modifieddate, parentaccountid, name, legalname, legalid, legaltype, siccode, tickersymbol, industry, type_, size_) FROM stdin;
10138	10136	0		2017-03-10 17:04:09.523	2017-03-10 17:04:09.523	0	liferay.com								
\.


--
-- Data for Name: address; Type: TABLE DATA; Schema: public; Owner: root
--

COPY address (addressid, companyid, userid, username, createdate, modifieddate, classnameid, classpk, street1, street2, street3, city, zip, regionid, countryid, typeid, mailing, primary_) FROM stdin;
\.


--
-- Data for Name: announcementsdelivery; Type: TABLE DATA; Schema: public; Owner: root
--

COPY announcementsdelivery (deliveryid, companyid, userid, type_, email, sms, website) FROM stdin;
\.


--
-- Data for Name: announcementsentry; Type: TABLE DATA; Schema: public; Owner: root
--

COPY announcementsentry (uuid_, entryid, companyid, userid, username, createdate, modifieddate, classnameid, classpk, title, content, url, type_, displaydate, expirationdate, priority, alert) FROM stdin;
\.


--
-- Data for Name: announcementsflag; Type: TABLE DATA; Schema: public; Owner: root
--

COPY announcementsflag (flagid, userid, createdate, entryid, value) FROM stdin;
\.


--
-- Data for Name: assetcategory; Type: TABLE DATA; Schema: public; Owner: root
--

COPY assetcategory (uuid_, categoryid, groupid, companyid, userid, username, createdate, modifieddate, parentcategoryid, leftcategoryid, rightcategoryid, name, title, vocabularyid) FROM stdin;
\.


--
-- Data for Name: assetcategoryproperty; Type: TABLE DATA; Schema: public; Owner: root
--

COPY assetcategoryproperty (categorypropertyid, companyid, userid, username, createdate, modifieddate, categoryid, key_, value) FROM stdin;
\.


--
-- Data for Name: assetentries_assetcategories; Type: TABLE DATA; Schema: public; Owner: root
--

COPY assetentries_assetcategories (entryid, categoryid) FROM stdin;
\.


--
-- Data for Name: assetentries_assettags; Type: TABLE DATA; Schema: public; Owner: root
--

COPY assetentries_assettags (entryid, tagid) FROM stdin;
\.


--
-- Data for Name: assetentry; Type: TABLE DATA; Schema: public; Owner: root
--

COPY assetentry (entryid, groupid, companyid, userid, username, createdate, modifieddate, classnameid, classpk, classuuid, visible, startdate, enddate, publishdate, expirationdate, mimetype, title, description, summary, url, height, width, priority, viewcount) FROM stdin;
10160	10154	10136	10140	 	2017-03-10 17:04:09.88	2017-03-10 17:04:09.88	10096	10158	8b7c26c5-3c3c-45d9-a6bc-76407e9f769f	f	\N	\N	\N	\N	text/html	10157				0	0	0	0
10168	10162	10136	10140	 	2017-03-10 17:04:09.955	2017-03-10 17:04:09.955	10096	10166	17bab393-e61a-420f-ae72-4d7a270b295c	f	\N	\N	\N	\N	text/html	10165				0	0	0	0
10183	10174	10136	10178	Test Test	2017-03-10 17:04:10.346	2017-03-10 17:04:10.346	10047	10178	69f7273b-5b15-41c5-bedd-5fa9507b2863	f	\N	\N	\N	\N		Test Test				0	0	0	0
10277	10180	10136	10178	Test Test	2017-03-10 17:06:40.332	2017-03-10 17:06:40.332	10096	10275	b664329b-89d8-410f-bdf6-c8b6534908c0	f	\N	\N	\N	\N	text/html	10274				0	0	0	0
10282	10180	10136	10178	Test Test	2017-03-10 17:06:40.355	2017-03-10 17:06:40.355	10096	10280	7d63d8f1-aebb-45eb-8188-4d126ad8353d	f	\N	\N	\N	\N	text/html	10279				0	0	0	0
10294	10174	10136	10178	Test Test	2017-03-10 17:06:52.056	2017-03-10 17:06:52.056	10012	10291		f	\N	\N	\N	\N		Staging Site				0	0	0	0
10298	10291	10136	10178	Test Test	2017-03-10 17:07:00.011	2017-03-10 17:07:00.011	10096	10296	0e96f674-cf42-4f5c-aa1e-48f4109ae109	f	\N	\N	\N	\N	text/html	10295				0	0	0	0
10304	10174	10136	10178	Test Test	2017-03-10 17:07:17.929	2017-03-10 17:07:17.929	10012	10301		f	\N	\N	\N	\N		Staging Site (Staging)				0	0	0	0
10330	10301	10136	10178	Test Test	2017-03-10 17:07:30.434	2017-03-10 17:07:30.434	10096	10328	fab94592-bc31-4afb-9941-d861b8b95b70	f	\N	\N	\N	\N	text/html	10325				0	0	0	0
10327	10301	10136	10178	Test Test	2017-03-10 17:07:30.425	2017-03-10 17:07:30.425	10087	10325	4dcf2e35-db94-4033-9464-d3e66007bda7	t	\N	\N	2017-03-10 17:07:00	\N	text/html	Web Content Title				0	0	0	1
\.


--
-- Data for Name: assetlink; Type: TABLE DATA; Schema: public; Owner: root
--

COPY assetlink (linkid, companyid, userid, username, createdate, entryid1, entryid2, type_, weight) FROM stdin;
\.


--
-- Data for Name: assettag; Type: TABLE DATA; Schema: public; Owner: root
--

COPY assettag (tagid, groupid, companyid, userid, username, createdate, modifieddate, name, assetcount) FROM stdin;
\.


--
-- Data for Name: assettagproperty; Type: TABLE DATA; Schema: public; Owner: root
--

COPY assettagproperty (tagpropertyid, companyid, userid, username, createdate, modifieddate, tagid, key_, value) FROM stdin;
\.


--
-- Data for Name: assettagstats; Type: TABLE DATA; Schema: public; Owner: root
--

COPY assettagstats (tagstatsid, tagid, classnameid, assetcount) FROM stdin;
\.


--
-- Data for Name: assetvocabulary; Type: TABLE DATA; Schema: public; Owner: root
--

COPY assetvocabulary (uuid_, vocabularyid, groupid, companyid, userid, username, createdate, modifieddate, name, title, description, settings_) FROM stdin;
20ca9f30-0c62-4fe4-a823-5fbdc1c93fbb	10309	10291	10136	10140	 	2017-03-10 17:07:18.296	2017-03-10 17:07:18.296	Topic	<?xml version='1.0' encoding='UTF-8'?><root available-locales="en_US" default-locale="en_US"><Title language-id="en_US">Topic</Title></root>		
20ca9f30-0c62-4fe4-a823-5fbdc1c93fbb	10310	10301	10136	10140	 	2017-03-10 17:07:18.413	2017-03-10 17:07:18.413	Topic	<?xml version='1.0' encoding='UTF-8'?><root available-locales="en_US" default-locale="en_US"><Title language-id="en_US">Topic</Title></root>		
\.


--
-- Data for Name: blogsentry; Type: TABLE DATA; Schema: public; Owner: root
--

COPY blogsentry (uuid_, entryid, groupid, companyid, userid, username, createdate, modifieddate, title, urltitle, content, displaydate, allowpingbacks, allowtrackbacks, trackbacks, status, statusbyuserid, statusbyusername, statusdate) FROM stdin;
\.


--
-- Data for Name: blogsstatsuser; Type: TABLE DATA; Schema: public; Owner: root
--

COPY blogsstatsuser (statsuserid, groupid, companyid, userid, entrycount, lastpostdate, ratingstotalentries, ratingstotalscore, ratingsaveragescore) FROM stdin;
\.


--
-- Data for Name: bookmarksentry; Type: TABLE DATA; Schema: public; Owner: root
--

COPY bookmarksentry (uuid_, entryid, groupid, companyid, userid, username, createdate, modifieddate, folderid, name, url, comments, visits, priority) FROM stdin;
\.


--
-- Data for Name: bookmarksfolder; Type: TABLE DATA; Schema: public; Owner: root
--

COPY bookmarksfolder (uuid_, folderid, groupid, companyid, userid, username, createdate, modifieddate, parentfolderid, name, description) FROM stdin;
\.


--
-- Data for Name: browsertracker; Type: TABLE DATA; Schema: public; Owner: root
--

COPY browsertracker (browsertrackerid, userid, browserkey) FROM stdin;
\.


--
-- Data for Name: calevent; Type: TABLE DATA; Schema: public; Owner: root
--

COPY calevent (uuid_, eventid, groupid, companyid, userid, username, createdate, modifieddate, title, description, startdate, enddate, durationhour, durationminute, allday, timezonesensitive, type_, repeating, recurrence, remindby, firstreminder, secondreminder) FROM stdin;
\.


--
-- Data for Name: classname_; Type: TABLE DATA; Schema: public; Owner: root
--

COPY classname_ (classnameid, value) FROM stdin;
10001	com.liferay.counter.model.Counter
10002	com.liferay.portal.kernel.workflow.WorkflowTask
10003	com.liferay.portal.model.Account
10004	com.liferay.portal.model.Address
10005	com.liferay.portal.model.BrowserTracker
10006	com.liferay.portal.model.ClassName
10007	com.liferay.portal.model.ClusterGroup
10008	com.liferay.portal.model.Company
10009	com.liferay.portal.model.Contact
10010	com.liferay.portal.model.Country
10011	com.liferay.portal.model.EmailAddress
10012	com.liferay.portal.model.Group
10013	com.liferay.portal.model.Image
10014	com.liferay.portal.model.Layout
10015	com.liferay.portal.model.LayoutPrototype
10016	com.liferay.portal.model.LayoutSet
10017	com.liferay.portal.model.LayoutSetPrototype
10018	com.liferay.portal.model.ListType
10019	com.liferay.portal.model.Lock
10020	com.liferay.portal.model.MembershipRequest
10021	com.liferay.portal.model.OrgGroupPermission
10022	com.liferay.portal.model.OrgGroupRole
10023	com.liferay.portal.model.OrgLabor
10024	com.liferay.portal.model.Organization
10025	com.liferay.portal.model.PasswordPolicy
10026	com.liferay.portal.model.PasswordPolicyRel
10027	com.liferay.portal.model.PasswordTracker
10028	com.liferay.portal.model.Permission
10029	com.liferay.portal.model.Phone
10030	com.liferay.portal.model.PluginSetting
10031	com.liferay.portal.model.PortalPreferences
10032	com.liferay.portal.model.Portlet
10033	com.liferay.portal.model.PortletItem
10034	com.liferay.portal.model.PortletPreferences
10035	com.liferay.portal.model.Region
10036	com.liferay.portal.model.Release
10037	com.liferay.portal.model.Resource
10038	com.liferay.portal.model.ResourceAction
10039	com.liferay.portal.model.ResourceCode
10040	com.liferay.portal.model.ResourcePermission
10041	com.liferay.portal.model.Role
10042	com.liferay.portal.model.ServiceComponent
10043	com.liferay.portal.model.Shard
10044	com.liferay.portal.model.Subscription
10045	com.liferay.portal.model.Team
10046	com.liferay.portal.model.Ticket
10047	com.liferay.portal.model.User
10048	com.liferay.portal.model.UserGroup
10049	com.liferay.portal.model.UserGroupGroupRole
10050	com.liferay.portal.model.UserGroupRole
10051	com.liferay.portal.model.UserIdMapper
10052	com.liferay.portal.model.UserNotificationEvent
10053	com.liferay.portal.model.UserTracker
10054	com.liferay.portal.model.UserTrackerPath
10055	com.liferay.portal.model.VirtualHost
10056	com.liferay.portal.model.WebDAVProps
10057	com.liferay.portal.model.Website
10058	com.liferay.portal.model.WorkflowDefinitionLink
10059	com.liferay.portal.model.WorkflowInstanceLink
10060	com.liferay.portlet.announcements.model.AnnouncementsDelivery
10061	com.liferay.portlet.announcements.model.AnnouncementsEntry
10062	com.liferay.portlet.announcements.model.AnnouncementsFlag
10063	com.liferay.portlet.asset.model.AssetCategory
10064	com.liferay.portlet.asset.model.AssetCategoryProperty
10065	com.liferay.portlet.asset.model.AssetEntry
10066	com.liferay.portlet.asset.model.AssetLink
10067	com.liferay.portlet.asset.model.AssetTag
10068	com.liferay.portlet.asset.model.AssetTagProperty
10069	com.liferay.portlet.asset.model.AssetTagStats
10070	com.liferay.portlet.asset.model.AssetVocabulary
10071	com.liferay.portlet.blogs.model.BlogsEntry
10072	com.liferay.portlet.blogs.model.BlogsStatsUser
10073	com.liferay.portlet.bookmarks.model.BookmarksEntry
10074	com.liferay.portlet.bookmarks.model.BookmarksFolder
10075	com.liferay.portlet.calendar.model.CalEvent
10076	com.liferay.portlet.documentlibrary.model.DLFileEntry
10077	com.liferay.portlet.documentlibrary.model.DLFileRank
10078	com.liferay.portlet.documentlibrary.model.DLFileShortcut
10079	com.liferay.portlet.documentlibrary.model.DLFileVersion
10080	com.liferay.portlet.documentlibrary.model.DLFolder
10081	com.liferay.portlet.expando.model.ExpandoColumn
10082	com.liferay.portlet.expando.model.ExpandoRow
10083	com.liferay.portlet.expando.model.ExpandoTable
10084	com.liferay.portlet.expando.model.ExpandoValue
10085	com.liferay.portlet.imagegallery.model.IGFolder
10086	com.liferay.portlet.imagegallery.model.IGImage
10087	com.liferay.portlet.journal.model.JournalArticle
10088	com.liferay.portlet.journal.model.JournalArticleImage
10089	com.liferay.portlet.journal.model.JournalArticleResource
10090	com.liferay.portlet.journal.model.JournalContentSearch
10091	com.liferay.portlet.journal.model.JournalFeed
10092	com.liferay.portlet.journal.model.JournalStructure
10093	com.liferay.portlet.journal.model.JournalTemplate
10094	com.liferay.portlet.messageboards.model.MBBan
10095	com.liferay.portlet.messageboards.model.MBCategory
10096	com.liferay.portlet.messageboards.model.MBDiscussion
10097	com.liferay.portlet.messageboards.model.MBMailingList
10098	com.liferay.portlet.messageboards.model.MBMessage
10099	com.liferay.portlet.messageboards.model.MBMessageFlag
10100	com.liferay.portlet.messageboards.model.MBStatsUser
10101	com.liferay.portlet.messageboards.model.MBThread
10102	com.liferay.portlet.polls.model.PollsChoice
10103	com.liferay.portlet.polls.model.PollsQuestion
10104	com.liferay.portlet.polls.model.PollsVote
10105	com.liferay.portlet.ratings.model.RatingsEntry
10106	com.liferay.portlet.ratings.model.RatingsStats
10107	com.liferay.portlet.shopping.model.ShoppingCart
10108	com.liferay.portlet.shopping.model.ShoppingCategory
10109	com.liferay.portlet.shopping.model.ShoppingCoupon
10110	com.liferay.portlet.shopping.model.ShoppingItem
10111	com.liferay.portlet.shopping.model.ShoppingItemField
10112	com.liferay.portlet.shopping.model.ShoppingItemPrice
10113	com.liferay.portlet.shopping.model.ShoppingOrder
10114	com.liferay.portlet.shopping.model.ShoppingOrderItem
10115	com.liferay.portlet.social.model.SocialActivity
10116	com.liferay.portlet.social.model.SocialEquityAssetEntry
10117	com.liferay.portlet.social.model.SocialEquityGroupSetting
10118	com.liferay.portlet.social.model.SocialEquityHistory
10119	com.liferay.portlet.social.model.SocialEquityLog
10120	com.liferay.portlet.social.model.SocialEquitySetting
10121	com.liferay.portlet.social.model.SocialEquityUser
10122	com.liferay.portlet.social.model.SocialRelation
10123	com.liferay.portlet.social.model.SocialRequest
10124	com.liferay.portlet.softwarecatalog.model.SCFrameworkVersion
10125	com.liferay.portlet.softwarecatalog.model.SCLicense
10126	com.liferay.portlet.softwarecatalog.model.SCProductEntry
10127	com.liferay.portlet.softwarecatalog.model.SCProductScreenshot
10128	com.liferay.portlet.softwarecatalog.model.SCProductVersion
10129	com.liferay.portlet.tasks.model.TasksProposal
10130	com.liferay.portlet.tasks.model.TasksReview
10131	com.liferay.portlet.usernotifications.model.UserNotificationEvent
10132	com.liferay.portlet.wiki.model.WikiNode
10133	com.liferay.portlet.wiki.model.WikiPage
10134	com.liferay.portlet.wiki.model.WikiPageResource
10170	com.liferay.portal.model.UserPersonalCommunity
\.


--
-- Data for Name: clustergroup; Type: TABLE DATA; Schema: public; Owner: root
--

COPY clustergroup (clustergroupid, name, clusternodeids, wholecluster) FROM stdin;
\.


--
-- Data for Name: company; Type: TABLE DATA; Schema: public; Owner: root
--

COPY company (companyid, accountid, webid, key_, mx, homeurl, logoid, system, maxusers) FROM stdin;
10136	10138	liferay.com	rO0ABXNyABRqYXZhLnNlY3VyaXR5LktleVJlcL35T7OImqVDAgAETAAJYWxnb3JpdGhtdAASTGphdmEvbGFuZy9TdHJpbmc7WwAHZW5jb2RlZHQAAltCTAAGZm9ybWF0cQB+AAFMAAR0eXBldAAbTGphdmEvc2VjdXJpdHkvS2V5UmVwJFR5cGU7eHB0AANERVN1cgACW0Ks8xf4BghU4AIAAHhwAAAACDLc5vLQ5Vf0dAADUkFXfnIAGWphdmEuc2VjdXJpdHkuS2V5UmVwJFR5cGUAAAAAAAAAABIAAHhyAA5qYXZhLmxhbmcuRW51bQAAAAAAAAAAEgAAeHB0AAZTRUNSRVQ=	liferay.com		0	f	0
\.


--
-- Data for Name: contact_; Type: TABLE DATA; Schema: public; Owner: root
--

COPY contact_ (contactid, companyid, userid, username, createdate, modifieddate, accountid, parentcontactid, firstname, middlename, lastname, prefixid, suffixid, male, birthday, smssn, aimsn, facebooksn, icqsn, jabbersn, msnsn, myspacesn, skypesn, twittersn, ymsn, employeestatusid, employeenumber, jobtitle, jobclass, hoursofoperation) FROM stdin;
10141	10136	10140		2017-03-10 17:04:09.512	2017-03-10 17:04:09.512	10138	0				0	0	t	2017-03-10 17:04:09.512															
10179	10136	10178		2017-03-10 17:04:10.247	2017-03-10 17:04:10.247	10138	0	Test		Test	0	0	t	1970-01-01 00:00:00															
\.


--
-- Data for Name: counter; Type: TABLE DATA; Schema: public; Owner: root
--

COPY counter (name, currentid) FROM stdin;
com.liferay.portal.model.Resource	100
com.liferay.portal.model.Permission	100
com.liferay.portal.model.ResourceAction	700
com.liferay.portal.model.Layout#10154#true	1
com.liferay.portal.model.Layout#10162#false	1
com.liferay.portal.model.Layout#10180#true	1
com.liferay.portal.model.Layout#10180#false	1
com.liferay.portal.model.Layout#10291#false	1
com.liferay.counter.model.Counter	10400
com.liferay.portal.model.ResourcePermission	400
com.liferay.portal.model.Layout#10301#false	1
\.


--
-- Data for Name: country; Type: TABLE DATA; Schema: public; Owner: root
--

COPY country (countryid, name, a2, a3, number_, idd_, active_) FROM stdin;
1	Canada	CA	CAN	124	001	t
2	China	CN	CHN	156	086	t
3	France	FR	FRA	250	033	t
4	Germany	DE	DEU	276	049	t
5	Hong Kong	HK	HKG	344	852	t
6	Hungary	HU	HUN	348	036	t
7	Israel	IL	ISR	376	972	t
8	Italy	IT	ITA	380	039	t
9	Japan	JP	JPN	392	081	t
10	South Korea	KR	KOR	410	082	t
11	Netherlands	NL	NLD	528	031	t
12	Portugal	PT	PRT	620	351	t
13	Russia	RU	RUS	643	007	t
14	Singapore	SG	SGP	702	065	t
15	Spain	ES	ESP	724	034	t
16	Turkey	TR	TUR	792	090	t
17	Vietnam	VN	VNM	704	084	t
18	United Kingdom	GB	GBR	826	044	t
19	United States	US	USA	840	001	t
20	Afghanistan	AF	AFG	4	093	t
21	Albania	AL	ALB	8	355	t
22	Algeria	DZ	DZA	12	213	t
23	American Samoa	AS	ASM	16	684	t
24	Andorra	AD	AND	20	376	t
25	Angola	AO	AGO	24	244	t
26	Anguilla	AI	AIA	660	264	t
27	Antarctica	AQ	ATA	10	672	t
28	Antigua	AG	ATG	28	268	t
29	Argentina	AR	ARG	32	054	t
30	Armenia	AM	ARM	51	374	t
31	Aruba	AW	ABW	533	297	t
32	Australia	AU	AUS	36	061	t
33	Austria	AT	AUT	40	043	t
34	Azerbaijan	AZ	AZE	31	994	t
35	Bahamas	BS	BHS	44	242	t
36	Bahrain	BH	BHR	48	973	t
37	Bangladesh	BD	BGD	50	880	t
38	Barbados	BB	BRB	52	246	t
39	Belarus	BY	BLR	112	375	t
40	Belgium	BE	BEL	56	032	t
41	Belize	BZ	BLZ	84	501	t
42	Benin	BJ	BEN	204	229	t
43	Bermuda	BM	BMU	60	441	t
44	Bhutan	BT	BTN	64	975	t
45	Bolivia	BO	BOL	68	591	t
46	Bosnia-Herzegovina	BA	BIH	70	387	t
47	Botswana	BW	BWA	72	267	t
48	Brazil	BR	BRA	76	055	t
49	British Virgin Islands	VG	VGB	92	284	t
50	Brunei	BN	BRN	96	673	t
51	Bulgaria	BG	BGR	100	359	t
52	Burkina Faso	BF	BFA	854	226	t
53	Burma (Myanmar)	MM	MMR	104	095	t
54	Burundi	BI	BDI	108	257	t
55	Cambodia	KH	KHM	116	855	t
56	Cameroon	CM	CMR	120	237	t
57	Cape Verde Island	CV	CPV	132	238	t
58	Cayman Islands	KY	CYM	136	345	t
59	Central African Republic	CF	CAF	140	236	t
60	Chad	TD	TCD	148	235	t
61	Chile	CL	CHL	152	056	t
62	Christmas Island	CX	CXR	162	061	t
63	Cocos Islands	CC	CCK	166	061	t
64	Colombia	CO	COL	170	057	t
65	Comoros	KM	COM	174	269	t
66	Republic of Congo	CD	COD	180	242	t
67	Democratic Republic of Congo	CG	COG	178	243	t
68	Cook Islands	CK	COK	184	682	t
69	Costa Rica	CR	CRI	188	506	t
70	Croatia	HR	HRV	191	385	t
71	Cuba	CU	CUB	192	053	t
72	Cyprus	CY	CYP	196	357	t
73	Czech Republic	CZ	CZE	203	420	t
74	Denmark	DK	DNK	208	045	t
75	Djibouti	DJ	DJI	262	253	t
76	Dominica	DM	DMA	212	767	t
77	Dominican Republic	DO	DOM	214	809	t
78	Ecuador	EC	ECU	218	593	t
79	Egypt	EG	EGY	818	020	t
80	El Salvador	SV	SLV	222	503	t
81	Equatorial Guinea	GQ	GNQ	226	240	t
82	Eritrea	ER	ERI	232	291	t
83	Estonia	EE	EST	233	372	t
84	Ethiopia	ET	ETH	231	251	t
85	Faeroe Islands	FO	FRO	234	298	t
86	Falkland Islands	FK	FLK	238	500	t
87	Fiji Islands	FJ	FJI	242	679	t
88	Finland	FI	FIN	246	358	t
89	French Guiana	GF	GUF	254	594	t
90	French Polynesia	PF	PYF	258	689	t
91	Gabon	GA	GAB	266	241	t
92	Gambia	GM	GMB	270	220	t
93	Georgia	GE	GEO	268	995	t
94	Ghana	GH	GHA	288	233	t
95	Gibraltar	GI	GIB	292	350	t
96	Greece	GR	GRC	300	030	t
97	Greenland	GL	GRL	304	299	t
98	Grenada	GD	GRD	308	473	t
99	Guadeloupe	GP	GLP	312	590	t
100	Guam	GU	GUM	316	671	t
101	Guatemala	GT	GTM	320	502	t
102	Guinea	GN	GIN	324	224	t
103	Guinea-Bissau	GW	GNB	624	245	t
104	Guyana	GY	GUY	328	592	t
105	Haiti	HT	HTI	332	509	t
106	Honduras	HN	HND	340	504	t
107	Iceland	IS	ISL	352	354	t
108	India	IN	IND	356	091	t
109	Indonesia	ID	IDN	360	062	t
110	Iran	IR	IRN	364	098	t
111	Iraq	IQ	IRQ	368	964	t
112	Ireland	IE	IRL	372	353	t
113	Ivory Coast	CI	CIV	384	225	t
114	Jamaica	JM	JAM	388	876	t
115	Jordan	JO	JOR	400	962	t
116	Kazakhstan	KZ	KAZ	398	007	t
117	Kenya	KE	KEN	404	254	t
118	Kiribati	KI	KIR	408	686	t
119	Kuwait	KW	KWT	414	965	t
120	North Korea	KP	PRK	408	850	t
121	Kyrgyzstan	KG	KGZ	471	996	t
122	Laos	LA	LAO	418	856	t
123	Latvia	LV	LVA	428	371	t
124	Lebanon	LB	LBN	422	961	t
125	Lesotho	LS	LSO	426	266	t
126	Liberia	LR	LBR	430	231	t
127	Libya	LY	LBY	434	218	t
128	Liechtenstein	LI	LIE	438	423	t
129	Lithuania	LT	LTU	440	370	t
130	Luxembourg	LU	LUX	442	352	t
131	Macau	MO	MAC	446	853	t
132	Macedonia	MK	MKD	807	389	t
133	Madagascar	MG	MDG	450	261	t
134	Malawi	MW	MWI	454	265	t
135	Malaysia	MY	MYS	458	060	t
136	Maldives	MV	MDV	462	960	t
137	Mali	ML	MLI	466	223	t
138	Malta	MT	MLT	470	356	t
139	Marshall Islands	MH	MHL	584	692	t
140	Martinique	MQ	MTQ	474	596	t
141	Mauritania	MR	MRT	478	222	t
142	Mauritius	MU	MUS	480	230	t
143	Mayotte Island	YT	MYT	175	269	t
144	Mexico	MX	MEX	484	052	t
145	Micronesia	FM	FSM	583	691	t
146	Moldova	MD	MDA	498	373	t
147	Monaco	MC	MCO	492	377	t
148	Mongolia	MN	MNG	496	976	t
149	Montenegro	ME	MNE	499	382	t
150	Montserrat	MS	MSR	500	664	t
151	Morocco	MA	MAR	504	212	t
152	Mozambique	MZ	MOZ	508	258	t
153	Namibia	NA	NAM	516	264	t
154	Nauru	NR	NRU	520	674	t
155	Nepal	NP	NPL	524	977	t
156	Netherlands Antilles	AN	ANT	530	599	t
157	New Caledonia	NC	NCL	540	687	t
158	New Zealand	NZ	NZL	554	064	t
159	Nicaragua	NI	NIC	558	505	t
160	Niger	NE	NER	562	227	t
161	Nigeria	NG	NGA	566	234	t
162	Niue	NU	NIU	570	683	t
163	Norfolk Island	NF	NFK	574	672	t
164	Norway	NO	NOR	578	047	t
165	Oman	OM	OMN	512	968	t
166	Pakistan	PK	PAK	586	092	t
167	Palau	PW	PLW	585	680	t
168	Palestine	PS	PSE	275	970	t
169	Panama	PA	PAN	591	507	t
170	Papua New Guinea	PG	PNG	598	675	t
171	Paraguay	PY	PRY	600	595	t
172	Peru	PE	PER	604	051	t
173	Philippines	PH	PHL	608	063	t
174	Poland	PL	POL	616	048	t
175	Puerto Rico	PR	PRI	630	787	t
176	Qatar	QA	QAT	634	974	t
177	Reunion Island	RE	REU	638	262	t
178	Romania	RO	ROU	642	040	t
179	Rwanda	RW	RWA	646	250	t
180	St. Helena	SH	SHN	654	290	t
181	St. Kitts	KN	KNA	659	869	t
182	St. Lucia	LC	LCA	662	758	t
183	St. Pierre & Miquelon	PM	SPM	666	508	t
184	St. Vincent	VC	VCT	670	784	t
185	San Marino	SM	SMR	674	378	t
186	Sao Tome & Principe	ST	STP	678	239	t
187	Saudi Arabia	SA	SAU	682	966	t
188	Senegal	SN	SEN	686	221	t
189	Serbia	RS	SRB	688	381	t
190	Seychelles	SC	SYC	690	248	t
191	Sierra Leone	SL	SLE	694	249	t
192	Slovakia	SK	SVK	703	421	t
193	Slovenia	SI	SVN	705	386	t
194	Solomon Islands	SB	SLB	90	677	t
195	Somalia	SO	SOM	706	252	t
196	South Africa	ZA	ZAF	710	027	t
197	Sri Lanka	LK	LKA	144	094	t
198	Sudan	SD	SDN	736	095	t
199	Suriname	SR	SUR	740	597	t
200	Swaziland	SZ	SWZ	748	268	t
201	Sweden	SE	SWE	752	046	t
202	Switzerland	CH	CHE	756	041	t
203	Syria	SY	SYR	760	963	t
204	Taiwan	TW	TWN	158	886	t
205	Tajikistan	TJ	TJK	762	992	t
206	Tanzania	TZ	TZA	834	255	t
207	Thailand	TH	THA	764	066	t
208	Togo	TG	TGO	768	228	t
209	Tonga	TO	TON	776	676	t
210	Trinidad & Tobago	TT	TTO	780	868	t
211	Tunisia	TN	TUN	788	216	t
212	Turkmenistan	TM	TKM	795	993	t
213	Turks & Caicos	TC	TCA	796	649	t
214	Tuvalu	TV	TUV	798	688	t
215	Uganda	UG	UGA	800	256	t
216	Ukraine	UA	UKR	804	380	t
217	United Arab Emirates	AE	ARE	784	971	t
218	Uruguay	UY	URY	858	598	t
219	Uzbekistan	UZ	UZB	860	998	t
220	Vanuatu	VU	VUT	548	678	t
221	Vatican City	VA	VAT	336	039	t
222	Venezuela	VE	VEN	862	058	t
223	Wallis & Futuna	WF	WLF	876	681	t
224	Western Samoa	EH	ESH	732	685	t
225	Yemen	YE	YEM	887	967	t
226	Zambia	ZM	ZMB	894	260	t
227	Zimbabwe	ZW	ZWE	716	263	t
\.


--
-- Data for Name: cyrususer; Type: TABLE DATA; Schema: public; Owner: root
--

COPY cyrususer (userid, password_) FROM stdin;
\.


--
-- Data for Name: cyrusvirtual; Type: TABLE DATA; Schema: public; Owner: root
--

COPY cyrusvirtual (emailaddress, userid) FROM stdin;
\.


--
-- Data for Name: dlfileentry; Type: TABLE DATA; Schema: public; Owner: root
--

COPY dlfileentry (uuid_, fileentryid, groupid, companyid, userid, username, versionuserid, versionusername, createdate, modifieddate, folderid, name, extension, mimetype, title, description, extrasettings, version, size_, readcount) FROM stdin;
\.


--
-- Data for Name: dlfilerank; Type: TABLE DATA; Schema: public; Owner: root
--

COPY dlfilerank (filerankid, groupid, companyid, userid, createdate, fileentryid) FROM stdin;
\.


--
-- Data for Name: dlfileshortcut; Type: TABLE DATA; Schema: public; Owner: root
--

COPY dlfileshortcut (uuid_, fileshortcutid, groupid, companyid, userid, username, createdate, modifieddate, folderid, tofileentryid, status, statusbyuserid, statusbyusername, statusdate) FROM stdin;
\.


--
-- Data for Name: dlfileversion; Type: TABLE DATA; Schema: public; Owner: root
--

COPY dlfileversion (fileversionid, groupid, companyid, userid, username, createdate, fileentryid, extension, mimetype, title, description, changelog, extrasettings, version, size_, status, statusbyuserid, statusbyusername, statusdate) FROM stdin;
\.


--
-- Data for Name: dlfolder; Type: TABLE DATA; Schema: public; Owner: root
--

COPY dlfolder (uuid_, folderid, groupid, companyid, userid, username, createdate, modifieddate, parentfolderid, name, description, lastpostdate) FROM stdin;
\.


--
-- Data for Name: emailaddress; Type: TABLE DATA; Schema: public; Owner: root
--

COPY emailaddress (emailaddressid, companyid, userid, username, createdate, modifieddate, classnameid, classpk, address, typeid, primary_) FROM stdin;
\.


--
-- Data for Name: expandocolumn; Type: TABLE DATA; Schema: public; Owner: root
--

COPY expandocolumn (columnid, companyid, tableid, name, type_, defaultdata, typesettings) FROM stdin;
\.


--
-- Data for Name: expandorow; Type: TABLE DATA; Schema: public; Owner: root
--

COPY expandorow (rowid_, companyid, tableid, classpk) FROM stdin;
\.


--
-- Data for Name: expandotable; Type: TABLE DATA; Schema: public; Owner: root
--

COPY expandotable (tableid, companyid, classnameid, name) FROM stdin;
\.


--
-- Data for Name: expandovalue; Type: TABLE DATA; Schema: public; Owner: root
--

COPY expandovalue (valueid, companyid, tableid, columnid, rowid_, classnameid, classpk, data_) FROM stdin;
\.


--
-- Data for Name: group_; Type: TABLE DATA; Schema: public; Owner: root
--

COPY group_ (groupid, companyid, creatoruserid, classnameid, classpk, parentgroupid, livegroupid, name, description, type_, typesettings, friendlyurl, active_) FROM stdin;
10154	10136	10140	10012	10154	0	0	Control Panel		3		/control_panel	t
10162	10136	10140	10012	10162	0	0	Guest		1		/guest	t
10171	10136	10140	10170	10140	0	0	User Personal Community		3		/personal_community	t
10174	10136	10140	10008	10136	0	0	10136		0		/null	t
10180	10136	10178	10047	10178	0	0	10178		0		/test	t
10301	10136	10178	10012	10301	0	10291	Staging Site (Staging)		1		/staging-site-staging	t
10291	10136	10178	10012	10291	0	0	Staging Site		1	staged-portlet_8=true\nworkflowEnabled=false\nstaged-portlet_108=true\nstagedRemotely=false\nstaged-portlet_107=true\nstaged-portlet_56=true\nstaged-portlet_15=true\nstaged-portlet_28=true\nstaged-portlet_39=true\nstaged-portlet_54=true\nstaged-portlet_19=true\nstaged-portlet_110=true\nstaged-portlet_36=true\nstaged-portlet_33=true\nstaged-portlet_20=true\nstaged-portlet_31=true\nstaged-portlet_59=true\nstaged-portlet_25=true\nstaged=true\n	/staging-site	t
\.


--
-- Data for Name: groups_orgs; Type: TABLE DATA; Schema: public; Owner: root
--

COPY groups_orgs (groupid, organizationid) FROM stdin;
\.


--
-- Data for Name: groups_permissions; Type: TABLE DATA; Schema: public; Owner: root
--

COPY groups_permissions (groupid, permissionid) FROM stdin;
\.


--
-- Data for Name: groups_roles; Type: TABLE DATA; Schema: public; Owner: root
--

COPY groups_roles (groupid, roleid) FROM stdin;
\.


--
-- Data for Name: groups_usergroups; Type: TABLE DATA; Schema: public; Owner: root
--

COPY groups_usergroups (groupid, usergroupid) FROM stdin;
\.


--
-- Data for Name: igfolder; Type: TABLE DATA; Schema: public; Owner: root
--

COPY igfolder (uuid_, folderid, groupid, companyid, userid, username, createdate, modifieddate, parentfolderid, name, description) FROM stdin;
\.


--
-- Data for Name: igimage; Type: TABLE DATA; Schema: public; Owner: root
--

COPY igimage (uuid_, imageid, groupid, companyid, userid, username, createdate, modifieddate, folderid, name, description, smallimageid, largeimageid, custom1imageid, custom2imageid) FROM stdin;
\.


--
-- Data for Name: image; Type: TABLE DATA; Schema: public; Owner: root
--

COPY image (imageid, modifieddate, text_, type_, height, width, size_) FROM stdin;
\.


--
-- Data for Name: journalarticle; Type: TABLE DATA; Schema: public; Owner: root
--

COPY journalarticle (uuid_, id_, resourceprimkey, groupid, companyid, userid, username, createdate, modifieddate, articleid, version, title, urltitle, description, content, type_, structureid, templateid, displaydate, expirationdate, reviewdate, indexable, smallimage, smallimageid, smallimageurl, status, statusbyuserid, statusbyusername, statusdate) FROM stdin;
4dcf2e35-db94-4033-9464-d3e66007bda7	10324	10325	10301	10136	10178	Test Test	2017-03-10 17:07:30.383	2017-03-10 17:07:30.438	10323	1	Web Content Title	web-content-title		<?xml version='1.0' encoding='UTF-8'?><root><static-content><![CDATA[<p>\n\tWeb Content Content</p>]]></static-content></root>	general			2017-03-10 17:07:00	\N	\N	t	f	10326		0	10178	Test Test	2017-03-10 17:07:30.438
\.


--
-- Data for Name: journalarticleimage; Type: TABLE DATA; Schema: public; Owner: root
--

COPY journalarticleimage (articleimageid, groupid, articleid, version, elinstanceid, elname, languageid, tempimage) FROM stdin;
\.


--
-- Data for Name: journalarticleresource; Type: TABLE DATA; Schema: public; Owner: root
--

COPY journalarticleresource (uuid_, resourceprimkey, groupid, articleid) FROM stdin;
56464c4d-7795-4855-8dae-f220d1962eba	10325	10301	10323
\.


--
-- Data for Name: journalcontentsearch; Type: TABLE DATA; Schema: public; Owner: root
--

COPY journalcontentsearch (contentsearchid, groupid, companyid, privatelayout, layoutid, portletid, articleid) FROM stdin;
10332	10301	10136	f	1	56_INSTANCE_imA4	10323
\.


--
-- Data for Name: journalfeed; Type: TABLE DATA; Schema: public; Owner: root
--

COPY journalfeed (uuid_, id_, groupid, companyid, userid, username, createdate, modifieddate, feedid, name, description, type_, structureid, templateid, renderertemplateid, delta, orderbycol, orderbytype, targetlayoutfriendlyurl, targetportletid, contentfield, feedtype, feedversion) FROM stdin;
\.


--
-- Data for Name: journalstructure; Type: TABLE DATA; Schema: public; Owner: root
--

COPY journalstructure (uuid_, id_, groupid, companyid, userid, username, createdate, modifieddate, structureid, parentstructureid, name, description, xsd) FROM stdin;
\.


--
-- Data for Name: journaltemplate; Type: TABLE DATA; Schema: public; Owner: root
--

COPY journaltemplate (uuid_, id_, groupid, companyid, userid, username, createdate, modifieddate, templateid, structureid, name, description, xsl, langtype, cacheable, smallimage, smallimageid, smallimageurl) FROM stdin;
\.


--
-- Data for Name: layout; Type: TABLE DATA; Schema: public; Owner: root
--

COPY layout (uuid_, plid, groupid, companyid, privatelayout, layoutid, parentlayoutid, name, title, description, type_, typesettings, hidden_, friendlyurl, iconimage, iconimageid, themeid, colorschemeid, wapthemeid, wapcolorschemeid, css, priority, layoutprototypeid, dlfolderid) FROM stdin;
b317a8cd-bd0e-4f47-bcdd-be911434fa6b	10157	10154	10136	t	1	0	<?xml version='1.0' encoding='UTF-8'?><root available-locales="en_US" default-locale="en_US"><name language-id="en_US">Control Panel</name></root>			control_panel		f	/manage	f	0						0	0	0
2e724872-18d6-49eb-b55b-ebda0892c4f4	10165	10162	10136	f	1	0	<?xml version='1.0' encoding='UTF-8'?><root available-locales="en_US" default-locale="en_US"><name language-id="en_US">Welcome</name></root>			portlet	layout-template-id=2_columns_ii\ncolumn-2=47,\ncolumn-1=58,\n	f	/home	f	0						0	0	0
475b348d-1413-475c-b0c2-f127baf6a4c2	10274	10180	10136	t	1	0	<?xml version='1.0' encoding='UTF-8'?><root available-locales="en_US" default-locale="en_US"><name language-id="en_US">Welcome</name></root>			portlet	layout-template-id=2_columns_ii\ncolumn-2=29,8,\ncolumn-1=82,23,11,\n	f	/home	f	0						0	0	0
7917de54-4b3a-48aa-afcf-379706f06f62	10279	10180	10136	f	1	0	<?xml version='1.0' encoding='UTF-8'?><root available-locales="en_US" default-locale="en_US"><name language-id="en_US">Welcome</name></root>			portlet	layout-template-id=2_columns_ii\ncolumn-2=33,\ncolumn-1=82,3,\n	f	/home	f	0						0	0	0
24f60cdc-9b61-4832-ae21-d7e305617d4f	10295	10291	10136	f	1	0	<?xml version='1.0' encoding='UTF-8'?><root available-locales="en_US" default-locale="en_US"><name language-id="en_US">Staging Site Page</name></root>			portlet	layout-template-id=2_columns_ii\n	f	/staging-site-page	f	0						0	0	0
24f60cdc-9b61-4832-ae21-d7e305617d4f	10311	10301	10136	f	1	0	<?xml version='1.0' encoding='UTF-8'?><root available-locales="en_US" default-locale="en_US"><name language-id="en_US">Staging Site Page</name></root>			portlet	layout-template-id=2_columns_ii\ncolumn-1=56_INSTANCE_imA4\n	f	/staging-site-page	f	0						0	0	0
\.


--
-- Data for Name: layoutprototype; Type: TABLE DATA; Schema: public; Owner: root
--

COPY layoutprototype (layoutprototypeid, companyid, name, description, settings_, active_) FROM stdin;
\.


--
-- Data for Name: layoutset; Type: TABLE DATA; Schema: public; Owner: root
--

COPY layoutset (layoutsetid, groupid, companyid, privatelayout, logo, logoid, themeid, colorschemeid, wapthemeid, wapcolorschemeid, css, pagecount, settings_, layoutsetprototypeid) FROM stdin;
10156	10154	10136	f	f	0	classic	01	mobile	01		0		0
10155	10154	10136	t	f	0	classic	01	mobile	01		1		0
10163	10162	10136	t	f	0	classic	01	mobile	01		0		0
10164	10162	10136	f	f	0	classic	01	mobile	01		1		0
10172	10171	10136	t	f	0	classic	01	mobile	01		0		0
10173	10171	10136	f	f	0	classic	01	mobile	01		0		0
10175	10174	10136	t	f	0	classic	01	mobile	01		0		0
10176	10174	10136	f	f	0	classic	01	mobile	01		0		0
10181	10180	10136	t	f	0	classic	01	mobile	01		1		0
10182	10180	10136	f	f	0	classic	01	mobile	01		1		0
10292	10291	10136	t	f	0	classic	01	mobile	01		0		0
10302	10301	10136	t	f	0	classic	01	mobile	01		0		0
10293	10291	10136	f	f	0	classic	01	mobile	01		1	last-publish-date=1489165637940\n	0
10303	10301	10136	f	f	0	classic	01	mobile	01		1		0
\.


--
-- Data for Name: layoutsetprototype; Type: TABLE DATA; Schema: public; Owner: root
--

COPY layoutsetprototype (layoutsetprototypeid, companyid, name, description, settings_, active_) FROM stdin;
\.


--
-- Data for Name: listtype; Type: TABLE DATA; Schema: public; Owner: root
--

COPY listtype (listtypeid, name, type_) FROM stdin;
10000	billing	com.liferay.portal.model.Account.address
10001	other	com.liferay.portal.model.Account.address
10002	p-o-box	com.liferay.portal.model.Account.address
10003	shipping	com.liferay.portal.model.Account.address
10004	email-address	com.liferay.portal.model.Account.emailAddress
10005	email-address-2	com.liferay.portal.model.Account.emailAddress
10006	email-address-3	com.liferay.portal.model.Account.emailAddress
10007	fax	com.liferay.portal.model.Account.phone
10008	local	com.liferay.portal.model.Account.phone
10009	other	com.liferay.portal.model.Account.phone
10010	toll-free	com.liferay.portal.model.Account.phone
10011	tty	com.liferay.portal.model.Account.phone
10012	intranet	com.liferay.portal.model.Account.website
10013	public	com.liferay.portal.model.Account.website
11000	business	com.liferay.portal.model.Contact.address
11001	other	com.liferay.portal.model.Contact.address
11002	personal	com.liferay.portal.model.Contact.address
11003	email-address	com.liferay.portal.model.Contact.emailAddress
11004	email-address-2	com.liferay.portal.model.Contact.emailAddress
11005	email-address-3	com.liferay.portal.model.Contact.emailAddress
11006	business	com.liferay.portal.model.Contact.phone
11007	business-fax	com.liferay.portal.model.Contact.phone
11008	mobile-phone	com.liferay.portal.model.Contact.phone
11009	other	com.liferay.portal.model.Contact.phone
11010	pager	com.liferay.portal.model.Contact.phone
11011	personal	com.liferay.portal.model.Contact.phone
11012	personal-fax	com.liferay.portal.model.Contact.phone
11013	tty	com.liferay.portal.model.Contact.phone
11014	dr	com.liferay.portal.model.Contact.prefix
11015	mr	com.liferay.portal.model.Contact.prefix
11016	mrs	com.liferay.portal.model.Contact.prefix
11017	ms	com.liferay.portal.model.Contact.prefix
11020	ii	com.liferay.portal.model.Contact.suffix
11021	iii	com.liferay.portal.model.Contact.suffix
11022	iv	com.liferay.portal.model.Contact.suffix
11023	jr	com.liferay.portal.model.Contact.suffix
11024	phd	com.liferay.portal.model.Contact.suffix
11025	sr	com.liferay.portal.model.Contact.suffix
11026	blog	com.liferay.portal.model.Contact.website
11027	business	com.liferay.portal.model.Contact.website
11028	other	com.liferay.portal.model.Contact.website
11029	personal	com.liferay.portal.model.Contact.website
12000	billing	com.liferay.portal.model.Organization.address
12001	other	com.liferay.portal.model.Organization.address
12002	p-o-box	com.liferay.portal.model.Organization.address
12003	shipping	com.liferay.portal.model.Organization.address
12004	email-address	com.liferay.portal.model.Organization.emailAddress
12005	email-address-2	com.liferay.portal.model.Organization.emailAddress
12006	email-address-3	com.liferay.portal.model.Organization.emailAddress
12007	fax	com.liferay.portal.model.Organization.phone
12008	local	com.liferay.portal.model.Organization.phone
12009	other	com.liferay.portal.model.Organization.phone
12010	toll-free	com.liferay.portal.model.Organization.phone
12011	tty	com.liferay.portal.model.Organization.phone
12012	administrative	com.liferay.portal.model.Organization.service
12013	contracts	com.liferay.portal.model.Organization.service
12014	donation	com.liferay.portal.model.Organization.service
12015	retail	com.liferay.portal.model.Organization.service
12016	training	com.liferay.portal.model.Organization.service
12017	full-member	com.liferay.portal.model.Organization.status
12018	provisional-member	com.liferay.portal.model.Organization.status
12019	intranet	com.liferay.portal.model.Organization.website
12020	public	com.liferay.portal.model.Organization.website
\.


--
-- Data for Name: lock_; Type: TABLE DATA; Schema: public; Owner: root
--

COPY lock_ (uuid_, lockid, companyid, userid, username, createdate, classname, key_, owner, inheritable, expirationdate) FROM stdin;
\.


--
-- Data for Name: mbban; Type: TABLE DATA; Schema: public; Owner: root
--

COPY mbban (banid, groupid, companyid, userid, username, createdate, modifieddate, banuserid) FROM stdin;
\.


--
-- Data for Name: mbcategory; Type: TABLE DATA; Schema: public; Owner: root
--

COPY mbcategory (uuid_, categoryid, groupid, companyid, userid, username, createdate, modifieddate, parentcategoryid, name, description, threadcount, messagecount, lastpostdate) FROM stdin;
\.


--
-- Data for Name: mbdiscussion; Type: TABLE DATA; Schema: public; Owner: root
--

COPY mbdiscussion (discussionid, classnameid, classpk, threadid) FROM stdin;
10161	10014	10157	10159
10169	10014	10165	10167
10278	10014	10274	10276
10283	10014	10279	10281
10299	10014	10295	10297
10331	10087	10325	10329
\.


--
-- Data for Name: mbmailinglist; Type: TABLE DATA; Schema: public; Owner: root
--

COPY mbmailinglist (uuid_, mailinglistid, groupid, companyid, userid, username, createdate, modifieddate, categoryid, emailaddress, inprotocol, inservername, inserverport, inusessl, inusername, inpassword, inreadinterval, outemailaddress, outcustom, outservername, outserverport, outusessl, outusername, outpassword, allowanonymous, active_) FROM stdin;
\.


--
-- Data for Name: mbmessage; Type: TABLE DATA; Schema: public; Owner: root
--

COPY mbmessage (uuid_, messageid, groupid, companyid, userid, username, createdate, modifieddate, classnameid, classpk, categoryid, threadid, rootmessageid, parentmessageid, subject, body, attachments, anonymous, priority, allowpingbacks, status, statusbyuserid, statusbyusername, statusdate) FROM stdin;
8b7c26c5-3c3c-45d9-a6bc-76407e9f769f	10158	10154	10136	10140	 	2017-03-10 17:04:09.871	2017-03-10 17:04:09.871	10014	10157	-1	10159	10158	0	10157	10157	f	t	0	f	0	10140	 	2017-03-10 17:04:09.89
17bab393-e61a-420f-ae72-4d7a270b295c	10166	10162	10136	10140	 	2017-03-10 17:04:09.952	2017-03-10 17:04:09.952	10014	10165	-1	10167	10166	0	10165	10165	f	t	0	f	0	10140	 	2017-03-10 17:04:09.957
b664329b-89d8-410f-bdf6-c8b6534908c0	10275	10180	10136	10178	Test Test	2017-03-10 17:06:40.329	2017-03-10 17:06:40.329	10014	10274	-1	10276	10275	0	10274	10274	f	f	0	f	0	10178	Test Test	2017-03-10 17:06:40.334
7d63d8f1-aebb-45eb-8188-4d126ad8353d	10280	10180	10136	10178	Test Test	2017-03-10 17:06:40.354	2017-03-10 17:06:40.354	10014	10279	-1	10281	10280	0	10279	10279	f	f	0	f	0	10178	Test Test	2017-03-10 17:06:40.356
0e96f674-cf42-4f5c-aa1e-48f4109ae109	10296	10291	10136	10178	Test Test	2017-03-10 17:07:00.01	2017-03-10 17:07:00.01	10014	10295	-1	10297	10296	0	10295	10295	f	f	0	f	0	10178	Test Test	2017-03-10 17:07:00.012
fab94592-bc31-4afb-9941-d861b8b95b70	10328	10301	10136	10178	Test Test	2017-03-10 17:07:30.429	2017-03-10 17:07:30.429	10087	10325	-1	10329	10328	0	10325	10325	f	f	0	f	0	10178	Test Test	2017-03-10 17:07:30.435
\.


--
-- Data for Name: mbmessageflag; Type: TABLE DATA; Schema: public; Owner: root
--

COPY mbmessageflag (messageflagid, userid, modifieddate, threadid, messageid, flag) FROM stdin;
\.


--
-- Data for Name: mbstatsuser; Type: TABLE DATA; Schema: public; Owner: root
--

COPY mbstatsuser (statsuserid, groupid, userid, messagecount, lastpostdate) FROM stdin;
\.


--
-- Data for Name: mbthread; Type: TABLE DATA; Schema: public; Owner: root
--

COPY mbthread (threadid, groupid, companyid, categoryid, rootmessageid, rootmessageuserid, messagecount, viewcount, lastpostbyuserid, lastpostdate, priority, status, statusbyuserid, statusbyusername, statusdate) FROM stdin;
10159	10154	10136	-1	10158	10140	1	0	0	2017-03-10 17:04:09.89	0	0	10140	 	2017-03-10 17:04:09.89
10167	10162	10136	-1	10166	10140	1	0	0	2017-03-10 17:04:09.957	0	0	10140	 	2017-03-10 17:04:09.957
10276	10180	10136	-1	10275	10178	1	0	10178	2017-03-10 17:06:40.334	0	0	10178	Test Test	2017-03-10 17:06:40.334
10281	10180	10136	-1	10280	10178	1	0	10178	2017-03-10 17:06:40.356	0	0	10178	Test Test	2017-03-10 17:06:40.356
10297	10291	10136	-1	10296	10178	1	0	10178	2017-03-10 17:07:00.012	0	0	10178	Test Test	2017-03-10 17:07:00.012
10329	10301	10136	-1	10328	10178	1	0	10178	2017-03-10 17:07:30.435	0	0	10178	Test Test	2017-03-10 17:07:30.435
\.


--
-- Data for Name: membershiprequest; Type: TABLE DATA; Schema: public; Owner: root
--

COPY membershiprequest (membershiprequestid, groupid, companyid, userid, createdate, comments, replycomments, replydate, replieruserid, statusid) FROM stdin;
\.


--
-- Data for Name: organization_; Type: TABLE DATA; Schema: public; Owner: root
--

COPY organization_ (organizationid, companyid, parentorganizationid, leftorganizationid, rightorganizationid, name, type_, recursable, regionid, countryid, statusid, comments) FROM stdin;
\.


--
-- Data for Name: orggrouppermission; Type: TABLE DATA; Schema: public; Owner: root
--

COPY orggrouppermission (organizationid, groupid, permissionid) FROM stdin;
\.


--
-- Data for Name: orggrouprole; Type: TABLE DATA; Schema: public; Owner: root
--

COPY orggrouprole (organizationid, groupid, roleid) FROM stdin;
\.


--
-- Data for Name: orglabor; Type: TABLE DATA; Schema: public; Owner: root
--

COPY orglabor (orglaborid, organizationid, typeid, sunopen, sunclose, monopen, monclose, tueopen, tueclose, wedopen, wedclose, thuopen, thuclose, friopen, friclose, satopen, satclose) FROM stdin;
\.


--
-- Data for Name: passwordpolicy; Type: TABLE DATA; Schema: public; Owner: root
--

COPY passwordpolicy (passwordpolicyid, companyid, userid, username, createdate, modifieddate, defaultpolicy, name, description, changeable, changerequired, minage, checksyntax, allowdictionarywords, minalphanumeric, minlength, minlowercase, minnumbers, minsymbols, minuppercase, history, historycount, expireable, maxage, warningtime, gracelimit, lockout, maxfailure, lockoutduration, requireunlock, resetfailurecount, resetticketmaxage) FROM stdin;
10177	10136	10140	 	2017-03-10 17:04:10.233	2017-03-10 17:04:10.233	t	Default Password Policy	Default Password Policy	t	f	0	f	t	0	6	0	1	0	1	f	6	f	8640000	86400	0	f	3	0	t	600	86400
\.


--
-- Data for Name: passwordpolicyrel; Type: TABLE DATA; Schema: public; Owner: root
--

COPY passwordpolicyrel (passwordpolicyrelid, passwordpolicyid, classnameid, classpk) FROM stdin;
\.


--
-- Data for Name: passwordtracker; Type: TABLE DATA; Schema: public; Owner: root
--

COPY passwordtracker (passwordtrackerid, userid, createdate, password_) FROM stdin;
\.


--
-- Data for Name: permission_; Type: TABLE DATA; Schema: public; Owner: root
--

COPY permission_ (permissionid, companyid, actionid, resourceid) FROM stdin;
\.


--
-- Data for Name: phone; Type: TABLE DATA; Schema: public; Owner: root
--

COPY phone (phoneid, companyid, userid, username, createdate, modifieddate, classnameid, classpk, number_, extension, typeid, primary_) FROM stdin;
\.


--
-- Data for Name: pluginsetting; Type: TABLE DATA; Schema: public; Owner: root
--

COPY pluginsetting (pluginsettingid, companyid, pluginid, plugintype, roles, active_) FROM stdin;
\.


--
-- Data for Name: pollschoice; Type: TABLE DATA; Schema: public; Owner: root
--

COPY pollschoice (uuid_, choiceid, questionid, name, description) FROM stdin;
\.


--
-- Data for Name: pollsquestion; Type: TABLE DATA; Schema: public; Owner: root
--

COPY pollsquestion (uuid_, questionid, groupid, companyid, userid, username, createdate, modifieddate, title, description, expirationdate, lastvotedate) FROM stdin;
\.


--
-- Data for Name: pollsvote; Type: TABLE DATA; Schema: public; Owner: root
--

COPY pollsvote (voteid, userid, questionid, choiceid, votedate) FROM stdin;
\.


--
-- Data for Name: portalpreferences; Type: TABLE DATA; Schema: public; Owner: root
--

COPY portalpreferences (portalpreferencesid, ownerid, ownertype, preferences) FROM stdin;
10135	0	1	<portlet-preferences />
10142	10136	1	<portlet-preferences />
10270	10140	4	<portlet-preferences />
10284	10178	4	<portlet-preferences><preference><name>com.liferay.portal.util.SessionTreeJSClicks#layoutsTree</name><value>layoutsTree_layoutId_0_plid_0,</value></preference><preference><name>com.liferay.portal.util.SessionClicks#show-portlet-description-134</name><value>false</value></preference></portlet-preferences>
\.


--
-- Data for Name: portlet; Type: TABLE DATA; Schema: public; Owner: root
--

COPY portlet (id_, companyid, portletid, roles, active_) FROM stdin;
10184	10136	98		t
10185	10136	66		t
10186	10136	27		t
10187	10136	152		t
10188	10136	134		t
10189	10136	130		t
10190	10136	122		t
10191	10136	36		t
10192	10136	26		t
10193	10136	104		t
10194	10136	64		t
10195	10136	153		t
10196	10136	129		t
10197	10136	100		t
10198	10136	19		t
10199	10136	157		t
10200	10136	128		t
10201	10136	154		t
10202	10136	148		t
10203	10136	11		t
10204	10136	29		t
10205	10136	158		t
10206	10136	8		t
10207	10136	58		t
10208	10136	155		t
10209	10136	71		t
10210	10136	97		t
10211	10136	39		t
10212	10136	85		t
10213	10136	118		t
10214	10136	79		t
10215	10136	107		t
10216	10136	30		t
10217	10136	147		t
10218	10136	48		t
10219	10136	125		t
10220	10136	146		t
10221	10136	62		t
10222	10136	159		t
10223	10136	108		t
10224	10136	84		t
10225	10136	101		t
10226	10136	121		t
10227	10136	37		t
10228	10136	143		t
10229	10136	77		t
10230	10136	115		t
10231	10136	56		t
10232	10136	111		t
10233	10136	3		t
10234	10136	20		t
10235	10136	16		t
10236	10136	23		t
10237	10136	83		t
10238	10136	99		t
10239	10136	70		t
10240	10136	141		t
10241	10136	9		t
10242	10136	28		t
10243	10136	137		t
10244	10136	15		t
10245	10136	47		t
10246	10136	116		t
10247	10136	82		t
10248	10136	151		t
10249	10136	54		t
10250	10136	34		t
10251	10136	132		t
10252	10136	61		t
10253	10136	73		t
10254	10136	31		t
10255	10136	136		t
10256	10136	50		t
10257	10136	127		t
10258	10136	25		t
10259	10136	33		t
10260	10136	150		t
10261	10136	114		t
10262	10136	126		t
10263	10136	149		t
10264	10136	67		t
10265	10136	110		t
10266	10136	59		t
10267	10136	135		t
10268	10136	131		t
10269	10136	102		t
\.


--
-- Data for Name: portletitem; Type: TABLE DATA; Schema: public; Owner: root
--

COPY portletitem (portletitemid, groupid, companyid, userid, username, createdate, modifieddate, name, portletid, classnameid) FROM stdin;
\.


--
-- Data for Name: portletpreferences; Type: TABLE DATA; Schema: public; Owner: root
--

COPY portletpreferences (portletpreferencesid, ownerid, ownertype, plid, portletid, preferences) FROM stdin;
10271	0	3	10165	103	<portlet-preferences />
10272	0	3	10165	47	<portlet-preferences />
10273	0	3	10165	58	<portlet-preferences />
10285	0	3	10165	145	<portlet-preferences />
10286	0	3	10165	terms-of-use	<portlet-preferences />
10287	0	3	10165	password-reminder	<portlet-preferences />
10288	0	3	10157	160	<portlet-preferences />
10289	0	3	10157	145	<portlet-preferences />
10290	0	3	10157	134	<portlet-preferences />
10300	0	3	10165	88	<portlet-preferences />
10305	0	3	10295	20	<portlet-preferences />
10306	10291	2	0	15	<portlet-preferences />
10307	0	3	10295	31	<portlet-preferences />
10308	10291	2	0	25	<portlet-preferences />
10312	0	3	10311	20	<portlet-preferences></portlet-preferences>
10313	10301	2	0	15	<?xml version="1.0"?>\n\n<portlet-preferences owner-id="10291" owner-type="2" default-user="false" plid="0" portlet-id="15"/>
10314	0	3	10311	15	<portlet-preferences></portlet-preferences>
10315	10301	2	0	25	<?xml version="1.0"?>\n\n<portlet-preferences owner-id="10291" owner-type="2" default-user="false" plid="0" portlet-id="25"/>
10316	0	3	10165	49	<portlet-preferences />
10317	0	3	10295	103	<portlet-preferences />
10318	0	3	10295	145	<portlet-preferences />
10319	0	3	10311	103	<portlet-preferences />
10320	0	3	10311	145	<portlet-preferences />
10321	0	3	10311	87	<portlet-preferences />
10322	0	3	10311	56_INSTANCE_imA4	<portlet-preferences><preference><name>group-id</name><value>10301</value></preference><preference><name>article-id</name><value>10323</value></preference></portlet-preferences>
\.


--
-- Data for Name: quartz_blob_triggers; Type: TABLE DATA; Schema: public; Owner: root
--

COPY quartz_blob_triggers (trigger_name, trigger_group, blob_data) FROM stdin;
\.


--
-- Data for Name: quartz_calendars; Type: TABLE DATA; Schema: public; Owner: root
--

COPY quartz_calendars (calendar_name, calendar) FROM stdin;
\.


--
-- Data for Name: quartz_cron_triggers; Type: TABLE DATA; Schema: public; Owner: root
--

COPY quartz_cron_triggers (trigger_name, trigger_group, cron_expression, time_zone_id) FROM stdin;
\.


--
-- Data for Name: quartz_fired_triggers; Type: TABLE DATA; Schema: public; Owner: root
--

COPY quartz_fired_triggers (entry_id, trigger_name, trigger_group, is_volatile, instance_name, fired_time, priority, state, job_name, job_group, is_stateful, requests_recovery) FROM stdin;
\.


--
-- Data for Name: quartz_job_details; Type: TABLE DATA; Schema: public; Owner: root
--

COPY quartz_job_details (job_name, job_group, description, job_class_name, is_durable, is_volatile, is_stateful, requests_recovery, job_data) FROM stdin;
\.


--
-- Data for Name: quartz_job_listeners; Type: TABLE DATA; Schema: public; Owner: root
--

COPY quartz_job_listeners (job_name, job_group, job_listener) FROM stdin;
\.


--
-- Data for Name: quartz_locks; Type: TABLE DATA; Schema: public; Owner: root
--

COPY quartz_locks (lock_name) FROM stdin;
TRIGGER_ACCESS
JOB_ACCESS
CALENDAR_ACCESS
STATE_ACCESS
MISFIRE_ACCESS
\.


--
-- Data for Name: quartz_paused_trigger_grps; Type: TABLE DATA; Schema: public; Owner: root
--

COPY quartz_paused_trigger_grps (trigger_group) FROM stdin;
\.


--
-- Data for Name: quartz_scheduler_state; Type: TABLE DATA; Schema: public; Owner: root
--

COPY quartz_scheduler_state (instance_name, last_checkin_time, checkin_interval) FROM stdin;
\.


--
-- Data for Name: quartz_simple_triggers; Type: TABLE DATA; Schema: public; Owner: root
--

COPY quartz_simple_triggers (trigger_name, trigger_group, repeat_count, repeat_interval, times_triggered) FROM stdin;
\.


--
-- Data for Name: quartz_trigger_listeners; Type: TABLE DATA; Schema: public; Owner: root
--

COPY quartz_trigger_listeners (trigger_name, trigger_group, trigger_listener) FROM stdin;
\.


--
-- Data for Name: quartz_triggers; Type: TABLE DATA; Schema: public; Owner: root
--

COPY quartz_triggers (trigger_name, trigger_group, job_name, job_group, is_volatile, description, next_fire_time, prev_fire_time, priority, trigger_state, trigger_type, start_time, end_time, calendar_name, misfire_instr, job_data) FROM stdin;
\.


--
-- Data for Name: ratingsentry; Type: TABLE DATA; Schema: public; Owner: root
--

COPY ratingsentry (entryid, companyid, userid, username, createdate, modifieddate, classnameid, classpk, score) FROM stdin;
\.


--
-- Data for Name: ratingsstats; Type: TABLE DATA; Schema: public; Owner: root
--

COPY ratingsstats (statsid, classnameid, classpk, totalentries, totalscore, averagescore) FROM stdin;
\.


--
-- Data for Name: region; Type: TABLE DATA; Schema: public; Owner: root
--

COPY region (regionid, countryid, regioncode, name, active_) FROM stdin;
1001	1	AB	Alberta	t
1002	1	BC	British Columbia	t
1003	1	MB	Manitoba	t
1004	1	NB	New Brunswick	t
1005	1	NL	Newfoundland and Labrador	t
1006	1	NT	Northwest Territories	t
1007	1	NS	Nova Scotia	t
1008	1	NU	Nunavut	t
1009	1	ON	Ontario	t
1010	1	PE	Prince Edward Island	t
1011	1	QC	Quebec	t
1012	1	SK	Saskatchewan	t
1013	1	YT	Yukon	t
2001	2	CN-34	Anhui	t
2002	2	CN-92	Aomen	t
2003	2	CN-11	Beijing	t
2004	2	CN-50	Chongqing	t
2005	2	CN-35	Fujian	t
2006	2	CN-62	Gansu	t
2007	2	CN-44	Guangdong	t
2008	2	CN-45	Guangxi	t
2009	2	CN-52	Guizhou	t
2010	2	CN-46	Hainan	t
2011	2	CN-13	Hebei	t
2012	2	CN-23	Heilongjiang	t
2013	2	CN-41	Henan	t
2014	2	CN-42	Hubei	t
2015	2	CN-43	Hunan	t
2016	2	CN-32	Jiangsu	t
2017	2	CN-36	Jiangxi	t
2018	2	CN-22	Jilin	t
2019	2	CN-21	Liaoning	t
2020	2	CN-15	Nei Mongol	t
2021	2	CN-64	Ningxia	t
2022	2	CN-63	Qinghai	t
2023	2	CN-61	Shaanxi	t
2024	2	CN-37	Shandong	t
2025	2	CN-31	Shanghai	t
2026	2	CN-14	Shanxi	t
2027	2	CN-51	Sichuan	t
2028	2	CN-71	Taiwan	t
2029	2	CN-12	Tianjin	t
2030	2	CN-91	Xianggang	t
2031	2	CN-65	Xinjiang	t
2032	2	CN-54	Xizang	t
2033	2	CN-53	Yunnan	t
2034	2	CN-33	Zhejiang	t
3001	3	A	Alsace	t
3002	3	B	Aquitaine	t
3003	3	C	Auvergne	t
3004	3	P	Basse-Normandie	t
3005	3	D	Bourgogne	t
3006	3	E	Bretagne	t
3007	3	F	Centre	t
3008	3	G	Champagne-Ardenne	t
3009	3	H	Corse	t
3010	3	GF	Guyane	t
3011	3	I	Franche Comté	t
3012	3	GP	Guadeloupe	t
3013	3	Q	Haute-Normandie	t
3014	3	J	Île-de-France	t
3015	3	K	Languedoc-Roussillon	t
3016	3	L	Limousin	t
3017	3	M	Lorraine	t
3018	3	MQ	Martinique	t
3019	3	N	Midi-Pyrénées	t
3020	3	O	Nord Pas de Calais	t
3021	3	R	Pays de la Loire	t
3022	3	S	Picardie	t
3023	3	T	Poitou-Charentes	t
3025	3	RE	Réunion	t
4002	4	BY	Bayern	t
4003	4	BE	Berlin	t
4004	4	BR	Brandenburg	t
4006	4	HH	Hamburg	t
4008	4	MV	Mecklenburg-Vorpommern	t
4010	4	NW	Nordrhein-Westfalen	t
4013	4	SN	Sachsen	t
4016	4	TH	Thüringen	t
8001	8	AG	Agrigento	t
8003	8	AN	Ancona	t
8005	8	AR	Arezzo	t
8007	8	AT	Asti	t
8010	8	BT	Barletta-Andria-Trani	t
8012	8	BN	Benevento	t
8014	8	BI	Biella	t
8016	8	BZ	Bolzano	t
8017	8	BS	Brescia	t
8020	8	CL	Caltanissetta	t
8024	8	CT	Catania	t
8031	8	CN	Cuneo	t
8032	8	EN	Enna	t
8033	8	FM	Fermo	t
8037	8	FC	Forli-Cesena	t
8039	8	GE	Genova	t
8041	8	GR	Grosseto	t
8043	8	IS	Isernia	t
8045	8	SP	La Spezia	t
8046	8	LT	Latina	t
8054	8	MS	Massa-Carrara	t
8056	8	MA	Medio Campidano	t
8057	8	ME	Messina	t
8059	8	MO	Modena	t
8060	8	MZ	Monza	t
8065	8	OT	Olbia-Tempio	t
8067	8	PD	Padova	t
8068	8	PA	Palermo	t
8070	8	PV	Pavia	t
8075	8	PI	Pisa	t
8079	8	PO	Prato	t
8080	8	RG	Ragusa	t
8081	8	RA	Ravenna	t
8082	8	RC	Reggio Calabria	t
8084	8	RI	Rieti	t
8085	8	RN	Rimini	t
8093	8	SO	Sondrio	t
8094	8	TA	Taranto	t
8096	8	TR	Terni	t
8098	8	TP	Trapani	t
8099	8	TN	Trento	t
8100	8	TV	Treviso	t
8102	8	UD	Udine	t
8104	8	VE	Venezia	t
8106	8	VC	Vercelli	t
8107	8	VR	Verona	t
8108	8	VV	Vibo Valentia	t
8110	8	VT	Viterbo	t
11002	11	FL	Flevoland	t
11003	11	FR	Friesland	t
11004	11	GE	Gelderland	t
11005	11	GR	Groningen	t
11008	11	NH	Noord-Holland	t
11010	11	UT	Utrecht	t
15002	15	AR	Aragon	t
15004	15	IB	Balearic Islands	t
15005	15	PV	Basque Country	t
15006	15	CN	Canary Islands	t
15007	15	CB	Cantabria	t
15008	15	CL	Castile and Leon	t
15009	15	CM	Castile-La Mancha	t
15010	15	CT	Catalonia	t
15012	15	EX	Extremadura	t
15013	15	GA	Galicia	t
15015	15	M	Madrid	t
15016	15	ML	Melilla	t
15017	15	MU	Murcia	t
15018	15	NA	Navarra	t
15019	15	VC	Valencia	t
19001	19	AL	Alabama	t
19003	19	AZ	Arizona	t
19004	19	AR	Arkansas	t
19005	19	CA	California	t
19006	19	CO	Colorado	t
19018	19	KY	Kentucky 	t
19019	19	LA	Louisiana 	t
19020	19	ME	Maine	t
19021	19	MD	Maryland	t
19022	19	MA	Massachusetts	t
19023	19	MI	Michigan	t
19025	19	MS	Mississippi	t
19026	19	MO	Missouri	t
19029	19	NV	Nevada	t
19030	19	NH	New Hampshire	t
19031	19	NJ	New Jersey	t
19032	19	NM	New Mexico	t
19034	19	NC	North Carolina	t
19035	19	ND	North Dakota	t
19040	19	PR	Puerto Rico	t
19041	19	RI	Rhode Island	t
19042	19	SC	South Carolina	t
19043	19	SD	South Dakota	t
19044	19	TN	Tennessee	t
19046	19	UT	Utah	t
19048	19	VA	Virginia	t
19049	19	WA	Washington	t
32001	32	ACT	Australian Capital Territory	t
32003	32	NT	Northern Territory	t
32005	32	SA	South Australia	t
32008	32	WA	Western Australia	t
202001	202	AG	Aargau	t
202002	202	AR	Appenzell Ausserrhoden	t
202003	202	AI	Appenzell Innerrhoden	t
202004	202	BL	Basel-Landschaft	t
202006	202	BE	Bern	t
202007	202	FR	Fribourg	t
202009	202	GL	Glarus	t
202010	202	GR	Graubünden	t
202011	202	JU	Jura	t
202012	202	LU	Lucerne	t
202015	202	OW	Obwalden	t
3026	3	V	Rhône-Alpes	t
4001	4	BW	Baden-Württemberg	t
4005	4	HB	Bremen	t
4007	4	HE	Hessen	t
4009	4	NI	Niedersachsen	t
4011	4	RP	Rheinland-Pfalz	t
4012	4	SL	Saarland	t
4014	4	ST	Sachsen-Anhalt	t
4015	4	SH	Schleswig-Holstein	t
8002	8	AL	Alessandria	t
8004	8	AO	Aosta	t
8006	8	AP	Ascoli Piceno	t
8008	8	AV	Avellino	t
8009	8	BA	Bari	t
8011	8	BL	Belluno	t
8013	8	BG	Bergamo	t
8015	8	BO	Bologna	t
8018	8	BR	Brindisi	t
8019	8	CA	Cagliari	t
8021	8	CB	Campobasso	t
8022	8	CI	Carbonia-Iglesias	t
8023	8	CE	Caserta	t
8025	8	CZ	Catanzaro	t
8026	8	CH	Chieti	t
8027	8	CO	Como	t
8028	8	CS	Cosenza	t
8029	8	CR	Cremona	t
8030	8	KR	Crotone	t
8034	8	FE	Ferrara	t
8035	8	FI	Firenze	t
8036	8	FG	Foggia	t
8038	8	FR	Frosinone	t
8040	8	GO	Gorizia	t
8042	8	IM	Imperia	t
8044	8	AQ	L'Aquila	t
8047	8	LE	Lecce	t
8048	8	LC	Lecco	t
8049	8	LI	Livorno	t
8050	8	LO	Lodi	t
8051	8	LU	Lucca	t
8052	8	MC	Macerata	t
8053	8	MN	Mantova	t
8055	8	MT	Matera	t
8058	8	MI	Milano	t
8061	8	NA	Napoli	t
8062	8	NO	Novara	t
8063	8	NU	Nuoro	t
8064	8	OG	Ogliastra	t
8066	8	OR	Oristano	t
8069	8	PR	Parma	t
8071	8	PG	Perugia	t
8072	8	PU	Pesaro e Urbino	t
8073	8	PE	Pescara	t
8074	8	PC	Piacenza	t
8076	8	PT	Pistoia	t
8077	8	PN	Pordenone	t
8078	8	PZ	Potenza	t
8083	8	RE	Reggio Emilia	t
8086	8	RM	Roma	t
8087	8	RO	Rovigo	t
8088	8	SA	Salerno	t
8089	8	SS	Sassari	t
8090	8	SV	Savona	t
8091	8	SI	Siena	t
8092	8	SR	Siracusa	t
8095	8	TE	Teramo	t
8097	8	TO	Torino	t
8101	8	TS	Trieste	t
8103	8	VA	Varese	t
8105	8	VB	Verbano-Cusio-Ossola	t
8109	8	VI	Vicenza	t
11001	11	DR	Drenthe	t
11006	11	LI	Limburg	t
11007	11	NB	Noord-Brabant	t
11009	11	OV	Overijssel	t
11011	11	ZE	Zeeland	t
11012	11	ZH	Zuid-Holland	t
15001	15	AN	Andalusia	t
15003	15	AS	Asturias	t
15011	15	CE	Ceuta	t
15014	15	LO	La Rioja	t
19002	19	AK	Alaska	t
19007	19	CT	Connecticut	t
19008	19	DC	District of Columbia	t
19009	19	DE	Delaware	t
19010	19	FL	Florida	t
19011	19	GA	Georgia	t
19012	19	HI	Hawaii	t
19013	19	ID	Idaho	t
19014	19	IL	Illinois	t
19015	19	IN	Indiana	t
19016	19	IA	Iowa	t
19017	19	KS	Kansas	t
19024	19	MN	Minnesota	t
19027	19	MT	Montana	t
19028	19	NE	Nebraska	t
19033	19	NY	New York	t
19036	19	OH	Ohio	t
19037	19	OK	Oklahoma 	t
19038	19	OR	Oregon	t
19039	19	PA	Pennsylvania	t
19045	19	TX	Texas	t
19047	19	VT	Vermont	t
19050	19	WV	West Virginia	t
19051	19	WI	Wisconsin	t
19052	19	WY	Wyoming	t
32002	32	NSW	New South Wales	t
32004	32	QLD	Queensland	t
32006	32	TAS	Tasmania	t
32007	32	VIC	Victoria	t
202005	202	BS	Basel-Stadt	t
202008	202	GE	Geneva	t
202013	202	NE	Neuchâtel	t
202014	202	NW	Nidwalden	t
202017	202	SZ	Schwyz	t
202018	202	SO	Solothurn	t
202023	202	VS	Valais	t
202024	202	VD	Vaud	t
202016	202	SH	Schaffhausen	t
202019	202	SG	St. Gallen	t
202020	202	TG	Thurgau	t
202021	202	TI	Ticino	t
202022	202	UR	Uri	t
202025	202	ZG	Zug	t
202026	202	ZH	Zürich	t
\.


--
-- Data for Name: release_; Type: TABLE DATA; Schema: public; Owner: root
--

COPY release_ (releaseid, createdate, modifieddate, servletcontextname, buildnumber, builddate, verified, teststring) FROM stdin;
1	2017-03-10 09:04:01.769264	2017-03-10 17:04:05.805	portal	6012	2011-07-27 00:00:00	t	You take the blue pill, the story ends, you wake up in your bed and believe whatever you want to believe. You take the red pill, you stay in Wonderland, and I show you how deep the rabbit hole goes.
\.


--
-- Data for Name: resource_; Type: TABLE DATA; Schema: public; Owner: root
--

COPY resource_ (resourceid, codeid, primkey) FROM stdin;
\.


--
-- Data for Name: resourceaction; Type: TABLE DATA; Schema: public; Owner: root
--

COPY resourceaction (resourceactionid, name, actionid, bitwisevalue) FROM stdin;
1	com.liferay.portlet.softwarecatalog	ADD_FRAMEWORK_VERSION	2
2	com.liferay.portlet.softwarecatalog	ADD_PRODUCT_ENTRY	4
3	com.liferay.portlet.softwarecatalog	PERMISSIONS	8
4	com.liferay.portal.model.Team	ASSIGN_MEMBERS	2
5	com.liferay.portal.model.Team	DELETE	4
6	com.liferay.portal.model.Team	PERMISSIONS	8
7	com.liferay.portal.model.Team	UPDATE	16
8	com.liferay.portal.model.Team	VIEW	1
9	com.liferay.portal.model.PasswordPolicy	ASSIGN_MEMBERS	2
10	com.liferay.portal.model.PasswordPolicy	DELETE	4
11	com.liferay.portal.model.PasswordPolicy	PERMISSIONS	8
12	com.liferay.portal.model.PasswordPolicy	UPDATE	16
13	com.liferay.portal.model.PasswordPolicy	VIEW	1
14	com.liferay.portlet.blogs.model.BlogsEntry	ADD_DISCUSSION	2
15	com.liferay.portlet.blogs.model.BlogsEntry	DELETE	4
16	com.liferay.portlet.blogs.model.BlogsEntry	DELETE_DISCUSSION	8
17	com.liferay.portlet.blogs.model.BlogsEntry	PERMISSIONS	16
18	com.liferay.portlet.blogs.model.BlogsEntry	UPDATE	32
19	com.liferay.portlet.blogs.model.BlogsEntry	UPDATE_DISCUSSION	64
20	com.liferay.portlet.blogs.model.BlogsEntry	VIEW	1
21	com.liferay.portlet.journal.model.JournalFeed	DELETE	2
22	com.liferay.portlet.journal.model.JournalFeed	PERMISSIONS	4
23	com.liferay.portlet.journal.model.JournalFeed	UPDATE	8
24	com.liferay.portlet.journal.model.JournalFeed	VIEW	1
25	com.liferay.portlet.wiki.model.WikiNode	ADD_ATTACHMENT	2
26	com.liferay.portlet.wiki.model.WikiNode	ADD_PAGE	4
27	com.liferay.portlet.wiki.model.WikiNode	DELETE	8
28	com.liferay.portlet.wiki.model.WikiNode	IMPORT	16
29	com.liferay.portlet.wiki.model.WikiNode	PERMISSIONS	32
30	com.liferay.portlet.wiki.model.WikiNode	SUBSCRIBE	64
31	com.liferay.portlet.wiki.model.WikiNode	UPDATE	128
32	com.liferay.portlet.wiki.model.WikiNode	VIEW	1
33	com.liferay.portlet.announcements.model.AnnouncementsEntry	DELETE	2
34	com.liferay.portlet.announcements.model.AnnouncementsEntry	UPDATE	4
35	com.liferay.portlet.announcements.model.AnnouncementsEntry	VIEW	1
36	com.liferay.portlet.announcements.model.AnnouncementsEntry	PERMISSIONS	8
37	com.liferay.portlet.bookmarks	ADD_ENTRY	2
38	com.liferay.portlet.bookmarks	ADD_FOLDER	4
39	com.liferay.portlet.bookmarks	PERMISSIONS	8
40	com.liferay.portlet.bookmarks	VIEW	1
41	com.liferay.portlet.asset.model.AssetVocabulary	DELETE	2
42	com.liferay.portlet.asset.model.AssetVocabulary	PERMISSIONS	4
43	com.liferay.portlet.asset.model.AssetVocabulary	UPDATE	8
44	com.liferay.portlet.asset.model.AssetVocabulary	VIEW	1
45	com.liferay.portlet.documentlibrary.model.DLFolder	ACCESS	2
46	com.liferay.portlet.documentlibrary.model.DLFolder	ADD_DOCUMENT	4
47	com.liferay.portlet.documentlibrary.model.DLFolder	ADD_SHORTCUT	8
48	com.liferay.portlet.documentlibrary.model.DLFolder	ADD_SUBFOLDER	16
49	com.liferay.portlet.documentlibrary.model.DLFolder	DELETE	32
50	com.liferay.portlet.documentlibrary.model.DLFolder	PERMISSIONS	64
51	com.liferay.portlet.documentlibrary.model.DLFolder	UPDATE	128
52	com.liferay.portlet.documentlibrary.model.DLFolder	VIEW	1
53	com.liferay.portlet.expando.model.ExpandoColumn	DELETE	2
54	com.liferay.portlet.expando.model.ExpandoColumn	PERMISSIONS	4
55	com.liferay.portlet.expando.model.ExpandoColumn	UPDATE	8
56	com.liferay.portlet.expando.model.ExpandoColumn	VIEW	1
57	com.liferay.portlet.documentlibrary	ADD_DOCUMENT	2
58	com.liferay.portlet.documentlibrary	ADD_FOLDER	4
59	com.liferay.portlet.documentlibrary	ADD_SHORTCUT	8
60	com.liferay.portlet.documentlibrary	PERMISSIONS	16
61	com.liferay.portlet.documentlibrary	VIEW	1
62	com.liferay.portlet.calendar.model.CalEvent	ADD_DISCUSSION	2
63	com.liferay.portlet.calendar.model.CalEvent	DELETE	4
64	com.liferay.portlet.calendar.model.CalEvent	DELETE_DISCUSSION	8
65	com.liferay.portlet.calendar.model.CalEvent	PERMISSIONS	16
66	com.liferay.portlet.calendar.model.CalEvent	UPDATE	32
67	com.liferay.portlet.calendar.model.CalEvent	UPDATE_DISCUSSION	64
68	com.liferay.portlet.calendar.model.CalEvent	VIEW	1
69	com.liferay.portlet.shopping.model.ShoppingCategory	ADD_ITEM	2
70	com.liferay.portlet.shopping.model.ShoppingCategory	ADD_SUBCATEGORY	4
71	com.liferay.portlet.shopping.model.ShoppingCategory	DELETE	8
72	com.liferay.portlet.shopping.model.ShoppingCategory	PERMISSIONS	16
73	com.liferay.portlet.shopping.model.ShoppingCategory	UPDATE	32
74	com.liferay.portlet.shopping.model.ShoppingCategory	VIEW	1
75	com.liferay.portlet.documentlibrary.model.DLFileShortcut	ADD_DISCUSSION	2
76	com.liferay.portlet.documentlibrary.model.DLFileShortcut	DELETE	4
77	com.liferay.portlet.documentlibrary.model.DLFileShortcut	DELETE_DISCUSSION	8
78	com.liferay.portlet.documentlibrary.model.DLFileShortcut	PERMISSIONS	16
79	com.liferay.portlet.documentlibrary.model.DLFileShortcut	UPDATE	32
80	com.liferay.portlet.documentlibrary.model.DLFileShortcut	UPDATE_DISCUSSION	64
81	com.liferay.portlet.documentlibrary.model.DLFileShortcut	VIEW	1
82	com.liferay.portlet.journal	ADD_ARTICLE	2
83	com.liferay.portlet.journal	ADD_FEED	4
84	com.liferay.portlet.journal	ADD_STRUCTURE	8
85	com.liferay.portlet.journal	ADD_TEMPLATE	16
86	com.liferay.portlet.journal	SUBSCRIBE	32
87	com.liferay.portlet.journal	PERMISSIONS	64
88	com.liferay.portlet.calendar	ADD_EVENT	2
89	com.liferay.portlet.calendar	EXPORT_ALL_EVENTS	4
90	com.liferay.portlet.calendar	PERMISSIONS	8
91	com.liferay.portal.model.LayoutPrototype	DELETE	2
92	com.liferay.portal.model.LayoutPrototype	PERMISSIONS	4
93	com.liferay.portal.model.LayoutPrototype	UPDATE	8
94	com.liferay.portal.model.LayoutPrototype	VIEW	1
95	com.liferay.portlet.tasks.model.TasksProposal	ADD_DISCUSSION	2
96	com.liferay.portlet.tasks.model.TasksProposal	DELETE	4
97	com.liferay.portlet.tasks.model.TasksProposal	DELETE_DISCUSSION	8
98	com.liferay.portlet.tasks.model.TasksProposal	UPDATE	16
99	com.liferay.portlet.tasks.model.TasksProposal	UPDATE_DISCUSSION	32
100	com.liferay.portlet.tasks.model.TasksProposal	VIEW	1
101	com.liferay.portlet.tasks.model.TasksProposal	PERMISSIONS	64
102	com.liferay.portal.model.Organization	APPROVE_PROPOSAL	2
103	com.liferay.portal.model.Organization	ASSIGN_MEMBERS	4
104	com.liferay.portal.model.Organization	ASSIGN_REVIEWER	8
105	com.liferay.portal.model.Organization	ASSIGN_USER_ROLES	16
106	com.liferay.portal.model.Organization	DELETE	32
107	com.liferay.portal.model.Organization	MANAGE_ANNOUNCEMENTS	64
108	com.liferay.portal.model.Organization	MANAGE_ARCHIVED_SETUPS	128
109	com.liferay.portal.model.Organization	MANAGE_LAYOUTS	256
110	com.liferay.portal.model.Organization	MANAGE_STAGING	512
111	com.liferay.portal.model.Organization	MANAGE_SUBORGANIZATIONS	1024
112	com.liferay.portal.model.Organization	MANAGE_TEAMS	2048
113	com.liferay.portal.model.Organization	MANAGE_USERS	4096
114	com.liferay.portal.model.Organization	PERMISSIONS	8192
115	com.liferay.portal.model.Organization	PUBLISH_STAGING	16384
116	com.liferay.portal.model.Organization	UPDATE	32768
117	com.liferay.portal.model.Organization	VIEW	1
118	com.liferay.portlet.imagegallery	ADD_FOLDER	2
119	com.liferay.portlet.imagegallery	ADD_IMAGE	4
120	com.liferay.portlet.imagegallery	PERMISSIONS	8
121	com.liferay.portlet.imagegallery	VIEW	1
122	com.liferay.portlet.softwarecatalog.model.SCLicense	DELETE	2
123	com.liferay.portlet.softwarecatalog.model.SCLicense	PERMISSIONS	4
124	com.liferay.portlet.softwarecatalog.model.SCLicense	UPDATE	8
125	com.liferay.portlet.softwarecatalog.model.SCLicense	VIEW	1
126	com.liferay.portlet.journal.model.JournalTemplate	DELETE	2
127	com.liferay.portlet.journal.model.JournalTemplate	PERMISSIONS	4
128	com.liferay.portlet.journal.model.JournalTemplate	UPDATE	8
129	com.liferay.portlet.journal.model.JournalTemplate	VIEW	1
130	com.liferay.portlet.journal.model.JournalArticle	ADD_DISCUSSION	2
131	com.liferay.portlet.journal.model.JournalArticle	DELETE	4
132	com.liferay.portlet.journal.model.JournalArticle	DELETE_DISCUSSION	8
133	com.liferay.portlet.journal.model.JournalArticle	EXPIRE	16
134	com.liferay.portlet.journal.model.JournalArticle	PERMISSIONS	32
135	com.liferay.portlet.journal.model.JournalArticle	UPDATE	64
136	com.liferay.portlet.journal.model.JournalArticle	UPDATE_DISCUSSION	128
137	com.liferay.portlet.journal.model.JournalArticle	VIEW	1
138	com.liferay.portlet.bookmarks.model.BookmarksFolder	ACCESS	2
139	com.liferay.portlet.bookmarks.model.BookmarksFolder	ADD_ENTRY	4
140	com.liferay.portlet.bookmarks.model.BookmarksFolder	ADD_SUBFOLDER	8
141	com.liferay.portlet.bookmarks.model.BookmarksFolder	DELETE	16
142	com.liferay.portlet.bookmarks.model.BookmarksFolder	PERMISSIONS	32
143	com.liferay.portlet.bookmarks.model.BookmarksFolder	UPDATE	64
144	com.liferay.portlet.bookmarks.model.BookmarksFolder	VIEW	1
145	com.liferay.portal.model.Group	APPROVE_PROPOSAL	2
146	com.liferay.portal.model.Group	ASSIGN_MEMBERS	4
147	com.liferay.portal.model.Group	ASSIGN_REVIEWER	8
148	com.liferay.portal.model.Group	ASSIGN_USER_ROLES	16
149	com.liferay.portal.model.Group	DELETE	32
150	com.liferay.portal.model.Group	MANAGE_ANNOUNCEMENTS	64
151	com.liferay.portal.model.Group	MANAGE_ARCHIVED_SETUPS	128
152	com.liferay.portal.model.Group	MANAGE_LAYOUTS	256
153	com.liferay.portal.model.Group	MANAGE_STAGING	512
154	com.liferay.portal.model.Group	MANAGE_TEAMS	1024
155	com.liferay.portal.model.Group	PERMISSIONS	2048
156	com.liferay.portal.model.Group	PUBLISH_STAGING	4096
157	com.liferay.portal.model.Group	PUBLISH_TO_REMOTE	8192
158	com.liferay.portal.model.Group	UPDATE	16384
159	com.liferay.portlet.journal.model.JournalStructure	DELETE	2
160	com.liferay.portlet.journal.model.JournalStructure	PERMISSIONS	4
161	com.liferay.portlet.journal.model.JournalStructure	UPDATE	8
162	com.liferay.portlet.journal.model.JournalStructure	VIEW	1
163	com.liferay.portlet.asset.model.AssetTag	DELETE	2
164	com.liferay.portlet.asset.model.AssetTag	PERMISSIONS	4
165	com.liferay.portlet.asset.model.AssetTag	UPDATE	8
166	com.liferay.portlet.asset.model.AssetTag	VIEW	1
167	com.liferay.portal.model.Layout	ADD_DISCUSSION	2
168	com.liferay.portal.model.Layout	DELETE	4
169	com.liferay.portal.model.Layout	DELETE_DISCUSSION	8
170	com.liferay.portal.model.Layout	UPDATE	16
171	com.liferay.portal.model.Layout	UPDATE_DISCUSSION	32
172	com.liferay.portal.model.Layout	VIEW	1
173	com.liferay.portal.model.Layout	PERMISSIONS	64
174	com.liferay.portlet.imagegallery.model.IGImage	DELETE	2
175	com.liferay.portlet.imagegallery.model.IGImage	PERMISSIONS	4
176	com.liferay.portlet.imagegallery.model.IGImage	UPDATE	8
177	com.liferay.portlet.imagegallery.model.IGImage	VIEW	1
178	com.liferay.portlet.asset	ADD_TAG	2
179	com.liferay.portlet.asset	PERMISSIONS	4
180	com.liferay.portlet.asset	ADD_CATEGORY	8
181	com.liferay.portlet.asset	ADD_VOCABULARY	16
182	com.liferay.portlet.messageboards	ADD_CATEGORY	2
183	com.liferay.portlet.messageboards	ADD_FILE	4
184	com.liferay.portlet.messageboards	ADD_MESSAGE	8
185	com.liferay.portlet.messageboards	BAN_USER	16
186	com.liferay.portlet.messageboards	MOVE_THREAD	32
187	com.liferay.portlet.messageboards	LOCK_THREAD	64
188	com.liferay.portlet.messageboards	PERMISSIONS	128
189	com.liferay.portlet.messageboards	REPLY_TO_MESSAGE	256
190	com.liferay.portlet.messageboards	SUBSCRIBE	512
191	com.liferay.portlet.messageboards	UPDATE_THREAD_PRIORITY	1024
192	com.liferay.portlet.messageboards	VIEW	1
193	com.liferay.portlet.polls	ADD_QUESTION	2
194	com.liferay.portlet.polls	PERMISSIONS	4
195	com.liferay.portlet.shopping.model.ShoppingItem	DELETE	2
196	com.liferay.portlet.shopping.model.ShoppingItem	PERMISSIONS	4
197	com.liferay.portlet.shopping.model.ShoppingItem	UPDATE	8
198	com.liferay.portlet.shopping.model.ShoppingItem	VIEW	1
199	com.liferay.portlet.bookmarks.model.BookmarksEntry	DELETE	2
200	com.liferay.portlet.bookmarks.model.BookmarksEntry	PERMISSIONS	4
201	com.liferay.portlet.bookmarks.model.BookmarksEntry	UPDATE	8
202	com.liferay.portlet.bookmarks.model.BookmarksEntry	VIEW	1
203	com.liferay.portlet.softwarecatalog.model.SCProductEntry	ADD_DISCUSSION	2
204	com.liferay.portlet.softwarecatalog.model.SCProductEntry	DELETE	4
205	com.liferay.portlet.softwarecatalog.model.SCProductEntry	DELETE_DISCUSSION	8
206	com.liferay.portlet.softwarecatalog.model.SCProductEntry	PERMISSIONS	16
207	com.liferay.portlet.softwarecatalog.model.SCProductEntry	UPDATE	32
208	com.liferay.portlet.softwarecatalog.model.SCProductEntry	UPDATE_DISCUSSION	64
209	com.liferay.portlet.softwarecatalog.model.SCProductEntry	VIEW	1
210	com.liferay.portal.model.User	DELETE	2
211	com.liferay.portal.model.User	IMPERSONATE	4
212	com.liferay.portal.model.User	PERMISSIONS	8
213	com.liferay.portal.model.User	UPDATE	16
214	com.liferay.portal.model.User	VIEW	1
215	com.liferay.portal.model.LayoutSetPrototype	DELETE	2
216	com.liferay.portal.model.LayoutSetPrototype	PERMISSIONS	4
217	com.liferay.portal.model.LayoutSetPrototype	UPDATE	8
218	com.liferay.portal.model.LayoutSetPrototype	VIEW	1
219	com.liferay.portlet.shopping	ADD_CATEGORY	2
220	com.liferay.portlet.shopping	ADD_ITEM	4
221	com.liferay.portlet.shopping	MANAGE_COUPONS	8
222	com.liferay.portlet.shopping	MANAGE_ORDERS	16
223	com.liferay.portlet.shopping	PERMISSIONS	32
224	com.liferay.portlet.shopping	VIEW	1
225	com.liferay.portlet.softwarecatalog.model.SCFrameworkVersion	DELETE	2
226	com.liferay.portlet.softwarecatalog.model.SCFrameworkVersion	PERMISSIONS	4
227	com.liferay.portlet.softwarecatalog.model.SCFrameworkVersion	UPDATE	8
228	com.liferay.portlet.wiki	ADD_NODE	2
229	com.liferay.portlet.wiki	PERMISSIONS	4
230	com.liferay.portlet.polls.model.PollsQuestion	ADD_VOTE	2
231	com.liferay.portlet.polls.model.PollsQuestion	DELETE	4
232	com.liferay.portlet.polls.model.PollsQuestion	PERMISSIONS	8
233	com.liferay.portlet.polls.model.PollsQuestion	UPDATE	16
234	com.liferay.portlet.polls.model.PollsQuestion	VIEW	1
235	com.liferay.portal.model.UserGroup	ASSIGN_MEMBERS	2
236	com.liferay.portal.model.UserGroup	DELETE	4
237	com.liferay.portal.model.UserGroup	MANAGE_ANNOUNCEMENTS	8
238	com.liferay.portal.model.UserGroup	PERMISSIONS	16
239	com.liferay.portal.model.UserGroup	MANAGE_LAYOUTS	32
240	com.liferay.portal.model.UserGroup	UPDATE	64
241	com.liferay.portal.model.UserGroup	VIEW	1
242	com.liferay.portlet.shopping.model.ShoppingOrder	DELETE	2
243	com.liferay.portlet.shopping.model.ShoppingOrder	PERMISSIONS	4
244	com.liferay.portlet.shopping.model.ShoppingOrder	UPDATE	8
245	com.liferay.portlet.shopping.model.ShoppingOrder	VIEW	1
246	com.liferay.portlet.imagegallery.model.IGFolder	ACCESS	2
247	com.liferay.portlet.imagegallery.model.IGFolder	ADD_IMAGE	4
248	com.liferay.portlet.imagegallery.model.IGFolder	ADD_SUBFOLDER	8
249	com.liferay.portlet.imagegallery.model.IGFolder	DELETE	16
250	com.liferay.portlet.imagegallery.model.IGFolder	PERMISSIONS	32
251	com.liferay.portlet.imagegallery.model.IGFolder	UPDATE	64
252	com.liferay.portlet.imagegallery.model.IGFolder	VIEW	1
253	com.liferay.portal.model.Role	ASSIGN_MEMBERS	2
254	com.liferay.portal.model.Role	DEFINE_PERMISSIONS	4
255	com.liferay.portal.model.Role	DELETE	8
256	com.liferay.portal.model.Role	MANAGE_ANNOUNCEMENTS	16
257	com.liferay.portal.model.Role	PERMISSIONS	32
258	com.liferay.portal.model.Role	UPDATE	64
259	com.liferay.portal.model.Role	VIEW	1
260	com.liferay.portlet.messageboards.model.MBCategory	ADD_FILE	2
261	com.liferay.portlet.messageboards.model.MBCategory	ADD_MESSAGE	4
262	com.liferay.portlet.messageboards.model.MBCategory	ADD_SUBCATEGORY	8
263	com.liferay.portlet.messageboards.model.MBCategory	DELETE	16
264	com.liferay.portlet.messageboards.model.MBCategory	LOCK_THREAD	32
265	com.liferay.portlet.messageboards.model.MBCategory	MOVE_THREAD	64
266	com.liferay.portlet.messageboards.model.MBCategory	PERMISSIONS	128
267	com.liferay.portlet.messageboards.model.MBCategory	REPLY_TO_MESSAGE	256
268	com.liferay.portlet.messageboards.model.MBCategory	SUBSCRIBE	512
269	com.liferay.portlet.messageboards.model.MBCategory	UPDATE	1024
270	com.liferay.portlet.messageboards.model.MBCategory	UPDATE_THREAD_PRIORITY	2048
271	com.liferay.portlet.messageboards.model.MBCategory	VIEW	1
272	com.liferay.portlet.wiki.model.WikiPage	ADD_DISCUSSION	2
273	com.liferay.portlet.wiki.model.WikiPage	DELETE	4
274	com.liferay.portlet.wiki.model.WikiPage	DELETE_DISCUSSION	8
275	com.liferay.portlet.wiki.model.WikiPage	PERMISSIONS	16
276	com.liferay.portlet.wiki.model.WikiPage	SUBSCRIBE	32
277	com.liferay.portlet.wiki.model.WikiPage	UPDATE	64
278	com.liferay.portlet.wiki.model.WikiPage	UPDATE_DISCUSSION	128
279	com.liferay.portlet.wiki.model.WikiPage	VIEW	1
280	com.liferay.portlet.asset.model.AssetCategory	ADD_CATEGORY	2
281	com.liferay.portlet.asset.model.AssetCategory	DELETE	4
282	com.liferay.portlet.asset.model.AssetCategory	PERMISSIONS	8
283	com.liferay.portlet.asset.model.AssetCategory	UPDATE	16
284	com.liferay.portlet.asset.model.AssetCategory	VIEW	1
285	com.liferay.portlet.messageboards.model.MBMessage	DELETE	2
286	com.liferay.portlet.messageboards.model.MBMessage	PERMISSIONS	4
287	com.liferay.portlet.messageboards.model.MBMessage	SUBSCRIBE	8
288	com.liferay.portlet.messageboards.model.MBMessage	UPDATE	16
289	com.liferay.portlet.messageboards.model.MBMessage	VIEW	1
290	com.liferay.portlet.blogs	ADD_ENTRY	2
291	com.liferay.portlet.blogs	PERMISSIONS	4
292	com.liferay.portlet.blogs	SUBSCRIBE	8
293	com.liferay.portlet.documentlibrary.model.DLFileEntry	ADD_DISCUSSION	2
294	com.liferay.portlet.documentlibrary.model.DLFileEntry	DELETE	4
295	com.liferay.portlet.documentlibrary.model.DLFileEntry	DELETE_DISCUSSION	8
296	com.liferay.portlet.documentlibrary.model.DLFileEntry	PERMISSIONS	16
297	com.liferay.portlet.documentlibrary.model.DLFileEntry	UPDATE	32
298	com.liferay.portlet.documentlibrary.model.DLFileEntry	UPDATE_DISCUSSION	64
299	com.liferay.portlet.documentlibrary.model.DLFileEntry	VIEW	1
300	98	ACCESS_IN_CONTROL_PANEL	2
301	98	ADD_TO_PAGE	4
302	98	CONFIGURATION	8
303	98	VIEW	1
304	66	VIEW	1
305	66	ADD_TO_PAGE	2
306	66	CONFIGURATION	4
307	156	VIEW	1
308	156	ADD_TO_PAGE	2
309	156	ACCESS_IN_CONTROL_PANEL	4
310	156	CONFIGURATION	8
311	152	ACCESS_IN_CONTROL_PANEL	2
312	152	CONFIGURATION	4
313	152	VIEW	1
314	27	VIEW	1
315	27	ADD_TO_PAGE	2
316	27	CONFIGURATION	4
317	88	VIEW	1
318	88	ADD_TO_PAGE	2
319	88	CONFIGURATION	4
320	87	VIEW	1
321	87	ADD_TO_PAGE	2
322	87	CONFIGURATION	4
323	134	ACCESS_IN_CONTROL_PANEL	2
324	134	CONFIGURATION	4
325	134	VIEW	1
326	130	ACCESS_IN_CONTROL_PANEL	2
327	130	CONFIGURATION	4
328	130	VIEW	1
329	122	VIEW	1
330	122	ADD_TO_PAGE	2
331	122	CONFIGURATION	4
332	36	ADD_TO_PAGE	2
333	36	CONFIGURATION	4
334	36	VIEW	1
335	26	VIEW	1
336	26	ADD_TO_PAGE	2
337	26	CONFIGURATION	4
338	104	VIEW	1
339	104	ADD_TO_PAGE	2
340	104	ACCESS_IN_CONTROL_PANEL	4
341	104	CONFIGURATION	8
342	153	ACCESS_IN_CONTROL_PANEL	2
343	153	CONFIGURATION	4
344	153	VIEW	1
345	64	VIEW	1
346	64	ADD_TO_PAGE	2
347	64	CONFIGURATION	4
348	129	ACCESS_IN_CONTROL_PANEL	2
349	129	CONFIGURATION	4
350	129	VIEW	1
351	100	VIEW	1
352	100	ADD_TO_PAGE	2
353	100	CONFIGURATION	4
354	157	ACCESS_IN_CONTROL_PANEL	2
355	157	CONFIGURATION	4
356	157	VIEW	1
357	19	ACCESS_IN_CONTROL_PANEL	2
358	19	ADD_TO_PAGE	4
359	19	CONFIGURATION	8
360	19	VIEW	1
361	160	VIEW	1
362	160	ADD_TO_PAGE	2
363	160	CONFIGURATION	4
364	128	ACCESS_IN_CONTROL_PANEL	2
365	128	CONFIGURATION	4
366	128	VIEW	1
367	86	VIEW	1
368	86	ADD_TO_PAGE	2
369	86	CONFIGURATION	4
370	154	ACCESS_IN_CONTROL_PANEL	2
371	154	CONFIGURATION	4
372	154	VIEW	1
373	148	VIEW	1
374	148	ADD_TO_PAGE	2
375	148	CONFIGURATION	4
376	11	ADD_TO_PAGE	2
377	11	CONFIGURATION	4
378	11	VIEW	1
379	120	VIEW	1
380	120	ADD_TO_PAGE	2
381	120	CONFIGURATION	4
382	29	ADD_TO_PAGE	2
383	29	CONFIGURATION	4
384	29	VIEW	1
385	158	ACCESS_IN_CONTROL_PANEL	2
386	158	CONFIGURATION	4
387	158	VIEW	1
388	124	VIEW	1
389	124	ADD_TO_PAGE	2
390	124	CONFIGURATION	4
391	8	ACCESS_IN_CONTROL_PANEL	2
392	8	ADD_TO_PAGE	4
393	8	CONFIGURATION	8
394	8	VIEW	1
395	58	ADD_TO_PAGE	2
396	58	CONFIGURATION	4
397	58	VIEW	1
398	155	ACCESS_IN_CONTROL_PANEL	2
399	155	VIEW	1
400	155	CONFIGURATION	4
401	97	VIEW	1
402	97	ADD_TO_PAGE	2
403	97	CONFIGURATION	4
404	71	ADD_TO_PAGE	2
405	71	CONFIGURATION	4
406	71	VIEW	1
407	39	VIEW	1
408	39	ADD_TO_PAGE	2
409	39	CONFIGURATION	4
410	85	ADD_TO_PAGE	2
411	85	CONFIGURATION	4
412	85	VIEW	1
413	118	VIEW	1
414	118	ADD_TO_PAGE	2
415	118	CONFIGURATION	4
416	107	VIEW	1
417	107	ADD_TO_PAGE	2
418	107	CONFIGURATION	4
419	79	CONFIGURATION	2
420	79	VIEW	1
421	79	ADD_TO_PAGE	4
422	30	VIEW	1
423	30	ADD_TO_PAGE	2
424	30	CONFIGURATION	4
425	147	ACCESS_IN_CONTROL_PANEL	2
426	147	CONFIGURATION	4
427	147	VIEW	1
428	48	VIEW	1
429	48	ADD_TO_PAGE	2
430	48	CONFIGURATION	4
431	125	ACCESS_IN_CONTROL_PANEL	2
432	125	CONFIGURATION	4
433	125	EXPORT_USER	8
434	125	VIEW	1
435	144	VIEW	1
436	144	ADD_TO_PAGE	2
437	144	CONFIGURATION	4
438	146	ACCESS_IN_CONTROL_PANEL	2
439	146	CONFIGURATION	4
440	146	VIEW	1
441	62	VIEW	1
442	62	ADD_TO_PAGE	2
443	62	CONFIGURATION	4
444	159	VIEW	1
445	159	ADD_TO_PAGE	2
446	159	CONFIGURATION	4
447	108	VIEW	1
448	108	ADD_TO_PAGE	2
449	108	CONFIGURATION	4
450	139	ACCESS_IN_CONTROL_PANEL	2
451	139	ADD_EXPANDO	4
452	139	CONFIGURATION	8
453	139	VIEW	1
454	84	ADD_ENTRY	2
455	84	ADD_TO_PAGE	4
456	84	CONFIGURATION	8
457	84	VIEW	1
458	101	VIEW	1
459	101	ADD_TO_PAGE	2
460	101	CONFIGURATION	4
461	121	VIEW	1
462	121	ADD_TO_PAGE	2
463	121	CONFIGURATION	4
464	49	VIEW	1
465	49	ADD_TO_PAGE	2
466	49	CONFIGURATION	4
467	143	VIEW	1
468	143	ADD_TO_PAGE	2
469	143	CONFIGURATION	4
470	37	VIEW	1
471	37	ADD_TO_PAGE	2
472	37	CONFIGURATION	4
473	77	VIEW	1
474	77	ADD_TO_PAGE	2
475	77	CONFIGURATION	4
476	115	VIEW	1
477	115	ADD_TO_PAGE	2
478	115	CONFIGURATION	4
479	56	ADD_TO_PAGE	2
480	56	CONFIGURATION	4
481	56	VIEW	1
482	111	VIEW	1
483	111	ADD_TO_PAGE	2
484	111	CONFIGURATION	4
485	142	VIEW	1
486	142	ADD_TO_PAGE	2
487	142	CONFIGURATION	4
488	3	VIEW	1
489	3	ADD_TO_PAGE	2
490	3	CONFIGURATION	4
491	20	ACCESS_IN_CONTROL_PANEL	2
492	20	ADD_TO_PAGE	4
493	20	CONFIGURATION	8
494	20	VIEW	1
495	145	VIEW	1
496	145	ADD_TO_PAGE	2
497	145	CONFIGURATION	4
498	16	PREFERENCES	2
499	16	GUEST_PREFERENCES	4
500	16	VIEW	1
501	16	ADD_TO_PAGE	8
502	16	CONFIGURATION	16
503	23	VIEW	1
504	23	ADD_TO_PAGE	2
505	23	CONFIGURATION	4
506	83	ADD_ENTRY	2
507	83	ADD_TO_PAGE	4
508	83	CONFIGURATION	8
509	83	VIEW	1
510	99	ACCESS_IN_CONTROL_PANEL	2
511	99	CONFIGURATION	4
512	99	VIEW	1
513	70	VIEW	1
514	70	ADD_TO_PAGE	2
515	70	CONFIGURATION	4
516	141	VIEW	1
517	141	ADD_TO_PAGE	2
518	141	CONFIGURATION	4
519	9	VIEW	1
520	9	ADD_TO_PAGE	2
521	9	CONFIGURATION	4
522	137	ACCESS_IN_CONTROL_PANEL	2
523	137	CONFIGURATION	4
524	137	VIEW	1
525	28	ACCESS_IN_CONTROL_PANEL	2
526	28	ADD_TO_PAGE	4
527	28	CONFIGURATION	8
528	28	VIEW	1
529	133	VIEW	1
530	133	ADD_TO_PAGE	2
531	133	CONFIGURATION	4
532	116	VIEW	1
533	116	ADD_TO_PAGE	2
534	116	CONFIGURATION	4
535	47	VIEW	1
536	47	ADD_TO_PAGE	2
537	47	CONFIGURATION	4
538	15	ACCESS_IN_CONTROL_PANEL	2
539	15	ADD_TO_PAGE	4
540	15	CONFIGURATION	8
541	15	VIEW	1
542	82	VIEW	1
543	82	ADD_TO_PAGE	2
544	82	CONFIGURATION	4
545	103	VIEW	1
546	103	ADD_TO_PAGE	2
547	103	CONFIGURATION	4
548	151	ACCESS_IN_CONTROL_PANEL	2
549	151	CONFIGURATION	4
550	151	VIEW	1
551	140	VIEW	1
552	140	ADD_TO_PAGE	2
553	140	ACCESS_IN_CONTROL_PANEL	4
554	140	CONFIGURATION	8
555	54	VIEW	1
556	54	ADD_TO_PAGE	2
557	54	CONFIGURATION	4
558	132	ACCESS_IN_CONTROL_PANEL	2
559	132	CONFIGURATION	4
560	132	VIEW	1
561	34	ADD_TO_PAGE	2
562	34	CONFIGURATION	4
563	34	VIEW	1
564	61	VIEW	1
565	61	ADD_TO_PAGE	2
566	61	CONFIGURATION	4
567	73	ADD_TO_PAGE	2
568	73	CONFIGURATION	4
569	73	VIEW	1
570	31	ACCESS_IN_CONTROL_PANEL	2
571	31	ADD_TO_PAGE	4
572	31	CONFIGURATION	8
573	31	VIEW	1
574	136	ACCESS_IN_CONTROL_PANEL	2
575	136	CONFIGURATION	4
576	136	VIEW	1
577	127	ACCESS_IN_CONTROL_PANEL	2
578	127	CONFIGURATION	4
579	127	VIEW	1
580	50	VIEW	1
581	50	ADD_TO_PAGE	2
582	50	CONFIGURATION	4
583	25	ACCESS_IN_CONTROL_PANEL	2
584	25	CONFIGURATION	4
585	25	VIEW	1
586	90	ADD_COMMUNITY	2
587	90	ADD_LAYOUT_PROTOTYPE	4
588	90	ADD_LAYOUT_SET_PROTOTYPE	8
589	90	ADD_LICENSE	16
590	90	ADD_ORGANIZATION	32
591	90	ADD_PASSWORD_POLICY	64
592	90	ADD_ROLE	128
593	90	ADD_USER	256
594	90	ADD_USER_GROUP	512
595	90	CONFIGURATION	1024
596	90	EXPORT_USER	2048
597	90	ADD_TO_PAGE	4096
598	90	VIEW	1
599	150	ACCESS_IN_CONTROL_PANEL	2
600	150	CONFIGURATION	4
601	150	VIEW	1
602	113	VIEW	1
603	113	ADD_TO_PAGE	2
604	113	CONFIGURATION	4
605	33	ACCESS_IN_CONTROL_PANEL	2
606	33	ADD_TO_PAGE	4
607	33	CONFIGURATION	8
608	33	VIEW	1
609	2	VIEW	1
610	2	ADD_TO_PAGE	2
611	2	ACCESS_IN_CONTROL_PANEL	4
612	2	CONFIGURATION	8
613	119	VIEW	1
614	119	ADD_TO_PAGE	2
615	119	CONFIGURATION	4
616	126	ACCESS_IN_CONTROL_PANEL	2
617	126	CONFIGURATION	4
618	126	VIEW	1
619	114	VIEW	1
620	114	ADD_TO_PAGE	2
621	114	CONFIGURATION	4
622	149	ACCESS_IN_CONTROL_PANEL	2
623	149	CONFIGURATION	4
624	149	VIEW	1
625	67	VIEW	1
626	67	ADD_TO_PAGE	2
627	67	CONFIGURATION	4
628	110	VIEW	1
629	110	ADD_TO_PAGE	2
630	110	CONFIGURATION	4
631	135	ACCESS_IN_CONTROL_PANEL	2
632	135	CONFIGURATION	4
633	135	VIEW	1
634	59	VIEW	1
635	59	ADD_TO_PAGE	2
636	59	CONFIGURATION	4
637	131	ACCESS_IN_CONTROL_PANEL	2
638	131	CONFIGURATION	4
639	131	VIEW	1
640	102	VIEW	1
641	102	ADD_TO_PAGE	2
642	102	CONFIGURATION	4
\.


--
-- Data for Name: resourcecode; Type: TABLE DATA; Schema: public; Owner: root
--

COPY resourcecode (codeid, companyid, name, scope) FROM stdin;
\.


--
-- Data for Name: resourcepermission; Type: TABLE DATA; Schema: public; Owner: root
--

COPY resourcepermission (resourcepermissionid, companyid, name, scope, primkey, roleid, ownerid, actionids) FROM stdin;
1	10136	com.liferay.portal.model.Layout	4	10157	10145	10140	127
2	10136	com.liferay.portal.model.Layout	4	10157	10149	0	3
3	10136	com.liferay.portal.model.Layout	4	10157	10144	0	1
4	10136	com.liferay.portal.model.Layout	4	10165	10145	10140	127
5	10136	com.liferay.portal.model.Layout	4	10165	10149	0	3
6	10136	com.liferay.portal.model.Layout	4	10165	10144	0	1
7	10136	98	2	10171	10147	0	1
8	10136	66	2	10171	10147	0	1
9	10136	27	2	10171	10147	0	1
10	10136	152	2	10171	10147	0	1
11	10136	134	2	10171	10147	0	1
12	10136	130	2	10171	10147	0	1
13	10136	122	2	10171	10147	0	1
14	10136	36	2	10171	10147	0	1
15	10136	26	2	10171	10147	0	1
16	10136	104	2	10171	10147	0	1
17	10136	64	2	10171	10147	0	1
18	10136	153	2	10171	10147	0	1
19	10136	129	2	10171	10147	0	1
20	10136	100	2	10171	10147	0	1
21	10136	19	2	10171	10147	0	1
22	10136	157	2	10171	10147	0	1
23	10136	128	2	10171	10147	0	1
24	10136	154	2	10171	10147	0	1
25	10136	148	2	10171	10147	0	1
26	10136	11	2	10171	10147	0	1
27	10136	29	2	10171	10147	0	1
28	10136	158	2	10171	10147	0	1
29	10136	8	2	10171	10147	0	1
30	10136	58	2	10171	10147	0	1
31	10136	155	2	10171	10147	0	1
32	10136	71	2	10171	10147	0	1
33	10136	97	2	10171	10147	0	1
34	10136	39	2	10171	10147	0	1
35	10136	85	2	10171	10147	0	1
36	10136	118	2	10171	10147	0	1
37	10136	79	2	10171	10147	0	1
38	10136	107	2	10171	10147	0	1
39	10136	30	2	10171	10147	0	1
40	10136	147	2	10171	10147	0	1
41	10136	48	2	10171	10147	0	1
42	10136	125	2	10171	10147	0	1
43	10136	146	2	10171	10147	0	1
44	10136	62	2	10171	10147	0	1
45	10136	159	2	10171	10147	0	1
46	10136	108	2	10171	10147	0	1
47	10136	84	2	10171	10147	0	1
48	10136	101	2	10171	10147	0	1
49	10136	121	2	10171	10147	0	1
50	10136	37	2	10171	10147	0	1
51	10136	143	2	10171	10147	0	1
52	10136	77	2	10171	10147	0	1
53	10136	115	2	10171	10147	0	1
54	10136	56	2	10171	10147	0	1
55	10136	111	2	10171	10147	0	1
56	10136	3	2	10171	10147	0	1
57	10136	20	2	10171	10147	0	1
58	10136	16	2	10171	10147	0	1
59	10136	23	2	10171	10147	0	1
60	10136	83	2	10171	10147	0	1
61	10136	99	2	10171	10147	0	1
62	10136	70	2	10171	10147	0	1
63	10136	141	2	10171	10147	0	1
64	10136	9	2	10171	10147	0	1
65	10136	28	2	10171	10147	0	1
66	10136	137	2	10171	10147	0	1
67	10136	15	2	10171	10147	0	1
68	10136	47	2	10171	10147	0	1
69	10136	116	2	10171	10147	0	1
70	10136	82	2	10171	10147	0	1
71	10136	151	2	10171	10147	0	1
72	10136	54	2	10171	10147	0	1
73	10136	34	2	10171	10147	0	1
74	10136	132	2	10171	10147	0	1
75	10136	61	2	10171	10147	0	1
76	10136	73	2	10171	10147	0	1
77	10136	31	2	10171	10147	0	1
78	10136	136	2	10171	10147	0	1
79	10136	50	2	10171	10147	0	1
80	10136	127	2	10171	10147	0	1
81	10136	25	2	10171	10147	0	1
82	10136	33	2	10171	10147	0	1
83	10136	150	2	10171	10147	0	1
84	10136	114	2	10171	10147	0	1
85	10136	126	2	10171	10147	0	1
86	10136	149	2	10171	10147	0	1
87	10136	67	2	10171	10147	0	1
88	10136	110	2	10171	10147	0	1
89	10136	59	2	10171	10147	0	1
90	10136	135	2	10171	10147	0	1
91	10136	131	2	10171	10147	0	1
92	10136	102	2	10171	10147	0	1
93	10136	com.liferay.portal.model.Layout	2	10171	10147	0	1
94	10136	com.liferay.portlet.blogs	2	10171	10147	0	14
95	10136	com.liferay.portlet.calendar	2	10171	10147	0	14
96	10136	98	2	10171	10146	0	2
97	10136	152	2	10171	10146	0	2
98	10136	19	2	10171	10146	0	2
99	10136	154	2	10171	10146	0	2
100	10136	8	2	10171	10146	0	2
101	10136	155	2	10171	10146	0	2
102	10136	147	2	10171	10146	0	2
103	10136	20	2	10171	10146	0	2
104	10136	99	2	10171	10146	0	2
105	10136	28	2	10171	10146	0	2
106	10136	15	2	10171	10146	0	2
107	10136	31	2	10171	10146	0	2
108	10136	25	2	10171	10146	0	2
109	10136	33	2	10171	10146	0	2
110	10136	com.liferay.portal.model.Group	2	10171	10146	0	256
111	10136	com.liferay.portlet.asset	2	10171	10146	0	30
112	10136	com.liferay.portlet.blogs	2	10171	10146	0	14
113	10136	com.liferay.portlet.bookmarks	2	10171	10146	0	15
114	10136	com.liferay.portlet.calendar	2	10171	10146	0	14
115	10136	com.liferay.portlet.documentlibrary	2	10171	10146	0	31
116	10136	com.liferay.portlet.imagegallery	2	10171	10146	0	15
117	10136	com.liferay.portlet.messageboards	2	10171	10146	0	2047
118	10136	com.liferay.portlet.polls	2	10171	10146	0	6
119	10136	com.liferay.portlet.wiki	2	10171	10146	0	6
120	10136	com.liferay.portal.model.User	4	10178	10145	10178	31
121	10136	98	1	10136	10146	0	4
122	10136	98	1	10136	10147	0	4
123	10136	66	1	10136	10146	0	2
124	10136	66	1	10136	10147	0	2
125	10136	27	1	10136	10146	0	2
126	10136	27	1	10136	10147	0	2
127	10136	122	1	10136	10144	0	2
128	10136	122	1	10136	10146	0	2
129	10136	122	1	10136	10147	0	2
130	10136	36	1	10136	10146	0	2
131	10136	36	1	10136	10147	0	2
132	10136	26	1	10136	10146	0	2
133	10136	26	1	10136	10147	0	2
134	10136	104	1	10136	10143	0	2
135	10136	64	1	10136	10144	0	2
136	10136	64	1	10136	10146	0	2
137	10136	64	1	10136	10147	0	2
138	10136	100	1	10136	10146	0	2
139	10136	100	1	10136	10147	0	2
140	10136	19	1	10136	10146	0	4
141	10136	19	1	10136	10147	0	4
142	10136	148	1	10136	10144	0	2
143	10136	148	1	10136	10146	0	2
144	10136	148	1	10136	10147	0	2
145	10136	11	1	10136	10146	0	2
146	10136	11	1	10136	10147	0	2
147	10136	29	1	10136	10146	0	2
148	10136	29	1	10136	10147	0	2
149	10136	8	1	10136	10146	0	4
150	10136	8	1	10136	10147	0	4
151	10136	58	1	10136	10144	0	2
152	10136	58	1	10136	10146	0	2
153	10136	58	1	10136	10147	0	2
154	10136	71	1	10136	10144	0	2
155	10136	71	1	10136	10146	0	2
156	10136	71	1	10136	10147	0	2
157	10136	97	1	10136	10146	0	2
158	10136	97	1	10136	10147	0	2
159	10136	39	1	10136	10146	0	2
160	10136	39	1	10136	10147	0	2
161	10136	85	1	10136	10144	0	2
162	10136	85	1	10136	10146	0	2
163	10136	85	1	10136	10147	0	2
164	10136	118	1	10136	10144	0	2
165	10136	118	1	10136	10146	0	2
166	10136	118	1	10136	10147	0	2
167	10136	79	1	10136	10143	0	4
168	10136	107	1	10136	10146	0	2
169	10136	107	1	10136	10147	0	2
170	10136	30	1	10136	10146	0	2
171	10136	30	1	10136	10147	0	2
172	10136	48	1	10136	10146	0	2
173	10136	48	1	10136	10147	0	2
174	10136	62	1	10136	10146	0	2
175	10136	62	1	10136	10147	0	2
176	10136	159	1	10136	10144	0	2
177	10136	159	1	10136	10146	0	2
178	10136	159	1	10136	10147	0	2
179	10136	108	1	10136	10146	0	2
180	10136	108	1	10136	10147	0	2
181	10136	84	1	10136	10146	0	4
182	10136	84	1	10136	10147	0	4
183	10136	101	1	10136	10144	0	2
184	10136	101	1	10136	10146	0	2
185	10136	101	1	10136	10147	0	2
186	10136	121	1	10136	10144	0	2
187	10136	121	1	10136	10146	0	2
188	10136	121	1	10136	10147	0	2
189	10136	37	1	10136	10146	0	2
190	10136	37	1	10136	10147	0	2
191	10136	143	1	10136	10144	0	2
192	10136	143	1	10136	10146	0	2
193	10136	143	1	10136	10147	0	2
194	10136	77	1	10136	10144	0	2
195	10136	77	1	10136	10146	0	2
196	10136	77	1	10136	10147	0	2
197	10136	115	1	10136	10144	0	2
198	10136	115	1	10136	10146	0	2
199	10136	115	1	10136	10147	0	2
200	10136	56	1	10136	10144	0	2
201	10136	56	1	10136	10146	0	2
202	10136	56	1	10136	10147	0	2
203	10136	111	1	10136	10143	0	2
204	10136	3	1	10136	10144	0	2
205	10136	3	1	10136	10146	0	2
206	10136	3	1	10136	10147	0	2
207	10136	20	1	10136	10144	0	4
208	10136	20	1	10136	10146	0	4
209	10136	20	1	10136	10147	0	4
210	10136	16	1	10136	10146	0	8
211	10136	16	1	10136	10147	0	8
212	10136	23	1	10136	10146	0	2
213	10136	23	1	10136	10147	0	2
214	10136	83	1	10136	10146	0	4
215	10136	83	1	10136	10147	0	4
216	10136	70	1	10136	10146	0	2
217	10136	70	1	10136	10147	0	2
218	10136	141	1	10136	10144	0	2
219	10136	141	1	10136	10146	0	2
220	10136	141	1	10136	10147	0	2
221	10136	9	1	10136	10143	0	2
222	10136	28	1	10136	10146	0	4
223	10136	28	1	10136	10147	0	4
224	10136	15	1	10136	10146	0	4
225	10136	15	1	10136	10147	0	4
226	10136	47	1	10136	10144	0	2
227	10136	47	1	10136	10146	0	2
228	10136	47	1	10136	10147	0	2
229	10136	116	1	10136	10144	0	2
230	10136	116	1	10136	10146	0	2
231	10136	116	1	10136	10147	0	2
232	10136	82	1	10136	10144	0	2
233	10136	82	1	10136	10146	0	2
234	10136	82	1	10136	10147	0	2
235	10136	54	1	10136	10146	0	2
236	10136	54	1	10136	10147	0	2
237	10136	34	1	10136	10146	0	2
238	10136	34	1	10136	10147	0	2
239	10136	61	1	10136	10146	0	2
240	10136	61	1	10136	10147	0	2
241	10136	73	1	10136	10144	0	2
242	10136	73	1	10136	10146	0	2
243	10136	73	1	10136	10147	0	2
244	10136	31	1	10136	10144	0	4
245	10136	31	1	10136	10146	0	4
246	10136	31	1	10136	10147	0	4
247	10136	50	1	10136	10144	0	2
248	10136	50	1	10136	10146	0	2
249	10136	50	1	10136	10147	0	2
250	10136	33	1	10136	10144	0	4
251	10136	33	1	10136	10146	0	4
252	10136	33	1	10136	10147	0	4
253	10136	114	1	10136	10144	0	2
254	10136	114	1	10136	10146	0	2
255	10136	114	1	10136	10147	0	2
256	10136	67	1	10136	10146	0	2
257	10136	67	1	10136	10147	0	2
258	10136	110	1	10136	10146	0	2
259	10136	110	1	10136	10147	0	2
260	10136	59	1	10136	10146	0	2
261	10136	59	1	10136	10147	0	2
262	10136	102	1	10136	10144	0	2
263	10136	102	1	10136	10146	0	2
264	10136	102	1	10136	10147	0	2
265	10136	103	4	10165_LAYOUT_103	10145	0	7
266	10136	103	4	10165_LAYOUT_103	10149	0	1
267	10136	103	4	10165_LAYOUT_103	10144	0	1
268	10136	47	4	10165_LAYOUT_47	10145	0	7
269	10136	47	4	10165_LAYOUT_47	10149	0	1
270	10136	47	4	10165_LAYOUT_47	10144	0	1
271	10136	58	4	10165_LAYOUT_58	10145	0	7
272	10136	58	4	10165_LAYOUT_58	10149	0	1
273	10136	58	4	10165_LAYOUT_58	10144	0	1
274	10136	com.liferay.portal.model.Layout	4	10274	10145	10178	127
275	10136	com.liferay.portal.model.Layout	4	10274	10146	0	3
276	10136	com.liferay.portal.model.Layout	4	10279	10145	10178	127
277	10136	com.liferay.portal.model.Layout	4	10279	10146	0	3
278	10136	com.liferay.portal.model.Layout	4	10279	10144	0	1
279	10136	145	4	10165_LAYOUT_145	10145	0	7
280	10136	145	4	10165_LAYOUT_145	10149	0	1
281	10136	145	4	10165_LAYOUT_145	10144	0	1
282	10136	160	4	10157_LAYOUT_160	10145	0	7
283	10136	160	4	10157_LAYOUT_160	10149	0	1
284	10136	160	4	10157_LAYOUT_160	10144	0	1
285	10136	145	4	10157_LAYOUT_145	10145	0	7
286	10136	145	4	10157_LAYOUT_145	10149	0	1
287	10136	145	4	10157_LAYOUT_145	10144	0	1
288	10136	134	4	10157_LAYOUT_134	10145	0	7
289	10136	134	4	10157_LAYOUT_134	10149	0	1
290	10136	134	4	10157_LAYOUT_134	10144	0	1
291	10136	com.liferay.portal.model.Group	4	10291	10145	0	32766
292	10136	com.liferay.portal.model.Layout	4	10295	10145	10178	127
293	10136	com.liferay.portal.model.Layout	4	10295	10149	0	3
294	10136	com.liferay.portal.model.Layout	4	10295	10144	0	1
295	10136	com.liferay.portal.model.Group	4	10301	10145	0	32766
296	10136	com.liferay.portlet.asset.model.AssetVocabulary	4	10309	10145	10140	15
297	10136	com.liferay.portlet.asset.model.AssetVocabulary	4	10309	10149	0	0
298	10136	com.liferay.portlet.asset.model.AssetVocabulary	4	10309	10144	0	0
299	10136	com.liferay.portlet.asset.model.AssetVocabulary	4	10310	10145	10140	15
302	10136	com.liferay.portlet.asset.model.AssetVocabulary	4	10310	10143	0	0
303	10136	com.liferay.portlet.asset.model.AssetVocabulary	4	10310	10148	0	0
300	10136	com.liferay.portlet.asset.model.AssetVocabulary	4	10310	10149	0	0
304	10136	com.liferay.portlet.asset.model.AssetVocabulary	4	10310	10150	0	0
301	10136	com.liferay.portlet.asset.model.AssetVocabulary	4	10310	10144	0	0
305	10136	com.liferay.portlet.asset.model.AssetVocabulary	4	10310	10146	0	0
306	10136	com.liferay.portlet.asset.model.AssetVocabulary	4	10310	10147	0	0
307	10136	com.liferay.portal.model.Layout	4	10311	10144	0	1
308	10136	com.liferay.portal.model.Layout	4	10311	10145	0	127
309	10136	com.liferay.portal.model.Layout	4	10311	10146	0	0
310	10136	com.liferay.portal.model.Layout	4	10311	10147	0	0
311	10136	com.liferay.portal.model.Layout	4	10311	10148	0	0
312	10136	com.liferay.portal.model.Layout	4	10311	10149	0	3
313	10136	com.liferay.portal.model.Layout	4	10311	10150	0	0
314	10136	com.liferay.portlet.documentlibrary	4	10301	10143	0	0
315	10136	com.liferay.portlet.documentlibrary	4	10301	10148	0	0
316	10136	com.liferay.portlet.documentlibrary	4	10301	10149	0	0
317	10136	com.liferay.portlet.documentlibrary	4	10301	10150	0	0
318	10136	com.liferay.portlet.documentlibrary	4	10301	10144	0	0
319	10136	com.liferay.portlet.documentlibrary	4	10301	10145	0	0
320	10136	com.liferay.portlet.documentlibrary	4	10301	10146	0	0
321	10136	com.liferay.portlet.documentlibrary	4	10301	10147	0	0
322	10136	20	4	10311_LAYOUT_20	10144	0	0
323	10136	20	4	10311_LAYOUT_20	10145	0	0
324	10136	20	4	10311_LAYOUT_20	10146	0	0
325	10136	20	4	10311_LAYOUT_20	10147	0	0
326	10136	20	4	10311_LAYOUT_20	10148	0	0
327	10136	20	4	10311_LAYOUT_20	10149	0	0
328	10136	20	4	10311_LAYOUT_20	10150	0	0
329	10136	com.liferay.portlet.journal	4	10301	10143	0	0
330	10136	com.liferay.portlet.journal	4	10301	10148	0	0
331	10136	com.liferay.portlet.journal	4	10301	10149	0	0
332	10136	com.liferay.portlet.journal	4	10301	10150	0	0
333	10136	com.liferay.portlet.journal	4	10301	10144	0	0
334	10136	com.liferay.portlet.journal	4	10301	10145	0	0
335	10136	com.liferay.portlet.journal	4	10301	10146	0	0
336	10136	com.liferay.portlet.journal	4	10301	10147	0	0
337	10136	15	4	10311_LAYOUT_15	10144	0	0
338	10136	15	4	10311_LAYOUT_15	10145	0	0
339	10136	15	4	10311_LAYOUT_15	10146	0	0
340	10136	15	4	10311_LAYOUT_15	10147	0	0
341	10136	15	4	10311_LAYOUT_15	10148	0	0
342	10136	15	4	10311_LAYOUT_15	10149	0	0
343	10136	15	4	10311_LAYOUT_15	10150	0	0
344	10136	com.liferay.portlet.imagegallery	4	10301	10143	0	0
345	10136	com.liferay.portlet.imagegallery	4	10301	10148	0	0
346	10136	com.liferay.portlet.imagegallery	4	10301	10149	0	0
347	10136	com.liferay.portlet.imagegallery	4	10301	10150	0	0
348	10136	com.liferay.portlet.imagegallery	4	10301	10144	0	0
349	10136	com.liferay.portlet.imagegallery	4	10301	10145	0	0
350	10136	com.liferay.portlet.imagegallery	4	10301	10146	0	0
351	10136	com.liferay.portlet.imagegallery	4	10301	10147	0	0
352	10136	31	4	10311_LAYOUT_31	10144	0	0
353	10136	31	4	10311_LAYOUT_31	10145	0	0
354	10136	31	4	10311_LAYOUT_31	10146	0	0
355	10136	31	4	10311_LAYOUT_31	10147	0	0
356	10136	31	4	10311_LAYOUT_31	10148	0	0
357	10136	31	4	10311_LAYOUT_31	10149	0	0
358	10136	31	4	10311_LAYOUT_31	10150	0	0
359	10136	com.liferay.portlet.polls	4	10301	10143	0	0
360	10136	com.liferay.portlet.polls	4	10301	10148	0	0
361	10136	com.liferay.portlet.polls	4	10301	10149	0	0
362	10136	com.liferay.portlet.polls	4	10301	10150	0	0
363	10136	com.liferay.portlet.polls	4	10301	10144	0	0
364	10136	com.liferay.portlet.polls	4	10301	10145	0	0
365	10136	com.liferay.portlet.polls	4	10301	10146	0	0
366	10136	com.liferay.portlet.polls	4	10301	10147	0	0
367	10136	25	4	10311_LAYOUT_25	10144	0	0
368	10136	25	4	10311_LAYOUT_25	10145	0	0
369	10136	25	4	10311_LAYOUT_25	10146	0	0
370	10136	25	4	10311_LAYOUT_25	10147	0	0
371	10136	25	4	10311_LAYOUT_25	10148	0	0
372	10136	25	4	10311_LAYOUT_25	10149	0	0
373	10136	25	4	10311_LAYOUT_25	10150	0	0
374	10136	103	4	10295_LAYOUT_103	10145	0	7
375	10136	103	4	10295_LAYOUT_103	10149	0	1
376	10136	103	4	10295_LAYOUT_103	10144	0	1
377	10136	145	4	10295_LAYOUT_145	10145	0	7
378	10136	145	4	10295_LAYOUT_145	10149	0	1
379	10136	145	4	10295_LAYOUT_145	10144	0	1
380	10136	103	4	10311_LAYOUT_103	10145	0	7
381	10136	103	4	10311_LAYOUT_103	10149	0	1
382	10136	103	4	10311_LAYOUT_103	10144	0	1
383	10136	145	4	10311_LAYOUT_145	10145	0	7
384	10136	145	4	10311_LAYOUT_145	10149	0	1
385	10136	145	4	10311_LAYOUT_145	10144	0	1
386	10136	87	4	10311_LAYOUT_87	10145	0	7
387	10136	87	4	10311_LAYOUT_87	10149	0	1
388	10136	87	4	10311_LAYOUT_87	10144	0	1
389	10136	56	4	10311_LAYOUT_56_INSTANCE_imA4	10145	0	7
390	10136	56	4	10311_LAYOUT_56_INSTANCE_imA4	10149	0	1
391	10136	56	4	10311_LAYOUT_56_INSTANCE_imA4	10144	0	1
392	10136	com.liferay.portlet.journal.model.JournalArticle	4	10325	10145	10178	255
393	10136	com.liferay.portlet.journal.model.JournalArticle	4	10325	10149	0	3
394	10136	com.liferay.portlet.journal.model.JournalArticle	4	10325	10144	0	1
\.


--
-- Data for Name: role_; Type: TABLE DATA; Schema: public; Owner: root
--

COPY role_ (roleid, companyid, classnameid, classpk, name, title, description, type_, subtype) FROM stdin;
10143	10136	10041	10143	Administrator		Administrators are super users who can do anything.	1	
10144	10136	10041	10144	Guest		Unauthenticated users always have this role.	1	
10145	10136	10041	10145	Owner		This is an implied role with respect to the objects users create.	1	
10146	10136	10041	10146	Power User		Power Users have their own public and private pages.	1	
10147	10136	10041	10147	User		Authenticated users should be assigned this role.	1	
10148	10136	10041	10148	Community Administrator		Community Administrators are super users of their community but cannot make other users into Community Administrators.	2	
10149	10136	10041	10149	Community Member		All users who belong to a community have this role within that community.	2	
10150	10136	10041	10150	Community Owner		Community Owners are super users of their community and can assign community roles to users.	2	
10151	10136	10041	10151	Organization Administrator		Organization Administrators are super users of their organization but cannot make other users into Organization Administrators.	3	
10152	10136	10041	10152	Organization Member		All users who belong to an organization have this role within that organization.	3	
10153	10136	10041	10153	Organization Owner		Organization Owners are super users of their organization and can assign organization roles to users.	3	
\.


--
-- Data for Name: roles_permissions; Type: TABLE DATA; Schema: public; Owner: root
--

COPY roles_permissions (roleid, permissionid) FROM stdin;
\.


--
-- Data for Name: scframeworkversi_scproductvers; Type: TABLE DATA; Schema: public; Owner: root
--

COPY scframeworkversi_scproductvers (frameworkversionid, productversionid) FROM stdin;
\.


--
-- Data for Name: scframeworkversion; Type: TABLE DATA; Schema: public; Owner: root
--

COPY scframeworkversion (frameworkversionid, groupid, companyid, userid, username, createdate, modifieddate, name, url, active_, priority) FROM stdin;
\.


--
-- Data for Name: sclicense; Type: TABLE DATA; Schema: public; Owner: root
--

COPY sclicense (licenseid, name, url, opensource, active_, recommended) FROM stdin;
\.


--
-- Data for Name: sclicenses_scproductentries; Type: TABLE DATA; Schema: public; Owner: root
--

COPY sclicenses_scproductentries (licenseid, productentryid) FROM stdin;
\.


--
-- Data for Name: scproductentry; Type: TABLE DATA; Schema: public; Owner: root
--

COPY scproductentry (productentryid, groupid, companyid, userid, username, createdate, modifieddate, name, type_, tags, shortdescription, longdescription, pageurl, author, repogroupid, repoartifactid) FROM stdin;
\.


--
-- Data for Name: scproductscreenshot; Type: TABLE DATA; Schema: public; Owner: root
--

COPY scproductscreenshot (productscreenshotid, companyid, groupid, productentryid, thumbnailid, fullimageid, priority) FROM stdin;
\.


--
-- Data for Name: scproductversion; Type: TABLE DATA; Schema: public; Owner: root
--

COPY scproductversion (productversionid, companyid, userid, username, createdate, modifieddate, productentryid, version, changelog, downloadpageurl, directdownloadurl, repostoreartifact) FROM stdin;
\.


--
-- Data for Name: servicecomponent; Type: TABLE DATA; Schema: public; Owner: root
--

COPY servicecomponent (servicecomponentid, buildnamespace, buildnumber, builddate, data_) FROM stdin;
\.


--
-- Data for Name: shard; Type: TABLE DATA; Schema: public; Owner: root
--

COPY shard (shardid, classnameid, classpk, name) FROM stdin;
10137	10008	10136	default
\.


--
-- Data for Name: shoppingcart; Type: TABLE DATA; Schema: public; Owner: root
--

COPY shoppingcart (cartid, groupid, companyid, userid, username, createdate, modifieddate, itemids, couponcodes, altshipping, insure) FROM stdin;
\.


--
-- Data for Name: shoppingcategory; Type: TABLE DATA; Schema: public; Owner: root
--

COPY shoppingcategory (categoryid, groupid, companyid, userid, username, createdate, modifieddate, parentcategoryid, name, description) FROM stdin;
\.


--
-- Data for Name: shoppingcoupon; Type: TABLE DATA; Schema: public; Owner: root
--

COPY shoppingcoupon (couponid, groupid, companyid, userid, username, createdate, modifieddate, code_, name, description, startdate, enddate, active_, limitcategories, limitskus, minorder, discount, discounttype) FROM stdin;
\.


--
-- Data for Name: shoppingitem; Type: TABLE DATA; Schema: public; Owner: root
--

COPY shoppingitem (itemid, groupid, companyid, userid, username, createdate, modifieddate, categoryid, sku, name, description, properties, fields_, fieldsquantities, minquantity, maxquantity, price, discount, taxable, shipping, useshippingformula, requiresshipping, stockquantity, featured_, sale_, smallimage, smallimageid, smallimageurl, mediumimage, mediumimageid, mediumimageurl, largeimage, largeimageid, largeimageurl) FROM stdin;
\.


--
-- Data for Name: shoppingitemfield; Type: TABLE DATA; Schema: public; Owner: root
--

COPY shoppingitemfield (itemfieldid, itemid, name, values_, description) FROM stdin;
\.


--
-- Data for Name: shoppingitemprice; Type: TABLE DATA; Schema: public; Owner: root
--

COPY shoppingitemprice (itempriceid, itemid, minquantity, maxquantity, price, discount, taxable, shipping, useshippingformula, status) FROM stdin;
\.


--
-- Data for Name: shoppingorder; Type: TABLE DATA; Schema: public; Owner: root
--

COPY shoppingorder (orderid, groupid, companyid, userid, username, createdate, modifieddate, number_, tax, shipping, altshipping, requiresshipping, insure, insurance, couponcodes, coupondiscount, billingfirstname, billinglastname, billingemailaddress, billingcompany, billingstreet, billingcity, billingstate, billingzip, billingcountry, billingphone, shiptobilling, shippingfirstname, shippinglastname, shippingemailaddress, shippingcompany, shippingstreet, shippingcity, shippingstate, shippingzip, shippingcountry, shippingphone, ccname, cctype, ccnumber, ccexpmonth, ccexpyear, ccvernumber, comments, pptxnid, pppaymentstatus, pppaymentgross, ppreceiveremail, pppayeremail, sendorderemail, sendshippingemail) FROM stdin;
\.


--
-- Data for Name: shoppingorderitem; Type: TABLE DATA; Schema: public; Owner: root
--

COPY shoppingorderitem (orderitemid, orderid, itemid, sku, name, description, properties, price, quantity, shippeddate) FROM stdin;
\.


--
-- Data for Name: socialactivity; Type: TABLE DATA; Schema: public; Owner: root
--

COPY socialactivity (activityid, groupid, companyid, userid, createdate, mirroractivityid, classnameid, classpk, type_, extradata, receiveruserid) FROM stdin;
\.


--
-- Data for Name: socialequityassetentry; Type: TABLE DATA; Schema: public; Owner: root
--

COPY socialequityassetentry (equityassetentryid, groupid, companyid, userid, assetentryid, informationk, informationb) FROM stdin;
\.


--
-- Data for Name: socialequitygroupsetting; Type: TABLE DATA; Schema: public; Owner: root
--

COPY socialequitygroupsetting (equitygroupsettingid, groupid, companyid, classnameid, type_, enabled) FROM stdin;
\.


--
-- Data for Name: socialequityhistory; Type: TABLE DATA; Schema: public; Owner: root
--

COPY socialequityhistory (equityhistoryid, groupid, companyid, userid, createdate, personalequity) FROM stdin;
\.


--
-- Data for Name: socialequitylog; Type: TABLE DATA; Schema: public; Owner: root
--

COPY socialequitylog (equitylogid, groupid, companyid, userid, assetentryid, actionid, actiondate, active_, expiration, type_, value, extradata) FROM stdin;
\.


--
-- Data for Name: socialequitysetting; Type: TABLE DATA; Schema: public; Owner: root
--

COPY socialequitysetting (equitysettingid, groupid, companyid, classnameid, actionid, dailylimit, lifespan, type_, uniqueentry, value) FROM stdin;
\.


--
-- Data for Name: socialequityuser; Type: TABLE DATA; Schema: public; Owner: root
--

COPY socialequityuser (equityuserid, groupid, companyid, userid, contributionk, contributionb, participationk, participationb, rank) FROM stdin;
\.


--
-- Data for Name: socialrelation; Type: TABLE DATA; Schema: public; Owner: root
--

COPY socialrelation (uuid_, relationid, companyid, createdate, userid1, userid2, type_) FROM stdin;
\.


--
-- Data for Name: socialrequest; Type: TABLE DATA; Schema: public; Owner: root
--

COPY socialrequest (uuid_, requestid, groupid, companyid, userid, createdate, modifieddate, classnameid, classpk, type_, extradata, receiveruserid, status) FROM stdin;
\.


--
-- Data for Name: subscription; Type: TABLE DATA; Schema: public; Owner: root
--

COPY subscription (subscriptionid, companyid, userid, username, createdate, modifieddate, classnameid, classpk, frequency) FROM stdin;
\.


--
-- Data for Name: tasksproposal; Type: TABLE DATA; Schema: public; Owner: root
--

COPY tasksproposal (proposalid, groupid, companyid, userid, username, createdate, modifieddate, classnameid, classpk, name, description, publishdate, duedate) FROM stdin;
\.


--
-- Data for Name: tasksreview; Type: TABLE DATA; Schema: public; Owner: root
--

COPY tasksreview (reviewid, groupid, companyid, userid, username, createdate, modifieddate, proposalid, assignedbyuserid, assignedbyusername, stage, completed, rejected) FROM stdin;
\.


--
-- Data for Name: team; Type: TABLE DATA; Schema: public; Owner: root
--

COPY team (teamid, companyid, userid, username, createdate, modifieddate, groupid, name, description) FROM stdin;
\.


--
-- Data for Name: ticket; Type: TABLE DATA; Schema: public; Owner: root
--

COPY ticket (ticketid, companyid, createdate, classnameid, classpk, key_, type_, extrainfo, expirationdate) FROM stdin;
\.


--
-- Data for Name: user_; Type: TABLE DATA; Schema: public; Owner: root
--

COPY user_ (uuid_, userid, companyid, createdate, modifieddate, defaultuser, contactid, password_, passwordencrypted, passwordreset, passwordmodifieddate, digest, reminderqueryquestion, reminderqueryanswer, gracelogincount, screenname, emailaddress, facebookid, openid, portraitid, languageid, timezoneid, greeting, comments, firstname, middlename, lastname, jobtitle, logindate, loginip, lastlogindate, lastloginip, lastfailedlogindate, failedloginattempts, lockout, lockoutdate, agreedtotermsofuse, active_) FROM stdin;
f0e700c5-87c8-4c81-a627-333c7bf11b52	10140	10136	2017-03-10 17:04:09.512	2017-03-10 17:04:09.512	t	10141	password	f	f	\N	5533ed38b5e33c076a804bb4bca644f9,436a0549ee5891dab9afc8a3378d5a3e,436a0549ee5891dab9afc8a3378d5a3e			0	10140	default@liferay.com	0		0	en_US	UTC	Welcome!						2017-03-10 17:04:09.512		\N		\N	0	f	\N	t	t
69f7273b-5b15-41c5-bedd-5fa9507b2863	10178	10136	2017-03-10 17:04:10.247	2017-03-10 17:04:10.247	f	10179	qUqP5cyxm6YcTAhz05Hph5gvu9M=	t	f	\N	e5d86c6f3672e52795891c3597f20de0,751da756639bc033b572ba2e7849b589,d530e5d49278f0d1b39690c9bcaaf823	what-is-your-father's-middle-name	test	0	test	test@liferay.com	0		0	en_US	UTC	Welcome Test Test!		Test		Test		2017-03-10 17:06:40.31	127.0.0.1	2017-03-10 17:06:40.31	127.0.0.1	\N	0	f	\N	t	t
\.


--
-- Data for Name: usergroup; Type: TABLE DATA; Schema: public; Owner: root
--

COPY usergroup (usergroupid, companyid, parentusergroupid, name, description, addedbyldapimport) FROM stdin;
\.


--
-- Data for Name: usergroupgrouprole; Type: TABLE DATA; Schema: public; Owner: root
--

COPY usergroupgrouprole (usergroupid, groupid, roleid) FROM stdin;
\.


--
-- Data for Name: usergrouprole; Type: TABLE DATA; Schema: public; Owner: root
--

COPY usergrouprole (userid, groupid, roleid) FROM stdin;
10178	10291	10150
10178	10301	10150
\.


--
-- Data for Name: usergroups_teams; Type: TABLE DATA; Schema: public; Owner: root
--

COPY usergroups_teams (usergroupid, teamid) FROM stdin;
\.


--
-- Data for Name: useridmapper; Type: TABLE DATA; Schema: public; Owner: root
--

COPY useridmapper (useridmapperid, userid, type_, description, externaluserid) FROM stdin;
\.


--
-- Data for Name: usernotificationevent; Type: TABLE DATA; Schema: public; Owner: root
--

COPY usernotificationevent (uuid_, usernotificationeventid, companyid, userid, type_, "timestamp", deliverby, payload) FROM stdin;
\.


--
-- Data for Name: users_groups; Type: TABLE DATA; Schema: public; Owner: root
--

COPY users_groups (userid, groupid) FROM stdin;
10178	10162
10178	10291
10178	10301
\.


--
-- Data for Name: users_orgs; Type: TABLE DATA; Schema: public; Owner: root
--

COPY users_orgs (userid, organizationid) FROM stdin;
\.


--
-- Data for Name: users_permissions; Type: TABLE DATA; Schema: public; Owner: root
--

COPY users_permissions (userid, permissionid) FROM stdin;
\.


--
-- Data for Name: users_roles; Type: TABLE DATA; Schema: public; Owner: root
--

COPY users_roles (userid, roleid) FROM stdin;
10140	10144
10178	10147
10178	10146
10178	10143
\.


--
-- Data for Name: users_teams; Type: TABLE DATA; Schema: public; Owner: root
--

COPY users_teams (userid, teamid) FROM stdin;
\.


--
-- Data for Name: users_usergroups; Type: TABLE DATA; Schema: public; Owner: root
--

COPY users_usergroups (usergroupid, userid) FROM stdin;
\.


--
-- Data for Name: usertracker; Type: TABLE DATA; Schema: public; Owner: root
--

COPY usertracker (usertrackerid, companyid, userid, modifieddate, sessionid, remoteaddr, remotehost, useragent) FROM stdin;
\.


--
-- Data for Name: usertrackerpath; Type: TABLE DATA; Schema: public; Owner: root
--

COPY usertrackerpath (usertrackerpathid, usertrackerid, path_, pathdate) FROM stdin;
\.


--
-- Data for Name: virtualhost; Type: TABLE DATA; Schema: public; Owner: root
--

COPY virtualhost (virtualhostid, companyid, layoutsetid, hostname) FROM stdin;
10139	10136	0	localhost
\.


--
-- Data for Name: vocabulary; Type: TABLE DATA; Schema: public; Owner: root
--

COPY vocabulary (vocabularyid, groupid, companyid, userid, username, createdate, modifieddate, name, description, folksonomy) FROM stdin;
\.


--
-- Data for Name: webdavprops; Type: TABLE DATA; Schema: public; Owner: root
--

COPY webdavprops (webdavpropsid, companyid, createdate, modifieddate, classnameid, classpk, props) FROM stdin;
\.


--
-- Data for Name: website; Type: TABLE DATA; Schema: public; Owner: root
--

COPY website (websiteid, companyid, userid, username, createdate, modifieddate, classnameid, classpk, url, typeid, primary_) FROM stdin;
\.


--
-- Data for Name: wikinode; Type: TABLE DATA; Schema: public; Owner: root
--

COPY wikinode (uuid_, nodeid, groupid, companyid, userid, username, createdate, modifieddate, name, description, lastpostdate) FROM stdin;
\.


--
-- Data for Name: wikipage; Type: TABLE DATA; Schema: public; Owner: root
--

COPY wikipage (uuid_, pageid, resourceprimkey, groupid, companyid, userid, username, createdate, modifieddate, nodeid, title, version, minoredit, content, summary, format, head, parenttitle, redirecttitle, status, statusbyuserid, statusbyusername, statusdate) FROM stdin;
\.


--
-- Data for Name: wikipageresource; Type: TABLE DATA; Schema: public; Owner: root
--

COPY wikipageresource (uuid_, resourceprimkey, nodeid, title) FROM stdin;
\.


--
-- Data for Name: workflowdefinitionlink; Type: TABLE DATA; Schema: public; Owner: root
--

COPY workflowdefinitionlink (workflowdefinitionlinkid, groupid, companyid, userid, username, createdate, modifieddate, classnameid, workflowdefinitionname, workflowdefinitionversion) FROM stdin;
\.


--
-- Data for Name: workflowinstancelink; Type: TABLE DATA; Schema: public; Owner: root
--

COPY workflowinstancelink (workflowinstancelinkid, groupid, companyid, userid, username, createdate, modifieddate, classnameid, classpk, workflowinstanceid) FROM stdin;
\.


--
-- Name: account__pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY account_
    ADD CONSTRAINT account__pkey PRIMARY KEY (accountid);


--
-- Name: address_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY address
    ADD CONSTRAINT address_pkey PRIMARY KEY (addressid);


--
-- Name: announcementsdelivery_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY announcementsdelivery
    ADD CONSTRAINT announcementsdelivery_pkey PRIMARY KEY (deliveryid);


--
-- Name: announcementsentry_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY announcementsentry
    ADD CONSTRAINT announcementsentry_pkey PRIMARY KEY (entryid);


--
-- Name: announcementsflag_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY announcementsflag
    ADD CONSTRAINT announcementsflag_pkey PRIMARY KEY (flagid);


--
-- Name: assetcategory_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY assetcategory
    ADD CONSTRAINT assetcategory_pkey PRIMARY KEY (categoryid);


--
-- Name: assetcategoryproperty_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY assetcategoryproperty
    ADD CONSTRAINT assetcategoryproperty_pkey PRIMARY KEY (categorypropertyid);


--
-- Name: assetentries_assetcategories_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY assetentries_assetcategories
    ADD CONSTRAINT assetentries_assetcategories_pkey PRIMARY KEY (entryid, categoryid);


--
-- Name: assetentries_assettags_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY assetentries_assettags
    ADD CONSTRAINT assetentries_assettags_pkey PRIMARY KEY (entryid, tagid);


--
-- Name: assetentry_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY assetentry
    ADD CONSTRAINT assetentry_pkey PRIMARY KEY (entryid);


--
-- Name: assetlink_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY assetlink
    ADD CONSTRAINT assetlink_pkey PRIMARY KEY (linkid);


--
-- Name: assettag_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY assettag
    ADD CONSTRAINT assettag_pkey PRIMARY KEY (tagid);


--
-- Name: assettagproperty_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY assettagproperty
    ADD CONSTRAINT assettagproperty_pkey PRIMARY KEY (tagpropertyid);


--
-- Name: assettagstats_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY assettagstats
    ADD CONSTRAINT assettagstats_pkey PRIMARY KEY (tagstatsid);


--
-- Name: assetvocabulary_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY assetvocabulary
    ADD CONSTRAINT assetvocabulary_pkey PRIMARY KEY (vocabularyid);


--
-- Name: blogsentry_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY blogsentry
    ADD CONSTRAINT blogsentry_pkey PRIMARY KEY (entryid);


--
-- Name: blogsstatsuser_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY blogsstatsuser
    ADD CONSTRAINT blogsstatsuser_pkey PRIMARY KEY (statsuserid);


--
-- Name: bookmarksentry_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY bookmarksentry
    ADD CONSTRAINT bookmarksentry_pkey PRIMARY KEY (entryid);


--
-- Name: bookmarksfolder_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY bookmarksfolder
    ADD CONSTRAINT bookmarksfolder_pkey PRIMARY KEY (folderid);


--
-- Name: browsertracker_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY browsertracker
    ADD CONSTRAINT browsertracker_pkey PRIMARY KEY (browsertrackerid);


--
-- Name: calevent_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY calevent
    ADD CONSTRAINT calevent_pkey PRIMARY KEY (eventid);


--
-- Name: classname__pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY classname_
    ADD CONSTRAINT classname__pkey PRIMARY KEY (classnameid);


--
-- Name: clustergroup_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY clustergroup
    ADD CONSTRAINT clustergroup_pkey PRIMARY KEY (clustergroupid);


--
-- Name: company_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY company
    ADD CONSTRAINT company_pkey PRIMARY KEY (companyid);


--
-- Name: contact__pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY contact_
    ADD CONSTRAINT contact__pkey PRIMARY KEY (contactid);


--
-- Name: counter_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY counter
    ADD CONSTRAINT counter_pkey PRIMARY KEY (name);


--
-- Name: country_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY country
    ADD CONSTRAINT country_pkey PRIMARY KEY (countryid);


--
-- Name: cyrususer_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY cyrususer
    ADD CONSTRAINT cyrususer_pkey PRIMARY KEY (userid);


--
-- Name: cyrusvirtual_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY cyrusvirtual
    ADD CONSTRAINT cyrusvirtual_pkey PRIMARY KEY (emailaddress);


--
-- Name: dlfileentry_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY dlfileentry
    ADD CONSTRAINT dlfileentry_pkey PRIMARY KEY (fileentryid);


--
-- Name: dlfilerank_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY dlfilerank
    ADD CONSTRAINT dlfilerank_pkey PRIMARY KEY (filerankid);


--
-- Name: dlfileshortcut_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY dlfileshortcut
    ADD CONSTRAINT dlfileshortcut_pkey PRIMARY KEY (fileshortcutid);


--
-- Name: dlfileversion_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY dlfileversion
    ADD CONSTRAINT dlfileversion_pkey PRIMARY KEY (fileversionid);


--
-- Name: dlfolder_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY dlfolder
    ADD CONSTRAINT dlfolder_pkey PRIMARY KEY (folderid);


--
-- Name: emailaddress_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY emailaddress
    ADD CONSTRAINT emailaddress_pkey PRIMARY KEY (emailaddressid);


--
-- Name: expandocolumn_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY expandocolumn
    ADD CONSTRAINT expandocolumn_pkey PRIMARY KEY (columnid);


--
-- Name: expandorow_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY expandorow
    ADD CONSTRAINT expandorow_pkey PRIMARY KEY (rowid_);


--
-- Name: expandotable_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY expandotable
    ADD CONSTRAINT expandotable_pkey PRIMARY KEY (tableid);


--
-- Name: expandovalue_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY expandovalue
    ADD CONSTRAINT expandovalue_pkey PRIMARY KEY (valueid);


--
-- Name: group__pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY group_
    ADD CONSTRAINT group__pkey PRIMARY KEY (groupid);


--
-- Name: groups_orgs_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY groups_orgs
    ADD CONSTRAINT groups_orgs_pkey PRIMARY KEY (groupid, organizationid);


--
-- Name: groups_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY groups_permissions
    ADD CONSTRAINT groups_permissions_pkey PRIMARY KEY (groupid, permissionid);


--
-- Name: groups_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY groups_roles
    ADD CONSTRAINT groups_roles_pkey PRIMARY KEY (groupid, roleid);


--
-- Name: groups_usergroups_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY groups_usergroups
    ADD CONSTRAINT groups_usergroups_pkey PRIMARY KEY (groupid, usergroupid);


--
-- Name: igfolder_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY igfolder
    ADD CONSTRAINT igfolder_pkey PRIMARY KEY (folderid);


--
-- Name: igimage_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY igimage
    ADD CONSTRAINT igimage_pkey PRIMARY KEY (imageid);


--
-- Name: image_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY image
    ADD CONSTRAINT image_pkey PRIMARY KEY (imageid);


--
-- Name: journalarticle_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY journalarticle
    ADD CONSTRAINT journalarticle_pkey PRIMARY KEY (id_);


--
-- Name: journalarticleimage_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY journalarticleimage
    ADD CONSTRAINT journalarticleimage_pkey PRIMARY KEY (articleimageid);


--
-- Name: journalarticleresource_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY journalarticleresource
    ADD CONSTRAINT journalarticleresource_pkey PRIMARY KEY (resourceprimkey);


--
-- Name: journalcontentsearch_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY journalcontentsearch
    ADD CONSTRAINT journalcontentsearch_pkey PRIMARY KEY (contentsearchid);


--
-- Name: journalfeed_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY journalfeed
    ADD CONSTRAINT journalfeed_pkey PRIMARY KEY (id_);


--
-- Name: journalstructure_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY journalstructure
    ADD CONSTRAINT journalstructure_pkey PRIMARY KEY (id_);


--
-- Name: journaltemplate_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY journaltemplate
    ADD CONSTRAINT journaltemplate_pkey PRIMARY KEY (id_);


--
-- Name: layout_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY layout
    ADD CONSTRAINT layout_pkey PRIMARY KEY (plid);


--
-- Name: layoutprototype_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY layoutprototype
    ADD CONSTRAINT layoutprototype_pkey PRIMARY KEY (layoutprototypeid);


--
-- Name: layoutset_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY layoutset
    ADD CONSTRAINT layoutset_pkey PRIMARY KEY (layoutsetid);


--
-- Name: layoutsetprototype_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY layoutsetprototype
    ADD CONSTRAINT layoutsetprototype_pkey PRIMARY KEY (layoutsetprototypeid);


--
-- Name: listtype_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY listtype
    ADD CONSTRAINT listtype_pkey PRIMARY KEY (listtypeid);


--
-- Name: lock__pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY lock_
    ADD CONSTRAINT lock__pkey PRIMARY KEY (lockid);


--
-- Name: mbban_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY mbban
    ADD CONSTRAINT mbban_pkey PRIMARY KEY (banid);


--
-- Name: mbcategory_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY mbcategory
    ADD CONSTRAINT mbcategory_pkey PRIMARY KEY (categoryid);


--
-- Name: mbdiscussion_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY mbdiscussion
    ADD CONSTRAINT mbdiscussion_pkey PRIMARY KEY (discussionid);


--
-- Name: mbmailinglist_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY mbmailinglist
    ADD CONSTRAINT mbmailinglist_pkey PRIMARY KEY (mailinglistid);


--
-- Name: mbmessage_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY mbmessage
    ADD CONSTRAINT mbmessage_pkey PRIMARY KEY (messageid);


--
-- Name: mbmessageflag_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY mbmessageflag
    ADD CONSTRAINT mbmessageflag_pkey PRIMARY KEY (messageflagid);


--
-- Name: mbstatsuser_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY mbstatsuser
    ADD CONSTRAINT mbstatsuser_pkey PRIMARY KEY (statsuserid);


--
-- Name: mbthread_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY mbthread
    ADD CONSTRAINT mbthread_pkey PRIMARY KEY (threadid);


--
-- Name: membershiprequest_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY membershiprequest
    ADD CONSTRAINT membershiprequest_pkey PRIMARY KEY (membershiprequestid);


--
-- Name: organization__pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY organization_
    ADD CONSTRAINT organization__pkey PRIMARY KEY (organizationid);


--
-- Name: orggrouppermission_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY orggrouppermission
    ADD CONSTRAINT orggrouppermission_pkey PRIMARY KEY (organizationid, groupid, permissionid);


--
-- Name: orggrouprole_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY orggrouprole
    ADD CONSTRAINT orggrouprole_pkey PRIMARY KEY (organizationid, groupid, roleid);


--
-- Name: orglabor_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY orglabor
    ADD CONSTRAINT orglabor_pkey PRIMARY KEY (orglaborid);


--
-- Name: passwordpolicy_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY passwordpolicy
    ADD CONSTRAINT passwordpolicy_pkey PRIMARY KEY (passwordpolicyid);


--
-- Name: passwordpolicyrel_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY passwordpolicyrel
    ADD CONSTRAINT passwordpolicyrel_pkey PRIMARY KEY (passwordpolicyrelid);


--
-- Name: passwordtracker_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY passwordtracker
    ADD CONSTRAINT passwordtracker_pkey PRIMARY KEY (passwordtrackerid);


--
-- Name: permission__pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY permission_
    ADD CONSTRAINT permission__pkey PRIMARY KEY (permissionid);


--
-- Name: phone_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY phone
    ADD CONSTRAINT phone_pkey PRIMARY KEY (phoneid);


--
-- Name: pluginsetting_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY pluginsetting
    ADD CONSTRAINT pluginsetting_pkey PRIMARY KEY (pluginsettingid);


--
-- Name: pollschoice_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY pollschoice
    ADD CONSTRAINT pollschoice_pkey PRIMARY KEY (choiceid);


--
-- Name: pollsquestion_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY pollsquestion
    ADD CONSTRAINT pollsquestion_pkey PRIMARY KEY (questionid);


--
-- Name: pollsvote_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY pollsvote
    ADD CONSTRAINT pollsvote_pkey PRIMARY KEY (voteid);


--
-- Name: portalpreferences_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY portalpreferences
    ADD CONSTRAINT portalpreferences_pkey PRIMARY KEY (portalpreferencesid);


--
-- Name: portlet_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY portlet
    ADD CONSTRAINT portlet_pkey PRIMARY KEY (id_);


--
-- Name: portletitem_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY portletitem
    ADD CONSTRAINT portletitem_pkey PRIMARY KEY (portletitemid);


--
-- Name: portletpreferences_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY portletpreferences
    ADD CONSTRAINT portletpreferences_pkey PRIMARY KEY (portletpreferencesid);


--
-- Name: quartz_blob_triggers_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY quartz_blob_triggers
    ADD CONSTRAINT quartz_blob_triggers_pkey PRIMARY KEY (trigger_name, trigger_group);


--
-- Name: quartz_calendars_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY quartz_calendars
    ADD CONSTRAINT quartz_calendars_pkey PRIMARY KEY (calendar_name);


--
-- Name: quartz_cron_triggers_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY quartz_cron_triggers
    ADD CONSTRAINT quartz_cron_triggers_pkey PRIMARY KEY (trigger_name, trigger_group);


--
-- Name: quartz_fired_triggers_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY quartz_fired_triggers
    ADD CONSTRAINT quartz_fired_triggers_pkey PRIMARY KEY (entry_id);


--
-- Name: quartz_job_details_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY quartz_job_details
    ADD CONSTRAINT quartz_job_details_pkey PRIMARY KEY (job_name, job_group);


--
-- Name: quartz_job_listeners_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY quartz_job_listeners
    ADD CONSTRAINT quartz_job_listeners_pkey PRIMARY KEY (job_name, job_group, job_listener);


--
-- Name: quartz_locks_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY quartz_locks
    ADD CONSTRAINT quartz_locks_pkey PRIMARY KEY (lock_name);


--
-- Name: quartz_paused_trigger_grps_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY quartz_paused_trigger_grps
    ADD CONSTRAINT quartz_paused_trigger_grps_pkey PRIMARY KEY (trigger_group);


--
-- Name: quartz_scheduler_state_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY quartz_scheduler_state
    ADD CONSTRAINT quartz_scheduler_state_pkey PRIMARY KEY (instance_name);


--
-- Name: quartz_simple_triggers_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY quartz_simple_triggers
    ADD CONSTRAINT quartz_simple_triggers_pkey PRIMARY KEY (trigger_name, trigger_group);


--
-- Name: quartz_trigger_listeners_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY quartz_trigger_listeners
    ADD CONSTRAINT quartz_trigger_listeners_pkey PRIMARY KEY (trigger_name, trigger_group, trigger_listener);


--
-- Name: quartz_triggers_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY quartz_triggers
    ADD CONSTRAINT quartz_triggers_pkey PRIMARY KEY (trigger_name, trigger_group);


--
-- Name: ratingsentry_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY ratingsentry
    ADD CONSTRAINT ratingsentry_pkey PRIMARY KEY (entryid);


--
-- Name: ratingsstats_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY ratingsstats
    ADD CONSTRAINT ratingsstats_pkey PRIMARY KEY (statsid);


--
-- Name: region_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY region
    ADD CONSTRAINT region_pkey PRIMARY KEY (regionid);


--
-- Name: release__pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY release_
    ADD CONSTRAINT release__pkey PRIMARY KEY (releaseid);


--
-- Name: resource__pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY resource_
    ADD CONSTRAINT resource__pkey PRIMARY KEY (resourceid);


--
-- Name: resourceaction_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY resourceaction
    ADD CONSTRAINT resourceaction_pkey PRIMARY KEY (resourceactionid);


--
-- Name: resourcecode_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY resourcecode
    ADD CONSTRAINT resourcecode_pkey PRIMARY KEY (codeid);


--
-- Name: resourcepermission_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY resourcepermission
    ADD CONSTRAINT resourcepermission_pkey PRIMARY KEY (resourcepermissionid);


--
-- Name: role__pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY role_
    ADD CONSTRAINT role__pkey PRIMARY KEY (roleid);


--
-- Name: roles_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY roles_permissions
    ADD CONSTRAINT roles_permissions_pkey PRIMARY KEY (roleid, permissionid);


--
-- Name: scframeworkversi_scproductvers_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY scframeworkversi_scproductvers
    ADD CONSTRAINT scframeworkversi_scproductvers_pkey PRIMARY KEY (frameworkversionid, productversionid);


--
-- Name: scframeworkversion_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY scframeworkversion
    ADD CONSTRAINT scframeworkversion_pkey PRIMARY KEY (frameworkversionid);


--
-- Name: sclicense_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY sclicense
    ADD CONSTRAINT sclicense_pkey PRIMARY KEY (licenseid);


--
-- Name: sclicenses_scproductentries_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY sclicenses_scproductentries
    ADD CONSTRAINT sclicenses_scproductentries_pkey PRIMARY KEY (licenseid, productentryid);


--
-- Name: scproductentry_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY scproductentry
    ADD CONSTRAINT scproductentry_pkey PRIMARY KEY (productentryid);


--
-- Name: scproductscreenshot_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY scproductscreenshot
    ADD CONSTRAINT scproductscreenshot_pkey PRIMARY KEY (productscreenshotid);


--
-- Name: scproductversion_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY scproductversion
    ADD CONSTRAINT scproductversion_pkey PRIMARY KEY (productversionid);


--
-- Name: servicecomponent_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY servicecomponent
    ADD CONSTRAINT servicecomponent_pkey PRIMARY KEY (servicecomponentid);


--
-- Name: shard_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY shard
    ADD CONSTRAINT shard_pkey PRIMARY KEY (shardid);


--
-- Name: shoppingcart_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY shoppingcart
    ADD CONSTRAINT shoppingcart_pkey PRIMARY KEY (cartid);


--
-- Name: shoppingcategory_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY shoppingcategory
    ADD CONSTRAINT shoppingcategory_pkey PRIMARY KEY (categoryid);


--
-- Name: shoppingcoupon_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY shoppingcoupon
    ADD CONSTRAINT shoppingcoupon_pkey PRIMARY KEY (couponid);


--
-- Name: shoppingitem_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY shoppingitem
    ADD CONSTRAINT shoppingitem_pkey PRIMARY KEY (itemid);


--
-- Name: shoppingitemfield_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY shoppingitemfield
    ADD CONSTRAINT shoppingitemfield_pkey PRIMARY KEY (itemfieldid);


--
-- Name: shoppingitemprice_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY shoppingitemprice
    ADD CONSTRAINT shoppingitemprice_pkey PRIMARY KEY (itempriceid);


--
-- Name: shoppingorder_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY shoppingorder
    ADD CONSTRAINT shoppingorder_pkey PRIMARY KEY (orderid);


--
-- Name: shoppingorderitem_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY shoppingorderitem
    ADD CONSTRAINT shoppingorderitem_pkey PRIMARY KEY (orderitemid);


--
-- Name: socialactivity_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY socialactivity
    ADD CONSTRAINT socialactivity_pkey PRIMARY KEY (activityid);


--
-- Name: socialequityassetentry_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY socialequityassetentry
    ADD CONSTRAINT socialequityassetentry_pkey PRIMARY KEY (equityassetentryid);


--
-- Name: socialequitygroupsetting_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY socialequitygroupsetting
    ADD CONSTRAINT socialequitygroupsetting_pkey PRIMARY KEY (equitygroupsettingid);


--
-- Name: socialequityhistory_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY socialequityhistory
    ADD CONSTRAINT socialequityhistory_pkey PRIMARY KEY (equityhistoryid);


--
-- Name: socialequitylog_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY socialequitylog
    ADD CONSTRAINT socialequitylog_pkey PRIMARY KEY (equitylogid);


--
-- Name: socialequitysetting_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY socialequitysetting
    ADD CONSTRAINT socialequitysetting_pkey PRIMARY KEY (equitysettingid);


--
-- Name: socialequityuser_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY socialequityuser
    ADD CONSTRAINT socialequityuser_pkey PRIMARY KEY (equityuserid);


--
-- Name: socialrelation_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY socialrelation
    ADD CONSTRAINT socialrelation_pkey PRIMARY KEY (relationid);


--
-- Name: socialrequest_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY socialrequest
    ADD CONSTRAINT socialrequest_pkey PRIMARY KEY (requestid);


--
-- Name: subscription_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY subscription
    ADD CONSTRAINT subscription_pkey PRIMARY KEY (subscriptionid);


--
-- Name: tasksproposal_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY tasksproposal
    ADD CONSTRAINT tasksproposal_pkey PRIMARY KEY (proposalid);


--
-- Name: tasksreview_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY tasksreview
    ADD CONSTRAINT tasksreview_pkey PRIMARY KEY (reviewid);


--
-- Name: team_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY team
    ADD CONSTRAINT team_pkey PRIMARY KEY (teamid);


--
-- Name: ticket_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY ticket
    ADD CONSTRAINT ticket_pkey PRIMARY KEY (ticketid);


--
-- Name: user__pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY user_
    ADD CONSTRAINT user__pkey PRIMARY KEY (userid);


--
-- Name: usergroup_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY usergroup
    ADD CONSTRAINT usergroup_pkey PRIMARY KEY (usergroupid);


--
-- Name: usergroupgrouprole_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY usergroupgrouprole
    ADD CONSTRAINT usergroupgrouprole_pkey PRIMARY KEY (usergroupid, groupid, roleid);


--
-- Name: usergrouprole_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY usergrouprole
    ADD CONSTRAINT usergrouprole_pkey PRIMARY KEY (userid, groupid, roleid);


--
-- Name: usergroups_teams_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY usergroups_teams
    ADD CONSTRAINT usergroups_teams_pkey PRIMARY KEY (usergroupid, teamid);


--
-- Name: useridmapper_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY useridmapper
    ADD CONSTRAINT useridmapper_pkey PRIMARY KEY (useridmapperid);


--
-- Name: usernotificationevent_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY usernotificationevent
    ADD CONSTRAINT usernotificationevent_pkey PRIMARY KEY (usernotificationeventid);


--
-- Name: users_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY users_groups
    ADD CONSTRAINT users_groups_pkey PRIMARY KEY (userid, groupid);


--
-- Name: users_orgs_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY users_orgs
    ADD CONSTRAINT users_orgs_pkey PRIMARY KEY (userid, organizationid);


--
-- Name: users_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY users_permissions
    ADD CONSTRAINT users_permissions_pkey PRIMARY KEY (userid, permissionid);


--
-- Name: users_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY users_roles
    ADD CONSTRAINT users_roles_pkey PRIMARY KEY (userid, roleid);


--
-- Name: users_teams_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY users_teams
    ADD CONSTRAINT users_teams_pkey PRIMARY KEY (userid, teamid);


--
-- Name: users_usergroups_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY users_usergroups
    ADD CONSTRAINT users_usergroups_pkey PRIMARY KEY (usergroupid, userid);


--
-- Name: usertracker_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY usertracker
    ADD CONSTRAINT usertracker_pkey PRIMARY KEY (usertrackerid);


--
-- Name: usertrackerpath_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY usertrackerpath
    ADD CONSTRAINT usertrackerpath_pkey PRIMARY KEY (usertrackerpathid);


--
-- Name: virtualhost_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY virtualhost
    ADD CONSTRAINT virtualhost_pkey PRIMARY KEY (virtualhostid);


--
-- Name: vocabulary_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY vocabulary
    ADD CONSTRAINT vocabulary_pkey PRIMARY KEY (vocabularyid);


--
-- Name: webdavprops_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY webdavprops
    ADD CONSTRAINT webdavprops_pkey PRIMARY KEY (webdavpropsid);


--
-- Name: website_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY website
    ADD CONSTRAINT website_pkey PRIMARY KEY (websiteid);


--
-- Name: wikinode_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY wikinode
    ADD CONSTRAINT wikinode_pkey PRIMARY KEY (nodeid);


--
-- Name: wikipage_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY wikipage
    ADD CONSTRAINT wikipage_pkey PRIMARY KEY (pageid);


--
-- Name: wikipageresource_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY wikipageresource
    ADD CONSTRAINT wikipageresource_pkey PRIMARY KEY (resourceprimkey);


--
-- Name: workflowdefinitionlink_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY workflowdefinitionlink
    ADD CONSTRAINT workflowdefinitionlink_pkey PRIMARY KEY (workflowdefinitionlinkid);


--
-- Name: workflowinstancelink_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY workflowinstancelink
    ADD CONSTRAINT workflowinstancelink_pkey PRIMARY KEY (workflowinstancelinkid);


--
-- Name: ix_103d6207; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_103d6207 ON journalarticleimage USING btree (groupid, articleid, version, elinstanceid, elname, languageid);


--
-- Name: ix_1073ab9f; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_1073ab9f ON mbmessage USING btree (groupid, categoryid);


--
-- Name: ix_119b5630; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_119b5630 ON shoppingorder USING btree (groupid, userid, pppaymentstatus);


--
-- Name: ix_11fb3e42; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_11fb3e42 ON region USING btree (countryid, active_);


--
-- Name: ix_12112599; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_12112599 ON pollsvote USING btree (questionid);


--
-- Name: ix_121ca3cb; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_121ca3cb ON socialactivity USING btree (receiveruserid);


--
-- Name: ix_12566ec2; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_12566ec2 ON company USING btree (mx);


--
-- Name: ix_1271f25f; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_1271f25f ON socialactivity USING btree (mirroractivityid);


--
-- Name: ix_128516c8; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_128516c8 ON assetlink USING btree (entryid1);


--
-- Name: ix_12851a89; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_12851a89 ON assetlink USING btree (entryid2);


--
-- Name: ix_12a92145; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_12a92145 ON socialrelation USING btree (userid1, userid2, type_);


--
-- Name: ix_12b5e51d; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_12b5e51d ON portlet USING btree (companyid, portletid);


--
-- Name: ix_12ee4898; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_12ee4898 ON calevent USING btree (groupid);


--
-- Name: ix_13805bf7; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_13805bf7 ON assettagproperty USING btree (companyid, key_);


--
-- Name: ix_13c5cd3a; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_13c5cd3a ON lock_ USING btree (uuid_);


--
-- Name: ix_143dc786; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_143dc786 ON team USING btree (groupid, name);


--
-- Name: ix_14d5a20d; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_14d5a20d ON assetlink USING btree (entryid1, type_);


--
-- Name: ix_14d8bcc0; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_14d8bcc0 ON usertrackerpath USING btree (usertrackerid);


--
-- Name: ix_14f06a6b; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_14f06a6b ON announcementsentry USING btree (classnameid, classpk, alert);


--
-- Name: ix_158b526f; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_158b526f ON journalarticleimage USING btree (groupid, articleid, version);


--
-- Name: ix_16184d57; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_16184d57 ON ratingsentry USING btree (classnameid, classpk);


--
-- Name: ix_16218a38; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_16218a38 ON group_ USING btree (livegroupid);


--
-- Name: ix_166a8f03; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_166a8f03 ON socialequityuser USING btree (rank);


--
-- Name: ix_16d87ca7; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_16d87ca7 ON region USING btree (countryid);


--
-- Name: ix_1701cb2b; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_1701cb2b ON journaltemplate USING btree (groupid, structureid);


--
-- Name: ix_181a4a1b; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_181a4a1b ON tasksproposal USING btree (classnameid, classpk);


--
-- Name: ix_1894b29a; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_1894b29a ON tasksreview USING btree (proposalid, stage, completed);


--
-- Name: ix_18f55caf; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_18f55caf ON socialequitylog USING btree (userid, actionid, actiondate, active_, type_, extradata);


--
-- Name: ix_19da007b; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_19da007b ON country USING btree (name);


--
-- Name: ix_1a1b61d2; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_1a1b61d2 ON layout USING btree (groupid, privatelayout, type_);


--
-- Name: ix_1a605e9f; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_1a605e9f ON igfolder USING btree (groupid, parentfolderid);


--
-- Name: ix_1aa07a6d; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_1aa07a6d ON website USING btree (companyid, classnameid, classpk, primary_);


--
-- Name: ix_1ad93c16; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_1ad93c16 ON mbmessage USING btree (companyid, status);


--
-- Name: ix_1afbde08; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_1afbde08 ON announcementsentry USING btree (uuid_);


--
-- Name: ix_1b1040fd; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_1b1040fd ON blogsentry USING btree (uuid_, groupid);


--
-- Name: ix_1b12ca20; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_1b12ca20 ON journaltemplate USING btree (templateid);


--
-- Name: ix_1b2b8792; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_1b2b8792 ON assetvocabulary USING btree (uuid_, groupid);


--
-- Name: ix_1b988d7a; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_1b988d7a ON usergrouprole USING btree (groupid);


--
-- Name: ix_1bb072ca; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_1bb072ca ON emailaddress USING btree (companyid);


--
-- Name: ix_1bbfd4d3; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_1bbfd4d3 ON pollsvote USING btree (questionid, userid);


--
-- Name: ix_1bd3f4c; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_1bd3f4c ON expandovalue USING btree (tableid, classpk);


--
-- Name: ix_1c717ca6; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_1c717ca6 ON shoppingitem USING btree (companyid, sku);


--
-- Name: ix_1c841592; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_1c841592 ON sclicense USING btree (active_);


--
-- Name: ix_1cdf88c; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_1cdf88c ON usergroupgrouprole USING btree (roleid);


--
-- Name: ix_1d15553e; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_1d15553e ON shoppingorder USING btree (groupid);


--
-- Name: ix_1d731f03; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_1d731f03 ON user_ USING btree (companyid, facebookid);


--
-- Name: ix_1e6464f5; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_1e6464f5 ON shoppingcategory USING btree (groupid, parentcategoryid);


--
-- Name: ix_1e9d371d; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_1e9d371d ON assetentry USING btree (classnameid, classpk);


--
-- Name: ix_1eba6821; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_1eba6821 ON assetentry USING btree (groupid, classuuid);


--
-- Name: ix_1ecc7656; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_1ecc7656 ON wikipage USING btree (nodeid, redirecttitle);


--
-- Name: ix_1efd8ee9; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_1efd8ee9 ON blogsentry USING btree (groupid, status);


--
-- Name: ix_1f00c374; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_1f00c374 ON socialactivity USING btree (mirroractivityid, classnameid, classpk);


--
-- Name: ix_206498f8; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_206498f8 ON igfolder USING btree (groupid);


--
-- Name: ix_20962903; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_20962903 ON journalcontentsearch USING btree (groupid, privatelayout);


--
-- Name: ix_20d8706c; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_20d8706c ON quartz_fired_triggers USING btree (trigger_name, trigger_group);


--
-- Name: ix_21277664; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_21277664 ON wikipageresource USING btree (nodeid, title);


--
-- Name: ix_2200aa69; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_2200aa69 ON resourcepermission USING btree (companyid, name, scope, primkey);


--
-- Name: ix_228562ad; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_228562ad ON lock_ USING btree (classname, key_);


--
-- Name: ix_22882d02; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_22882d02 ON journalarticle USING btree (groupid, urltitle);


--
-- Name: ix_22f6b5cb; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_22f6b5cb ON socialequityassetentry USING btree (assetentryid);


--
-- Name: ix_23922f7d; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_23922f7d ON layout USING btree (iconimageid);


--
-- Name: ix_23ead0d; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_23ead0d ON usergroup USING btree (companyid, name);


--
-- Name: ix_2578fbd3; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_2578fbd3 ON resource_ USING btree (codeid);


--
-- Name: ix_25d734cd; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_25d734cd ON country USING btree (active_);


--
-- Name: ix_25ffb6fa; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_25ffb6fa ON journaltemplate USING btree (smallimageid);


--
-- Name: ix_265bb0f1; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_265bb0f1 ON igimage USING btree (uuid_);


--
-- Name: ix_27006638; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_27006638 ON sclicenses_scproductentries USING btree (licenseid);


--
-- Name: ix_272991fa; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_272991fa ON scframeworkversion USING btree (groupid);


--
-- Name: ix_2857419d; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_2857419d ON journaltemplate USING btree (uuid_);


--
-- Name: ix_287b1f89; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_287b1f89 ON assetcategory USING btree (vocabularyid);


--
-- Name: ix_28c78d5c; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_28c78d5c ON blogsstatsuser USING btree (groupid, entrycount);


--
-- Name: ix_2932dd37; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_2932dd37 ON listtype USING btree (type_);


--
-- Name: ix_29ba1cf5; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_29ba1cf5 ON usertracker USING btree (companyid);


--
-- Name: ix_2a2468; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_2a2468 ON socialactivity USING btree (groupid);


--
-- Name: ix_2a2cb130; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_2a2cb130 ON emailaddress USING btree (companyid, classnameid, classpk, primary_);


--
-- Name: ix_2aba25d7; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_2aba25d7 ON bookmarksfolder USING btree (companyid);


--
-- Name: ix_2c1142e; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_2c1142e ON passwordpolicy USING btree (companyid, defaultpolicy);


--
-- Name: ix_2c61314e; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_2c61314e ON portletitem USING btree (groupid, portletid);


--
-- Name: ix_2c944354; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_2c944354 ON assettagproperty USING btree (tagid, key_);


--
-- Name: ix_2cd67c81; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_2cd67c81 ON wikipage USING btree (resourceprimkey, nodeid, version);


--
-- Name: ix_2d9a426f; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_2d9a426f ON region USING btree (active_);


--
-- Name: ix_2e1a92d4; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_2e1a92d4 ON subscription USING btree (companyid, userid, classnameid, classpk);


--
-- Name: ix_2e207659; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_2e207659 ON journalarticle USING btree (groupid, structureid);


--
-- Name: ix_2ea537d7; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_2ea537d7 ON mbmessageflag USING btree (userid, threadid, flag);


--
-- Name: ix_2ed82cad; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_2ed82cad ON assetentries_assettags USING btree (entryid);


--
-- Name: ix_301d024b; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_301d024b ON journalarticle USING btree (groupid, status);


--
-- Name: ix_30616aaa; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_30616aaa ON layoutprototype USING btree (companyid);


--
-- Name: ix_3103ef3d; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_3103ef3d ON groups_roles USING btree (roleid);


--
-- Name: ix_31fb0b08; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_31fb0b08 ON usergroups_teams USING btree (teamid);


--
-- Name: ix_31fb749a; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_31fb749a ON groups_usergroups USING btree (groupid);


--
-- Name: ix_32292ed1; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_32292ed1 ON socialrequest USING btree (receiveruserid);


--
-- Name: ix_323df109; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_323df109 ON journalarticle USING btree (companyid, status);


--
-- Name: ix_3251af16; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_3251af16 ON shoppingcoupon USING btree (groupid);


--
-- Name: ix_3269e180; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_3269e180 ON assettagproperty USING btree (tagid);


--
-- Name: ix_326f75bd; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_326f75bd ON passwordtracker USING btree (userid);


--
-- Name: ix_33a4de38; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_33a4de38 ON mbdiscussion USING btree (classnameid, classpk);


--
-- Name: ix_33b8ce8d; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_33b8ce8d ON portletitem USING btree (groupid, portletid, name);


--
-- Name: ix_33f49d16; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_33f49d16 ON journalarticle USING btree (resourceprimkey);


--
-- Name: ix_3463d95b; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_3463d95b ON journalarticle USING btree (uuid_, groupid);


--
-- Name: ix_3504b8bc; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_3504b8bc ON socialactivity USING btree (userid);


--
-- Name: ix_35a2db2f; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_35a2db2f ON journalfeed USING btree (groupid);


--
-- Name: ix_35aa8fa6; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_35aa8fa6 ON membershiprequest USING btree (groupid, userid, statusid);


--
-- Name: ix_35e3e7c6; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_35e3e7c6 ON company USING btree (system);


--
-- Name: ix_36a90ca7; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_36a90ca7 ON socialrequest USING btree (userid, classnameid, classpk, type_, receiveruserid);


--
-- Name: ix_36f512e6; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_36f512e6 ON tasksreview USING btree (userid);


--
-- Name: ix_37562284; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_37562284 ON expandotable USING btree (companyid, classnameid, name);


--
-- Name: ix_377858d2; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_377858d2 ON mbmessage USING btree (groupid, userid, status);


--
-- Name: ix_385e123e; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_385e123e ON mbmessage USING btree (groupid, categoryid, threadid, status);


--
-- Name: ix_38efe3fd; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_38efe3fd ON company USING btree (logoid);


--
-- Name: ix_38f0315; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_38f0315 ON dlfilerank USING btree (companyid, userid, fileentryid);


--
-- Name: ix_39031f51; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_39031f51 ON journalfeed USING btree (uuid_, groupid);


--
-- Name: ix_3a1e834e; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_3a1e834e ON user_ USING btree (companyid);


--
-- Name: ix_3b51bb68; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_3b51bb68 ON journalarticleimage USING btree (groupid);


--
-- Name: ix_3b69160f; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_3b69160f ON groups_usergroups USING btree (usergroupid);


--
-- Name: ix_3bb93eca; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_3bb93eca ON scframeworkversi_scproductvers USING btree (frameworkversionid);


--
-- Name: ix_3c8a04b2; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_3c8a04b2 ON socialequitylog USING btree (userid);


--
-- Name: ix_3cc1ded2; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_3cc1ded2 ON dlfolder USING btree (uuid_, groupid);


--
-- Name: ix_3cfd579d; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_3cfd579d ON mbmessageflag USING btree (threadid, flag);


--
-- Name: ix_3d070845; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_3d070845 ON journalarticle USING btree (companyid, version);


--
-- Name: ix_3d4af476; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_3d4af476 ON wikipage USING btree (nodeid, title, version);


--
-- Name: ix_3e2765fc; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_3e2765fc ON journalarticle USING btree (resourceprimkey, status);


--
-- Name: ix_3e5d78c4; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_3e5d78c4 ON usernotificationevent USING btree (userid);


--
-- Name: ix_3f9c2fa8; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_3f9c2fa8 ON socialrelation USING btree (userid2, type_);


--
-- Name: ix_3fbfa9f4; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_3fbfa9f4 ON passwordpolicy USING btree (companyid, name);


--
-- Name: ix_4115ec7a; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_4115ec7a ON mbmailinglist USING btree (uuid_);


--
-- Name: ix_415a7007; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_415a7007 ON workflowinstancelink USING btree (groupid, companyid, classnameid, classpk);


--
-- Name: ix_418e4522; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_418e4522 ON organization_ USING btree (companyid, parentorganizationid);


--
-- Name: ix_41a32e0d; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_41a32e0d ON useridmapper USING btree (type_, externaluserid);


--
-- Name: ix_41afc20c; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_41afc20c ON tasksreview USING btree (proposalid, stage, completed, rejected);


--
-- Name: ix_41f6dc8a; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_41f6dc8a ON mbthread USING btree (categoryid, priority);


--
-- Name: ix_4257db85; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_4257db85 ON mbmessage USING btree (groupid, categoryid, status);


--
-- Name: ix_42e86e58; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_42e86e58 ON journalstructure USING btree (uuid_, groupid);


--
-- Name: ix_430d791f; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_430d791f ON blogsentry USING btree (companyid, displaydate);


--
-- Name: ix_431a3960; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_431a3960 ON virtualhost USING btree (hostname);


--
-- Name: ix_43261870; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_43261870 ON dlfileentry USING btree (groupid, userid);


--
-- Name: ix_432f0ab0; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_432f0ab0 ON wikipage USING btree (nodeid, head, status);


--
-- Name: ix_43840eeb; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_43840eeb ON blogsstatsuser USING btree (groupid);


--
-- Name: ix_449a10b9; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_449a10b9 ON role_ USING btree (companyid);


--
-- Name: ix_451e7ae3; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_451e7ae3 ON bookmarksfolder USING btree (uuid_);


--
-- Name: ix_4539a99c; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_4539a99c ON announcementsflag USING btree (userid, entryid, value);


--
-- Name: ix_467956fd; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_467956fd ON scproductscreenshot USING btree (productentryid);


--
-- Name: ix_46b0ae8e; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_46b0ae8e ON usertracker USING btree (sessionid);


--
-- Name: ix_46eef3c8; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_46eef3c8 ON wikipage USING btree (nodeid, parenttitle);


--
-- Name: ix_4831ebe4; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_4831ebe4 ON dlfileshortcut USING btree (uuid_);


--
-- Name: ix_48550691; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_48550691 ON layoutset USING btree (groupid, privatelayout);


--
-- Name: ix_485f7e98; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_485f7e98 ON mbthread USING btree (groupid, categoryid, status);


--
-- Name: ix_48814bba; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_48814bba ON mbban USING btree (userid);


--
-- Name: ix_49c37475; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_49c37475 ON dlfolder USING btree (groupid, parentfolderid);


--
-- Name: ix_49d2dec4; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_49d2dec4 ON emailaddress USING btree (companyid, classnameid);


--
-- Name: ix_49d5872c; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_49d5872c ON socialrequest USING btree (uuid_);


--
-- Name: ix_49e15a23; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_49e15a23 ON blogsentry USING btree (groupid, userid, status);


--
-- Name: ix_4a1f4402; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_4a1f4402 ON resourcepermission USING btree (companyid, name, scope, primkey, roleid, ownerid, actionids);


--
-- Name: ix_4a527dd3; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_4a527dd3 ON orggrouprole USING btree (groupid);


--
-- Name: ix_4b52be89; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_4b52be89 ON socialrelation USING btree (userid1, type_);


--
-- Name: ix_4b7247f6; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_4b7247f6 ON dlfileshortcut USING btree (tofileentryid);


--
-- Name: ix_4cb1b2b4; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_4cb1b2b4 ON dlfileentry USING btree (companyid);


--
-- Name: ix_4d040680; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_4d040680 ON usergrouprole USING btree (userid, groupid);


--
-- Name: ix_4d06ad51; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_4d06ad51 ON users_teams USING btree (teamid);


--
-- Name: ix_4d0c7f8d; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_4d0c7f8d ON tasksreview USING btree (proposalid);


--
-- Name: ix_4d19c2b8; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_4d19c2b8 ON permission_ USING btree (actionid, resourceid);


--
-- Name: ix_4d37bb00; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_4d37bb00 ON assetcategory USING btree (uuid_);


--
-- Name: ix_4d5cd982; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_4d5cd982 ON journalarticle USING btree (groupid, articleid, status);


--
-- Name: ix_4f0315b8; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_4f0315b8 ON servicecomponent USING btree (buildnamespace, buildnumber);


--
-- Name: ix_4f0f0ca7; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_4f0f0ca7 ON website USING btree (companyid, classnameid);


--
-- Name: ix_4f973efe; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_4f973efe ON socialrequest USING btree (uuid_, groupid);


--
-- Name: ix_4fddd2bf; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_4fddd2bf ON calevent USING btree (groupid, repeating);


--
-- Name: ix_50702693; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_50702693 ON assettagstats USING btree (classnameid);


--
-- Name: ix_507ba031; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_507ba031 ON blogsstatsuser USING btree (userid, lastpostdate);


--
-- Name: ix_50c36d79; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_50c36d79 ON journalfeed USING btree (uuid_);


--
-- Name: ix_50f1904a; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_50f1904a ON mbthread USING btree (groupid, categoryid, lastpostdate);


--
-- Name: ix_51556082; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_51556082 ON dlfolder USING btree (parentfolderid, name);


--
-- Name: ix_51a8d44d; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_51a8d44d ON mbmessage USING btree (classnameid, classpk);


--
-- Name: ix_51f087f4; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_51f087f4 ON pollsquestion USING btree (uuid_);


--
-- Name: ix_5200100c; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_5200100c ON bookmarksentry USING btree (groupid, folderid);


--
-- Name: ix_5204c37b; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_5204c37b ON user_ USING btree (companyid, active_);


--
-- Name: ix_52340033; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_52340033 ON assetcategoryproperty USING btree (companyid, key_);


--
-- Name: ix_524fefce; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_524fefce ON usergroup USING btree (companyid);


--
-- Name: ix_5327bb79; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_5327bb79 ON sclicense USING btree (active_, recommended);


--
-- Name: ix_5391712; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_5391712 ON dlfileentry USING btree (groupid, folderid, name);


--
-- Name: ix_54101cc8; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_54101cc8 ON shoppingcart USING btree (userid);


--
-- Name: ix_541bda0f; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_541bda0f ON socialequitylog USING btree (assetentryid, actionid, active_, extradata);


--
-- Name: ix_54243afd; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_54243afd ON subscription USING btree (userid);


--
-- Name: ix_546f2d5c; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_546f2d5c ON wikipage USING btree (nodeid, status);


--
-- Name: ix_551a519f; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_551a519f ON emailaddress USING btree (companyid, classnameid, classpk);


--
-- Name: ix_557a639f; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_557a639f ON layoutprototype USING btree (companyid, active_);


--
-- Name: ix_55f58818; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_55f58818 ON assetvocabulary USING btree (uuid_);


--
-- Name: ix_55f63d98; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_55f63d98 ON layoutsetprototype USING btree (companyid);


--
-- Name: ix_56682cc4; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_56682cc4 ON assettagstats USING btree (tagid, classnameid);


--
-- Name: ix_56e0ab21; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_56e0ab21 ON assetlink USING btree (entryid1, entryid2);


--
-- Name: ix_5a40cdcc; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_5a40cdcc ON socialrelation USING btree (userid1);


--
-- Name: ix_5a40d18d; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_5a40d18d ON socialrelation USING btree (userid2);


--
-- Name: ix_5aa68501; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_5aa68501 ON group_ USING btree (companyid, name);


--
-- Name: ix_5adbe171; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_5adbe171 ON user_ USING btree (contactid);


--
-- Name: ix_5b153fb2; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_5b153fb2 ON mbmessage USING btree (groupid);


--
-- Name: ix_5bc8b0d4; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_5bc8b0d4 ON address USING btree (userid);


--
-- Name: ix_5bddb872; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_5bddb872 ON group_ USING btree (companyid, friendlyurl);


--
-- Name: ix_5c3ff12a; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_5c3ff12a ON mbban USING btree (groupid);


--
-- Name: ix_5c6be4c7; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_5c6be4c7 ON tasksreview USING btree (userid, proposalid);


--
-- Name: ix_5cce79c8; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_5cce79c8 ON calevent USING btree (uuid_, groupid);


--
-- Name: ix_5d25244f; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_5d25244f ON scproductentry USING btree (companyid);


--
-- Name: ix_5d6fe3f0; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_5d6fe3f0 ON wikinode USING btree (companyid);


--
-- Name: ix_5de0be11; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_5de0be11 ON group_ USING btree (companyid, classnameid, livegroupid, name);


--
-- Name: ix_5eb4e2fb; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_5eb4e2fb ON role_ USING btree (subtype);


--
-- Name: ix_5f615d3e; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_5f615d3e ON shoppingcategory USING btree (groupid);


--
-- Name: ix_5feabbc; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_5feabbc ON quartz_fired_triggers USING btree (trigger_name);


--
-- Name: ix_60214cf6; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_60214cf6 ON igfolder USING btree (companyid);


--
-- Name: ix_60b99860; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_60b99860 ON resourcepermission USING btree (companyid, name, scope);


--
-- Name: ix_61171e99; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_61171e99 ON socialrelation USING btree (companyid);


--
-- Name: ix_615e9f7a; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_615e9f7a ON user_ USING btree (companyid, emailaddress);


--
-- Name: ix_621e19d; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_621e19d ON blogsentry USING btree (groupid, displaydate);


--
-- Name: ix_62d1b3ad; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_62d1b3ad ON journaltemplate USING btree (uuid_, groupid);


--
-- Name: ix_63820a7; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_63820a7 ON igimage USING btree (groupid);


--
-- Name: ix_64b194f2; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_64b194f2 ON quartz_fired_triggers USING btree (trigger_group);


--
-- Name: ix_64b1bc66; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_64b1bc66 ON socialactivity USING btree (companyid);


--
-- Name: ix_64f0b572; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_64f0b572 ON igimage USING btree (largeimageid);


--
-- Name: ix_64f0fe40; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_64f0fe40 ON dlfileentry USING btree (uuid_);


--
-- Name: ix_65576cbc; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_65576cbc ON journalfeed USING btree (groupid, feedid);


--
-- Name: ix_65e84af4; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_65e84af4 ON wikipage USING btree (nodeid, head, parenttitle);


--
-- Name: ix_6660b399; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_6660b399 ON pollschoice USING btree (uuid_);


--
-- Name: ix_66d496a3; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_66d496a3 ON contact_ USING btree (companyid);


--
-- Name: ix_66d70879; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_66d70879 ON membershiprequest USING btree (userid);


--
-- Name: ix_66ff2503; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_66ff2503 ON users_usergroups USING btree (usergroupid);


--
-- Name: ix_6702ca92; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_6702ca92 ON journalstructure USING btree (uuid_);


--
-- Name: ix_67de7856; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_67de7856 ON resource_ USING btree (codeid, primkey);


--
-- Name: ix_6838e427; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_6838e427 ON journalcontentsearch USING btree (groupid, articleid);


--
-- Name: ix_68c0f69c; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_68c0f69c ON journalarticle USING btree (groupid, articleid);


--
-- Name: ix_69157a4d; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_69157a4d ON blogsentry USING btree (uuid_);


--
-- Name: ix_69771487; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_69771487 ON usergroup USING btree (companyid, parentusergroupid);


--
-- Name: ix_69951a25; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_69951a25 ON mbban USING btree (banuserid);


--
-- Name: ix_6a925a4d; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_6a925a4d ON image USING btree (size_);


--
-- Name: ix_6af0d434; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_6af0d434 ON orglabor USING btree (organizationid);


--
-- Name: ix_6b42b3e7; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_6b42b3e7 ON socialequityuser USING btree (groupid);


--
-- Name: ix_6bbb7682; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_6bbb7682 ON groups_orgs USING btree (organizationid);


--
-- Name: ix_6c112d7c; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_6c112d7c ON wikinode USING btree (uuid_);


--
-- Name: ix_6c53da4e; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_6c53da4e ON orggrouppermission USING btree (permissionid);


--
-- Name: ix_6c572dac; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_6c572dac ON scproductscreenshot USING btree (thumbnailid);


--
-- Name: ix_6d5f9b87; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_6d5f9b87 ON shoppingitemfield USING btree (itemid);


--
-- Name: ix_6de88b06; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_6de88b06 ON layout USING btree (groupid, privatelayout, parentlayoutid);


--
-- Name: ix_6e1764f; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_6e1764f ON scframeworkversion USING btree (groupid, active_);


--
-- Name: ix_6ecbd5d; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_6ecbd5d ON socialequityuser USING btree (userid);


--
-- Name: ix_6edb9600; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_6edb9600 ON announcementsdelivery USING btree (userid);


--
-- Name: ix_6eec675e; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_6eec675e ON tasksproposal USING btree (groupid, userid);


--
-- Name: ix_6ef03e4e; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_6ef03e4e ON user_ USING btree (companyid, defaultuser);


--
-- Name: ix_7020130f; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_7020130f ON scproductversion USING btree (directdownloadurl);


--
-- Name: ix_705f5aa3; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_705f5aa3 ON layout USING btree (groupid, privatelayout);


--
-- Name: ix_70afea01; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_70afea01 ON tasksreview USING btree (proposalid, stage);


--
-- Name: ix_7162c27c; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_7162c27c ON layout USING btree (groupid, privatelayout, layoutid);


--
-- Name: ix_7171b2e8; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_7171b2e8 ON pluginsetting USING btree (companyid, pluginid, plugintype);


--
-- Name: ix_717b97e1; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_717b97e1 ON country USING btree (a2);


--
-- Name: ix_717b9ba2; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_717b9ba2 ON country USING btree (a3);


--
-- Name: ix_717fdd47; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_717fdd47 ON resourcecode USING btree (companyid);


--
-- Name: ix_71cb1123; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_71cb1123 ON address USING btree (companyid, classnameid, classpk);


--
-- Name: ix_72ef6041; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_72ef6041 ON blogsentry USING btree (companyid);


--
-- Name: ix_72f87291; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_72f87291 ON scproductentry USING btree (groupid);


--
-- Name: ix_7306c60; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_7306c60 ON assetentry USING btree (companyid);


--
-- Name: ix_7311e812; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_7311e812 ON scproductentry USING btree (repogroupid, repoartifactid);


--
-- Name: ix_7338606f; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_7338606f ON servicecomponent USING btree (buildnamespace);


--
-- Name: ix_73c52252; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_73c52252 ON usergroupgrouprole USING btree (usergroupid, groupid);


--
-- Name: ix_75267dca; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_75267dca ON groups_orgs USING btree (groupid);


--
-- Name: ix_75b95071; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_75b95071 ON mbmessage USING btree (threadid);


--
-- Name: ix_7609b2ae; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_7609b2ae ON wikinode USING btree (uuid_, groupid);


--
-- Name: ix_762f63c6; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_762f63c6 ON user_ USING btree (emailaddress);


--
-- Name: ix_76ce9cdd; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_76ce9cdd ON mbmailinglist USING btree (groupid, categoryid);


--
-- Name: ix_77923653; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_77923653 ON journaltemplate USING btree (groupid);


--
-- Name: ix_786d171a; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_786d171a ON subscription USING btree (companyid, classnameid, classpk);


--
-- Name: ix_79d0120b; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_79d0120b ON mbdiscussion USING btree (classnameid);


--
-- Name: ix_7a040c32; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_7a040c32 ON mbmessage USING btree (userid);


--
-- Name: ix_7a3619c6; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_7a3619c6 ON roles_permissions USING btree (permissionid);


--
-- Name: ix_7acc74c9; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_7acc74c9 ON journalcontentsearch USING btree (groupid, privatelayout, layoutid, portletid);


--
-- Name: ix_7b2917be; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_7b2917be ON mbmessageflag USING btree (userid);


--
-- Name: ix_7b43cd8; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_7b43cd8 ON emailaddress USING btree (userid);


--
-- Name: ix_7b590a7a; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_7b590a7a ON group_ USING btree (type_, active_);


--
-- Name: ix_7bb1826b; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_7bb1826b ON assetcategory USING btree (parentcategoryid);


--
-- Name: ix_7c9e46ba; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_7c9e46ba ON assettag USING btree (groupid);


--
-- Name: ix_7cc7d73e; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_7cc7d73e ON journalcontentsearch USING btree (groupid, privatelayout, articleid);


--
-- Name: ix_7ef4ec0e; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_7ef4ec0e ON users_orgs USING btree (organizationid);


--
-- Name: ix_7f187e63; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_7f187e63 ON usergroups_teams USING btree (usergroupid);


--
-- Name: ix_7f703619; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_7f703619 ON bookmarksfolder USING btree (groupid);


--
-- Name: ix_7fb27324; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_7fb27324 ON tasksproposal USING btree (groupid);


--
-- Name: ix_8040c593; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_8040c593 ON quartz_triggers USING btree (trigger_state, next_fire_time);


--
-- Name: ix_804154af; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_804154af ON quartz_fired_triggers USING btree (instance_name);


--
-- Name: ix_80cc9508; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_80cc9508 ON portlet USING btree (companyid);


--
-- Name: ix_80f7a9c2; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_80f7a9c2 ON socialrequest USING btree (userid);


--
-- Name: ix_812ce07a; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_812ce07a ON phone USING btree (companyid, classnameid, classpk, primary_);


--
-- Name: ix_81a50303; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_81a50303 ON blogsentry USING btree (groupid);


--
-- Name: ix_81efbff5; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_81efbff5 ON expandorow USING btree (tableid, classpk);


--
-- Name: ix_81f2db09; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_81f2db09 ON resourceaction USING btree (name);


--
-- Name: ix_82254c25; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_82254c25 ON blogsstatsuser USING btree (groupid, userid);


--
-- Name: ix_82e39a0c; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_82e39a0c ON socialactivity USING btree (classnameid);


--
-- Name: ix_834bceb6; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_834bceb6 ON organization_ USING btree (companyid);


--
-- Name: ix_8377a211; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_8377a211 ON scproductversion USING btree (productentryid);


--
-- Name: ix_84471fd2; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_84471fd2 ON groups_roles USING btree (groupid);


--
-- Name: ix_847f92b5; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_847f92b5 ON mbstatsuser USING btree (userid);


--
-- Name: ix_84ab0309; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_84ab0309 ON journalarticleresource USING btree (uuid_, groupid);


--
-- Name: ix_85c52eec; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_85c52eec ON journalarticle USING btree (groupid, articleid, version);


--
-- Name: ix_8654719f; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_8654719f ON assetcategoryproperty USING btree (companyid);


--
-- Name: ix_871412df; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_871412df ON usergrouprole USING btree (groupid, roleid);


--
-- Name: ix_8831e4fc; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_8831e4fc ON journalstructure USING btree (structureid);


--
-- Name: ix_88705859; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_88705859 ON resourcepermission USING btree (companyid, name, primkey, ownerid);


--
-- Name: ix_887a2c95; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_887a2c95 ON usergrouprole USING btree (roleid);


--
-- Name: ix_887be56a; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_887be56a ON usergrouprole USING btree (userid);


--
-- Name: ix_88df994a; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_88df994a ON journalarticleresource USING btree (groupid, articleid);


--
-- Name: ix_89509087; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_89509087 ON user_ USING btree (companyid, openid);


--
-- Name: ix_8956b2c4; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_8956b2c4 ON igimage USING btree (groupid, folderid);


--
-- Name: ix_899d3dfb; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_899d3dfb ON wikipage USING btree (uuid_, groupid);


--
-- Name: ix_8a1cc4b; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_8a1cc4b ON membershiprequest USING btree (groupid);


--
-- Name: ix_8abc4e3b; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_8abc4e3b ON mbban USING btree (groupid, banuserid);


--
-- Name: ix_8ae58a91; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_8ae58a91 ON users_permissions USING btree (permissionid);


--
-- Name: ix_8bd6bca7; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_8bd6bca7 ON release_ USING btree (servletcontextname);


--
-- Name: ix_8cace77b; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_8cace77b ON blogsentry USING btree (companyid, userid);


--
-- Name: ix_8d12316e; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_8d12316e ON mbmessage USING btree (uuid_, groupid);


--
-- Name: ix_8d83d0ce; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_8d83d0ce ON resourcepermission USING btree (companyid, name, scope, primkey, roleid);


--
-- Name: ix_8deae14e; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_8deae14e ON journalarticle USING btree (groupid, templateid);


--
-- Name: ix_8e71167f; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_8e71167f ON portletitem USING btree (groupid, portletid, classnameid, name);


--
-- Name: ix_8eb8c5ec; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_8eb8c5ec ON mbmessage USING btree (groupid, userid);


--
-- Name: ix_8f32dec9; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_8f32dec9 ON socialactivity USING btree (groupid, userid, createdate, classnameid, classpk, type_, receiveruserid);


--
-- Name: ix_8f542794; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_8f542794 ON assetlink USING btree (entryid1, entryid2, type_);


--
-- Name: ix_902fd874; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_902fd874 ON dlfolder USING btree (groupid, parentfolderid, name);


--
-- Name: ix_903c1b28; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_903c1b28 ON socialequitysetting USING btree (groupid, classnameid, actionid, type_);


--
-- Name: ix_903dc750; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_903dc750 ON shoppingitem USING btree (largeimageid);


--
-- Name: ix_90cda39a; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_90cda39a ON blogsstatsuser USING btree (companyid, entrycount);


--
-- Name: ix_9112a7a0; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_9112a7a0 ON expandovalue USING btree (rowid_);


--
-- Name: ix_9168e2c9; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_9168e2c9 ON mbstatsuser USING btree (groupid, userid);


--
-- Name: ix_9178fc71; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_9178fc71 ON layoutsetprototype USING btree (companyid, active_);


--
-- Name: ix_91f132c; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_91f132c ON assetlink USING btree (entryid2, type_);


--
-- Name: ix_9207cb31; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_9207cb31 ON journalcontentsearch USING btree (articleid);


--
-- Name: ix_920cd8b1; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_920cd8b1 ON wikinode USING btree (groupid, name);


--
-- Name: ix_9226dbb4; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_9226dbb4 ON address USING btree (companyid, classnameid, classpk, primary_);


--
-- Name: ix_923bd178; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_923bd178 ON address USING btree (companyid, classnameid, classpk, mailing);


--
-- Name: ix_9356f865; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_9356f865 ON journalarticle USING btree (groupid);


--
-- Name: ix_93cf8193; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_93cf8193 ON dlfileentry USING btree (groupid, folderid);


--
-- Name: ix_93d5ad4e; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_93d5ad4e ON address USING btree (companyid);


--
-- Name: ix_941ba8c3; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_941ba8c3 ON shard USING btree (name);


--
-- Name: ix_945e27c7; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_945e27c7 ON socialequityuser USING btree (groupid, rank);


--
-- Name: ix_9464ca; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_9464ca ON assettagstats USING btree (tagid);


--
-- Name: ix_94d1054d; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_94d1054d ON wikipage USING btree (resourceprimkey, nodeid, status);


--
-- Name: ix_95135d1c; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_95135d1c ON socialrelation USING btree (companyid, type_);


--
-- Name: ix_95c0ea45; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_95c0ea45 ON mbthread USING btree (groupid);


--
-- Name: ix_967799c0; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_967799c0 ON bookmarksfolder USING btree (groupid, parentfolderid);


--
-- Name: ix_96bdd537; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_96bdd537 ON portletitem USING btree (groupid, classnameid);


--
-- Name: ix_96f07007; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_96f07007 ON website USING btree (companyid);


--
-- Name: ix_9782ad88; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_9782ad88 ON user_ USING btree (companyid, userid);


--
-- Name: ix_97dfa146; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_97dfa146 ON webdavprops USING btree (classnameid, classpk);


--
-- Name: ix_98e6a9cb; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_98e6a9cb ON scproductentry USING btree (groupid, userid);


--
-- Name: ix_9955efb5; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_9955efb5 ON quartz_triggers USING btree (trigger_state);


--
-- Name: ix_997eedd2; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_997eedd2 ON wikipage USING btree (nodeid, title);


--
-- Name: ix_99da856; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_99da856 ON assetcategoryproperty USING btree (categoryid);


--
-- Name: ix_9a2d11b2; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_9a2d11b2 ON mbthread USING btree (groupid, categoryid);


--
-- Name: ix_9a53569; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_9a53569 ON phone USING btree (companyid, classnameid, classpk);


--
-- Name: ix_9bbafb1e; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_9bbafb1e ON igfolder USING btree (groupid, parentfolderid, name);


--
-- Name: ix_9c0e478f; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_9c0e478f ON wikipage USING btree (uuid_);


--
-- Name: ix_9c7eb9f; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_9c7eb9f ON announcementsflag USING btree (entryid);


--
-- Name: ix_9dc8e57; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_9dc8e57 ON mbmessage USING btree (threadid, status);


--
-- Name: ix_9ddd15ea; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_9ddd15ea ON assetcategory USING btree (parentcategoryid, name);


--
-- Name: ix_9ddd21e5; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_9ddd21e5 ON expandovalue USING btree (columnid, rowid_);


--
-- Name: ix_9f704a14; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_9f704a14 ON phone USING btree (companyid);


--
-- Name: ix_9f7655da; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_9f7655da ON wikipage USING btree (nodeid, head, parenttitle, status);


--
-- Name: ix_9ff342ea; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_9ff342ea ON pollsquestion USING btree (groupid);


--
-- Name: ix_a00a898f; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_a00a898f ON mbstatsuser USING btree (groupid);


--
-- Name: ix_a083d394; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_a083d394 ON virtualhost USING btree (companyid, layoutsetid);


--
-- Name: ix_a098efbf; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_a098efbf ON users_teams USING btree (userid);


--
-- Name: ix_a0fa597e; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_a0fa597e ON socialequitylog USING btree (userid, assetentryid, actionid, actiondate, active_, type_, extradata);


--
-- Name: ix_a18034a4; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_a18034a4 ON user_ USING btree (portraitid);


--
-- Name: ix_a188f560; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_a188f560 ON assetentries_assetcategories USING btree (categoryid);


--
-- Name: ix_a1a8cb8b; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_a1a8cb8b ON ratingsentry USING btree (classnameid, classpk, score);


--
-- Name: ix_a2001730; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_a2001730 ON wikipage USING btree (format);


--
-- Name: ix_a2e4afba; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_a2e4afba ON phone USING btree (companyid, classnameid);


--
-- Name: ix_a32c097e; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_a32c097e ON resourcecode USING btree (companyid, name, scope);


--
-- Name: ix_a37a0588; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_a37a0588 ON resourcepermission USING btree (roleid);


--
-- Name: ix_a40b8bec; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_a40b8bec ON layoutset USING btree (groupid);


--
-- Name: ix_a425f71a; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_a425f71a ON orggrouppermission USING btree (groupid);


--
-- Name: ix_a4db1f0f; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_a4db1f0f ON workflowdefinitionlink USING btree (companyid, workflowdefinitionname, workflowdefinitionversion);


--
-- Name: ix_a5f57b61; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_a5f57b61 ON blogsentry USING btree (companyid, userid, status);


--
-- Name: ix_a65a1f8b; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_a65a1f8b ON dlfilerank USING btree (fileentryid);


--
-- Name: ix_a6973a8e; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_a6973a8e ON mbmessageflag USING btree (messageid, flag);


--
-- Name: ix_a6e99284; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_a6e99284 ON ratingsstats USING btree (classnameid, classpk);


--
-- Name: ix_a6ef0b81; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_a6ef0b81 ON announcementsentry USING btree (classnameid, classpk);


--
-- Name: ix_a7038cd7; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_a7038cd7 ON mbmessage USING btree (threadid, parentmessageid);


--
-- Name: ix_a74db14c; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_a74db14c ON dlfolder USING btree (companyid);


--
-- Name: ix_a853c757; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_a853c757 ON socialactivity USING btree (classnameid, classpk);


--
-- Name: ix_a88e424e; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_a88e424e ON role_ USING btree (companyid, classnameid, classpk);


--
-- Name: ix_a8b0d276; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_a8b0d276 ON workflowdefinitionlink USING btree (companyid);


--
-- Name: ix_a8c0cbe8; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_a8c0cbe8 ON expandocolumn USING btree (tableid);


--
-- Name: ix_a90fe5a0; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_a90fe5a0 ON socialrequest USING btree (companyid);


--
-- Name: ix_aacaff40; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_aacaff40 ON resourcecode USING btree (name);


--
-- Name: ix_aae8df83; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_aae8df83 ON igimage USING btree (groupid, folderid, name);


--
-- Name: ix_ab044d1c; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_ab044d1c ON orggrouprole USING btree (roleid);


--
-- Name: ix_ab5906a8; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_ab5906a8 ON socialrequest USING btree (userid, status);


--
-- Name: ix_ab6e9996; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_ab6e9996 ON journalstructure USING btree (groupid, structureid);


--
-- Name: ix_aba5cec2; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_aba5cec2 ON group_ USING btree (companyid);


--
-- Name: ix_abd7dac0; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_abd7dac0 ON address USING btree (companyid, classnameid);


--
-- Name: ix_ac18d8f8; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_ac18d8f8 ON socialequitylog USING btree (assetentryid, actionid, actiondate, active_, type_, extradata);


--
-- Name: ix_adee6a17; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_adee6a17 ON quartz_fired_triggers USING btree (job_name);


--
-- Name: ix_ae6e9907; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_ae6e9907 ON team USING btree (groupid);


--
-- Name: ix_ae8224cc; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_ae8224cc ON scproductscreenshot USING btree (fullimageid);


--
-- Name: ix_aedd9cb5; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_aedd9cb5 ON mbthread USING btree (lastpostdate, priority);


--
-- Name: ix_b0051937; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_b0051937 ON dlfileshortcut USING btree (groupid, folderid);


--
-- Name: ix_b10efd68; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_b10efd68 ON igfolder USING btree (uuid_, groupid);


--
-- Name: ix_b1432d30; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_b1432d30 ON mbmessage USING btree (companyid);


--
-- Name: ix_b185e980; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_b185e980 ON assetcategory USING btree (parentcategoryid, vocabularyid);


--
-- Name: ix_b22d908c; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_b22d908c ON assetvocabulary USING btree (companyid);


--
-- Name: ix_b2468446; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_b2468446 ON ticket USING btree (key_);


--
-- Name: ix_b27a301f; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_b27a301f ON classname_ USING btree (value);


--
-- Name: ix_b29fef17; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_b29fef17 ON expandovalue USING btree (classnameid, classpk);


--
-- Name: ix_b2a61b55; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_b2a61b55 ON assetentries_assettags USING btree (tagid);


--
-- Name: ix_b3b318dc; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_b3b318dc ON journalcontentsearch USING btree (groupid, privatelayout, layoutid);


--
-- Name: ix_b47e3c11; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_b47e3c11 ON ratingsentry USING btree (userid, classnameid, classpk);


--
-- Name: ix_b480a672; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_b480a672 ON wikinode USING btree (groupid);


--
-- Name: ix_b5ae8a85; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_b5ae8a85 ON expandotable USING btree (companyid, classnameid);


--
-- Name: ix_b5c9c690; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_b5c9c690 ON socialrelation USING btree (userid1, userid2);


--
-- Name: ix_b5ca2dc; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_b5ca2dc ON mbdiscussion USING btree (threadid);


--
-- Name: ix_b5f82c7a; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_b5f82c7a ON shoppingorderitem USING btree (orderid);


--
-- Name: ix_b670ba39; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_b670ba39 ON bookmarksentry USING btree (uuid_);


--
-- Name: ix_b674ab58; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_b674ab58 ON mbmessage USING btree (groupid, categoryid, threadid);


--
-- Name: ix_b6b8ca0e; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_b6b8ca0e ON assetvocabulary USING btree (groupid);


--
-- Name: ix_b6ee8c9e; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_b6ee8c9e ON workflowdefinitionlink USING btree (groupid, companyid, classnameid);


--
-- Name: ix_b71e92d5; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_b71e92d5 ON expandovalue USING btree (tableid, rowid_);


--
-- Name: ix_b771d67; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_b771d67 ON wikipage USING btree (resourceprimkey, nodeid);


--
-- Name: ix_b9746445; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_b9746445 ON pluginsetting USING btree (companyid);


--
-- Name: ix_b97f5608; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_b97f5608 ON journalstructure USING btree (groupid);


--
-- Name: ix_ba4413d5; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_ba4413d5 ON announcementsdelivery USING btree (userid, type_);


--
-- Name: ix_bab9a1f7; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_bab9a1f7 ON quartz_fired_triggers USING btree (job_group);


--
-- Name: ix_bafb116e; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_bafb116e ON dlfilerank USING btree (groupid, userid);


--
-- Name: ix_bb0c2905; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_bb0c2905 ON blogsentry USING btree (companyid, displaydate, status);


--
-- Name: ix_bb51f1d9; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_bb51f1d9 ON blogsstatsuser USING btree (userid);


--
-- Name: ix_bb870c11; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_bb870c11 ON mbcategory USING btree (groupid);


--
-- Name: ix_bbca55b; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_bbca55b ON group_ USING btree (companyid, livegroupid, name);


--
-- Name: ix_bc2c4231; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_bc2c4231 ON layout USING btree (groupid, privatelayout, friendlyurl);


--
-- Name: ix_bc2e7e6a; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_bc2e7e6a ON dlfileentry USING btree (uuid_, groupid);


--
-- Name: ix_bc735dcf; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_bc735dcf ON mbcategory USING btree (companyid);


--
-- Name: ix_be4df2bf; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_be4df2bf ON assetcategory USING btree (parentcategoryid, name, vocabularyid);


--
-- Name: ix_be79e1e1; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_be79e1e1 ON igimage USING btree (groupid, userid);


--
-- Name: ix_be8102d6; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_be8102d6 ON users_usergroups USING btree (userid);


--
-- Name: ix_be898221; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_be898221 ON wikipageresource USING btree (uuid_);


--
-- Name: ix_bea33ab8; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_bea33ab8 ON wikipage USING btree (nodeid, title, status);


--
-- Name: ix_bfeb984f; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_bfeb984f ON mbmailinglist USING btree (active_);


--
-- Name: ix_c099d61a; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_c099d61a ON layout USING btree (groupid);


--
-- Name: ix_c0aad74d; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_c0aad74d ON assetvocabulary USING btree (groupid, name);


--
-- Name: ix_c19e5f31; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_c19e5f31 ON users_roles USING btree (roleid);


--
-- Name: ix_c1a01806; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_c1a01806 ON users_roles USING btree (userid);


--
-- Name: ix_c1ad2122; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_c1ad2122 ON calevent USING btree (uuid_);


--
-- Name: ix_c1c9a8fd; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_c1c9a8fd ON mbmessageflag USING btree (threadid);


--
-- Name: ix_c2626edb; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_c2626edb ON mbcategory USING btree (uuid_);


--
-- Name: ix_c26aa64d; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_c26aa64d ON users_permissions USING btree (userid);


--
-- Name: ix_c28b41dc; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_c28b41dc ON shoppingcart USING btree (groupid);


--
-- Name: ix_c28c72ec; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_c28c72ec ON membershiprequest USING btree (groupid, statusid);


--
-- Name: ix_c31a64c6; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_c31a64c6 ON socialrelation USING btree (type_);


--
-- Name: ix_c3a17327; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_c3a17327 ON passwordpolicyrel USING btree (classnameid, classpk);


--
-- Name: ix_c3aa93b8; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_c3aa93b8 ON journalcontentsearch USING btree (groupid, privatelayout, layoutid, portletid, articleid);


--
-- Name: ix_c48736b; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_c48736b ON groups_permissions USING btree (groupid);


--
-- Name: ix_c4f9e699; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_c4f9e699 ON users_groups USING btree (groupid);


--
-- Name: ix_c57b16bc; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_c57b16bc ON mbmessage USING btree (uuid_);


--
-- Name: ix_c5806019; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_c5806019 ON user_ USING btree (companyid, screenname);


--
-- Name: ix_c68dc967; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_c68dc967 ON dlfileversion USING btree (fileentryid);


--
-- Name: ix_c7057ff7; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_c7057ff7 ON portletpreferences USING btree (ownerid, ownertype, plid, portletid);


--
-- Name: ix_c7fbc998; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_c7fbc998 ON layout USING btree (companyid);


--
-- Name: ix_c8a9c476; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_c8a9c476 ON wikipage USING btree (nodeid);


--
-- Name: ix_c94c7708; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_c94c7708 ON resourcepermission USING btree (companyid, name, primkey, roleid, actionids);


--
-- Name: ix_c98c0d78; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_c98c0d78 ON scframeworkversion USING btree (companyid);


--
-- Name: ix_ca0bd48c; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_ca0bd48c ON journalstructure USING btree (groupid, parentstructureid);


--
-- Name: ix_ca9afb7c; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_ca9afb7c ON expandovalue USING btree (tableid, columnid);


--
-- Name: ix_cab0ccc8; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_cab0ccc8 ON usergroupgrouprole USING btree (groupid, roleid);


--
-- Name: ix_cbc408d8; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_cbc408d8 ON dlfolder USING btree (uuid_);


--
-- Name: ix_cbe204; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_cbe204 ON role_ USING btree (type_, subtype);


--
-- Name: ix_cc86a444; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_cc86a444 ON socialrequest USING btree (userid, classnameid, classpk, type_, status);


--
-- Name: ix_cc993ecb; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_cc993ecb ON mbthread USING btree (rootmessageid);


--
-- Name: ix_ccbe4063; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_ccbe4063 ON usergroupgrouprole USING btree (groupid);


--
-- Name: ix_cd25266e; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_cd25266e ON passwordpolicyrel USING btree (passwordpolicyid);


--
-- Name: ix_ced31606; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_ced31606 ON layout USING btree (uuid_, groupid);


--
-- Name: ix_d0822724; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_d0822724 ON layout USING btree (uuid_);


--
-- Name: ix_d0d5e397; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_d0d5e397 ON group_ USING btree (companyid, classnameid, classpk);


--
-- Name: ix_d180d4ae; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_d180d4ae ON mbmessageflag USING btree (messageid);


--
-- Name: ix_d1c44a6e; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_d1c44a6e ON useridmapper USING btree (userid, type_);


--
-- Name: ix_d1f795f1; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_d1f795f1 ON portalpreferences USING btree (ownerid, ownertype);


--
-- Name: ix_d20c434d; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_d20c434d ON dlfileentry USING btree (groupid, userid, folderid);


--
-- Name: ix_d217ab30; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_d217ab30 ON shoppingitem USING btree (mediumimageid);


--
-- Name: ix_d27b03e7; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_d27b03e7 ON expandovalue USING btree (tableid, columnid, classpk);


--
-- Name: ix_d2d249e8; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_d2d249e8 ON journalarticle USING btree (groupid, urltitle, status);


--
-- Name: ix_d340db76; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_d340db76 ON portletpreferences USING btree (plid, portletid);


--
-- Name: ix_d3425487; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_d3425487 ON socialrequest USING btree (classnameid, classpk, type_, receiveruserid, status);


--
-- Name: ix_d3d32126; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_d3d32126 ON igimage USING btree (smallimageid);


--
-- Name: ix_d3f5d7ae; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_d3f5d7ae ON expandorow USING btree (tableid);


--
-- Name: ix_d4121315; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_d4121315 ON journalarticleimage USING btree (tempimage);


--
-- Name: ix_d47bb14d; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_d47bb14d ON dlfileversion USING btree (fileentryid, status);


--
-- Name: ix_d49c2e66; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_d49c2e66 ON announcementsentry USING btree (userid);


--
-- Name: ix_d5df7b54; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_d5df7b54 ON pollsvote USING btree (choiceid);


--
-- Name: ix_d61abe08; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_d61abe08 ON assetcategory USING btree (name, vocabularyid);


--
-- Name: ix_d65d3521; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_d65d3521 ON socialequityuser USING btree (groupid, userid);


--
-- Name: ix_d699243f; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_d699243f ON portletitem USING btree (groupid, name, portletid, classnameid);


--
-- Name: ix_d6fd9496; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_d6fd9496 ON calevent USING btree (companyid);


--
-- Name: ix_d76dd2cf; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_d76dd2cf ON pollschoice USING btree (questionid, name);


--
-- Name: ix_d7710a66; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_d7710a66 ON sclicenses_scproductentries USING btree (productentryid);


--
-- Name: ix_d7d6e87a; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_d7d6e87a ON shoppingorder USING btree (number_);


--
-- Name: ix_d9380cb7; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_d9380cb7 ON socialrequest USING btree (receiveruserid, status);


--
-- Name: ix_d9e0a34c; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_d9e0a34c ON igimage USING btree (custom2imageid);


--
-- Name: ix_da04f689; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_da04f689 ON blogsentry USING btree (groupid, userid, displaydate, status);


--
-- Name: ix_da5f4359; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_da5f4359 ON shard USING btree (classnameid, classpk);


--
-- Name: ix_da913a55; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_da913a55 ON scproductscreenshot USING btree (productentryid, priority);


--
-- Name: ix_dae54b49; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_dae54b49 ON socialequitylog USING btree (userid, assetentryid, actionid, active_, extradata);


--
-- Name: ix_db780a20; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_db780a20 ON blogsentry USING btree (groupid, urltitle);


--
-- Name: ix_dbd111aa; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_dbd111aa ON assetcategoryproperty USING btree (categoryid, key_);


--
-- Name: ix_dc2f8927; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_dc2f8927 ON bookmarksfolder USING btree (uuid_, groupid);


--
-- Name: ix_dc60cfae; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_dc60cfae ON shoppingcoupon USING btree (code_);


--
-- Name: ix_dcd1fac1; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_dcd1fac1 ON journalarticleresource USING btree (uuid_);


--
-- Name: ix_dcded558; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_dcded558 ON usergroupgrouprole USING btree (usergroupid);


--
-- Name: ix_dff1f063; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_dff1f063 ON assettagproperty USING btree (companyid);


--
-- Name: ix_dff98523; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_dff98523 ON journalarticle USING btree (companyid);


--
-- Name: ix_e0422bda; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_e0422bda ON user_ USING btree (uuid_);


--
-- Name: ix_e04e486d; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_e04e486d ON roles_permissions USING btree (roleid);


--
-- Name: ix_e119938a; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_e119938a ON assetentries_assetcategories USING btree (entryid);


--
-- Name: ix_e1e7142b; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_e1e7142b ON mbthread USING btree (groupid, status);


--
-- Name: ix_e2815081; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_e2815081 ON dlfileversion USING btree (fileentryid, version);


--
-- Name: ix_e2e9f129; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_e2e9f129 ON bookmarksentry USING btree (groupid, userid);


--
-- Name: ix_e301bdf5; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_e301bdf5 ON organization_ USING btree (companyid, name);


--
-- Name: ix_e3f1286b; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_e3f1286b ON lock_ USING btree (expirationdate);


--
-- Name: ix_e4efba8d; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_e4efba8d ON usertracker USING btree (userid);


--
-- Name: ix_e4f13e6e; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_e4f13e6e ON portletpreferences USING btree (ownerid, ownertype, plid);


--
-- Name: ix_e4f84168; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_e4f84168 ON socialequitygroupsetting USING btree (groupid, classnameid, type_);


--
-- Name: ix_e52ff7ef; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_e52ff7ef ON bookmarksentry USING btree (groupid);


--
-- Name: ix_e597322d; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_e597322d ON igimage USING btree (custom1imageid);


--
-- Name: ix_e60ea987; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_e60ea987 ON useridmapper USING btree (userid);


--
-- Name: ix_e639e2f6; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_e639e2f6 ON assetcategory USING btree (groupid);


--
-- Name: ix_e745ea26; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_e745ea26 ON wikipage USING btree (nodeid, title, head);


--
-- Name: ix_e7b95510; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_e7b95510 ON browsertracker USING btree (userid);


--
-- Name: ix_e7f635ca; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_e7f635ca ON wikipage USING btree (nodeid, head);


--
-- Name: ix_e802aa3c; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_e802aa3c ON journaltemplate USING btree (groupid, templateid);


--
-- Name: ix_e82f322b; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_e82f322b ON journalarticle USING btree (companyid, version, status);


--
-- Name: ix_e858f170; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_e858f170 ON mbmailinglist USING btree (uuid_, groupid);


--
-- Name: ix_e8d019aa; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_e8d019aa ON assetcategory USING btree (uuid_, groupid);


--
-- Name: ix_e8d33ff9; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_e8d33ff9 ON scframeworkversi_scproductvers USING btree (productversionid);


--
-- Name: ix_e8da181d; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_e8da181d ON socialequitylog USING btree (assetentryid, type_, active_);


--
-- Name: ix_e8f34171; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_e8f34171 ON subscription USING btree (userid, classnameid);


--
-- Name: ix_e922d6c0; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_e922d6c0 ON portletitem USING btree (groupid, portletid, classnameid);


--
-- Name: ix_e97342d9; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_e97342d9 ON igimage USING btree (uuid_, groupid);


--
-- Name: ix_e9eb6194; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_e9eb6194 ON mbmessageflag USING btree (userid, messageid, flag);


--
-- Name: ix_ea6fd516; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_ea6fd516 ON shoppingitemprice USING btree (itemid);


--
-- Name: ix_eaa02a91; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_eaa02a91 ON bookmarksentry USING btree (uuid_, groupid);


--
-- Name: ix_eb2dce27; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_eb2dce27 ON blogsentry USING btree (companyid, status);


--
-- Name: ix_ebc931b8; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_ebc931b8 ON role_ USING btree (companyid, name);


--
-- Name: ix_ec00543c; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_ec00543c ON company USING btree (webid);


--
-- Name: ix_ec370f10; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_ec370f10 ON pollschoice USING btree (questionid);


--
-- Name: ix_ec97689d; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_ec97689d ON groups_permissions USING btree (permissionid);


--
-- Name: ix_ecce311d; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_ecce311d ON dlfileshortcut USING btree (groupid, folderid, status);


--
-- Name: ix_ecd8cfea; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_ecd8cfea ON usernotificationevent USING btree (uuid_);


--
-- Name: ix_ed292508; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_ed292508 ON mbcategory USING btree (groupid, parentcategoryid);


--
-- Name: ix_ed39ac98; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_ed39ac98 ON mbmessage USING btree (groupid, status);


--
-- Name: ix_ed5ca615; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_ed5ca615 ON dlfileentry USING btree (groupid, folderid, title);


--
-- Name: ix_ed7cf243; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_ed7cf243 ON passwordpolicyrel USING btree (passwordpolicyid, classnameid, classpk);


--
-- Name: ix_edb9986e; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_edb9986e ON resourceaction USING btree (name, actionid);


--
-- Name: ix_eed06670; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_eed06670 ON dlfilerank USING btree (userid);


--
-- Name: ix_ef9b7028; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_ef9b7028 ON journalarticle USING btree (smallimageid);


--
-- Name: ix_f029602f; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_f029602f ON journalarticle USING btree (uuid_);


--
-- Name: ix_f0566a77; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_f0566a77 ON expandovalue USING btree (tableid);


--
-- Name: ix_f090c113; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_f090c113 ON permission_ USING btree (resourceid);


--
-- Name: ix_f0ca24a5; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_f0ca24a5 ON socialrelation USING btree (uuid_);


--
-- Name: ix_f0e73383; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_f0e73383 ON blogsentry USING btree (groupid, displaydate, status);


--
-- Name: ix_f10b6c6b; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_f10b6c6b ON users_groups USING btree (userid);


--
-- Name: ix_f15c1c4f; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_f15c1c4f ON portletpreferences USING btree (plid);


--
-- Name: ix_f202b9ce; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_f202b9ce ON phone USING btree (userid);


--
-- Name: ix_f2ea1ace; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_f2ea1ace ON dlfolder USING btree (groupid);


--
-- Name: ix_f3aad60d; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_f3aad60d ON socialequitysetting USING btree (groupid, classnameid, actionid);


--
-- Name: ix_f3c9f36; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_f3c9f36 ON pollsquestion USING btree (uuid_, groupid);


--
-- Name: ix_f436ec8e; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_f436ec8e ON role_ USING btree (name);


--
-- Name: ix_f474fd89; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_f474fd89 ON shoppingorder USING btree (pptxnid);


--
-- Name: ix_f4af5636; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_f4af5636 ON dlfileentry USING btree (groupid);


--
-- Name: ix_f6006202; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_f6006202 ON calevent USING btree (remindby);


--
-- Name: ix_f6687633; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_f6687633 ON mbmessage USING btree (classnameid, classpk, status);


--
-- Name: ix_f73c0982; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_f73c0982 ON igfolder USING btree (uuid_);


--
-- Name: ix_f75690bb; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_f75690bb ON website USING btree (userid);


--
-- Name: ix_f7655cc3; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_f7655cc3 ON quartz_triggers USING btree (next_fire_time);


--
-- Name: ix_f7d28c2f; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_f7d28c2f ON mbcategory USING btree (uuid_, groupid);


--
-- Name: ix_f7dd0987; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_f7dd0987 ON expandovalue USING btree (columnid);


--
-- Name: ix_f8433677; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_f8433677 ON journalarticleresource USING btree (groupid);


--
-- Name: ix_f960131c; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_f960131c ON website USING btree (companyid, classnameid, classpk);


--
-- Name: ix_fab5a88b; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_fab5a88b ON mbstatsuser USING btree (groupid, messagecount);


--
-- Name: ix_fad05595; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_fad05595 ON layout USING btree (dlfolderid);


--
-- Name: ix_fb646ca6; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_fb646ca6 ON users_orgs USING btree (userid);


--
-- Name: ix_fbbe7c96; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_fbbe7c96 ON wikipage USING btree (userid, nodeid, status);


--
-- Name: ix_fbde0aa3; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_fbde0aa3 ON blogsentry USING btree (groupid, userid, displaydate);


--
-- Name: ix_fc1f9c7b; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_fc1f9c7b ON assetentry USING btree (classuuid);


--
-- Name: ix_fc46fe16; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_fc46fe16 ON shoppingcart USING btree (groupid, userid);


--
-- Name: ix_fcade8c4; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_fcade8c4 ON resourcecode USING btree (name, scope);


--
-- Name: ix_fcd7c63d; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_fcd7c63d ON calevent USING btree (groupid, type_);


--
-- Name: ix_fdb4a946; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_fdb4a946 ON dlfileshortcut USING btree (uuid_, groupid);


--
-- Name: ix_fefc8da7; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_fefc8da7 ON expandocolumn USING btree (tableid, name);


--
-- Name: ix_fefe7d76; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_fefe7d76 ON shoppingitem USING btree (groupid, categoryid);


--
-- Name: ix_ff203304; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_ff203304 ON shoppingitem USING btree (smallimageid);


--
-- Name: public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

