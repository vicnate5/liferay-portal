-- MySQL dump 10.13  Distrib 5.5.21, for Win64 (x86)
--
-- Host: localhost    Database: lportal
-- ------------------------------------------------------
-- Server version	5.5.21

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `Account_`
--

DROP TABLE IF EXISTS `Account_`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Account_` (
  `accountId` bigint(20) NOT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `userId` bigint(20) DEFAULT NULL,
  `userName` varchar(75) DEFAULT NULL,
  `createDate` datetime DEFAULT NULL,
  `modifiedDate` datetime DEFAULT NULL,
  `parentAccountId` bigint(20) DEFAULT NULL,
  `name` varchar(75) DEFAULT NULL,
  `legalName` varchar(75) DEFAULT NULL,
  `legalId` varchar(75) DEFAULT NULL,
  `legalType` varchar(75) DEFAULT NULL,
  `sicCode` varchar(75) DEFAULT NULL,
  `tickerSymbol` varchar(75) DEFAULT NULL,
  `industry` varchar(75) DEFAULT NULL,
  `type_` varchar(75) DEFAULT NULL,
  `size_` varchar(75) DEFAULT NULL,
  PRIMARY KEY (`accountId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Account_`
--

LOCK TABLES `Account_` WRITE;
/*!40000 ALTER TABLE `Account_` DISABLE KEYS */;
INSERT INTO `Account_` VALUES (10156,10154,0,'','2014-03-18 17:33:36','2014-03-18 17:33:36',0,'liferay.com','','','','','','','','');
/*!40000 ALTER TABLE `Account_` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Address`
--

DROP TABLE IF EXISTS `Address`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Address` (
  `addressId` bigint(20) NOT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `userId` bigint(20) DEFAULT NULL,
  `userName` varchar(75) DEFAULT NULL,
  `createDate` datetime DEFAULT NULL,
  `modifiedDate` datetime DEFAULT NULL,
  `classNameId` bigint(20) DEFAULT NULL,
  `classPK` bigint(20) DEFAULT NULL,
  `street1` varchar(75) DEFAULT NULL,
  `street2` varchar(75) DEFAULT NULL,
  `street3` varchar(75) DEFAULT NULL,
  `city` varchar(75) DEFAULT NULL,
  `zip` varchar(75) DEFAULT NULL,
  `regionId` bigint(20) DEFAULT NULL,
  `countryId` bigint(20) DEFAULT NULL,
  `typeId` int(11) DEFAULT NULL,
  `mailing` tinyint(4) DEFAULT NULL,
  `primary_` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`addressId`),
  KEY `IX_93D5AD4E` (`companyId`),
  KEY `IX_ABD7DAC0` (`companyId`,`classNameId`),
  KEY `IX_71CB1123` (`companyId`,`classNameId`,`classPK`),
  KEY `IX_923BD178` (`companyId`,`classNameId`,`classPK`,`mailing`),
  KEY `IX_9226DBB4` (`companyId`,`classNameId`,`classPK`,`primary_`),
  KEY `IX_5BC8B0D4` (`userId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Address`
--

LOCK TABLES `Address` WRITE;
/*!40000 ALTER TABLE `Address` DISABLE KEYS */;
INSERT INTO `Address` VALUES (10874,10154,10196,'Test Test','2014-03-18 18:02:26','2014-03-18 18:02:47',10022,10197,'1220 Brea Canyon Rd','','','Walnut','91789',19005,19,11000,1,1);
/*!40000 ALTER TABLE `Address` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `AnnouncementsDelivery`
--

DROP TABLE IF EXISTS `AnnouncementsDelivery`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `AnnouncementsDelivery` (
  `deliveryId` bigint(20) NOT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `userId` bigint(20) DEFAULT NULL,
  `type_` varchar(75) DEFAULT NULL,
  `email` tinyint(4) DEFAULT NULL,
  `sms` tinyint(4) DEFAULT NULL,
  `website` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`deliveryId`),
  UNIQUE KEY `IX_BA4413D5` (`userId`,`type_`),
  KEY `IX_6EDB9600` (`userId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `AnnouncementsDelivery`
--

LOCK TABLES `AnnouncementsDelivery` WRITE;
/*!40000 ALTER TABLE `AnnouncementsDelivery` DISABLE KEYS */;
INSERT INTO `AnnouncementsDelivery` VALUES (10464,10154,10458,'general',0,0,0),(10465,10154,10458,'news',0,0,0),(10466,10154,10458,'test',0,0,0),(10607,10154,10601,'general',0,0,0),(10608,10154,10601,'news',0,0,0),(10609,10154,10601,'test',0,0,0),(10656,10154,10650,'general',0,0,0),(10657,10154,10650,'news',0,0,0),(10658,10154,10650,'test',0,0,0),(10842,10154,10196,'general',1,1,1),(10843,10154,10196,'news',0,0,1),(10844,10154,10196,'test',0,0,1),(10854,10154,10848,'general',0,0,0),(10855,10154,10848,'news',0,0,0),(10856,10154,10848,'test',0,0,0);
/*!40000 ALTER TABLE `AnnouncementsDelivery` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `AnnouncementsEntry`
--

DROP TABLE IF EXISTS `AnnouncementsEntry`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `AnnouncementsEntry` (
  `uuid_` varchar(75) DEFAULT NULL,
  `entryId` bigint(20) NOT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `userId` bigint(20) DEFAULT NULL,
  `userName` varchar(75) DEFAULT NULL,
  `createDate` datetime DEFAULT NULL,
  `modifiedDate` datetime DEFAULT NULL,
  `classNameId` bigint(20) DEFAULT NULL,
  `classPK` bigint(20) DEFAULT NULL,
  `title` varchar(75) DEFAULT NULL,
  `content` longtext,
  `url` longtext,
  `type_` varchar(75) DEFAULT NULL,
  `displayDate` datetime DEFAULT NULL,
  `expirationDate` datetime DEFAULT NULL,
  `priority` int(11) DEFAULT NULL,
  `alert` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`entryId`),
  KEY `IX_A6EF0B81` (`classNameId`,`classPK`),
  KEY `IX_14F06A6B` (`classNameId`,`classPK`,`alert`),
  KEY `IX_D49C2E66` (`userId`),
  KEY `IX_1AFBDE08` (`uuid_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `AnnouncementsEntry`
--

LOCK TABLES `AnnouncementsEntry` WRITE;
/*!40000 ALTER TABLE `AnnouncementsEntry` DISABLE KEYS */;
/*!40000 ALTER TABLE `AnnouncementsEntry` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `AnnouncementsFlag`
--

DROP TABLE IF EXISTS `AnnouncementsFlag`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `AnnouncementsFlag` (
  `flagId` bigint(20) NOT NULL,
  `userId` bigint(20) DEFAULT NULL,
  `createDate` datetime DEFAULT NULL,
  `entryId` bigint(20) DEFAULT NULL,
  `value` int(11) DEFAULT NULL,
  PRIMARY KEY (`flagId`),
  UNIQUE KEY `IX_4539A99C` (`userId`,`entryId`,`value`),
  KEY `IX_9C7EB9F` (`entryId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `AnnouncementsFlag`
--

LOCK TABLES `AnnouncementsFlag` WRITE;
/*!40000 ALTER TABLE `AnnouncementsFlag` DISABLE KEYS */;
/*!40000 ALTER TABLE `AnnouncementsFlag` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `AssetCategory`
--

DROP TABLE IF EXISTS `AssetCategory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `AssetCategory` (
  `uuid_` varchar(75) DEFAULT NULL,
  `categoryId` bigint(20) NOT NULL,
  `groupId` bigint(20) DEFAULT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `userId` bigint(20) DEFAULT NULL,
  `userName` varchar(75) DEFAULT NULL,
  `createDate` datetime DEFAULT NULL,
  `modifiedDate` datetime DEFAULT NULL,
  `parentCategoryId` bigint(20) DEFAULT NULL,
  `leftCategoryId` bigint(20) DEFAULT NULL,
  `rightCategoryId` bigint(20) DEFAULT NULL,
  `name` varchar(75) DEFAULT NULL,
  `title` longtext,
  `description` longtext,
  `vocabularyId` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`categoryId`),
  UNIQUE KEY `IX_BE4DF2BF` (`parentCategoryId`,`name`,`vocabularyId`),
  UNIQUE KEY `IX_E8D019AA` (`uuid_`,`groupId`),
  KEY `IX_E639E2F6` (`groupId`),
  KEY `IX_2008FACB` (`groupId`,`vocabularyId`),
  KEY `IX_D61ABE08` (`name`,`vocabularyId`),
  KEY `IX_7BB1826B` (`parentCategoryId`),
  KEY `IX_9DDD15EA` (`parentCategoryId`,`name`),
  KEY `IX_B185E980` (`parentCategoryId`,`vocabularyId`),
  KEY `IX_4D37BB00` (`uuid_`),
  KEY `IX_287B1F89` (`vocabularyId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `AssetCategory`
--

LOCK TABLES `AssetCategory` WRITE;
/*!40000 ALTER TABLE `AssetCategory` DISABLE KEYS */;
/*!40000 ALTER TABLE `AssetCategory` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `AssetCategoryProperty`
--

DROP TABLE IF EXISTS `AssetCategoryProperty`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `AssetCategoryProperty` (
  `categoryPropertyId` bigint(20) NOT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `userId` bigint(20) DEFAULT NULL,
  `userName` varchar(75) DEFAULT NULL,
  `createDate` datetime DEFAULT NULL,
  `modifiedDate` datetime DEFAULT NULL,
  `categoryId` bigint(20) DEFAULT NULL,
  `key_` varchar(75) DEFAULT NULL,
  `value` varchar(75) DEFAULT NULL,
  PRIMARY KEY (`categoryPropertyId`),
  UNIQUE KEY `IX_DBD111AA` (`categoryId`,`key_`),
  KEY `IX_99DA856` (`categoryId`),
  KEY `IX_8654719F` (`companyId`),
  KEY `IX_52340033` (`companyId`,`key_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `AssetCategoryProperty`
--

LOCK TABLES `AssetCategoryProperty` WRITE;
/*!40000 ALTER TABLE `AssetCategoryProperty` DISABLE KEYS */;
/*!40000 ALTER TABLE `AssetCategoryProperty` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `AssetEntries_AssetCategories`
--

DROP TABLE IF EXISTS `AssetEntries_AssetCategories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `AssetEntries_AssetCategories` (
  `entryId` bigint(20) NOT NULL,
  `categoryId` bigint(20) NOT NULL,
  PRIMARY KEY (`entryId`,`categoryId`),
  KEY `IX_A188F560` (`categoryId`),
  KEY `IX_E119938A` (`entryId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `AssetEntries_AssetCategories`
--

LOCK TABLES `AssetEntries_AssetCategories` WRITE;
/*!40000 ALTER TABLE `AssetEntries_AssetCategories` DISABLE KEYS */;
/*!40000 ALTER TABLE `AssetEntries_AssetCategories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `AssetEntries_AssetTags`
--

DROP TABLE IF EXISTS `AssetEntries_AssetTags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `AssetEntries_AssetTags` (
  `entryId` bigint(20) NOT NULL,
  `tagId` bigint(20) NOT NULL,
  PRIMARY KEY (`entryId`,`tagId`),
  KEY `IX_2ED82CAD` (`entryId`),
  KEY `IX_B2A61B55` (`tagId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `AssetEntries_AssetTags`
--

LOCK TABLES `AssetEntries_AssetTags` WRITE;
/*!40000 ALTER TABLE `AssetEntries_AssetTags` DISABLE KEYS */;
/*!40000 ALTER TABLE `AssetEntries_AssetTags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `AssetEntry`
--

DROP TABLE IF EXISTS `AssetEntry`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `AssetEntry` (
  `entryId` bigint(20) NOT NULL,
  `groupId` bigint(20) DEFAULT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `userId` bigint(20) DEFAULT NULL,
  `userName` varchar(75) DEFAULT NULL,
  `createDate` datetime DEFAULT NULL,
  `modifiedDate` datetime DEFAULT NULL,
  `classNameId` bigint(20) DEFAULT NULL,
  `classPK` bigint(20) DEFAULT NULL,
  `classUuid` varchar(75) DEFAULT NULL,
  `classTypeId` bigint(20) DEFAULT NULL,
  `visible` tinyint(4) DEFAULT NULL,
  `startDate` datetime DEFAULT NULL,
  `endDate` datetime DEFAULT NULL,
  `publishDate` datetime DEFAULT NULL,
  `expirationDate` datetime DEFAULT NULL,
  `mimeType` varchar(75) DEFAULT NULL,
  `title` longtext,
  `description` longtext,
  `summary` longtext,
  `url` longtext,
  `layoutUuid` varchar(75) DEFAULT NULL,
  `height` int(11) DEFAULT NULL,
  `width` int(11) DEFAULT NULL,
  `priority` double DEFAULT NULL,
  `viewCount` int(11) DEFAULT NULL,
  PRIMARY KEY (`entryId`),
  UNIQUE KEY `IX_1E9D371D` (`classNameId`,`classPK`),
  KEY `IX_FC1F9C7B` (`classUuid`),
  KEY `IX_7306C60` (`companyId`),
  KEY `IX_75D42FF9` (`expirationDate`),
  KEY `IX_1EBA6821` (`groupId`,`classUuid`),
  KEY `IX_2E4E3885` (`publishDate`),
  KEY `IX_9029E15A` (`visible`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `AssetEntry`
--

LOCK TABLES `AssetEntry` WRITE;
/*!40000 ALTER TABLE `AssetEntry` DISABLE KEYS */;
INSERT INTO `AssetEntry` VALUES (10178,10172,10154,10158,'','2014-03-18 17:33:37','2014-03-18 17:33:37',10117,10176,'e46c2d1d-3090-4cc7-ac28-bdbbc6027935',0,0,NULL,NULL,NULL,NULL,'text/html','10175','','','','',0,0,0,0),(10186,10180,10154,10158,'','2014-03-18 17:33:37','2014-03-18 17:33:37',10117,10184,'b6298931-eaf0-4fc4-8d42-d07d9fd835f9',0,0,NULL,NULL,NULL,NULL,'text/html','10183','','','','',0,0,0,0),(10201,10192,10154,10196,'Test Test','2014-03-18 17:33:37','2014-03-18 18:02:47',10005,10196,'ff49757e-f39c-4371-b396-19017d5b0289',0,0,NULL,NULL,NULL,NULL,'','Test Test','','','','',0,0,0,0),(10317,10310,10154,10158,'','2014-03-18 17:33:39','2014-03-18 17:33:39',10117,10314,'bb2314d6-1d96-4501-8e21-4843dd569fec',0,0,NULL,NULL,NULL,NULL,'text/html','10313','','','','',0,0,0,0),(10326,10320,10154,10158,'','2014-03-18 17:33:39','2014-03-18 17:33:39',10117,10324,'f863ef6d-96a5-4e97-829a-b4fe8c512e44',0,0,NULL,NULL,NULL,NULL,'text/html','10323','','','','',0,0,0,0),(10335,10329,10154,10158,'','2014-03-18 17:33:39','2014-03-18 17:33:39',10117,10333,'4218d01f-d180-4648-a299-3afb3da0b521',0,0,NULL,NULL,NULL,NULL,'text/html','10332','','','','',0,0,0,0),(10344,10338,10154,10158,'','2014-03-18 17:33:39','2014-03-18 17:33:39',10117,10342,'2c0d9b01-7adb-4447-bab6-0d8416c9a3d9',0,0,NULL,NULL,NULL,NULL,'text/html','10341','','','','',0,0,0,0),(10349,10338,10154,10158,'','2014-03-18 17:33:40','2014-03-18 17:33:40',10117,10347,'57bb9ac3-ceb4-4b12-9cc1-d1f4dbfa8bec',0,0,NULL,NULL,NULL,NULL,'text/html','10346','','','','',0,0,0,0),(10355,10338,10154,10158,'','2014-03-18 17:33:40','2014-03-18 17:33:40',10117,10353,'30531bfa-404d-499c-a795-a70fbb3125df',0,0,NULL,NULL,NULL,NULL,'text/html','10352','','','','',0,0,0,0),(10361,10338,10154,10158,'','2014-03-18 17:33:40','2014-03-18 17:33:40',10117,10359,'f26790f6-baa1-4063-9ce1-0ba0e34d72d3',0,0,NULL,NULL,NULL,NULL,'text/html','10358','','','','',0,0,0,0),(10370,10364,10154,10158,'','2014-03-18 17:33:40','2014-03-18 17:33:40',10117,10368,'5d08f6a3-7cba-4ed3-9372-a7777b05b83b',0,0,NULL,NULL,NULL,NULL,'text/html','10367','','','','',0,0,0,0),(10375,10364,10154,10158,'','2014-03-18 17:33:40','2014-03-18 17:33:40',10117,10373,'6d7e5dab-a32c-446c-80bb-5997ce53c1db',0,0,NULL,NULL,NULL,NULL,'text/html','10372','','','','',0,0,0,0),(10383,10364,10154,10158,'','2014-03-18 17:33:40','2014-03-18 17:33:40',10117,10381,'6e5d1e57-9c2d-4985-a6dd-6177cca9e552',0,0,NULL,NULL,NULL,NULL,'text/html','10380','','','','',0,0,0,0),(10389,10364,10154,10158,'','2014-03-18 17:33:40','2014-03-18 17:33:40',10117,10387,'d8bed651-7fca-477e-be43-52822e5fbf36',0,0,NULL,NULL,NULL,NULL,'text/html','10386','','','','',0,0,0,0),(10395,10364,10154,10158,'','2014-03-18 17:33:40','2014-03-18 17:33:40',10117,10393,'331edc1e-5015-4f12-823f-d6e4b5b62ca0',0,0,NULL,NULL,NULL,NULL,'text/html','10392','','','','',0,0,0,0),(10412,10198,10154,10196,'Test Test','2014-03-18 17:34:21','2014-03-18 17:34:21',10117,10410,'155b37ca-c514-42a0-a1a9-7962f3c50995',0,0,NULL,NULL,NULL,NULL,'text/html','10409','','','','',0,0,0,0),(10417,10198,10154,10196,'Test Test','2014-03-18 17:34:21','2014-03-18 17:34:21',10117,10415,'981a5003-102d-468c-8157-d9615971870b',0,0,NULL,NULL,NULL,NULL,'text/html','10414','','','','',0,0,0,0),(10427,10180,10154,10196,'Test Test','2014-03-18 17:34:33','2014-03-18 17:34:33',10117,10425,'f52ecc7d-4c70-4b49-995d-e38ad91fabaf',0,0,NULL,NULL,NULL,NULL,'text/html','10424','','','','',0,0,0,0),(10443,10180,10154,10196,'Test Test','2014-03-18 17:35:03','2014-03-18 17:35:03',10117,10441,'f5101096-864b-421e-958c-4e143669e4fd',0,0,NULL,NULL,NULL,NULL,'text/html','10435','','','','',0,0,0,0),(10453,10192,10154,10196,'Test Test','2014-03-18 17:35:41','2014-03-18 17:35:41',10001,10450,'',0,0,NULL,NULL,NULL,NULL,'','Member Site','','','','',0,0,0,0),(10463,10192,10154,10196,'Test Test','2014-03-18 17:36:49','2014-03-18 17:36:49',10005,10458,'ec952fc4-62dc-4851-8a4f-c13ddb755aea',0,0,NULL,NULL,NULL,NULL,'','userfn userln','','','','',0,0,0,0),(10470,10192,10154,10196,'Test Test','2014-03-18 17:37:26','2014-03-18 17:37:26',10001,10467,'',0,0,NULL,NULL,NULL,NULL,'','Wiki Site','','','','',0,0,0,0),(10475,10467,10154,10196,'Test Test','2014-03-18 17:37:44','2014-03-18 17:37:44',10117,10473,'381f0d58-f788-4274-b67b-05a00f68afda',0,0,NULL,NULL,NULL,NULL,'text/html','10472','','','','',0,0,0,0),(10484,10467,10154,10196,'Test Test','2014-03-18 17:37:54','2014-03-18 17:37:54',10013,10483,'91081b0b-53ae-411b-8958-4fe6102540cb',0,1,NULL,NULL,NULL,NULL,'text/html','FrontPage','','','','',0,0,0,3),(10487,10467,10154,10196,'Test Test','2014-03-18 17:37:54','2014-03-18 17:37:54',10117,10485,'6b291213-4a32-4a04-a0df-9ce0b1435fe3',0,0,NULL,NULL,NULL,NULL,'text/html','10483','','','','',0,0,0,0),(10501,10180,10154,10196,'Test Test','2014-03-18 17:38:43','2014-03-18 17:38:43',10117,10499,'b7cd8b1d-3e55-436e-b678-d0c23daf5812',0,0,NULL,NULL,NULL,NULL,'text/html','10498','','','','',0,0,0,0),(10512,10192,10154,10196,'Test Test','2014-03-18 17:39:28','2014-03-18 17:39:28',10001,10509,'',0,0,NULL,NULL,NULL,NULL,'','WebContent Site','','','','',0,0,0,0),(10516,10509,10154,10196,'Test Test','2014-03-18 17:39:42','2014-03-18 17:39:42',10117,10514,'2e3cc653-40e4-417a-ae78-07802b82b1ab',0,0,NULL,NULL,NULL,NULL,'text/html','10513','','','','',0,0,0,0),(10525,10192,10154,10196,'Test Test','2014-03-18 17:41:21','2014-03-18 17:41:21',10001,10522,'',0,0,NULL,NULL,NULL,NULL,'','Social Activity Site','','','','',0,0,0,0),(10529,10522,10154,10196,'Test Test','2014-03-18 17:41:35','2014-03-18 17:41:35',10117,10527,'7beacb85-d3ba-46cb-90fc-f12ee454f115',0,0,NULL,NULL,NULL,NULL,'text/html','10526','','','','',0,0,0,0),(10553,10547,10154,10196,'Test Test','2014-03-18 17:42:28','2014-03-18 17:42:28',10117,10551,'ddee02bb-92ec-4fb4-854f-4a5ef92f9448',0,0,NULL,NULL,NULL,NULL,'text/html','10550','','','','',0,0,0,0),(10560,10192,10154,10196,'Test Test','2014-03-18 17:42:56','2014-03-18 17:42:56',10001,10557,'',0,0,NULL,NULL,NULL,NULL,'','Dynamic Data List Display Site','','','','',0,0,0,0),(10564,10557,10154,10196,'Test Test','2014-03-18 17:43:11','2014-03-18 17:43:11',10117,10562,'51879ae9-4a4f-4058-ab57-af15ff1ad1d1',0,0,NULL,NULL,NULL,NULL,'text/html','10561','','','','',0,0,0,0),(10585,10557,10154,10196,'Test Test','2014-03-18 17:44:03','2014-03-18 17:44:03',10096,10581,'0453ebb0-57b5-403f-ba3d-1e6b30060196',0,0,NULL,NULL,NULL,NULL,'text/html','New Record for List: List Name','','','','',0,0,0,0),(10597,10591,10154,10196,'Test Test','2014-03-18 17:45:09','2014-03-18 17:45:09',10117,10595,'60b917bb-0a2b-4194-9daf-53929e590c9e',0,0,NULL,NULL,NULL,NULL,'text/html','10594','','','','',0,0,0,0),(10606,10192,10154,10196,'Test Test','2014-03-18 17:45:50','2014-03-18 17:47:03',10005,10601,'8ae5f590-b4df-44c0-b2ad-351328b5bdb9',0,0,NULL,NULL,NULL,NULL,'','userPPfn userPPln','','','','',0,0,0,0),(10613,10603,10154,10601,'userPPfn userPPln','2014-03-18 17:46:17','2014-03-18 17:46:17',10117,10611,'9ac1918d-f73f-4a05-bd47-81ec59f457a0',0,0,NULL,NULL,NULL,NULL,'text/html','10610','','','','',0,0,0,0),(10618,10603,10154,10601,'userPPfn userPPln','2014-03-18 17:46:17','2014-03-18 17:46:17',10117,10616,'4b8bc74e-3084-4dcf-b800-dd1d7ef61d4d',0,0,NULL,NULL,NULL,NULL,'text/html','10615','','','','',0,0,0,0),(10625,10192,10154,10158,'','2014-03-18 17:47:44','2014-03-18 17:47:52',10001,10180,'',0,0,NULL,NULL,NULL,NULL,'','liferay.com','','','','',0,0,0,0),(10630,10180,10154,10196,'Test Test','2014-03-18 17:48:15','2014-03-18 17:48:15',10117,10628,'15c8194a-e203-44e6-bd16-55975923a635',0,0,NULL,NULL,NULL,NULL,'text/html','10627','','','','',0,0,0,0),(10649,10192,10154,10196,'Test Test','2014-03-18 17:49:28','2014-03-18 17:49:28',10001,10646,'',0,0,NULL,NULL,NULL,NULL,'','Site Name','','','','',0,0,0,0),(10655,10192,10154,10196,'Test Test','2014-03-18 17:49:40','2014-03-18 17:49:57',10005,10650,'5373112c-bc4a-48f6-9283-96169924aeaf',0,0,NULL,NULL,NULL,NULL,'','userSMfn userSMln','','','','',0,0,0,0),(10662,10652,10154,10650,'userSMfn userSMln','2014-03-18 17:50:07','2014-03-18 17:50:07',10117,10660,'61dbbcb8-8710-4687-9c3c-32367e4a0631',0,0,NULL,NULL,NULL,NULL,'text/html','10659','','','','',0,0,0,0),(10667,10652,10154,10650,'userSMfn userSMln','2014-03-18 17:50:07','2014-03-18 17:50:07',10117,10665,'517f7fbc-dd62-4ade-8c28-6e0a857d0db9',0,0,NULL,NULL,NULL,NULL,'text/html','10664','','','','',0,0,0,0),(10682,10192,10154,10196,'Test Test','2014-03-18 17:51:07','2014-03-18 17:51:43',10001,10679,'',0,0,NULL,NULL,NULL,NULL,'','Staging Site','','','','',0,0,0,0),(10686,10679,10154,10196,'Test Test','2014-03-18 17:51:23','2014-03-18 17:51:23',10117,10684,'97d6d8c4-2738-4a0e-b6bc-b12debf5acc9',0,0,NULL,NULL,NULL,NULL,'text/html','10683','','','','',0,0,0,0),(10691,10192,10154,10196,'Test Test','2014-03-18 17:51:43','2014-03-18 17:51:43',10001,10688,'',0,0,NULL,NULL,NULL,NULL,'','Staging Site (Staging)','','','','',0,0,0,0),(10740,10180,10154,10196,'Test Test','2014-03-18 17:52:33','2014-03-18 17:52:33',10117,10738,'618f8f7e-22a8-4b17-a392-2429aae5f537',0,0,NULL,NULL,NULL,NULL,'text/html','10737','','','','',0,0,0,0),(10753,10180,10154,10196,'Test Test','2014-03-18 17:52:50','2014-03-18 17:52:50',10008,10746,'62e10b51-f76e-4a7b-af24-b42a4e5b9fd1',0,1,NULL,NULL,NULL,NULL,'text/plain','Test Bookmark Name','Test Bookmark Description','','http://www.liferay.com','',0,0,0,0),(10764,10192,10154,10196,'Test Test','2014-03-18 17:53:27','2014-03-18 17:53:27',10001,10761,'',0,0,NULL,NULL,NULL,NULL,'','AP Site','','','','',0,0,0,0),(10768,10761,10154,10196,'Test Test','2014-03-18 17:53:44','2014-03-18 17:53:44',10117,10766,'0c4cf9b3-69a8-4234-a42c-02f5cec1718f',0,0,NULL,NULL,NULL,NULL,'text/html','10765','','','','',0,0,0,0),(10781,10192,10154,10196,'Test Test','2014-03-18 17:54:37','2014-03-18 17:54:37',10001,10778,'',0,0,NULL,NULL,NULL,NULL,'','Documents and Media Site','','','','',0,0,0,0),(10785,10778,10154,10196,'Test Test','2014-03-18 17:54:53','2014-03-18 17:54:53',10117,10783,'58ccfe7c-6690-4948-9659-623af0c3006b',0,0,NULL,NULL,NULL,NULL,'text/html','10782','','','','',0,0,0,0),(10795,10778,10154,10196,'Test Test','2014-03-18 17:55:13','2014-03-18 17:55:13',10010,10792,'6cb91ae9-12bb-4442-b7dd-1b6df193154e',0,1,NULL,NULL,NULL,NULL,'text/plain','DM Document Title','DM Document Description','','','',0,0,0,0),(10798,10778,10154,10196,'Test Test','2014-03-18 17:55:13','2014-03-18 17:55:13',10117,10796,'c732763a-ab1c-4346-81d7-8fe1be895fca',0,0,NULL,NULL,NULL,NULL,'text/html','10792','','','','',0,0,0,0),(10810,10192,10154,10196,'Test Test','2014-03-18 17:57:27','2014-03-18 17:57:27',10001,10807,'',0,0,NULL,NULL,NULL,NULL,'','MDR Site','','','','',0,0,0,0),(10814,10807,10154,10196,'Test Test','2014-03-18 17:57:43','2014-03-18 17:57:43',10117,10812,'a5bce8e8-d779-490d-a724-6c932d8444e9',0,0,NULL,NULL,NULL,NULL,'text/html','10811','','','','',0,0,0,0),(10824,10180,10154,10196,'Test Test','2014-03-18 17:58:52','2014-03-18 17:58:52',10117,10822,'123d1319-4195-49c4-9c4c-4aa2825863a9',0,0,NULL,NULL,NULL,NULL,'text/html','10821','','','','',0,0,0,0),(10835,10180,10154,10196,'Test Test','2014-03-18 17:59:30','2014-03-18 17:59:30',10117,10833,'4babf646-7de3-4b5d-8f50-66374f9d8efb',0,0,NULL,NULL,NULL,NULL,'text/html','10832','','','','',0,0,0,0),(10853,10192,10154,10196,'Test Test','2014-03-18 18:00:30','2014-03-18 18:00:30',10005,10848,'673c1241-2cc0-4b83-946c-caf94cc3d36b',0,0,NULL,NULL,NULL,NULL,'','userCFfn userCFln','','','','',0,0,0,0),(10860,10192,10154,10196,'Test Test','2014-03-18 18:01:16','2014-03-18 18:01:16',10001,10857,'',0,0,NULL,NULL,NULL,NULL,'','Blogs Site','','','','',0,0,0,0),(10864,10857,10154,10196,'Test Test','2014-03-18 18:01:31','2014-03-18 18:01:31',10117,10862,'9855e2e9-9762-4102-90ce-85c6e23df491',0,0,NULL,NULL,NULL,NULL,'text/html','10861','','','','',0,0,0,0),(10909,10903,10154,10196,'Test Test','2014-07-08 22:42:33','2014-07-08 22:42:33',10117,10907,'df30eaa1-9eab-4810-92d2-6e1e7fea3e83',0,0,NULL,NULL,NULL,NULL,'text/html','10906','','','','',0,0,0,0),(10917,10903,10154,10196,'Test Test','2014-07-08 22:43:02','2014-07-08 22:43:02',10117,10915,'9bec5b45-20ce-4a2a-b492-b3140d44b980',0,0,NULL,NULL,NULL,NULL,'text/html','10914','','','','',0,0,0,0),(10925,10192,10154,10196,'Test Test','2014-07-08 22:45:00','2014-07-08 22:45:00',10001,10922,'',0,0,NULL,NULL,NULL,NULL,'','AP Export Site A','','','','',0,0,0,0),(10949,10192,10154,10196,'Test Test','2014-07-08 22:46:27','2014-07-08 22:46:27',10001,10946,'',0,0,NULL,NULL,NULL,NULL,'','AP Import Site B','','','','',0,0,0,0),(10965,10946,10154,10196,'Test Test','2014-07-08 22:49:19','2014-07-08 23:04:16',10108,10963,'739823fb-a21f-4b58-a0f5-977a5315e3f1',0,1,NULL,NULL,'2014-07-08 22:48:00',NULL,'text/html','<?xml version=\'1.0\' encoding=\'UTF-8\'?><root available-locales=\"en_US\" default-locale=\"en_US\"><Title language-id=\"en_US\">WC Webcontent Title</Title></root>','','','','44c6d238-b819-4053-a4c0-7894532f1d12',0,0,0,0),(10968,10946,10154,10196,'Test Test','2014-07-08 22:49:19','2014-07-08 22:49:19',10117,10966,'7b4fb5d0-84f6-4b91-a957-03146374df0c',0,0,NULL,NULL,NULL,NULL,'text/html','10963','','','','',0,0,0,0);
/*!40000 ALTER TABLE `AssetEntry` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `AssetLink`
--

DROP TABLE IF EXISTS `AssetLink`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `AssetLink` (
  `linkId` bigint(20) NOT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `userId` bigint(20) DEFAULT NULL,
  `userName` varchar(75) DEFAULT NULL,
  `createDate` datetime DEFAULT NULL,
  `entryId1` bigint(20) DEFAULT NULL,
  `entryId2` bigint(20) DEFAULT NULL,
  `type_` int(11) DEFAULT NULL,
  `weight` int(11) DEFAULT NULL,
  PRIMARY KEY (`linkId`),
  UNIQUE KEY `IX_8F542794` (`entryId1`,`entryId2`,`type_`),
  KEY `IX_128516C8` (`entryId1`),
  KEY `IX_56E0AB21` (`entryId1`,`entryId2`),
  KEY `IX_14D5A20D` (`entryId1`,`type_`),
  KEY `IX_12851A89` (`entryId2`),
  KEY `IX_91F132C` (`entryId2`,`type_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `AssetLink`
--

LOCK TABLES `AssetLink` WRITE;
/*!40000 ALTER TABLE `AssetLink` DISABLE KEYS */;
/*!40000 ALTER TABLE `AssetLink` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `AssetTag`
--

DROP TABLE IF EXISTS `AssetTag`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `AssetTag` (
  `tagId` bigint(20) NOT NULL,
  `groupId` bigint(20) DEFAULT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `userId` bigint(20) DEFAULT NULL,
  `userName` varchar(75) DEFAULT NULL,
  `createDate` datetime DEFAULT NULL,
  `modifiedDate` datetime DEFAULT NULL,
  `name` varchar(75) DEFAULT NULL,
  `assetCount` int(11) DEFAULT NULL,
  PRIMARY KEY (`tagId`),
  KEY `IX_7C9E46BA` (`groupId`),
  KEY `IX_D63322F9` (`groupId`,`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `AssetTag`
--

LOCK TABLES `AssetTag` WRITE;
/*!40000 ALTER TABLE `AssetTag` DISABLE KEYS */;
INSERT INTO `AssetTag` VALUES (10867,10857,10154,10196,'Test Test','2014-03-18 18:01:46','2014-03-18 18:01:46','blue',0);
/*!40000 ALTER TABLE `AssetTag` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `AssetTagProperty`
--

DROP TABLE IF EXISTS `AssetTagProperty`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `AssetTagProperty` (
  `tagPropertyId` bigint(20) NOT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `userId` bigint(20) DEFAULT NULL,
  `userName` varchar(75) DEFAULT NULL,
  `createDate` datetime DEFAULT NULL,
  `modifiedDate` datetime DEFAULT NULL,
  `tagId` bigint(20) DEFAULT NULL,
  `key_` varchar(75) DEFAULT NULL,
  `value` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`tagPropertyId`),
  UNIQUE KEY `IX_2C944354` (`tagId`,`key_`),
  KEY `IX_DFF1F063` (`companyId`),
  KEY `IX_13805BF7` (`companyId`,`key_`),
  KEY `IX_3269E180` (`tagId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `AssetTagProperty`
--

LOCK TABLES `AssetTagProperty` WRITE;
/*!40000 ALTER TABLE `AssetTagProperty` DISABLE KEYS */;
INSERT INTO `AssetTagProperty` VALUES (10868,10154,10196,'Test Test','2014-03-18 18:01:46','2014-03-18 18:01:46',10867,'Tag Property Key','Tag Property Value');
/*!40000 ALTER TABLE `AssetTagProperty` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `AssetTagStats`
--

DROP TABLE IF EXISTS `AssetTagStats`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `AssetTagStats` (
  `tagStatsId` bigint(20) NOT NULL,
  `tagId` bigint(20) DEFAULT NULL,
  `classNameId` bigint(20) DEFAULT NULL,
  `assetCount` int(11) DEFAULT NULL,
  PRIMARY KEY (`tagStatsId`),
  UNIQUE KEY `IX_56682CC4` (`tagId`,`classNameId`),
  KEY `IX_50702693` (`classNameId`),
  KEY `IX_9464CA` (`tagId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `AssetTagStats`
--

LOCK TABLES `AssetTagStats` WRITE;
/*!40000 ALTER TABLE `AssetTagStats` DISABLE KEYS */;
/*!40000 ALTER TABLE `AssetTagStats` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `AssetVocabulary`
--

DROP TABLE IF EXISTS `AssetVocabulary`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `AssetVocabulary` (
  `uuid_` varchar(75) DEFAULT NULL,
  `vocabularyId` bigint(20) NOT NULL,
  `groupId` bigint(20) DEFAULT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `userId` bigint(20) DEFAULT NULL,
  `userName` varchar(75) DEFAULT NULL,
  `createDate` datetime DEFAULT NULL,
  `modifiedDate` datetime DEFAULT NULL,
  `name` varchar(75) DEFAULT NULL,
  `title` longtext,
  `description` longtext,
  `settings_` longtext,
  PRIMARY KEY (`vocabularyId`),
  UNIQUE KEY `IX_C0AAD74D` (`groupId`,`name`),
  UNIQUE KEY `IX_1B2B8792` (`uuid_`,`groupId`),
  KEY `IX_B22D908C` (`companyId`),
  KEY `IX_B6B8CA0E` (`groupId`),
  KEY `IX_55F58818` (`uuid_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `AssetVocabulary`
--

LOCK TABLES `AssetVocabulary` WRITE;
/*!40000 ALTER TABLE `AssetVocabulary` DISABLE KEYS */;
INSERT INTO `AssetVocabulary` VALUES ('345d8f9c-a5b6-48fd-ac5a-9328cd918f04',10316,10192,10154,10158,'','2014-03-18 17:33:39','2014-03-18 17:33:39','Topic','<?xml version=\'1.0\' encoding=\'UTF-8\'?><root available-locales=\"en_US\" default-locale=\"en_US\"><Title language-id=\"en_US\">Topic</Title></root>','',''),('5e4fa961-a0cd-4938-9763-a013de7e3ab8',10489,10467,10154,10158,'','2014-03-18 17:37:56','2014-03-18 17:37:56','Topic','<?xml version=\'1.0\' encoding=\'UTF-8\'?><root available-locales=\"en_US\" default-locale=\"en_US\"><Title language-id=\"en_US\">Topic</Title></root>','',''),('ca1f421b-33e0-4803-a020-6ffa41a3ae6d',10703,10679,10154,10158,'','2014-03-18 17:51:44','2014-03-18 17:51:44','Topic','<?xml version=\'1.0\' encoding=\'UTF-8\'?><root available-locales=\"en_US\" default-locale=\"en_US\"><Title language-id=\"en_US\">Topic</Title></root>','',''),('ca1f421b-33e0-4803-a020-6ffa41a3ae6d',10704,10688,10154,10158,'','2014-03-18 17:51:44','2014-03-18 17:51:44','Topic','<?xml version=\'1.0\' encoding=\'UTF-8\'?><root available-locales=\"en_US\" default-locale=\"en_US\"><Title language-id=\"en_US\">Topic</Title></root>','',''),('4f8ad237-b72c-45f7-b9e1-afd84711dc9c',10938,10903,10154,10158,'','2014-07-08 22:45:00','2014-07-08 22:45:00','Topic','<?xml version=\'1.0\' encoding=\'UTF-8\'?><root available-locales=\"en_US\" default-locale=\"en_US\"><Title language-id=\"en_US\">Topic</Title></root>','',''),('4f8ad237-b72c-45f7-b9e1-afd84711dc9c',10939,10922,10154,10158,'','2014-07-08 22:45:01','2014-07-08 22:45:01','Topic','<?xml version=\'1.0\' encoding=\'UTF-8\'?><root available-locales=\"en_US\" default-locale=\"en_US\"><Title language-id=\"en_US\">Topic</Title></root>','','');
/*!40000 ALTER TABLE `AssetVocabulary` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `BlogsEntry`
--

DROP TABLE IF EXISTS `BlogsEntry`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `BlogsEntry` (
  `uuid_` varchar(75) DEFAULT NULL,
  `entryId` bigint(20) NOT NULL,
  `groupId` bigint(20) DEFAULT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `userId` bigint(20) DEFAULT NULL,
  `userName` varchar(75) DEFAULT NULL,
  `createDate` datetime DEFAULT NULL,
  `modifiedDate` datetime DEFAULT NULL,
  `title` varchar(150) DEFAULT NULL,
  `urlTitle` varchar(150) DEFAULT NULL,
  `description` varchar(75) DEFAULT NULL,
  `content` longtext,
  `displayDate` datetime DEFAULT NULL,
  `allowPingbacks` tinyint(4) DEFAULT NULL,
  `allowTrackbacks` tinyint(4) DEFAULT NULL,
  `trackbacks` longtext,
  `smallImage` tinyint(4) DEFAULT NULL,
  `smallImageId` bigint(20) DEFAULT NULL,
  `smallImageURL` longtext,
  `status` int(11) DEFAULT NULL,
  `statusByUserId` bigint(20) DEFAULT NULL,
  `statusByUserName` varchar(75) DEFAULT NULL,
  `statusDate` datetime DEFAULT NULL,
  PRIMARY KEY (`entryId`),
  UNIQUE KEY `IX_DB780A20` (`groupId`,`urlTitle`),
  UNIQUE KEY `IX_1B1040FD` (`uuid_`,`groupId`),
  KEY `IX_72EF6041` (`companyId`),
  KEY `IX_430D791F` (`companyId`,`displayDate`),
  KEY `IX_BB0C2905` (`companyId`,`displayDate`,`status`),
  KEY `IX_EB2DCE27` (`companyId`,`status`),
  KEY `IX_8CACE77B` (`companyId`,`userId`),
  KEY `IX_A5F57B61` (`companyId`,`userId`,`status`),
  KEY `IX_81A50303` (`groupId`),
  KEY `IX_621E19D` (`groupId`,`displayDate`),
  KEY `IX_F0E73383` (`groupId`,`displayDate`,`status`),
  KEY `IX_1EFD8EE9` (`groupId`,`status`),
  KEY `IX_FBDE0AA3` (`groupId`,`userId`,`displayDate`),
  KEY `IX_DA04F689` (`groupId`,`userId`,`displayDate`,`status`),
  KEY `IX_49E15A23` (`groupId`,`userId`,`status`),
  KEY `IX_69157A4D` (`uuid_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `BlogsEntry`
--

LOCK TABLES `BlogsEntry` WRITE;
/*!40000 ALTER TABLE `BlogsEntry` DISABLE KEYS */;
/*!40000 ALTER TABLE `BlogsEntry` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `BlogsStatsUser`
--

DROP TABLE IF EXISTS `BlogsStatsUser`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `BlogsStatsUser` (
  `statsUserId` bigint(20) NOT NULL,
  `groupId` bigint(20) DEFAULT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `userId` bigint(20) DEFAULT NULL,
  `entryCount` int(11) DEFAULT NULL,
  `lastPostDate` datetime DEFAULT NULL,
  `ratingsTotalEntries` int(11) DEFAULT NULL,
  `ratingsTotalScore` double DEFAULT NULL,
  `ratingsAverageScore` double DEFAULT NULL,
  PRIMARY KEY (`statsUserId`),
  UNIQUE KEY `IX_82254C25` (`groupId`,`userId`),
  KEY `IX_90CDA39A` (`companyId`,`entryCount`),
  KEY `IX_43840EEB` (`groupId`),
  KEY `IX_28C78D5C` (`groupId`,`entryCount`),
  KEY `IX_BB51F1D9` (`userId`),
  KEY `IX_507BA031` (`userId`,`lastPostDate`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `BlogsStatsUser`
--

LOCK TABLES `BlogsStatsUser` WRITE;
/*!40000 ALTER TABLE `BlogsStatsUser` DISABLE KEYS */;
/*!40000 ALTER TABLE `BlogsStatsUser` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `BookmarksEntry`
--

DROP TABLE IF EXISTS `BookmarksEntry`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `BookmarksEntry` (
  `uuid_` varchar(75) DEFAULT NULL,
  `entryId` bigint(20) NOT NULL,
  `groupId` bigint(20) DEFAULT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `userId` bigint(20) DEFAULT NULL,
  `userName` varchar(75) DEFAULT NULL,
  `createDate` datetime DEFAULT NULL,
  `modifiedDate` datetime DEFAULT NULL,
  `resourceBlockId` bigint(20) DEFAULT NULL,
  `folderId` bigint(20) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `url` longtext,
  `description` longtext,
  `visits` int(11) DEFAULT NULL,
  `priority` int(11) DEFAULT NULL,
  PRIMARY KEY (`entryId`),
  UNIQUE KEY `IX_EAA02A91` (`uuid_`,`groupId`),
  KEY `IX_E52FF7EF` (`groupId`),
  KEY `IX_5200100C` (`groupId`,`folderId`),
  KEY `IX_E2E9F129` (`groupId`,`userId`),
  KEY `IX_E848278F` (`resourceBlockId`),
  KEY `IX_B670BA39` (`uuid_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `BookmarksEntry`
--

LOCK TABLES `BookmarksEntry` WRITE;
/*!40000 ALTER TABLE `BookmarksEntry` DISABLE KEYS */;
INSERT INTO `BookmarksEntry` VALUES ('62e10b51-f76e-4a7b-af24-b42a4e5b9fd1',10746,10180,10154,10196,'Test Test','2014-03-18 17:52:50','2014-03-18 17:52:50',3,0,'Test Bookmark Name','http://www.liferay.com','Test Bookmark Description',0,0);
/*!40000 ALTER TABLE `BookmarksEntry` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `BookmarksFolder`
--

DROP TABLE IF EXISTS `BookmarksFolder`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `BookmarksFolder` (
  `uuid_` varchar(75) DEFAULT NULL,
  `folderId` bigint(20) NOT NULL,
  `groupId` bigint(20) DEFAULT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `userId` bigint(20) DEFAULT NULL,
  `userName` varchar(75) DEFAULT NULL,
  `createDate` datetime DEFAULT NULL,
  `modifiedDate` datetime DEFAULT NULL,
  `resourceBlockId` bigint(20) DEFAULT NULL,
  `parentFolderId` bigint(20) DEFAULT NULL,
  `name` varchar(75) DEFAULT NULL,
  `description` longtext,
  PRIMARY KEY (`folderId`),
  UNIQUE KEY `IX_DC2F8927` (`uuid_`,`groupId`),
  KEY `IX_2ABA25D7` (`companyId`),
  KEY `IX_7F703619` (`groupId`),
  KEY `IX_967799C0` (`groupId`,`parentFolderId`),
  KEY `IX_28A49BB9` (`resourceBlockId`),
  KEY `IX_451E7AE3` (`uuid_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `BookmarksFolder`
--

LOCK TABLES `BookmarksFolder` WRITE;
/*!40000 ALTER TABLE `BookmarksFolder` DISABLE KEYS */;
INSERT INTO `BookmarksFolder` VALUES ('e0357e69-9147-4def-845a-8e0af22dd918',10754,10180,10154,10196,'Test Test','2014-03-18 17:52:58','2014-03-18 17:52:58',6,0,'Test Folder Name','Test Folder Description');
/*!40000 ALTER TABLE `BookmarksFolder` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `BrowserTracker`
--

DROP TABLE IF EXISTS `BrowserTracker`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `BrowserTracker` (
  `browserTrackerId` bigint(20) NOT NULL,
  `userId` bigint(20) DEFAULT NULL,
  `browserKey` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`browserTrackerId`),
  UNIQUE KEY `IX_E7B95510` (`userId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `BrowserTracker`
--

LOCK TABLES `BrowserTracker` WRITE;
/*!40000 ALTER TABLE `BrowserTracker` DISABLE KEYS */;
/*!40000 ALTER TABLE `BrowserTracker` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CalEvent`
--

DROP TABLE IF EXISTS `CalEvent`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `CalEvent` (
  `uuid_` varchar(75) DEFAULT NULL,
  `eventId` bigint(20) NOT NULL,
  `groupId` bigint(20) DEFAULT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `userId` bigint(20) DEFAULT NULL,
  `userName` varchar(75) DEFAULT NULL,
  `createDate` datetime DEFAULT NULL,
  `modifiedDate` datetime DEFAULT NULL,
  `title` varchar(75) DEFAULT NULL,
  `description` longtext,
  `location` longtext,
  `startDate` datetime DEFAULT NULL,
  `endDate` datetime DEFAULT NULL,
  `durationHour` int(11) DEFAULT NULL,
  `durationMinute` int(11) DEFAULT NULL,
  `allDay` tinyint(4) DEFAULT NULL,
  `timeZoneSensitive` tinyint(4) DEFAULT NULL,
  `type_` varchar(75) DEFAULT NULL,
  `repeating` tinyint(4) DEFAULT NULL,
  `recurrence` longtext,
  `remindBy` int(11) DEFAULT NULL,
  `firstReminder` int(11) DEFAULT NULL,
  `secondReminder` int(11) DEFAULT NULL,
  PRIMARY KEY (`eventId`),
  UNIQUE KEY `IX_5CCE79C8` (`uuid_`,`groupId`),
  KEY `IX_D6FD9496` (`companyId`),
  KEY `IX_12EE4898` (`groupId`),
  KEY `IX_4FDDD2BF` (`groupId`,`repeating`),
  KEY `IX_FCD7C63D` (`groupId`,`type_`),
  KEY `IX_FD93CBFA` (`groupId`,`type_`,`repeating`),
  KEY `IX_F6006202` (`remindBy`),
  KEY `IX_C1AD2122` (`uuid_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CalEvent`
--

LOCK TABLES `CalEvent` WRITE;
/*!40000 ALTER TABLE `CalEvent` DISABLE KEYS */;
/*!40000 ALTER TABLE `CalEvent` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ClassName_`
--

DROP TABLE IF EXISTS `ClassName_`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ClassName_` (
  `classNameId` bigint(20) NOT NULL,
  `value` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`classNameId`),
  UNIQUE KEY `IX_B27A301F` (`value`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ClassName_`
--

LOCK TABLES `ClassName_` WRITE;
/*!40000 ALTER TABLE `ClassName_` DISABLE KEYS */;
INSERT INTO `ClassName_` VALUES (10014,'com.liferay.counter.model.Counter'),(10015,'com.liferay.portal.kernel.workflow.WorkflowTask'),(10016,'com.liferay.portal.model.Account'),(10017,'com.liferay.portal.model.Address'),(10018,'com.liferay.portal.model.BrowserTracker'),(10019,'com.liferay.portal.model.ClassName'),(10020,'com.liferay.portal.model.ClusterGroup'),(10021,'com.liferay.portal.model.Company'),(10022,'com.liferay.portal.model.Contact'),(10023,'com.liferay.portal.model.Country'),(10024,'com.liferay.portal.model.EmailAddress'),(10001,'com.liferay.portal.model.Group'),(10025,'com.liferay.portal.model.Image'),(10002,'com.liferay.portal.model.Layout'),(10026,'com.liferay.portal.model.LayoutBranch'),(10027,'com.liferay.portal.model.LayoutPrototype'),(10028,'com.liferay.portal.model.LayoutRevision'),(10029,'com.liferay.portal.model.LayoutSet'),(10030,'com.liferay.portal.model.LayoutSetBranch'),(10031,'com.liferay.portal.model.LayoutSetPrototype'),(10032,'com.liferay.portal.model.ListType'),(10033,'com.liferay.portal.model.Lock'),(10034,'com.liferay.portal.model.MembershipRequest'),(10003,'com.liferay.portal.model.Organization'),(10035,'com.liferay.portal.model.OrgGroupPermission'),(10036,'com.liferay.portal.model.OrgGroupRole'),(10037,'com.liferay.portal.model.OrgLabor'),(10038,'com.liferay.portal.model.PasswordPolicy'),(10039,'com.liferay.portal.model.PasswordPolicyRel'),(10040,'com.liferay.portal.model.PasswordTracker'),(10041,'com.liferay.portal.model.Permission'),(10042,'com.liferay.portal.model.Phone'),(10043,'com.liferay.portal.model.PluginSetting'),(10044,'com.liferay.portal.model.PortalPreferences'),(10045,'com.liferay.portal.model.Portlet'),(10046,'com.liferay.portal.model.PortletItem'),(10047,'com.liferay.portal.model.PortletPreferences'),(10048,'com.liferay.portal.model.Region'),(10049,'com.liferay.portal.model.Release'),(10050,'com.liferay.portal.model.Repository'),(10051,'com.liferay.portal.model.RepositoryEntry'),(10052,'com.liferay.portal.model.Resource'),(10053,'com.liferay.portal.model.ResourceAction'),(10054,'com.liferay.portal.model.ResourceBlock'),(10055,'com.liferay.portal.model.ResourceBlockPermission'),(10056,'com.liferay.portal.model.ResourceCode'),(10057,'com.liferay.portal.model.ResourcePermission'),(10058,'com.liferay.portal.model.ResourceTypePermission'),(10004,'com.liferay.portal.model.Role'),(10059,'com.liferay.portal.model.ServiceComponent'),(10060,'com.liferay.portal.model.Shard'),(10061,'com.liferay.portal.model.Subscription'),(10062,'com.liferay.portal.model.Team'),(10063,'com.liferay.portal.model.Ticket'),(10005,'com.liferay.portal.model.User'),(10006,'com.liferay.portal.model.UserGroup'),(10064,'com.liferay.portal.model.UserGroupGroupRole'),(10065,'com.liferay.portal.model.UserGroupRole'),(10066,'com.liferay.portal.model.UserIdMapper'),(10067,'com.liferay.portal.model.UserNotificationEvent'),(10188,'com.liferay.portal.model.UserPersonalSite'),(10068,'com.liferay.portal.model.UserTracker'),(10069,'com.liferay.portal.model.UserTrackerPath'),(10070,'com.liferay.portal.model.VirtualHost'),(10071,'com.liferay.portal.model.WebDAVProps'),(10072,'com.liferay.portal.model.Website'),(10073,'com.liferay.portal.model.WorkflowDefinitionLink'),(10074,'com.liferay.portal.model.WorkflowInstanceLink'),(10791,'com.liferay.portal.repository.liferayrepository.LiferayRepository'),(10075,'com.liferay.portlet.announcements.model.AnnouncementsDelivery'),(10076,'com.liferay.portlet.announcements.model.AnnouncementsEntry'),(10077,'com.liferay.portlet.announcements.model.AnnouncementsFlag'),(10078,'com.liferay.portlet.asset.model.AssetCategory'),(10079,'com.liferay.portlet.asset.model.AssetCategoryProperty'),(10080,'com.liferay.portlet.asset.model.AssetEntry'),(10081,'com.liferay.portlet.asset.model.AssetLink'),(10082,'com.liferay.portlet.asset.model.AssetTag'),(10083,'com.liferay.portlet.asset.model.AssetTagProperty'),(10084,'com.liferay.portlet.asset.model.AssetTagStats'),(10085,'com.liferay.portlet.asset.model.AssetVocabulary'),(10007,'com.liferay.portlet.blogs.model.BlogsEntry'),(10086,'com.liferay.portlet.blogs.model.BlogsStatsUser'),(10008,'com.liferay.portlet.bookmarks.model.BookmarksEntry'),(10087,'com.liferay.portlet.bookmarks.model.BookmarksFolder'),(10009,'com.liferay.portlet.calendar.model.CalEvent'),(10088,'com.liferay.portlet.documentlibrary.model.DLContent'),(10010,'com.liferay.portlet.documentlibrary.model.DLFileEntry'),(10089,'com.liferay.portlet.documentlibrary.model.DLFileEntryMetadata'),(10090,'com.liferay.portlet.documentlibrary.model.DLFileEntryType'),(10091,'com.liferay.portlet.documentlibrary.model.DLFileRank'),(10092,'com.liferay.portlet.documentlibrary.model.DLFileShortcut'),(10093,'com.liferay.portlet.documentlibrary.model.DLFileVersion'),(10094,'com.liferay.portlet.documentlibrary.model.DLFolder'),(10095,'com.liferay.portlet.documentlibrary.model.DLSync'),(10096,'com.liferay.portlet.dynamicdatalists.model.DDLRecord'),(10097,'com.liferay.portlet.dynamicdatalists.model.DDLRecordSet'),(10098,'com.liferay.portlet.dynamicdatalists.model.DDLRecordVersion'),(10099,'com.liferay.portlet.dynamicdatamapping.model.DDMContent'),(10100,'com.liferay.portlet.dynamicdatamapping.model.DDMStorageLink'),(10101,'com.liferay.portlet.dynamicdatamapping.model.DDMStructure'),(10102,'com.liferay.portlet.dynamicdatamapping.model.DDMStructureLink'),(10103,'com.liferay.portlet.dynamicdatamapping.model.DDMTemplate'),(10104,'com.liferay.portlet.expando.model.ExpandoColumn'),(10105,'com.liferay.portlet.expando.model.ExpandoRow'),(10106,'com.liferay.portlet.expando.model.ExpandoTable'),(10107,'com.liferay.portlet.expando.model.ExpandoValue'),(10108,'com.liferay.portlet.journal.model.JournalArticle'),(10109,'com.liferay.portlet.journal.model.JournalArticleImage'),(10110,'com.liferay.portlet.journal.model.JournalArticleResource'),(10111,'com.liferay.portlet.journal.model.JournalContentSearch'),(10112,'com.liferay.portlet.journal.model.JournalFeed'),(10113,'com.liferay.portlet.journal.model.JournalStructure'),(10114,'com.liferay.portlet.journal.model.JournalTemplate'),(10115,'com.liferay.portlet.messageboards.model.MBBan'),(10116,'com.liferay.portlet.messageboards.model.MBCategory'),(10117,'com.liferay.portlet.messageboards.model.MBDiscussion'),(10118,'com.liferay.portlet.messageboards.model.MBMailingList'),(10011,'com.liferay.portlet.messageboards.model.MBMessage'),(10119,'com.liferay.portlet.messageboards.model.MBStatsUser'),(10012,'com.liferay.portlet.messageboards.model.MBThread'),(10120,'com.liferay.portlet.messageboards.model.MBThreadFlag'),(10121,'com.liferay.portlet.mobiledevicerules.model.MDRAction'),(10122,'com.liferay.portlet.mobiledevicerules.model.MDRRule'),(10123,'com.liferay.portlet.mobiledevicerules.model.MDRRuleGroup'),(10124,'com.liferay.portlet.mobiledevicerules.model.MDRRuleGroupInstance'),(10125,'com.liferay.portlet.polls.model.PollsChoice'),(10126,'com.liferay.portlet.polls.model.PollsQuestion'),(10127,'com.liferay.portlet.polls.model.PollsVote'),(10128,'com.liferay.portlet.ratings.model.RatingsEntry'),(10129,'com.liferay.portlet.ratings.model.RatingsStats'),(10130,'com.liferay.portlet.shopping.model.ShoppingCart'),(10131,'com.liferay.portlet.shopping.model.ShoppingCategory'),(10132,'com.liferay.portlet.shopping.model.ShoppingCoupon'),(10133,'com.liferay.portlet.shopping.model.ShoppingItem'),(10134,'com.liferay.portlet.shopping.model.ShoppingItemField'),(10135,'com.liferay.portlet.shopping.model.ShoppingItemPrice'),(10136,'com.liferay.portlet.shopping.model.ShoppingOrder'),(10137,'com.liferay.portlet.shopping.model.ShoppingOrderItem'),(10138,'com.liferay.portlet.social.model.SocialActivity'),(10139,'com.liferay.portlet.social.model.SocialActivityAchievement'),(10140,'com.liferay.portlet.social.model.SocialActivityCounter'),(10141,'com.liferay.portlet.social.model.SocialActivityLimit'),(10142,'com.liferay.portlet.social.model.SocialActivitySetting'),(10143,'com.liferay.portlet.social.model.SocialRelation'),(10144,'com.liferay.portlet.social.model.SocialRequest'),(10145,'com.liferay.portlet.softwarecatalog.model.SCFrameworkVersion'),(10146,'com.liferay.portlet.softwarecatalog.model.SCLicense'),(10147,'com.liferay.portlet.softwarecatalog.model.SCProductEntry'),(10148,'com.liferay.portlet.softwarecatalog.model.SCProductScreenshot'),(10149,'com.liferay.portlet.softwarecatalog.model.SCProductVersion'),(10150,'com.liferay.portlet.usernotifications.model.UserNotificationEvent'),(10151,'com.liferay.portlet.wiki.model.WikiNode'),(10013,'com.liferay.portlet.wiki.model.WikiPage'),(10152,'com.liferay.portlet.wiki.model.WikiPageResource');
/*!40000 ALTER TABLE `ClassName_` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ClusterGroup`
--

DROP TABLE IF EXISTS `ClusterGroup`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ClusterGroup` (
  `clusterGroupId` bigint(20) NOT NULL,
  `name` varchar(75) DEFAULT NULL,
  `clusterNodeIds` varchar(75) DEFAULT NULL,
  `wholeCluster` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`clusterGroupId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ClusterGroup`
--

LOCK TABLES `ClusterGroup` WRITE;
/*!40000 ALTER TABLE `ClusterGroup` DISABLE KEYS */;
/*!40000 ALTER TABLE `ClusterGroup` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Company`
--

DROP TABLE IF EXISTS `Company`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Company` (
  `companyId` bigint(20) NOT NULL,
  `accountId` bigint(20) DEFAULT NULL,
  `webId` varchar(75) DEFAULT NULL,
  `key_` longtext,
  `mx` varchar(75) DEFAULT NULL,
  `homeURL` longtext,
  `logoId` bigint(20) DEFAULT NULL,
  `system` tinyint(4) DEFAULT NULL,
  `maxUsers` int(11) DEFAULT NULL,
  `active_` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`companyId`),
  UNIQUE KEY `IX_EC00543C` (`webId`),
  KEY `IX_38EFE3FD` (`logoId`),
  KEY `IX_12566EC2` (`mx`),
  KEY `IX_35E3E7C6` (`system`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Company`
--

LOCK TABLES `Company` WRITE;
/*!40000 ALTER TABLE `Company` DISABLE KEYS */;
INSERT INTO `Company` VALUES (10154,10156,'liferay.com','rO0ABXNyABRqYXZhLnNlY3VyaXR5LktleVJlcL35T7OImqVDAgAETAAJYWxnb3JpdGhtdAASTGphdmEvbGFuZy9TdHJpbmc7WwAHZW5jb2RlZHQAAltCTAAGZm9ybWF0cQB+AAFMAAR0eXBldAAbTGphdmEvc2VjdXJpdHkvS2V5UmVwJFR5cGU7eHB0AANERVN1cgACW0Ks8xf4BghU4AIAAHhwAAAACHkvAUWDzj12dAADUkFXfnIAGWphdmEuc2VjdXJpdHkuS2V5UmVwJFR5cGUAAAAAAAAAABIAAHhyAA5qYXZhLmxhbmcuRW51bQAAAAAAAAAAEgAAeHB0AAZTRUNSRVQ=','liferay.com','',0,0,0,1);
/*!40000 ALTER TABLE `Company` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Contact_`
--

DROP TABLE IF EXISTS `Contact_`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Contact_` (
  `contactId` bigint(20) NOT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `userId` bigint(20) DEFAULT NULL,
  `userName` varchar(75) DEFAULT NULL,
  `createDate` datetime DEFAULT NULL,
  `modifiedDate` datetime DEFAULT NULL,
  `accountId` bigint(20) DEFAULT NULL,
  `parentContactId` bigint(20) DEFAULT NULL,
  `firstName` varchar(75) DEFAULT NULL,
  `middleName` varchar(75) DEFAULT NULL,
  `lastName` varchar(75) DEFAULT NULL,
  `prefixId` int(11) DEFAULT NULL,
  `suffixId` int(11) DEFAULT NULL,
  `male` tinyint(4) DEFAULT NULL,
  `birthday` datetime DEFAULT NULL,
  `smsSn` varchar(75) DEFAULT NULL,
  `aimSn` varchar(75) DEFAULT NULL,
  `facebookSn` varchar(75) DEFAULT NULL,
  `icqSn` varchar(75) DEFAULT NULL,
  `jabberSn` varchar(75) DEFAULT NULL,
  `msnSn` varchar(75) DEFAULT NULL,
  `mySpaceSn` varchar(75) DEFAULT NULL,
  `skypeSn` varchar(75) DEFAULT NULL,
  `twitterSn` varchar(75) DEFAULT NULL,
  `ymSn` varchar(75) DEFAULT NULL,
  `employeeStatusId` varchar(75) DEFAULT NULL,
  `employeeNumber` varchar(75) DEFAULT NULL,
  `jobTitle` varchar(100) DEFAULT NULL,
  `jobClass` varchar(75) DEFAULT NULL,
  `hoursOfOperation` varchar(75) DEFAULT NULL,
  PRIMARY KEY (`contactId`),
  KEY `IX_66D496A3` (`companyId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Contact_`
--

LOCK TABLES `Contact_` WRITE;
/*!40000 ALTER TABLE `Contact_` DISABLE KEYS */;
INSERT INTO `Contact_` VALUES (10159,10154,10158,'','2014-03-18 17:33:36','2014-03-18 17:33:36',10156,0,'','','',0,0,1,'2014-03-18 17:33:36','','','','','','','','','','','','','','',''),(10197,10154,10196,'','2014-03-18 17:33:37','2014-03-18 18:02:47',10156,0,'Test','','Test',0,0,1,'1970-01-01 00:00:00','','','','','','','','','','','','','','',''),(10459,10154,10196,'Test Test','2014-03-18 17:36:49','2014-03-18 17:36:49',10156,0,'userfn','','userln',0,0,1,'1970-01-01 00:00:00','','','','','','','','','','','','','','',''),(10602,10154,10196,'Test Test','2014-03-18 17:45:50','2014-03-18 17:47:03',10156,0,'userPPfn','','userPPln',0,0,1,'1970-01-01 00:00:00','','','','','','','','','','','','','','',''),(10651,10154,10196,'Test Test','2014-03-18 17:49:40','2014-03-18 17:49:57',10156,0,'userSMfn','','userSMln',0,0,1,'1970-01-01 00:00:00','','','','','','','','','','','','','','',''),(10849,10154,10196,'Test Test','2014-03-18 18:00:30','2014-03-18 18:00:30',10156,0,'userCFfn','','userCFln',0,0,1,'1970-01-01 00:00:00','','','','','','','','','','','','','','','');
/*!40000 ALTER TABLE `Contact_` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Counter`
--

DROP TABLE IF EXISTS `Counter`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Counter` (
  `name` varchar(75) NOT NULL,
  `currentId` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Counter`
--

LOCK TABLES `Counter` WRITE;
/*!40000 ALTER TABLE `Counter` DISABLE KEYS */;
INSERT INTO `Counter` VALUES ('com.liferay.counter.model.Counter',11100),('com.liferay.portal.model.Layout#10172#true',1),('com.liferay.portal.model.Layout#10180#false',7),('com.liferay.portal.model.Layout#10198#false',1),('com.liferay.portal.model.Layout#10198#true',1),('com.liferay.portal.model.Layout#10310#true',1),('com.liferay.portal.model.Layout#10320#true',1),('com.liferay.portal.model.Layout#10329#true',1),('com.liferay.portal.model.Layout#10338#true',3),('com.liferay.portal.model.Layout#10364#true',4),('com.liferay.portal.model.Layout#10467#false',1),('com.liferay.portal.model.Layout#10509#false',1),('com.liferay.portal.model.Layout#10522#false',1),('com.liferay.portal.model.Layout#10547#true',1),('com.liferay.portal.model.Layout#10557#false',1),('com.liferay.portal.model.Layout#10591#true',1),('com.liferay.portal.model.Layout#10603#false',1),('com.liferay.portal.model.Layout#10603#true',1),('com.liferay.portal.model.Layout#10652#false',1),('com.liferay.portal.model.Layout#10652#true',1),('com.liferay.portal.model.Layout#10679#false',1),('com.liferay.portal.model.Layout#10688#false',1),('com.liferay.portal.model.Layout#10761#false',1),('com.liferay.portal.model.Layout#10778#false',1),('com.liferay.portal.model.Layout#10807#false',1),('com.liferay.portal.model.Layout#10857#false',1),('com.liferay.portal.model.Layout#10903#true',2),('com.liferay.portal.model.Layout#10922#false',2),('com.liferay.portal.model.Layout#10946#false',2),('com.liferay.portal.model.Permission',100),('com.liferay.portal.model.Resource',100),('com.liferay.portal.model.ResourceAction',1000),('com.liferay.portal.model.ResourceBlock',100),('com.liferay.portal.model.ResourcePermission',1100),('com.liferay.portal.model.UserTracker',100),('com.liferay.portal.model.UserTrackerPath',800),('com.liferay.portlet.documentlibrary.model.DLFileEntry',100),('com.liferay.portlet.social.model.SocialActivity',100);
/*!40000 ALTER TABLE `Counter` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Country`
--

DROP TABLE IF EXISTS `Country`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Country` (
  `countryId` bigint(20) NOT NULL,
  `name` varchar(75) DEFAULT NULL,
  `a2` varchar(75) DEFAULT NULL,
  `a3` varchar(75) DEFAULT NULL,
  `number_` varchar(75) DEFAULT NULL,
  `idd_` varchar(75) DEFAULT NULL,
  `zipRequired` tinyint(4) DEFAULT NULL,
  `active_` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`countryId`),
  UNIQUE KEY `IX_717B97E1` (`a2`),
  UNIQUE KEY `IX_717B9BA2` (`a3`),
  UNIQUE KEY `IX_19DA007B` (`name`),
  KEY `IX_25D734CD` (`active_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Country`
--

LOCK TABLES `Country` WRITE;
/*!40000 ALTER TABLE `Country` DISABLE KEYS */;
INSERT INTO `Country` VALUES (1,'Canada','CA','CAN','124','001',1,1),(2,'China','CN','CHN','156','086',1,1),(3,'France','FR','FRA','250','033',1,1),(4,'Germany','DE','DEU','276','049',1,1),(5,'Hong Kong','HK','HKG','344','852',1,1),(6,'Hungary','HU','HUN','348','036',1,1),(7,'Israel','IL','ISR','376','972',1,1),(8,'Italy','IT','ITA','380','039',1,1),(9,'Japan','JP','JPN','392','081',1,1),(10,'South Korea','KR','KOR','410','082',1,1),(11,'Netherlands','NL','NLD','528','031',1,1),(12,'Portugal','PT','PRT','620','351',1,1),(13,'Russia','RU','RUS','643','007',1,1),(14,'Singapore','SG','SGP','702','065',1,1),(15,'Spain','ES','ESP','724','034',1,1),(16,'Turkey','TR','TUR','792','090',1,1),(17,'Vietnam','VN','VNM','704','084',1,1),(18,'United Kingdom','GB','GBR','826','044',1,1),(19,'United States','US','USA','840','001',1,1),(20,'Afghanistan','AF','AFG','4','093',1,1),(21,'Albania','AL','ALB','8','355',1,1),(22,'Algeria','DZ','DZA','12','213',1,1),(23,'American Samoa','AS','ASM','16','684',1,1),(24,'Andorra','AD','AND','20','376',1,1),(25,'Angola','AO','AGO','24','244',0,1),(26,'Anguilla','AI','AIA','660','264',1,1),(27,'Antarctica','AQ','ATA','10','672',1,1),(28,'Antigua','AG','ATG','28','268',0,1),(29,'Argentina','AR','ARG','32','054',1,1),(30,'Armenia','AM','ARM','51','374',1,1),(31,'Aruba','AW','ABW','533','297',0,1),(32,'Australia','AU','AUS','36','061',1,1),(33,'Austria','AT','AUT','40','043',1,1),(34,'Azerbaijan','AZ','AZE','31','994',1,1),(35,'Bahamas','BS','BHS','44','242',0,1),(36,'Bahrain','BH','BHR','48','973',1,1),(37,'Bangladesh','BD','BGD','50','880',1,1),(38,'Barbados','BB','BRB','52','246',1,1),(39,'Belarus','BY','BLR','112','375',1,1),(40,'Belgium','BE','BEL','56','032',1,1),(41,'Belize','BZ','BLZ','84','501',0,1),(42,'Benin','BJ','BEN','204','229',0,1),(43,'Bermuda','BM','BMU','60','441',1,1),(44,'Bhutan','BT','BTN','64','975',1,1),(45,'Bolivia','BO','BOL','68','591',1,1),(46,'Bosnia-Herzegovina','BA','BIH','70','387',1,1),(47,'Botswana','BW','BWA','72','267',0,1),(48,'Brazil','BR','BRA','76','055',1,1),(49,'British Virgin Islands','VG','VGB','92','284',1,1),(50,'Brunei','BN','BRN','96','673',1,1),(51,'Bulgaria','BG','BGR','100','359',1,1),(52,'Burkina Faso','BF','BFA','854','226',0,1),(53,'Burma (Myanmar)','MM','MMR','104','095',1,1),(54,'Burundi','BI','BDI','108','257',0,1),(55,'Cambodia','KH','KHM','116','855',1,1),(56,'Cameroon','CM','CMR','120','237',1,1),(57,'Cape Verde Island','CV','CPV','132','238',1,1),(58,'Cayman Islands','KY','CYM','136','345',1,1),(59,'Central African Republic','CF','CAF','140','236',0,1),(60,'Chad','TD','TCD','148','235',1,1),(61,'Chile','CL','CHL','152','056',1,1),(62,'Christmas Island','CX','CXR','162','061',1,1),(63,'Cocos Islands','CC','CCK','166','061',1,1),(64,'Colombia','CO','COL','170','057',1,1),(65,'Comoros','KM','COM','174','269',0,1),(66,'Republic of Congo','CD','COD','180','242',0,1),(67,'Democratic Republic of Congo','CG','COG','178','243',0,1),(68,'Cook Islands','CK','COK','184','682',0,1),(69,'Costa Rica','CR','CRI','188','506',1,1),(70,'Croatia','HR','HRV','191','385',1,1),(71,'Cuba','CU','CUB','192','053',1,1),(72,'Cyprus','CY','CYP','196','357',1,1),(73,'Czech Republic','CZ','CZE','203','420',1,1),(74,'Denmark','DK','DNK','208','045',1,1),(75,'Djibouti','DJ','DJI','262','253',0,1),(76,'Dominica','DM','DMA','212','767',0,1),(77,'Dominican Republic','DO','DOM','214','809',1,1),(78,'Ecuador','EC','ECU','218','593',1,1),(79,'Egypt','EG','EGY','818','020',1,1),(80,'El Salvador','SV','SLV','222','503',1,1),(81,'Equatorial Guinea','GQ','GNQ','226','240',0,1),(82,'Eritrea','ER','ERI','232','291',0,1),(83,'Estonia','EE','EST','233','372',1,1),(84,'Ethiopia','ET','ETH','231','251',1,1),(85,'Faeroe Islands','FO','FRO','234','298',1,1),(86,'Falkland Islands','FK','FLK','238','500',1,1),(87,'Fiji Islands','FJ','FJI','242','679',0,1),(88,'Finland','FI','FIN','246','358',1,1),(89,'French Guiana','GF','GUF','254','594',1,1),(90,'French Polynesia','PF','PYF','258','689',1,1),(91,'Gabon','GA','GAB','266','241',1,1),(92,'Gambia','GM','GMB','270','220',0,1),(93,'Georgia','GE','GEO','268','995',1,1),(94,'Ghana','GH','GHA','288','233',0,1),(95,'Gibraltar','GI','GIB','292','350',1,1),(96,'Greece','GR','GRC','300','030',1,1),(97,'Greenland','GL','GRL','304','299',1,1),(98,'Grenada','GD','GRD','308','473',0,1),(99,'Guadeloupe','GP','GLP','312','590',1,1),(100,'Guam','GU','GUM','316','671',1,1),(101,'Guatemala','GT','GTM','320','502',1,1),(102,'Guinea','GN','GIN','324','224',0,1),(103,'Guinea-Bissau','GW','GNB','624','245',1,1),(104,'Guyana','GY','GUY','328','592',0,1),(105,'Haiti','HT','HTI','332','509',1,1),(106,'Honduras','HN','HND','340','504',1,1),(107,'Iceland','IS','ISL','352','354',1,1),(108,'India','IN','IND','356','091',1,1),(109,'Indonesia','ID','IDN','360','062',1,1),(110,'Iran','IR','IRN','364','098',1,1),(111,'Iraq','IQ','IRQ','368','964',1,1),(112,'Ireland','IE','IRL','372','353',0,1),(113,'Ivory Coast','CI','CIV','384','225',1,1),(114,'Jamaica','JM','JAM','388','876',1,1),(115,'Jordan','JO','JOR','400','962',1,1),(116,'Kazakhstan','KZ','KAZ','398','007',1,1),(117,'Kenya','KE','KEN','404','254',1,1),(118,'Kiribati','KI','KIR','408','686',0,1),(119,'Kuwait','KW','KWT','414','965',1,1),(120,'North Korea','KP','PRK','408','850',0,1),(121,'Kyrgyzstan','KG','KGZ','471','996',1,1),(122,'Laos','LA','LAO','418','856',1,1),(123,'Latvia','LV','LVA','428','371',1,1),(124,'Lebanon','LB','LBN','422','961',1,1),(125,'Lesotho','LS','LSO','426','266',1,1),(126,'Liberia','LR','LBR','430','231',1,1),(127,'Libya','LY','LBY','434','218',1,1),(128,'Liechtenstein','LI','LIE','438','423',1,1),(129,'Lithuania','LT','LTU','440','370',1,1),(130,'Luxembourg','LU','LUX','442','352',1,1),(131,'Macau','MO','MAC','446','853',0,1),(132,'Macedonia','MK','MKD','807','389',1,1),(133,'Madagascar','MG','MDG','450','261',1,1),(134,'Malawi','MW','MWI','454','265',0,1),(135,'Malaysia','MY','MYS','458','060',1,1),(136,'Maldives','MV','MDV','462','960',1,1),(137,'Mali','ML','MLI','466','223',0,1),(138,'Malta','MT','MLT','470','356',1,1),(139,'Marshall Islands','MH','MHL','584','692',1,1),(140,'Martinique','MQ','MTQ','474','596',1,1),(141,'Mauritania','MR','MRT','478','222',0,1),(142,'Mauritius','MU','MUS','480','230',0,1),(143,'Mayotte Island','YT','MYT','175','269',1,1),(144,'Mexico','MX','MEX','484','052',1,1),(145,'Micronesia','FM','FSM','583','691',1,1),(146,'Moldova','MD','MDA','498','373',1,1),(147,'Monaco','MC','MCO','492','377',1,1),(148,'Mongolia','MN','MNG','496','976',1,1),(149,'Montenegro','ME','MNE','499','382',1,1),(150,'Montserrat','MS','MSR','500','664',0,1),(151,'Morocco','MA','MAR','504','212',1,1),(152,'Mozambique','MZ','MOZ','508','258',1,1),(153,'Namibia','NA','NAM','516','264',1,1),(154,'Nauru','NR','NRU','520','674',0,1),(155,'Nepal','NP','NPL','524','977',1,1),(156,'Netherlands Antilles','AN','ANT','530','599',1,1),(157,'New Caledonia','NC','NCL','540','687',1,1),(158,'New Zealand','NZ','NZL','554','064',1,1),(159,'Nicaragua','NI','NIC','558','505',1,1),(160,'Niger','NE','NER','562','227',1,1),(161,'Nigeria','NG','NGA','566','234',1,1),(162,'Niue','NU','NIU','570','683',0,1),(163,'Norfolk Island','NF','NFK','574','672',1,1),(164,'Norway','NO','NOR','578','047',1,1),(165,'Oman','OM','OMN','512','968',1,1),(166,'Pakistan','PK','PAK','586','092',1,1),(167,'Palau','PW','PLW','585','680',1,1),(168,'Palestine','PS','PSE','275','970',1,1),(169,'Panama','PA','PAN','591','507',1,1),(170,'Papua New Guinea','PG','PNG','598','675',1,1),(171,'Paraguay','PY','PRY','600','595',1,1),(172,'Peru','PE','PER','604','051',1,1),(173,'Philippines','PH','PHL','608','063',1,1),(174,'Poland','PL','POL','616','048',1,1),(175,'Puerto Rico','PR','PRI','630','787',1,1),(176,'Qatar','QA','QAT','634','974',0,1),(177,'Reunion Island','RE','REU','638','262',1,1),(178,'Romania','RO','ROU','642','040',1,1),(179,'Rwanda','RW','RWA','646','250',0,1),(180,'St. Helena','SH','SHN','654','290',1,1),(181,'St. Kitts','KN','KNA','659','869',0,1),(182,'St. Lucia','LC','LCA','662','758',0,1),(183,'St. Pierre & Miquelon','PM','SPM','666','508',1,1),(184,'St. Vincent','VC','VCT','670','784',1,1),(185,'San Marino','SM','SMR','674','378',1,1),(186,'Sao Tome & Principe','ST','STP','678','239',0,1),(187,'Saudi Arabia','SA','SAU','682','966',1,1),(188,'Senegal','SN','SEN','686','221',1,1),(189,'Serbia','RS','SRB','688','381',1,1),(190,'Seychelles','SC','SYC','690','248',0,1),(191,'Sierra Leone','SL','SLE','694','249',0,1),(192,'Slovakia','SK','SVK','703','421',1,1),(193,'Slovenia','SI','SVN','705','386',1,1),(194,'Solomon Islands','SB','SLB','90','677',0,1),(195,'Somalia','SO','SOM','706','252',0,1),(196,'South Africa','ZA','ZAF','710','027',1,1),(197,'Sri Lanka','LK','LKA','144','094',1,1),(198,'Sudan','SD','SDN','736','095',1,1),(199,'Suriname','SR','SUR','740','597',0,1),(200,'Swaziland','SZ','SWZ','748','268',1,1),(201,'Sweden','SE','SWE','752','046',1,1),(202,'Switzerland','CH','CHE','756','041',1,1),(203,'Syria','SY','SYR','760','963',0,1),(204,'Taiwan','TW','TWN','158','886',1,1),(205,'Tajikistan','TJ','TJK','762','992',1,1),(206,'Tanzania','TZ','TZA','834','255',0,1),(207,'Thailand','TH','THA','764','066',1,1),(208,'Togo','TG','TGO','768','228',1,1),(209,'Tonga','TO','TON','776','676',0,1),(210,'Trinidad & Tobago','TT','TTO','780','868',0,1),(211,'Tunisia','TN','TUN','788','216',1,1),(212,'Turkmenistan','TM','TKM','795','993',1,1),(213,'Turks & Caicos','TC','TCA','796','649',1,1),(214,'Tuvalu','TV','TUV','798','688',0,1),(215,'Uganda','UG','UGA','800','256',0,1),(216,'Ukraine','UA','UKR','804','380',1,1),(217,'United Arab Emirates','AE','ARE','784','971',0,1),(218,'Uruguay','UY','URY','858','598',1,1),(219,'Uzbekistan','UZ','UZB','860','998',1,1),(220,'Vanuatu','VU','VUT','548','678',0,1),(221,'Vatican City','VA','VAT','336','039',1,1),(222,'Venezuela','VE','VEN','862','058',1,1),(223,'Wallis & Futuna','WF','WLF','876','681',1,1),(224,'Western Samoa','EH','ESH','732','685',1,1),(225,'Yemen','YE','YEM','887','967',0,1),(226,'Zambia','ZM','ZMB','894','260',1,1),(227,'Zimbabwe','ZW','ZWE','716','263',0,1);
/*!40000 ALTER TABLE `Country` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CyrusUser`
--

DROP TABLE IF EXISTS `CyrusUser`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `CyrusUser` (
  `userId` varchar(75) NOT NULL,
  `password_` varchar(75) NOT NULL,
  PRIMARY KEY (`userId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CyrusUser`
--

LOCK TABLES `CyrusUser` WRITE;
/*!40000 ALTER TABLE `CyrusUser` DISABLE KEYS */;
/*!40000 ALTER TABLE `CyrusUser` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CyrusVirtual`
--

DROP TABLE IF EXISTS `CyrusVirtual`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `CyrusVirtual` (
  `emailAddress` varchar(75) NOT NULL,
  `userId` varchar(75) NOT NULL,
  PRIMARY KEY (`emailAddress`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CyrusVirtual`
--

LOCK TABLES `CyrusVirtual` WRITE;
/*!40000 ALTER TABLE `CyrusVirtual` DISABLE KEYS */;
/*!40000 ALTER TABLE `CyrusVirtual` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `DDLRecord`
--

DROP TABLE IF EXISTS `DDLRecord`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `DDLRecord` (
  `uuid_` varchar(75) DEFAULT NULL,
  `recordId` bigint(20) NOT NULL,
  `groupId` bigint(20) DEFAULT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `userId` bigint(20) DEFAULT NULL,
  `userName` varchar(75) DEFAULT NULL,
  `versionUserId` bigint(20) DEFAULT NULL,
  `versionUserName` varchar(75) DEFAULT NULL,
  `createDate` datetime DEFAULT NULL,
  `modifiedDate` datetime DEFAULT NULL,
  `DDMStorageId` bigint(20) DEFAULT NULL,
  `recordSetId` bigint(20) DEFAULT NULL,
  `version` varchar(75) DEFAULT NULL,
  `displayIndex` int(11) DEFAULT NULL,
  PRIMARY KEY (`recordId`),
  UNIQUE KEY `IX_B4328F39` (`uuid_`,`groupId`),
  KEY `IX_87A6B599` (`recordSetId`),
  KEY `IX_AAC564D3` (`recordSetId`,`userId`),
  KEY `IX_8BC2F891` (`uuid_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `DDLRecord`
--

LOCK TABLES `DDLRecord` WRITE;
/*!40000 ALTER TABLE `DDLRecord` DISABLE KEYS */;
INSERT INTO `DDLRecord` VALUES ('0453ebb0-57b5-403f-ba3d-1e6b30060196',10581,10557,10154,10196,'Test Test',10196,'Test Test','2014-03-18 17:44:03','2014-03-18 17:44:03',10582,10579,'1.0',0);
/*!40000 ALTER TABLE `DDLRecord` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `DDLRecordSet`
--

DROP TABLE IF EXISTS `DDLRecordSet`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `DDLRecordSet` (
  `uuid_` varchar(75) DEFAULT NULL,
  `recordSetId` bigint(20) NOT NULL,
  `groupId` bigint(20) DEFAULT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `userId` bigint(20) DEFAULT NULL,
  `userName` varchar(75) DEFAULT NULL,
  `createDate` datetime DEFAULT NULL,
  `modifiedDate` datetime DEFAULT NULL,
  `DDMStructureId` bigint(20) DEFAULT NULL,
  `recordSetKey` varchar(75) DEFAULT NULL,
  `name` longtext,
  `description` longtext,
  `minDisplayRows` int(11) DEFAULT NULL,
  `scope` int(11) DEFAULT NULL,
  PRIMARY KEY (`recordSetId`),
  UNIQUE KEY `IX_56DAB121` (`groupId`,`recordSetKey`),
  UNIQUE KEY `IX_270BA5E1` (`uuid_`,`groupId`),
  KEY `IX_4FA5969F` (`groupId`),
  KEY `IX_561E44E9` (`uuid_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `DDLRecordSet`
--

LOCK TABLES `DDLRecordSet` WRITE;
/*!40000 ALTER TABLE `DDLRecordSet` DISABLE KEYS */;
INSERT INTO `DDLRecordSet` VALUES ('3f99dc63-90ad-43f2-b1ad-397b6e8c5f98',10579,10557,10154,10196,'Test Test','2014-03-18 17:43:53','2014-03-18 17:43:53',10575,'10578','<?xml version=\'1.0\' encoding=\'UTF-8\'?><root available-locales=\"en_US\" default-locale=\"en_US\"><Name language-id=\"en_US\">List Name</Name></root>','<?xml version=\'1.0\' encoding=\'UTF-8\'?><root available-locales=\"en_US\" default-locale=\"en_US\"><Description language-id=\"en_US\">List Description</Description></root>',20,0);
/*!40000 ALTER TABLE `DDLRecordSet` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `DDLRecordVersion`
--

DROP TABLE IF EXISTS `DDLRecordVersion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `DDLRecordVersion` (
  `recordVersionId` bigint(20) NOT NULL,
  `groupId` bigint(20) DEFAULT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `userId` bigint(20) DEFAULT NULL,
  `userName` varchar(75) DEFAULT NULL,
  `createDate` datetime DEFAULT NULL,
  `DDMStorageId` bigint(20) DEFAULT NULL,
  `recordSetId` bigint(20) DEFAULT NULL,
  `recordId` bigint(20) DEFAULT NULL,
  `version` varchar(75) DEFAULT NULL,
  `displayIndex` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `statusByUserId` bigint(20) DEFAULT NULL,
  `statusByUserName` varchar(75) DEFAULT NULL,
  `statusDate` datetime DEFAULT NULL,
  PRIMARY KEY (`recordVersionId`),
  UNIQUE KEY `IX_C79E347` (`recordId`,`version`),
  KEY `IX_2F4DDFE1` (`recordId`),
  KEY `IX_762ADC7` (`recordId`,`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `DDLRecordVersion`
--

LOCK TABLES `DDLRecordVersion` WRITE;
/*!40000 ALTER TABLE `DDLRecordVersion` DISABLE KEYS */;
INSERT INTO `DDLRecordVersion` VALUES (10584,10557,10154,10196,'Test Test','2014-03-18 17:44:03',10582,10579,10581,'1.0',0,0,10196,'Test Test','2014-03-18 17:44:03');
/*!40000 ALTER TABLE `DDLRecordVersion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `DDMContent`
--

DROP TABLE IF EXISTS `DDMContent`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `DDMContent` (
  `uuid_` varchar(75) DEFAULT NULL,
  `contentId` bigint(20) NOT NULL,
  `groupId` bigint(20) DEFAULT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `userId` bigint(20) DEFAULT NULL,
  `userName` varchar(75) DEFAULT NULL,
  `createDate` datetime DEFAULT NULL,
  `modifiedDate` datetime DEFAULT NULL,
  `name` longtext,
  `description` longtext,
  `xml` longtext,
  PRIMARY KEY (`contentId`),
  UNIQUE KEY `IX_EB9BDE28` (`uuid_`,`groupId`),
  KEY `IX_E3BAF436` (`companyId`),
  KEY `IX_50BF1038` (`groupId`),
  KEY `IX_AE4B50C2` (`uuid_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `DDMContent`
--

LOCK TABLES `DDMContent` WRITE;
/*!40000 ALTER TABLE `DDMContent` DISABLE KEYS */;
INSERT INTO `DDMContent` VALUES ('6ba5e7ed-0dcf-411a-8545-a512cbc42d99',10582,10557,10154,10196,'Test Test','2014-03-18 17:44:03','2014-03-18 17:44:03','com.liferay.portlet.dynamicdatamapping.model.DDMStorageLink','','<?xml version=\"1.0\"?>\n\n<root>\n	<dynamic-element name=\"text\">\n		<dynamic-content><![CDATA[Text]]></dynamic-content>\n	</dynamic-element>\n</root>'),('573f89fa-272f-46bc-8ccd-4e23657a694d',10802,10778,10154,10196,'Test Test','2014-03-18 17:55:13','2014-03-18 17:55:13','com.liferay.portlet.dynamicdatamapping.model.DDMStorageLink','','<?xml version=\"1.0\"?>\n\n<root>\n	<dynamic-element name=\"HttpHeaders_CONTENT_TYPE\">\n		<dynamic-content><![CDATA[text/plain]]></dynamic-content>\n	</dynamic-element>\n	<dynamic-element name=\"HttpHeaders_CONTENT_ENCODING\">\n		<dynamic-content><![CDATA[ISO-8859-1]]></dynamic-content>\n	</dynamic-element>\n</root>');
/*!40000 ALTER TABLE `DDMContent` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `DDMStorageLink`
--

DROP TABLE IF EXISTS `DDMStorageLink`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `DDMStorageLink` (
  `uuid_` varchar(75) DEFAULT NULL,
  `storageLinkId` bigint(20) NOT NULL,
  `classNameId` bigint(20) DEFAULT NULL,
  `classPK` bigint(20) DEFAULT NULL,
  `structureId` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`storageLinkId`),
  UNIQUE KEY `IX_702D1AD5` (`classPK`),
  KEY `IX_81776090` (`structureId`),
  KEY `IX_32A18526` (`uuid_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `DDMStorageLink`
--

LOCK TABLES `DDMStorageLink` WRITE;
/*!40000 ALTER TABLE `DDMStorageLink` DISABLE KEYS */;
INSERT INTO `DDMStorageLink` VALUES ('cdbb345a-a651-4ced-8010-ba9affbdd787',10583,10099,10582,10575),('c6d2203f-9498-42e3-9324-9466e039859f',10803,10099,10802,10308);
/*!40000 ALTER TABLE `DDMStorageLink` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `DDMStructure`
--

DROP TABLE IF EXISTS `DDMStructure`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `DDMStructure` (
  `uuid_` varchar(75) DEFAULT NULL,
  `structureId` bigint(20) NOT NULL,
  `groupId` bigint(20) DEFAULT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `userId` bigint(20) DEFAULT NULL,
  `userName` varchar(75) DEFAULT NULL,
  `createDate` datetime DEFAULT NULL,
  `modifiedDate` datetime DEFAULT NULL,
  `classNameId` bigint(20) DEFAULT NULL,
  `structureKey` varchar(75) DEFAULT NULL,
  `name` longtext,
  `description` longtext,
  `xsd` longtext,
  `storageType` varchar(75) DEFAULT NULL,
  `type_` int(11) DEFAULT NULL,
  PRIMARY KEY (`structureId`),
  UNIQUE KEY `IX_490E7A1E` (`groupId`,`structureKey`),
  UNIQUE KEY `IX_85C7EBE2` (`uuid_`,`groupId`),
  KEY `IX_31817A62` (`classNameId`),
  KEY `IX_C8419FBE` (`groupId`),
  KEY `IX_E61809C8` (`uuid_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `DDMStructure`
--

LOCK TABLES `DDMStructure` WRITE;
/*!40000 ALTER TABLE `DDMStructure` DISABLE KEYS */;
INSERT INTO `DDMStructure` VALUES ('33691c9b-b333-44b7-b3f7-000ff374df47',10297,10192,10154,10158,'','2014-03-18 17:33:39','2014-03-18 17:33:39',10089,'Learning Module Metadata','<?xml version=\'1.0\' encoding=\'UTF-8\'?><root available-locales=\"en_US\" default-locale=\"en_US\"><Name language-id=\"en_US\">Learning Module Metadata</Name></root>','<?xml version=\'1.0\' encoding=\'UTF-8\'?><root available-locales=\"en_US\" default-locale=\"en_US\"><Description language-id=\"en_US\">Learning Module Metadata</Description></root>','<?xml version=\"1.0\"?>\n\n<root available-locales=\"en_US\" default-locale=\"en_US\">\n	<dynamic-element dataType=\"string\" name=\"select2235\" type=\"select\">\n		<dynamic-element name=\"home_edition\" type=\"option\" value=\"HE\">\n			<meta-data locale=\"en_US\">\n				<entry name=\"label\"><![CDATA[Home Edition]]></entry>\n				<entry name=\"multiple\"><![CDATA[false]]></entry>\n			</meta-data>\n		</dynamic-element>\n		<dynamic-element name=\"business_edition\" type=\"option\" value=\"BE\">\n			<meta-data locale=\"en_US\">\n				<entry name=\"label\"><![CDATA[Business Edition]]></entry>\n			</meta-data>\n		</dynamic-element>\n		<dynamic-element name=\"enterprise_edition\" type=\"option\" value=\"EE\">\n			<meta-data locale=\"en_US\">\n				<entry name=\"label\"><![CDATA[Enterprise Edition]]></entry>\n			</meta-data>\n		</dynamic-element>\n		<meta-data locale=\"en_US\">\n			<entry name=\"displayChildLabelAsValue\"><![CDATA[true]]></entry>\n			<entry name=\"label\"><![CDATA[Product]]></entry>\n			<entry name=\"multiple\"><![CDATA[true]]></entry>\n			<entry name=\"predefinedValue\"><![CDATA[]]></entry>\n			<entry name=\"readOnly\"><![CDATA[false]]></entry>\n			<entry name=\"required\"><![CDATA[false]]></entry>\n			<entry name=\"showLabel\"><![CDATA[true]]></entry>\n			<entry name=\"tip\"><![CDATA[]]></entry>\n		</meta-data>\n	</dynamic-element>\n	<dynamic-element dataType=\"string\" name=\"select3212\" type=\"select\">\n		<dynamic-element name=\"1_0\" type=\"option\" value=\"1\">\n			<meta-data locale=\"en_US\">\n				<entry name=\"label\"><![CDATA[1.0]]></entry>\n				<entry name=\"multiple\"><![CDATA[false]]></entry>\n			</meta-data>\n		</dynamic-element>\n		<dynamic-element name=\"2_0\" type=\"option\" value=\"2\">\n			<meta-data locale=\"en_US\">\n				<entry name=\"label\"><![CDATA[2.0]]></entry>\n			</meta-data>\n		</dynamic-element>\n		<dynamic-element name=\"3_0\" type=\"option\" value=\"3\">\n			<meta-data locale=\"en_US\">\n				<entry name=\"label\"><![CDATA[3.0]]></entry>\n			</meta-data>\n		</dynamic-element>\n		<meta-data locale=\"en_US\">\n			<entry name=\"displayChildLabelAsValue\"><![CDATA[true]]></entry>\n			<entry name=\"label\"><![CDATA[Version]]></entry>\n			<entry name=\"multiple\"><![CDATA[true]]></entry>\n			<entry name=\"predefinedValue\"><![CDATA[]]></entry>\n			<entry name=\"readOnly\"><![CDATA[false]]></entry>\n			<entry name=\"required\"><![CDATA[false]]></entry>\n			<entry name=\"showLabel\"><![CDATA[true]]></entry>\n			<entry name=\"tip\"><![CDATA[]]></entry>\n		</meta-data>\n	</dynamic-element>\n	<dynamic-element dataType=\"string\" name=\"select4115\" type=\"select\">\n		<dynamic-element name=\"administration\" type=\"option\" value=\"admin\">\n			<meta-data locale=\"en_US\">\n				<entry name=\"label\"><![CDATA[Administration]]></entry>\n				<entry name=\"multiple\"><![CDATA[false]]></entry>\n			</meta-data>\n		</dynamic-element>\n		<dynamic-element name=\"installation\" type=\"option\" value=\"install\">\n			<meta-data locale=\"en_US\">\n				<entry name=\"label\"><![CDATA[Installation]]></entry>\n			</meta-data>\n		</dynamic-element>\n		<dynamic-element name=\"configuration\" type=\"option\" value=\"config\">\n			<meta-data locale=\"en_US\">\n				<entry name=\"label\"><![CDATA[Configuration]]></entry>\n			</meta-data>\n		</dynamic-element>\n		<meta-data locale=\"en_US\">\n			<entry name=\"displayChildLabelAsValue\"><![CDATA[true]]></entry>\n			<entry name=\"label\"><![CDATA[Topics]]></entry>\n			<entry name=\"multiple\"><![CDATA[true]]></entry>\n			<entry name=\"predefinedValue\"><![CDATA[]]></entry>\n			<entry name=\"readOnly\"><![CDATA[false]]></entry>\n			<entry name=\"required\"><![CDATA[false]]></entry>\n			<entry name=\"showLabel\"><![CDATA[true]]></entry>\n			<entry name=\"tip\"><![CDATA[]]></entry>\n		</meta-data>\n	</dynamic-element>\n	<dynamic-element dataType=\"string\" name=\"select5069\" type=\"select\">\n		<dynamic-element name=\"beginner\" type=\"option\" value=\"beginner\">\n			<meta-data locale=\"en_US\">\n				<entry name=\"label\"><![CDATA[Beginner]]></entry>\n				<entry name=\"multiple\"><![CDATA[false]]></entry>\n			</meta-data>\n		</dynamic-element>\n		<dynamic-element name=\"intermediate\" type=\"option\" value=\"intermediate\">\n			<meta-data locale=\"en_US\">\n				<entry name=\"label\"><![CDATA[Intermediate]]></entry>\n			</meta-data>\n		</dynamic-element>\n		<dynamic-element name=\"advanced\" type=\"option\" value=\"advanced\">\n			<meta-data locale=\"en_US\">\n				<entry name=\"label\"><![CDATA[Advanced]]></entry>\n			</meta-data>\n		</dynamic-element>\n		<meta-data locale=\"en_US\">\n			<entry name=\"displayChildLabelAsValue\"><![CDATA[true]]></entry>\n			<entry name=\"label\"><![CDATA[Level]]></entry>\n			<entry name=\"multiple\"><![CDATA[false]]></entry>\n			<entry name=\"predefinedValue\"><![CDATA[]]></entry>\n			<entry name=\"readOnly\"><![CDATA[false]]></entry>\n			<entry name=\"required\"><![CDATA[false]]></entry>\n			<entry name=\"showLabel\"><![CDATA[true]]></entry>\n			<entry name=\"tip\"><![CDATA[]]></entry>\n		</meta-data>\n	</dynamic-element>\n</root>','xml',0),('e9fca9e1-7f02-4959-983d-34a9b65be183',10298,10192,10154,10158,'','2014-03-18 17:33:39','2014-03-18 17:33:39',10089,'Marketing Campaign Theme Metadata','<?xml version=\'1.0\' encoding=\'UTF-8\'?><root available-locales=\"en_US\" default-locale=\"en_US\"><Name language-id=\"en_US\">Marketing Campaign Theme Metadata</Name></root>','<?xml version=\'1.0\' encoding=\'UTF-8\'?><root available-locales=\"en_US\" default-locale=\"en_US\"><Description language-id=\"en_US\">Marketing Campaign Theme Metadata</Description></root>','<?xml version=\"1.0\"?>\n\n<root available-locales=\"en_US\" default-locale=\"en_US\">\n	<dynamic-element dataType=\"string\" name=\"select2305\" type=\"select\">\n		<dynamic-element name=\"strong_company\" type=\"option\" value=\"strong\">\n			<meta-data locale=\"en_US\">\n				<entry name=\"label\"><![CDATA[Strong Company]]></entry>\n				<entry name=\"multiple\"><![CDATA[false]]></entry>\n			</meta-data>\n		</dynamic-element>\n		<dynamic-element name=\"new_product_launch\" type=\"option\" value=\"product\">\n			<meta-data locale=\"en_US\">\n				<entry name=\"label\"><![CDATA[New Product Launch]]></entry>\n			</meta-data>\n		</dynamic-element>\n		<dynamic-element name=\"company_philosophy\" type=\"option\" value=\"philosophy\">\n			<meta-data locale=\"en_US\">\n				<entry name=\"label\"><![CDATA[Company Philosophy]]></entry>\n			</meta-data>\n		</dynamic-element>\n		<meta-data locale=\"en_US\">\n			<entry name=\"displayChildLabelAsValue\"><![CDATA[true]]></entry>\n			<entry name=\"label\"><![CDATA[Select]]></entry>\n			<entry name=\"multiple\"><![CDATA[false]]></entry>\n			<entry name=\"predefinedValue\"><![CDATA[]]></entry>\n			<entry name=\"readOnly\"><![CDATA[false]]></entry>\n			<entry name=\"required\"><![CDATA[false]]></entry>\n			<entry name=\"showLabel\"><![CDATA[true]]></entry>\n			<entry name=\"tip\"><![CDATA[]]></entry>\n		</meta-data>\n	</dynamic-element>\n	<dynamic-element dataType=\"string\" name=\"select3229\" type=\"select\">\n		<dynamic-element name=\"your_trusted_advisor\" type=\"option\" value=\"advisor\">\n			<meta-data locale=\"en_US\">\n				<entry name=\"label\"><![CDATA[Your Trusted Advisor]]></entry>\n				<entry name=\"multiple\"><![CDATA[false]]></entry>\n			</meta-data>\n		</dynamic-element>\n		<dynamic-element name=\"10_years_of_customer_solutions\" type=\"option\" value=\"solutions\">\n			<meta-data locale=\"en_US\">\n				<entry name=\"label\"><![CDATA[10 Years of Customer Solutions]]></entry>\n			</meta-data>\n		</dynamic-element>\n		<dynamic-element name=\"making_a_difference\" type=\"option\" value=\"difference\">\n			<meta-data locale=\"en_US\">\n				<entry name=\"label\"><![CDATA[Making a Difference]]></entry>\n			</meta-data>\n		</dynamic-element>\n		<meta-data locale=\"en_US\">\n			<entry name=\"displayChildLabelAsValue\"><![CDATA[true]]></entry>\n			<entry name=\"label\"><![CDATA[Campaign Theme]]></entry>\n			<entry name=\"multiple\"><![CDATA[false]]></entry>\n			<entry name=\"predefinedValue\"><![CDATA[]]></entry>\n			<entry name=\"readOnly\"><![CDATA[false]]></entry>\n			<entry name=\"required\"><![CDATA[false]]></entry>\n			<entry name=\"showLabel\"><![CDATA[true]]></entry>\n			<entry name=\"tip\"><![CDATA[]]></entry>\n		</meta-data>\n	</dynamic-element>\n	<dynamic-element dataType=\"string\" name=\"select4282\" type=\"select\">\n		<dynamic-element name=\"awareness\" type=\"option\" value=\"awareness\">\n			<meta-data locale=\"en_US\">\n				<entry name=\"label\"><![CDATA[Awareness]]></entry>\n				<entry name=\"multiple\"><![CDATA[false]]></entry>\n			</meta-data>\n		</dynamic-element>\n		<dynamic-element name=\"lead_generation\" type=\"option\" value=\"leads\">\n			<meta-data locale=\"en_US\">\n				<entry name=\"label\"><![CDATA[Lead Generation]]></entry>\n			</meta-data>\n		</dynamic-element>\n		<dynamic-element name=\"customer_service\" type=\"option\" value=\"service\">\n			<meta-data locale=\"en_US\">\n				<entry name=\"label\"><![CDATA[Customer Service]]></entry>\n			</meta-data>\n		</dynamic-element>\n		<meta-data locale=\"en_US\">\n			<entry name=\"displayChildLabelAsValue\"><![CDATA[true]]></entry>\n			<entry name=\"label\"><![CDATA[Business Goal]]></entry>\n			<entry name=\"multiple\"><![CDATA[false]]></entry>\n			<entry name=\"predefinedValue\"><![CDATA[]]></entry>\n			<entry name=\"readOnly\"><![CDATA[false]]></entry>\n			<entry name=\"required\"><![CDATA[false]]></entry>\n			<entry name=\"showLabel\"><![CDATA[true]]></entry>\n			<entry name=\"tip\"><![CDATA[]]></entry>\n		</meta-data>\n	</dynamic-element>\n</root>','xml',0),('287e2fe4-7cfa-4e07-94fb-50ff0055c8a1',10299,10192,10154,10158,'','2014-03-18 17:33:39','2014-03-18 17:33:39',10089,'Meeting Metadata','<?xml version=\'1.0\' encoding=\'UTF-8\'?><root available-locales=\"en_US\" default-locale=\"en_US\"><Name language-id=\"en_US\">Meeting Metadata</Name></root>','<?xml version=\'1.0\' encoding=\'UTF-8\'?><root available-locales=\"en_US\" default-locale=\"en_US\"><Description language-id=\"en_US\">Metadata for meeting</Description></root>','<?xml version=\"1.0\"?>\n\n<root available-locales=\"en_US\" default-locale=\"en_US\">\n	<dynamic-element dataType=\"date\" fieldNamespace=\"ddm\" name=\"ddm-date3054\" type=\"ddm-date\">\n		<meta-data locale=\"en_US\">\n			<entry name=\"fieldCssClass\"><![CDATA[aui-w25]]></entry>\n			<entry name=\"label\"><![CDATA[Date]]></entry>\n			<entry name=\"predefinedValue\"><![CDATA[]]></entry>\n			<entry name=\"readOnly\"><![CDATA[false]]></entry>\n			<entry name=\"required\"><![CDATA[false]]></entry>\n			<entry name=\"showLabel\"><![CDATA[true]]></entry>\n			<entry name=\"tip\"><![CDATA[]]></entry>\n			<entry name=\"width\"><![CDATA[25]]></entry>\n		</meta-data>\n	</dynamic-element>\n	<dynamic-element dataType=\"string\" name=\"text2217\" type=\"text\">\n		<meta-data locale=\"en_US\">\n			<entry name=\"fieldCssClass\"><![CDATA[aui-w25]]></entry>\n			<entry name=\"label\"><![CDATA[Meeting Name]]></entry>\n			<entry name=\"predefinedValue\"><![CDATA[]]></entry>\n			<entry name=\"readOnly\"><![CDATA[false]]></entry>\n			<entry name=\"required\"><![CDATA[false]]></entry>\n			<entry name=\"showLabel\"><![CDATA[true]]></entry>\n			<entry name=\"tip\"><![CDATA[]]></entry>\n			<entry name=\"width\"><![CDATA[25]]></entry>\n		</meta-data>\n	</dynamic-element>\n	<dynamic-element dataType=\"string\" name=\"text4569\" type=\"text\">\n		<meta-data locale=\"en_US\">\n			<entry name=\"fieldCssClass\"><![CDATA[aui-w25]]></entry>\n			<entry name=\"label\"><![CDATA[Time]]></entry>\n			<entry name=\"predefinedValue\"><![CDATA[]]></entry>\n			<entry name=\"readOnly\"><![CDATA[false]]></entry>\n			<entry name=\"required\"><![CDATA[false]]></entry>\n			<entry name=\"showLabel\"><![CDATA[true]]></entry>\n			<entry name=\"tip\"><![CDATA[]]></entry>\n			<entry name=\"width\"><![CDATA[25]]></entry>\n		</meta-data>\n	</dynamic-element>\n	<dynamic-element dataType=\"string\" name=\"text5638\" type=\"text\">\n		<meta-data locale=\"en_US\">\n			<entry name=\"fieldCssClass\"><![CDATA[aui-w25]]></entry>\n			<entry name=\"label\"><![CDATA[Location]]></entry>\n			<entry name=\"predefinedValue\"><![CDATA[]]></entry>\n			<entry name=\"readOnly\"><![CDATA[false]]></entry>\n			<entry name=\"required\"><![CDATA[false]]></entry>\n			<entry name=\"showLabel\"><![CDATA[true]]></entry>\n			<entry name=\"tip\"><![CDATA[]]></entry>\n			<entry name=\"width\"><![CDATA[25]]></entry>\n		</meta-data>\n	</dynamic-element>\n	<dynamic-element dataType=\"string\" name=\"textarea6584\" type=\"textarea\">\n		<meta-data locale=\"en_US\">\n			<entry name=\"fieldCssClass\"><![CDATA[aui-w25]]></entry>\n			<entry name=\"label\"><![CDATA[Description]]></entry>\n			<entry name=\"predefinedValue\"><![CDATA[]]></entry>\n			<entry name=\"readOnly\"><![CDATA[false]]></entry>\n			<entry name=\"required\"><![CDATA[false]]></entry>\n			<entry name=\"showLabel\"><![CDATA[true]]></entry>\n			<entry name=\"tip\"><![CDATA[]]></entry>\n			<entry name=\"width\"><![CDATA[25]]></entry>\n		</meta-data>\n	</dynamic-element>\n	<dynamic-element dataType=\"string\" name=\"textarea7502\" type=\"textarea\">\n		<meta-data locale=\"en_US\">\n			<entry name=\"fieldCssClass\"><![CDATA[aui-w25]]></entry>\n			<entry name=\"label\"><![CDATA[Participants]]></entry>\n			<entry name=\"predefinedValue\"><![CDATA[]]></entry>\n			<entry name=\"readOnly\"><![CDATA[false]]></entry>\n			<entry name=\"required\"><![CDATA[false]]></entry>\n			<entry name=\"showLabel\"><![CDATA[true]]></entry>\n			<entry name=\"tip\"><![CDATA[]]></entry>\n			<entry name=\"width\"><![CDATA[25]]></entry>\n		</meta-data>\n	</dynamic-element>\n</root>','xml',0),('42f510aa-6da9-48fa-b975-6d9bc97839f6',10301,10192,10154,10158,'','2014-03-18 17:33:39','2014-03-18 17:33:39',10089,'auto_10300','<?xml version=\'1.0\' encoding=\'UTF-8\'?><root available-locales=\"en_US\" default-locale=\"en_US\"><Name language-id=\"en_US\">Contract</Name></root>','<?xml version=\'1.0\' encoding=\'UTF-8\'?><root available-locales=\"en_US\" default-locale=\"en_US\"><Description language-id=\"en_US\">Legal Contracts</Description></root>','<?xml version=\"1.0\"?>\n\n<root available-locales=\"en_US\" default-locale=\"en_US\">\n	<dynamic-element dataType=\"date\" fieldNamespace=\"ddm\" name=\"ddm-date18949\" type=\"ddm-date\">\n		<meta-data locale=\"en_US\">\n			<entry name=\"fieldCssClass\"><![CDATA[aui-w25]]></entry>\n			<entry name=\"label\"><![CDATA[Effective Date]]></entry>\n			<entry name=\"predefinedValue\"><![CDATA[]]></entry>\n			<entry name=\"readOnly\"><![CDATA[false]]></entry>\n			<entry name=\"required\"><![CDATA[false]]></entry>\n			<entry name=\"showLabel\"><![CDATA[true]]></entry>\n			<entry name=\"tip\"><![CDATA[]]></entry>\n			<entry name=\"width\"><![CDATA[25]]></entry>\n		</meta-data>\n	</dynamic-element>\n	<dynamic-element dataType=\"date\" fieldNamespace=\"ddm\" name=\"ddm-date20127\" type=\"ddm-date\">\n		<meta-data locale=\"en_US\">\n			<entry name=\"fieldCssClass\"><![CDATA[aui-w25]]></entry>\n			<entry name=\"label\"><![CDATA[Expiration Date]]></entry>\n			<entry name=\"predefinedValue\"><![CDATA[]]></entry>\n			<entry name=\"readOnly\"><![CDATA[false]]></entry>\n			<entry name=\"required\"><![CDATA[false]]></entry>\n			<entry name=\"showLabel\"><![CDATA[true]]></entry>\n			<entry name=\"tip\"><![CDATA[]]></entry>\n			<entry name=\"width\"><![CDATA[25]]></entry>\n		</meta-data>\n	</dynamic-element>\n	<dynamic-element dataType=\"string\" name=\"select10264\" type=\"select\">\n		<dynamic-element name=\"nda\" type=\"option\" value=\"NDA\">\n			<meta-data locale=\"en_US\">\n				<entry name=\"label\"><![CDATA[NDA]]></entry>\n				<entry name=\"multiple\"><![CDATA[false]]></entry>\n			</meta-data>\n		</dynamic-element>\n		<dynamic-element name=\"msa\" type=\"option\" value=\"MSA\">\n			<meta-data locale=\"en_US\">\n				<entry name=\"label\"><![CDATA[MSA]]></entry>\n			</meta-data>\n		</dynamic-element>\n		<dynamic-element name=\"license_agreement\" type=\"option\" value=\"License\">\n			<meta-data locale=\"en_US\">\n				<entry name=\"label\"><![CDATA[License Agreement]]></entry>\n			</meta-data>\n		</dynamic-element>\n		<meta-data locale=\"en_US\">\n			<entry name=\"displayChildLabelAsValue\"><![CDATA[true]]></entry>\n			<entry name=\"label\"><![CDATA[Contract Type]]></entry>\n			<entry name=\"multiple\"><![CDATA[false]]></entry>\n			<entry name=\"predefinedValue\"><![CDATA[]]></entry>\n			<entry name=\"readOnly\"><![CDATA[false]]></entry>\n			<entry name=\"required\"><![CDATA[false]]></entry>\n			<entry name=\"showLabel\"><![CDATA[true]]></entry>\n			<entry name=\"tip\"><![CDATA[]]></entry>\n		</meta-data>\n	</dynamic-element>\n	<dynamic-element dataType=\"string\" name=\"select4893\" type=\"select\">\n		<dynamic-element name=\"draft\" type=\"option\" value=\"Draft\">\n			<meta-data locale=\"en_US\">\n				<entry name=\"label\"><![CDATA[Draft]]></entry>\n				<entry name=\"multiple\"><![CDATA[false]]></entry>\n			</meta-data>\n		</dynamic-element>\n		<dynamic-element name=\"in_review\" type=\"option\" value=\"Review\">\n			<meta-data locale=\"en_US\">\n				<entry name=\"label\"><![CDATA[In Review]]></entry>\n			</meta-data>\n		</dynamic-element>\n		<dynamic-element name=\"suspended\" type=\"option\" value=\"Suspended\">\n			<meta-data locale=\"en_US\">\n				<entry name=\"label\"><![CDATA[Suspended]]></entry>\n			</meta-data>\n		</dynamic-element>\n		<dynamic-element name=\"signed\" type=\"option\" value=\"Signed\">\n			<meta-data locale=\"en_US\">\n				<entry name=\"label\"><![CDATA[Signed]]></entry>\n			</meta-data>\n		</dynamic-element>\n		<meta-data locale=\"en_US\">\n			<entry name=\"displayChildLabelAsValue\"><![CDATA[true]]></entry>\n			<entry name=\"label\"><![CDATA[Status]]></entry>\n			<entry name=\"multiple\"><![CDATA[false]]></entry>\n			<entry name=\"predefinedValue\"><![CDATA[]]></entry>\n			<entry name=\"readOnly\"><![CDATA[false]]></entry>\n			<entry name=\"required\"><![CDATA[false]]></entry>\n			<entry name=\"showLabel\"><![CDATA[true]]></entry>\n			<entry name=\"tip\"><![CDATA[]]></entry>\n		</meta-data>\n	</dynamic-element>\n	<dynamic-element dataType=\"string\" name=\"text14822\" type=\"text\">\n		<meta-data locale=\"en_US\">\n			<entry name=\"fieldCssClass\"><![CDATA[aui-w25]]></entry>\n			<entry name=\"label\"><![CDATA[Legal Reviewer]]></entry>\n			<entry name=\"predefinedValue\"><![CDATA[]]></entry>\n			<entry name=\"readOnly\"><![CDATA[false]]></entry>\n			<entry name=\"required\"><![CDATA[false]]></entry>\n			<entry name=\"showLabel\"><![CDATA[true]]></entry>\n			<entry name=\"tip\"><![CDATA[]]></entry>\n			<entry name=\"width\"><![CDATA[25]]></entry>\n		</meta-data>\n	</dynamic-element>\n	<dynamic-element dataType=\"string\" name=\"text17700\" type=\"text\">\n		<meta-data locale=\"en_US\">\n			<entry name=\"fieldCssClass\"><![CDATA[aui-w25]]></entry>\n			<entry name=\"label\"><![CDATA[Signing Authority]]></entry>\n			<entry name=\"predefinedValue\"><![CDATA[]]></entry>\n			<entry name=\"readOnly\"><![CDATA[false]]></entry>\n			<entry name=\"required\"><![CDATA[false]]></entry>\n			<entry name=\"showLabel\"><![CDATA[true]]></entry>\n			<entry name=\"tip\"><![CDATA[]]></entry>\n			<entry name=\"width\"><![CDATA[25]]></entry>\n		</meta-data>\n	</dynamic-element>\n	<dynamic-element dataType=\"string\" name=\"text2087\" type=\"text\">\n		<meta-data locale=\"en_US\">\n			<entry name=\"fieldCssClass\"><![CDATA[aui-w25]]></entry>\n			<entry name=\"label\"><![CDATA[Deal Name]]></entry>\n			<entry name=\"predefinedValue\"><![CDATA[]]></entry>\n			<entry name=\"readOnly\"><![CDATA[false]]></entry>\n			<entry name=\"required\"><![CDATA[false]]></entry>\n			<entry name=\"showLabel\"><![CDATA[true]]></entry>\n			<entry name=\"tip\"><![CDATA[]]></entry>\n			<entry name=\"width\"><![CDATA[25]]></entry>\n		</meta-data>\n	</dynamic-element>\n</root>','xml',1),('f714e9a4-3be6-469b-85a2-0d5b56432846',10303,10192,10154,10158,'','2014-03-18 17:33:39','2014-03-18 17:33:39',10089,'auto_10302','<?xml version=\'1.0\' encoding=\'UTF-8\'?><root available-locales=\"en_US\" default-locale=\"en_US\"><Name language-id=\"en_US\">Marketing Banner</Name></root>','<?xml version=\'1.0\' encoding=\'UTF-8\'?><root available-locales=\"en_US\" default-locale=\"en_US\"><Description language-id=\"en_US\">Marketing Banner</Description></root>','<?xml version=\"1.0\"?>\n\n<root available-locales=\"en_US\" default-locale=\"en_US\">\n	<dynamic-element dataType=\"string\" name=\"radio5547\" type=\"radio\">\n		<dynamic-element name=\"yes\" type=\"option\" value=\"yes\">\n			<meta-data locale=\"en_US\">\n				<entry name=\"label\"><![CDATA[Yes]]></entry>\n			</meta-data>\n		</dynamic-element>\n		<dynamic-element name=\"no\" type=\"option\" value=\"no\">\n			<meta-data locale=\"en_US\">\n				<entry name=\"label\"><![CDATA[No]]></entry>\n			</meta-data>\n		</dynamic-element>\n		<meta-data locale=\"en_US\">\n			<entry name=\"displayChildLabelAsValue\"><![CDATA[true]]></entry>\n			<entry name=\"label\"><![CDATA[Needs Legal Review]]></entry>\n			<entry name=\"predefinedValue\"><![CDATA[]]></entry>\n			<entry name=\"readOnly\"><![CDATA[false]]></entry>\n			<entry name=\"required\"><![CDATA[false]]></entry>\n			<entry name=\"showLabel\"><![CDATA[true]]></entry>\n			<entry name=\"tip\"><![CDATA[]]></entry>\n		</meta-data>\n	</dynamic-element>\n	<dynamic-element dataType=\"string\" name=\"text2033\" type=\"text\">\n		<meta-data locale=\"en_US\">\n			<entry name=\"fieldCssClass\"><![CDATA[aui-w25]]></entry>\n			<entry name=\"label\"><![CDATA[Banner Name]]></entry>\n			<entry name=\"predefinedValue\"><![CDATA[]]></entry>\n			<entry name=\"readOnly\"><![CDATA[false]]></entry>\n			<entry name=\"required\"><![CDATA[false]]></entry>\n			<entry name=\"showLabel\"><![CDATA[true]]></entry>\n			<entry name=\"tip\"><![CDATA[]]></entry>\n			<entry name=\"width\"><![CDATA[25]]></entry>\n		</meta-data>\n	</dynamic-element>\n	<dynamic-element dataType=\"string\" name=\"textarea2873\" type=\"textarea\">\n		<meta-data locale=\"en_US\">\n			<entry name=\"fieldCssClass\"><![CDATA[aui-w25]]></entry>\n			<entry name=\"label\"><![CDATA[Description]]></entry>\n			<entry name=\"predefinedValue\"><![CDATA[]]></entry>\n			<entry name=\"readOnly\"><![CDATA[false]]></entry>\n			<entry name=\"required\"><![CDATA[false]]></entry>\n			<entry name=\"showLabel\"><![CDATA[true]]></entry>\n			<entry name=\"tip\"><![CDATA[]]></entry>\n			<entry name=\"width\"><![CDATA[25]]></entry>\n		</meta-data>\n	</dynamic-element>\n</root>','xml',1),('1c1525a3-b65f-4034-a913-a1440e0797e5',10305,10192,10154,10158,'','2014-03-18 17:33:39','2014-03-18 17:33:39',10089,'auto_10304','<?xml version=\'1.0\' encoding=\'UTF-8\'?><root available-locales=\"en_US\" default-locale=\"en_US\"><Name language-id=\"en_US\">Online Training</Name></root>','<?xml version=\'1.0\' encoding=\'UTF-8\'?><root available-locales=\"en_US\" default-locale=\"en_US\"><Description language-id=\"en_US\">Online Training</Description></root>','<?xml version=\"1.0\"?>\n\n<root available-locales=\"en_US\" default-locale=\"en_US\">\n	<dynamic-element dataType=\"string\" name=\"text2082\" type=\"text\">\n		<meta-data locale=\"en_US\">\n			<entry name=\"fieldCssClass\"><![CDATA[aui-w25]]></entry>\n			<entry name=\"label\"><![CDATA[Lesson Title]]></entry>\n			<entry name=\"predefinedValue\"><![CDATA[]]></entry>\n			<entry name=\"readOnly\"><![CDATA[false]]></entry>\n			<entry name=\"required\"><![CDATA[false]]></entry>\n			<entry name=\"showLabel\"><![CDATA[true]]></entry>\n			<entry name=\"tip\"><![CDATA[]]></entry>\n			<entry name=\"width\"><![CDATA[25]]></entry>\n		</meta-data>\n	</dynamic-element>\n	<dynamic-element dataType=\"string\" name=\"text2979\" type=\"text\">\n		<meta-data locale=\"en_US\">\n			<entry name=\"fieldCssClass\"><![CDATA[aui-w25]]></entry>\n			<entry name=\"label\"><![CDATA[Author]]></entry>\n			<entry name=\"predefinedValue\"><![CDATA[]]></entry>\n			<entry name=\"readOnly\"><![CDATA[false]]></entry>\n			<entry name=\"required\"><![CDATA[false]]></entry>\n			<entry name=\"showLabel\"><![CDATA[true]]></entry>\n			<entry name=\"tip\"><![CDATA[]]></entry>\n			<entry name=\"width\"><![CDATA[25]]></entry>\n		</meta-data>\n	</dynamic-element>\n</root>','xml',1),('1e860afe-bc9f-4a3d-b654-1e12abdb027e',10307,10192,10154,10158,'','2014-03-18 17:33:39','2014-03-18 17:33:39',10089,'auto_10306','<?xml version=\'1.0\' encoding=\'UTF-8\'?><root available-locales=\"en_US\" default-locale=\"en_US\"><Name language-id=\"en_US\">Sales Presentation</Name></root>','<?xml version=\'1.0\' encoding=\'UTF-8\'?><root available-locales=\"en_US\" default-locale=\"en_US\"><Description language-id=\"en_US\">Sales Presentation</Description></root>','<?xml version=\"1.0\"?>\n\n<root available-locales=\"en_US\" default-locale=\"en_US\">\n	<dynamic-element dataType=\"string\" name=\"select2890\" type=\"select\">\n		<dynamic-element name=\"home_edition\" type=\"option\" value=\"HE\">\n			<meta-data locale=\"en_US\">\n				<entry name=\"label\"><![CDATA[Home Edition]]></entry>\n				<entry name=\"multiple\"><![CDATA[false]]></entry>\n			</meta-data>\n		</dynamic-element>\n		<dynamic-element name=\"business_edition\" type=\"option\" value=\"BE\">\n			<meta-data locale=\"en_US\">\n				<entry name=\"label\"><![CDATA[Business Edition]]></entry>\n			</meta-data>\n		</dynamic-element>\n		<dynamic-element name=\"enterprise_edition\" type=\"option\" value=\"EE\">\n			<meta-data locale=\"en_US\">\n				<entry name=\"label\"><![CDATA[Enterprise Edition]]></entry>\n			</meta-data>\n		</dynamic-element>\n		<meta-data locale=\"en_US\">\n			<entry name=\"displayChildLabelAsValue\"><![CDATA[true]]></entry>\n			<entry name=\"label\"><![CDATA[Product]]></entry>\n			<entry name=\"multiple\"><![CDATA[false]]></entry>\n			<entry name=\"predefinedValue\"><![CDATA[]]></entry>\n			<entry name=\"readOnly\"><![CDATA[false]]></entry>\n			<entry name=\"required\"><![CDATA[false]]></entry>\n			<entry name=\"showLabel\"><![CDATA[true]]></entry>\n			<entry name=\"tip\"><![CDATA[]]></entry>\n		</meta-data>\n	</dynamic-element>\n	<dynamic-element dataType=\"string\" name=\"select3864\" type=\"select\">\n		<dynamic-element name=\"1_0\" type=\"option\" value=\"1\">\n			<meta-data locale=\"en_US\">\n				<entry name=\"label\"><![CDATA[1.0]]></entry>\n				<entry name=\"multiple\"><![CDATA[false]]></entry>\n			</meta-data>\n		</dynamic-element>\n		<dynamic-element name=\"2_0\" type=\"option\" value=\"2\">\n			<meta-data locale=\"en_US\">\n				<entry name=\"label\"><![CDATA[2.0]]></entry>\n			</meta-data>\n		</dynamic-element>\n		<dynamic-element name=\"3_0\" type=\"option\" value=\"3\">\n			<meta-data locale=\"en_US\">\n				<entry name=\"label\"><![CDATA[3.0]]></entry>\n			</meta-data>\n		</dynamic-element>\n		<meta-data locale=\"en_US\">\n			<entry name=\"displayChildLabelAsValue\"><![CDATA[true]]></entry>\n			<entry name=\"label\"><![CDATA[Version]]></entry>\n			<entry name=\"multiple\"><![CDATA[false]]></entry>\n			<entry name=\"predefinedValue\"><![CDATA[]]></entry>\n			<entry name=\"readOnly\"><![CDATA[false]]></entry>\n			<entry name=\"required\"><![CDATA[false]]></entry>\n			<entry name=\"showLabel\"><![CDATA[true]]></entry>\n			<entry name=\"tip\"><![CDATA[]]></entry>\n		</meta-data>\n	</dynamic-element>\n	<dynamic-element dataType=\"string\" name=\"select4831\" type=\"select\">\n		<dynamic-element name=\"website\" type=\"option\" value=\"website\">\n			<meta-data locale=\"en_US\">\n				<entry name=\"label\"><![CDATA[Website]]></entry>\n				<entry name=\"multiple\"><![CDATA[false]]></entry>\n			</meta-data>\n		</dynamic-element>\n		<dynamic-element name=\"collaboration\" type=\"option\" value=\"collaboration\">\n			<meta-data locale=\"en_US\">\n				<entry name=\"label\"><![CDATA[Collaboration]]></entry>\n			</meta-data>\n		</dynamic-element>\n		<dynamic-element name=\"intranet\" type=\"option\" value=\"intranet\">\n			<meta-data locale=\"en_US\">\n				<entry name=\"label\"><![CDATA[Intranet]]></entry>\n			</meta-data>\n		</dynamic-element>\n		<meta-data locale=\"en_US\">\n			<entry name=\"displayChildLabelAsValue\"><![CDATA[true]]></entry>\n			<entry name=\"label\"><![CDATA[Areas of Interest]]></entry>\n			<entry name=\"multiple\"><![CDATA[true]]></entry>\n			<entry name=\"predefinedValue\"><![CDATA[]]></entry>\n			<entry name=\"readOnly\"><![CDATA[false]]></entry>\n			<entry name=\"required\"><![CDATA[false]]></entry>\n			<entry name=\"showLabel\"><![CDATA[true]]></entry>\n			<entry name=\"tip\"><![CDATA[]]></entry>\n		</meta-data>\n	</dynamic-element>\n	<dynamic-element dataType=\"string\" name=\"select5929\" type=\"select\">\n		<dynamic-element name=\"acme\" type=\"option\" value=\"acme\">\n			<meta-data locale=\"en_US\">\n				<entry name=\"label\"><![CDATA[ACME]]></entry>\n				<entry name=\"multiple\"><![CDATA[false]]></entry>\n			</meta-data>\n		</dynamic-element>\n		<dynamic-element name=\"sevencogs\" type=\"option\" value=\"sevencogs\">\n			<meta-data locale=\"en_US\">\n				<entry name=\"label\"><![CDATA[SevenCogs]]></entry>\n			</meta-data>\n		</dynamic-element>\n		<dynamic-element name=\"freeplus\" type=\"option\" value=\"freeplus\">\n			<meta-data locale=\"en_US\">\n				<entry name=\"label\"><![CDATA[FreePlus]]></entry>\n			</meta-data>\n		</dynamic-element>\n		<meta-data locale=\"en_US\">\n			<entry name=\"displayChildLabelAsValue\"><![CDATA[true]]></entry>\n			<entry name=\"label\"><![CDATA[Competitors]]></entry>\n			<entry name=\"multiple\"><![CDATA[true]]></entry>\n			<entry name=\"predefinedValue\"><![CDATA[]]></entry>\n			<entry name=\"readOnly\"><![CDATA[false]]></entry>\n			<entry name=\"required\"><![CDATA[false]]></entry>\n			<entry name=\"showLabel\"><![CDATA[true]]></entry>\n			<entry name=\"tip\"><![CDATA[]]></entry>\n		</meta-data>\n	</dynamic-element>\n	<dynamic-element dataType=\"string\" name=\"text1993\" type=\"text\">\n		<meta-data locale=\"en_US\">\n			<entry name=\"fieldCssClass\"><![CDATA[aui-w25]]></entry>\n			<entry name=\"label\"><![CDATA[Prospect Name]]></entry>\n			<entry name=\"predefinedValue\"><![CDATA[]]></entry>\n			<entry name=\"readOnly\"><![CDATA[false]]></entry>\n			<entry name=\"required\"><![CDATA[false]]></entry>\n			<entry name=\"showLabel\"><![CDATA[true]]></entry>\n			<entry name=\"tip\"><![CDATA[]]></entry>\n			<entry name=\"width\"><![CDATA[25]]></entry>\n		</meta-data>\n	</dynamic-element>\n</root>','xml',1),('9eef8afc-2185-4607-b15c-9cca3c3ac8b1',10308,10192,10154,10158,'','2014-03-18 17:33:39','2014-03-18 17:33:39',10010,'TikaRawMetadata','<?xml version=\'1.0\' encoding=\'UTF-8\'?><root available-locales=\"en_US\" default-locale=\"en_US\"><Name language-id=\"en_US\">TikaRawMetadata</Name></root>','<?xml version=\'1.0\' encoding=\'UTF-8\'?><root available-locales=\"en_US\" default-locale=\"en_US\"><Description language-id=\"en_US\">TikaRawMetadata</Description></root>','<root available-locales=\"en_US\" default-locale=\"en_US\"><dynamic-element dataType=\"string\" name=\"ClimateForcast_PROGRAM_ID\" type=\"text\"><meta-data locale=\"en_US\"><entry name=\"label\"><![CDATA[metadata.ClimateForcast.PROGRAM_ID]]></entry><entry name=\"predefinedValue\"><![CDATA[]]></entry><entry name=\"required\"><![CDATA[false]]></entry><entry name=\"showLabel\"><![CDATA[true]]></entry></meta-data></dynamic-element><dynamic-element dataType=\"string\" name=\"ClimateForcast_COMMAND_LINE\" type=\"text\"><meta-data locale=\"en_US\"><entry name=\"label\"><![CDATA[metadata.ClimateForcast.COMMAND_LINE]]></entry><entry name=\"predefinedValue\"><![CDATA[]]></entry><entry name=\"required\"><![CDATA[false]]></entry><entry name=\"showLabel\"><![CDATA[true]]></entry></meta-data></dynamic-element><dynamic-element dataType=\"string\" name=\"ClimateForcast_HISTORY\" type=\"text\"><meta-data locale=\"en_US\"><entry name=\"label\"><![CDATA[metadata.ClimateForcast.HISTORY]]></entry><entry name=\"predefinedValue\"><![CDATA[]]></entry><entry name=\"required\"><![CDATA[false]]></entry><entry name=\"showLabel\"><![CDATA[true]]></entry></meta-data></dynamic-element><dynamic-element dataType=\"string\" name=\"ClimateForcast_TABLE_ID\" type=\"text\"><meta-data locale=\"en_US\"><entry name=\"label\"><![CDATA[metadata.ClimateForcast.TABLE_ID]]></entry><entry name=\"predefinedValue\"><![CDATA[]]></entry><entry name=\"required\"><![CDATA[false]]></entry><entry name=\"showLabel\"><![CDATA[true]]></entry></meta-data></dynamic-element><dynamic-element dataType=\"string\" name=\"ClimateForcast_INSTITUTION\" type=\"text\"><meta-data locale=\"en_US\"><entry name=\"label\"><![CDATA[metadata.ClimateForcast.INSTITUTION]]></entry><entry name=\"predefinedValue\"><![CDATA[]]></entry><entry name=\"required\"><![CDATA[false]]></entry><entry name=\"showLabel\"><![CDATA[true]]></entry></meta-data></dynamic-element><dynamic-element dataType=\"string\" name=\"ClimateForcast_SOURCE\" type=\"text\"><meta-data locale=\"en_US\"><entry name=\"label\"><![CDATA[metadata.ClimateForcast.SOURCE]]></entry><entry name=\"predefinedValue\"><![CDATA[]]></entry><entry name=\"required\"><![CDATA[false]]></entry><entry name=\"showLabel\"><![CDATA[true]]></entry></meta-data></dynamic-element><dynamic-element dataType=\"string\" name=\"ClimateForcast_CONTACT\" type=\"text\"><meta-data locale=\"en_US\"><entry name=\"label\"><![CDATA[metadata.ClimateForcast.CONTACT]]></entry><entry name=\"predefinedValue\"><![CDATA[]]></entry><entry name=\"required\"><![CDATA[false]]></entry><entry name=\"showLabel\"><![CDATA[true]]></entry></meta-data></dynamic-element><dynamic-element dataType=\"string\" name=\"ClimateForcast_PROJECT_ID\" type=\"text\"><meta-data locale=\"en_US\"><entry name=\"label\"><![CDATA[metadata.ClimateForcast.PROJECT_ID]]></entry><entry name=\"predefinedValue\"><![CDATA[]]></entry><entry name=\"required\"><![CDATA[false]]></entry><entry name=\"showLabel\"><![CDATA[true]]></entry></meta-data></dynamic-element><dynamic-element dataType=\"string\" name=\"ClimateForcast_CONVENTIONS\" type=\"text\"><meta-data locale=\"en_US\"><entry name=\"label\"><![CDATA[metadata.ClimateForcast.CONVENTIONS]]></entry><entry name=\"predefinedValue\"><![CDATA[]]></entry><entry name=\"required\"><![CDATA[false]]></entry><entry name=\"showLabel\"><![CDATA[true]]></entry></meta-data></dynamic-element><dynamic-element dataType=\"string\" name=\"ClimateForcast_REFERENCES\" type=\"text\"><meta-data locale=\"en_US\"><entry name=\"label\"><![CDATA[metadata.ClimateForcast.REFERENCES]]></entry><entry name=\"predefinedValue\"><![CDATA[]]></entry><entry name=\"required\"><![CDATA[false]]></entry><entry name=\"showLabel\"><![CDATA[true]]></entry></meta-data></dynamic-element><dynamic-element dataType=\"string\" name=\"ClimateForcast_ACKNOWLEDGEMENT\" type=\"text\"><meta-data locale=\"en_US\"><entry name=\"label\"><![CDATA[metadata.ClimateForcast.ACKNOWLEDGEMENT]]></entry><entry name=\"predefinedValue\"><![CDATA[]]></entry><entry name=\"required\"><![CDATA[false]]></entry><entry name=\"showLabel\"><![CDATA[true]]></entry></meta-data></dynamic-element><dynamic-element dataType=\"string\" name=\"ClimateForcast_REALIZATION\" type=\"text\"><meta-data locale=\"en_US\"><entry name=\"label\"><![CDATA[metadata.ClimateForcast.REALIZATION]]></entry><entry name=\"predefinedValue\"><![CDATA[]]></entry><entry name=\"required\"><![CDATA[false]]></entry><entry name=\"showLabel\"><![CDATA[true]]></entry></meta-data></dynamic-element><dynamic-element dataType=\"string\" name=\"ClimateForcast_EXPERIMENT_ID\" type=\"text\"><meta-data locale=\"en_US\"><entry name=\"label\"><![CDATA[metadata.ClimateForcast.EXPERIMENT_ID]]></entry><entry name=\"predefinedValue\"><![CDATA[]]></entry><entry name=\"required\"><![CDATA[false]]></entry><entry name=\"showLabel\"><![CDATA[true]]></entry></meta-data></dynamic-element><dynamic-element dataType=\"string\" name=\"ClimateForcast_COMMENT\" type=\"text\"><meta-data locale=\"en_US\"><entry name=\"label\"><![CDATA[metadata.ClimateForcast.COMMENT]]></entry><entry name=\"predefinedValue\"><![CDATA[]]></entry><entry name=\"required\"><![CDATA[false]]></entry><entry name=\"showLabel\"><![CDATA[true]]></entry></meta-data></dynamic-element><dynamic-element dataType=\"string\" name=\"ClimateForcast_MODEL_NAME_ENGLISH\" type=\"text\"><meta-data locale=\"en_US\"><entry name=\"label\"><![CDATA[metadata.ClimateForcast.MODEL_NAME_ENGLISH]]></entry><entry name=\"predefinedValue\"><![CDATA[]]></entry><entry name=\"required\"><![CDATA[false]]></entry><entry name=\"showLabel\"><![CDATA[true]]></entry></meta-data></dynamic-element><dynamic-element dataType=\"string\" name=\"CreativeCommons_LICENSE_URL\" type=\"text\"><meta-data locale=\"en_US\"><entry name=\"label\"><![CDATA[metadata.CreativeCommons.LICENSE_URL]]></entry><entry name=\"predefinedValue\"><![CDATA[]]></entry><entry name=\"required\"><![CDATA[false]]></entry><entry name=\"showLabel\"><![CDATA[true]]></entry></meta-data></dynamic-element><dynamic-element dataType=\"string\" name=\"CreativeCommons_LICENSE_LOCATION\" type=\"text\"><meta-data locale=\"en_US\"><entry name=\"label\"><![CDATA[metadata.CreativeCommons.LICENSE_LOCATION]]></entry><entry name=\"predefinedValue\"><![CDATA[]]></entry><entry name=\"required\"><![CDATA[false]]></entry><entry name=\"showLabel\"><![CDATA[true]]></entry></meta-data></dynamic-element><dynamic-element dataType=\"string\" name=\"CreativeCommons_WORK_TYPE\" type=\"text\"><meta-data locale=\"en_US\"><entry name=\"label\"><![CDATA[metadata.CreativeCommons.WORK_TYPE]]></entry><entry name=\"predefinedValue\"><![CDATA[]]></entry><entry name=\"required\"><![CDATA[false]]></entry><entry name=\"showLabel\"><![CDATA[true]]></entry></meta-data></dynamic-element><dynamic-element dataType=\"string\" name=\"DublinCore_FORMAT\" type=\"text\"><meta-data locale=\"en_US\"><entry name=\"label\"><![CDATA[metadata.DublinCore.FORMAT]]></entry><entry name=\"predefinedValue\"><![CDATA[]]></entry><entry name=\"required\"><![CDATA[false]]></entry><entry name=\"showLabel\"><![CDATA[true]]></entry></meta-data></dynamic-element><dynamic-element dataType=\"string\" name=\"DublinCore_IDENTIFIER\" type=\"text\"><meta-data locale=\"en_US\"><entry name=\"label\"><![CDATA[metadata.DublinCore.IDENTIFIER]]></entry><entry name=\"predefinedValue\"><![CDATA[]]></entry><entry name=\"required\"><![CDATA[false]]></entry><entry name=\"showLabel\"><![CDATA[true]]></entry></meta-data></dynamic-element><dynamic-element dataType=\"string\" name=\"DublinCore_MODIFIED\" type=\"text\"><meta-data locale=\"en_US\"><entry name=\"label\"><![CDATA[metadata.DublinCore.MODIFIED]]></entry><entry name=\"predefinedValue\"><![CDATA[]]></entry><entry name=\"required\"><![CDATA[false]]></entry><entry name=\"showLabel\"><![CDATA[true]]></entry></meta-data></dynamic-element><dynamic-element dataType=\"string\" name=\"DublinCore_CONTRIBUTOR\" type=\"text\"><meta-data locale=\"en_US\"><entry name=\"label\"><![CDATA[metadata.DublinCore.CONTRIBUTOR]]></entry><entry name=\"predefinedValue\"><![CDATA[]]></entry><entry name=\"required\"><![CDATA[false]]></entry><entry name=\"showLabel\"><![CDATA[true]]></entry></meta-data></dynamic-element><dynamic-element dataType=\"string\" name=\"DublinCore_COVERAGE\" type=\"text\"><meta-data locale=\"en_US\"><entry name=\"label\"><![CDATA[metadata.DublinCore.COVERAGE]]></entry><entry name=\"predefinedValue\"><![CDATA[]]></entry><entry name=\"required\"><![CDATA[false]]></entry><entry name=\"showLabel\"><![CDATA[true]]></entry></meta-data></dynamic-element><dynamic-element dataType=\"string\" name=\"DublinCore_CREATOR\" type=\"text\"><meta-data locale=\"en_US\"><entry name=\"label\"><![CDATA[metadata.DublinCore.CREATOR]]></entry><entry name=\"predefinedValue\"><![CDATA[]]></entry><entry name=\"required\"><![CDATA[false]]></entry><entry name=\"showLabel\"><![CDATA[true]]></entry></meta-data></dynamic-element><dynamic-element dataType=\"string\" name=\"DublinCore_DATE\" type=\"text\"><meta-data locale=\"en_US\"><entry name=\"label\"><![CDATA[metadata.DublinCore.DATE]]></entry><entry name=\"predefinedValue\"><![CDATA[]]></entry><entry name=\"required\"><![CDATA[false]]></entry><entry name=\"showLabel\"><![CDATA[true]]></entry></meta-data></dynamic-element><dynamic-element dataType=\"string\" name=\"DublinCore_DESCRIPTION\" type=\"text\"><meta-data locale=\"en_US\"><entry name=\"label\"><![CDATA[metadata.DublinCore.DESCRIPTION]]></entry><entry name=\"predefinedValue\"><![CDATA[]]></entry><entry name=\"required\"><![CDATA[false]]></entry><entry name=\"showLabel\"><![CDATA[true]]></entry></meta-data></dynamic-element><dynamic-element dataType=\"string\" name=\"DublinCore_LANGUAGE\" type=\"text\"><meta-data locale=\"en_US\"><entry name=\"label\"><![CDATA[metadata.DublinCore.LANGUAGE]]></entry><entry name=\"predefinedValue\"><![CDATA[]]></entry><entry name=\"required\"><![CDATA[false]]></entry><entry name=\"showLabel\"><![CDATA[true]]></entry></meta-data></dynamic-element><dynamic-element dataType=\"string\" name=\"DublinCore_PUBLISHER\" type=\"text\"><meta-data locale=\"en_US\"><entry name=\"label\"><![CDATA[metadata.DublinCore.PUBLISHER]]></entry><entry name=\"predefinedValue\"><![CDATA[]]></entry><entry name=\"required\"><![CDATA[false]]></entry><entry name=\"showLabel\"><![CDATA[true]]></entry></meta-data></dynamic-element><dynamic-element dataType=\"string\" name=\"DublinCore_RELATION\" type=\"text\"><meta-data locale=\"en_US\"><entry name=\"label\"><![CDATA[metadata.DublinCore.RELATION]]></entry><entry name=\"predefinedValue\"><![CDATA[]]></entry><entry name=\"required\"><![CDATA[false]]></entry><entry name=\"showLabel\"><![CDATA[true]]></entry></meta-data></dynamic-element><dynamic-element dataType=\"string\" name=\"DublinCore_RIGHTS\" type=\"text\"><meta-data locale=\"en_US\"><entry name=\"label\"><![CDATA[metadata.DublinCore.RIGHTS]]></entry><entry name=\"predefinedValue\"><![CDATA[]]></entry><entry name=\"required\"><![CDATA[false]]></entry><entry name=\"showLabel\"><![CDATA[true]]></entry></meta-data></dynamic-element><dynamic-element dataType=\"string\" name=\"DublinCore_SOURCE\" type=\"text\"><meta-data locale=\"en_US\"><entry name=\"label\"><![CDATA[metadata.DublinCore.SOURCE]]></entry><entry name=\"predefinedValue\"><![CDATA[]]></entry><entry name=\"required\"><![CDATA[false]]></entry><entry name=\"showLabel\"><![CDATA[true]]></entry></meta-data></dynamic-element><dynamic-element dataType=\"string\" name=\"DublinCore_SUBJECT\" type=\"text\"><meta-data locale=\"en_US\"><entry name=\"label\"><![CDATA[metadata.DublinCore.SUBJECT]]></entry><entry name=\"predefinedValue\"><![CDATA[]]></entry><entry name=\"required\"><![CDATA[false]]></entry><entry name=\"showLabel\"><![CDATA[true]]></entry></meta-data></dynamic-element><dynamic-element dataType=\"string\" name=\"DublinCore_TITLE\" type=\"text\"><meta-data locale=\"en_US\"><entry name=\"label\"><![CDATA[metadata.DublinCore.TITLE]]></entry><entry name=\"predefinedValue\"><![CDATA[]]></entry><entry name=\"required\"><![CDATA[false]]></entry><entry name=\"showLabel\"><![CDATA[true]]></entry></meta-data></dynamic-element><dynamic-element dataType=\"string\" name=\"DublinCore_TYPE\" type=\"text\"><meta-data locale=\"en_US\"><entry name=\"label\"><![CDATA[metadata.DublinCore.TYPE]]></entry><entry name=\"predefinedValue\"><![CDATA[]]></entry><entry name=\"required\"><![CDATA[false]]></entry><entry name=\"showLabel\"><![CDATA[true]]></entry></meta-data></dynamic-element><dynamic-element dataType=\"string\" name=\"Geographic_LATITUDE\" type=\"text\"><meta-data locale=\"en_US\"><entry name=\"label\"><![CDATA[metadata.Geographic.LATITUDE]]></entry><entry name=\"predefinedValue\"><![CDATA[]]></entry><entry name=\"required\"><![CDATA[false]]></entry><entry name=\"showLabel\"><![CDATA[true]]></entry></meta-data></dynamic-element><dynamic-element dataType=\"string\" name=\"Geographic_LONGITUDE\" type=\"text\"><meta-data locale=\"en_US\"><entry name=\"label\"><![CDATA[metadata.Geographic.LONGITUDE]]></entry><entry name=\"predefinedValue\"><![CDATA[]]></entry><entry name=\"required\"><![CDATA[false]]></entry><entry name=\"showLabel\"><![CDATA[true]]></entry></meta-data></dynamic-element><dynamic-element dataType=\"string\" name=\"Geographic_ALTITUDE\" type=\"text\"><meta-data locale=\"en_US\"><entry name=\"label\"><![CDATA[metadata.Geographic.ALTITUDE]]></entry><entry name=\"predefinedValue\"><![CDATA[]]></entry><entry name=\"required\"><![CDATA[false]]></entry><entry name=\"showLabel\"><![CDATA[true]]></entry></meta-data></dynamic-element><dynamic-element dataType=\"string\" name=\"HttpHeaders_CONTENT_ENCODING\" type=\"text\"><meta-data locale=\"en_US\"><entry name=\"label\"><![CDATA[metadata.HttpHeaders.CONTENT_ENCODING]]></entry><entry name=\"predefinedValue\"><![CDATA[]]></entry><entry name=\"required\"><![CDATA[false]]></entry><entry name=\"showLabel\"><![CDATA[true]]></entry></meta-data></dynamic-element><dynamic-element dataType=\"string\" name=\"HttpHeaders_CONTENT_LANGUAGE\" type=\"text\"><meta-data locale=\"en_US\"><entry name=\"label\"><![CDATA[metadata.HttpHeaders.CONTENT_LANGUAGE]]></entry><entry name=\"predefinedValue\"><![CDATA[]]></entry><entry name=\"required\"><![CDATA[false]]></entry><entry name=\"showLabel\"><![CDATA[true]]></entry></meta-data></dynamic-element><dynamic-element dataType=\"string\" name=\"HttpHeaders_CONTENT_LENGTH\" type=\"text\"><meta-data locale=\"en_US\"><entry name=\"label\"><![CDATA[metadata.HttpHeaders.CONTENT_LENGTH]]></entry><entry name=\"predefinedValue\"><![CDATA[]]></entry><entry name=\"required\"><![CDATA[false]]></entry><entry name=\"showLabel\"><![CDATA[true]]></entry></meta-data></dynamic-element><dynamic-element dataType=\"string\" name=\"HttpHeaders_CONTENT_LOCATION\" type=\"text\"><meta-data locale=\"en_US\"><entry name=\"label\"><![CDATA[metadata.HttpHeaders.CONTENT_LOCATION]]></entry><entry name=\"predefinedValue\"><![CDATA[]]></entry><entry name=\"required\"><![CDATA[false]]></entry><entry name=\"showLabel\"><![CDATA[true]]></entry></meta-data></dynamic-element><dynamic-element dataType=\"string\" name=\"HttpHeaders_CONTENT_DISPOSITION\" type=\"text\"><meta-data locale=\"en_US\"><entry name=\"label\"><![CDATA[metadata.HttpHeaders.CONTENT_DISPOSITION]]></entry><entry name=\"predefinedValue\"><![CDATA[]]></entry><entry name=\"required\"><![CDATA[false]]></entry><entry name=\"showLabel\"><![CDATA[true]]></entry></meta-data></dynamic-element><dynamic-element dataType=\"string\" name=\"HttpHeaders_CONTENT_MD5\" type=\"text\"><meta-data locale=\"en_US\"><entry name=\"label\"><![CDATA[metadata.HttpHeaders.CONTENT_MD5]]></entry><entry name=\"predefinedValue\"><![CDATA[]]></entry><entry name=\"required\"><![CDATA[false]]></entry><entry name=\"showLabel\"><![CDATA[true]]></entry></meta-data></dynamic-element><dynamic-element dataType=\"string\" name=\"HttpHeaders_CONTENT_TYPE\" type=\"text\"><meta-data locale=\"en_US\"><entry name=\"label\"><![CDATA[metadata.HttpHeaders.CONTENT_TYPE]]></entry><entry name=\"predefinedValue\"><![CDATA[]]></entry><entry name=\"required\"><![CDATA[false]]></entry><entry name=\"showLabel\"><![CDATA[true]]></entry></meta-data></dynamic-element><dynamic-element dataType=\"string\" name=\"HttpHeaders_LAST_MODIFIED\" type=\"text\"><meta-data locale=\"en_US\"><entry name=\"label\"><![CDATA[metadata.HttpHeaders.LAST_MODIFIED]]></entry><entry name=\"predefinedValue\"><![CDATA[]]></entry><entry name=\"required\"><![CDATA[false]]></entry><entry name=\"showLabel\"><![CDATA[true]]></entry></meta-data></dynamic-element><dynamic-element dataType=\"string\" name=\"HttpHeaders_LOCATION\" type=\"text\"><meta-data locale=\"en_US\"><entry name=\"label\"><![CDATA[metadata.HttpHeaders.LOCATION]]></entry><entry name=\"predefinedValue\"><![CDATA[]]></entry><entry name=\"required\"><![CDATA[false]]></entry><entry name=\"showLabel\"><![CDATA[true]]></entry></meta-data></dynamic-element><dynamic-element dataType=\"string\" name=\"Message_MESSAGE_RECIPIENT_ADDRESS\" type=\"text\"><meta-data locale=\"en_US\"><entry name=\"label\"><![CDATA[metadata.Message.MESSAGE_RECIPIENT_ADDRESS]]></entry><entry name=\"predefinedValue\"><![CDATA[]]></entry><entry name=\"required\"><![CDATA[false]]></entry><entry name=\"showLabel\"><![CDATA[true]]></entry></meta-data></dynamic-element><dynamic-element dataType=\"string\" name=\"Message_MESSAGE_FROM\" type=\"text\"><meta-data locale=\"en_US\"><entry name=\"label\"><![CDATA[metadata.Message.MESSAGE_FROM]]></entry><entry name=\"predefinedValue\"><![CDATA[]]></entry><entry name=\"required\"><![CDATA[false]]></entry><entry name=\"showLabel\"><![CDATA[true]]></entry></meta-data></dynamic-element><dynamic-element dataType=\"string\" name=\"Message_MESSAGE_TO\" type=\"text\"><meta-data locale=\"en_US\"><entry name=\"label\"><![CDATA[metadata.Message.MESSAGE_TO]]></entry><entry name=\"predefinedValue\"><![CDATA[]]></entry><entry name=\"required\"><![CDATA[false]]></entry><entry name=\"showLabel\"><![CDATA[true]]></entry></meta-data></dynamic-element><dynamic-element dataType=\"string\" name=\"Message_MESSAGE_CC\" type=\"text\"><meta-data locale=\"en_US\"><entry name=\"label\"><![CDATA[metadata.Message.MESSAGE_CC]]></entry><entry name=\"predefinedValue\"><![CDATA[]]></entry><entry name=\"required\"><![CDATA[false]]></entry><entry name=\"showLabel\"><![CDATA[true]]></entry></meta-data></dynamic-element><dynamic-element dataType=\"string\" name=\"Message_MESSAGE_BCC\" type=\"text\"><meta-data locale=\"en_US\"><entry name=\"label\"><![CDATA[metadata.Message.MESSAGE_BCC]]></entry><entry name=\"predefinedValue\"><![CDATA[]]></entry><entry name=\"required\"><![CDATA[false]]></entry><entry name=\"showLabel\"><![CDATA[true]]></entry></meta-data></dynamic-element><dynamic-element dataType=\"string\" name=\"MSOffice_KEYWORDS\" type=\"text\"><meta-data locale=\"en_US\"><entry name=\"label\"><![CDATA[metadata.MSOffice.KEYWORDS]]></entry><entry name=\"predefinedValue\"><![CDATA[]]></entry><entry name=\"required\"><![CDATA[false]]></entry><entry name=\"showLabel\"><![CDATA[true]]></entry></meta-data></dynamic-element><dynamic-element dataType=\"string\" name=\"MSOffice_COMMENTS\" type=\"text\"><meta-data locale=\"en_US\"><entry name=\"label\"><![CDATA[metadata.MSOffice.COMMENTS]]></entry><entry name=\"predefinedValue\"><![CDATA[]]></entry><entry name=\"required\"><![CDATA[false]]></entry><entry name=\"showLabel\"><![CDATA[true]]></entry></meta-data></dynamic-element><dynamic-element dataType=\"string\" name=\"MSOffice_LAST_AUTHOR\" type=\"text\"><meta-data locale=\"en_US\"><entry name=\"label\"><![CDATA[metadata.MSOffice.LAST_AUTHOR]]></entry><entry name=\"predefinedValue\"><![CDATA[]]></entry><entry name=\"required\"><![CDATA[false]]></entry><entry name=\"showLabel\"><![CDATA[true]]></entry></meta-data></dynamic-element><dynamic-element dataType=\"string\" name=\"MSOffice_APPLICATION_NAME\" type=\"text\"><meta-data locale=\"en_US\"><entry name=\"label\"><![CDATA[metadata.MSOffice.APPLICATION_NAME]]></entry><entry name=\"predefinedValue\"><![CDATA[]]></entry><entry name=\"required\"><![CDATA[false]]></entry><entry name=\"showLabel\"><![CDATA[true]]></entry></meta-data></dynamic-element><dynamic-element dataType=\"string\" name=\"MSOffice_CHARACTER_COUNT\" type=\"text\"><meta-data locale=\"en_US\"><entry name=\"label\"><![CDATA[metadata.MSOffice.CHARACTER_COUNT]]></entry><entry name=\"predefinedValue\"><![CDATA[]]></entry><entry name=\"required\"><![CDATA[false]]></entry><entry name=\"showLabel\"><![CDATA[true]]></entry></meta-data></dynamic-element><dynamic-element dataType=\"string\" name=\"MSOffice_LAST_PRINTED\" type=\"text\"><meta-data locale=\"en_US\"><entry name=\"label\"><![CDATA[metadata.MSOffice.LAST_PRINTED]]></entry><entry name=\"predefinedValue\"><![CDATA[]]></entry><entry name=\"required\"><![CDATA[false]]></entry><entry name=\"showLabel\"><![CDATA[true]]></entry></meta-data></dynamic-element><dynamic-element dataType=\"string\" name=\"MSOffice_LAST_SAVED\" type=\"text\"><meta-data locale=\"en_US\"><entry name=\"label\"><![CDATA[metadata.MSOffice.LAST_SAVED]]></entry><entry name=\"predefinedValue\"><![CDATA[]]></entry><entry name=\"required\"><![CDATA[false]]></entry><entry name=\"showLabel\"><![CDATA[true]]></entry></meta-data></dynamic-element><dynamic-element dataType=\"string\" name=\"MSOffice_PAGE_COUNT\" type=\"text\"><meta-data locale=\"en_US\"><entry name=\"label\"><![CDATA[metadata.MSOffice.PAGE_COUNT]]></entry><entry name=\"predefinedValue\"><![CDATA[]]></entry><entry name=\"required\"><![CDATA[false]]></entry><entry name=\"showLabel\"><![CDATA[true]]></entry></meta-data></dynamic-element><dynamic-element dataType=\"string\" name=\"MSOffice_REVISION_NUMBER\" type=\"text\"><meta-data locale=\"en_US\"><entry name=\"label\"><![CDATA[metadata.MSOffice.REVISION_NUMBER]]></entry><entry name=\"predefinedValue\"><![CDATA[]]></entry><entry name=\"required\"><![CDATA[false]]></entry><entry name=\"showLabel\"><![CDATA[true]]></entry></meta-data></dynamic-element><dynamic-element dataType=\"string\" name=\"MSOffice_WORD_COUNT\" type=\"text\"><meta-data locale=\"en_US\"><entry name=\"label\"><![CDATA[metadata.MSOffice.WORD_COUNT]]></entry><entry name=\"predefinedValue\"><![CDATA[]]></entry><entry name=\"required\"><![CDATA[false]]></entry><entry name=\"showLabel\"><![CDATA[true]]></entry></meta-data></dynamic-element><dynamic-element dataType=\"string\" name=\"MSOffice_TEMPLATE\" type=\"text\"><meta-data locale=\"en_US\"><entry name=\"label\"><![CDATA[metadata.MSOffice.TEMPLATE]]></entry><entry name=\"predefinedValue\"><![CDATA[]]></entry><entry name=\"required\"><![CDATA[false]]></entry><entry name=\"showLabel\"><![CDATA[true]]></entry></meta-data></dynamic-element><dynamic-element dataType=\"string\" name=\"MSOffice_AUTHOR\" type=\"text\"><meta-data locale=\"en_US\"><entry name=\"label\"><![CDATA[metadata.MSOffice.AUTHOR]]></entry><entry name=\"predefinedValue\"><![CDATA[]]></entry><entry name=\"required\"><![CDATA[false]]></entry><entry name=\"showLabel\"><![CDATA[true]]></entry></meta-data></dynamic-element><dynamic-element dataType=\"string\" name=\"MSOffice_TOTAL_TIME\" type=\"text\"><meta-data locale=\"en_US\"><entry name=\"label\"><![CDATA[metadata.MSOffice.TOTAL_TIME]]></entry><entry name=\"predefinedValue\"><![CDATA[]]></entry><entry name=\"required\"><![CDATA[false]]></entry><entry name=\"showLabel\"><![CDATA[true]]></entry></meta-data></dynamic-element><dynamic-element dataType=\"string\" name=\"MSOffice_SLIDE_COUNT\" type=\"text\"><meta-data locale=\"en_US\"><entry name=\"label\"><![CDATA[metadata.MSOffice.SLIDE_COUNT]]></entry><entry name=\"predefinedValue\"><![CDATA[]]></entry><entry name=\"required\"><![CDATA[false]]></entry><entry name=\"showLabel\"><![CDATA[true]]></entry></meta-data></dynamic-element><dynamic-element dataType=\"string\" name=\"MSOffice_PRESENTATION_FORMAT\" type=\"text\"><meta-data locale=\"en_US\"><entry name=\"label\"><![CDATA[metadata.MSOffice.PRESENTATION_FORMAT]]></entry><entry name=\"predefinedValue\"><![CDATA[]]></entry><entry name=\"required\"><![CDATA[false]]></entry><entry name=\"showLabel\"><![CDATA[true]]></entry></meta-data></dynamic-element><dynamic-element dataType=\"string\" name=\"MSOffice_PARAGRAPH_COUNT\" type=\"text\"><meta-data locale=\"en_US\"><entry name=\"label\"><![CDATA[metadata.MSOffice.PARAGRAPH_COUNT]]></entry><entry name=\"predefinedValue\"><![CDATA[]]></entry><entry name=\"required\"><![CDATA[false]]></entry><entry name=\"showLabel\"><![CDATA[true]]></entry></meta-data></dynamic-element><dynamic-element dataType=\"string\" name=\"MSOffice_NOTES\" type=\"text\"><meta-data locale=\"en_US\"><entry name=\"label\"><![CDATA[metadata.MSOffice.NOTES]]></entry><entry name=\"predefinedValue\"><![CDATA[]]></entry><entry name=\"required\"><![CDATA[false]]></entry><entry name=\"showLabel\"><![CDATA[true]]></entry></meta-data></dynamic-element><dynamic-element dataType=\"string\" name=\"MSOffice_MANAGER\" type=\"text\"><meta-data locale=\"en_US\"><entry name=\"label\"><![CDATA[metadata.MSOffice.MANAGER]]></entry><entry name=\"predefinedValue\"><![CDATA[]]></entry><entry name=\"required\"><![CDATA[false]]></entry><entry name=\"showLabel\"><![CDATA[true]]></entry></meta-data></dynamic-element><dynamic-element dataType=\"string\" name=\"MSOffice_LINE_COUNT\" type=\"text\"><meta-data locale=\"en_US\"><entry name=\"label\"><![CDATA[metadata.MSOffice.LINE_COUNT]]></entry><entry name=\"predefinedValue\"><![CDATA[]]></entry><entry name=\"required\"><![CDATA[false]]></entry><entry name=\"showLabel\"><![CDATA[true]]></entry></meta-data></dynamic-element><dynamic-element dataType=\"string\" name=\"MSOffice_CHARACTER_COUNT_WITH_SPACES\" type=\"text\"><meta-data locale=\"en_US\"><entry name=\"label\"><![CDATA[metadata.MSOffice.CHARACTER_COUNT_WITH_SPACES]]></entry><entry name=\"predefinedValue\"><![CDATA[]]></entry><entry name=\"required\"><![CDATA[false]]></entry><entry name=\"showLabel\"><![CDATA[true]]></entry></meta-data></dynamic-element><dynamic-element dataType=\"string\" name=\"MSOffice_APPLICATION_VERSION\" type=\"text\"><meta-data locale=\"en_US\"><entry name=\"label\"><![CDATA[metadata.MSOffice.APPLICATION_VERSION]]></entry><entry name=\"predefinedValue\"><![CDATA[]]></entry><entry name=\"required\"><![CDATA[false]]></entry><entry name=\"showLabel\"><![CDATA[true]]></entry></meta-data></dynamic-element><dynamic-element dataType=\"string\" name=\"MSOffice_VERSION\" type=\"text\"><meta-data locale=\"en_US\"><entry name=\"label\"><![CDATA[metadata.MSOffice.VERSION]]></entry><entry name=\"predefinedValue\"><![CDATA[]]></entry><entry name=\"required\"><![CDATA[false]]></entry><entry name=\"showLabel\"><![CDATA[true]]></entry></meta-data></dynamic-element><dynamic-element dataType=\"string\" name=\"MSOffice_CONTENT_STATUS\" type=\"text\"><meta-data locale=\"en_US\"><entry name=\"label\"><![CDATA[metadata.MSOffice.CONTENT_STATUS]]></entry><entry name=\"predefinedValue\"><![CDATA[]]></entry><entry name=\"required\"><![CDATA[false]]></entry><entry name=\"showLabel\"><![CDATA[true]]></entry></meta-data></dynamic-element><dynamic-element dataType=\"string\" name=\"MSOffice_CATEGORY\" type=\"text\"><meta-data locale=\"en_US\"><entry name=\"label\"><![CDATA[metadata.MSOffice.CATEGORY]]></entry><entry name=\"predefinedValue\"><![CDATA[]]></entry><entry name=\"required\"><![CDATA[false]]></entry><entry name=\"showLabel\"><![CDATA[true]]></entry></meta-data></dynamic-element><dynamic-element dataType=\"string\" name=\"MSOffice_COMPANY\" type=\"text\"><meta-data locale=\"en_US\"><entry name=\"label\"><![CDATA[metadata.MSOffice.COMPANY]]></entry><entry name=\"predefinedValue\"><![CDATA[]]></entry><entry name=\"required\"><![CDATA[false]]></entry><entry name=\"showLabel\"><![CDATA[true]]></entry></meta-data></dynamic-element><dynamic-element dataType=\"string\" name=\"MSOffice_SECURITY\" type=\"text\"><meta-data locale=\"en_US\"><entry name=\"label\"><![CDATA[metadata.MSOffice.SECURITY]]></entry><entry name=\"predefinedValue\"><![CDATA[]]></entry><entry name=\"required\"><![CDATA[false]]></entry><entry name=\"showLabel\"><![CDATA[true]]></entry></meta-data></dynamic-element><dynamic-element dataType=\"string\" name=\"MSOffice_EDIT_TIME\" type=\"text\"><meta-data locale=\"en_US\"><entry name=\"label\"><![CDATA[metadata.MSOffice.EDIT_TIME]]></entry><entry name=\"predefinedValue\"><![CDATA[]]></entry><entry name=\"required\"><![CDATA[false]]></entry><entry name=\"showLabel\"><![CDATA[true]]></entry></meta-data></dynamic-element><dynamic-element dataType=\"string\" name=\"MSOffice_CREATION_DATE\" type=\"text\"><meta-data locale=\"en_US\"><entry name=\"label\"><![CDATA[metadata.MSOffice.CREATION_DATE]]></entry><entry name=\"predefinedValue\"><![CDATA[]]></entry><entry name=\"required\"><![CDATA[false]]></entry><entry name=\"showLabel\"><![CDATA[true]]></entry></meta-data></dynamic-element><dynamic-element dataType=\"string\" name=\"TIFF_BITS_PER_SAMPLE\" type=\"text\"><meta-data locale=\"en_US\"><entry name=\"label\"><![CDATA[metadata.TIFF.BITS_PER_SAMPLE]]></entry><entry name=\"predefinedValue\"><![CDATA[]]></entry><entry name=\"required\"><![CDATA[false]]></entry><entry name=\"showLabel\"><![CDATA[true]]></entry></meta-data></dynamic-element><dynamic-element dataType=\"string\" name=\"TIFF_IMAGE_LENGTH\" type=\"text\"><meta-data locale=\"en_US\"><entry name=\"label\"><![CDATA[metadata.TIFF.IMAGE_LENGTH]]></entry><entry name=\"predefinedValue\"><![CDATA[]]></entry><entry name=\"required\"><![CDATA[false]]></entry><entry name=\"showLabel\"><![CDATA[true]]></entry></meta-data></dynamic-element><dynamic-element dataType=\"string\" name=\"TIFF_IMAGE_WIDTH\" type=\"text\"><meta-data locale=\"en_US\"><entry name=\"label\"><![CDATA[metadata.TIFF.IMAGE_WIDTH]]></entry><entry name=\"predefinedValue\"><![CDATA[]]></entry><entry name=\"required\"><![CDATA[false]]></entry><entry name=\"showLabel\"><![CDATA[true]]></entry></meta-data></dynamic-element><dynamic-element dataType=\"string\" name=\"TIFF_SAMPLES_PER_PIXEL\" type=\"text\"><meta-data locale=\"en_US\"><entry name=\"label\"><![CDATA[metadata.TIFF.SAMPLES_PER_PIXEL]]></entry><entry name=\"predefinedValue\"><![CDATA[]]></entry><entry name=\"required\"><![CDATA[false]]></entry><entry name=\"showLabel\"><![CDATA[true]]></entry></meta-data></dynamic-element><dynamic-element dataType=\"string\" name=\"TIFF_FLASH_FIRED\" type=\"text\"><meta-data locale=\"en_US\"><entry name=\"label\"><![CDATA[metadata.TIFF.FLASH_FIRED]]></entry><entry name=\"predefinedValue\"><![CDATA[]]></entry><entry name=\"required\"><![CDATA[false]]></entry><entry name=\"showLabel\"><![CDATA[true]]></entry></meta-data></dynamic-element><dynamic-element dataType=\"string\" name=\"TIFF_EXPOSURE_TIME\" type=\"text\"><meta-data locale=\"en_US\"><entry name=\"label\"><![CDATA[metadata.TIFF.EXPOSURE_TIME]]></entry><entry name=\"predefinedValue\"><![CDATA[]]></entry><entry name=\"required\"><![CDATA[false]]></entry><entry name=\"showLabel\"><![CDATA[true]]></entry></meta-data></dynamic-element><dynamic-element dataType=\"string\" name=\"TIFF_F_NUMBER\" type=\"text\"><meta-data locale=\"en_US\"><entry name=\"label\"><![CDATA[metadata.TIFF.F_NUMBER]]></entry><entry name=\"predefinedValue\"><![CDATA[]]></entry><entry name=\"required\"><![CDATA[false]]></entry><entry name=\"showLabel\"><![CDATA[true]]></entry></meta-data></dynamic-element><dynamic-element dataType=\"string\" name=\"TIFF_FOCAL_LENGTH\" type=\"text\"><meta-data locale=\"en_US\"><entry name=\"label\"><![CDATA[metadata.TIFF.FOCAL_LENGTH]]></entry><entry name=\"predefinedValue\"><![CDATA[]]></entry><entry name=\"required\"><![CDATA[false]]></entry><entry name=\"showLabel\"><![CDATA[true]]></entry></meta-data></dynamic-element><dynamic-element dataType=\"string\" name=\"TIFF_ISO_SPEED_RATINGS\" type=\"text\"><meta-data locale=\"en_US\"><entry name=\"label\"><![CDATA[metadata.TIFF.ISO_SPEED_RATINGS]]></entry><entry name=\"predefinedValue\"><![CDATA[]]></entry><entry name=\"required\"><![CDATA[false]]></entry><entry name=\"showLabel\"><![CDATA[true]]></entry></meta-data></dynamic-element><dynamic-element dataType=\"string\" name=\"TIFF_EQUIPMENT_MAKE\" type=\"text\"><meta-data locale=\"en_US\"><entry name=\"label\"><![CDATA[metadata.TIFF.EQUIPMENT_MAKE]]></entry><entry name=\"predefinedValue\"><![CDATA[]]></entry><entry name=\"required\"><![CDATA[false]]></entry><entry name=\"showLabel\"><![CDATA[true]]></entry></meta-data></dynamic-element><dynamic-element dataType=\"string\" name=\"TIFF_EQUIPMENT_MODEL\" type=\"text\"><meta-data locale=\"en_US\"><entry name=\"label\"><![CDATA[metadata.TIFF.EQUIPMENT_MODEL]]></entry><entry name=\"predefinedValue\"><![CDATA[]]></entry><entry name=\"required\"><![CDATA[false]]></entry><entry name=\"showLabel\"><![CDATA[true]]></entry></meta-data></dynamic-element><dynamic-element dataType=\"string\" name=\"TIFF_SOFTWARE\" type=\"text\"><meta-data locale=\"en_US\"><entry name=\"label\"><![CDATA[metadata.TIFF.SOFTWARE]]></entry><entry name=\"predefinedValue\"><![CDATA[]]></entry><entry name=\"required\"><![CDATA[false]]></entry><entry name=\"showLabel\"><![CDATA[true]]></entry></meta-data></dynamic-element><dynamic-element dataType=\"string\" name=\"TIFF_ORIENTATION\" type=\"text\"><meta-data locale=\"en_US\"><entry name=\"label\"><![CDATA[metadata.TIFF.ORIENTATION]]></entry><entry name=\"predefinedValue\"><![CDATA[]]></entry><entry name=\"required\"><![CDATA[false]]></entry><entry name=\"showLabel\"><![CDATA[true]]></entry></meta-data></dynamic-element><dynamic-element dataType=\"string\" name=\"TIFF_RESOLUTION_HORIZONTAL\" type=\"text\"><meta-data locale=\"en_US\"><entry name=\"label\"><![CDATA[metadata.TIFF.RESOLUTION_HORIZONTAL]]></entry><entry name=\"predefinedValue\"><![CDATA[]]></entry><entry name=\"required\"><![CDATA[false]]></entry><entry name=\"showLabel\"><![CDATA[true]]></entry></meta-data></dynamic-element><dynamic-element dataType=\"string\" name=\"TIFF_RESOLUTION_VERTICAL\" type=\"text\"><meta-data locale=\"en_US\"><entry name=\"label\"><![CDATA[metadata.TIFF.RESOLUTION_VERTICAL]]></entry><entry name=\"predefinedValue\"><![CDATA[]]></entry><entry name=\"required\"><![CDATA[false]]></entry><entry name=\"showLabel\"><![CDATA[true]]></entry></meta-data></dynamic-element><dynamic-element dataType=\"string\" name=\"TIFF_RESOLUTION_UNIT\" type=\"text\"><meta-data locale=\"en_US\"><entry name=\"label\"><![CDATA[metadata.TIFF.RESOLUTION_UNIT]]></entry><entry name=\"predefinedValue\"><![CDATA[]]></entry><entry name=\"required\"><![CDATA[false]]></entry><entry name=\"showLabel\"><![CDATA[true]]></entry></meta-data></dynamic-element><dynamic-element dataType=\"string\" name=\"TIFF_ORIGINAL_DATE\" type=\"text\"><meta-data locale=\"en_US\"><entry name=\"label\"><![CDATA[metadata.TIFF.ORIGINAL_DATE]]></entry><entry name=\"predefinedValue\"><![CDATA[]]></entry><entry name=\"required\"><![CDATA[false]]></entry><entry name=\"showLabel\"><![CDATA[true]]></entry></meta-data></dynamic-element><dynamic-element dataType=\"string\" name=\"TikaMetadataKeys_RESOURCE_NAME_KEY\" type=\"text\"><meta-data locale=\"en_US\"><entry name=\"label\"><![CDATA[metadata.TikaMetadataKeys.RESOURCE_NAME_KEY]]></entry><entry name=\"predefinedValue\"><![CDATA[]]></entry><entry name=\"required\"><![CDATA[false]]></entry><entry name=\"showLabel\"><![CDATA[true]]></entry></meta-data></dynamic-element><dynamic-element dataType=\"string\" name=\"TikaMetadataKeys_PROTECTED\" type=\"text\"><meta-data locale=\"en_US\"><entry name=\"label\"><![CDATA[metadata.TikaMetadataKeys.PROTECTED]]></entry><entry name=\"predefinedValue\"><![CDATA[]]></entry><entry name=\"required\"><![CDATA[false]]></entry><entry name=\"showLabel\"><![CDATA[true]]></entry></meta-data></dynamic-element><dynamic-element dataType=\"string\" name=\"TikaMimeKeys_TIKA_MIME_FILE\" type=\"text\"><meta-data locale=\"en_US\"><entry name=\"label\"><![CDATA[metadata.TikaMimeKeys.TIKA_MIME_FILE]]></entry><entry name=\"predefinedValue\"><![CDATA[]]></entry><entry name=\"required\"><![CDATA[false]]></entry><entry name=\"showLabel\"><![CDATA[true]]></entry></meta-data></dynamic-element><dynamic-element dataType=\"string\" name=\"TikaMimeKeys_MIME_TYPE_MAGIC\" type=\"text\"><meta-data locale=\"en_US\"><entry name=\"label\"><![CDATA[metadata.TikaMimeKeys.MIME_TYPE_MAGIC]]></entry><entry name=\"predefinedValue\"><![CDATA[]]></entry><entry name=\"required\"><![CDATA[false]]></entry><entry name=\"showLabel\"><![CDATA[true]]></entry></meta-data></dynamic-element><dynamic-element dataType=\"string\" name=\"XMPDM_DURATION\" type=\"text\"><meta-data locale=\"en_US\"><entry name=\"label\"><![CDATA[metadata.XMPDM.DURATION]]></entry><entry name=\"predefinedValue\"><![CDATA[]]></entry><entry name=\"required\"><![CDATA[false]]></entry><entry name=\"showLabel\"><![CDATA[true]]></entry></meta-data></dynamic-element><dynamic-element dataType=\"string\" name=\"XMPDM_ABS_PEAK_AUDIO_FILE_PATH\" type=\"text\"><meta-data locale=\"en_US\"><entry name=\"label\"><![CDATA[metadata.XMPDM.ABS_PEAK_AUDIO_FILE_PATH]]></entry><entry name=\"predefinedValue\"><![CDATA[]]></entry><entry name=\"required\"><![CDATA[false]]></entry><entry name=\"showLabel\"><![CDATA[true]]></entry></meta-data></dynamic-element><dynamic-element dataType=\"string\" name=\"XMPDM_ALBUM\" type=\"text\"><meta-data locale=\"en_US\"><entry name=\"label\"><![CDATA[metadata.XMPDM.ALBUM]]></entry><entry name=\"predefinedValue\"><![CDATA[]]></entry><entry name=\"required\"><![CDATA[false]]></entry><entry name=\"showLabel\"><![CDATA[true]]></entry></meta-data></dynamic-element><dynamic-element dataType=\"string\" name=\"XMPDM_ALT_TAPE_NAME\" type=\"text\"><meta-data locale=\"en_US\"><entry name=\"label\"><![CDATA[metadata.XMPDM.ALT_TAPE_NAME]]></entry><entry name=\"predefinedValue\"><![CDATA[]]></entry><entry name=\"required\"><![CDATA[false]]></entry><entry name=\"showLabel\"><![CDATA[true]]></entry></meta-data></dynamic-element><dynamic-element dataType=\"string\" name=\"XMPDM_ARTIST\" type=\"text\"><meta-data locale=\"en_US\"><entry name=\"label\"><![CDATA[metadata.XMPDM.ARTIST]]></entry><entry name=\"predefinedValue\"><![CDATA[]]></entry><entry name=\"required\"><![CDATA[false]]></entry><entry name=\"showLabel\"><![CDATA[true]]></entry></meta-data></dynamic-element><dynamic-element dataType=\"string\" name=\"XMPDM_AUDIO_MOD_DATE\" type=\"text\"><meta-data locale=\"en_US\"><entry name=\"label\"><![CDATA[metadata.XMPDM.AUDIO_MOD_DATE]]></entry><entry name=\"predefinedValue\"><![CDATA[]]></entry><entry name=\"required\"><![CDATA[false]]></entry><entry name=\"showLabel\"><![CDATA[true]]></entry></meta-data></dynamic-element><dynamic-element dataType=\"string\" name=\"XMPDM_AUDIO_SAMPLE_RATE\" type=\"text\"><meta-data locale=\"en_US\"><entry name=\"label\"><![CDATA[metadata.XMPDM.AUDIO_SAMPLE_RATE]]></entry><entry name=\"predefinedValue\"><![CDATA[]]></entry><entry name=\"required\"><![CDATA[false]]></entry><entry name=\"showLabel\"><![CDATA[true]]></entry></meta-data></dynamic-element><dynamic-element dataType=\"string\" name=\"XMPDM_AUDIO_SAMPLE_TYPE\" type=\"text\"><meta-data locale=\"en_US\"><entry name=\"label\"><![CDATA[metadata.XMPDM.AUDIO_SAMPLE_TYPE]]></entry><entry name=\"predefinedValue\"><![CDATA[]]></entry><entry name=\"required\"><![CDATA[false]]></entry><entry name=\"showLabel\"><![CDATA[true]]></entry></meta-data></dynamic-element><dynamic-element dataType=\"string\" name=\"XMPDM_AUDIO_CHANNEL_TYPE\" type=\"text\"><meta-data locale=\"en_US\"><entry name=\"label\"><![CDATA[metadata.XMPDM.AUDIO_CHANNEL_TYPE]]></entry><entry name=\"predefinedValue\"><![CDATA[]]></entry><entry name=\"required\"><![CDATA[false]]></entry><entry name=\"showLabel\"><![CDATA[true]]></entry></meta-data></dynamic-element><dynamic-element dataType=\"string\" name=\"XMPDM_AUDIO_COMPRESSOR\" type=\"text\"><meta-data locale=\"en_US\"><entry name=\"label\"><![CDATA[metadata.XMPDM.AUDIO_COMPRESSOR]]></entry><entry name=\"predefinedValue\"><![CDATA[]]></entry><entry name=\"required\"><![CDATA[false]]></entry><entry name=\"showLabel\"><![CDATA[true]]></entry></meta-data></dynamic-element><dynamic-element dataType=\"string\" name=\"XMPDM_COMPOSER\" type=\"text\"><meta-data locale=\"en_US\"><entry name=\"label\"><![CDATA[metadata.XMPDM.COMPOSER]]></entry><entry name=\"predefinedValue\"><![CDATA[]]></entry><entry name=\"required\"><![CDATA[false]]></entry><entry name=\"showLabel\"><![CDATA[true]]></entry></meta-data></dynamic-element><dynamic-element dataType=\"string\" name=\"XMPDM_COPYRIGHT\" type=\"text\"><meta-data locale=\"en_US\"><entry name=\"label\"><![CDATA[metadata.XMPDM.COPYRIGHT]]></entry><entry name=\"predefinedValue\"><![CDATA[]]></entry><entry name=\"required\"><![CDATA[false]]></entry><entry name=\"showLabel\"><![CDATA[true]]></entry></meta-data></dynamic-element><dynamic-element dataType=\"string\" name=\"XMPDM_ENGINEER\" type=\"text\"><meta-data locale=\"en_US\"><entry name=\"label\"><![CDATA[metadata.XMPDM.ENGINEER]]></entry><entry name=\"predefinedValue\"><![CDATA[]]></entry><entry name=\"required\"><![CDATA[false]]></entry><entry name=\"showLabel\"><![CDATA[true]]></entry></meta-data></dynamic-element><dynamic-element dataType=\"string\" name=\"XMPDM_FILE_DATA_RATE\" type=\"text\"><meta-data locale=\"en_US\"><entry name=\"label\"><![CDATA[metadata.XMPDM.FILE_DATA_RATE]]></entry><entry name=\"predefinedValue\"><![CDATA[]]></entry><entry name=\"required\"><![CDATA[false]]></entry><entry name=\"showLabel\"><![CDATA[true]]></entry></meta-data></dynamic-element><dynamic-element dataType=\"string\" name=\"XMPDM_GENRE\" type=\"text\"><meta-data locale=\"en_US\"><entry name=\"label\"><![CDATA[metadata.XMPDM.GENRE]]></entry><entry name=\"predefinedValue\"><![CDATA[]]></entry><entry name=\"required\"><![CDATA[false]]></entry><entry name=\"showLabel\"><![CDATA[true]]></entry></meta-data></dynamic-element><dynamic-element dataType=\"string\" name=\"XMPDM_INSTRUMENT\" type=\"text\"><meta-data locale=\"en_US\"><entry name=\"label\"><![CDATA[metadata.XMPDM.INSTRUMENT]]></entry><entry name=\"predefinedValue\"><![CDATA[]]></entry><entry name=\"required\"><![CDATA[false]]></entry><entry name=\"showLabel\"><![CDATA[true]]></entry></meta-data></dynamic-element><dynamic-element dataType=\"string\" name=\"XMPDM_KEY\" type=\"text\"><meta-data locale=\"en_US\"><entry name=\"label\"><![CDATA[metadata.XMPDM.KEY]]></entry><entry name=\"predefinedValue\"><![CDATA[]]></entry><entry name=\"required\"><![CDATA[false]]></entry><entry name=\"showLabel\"><![CDATA[true]]></entry></meta-data></dynamic-element><dynamic-element dataType=\"string\" name=\"XMPDM_LOG_COMMENT\" type=\"text\"><meta-data locale=\"en_US\"><entry name=\"label\"><![CDATA[metadata.XMPDM.LOG_COMMENT]]></entry><entry name=\"predefinedValue\"><![CDATA[]]></entry><entry name=\"required\"><![CDATA[false]]></entry><entry name=\"showLabel\"><![CDATA[true]]></entry></meta-data></dynamic-element><dynamic-element dataType=\"string\" name=\"XMPDM_LOOP\" type=\"text\"><meta-data locale=\"en_US\"><entry name=\"label\"><![CDATA[metadata.XMPDM.LOOP]]></entry><entry name=\"predefinedValue\"><![CDATA[]]></entry><entry name=\"required\"><![CDATA[false]]></entry><entry name=\"showLabel\"><![CDATA[true]]></entry></meta-data></dynamic-element><dynamic-element dataType=\"string\" name=\"XMPDM_NUMBER_OF_BEATS\" type=\"text\"><meta-data locale=\"en_US\"><entry name=\"label\"><![CDATA[metadata.XMPDM.NUMBER_OF_BEATS]]></entry><entry name=\"predefinedValue\"><![CDATA[]]></entry><entry name=\"required\"><![CDATA[false]]></entry><entry name=\"showLabel\"><![CDATA[true]]></entry></meta-data></dynamic-element><dynamic-element dataType=\"string\" name=\"XMPDM_METADATA_MOD_DATE\" type=\"text\"><meta-data locale=\"en_US\"><entry name=\"label\"><![CDATA[metadata.XMPDM.METADATA_MOD_DATE]]></entry><entry name=\"predefinedValue\"><![CDATA[]]></entry><entry name=\"required\"><![CDATA[false]]></entry><entry name=\"showLabel\"><![CDATA[true]]></entry></meta-data></dynamic-element><dynamic-element dataType=\"string\" name=\"XMPDM_PULL_DOWN\" type=\"text\"><meta-data locale=\"en_US\"><entry name=\"label\"><![CDATA[metadata.XMPDM.PULL_DOWN]]></entry><entry name=\"predefinedValue\"><![CDATA[]]></entry><entry name=\"required\"><![CDATA[false]]></entry><entry name=\"showLabel\"><![CDATA[true]]></entry></meta-data></dynamic-element><dynamic-element dataType=\"string\" name=\"XMPDM_RELATIVE_PEAK_AUDIO_FILE_PATH\" type=\"text\"><meta-data locale=\"en_US\"><entry name=\"label\"><![CDATA[metadata.XMPDM.RELATIVE_PEAK_AUDIO_FILE_PATH]]></entry><entry name=\"predefinedValue\"><![CDATA[]]></entry><entry name=\"required\"><![CDATA[false]]></entry><entry name=\"showLabel\"><![CDATA[true]]></entry></meta-data></dynamic-element><dynamic-element dataType=\"string\" name=\"XMPDM_RELEASE_DATE\" type=\"text\"><meta-data locale=\"en_US\"><entry name=\"label\"><![CDATA[metadata.XMPDM.RELEASE_DATE]]></entry><entry name=\"predefinedValue\"><![CDATA[]]></entry><entry name=\"required\"><![CDATA[false]]></entry><entry name=\"showLabel\"><![CDATA[true]]></entry></meta-data></dynamic-element><dynamic-element dataType=\"string\" name=\"XMPDM_SCALE_TYPE\" type=\"text\"><meta-data locale=\"en_US\"><entry name=\"label\"><![CDATA[metadata.XMPDM.SCALE_TYPE]]></entry><entry name=\"predefinedValue\"><![CDATA[]]></entry><entry name=\"required\"><![CDATA[false]]></entry><entry name=\"showLabel\"><![CDATA[true]]></entry></meta-data></dynamic-element><dynamic-element dataType=\"string\" name=\"XMPDM_SCENE\" type=\"text\"><meta-data locale=\"en_US\"><entry name=\"label\"><![CDATA[metadata.XMPDM.SCENE]]></entry><entry name=\"predefinedValue\"><![CDATA[]]></entry><entry name=\"required\"><![CDATA[false]]></entry><entry name=\"showLabel\"><![CDATA[true]]></entry></meta-data></dynamic-element><dynamic-element dataType=\"string\" name=\"XMPDM_SHOT_DATE\" type=\"text\"><meta-data locale=\"en_US\"><entry name=\"label\"><![CDATA[metadata.XMPDM.SHOT_DATE]]></entry><entry name=\"predefinedValue\"><![CDATA[]]></entry><entry name=\"required\"><![CDATA[false]]></entry><entry name=\"showLabel\"><![CDATA[true]]></entry></meta-data></dynamic-element><dynamic-element dataType=\"string\" name=\"XMPDM_SHOT_LOCATION\" type=\"text\"><meta-data locale=\"en_US\"><entry name=\"label\"><![CDATA[metadata.XMPDM.SHOT_LOCATION]]></entry><entry name=\"predefinedValue\"><![CDATA[]]></entry><entry name=\"required\"><![CDATA[false]]></entry><entry name=\"showLabel\"><![CDATA[true]]></entry></meta-data></dynamic-element><dynamic-element dataType=\"string\" name=\"XMPDM_SHOT_NAME\" type=\"text\"><meta-data locale=\"en_US\"><entry name=\"label\"><![CDATA[metadata.XMPDM.SHOT_NAME]]></entry><entry name=\"predefinedValue\"><![CDATA[]]></entry><entry name=\"required\"><![CDATA[false]]></entry><entry name=\"showLabel\"><![CDATA[true]]></entry></meta-data></dynamic-element><dynamic-element dataType=\"string\" name=\"XMPDM_SPEAKER_PLACEMENT\" type=\"text\"><meta-data locale=\"en_US\"><entry name=\"label\"><![CDATA[metadata.XMPDM.SPEAKER_PLACEMENT]]></entry><entry name=\"predefinedValue\"><![CDATA[]]></entry><entry name=\"required\"><![CDATA[false]]></entry><entry name=\"showLabel\"><![CDATA[true]]></entry></meta-data></dynamic-element><dynamic-element dataType=\"string\" name=\"XMPDM_STRETCH_MODE\" type=\"text\"><meta-data locale=\"en_US\"><entry name=\"label\"><![CDATA[metadata.XMPDM.STRETCH_MODE]]></entry><entry name=\"predefinedValue\"><![CDATA[]]></entry><entry name=\"required\"><![CDATA[false]]></entry><entry name=\"showLabel\"><![CDATA[true]]></entry></meta-data></dynamic-element><dynamic-element dataType=\"string\" name=\"XMPDM_TAPE_NAME\" type=\"text\"><meta-data locale=\"en_US\"><entry name=\"label\"><![CDATA[metadata.XMPDM.TAPE_NAME]]></entry><entry name=\"predefinedValue\"><![CDATA[]]></entry><entry name=\"required\"><![CDATA[false]]></entry><entry name=\"showLabel\"><![CDATA[true]]></entry></meta-data></dynamic-element><dynamic-element dataType=\"string\" name=\"XMPDM_TEMPO\" type=\"text\"><meta-data locale=\"en_US\"><entry name=\"label\"><![CDATA[metadata.XMPDM.TEMPO]]></entry><entry name=\"predefinedValue\"><![CDATA[]]></entry><entry name=\"required\"><![CDATA[false]]></entry><entry name=\"showLabel\"><![CDATA[true]]></entry></meta-data></dynamic-element><dynamic-element dataType=\"string\" name=\"XMPDM_TIME_SIGNATURE\" type=\"text\"><meta-data locale=\"en_US\"><entry name=\"label\"><![CDATA[metadata.XMPDM.TIME_SIGNATURE]]></entry><entry name=\"predefinedValue\"><![CDATA[]]></entry><entry name=\"required\"><![CDATA[false]]></entry><entry name=\"showLabel\"><![CDATA[true]]></entry></meta-data></dynamic-element><dynamic-element dataType=\"string\" name=\"XMPDM_TRACK_NUMBER\" type=\"text\"><meta-data locale=\"en_US\"><entry name=\"label\"><![CDATA[metadata.XMPDM.TRACK_NUMBER]]></entry><entry name=\"predefinedValue\"><![CDATA[]]></entry><entry name=\"required\"><![CDATA[false]]></entry><entry name=\"showLabel\"><![CDATA[true]]></entry></meta-data></dynamic-element><dynamic-element dataType=\"string\" name=\"XMPDM_VIDEO_ALPHA_MODE\" type=\"text\"><meta-data locale=\"en_US\"><entry name=\"label\"><![CDATA[metadata.XMPDM.VIDEO_ALPHA_MODE]]></entry><entry name=\"predefinedValue\"><![CDATA[]]></entry><entry name=\"required\"><![CDATA[false]]></entry><entry name=\"showLabel\"><![CDATA[true]]></entry></meta-data></dynamic-element><dynamic-element dataType=\"string\" name=\"XMPDM_VIDEO_ALPHA_UNITY_IS_TRANSPARENT\" type=\"text\"><meta-data locale=\"en_US\"><entry name=\"label\"><![CDATA[metadata.XMPDM.VIDEO_ALPHA_UNITY_IS_TRANSPARENT]]></entry><entry name=\"predefinedValue\"><![CDATA[]]></entry><entry name=\"required\"><![CDATA[false]]></entry><entry name=\"showLabel\"><![CDATA[true]]></entry></meta-data></dynamic-element><dynamic-element dataType=\"string\" name=\"XMPDM_VIDEO_COLOR_SPACE\" type=\"text\"><meta-data locale=\"en_US\"><entry name=\"label\"><![CDATA[metadata.XMPDM.VIDEO_COLOR_SPACE]]></entry><entry name=\"predefinedValue\"><![CDATA[]]></entry><entry name=\"required\"><![CDATA[false]]></entry><entry name=\"showLabel\"><![CDATA[true]]></entry></meta-data></dynamic-element><dynamic-element dataType=\"string\" name=\"XMPDM_VIDEO_COMPRESSOR\" type=\"text\"><meta-data locale=\"en_US\"><entry name=\"label\"><![CDATA[metadata.XMPDM.VIDEO_COMPRESSOR]]></entry><entry name=\"predefinedValue\"><![CDATA[]]></entry><entry name=\"required\"><![CDATA[false]]></entry><entry name=\"showLabel\"><![CDATA[true]]></entry></meta-data></dynamic-element><dynamic-element dataType=\"string\" name=\"XMPDM_VIDEO_FIELD_ORDER\" type=\"text\"><meta-data locale=\"en_US\"><entry name=\"label\"><![CDATA[metadata.XMPDM.VIDEO_FIELD_ORDER]]></entry><entry name=\"predefinedValue\"><![CDATA[]]></entry><entry name=\"required\"><![CDATA[false]]></entry><entry name=\"showLabel\"><![CDATA[true]]></entry></meta-data></dynamic-element><dynamic-element dataType=\"string\" name=\"XMPDM_VIDEO_FRAME_RATE\" type=\"text\"><meta-data locale=\"en_US\"><entry name=\"label\"><![CDATA[metadata.XMPDM.VIDEO_FRAME_RATE]]></entry><entry name=\"predefinedValue\"><![CDATA[]]></entry><entry name=\"required\"><![CDATA[false]]></entry><entry name=\"showLabel\"><![CDATA[true]]></entry></meta-data></dynamic-element><dynamic-element dataType=\"string\" name=\"XMPDM_VIDEO_MOD_DATE\" type=\"text\"><meta-data locale=\"en_US\"><entry name=\"label\"><![CDATA[metadata.XMPDM.VIDEO_MOD_DATE]]></entry><entry name=\"predefinedValue\"><![CDATA[]]></entry><entry name=\"required\"><![CDATA[false]]></entry><entry name=\"showLabel\"><![CDATA[true]]></entry></meta-data></dynamic-element><dynamic-element dataType=\"string\" name=\"XMPDM_VIDEO_PIXEL_DEPTH\" type=\"text\"><meta-data locale=\"en_US\"><entry name=\"label\"><![CDATA[metadata.XMPDM.VIDEO_PIXEL_DEPTH]]></entry><entry name=\"predefinedValue\"><![CDATA[]]></entry><entry name=\"required\"><![CDATA[false]]></entry><entry name=\"showLabel\"><![CDATA[true]]></entry></meta-data></dynamic-element><dynamic-element dataType=\"string\" name=\"XMPDM_VIDEO_PIXEL_ASPECT_RATIO\" type=\"text\"><meta-data locale=\"en_US\"><entry name=\"label\"><![CDATA[metadata.XMPDM.VIDEO_PIXEL_ASPECT_RATIO]]></entry><entry name=\"predefinedValue\"><![CDATA[]]></entry><entry name=\"required\"><![CDATA[false]]></entry><entry name=\"showLabel\"><![CDATA[true]]></entry></meta-data></dynamic-element></root>','xml',0),('9ee661ea-0a79-4f80-a00a-8b15b57c1c75',10399,10180,10154,10158,'','2014-03-18 17:33:40','2014-03-18 17:33:40',10097,'Contacts','<?xml version=\'1.0\' encoding=\'UTF-8\'?><root available-locales=\"en_US\" default-locale=\"en_US\"><Name language-id=\"en_US\">Contacts</Name></root>','<?xml version=\'1.0\' encoding=\'UTF-8\'?><root available-locales=\"en_US\" default-locale=\"en_US\"><Description language-id=\"en_US\">Contacts</Description></root>','<?xml version=\"1.0\"?>\n\n<root available-locales=\"en_US\" default-locale=\"en_US\">\n	<dynamic-element dataType=\"string\" name=\"company\" type=\"text\">\n		<meta-data locale=\"en_US\">\n			<entry name=\"fieldCssClass\"><![CDATA[aui-w50]]></entry>\n			<entry name=\"label\"><![CDATA[Company]]></entry>\n			<entry name=\"predefinedValue\"><![CDATA[]]></entry>\n			<entry name=\"required\"><![CDATA[false]]></entry>\n			<entry name=\"showLabel\"><![CDATA[true]]></entry>\n			<entry name=\"width\"><![CDATA[50]]></entry>\n		</meta-data>\n	</dynamic-element>\n	<dynamic-element dataType=\"string\" name=\"email\" type=\"text\">\n		<meta-data locale=\"en_US\">\n			<entry name=\"fieldCssClass\"><![CDATA[aui-w50]]></entry>\n			<entry name=\"label\"><![CDATA[Email]]></entry>\n			<entry name=\"predefinedValue\"><![CDATA[]]></entry>\n			<entry name=\"required\"><![CDATA[false]]></entry>\n			<entry name=\"showLabel\"><![CDATA[true]]></entry>\n			<entry name=\"width\"><![CDATA[50]]></entry>\n		</meta-data>\n	</dynamic-element>\n	<dynamic-element dataType=\"string\" name=\"firstName\" type=\"text\">\n		<meta-data locale=\"en_US\">\n			<entry name=\"fieldCssClass\"><![CDATA[aui-w50]]></entry>\n			<entry name=\"label\"><![CDATA[First Name]]></entry>\n			<entry name=\"predefinedValue\"><![CDATA[]]></entry>\n			<entry name=\"required\"><![CDATA[false]]></entry>\n			<entry name=\"showLabel\"><![CDATA[true]]></entry>\n			<entry name=\"width\"><![CDATA[50]]></entry>\n		</meta-data>\n	</dynamic-element>\n	<dynamic-element dataType=\"string\" name=\"imService\" type=\"select\">\n		<dynamic-element name=\"aol\" type=\"option\" value=\"aol\">\n			<meta-data locale=\"en_US\">\n				<entry name=\"label\"><![CDATA[AOL]]></entry>\n				<entry name=\"multiple\"><![CDATA[false]]></entry>\n			</meta-data>\n		</dynamic-element>\n		<dynamic-element name=\"yahoo\" type=\"option\" value=\"yahoo\">\n			<meta-data locale=\"en_US\">\n				<entry name=\"label\"><![CDATA[Yahoo]]></entry>\n			</meta-data>\n		</dynamic-element>\n		<dynamic-element name=\"gtalk\" type=\"option\" value=\"gtalk\">\n			<meta-data locale=\"en_US\">\n				<entry name=\"label\"><![CDATA[GTalk]]></entry>\n			</meta-data>\n		</dynamic-element>\n		<meta-data locale=\"en_US\">\n			<entry name=\"label\"><![CDATA[Instant Messenger Service]]></entry>\n			<entry name=\"predefinedValue\"><![CDATA[[\"gtalk\"]]]></entry>\n			<entry name=\"required\"><![CDATA[false]]></entry>\n			<entry name=\"showLabel\"><![CDATA[true]]></entry>\n		</meta-data>\n	</dynamic-element>\n	<dynamic-element dataType=\"string\" name=\"imUserName\" type=\"text\">\n		<meta-data locale=\"en_US\">\n			<entry name=\"fieldCssClass\"><![CDATA[aui-w50]]></entry>\n			<entry name=\"label\"><![CDATA[Instant Messenger]]></entry>\n			<entry name=\"predefinedValue\"><![CDATA[]]></entry>\n			<entry name=\"required\"><![CDATA[false]]></entry>\n			<entry name=\"showLabel\"><![CDATA[true]]></entry>\n			<entry name=\"width\"><![CDATA[50]]></entry>\n		</meta-data>\n	</dynamic-element>\n	<dynamic-element dataType=\"string\" name=\"jobTitle\" type=\"text\">\n		<meta-data locale=\"en_US\">\n			<entry name=\"fieldCssClass\"><![CDATA[aui-w50]]></entry>\n			<entry name=\"label\"><![CDATA[Job Title]]></entry>\n			<entry name=\"predefinedValue\"><![CDATA[]]></entry>\n			<entry name=\"required\"><![CDATA[false]]></entry>\n			<entry name=\"showLabel\"><![CDATA[true]]></entry>\n			<entry name=\"width\"><![CDATA[50]]></entry>\n		</meta-data>\n	</dynamic-element>\n	<dynamic-element dataType=\"string\" name=\"lastName\" type=\"text\">\n		<meta-data locale=\"en_US\">\n			<entry name=\"fieldCssClass\"><![CDATA[aui-w50]]></entry>\n			<entry name=\"label\"><![CDATA[Last Name]]></entry>\n			<entry name=\"predefinedValue\"><![CDATA[]]></entry>\n			<entry name=\"required\"><![CDATA[false]]></entry>\n			<entry name=\"showLabel\"><![CDATA[true]]></entry>\n			<entry name=\"width\"><![CDATA[50]]></entry>\n		</meta-data>\n	</dynamic-element>\n	<dynamic-element dataType=\"string\" name=\"notes\" type=\"textarea\">\n		<meta-data locale=\"en_US\">\n			<entry name=\"fieldCssClass\"><![CDATA[aui-w100]]></entry>\n			<entry name=\"label\"><![CDATA[Notes]]></entry>\n			<entry name=\"predefinedValue\"><![CDATA[]]></entry>\n			<entry name=\"required\"><![CDATA[false]]></entry>\n			<entry name=\"showLabel\"><![CDATA[true]]></entry>\n			<entry name=\"width\"><![CDATA[100]]></entry>\n		</meta-data>\n	</dynamic-element>\n	<dynamic-element dataType=\"string\" name=\"phoneMobile\" type=\"text\">\n		<meta-data locale=\"en_US\">\n			<entry name=\"fieldCssClass\"><![CDATA[aui-w50]]></entry>\n			<entry name=\"label\"><![CDATA[Phone (Mobile)]]></entry>\n			<entry name=\"predefinedValue\"><![CDATA[]]></entry>\n			<entry name=\"required\"><![CDATA[false]]></entry>\n			<entry name=\"showLabel\"><![CDATA[true]]></entry>\n			<entry name=\"width\"><![CDATA[50]]></entry>\n		</meta-data>\n	</dynamic-element>\n	<dynamic-element dataType=\"string\" name=\"phoneOffice\" type=\"text\">\n		<meta-data locale=\"en_US\">\n			<entry name=\"fieldCssClass\"><![CDATA[aui-w50]]></entry>\n			<entry name=\"label\"><![CDATA[Phone (Office)]]></entry>\n			<entry name=\"predefinedValue\"><![CDATA[]]></entry>\n			<entry name=\"required\"><![CDATA[false]]></entry>\n			<entry name=\"showLabel\"><![CDATA[true]]></entry>\n			<entry name=\"width\"><![CDATA[50]]></entry>\n		</meta-data>\n	</dynamic-element>\n</root>','xml',0),('3c8db918-3707-463c-ab35-56c58b1ed800',10400,10180,10154,10158,'','2014-03-18 17:33:40','2014-03-18 17:33:40',10097,'Events','<?xml version=\'1.0\' encoding=\'UTF-8\'?><root available-locales=\"en_US\" default-locale=\"en_US\"><Name language-id=\"en_US\">Events</Name></root>','<?xml version=\'1.0\' encoding=\'UTF-8\'?><root available-locales=\"en_US\" default-locale=\"en_US\"><Description language-id=\"en_US\">Events</Description></root>','<?xml version=\"1.0\"?>\n\n<root available-locales=\"en_US\" default-locale=\"en_US\">\n	<dynamic-element dataType=\"file-upload\" fieldNamespace=\"ddm\" name=\"attachment\" type=\"ddm-fileupload\">\n		<meta-data locale=\"en_US\">\n			<entry name=\"acceptFiles\"><![CDATA[*]]></entry>\n			<entry name=\"folder\"><![CDATA[{\"folderId\":0,\"folderName\":\"Documents Home\"}]]></entry>\n			<entry name=\"label\"><![CDATA[Attachment]]></entry>\n			<entry name=\"name\"><![CDATA[attachment]]></entry>\n			<entry name=\"predefinedValue\"><![CDATA[]]></entry>\n			<entry name=\"required\"><![CDATA[false]]></entry>\n			<entry name=\"showLabel\"><![CDATA[true]]></entry>\n			<entry name=\"tip\"><![CDATA[Upload documents no larger than 3,000k.]]></entry>\n			<entry name=\"type\"><![CDATA[ddm-fileupload]]></entry>\n		</meta-data>\n	</dynamic-element>\n	<dynamic-element dataType=\"double\" fieldNamespace=\"ddm\" name=\"cost\" type=\"ddm-number\">\n		<meta-data locale=\"en_US\">\n			<entry name=\"fieldCssClass\"><![CDATA[aui-w25]]></entry>\n			<entry name=\"label\"><![CDATA[Cost]]></entry>\n			<entry name=\"name\"><![CDATA[cost]]></entry>\n			<entry name=\"predefinedValue\"><![CDATA[]]></entry>\n			<entry name=\"required\"><![CDATA[false]]></entry>\n			<entry name=\"showLabel\"><![CDATA[true]]></entry>\n			<entry name=\"tip\"><![CDATA[]]></entry>\n			<entry name=\"type\"><![CDATA[ddm-number]]></entry>\n			<entry name=\"width\"><![CDATA[25]]></entry>\n		</meta-data>\n	</dynamic-element>\n	<dynamic-element dataType=\"string\" name=\"description\" type=\"textarea\">\n		<meta-data locale=\"en_US\">\n			<entry name=\"fieldCssClass\"><![CDATA[aui-w100]]></entry>\n			<entry name=\"label\"><![CDATA[Description]]></entry>\n			<entry name=\"name\"><![CDATA[description]]></entry>\n			<entry name=\"predefinedValue\"><![CDATA[]]></entry>\n			<entry name=\"required\"><![CDATA[false]]></entry>\n			<entry name=\"showLabel\"><![CDATA[true]]></entry>\n			<entry name=\"tip\"><![CDATA[]]></entry>\n			<entry name=\"type\"><![CDATA[textarea]]></entry>\n			<entry name=\"width\"><![CDATA[100]]></entry>\n		</meta-data>\n	</dynamic-element>\n	<dynamic-element dataType=\"date\" fieldNamespace=\"ddm\" name=\"eventDate\" type=\"ddm-date\">\n		<meta-data locale=\"en_US\">\n			<entry name=\"fieldCssClass\"><![CDATA[aui-w25]]></entry>\n			<entry name=\"label\"><![CDATA[Date]]></entry>\n			<entry name=\"name\"><![CDATA[eventDate]]></entry>\n			<entry name=\"predefinedValue\"><![CDATA[]]></entry>\n			<entry name=\"required\"><![CDATA[false]]></entry>\n			<entry name=\"showLabel\"><![CDATA[true]]></entry>\n			<entry name=\"tip\"><![CDATA[]]></entry>\n			<entry name=\"type\"><![CDATA[ddm-date]]></entry>\n			<entry name=\"width\"><![CDATA[25]]></entry>\n		</meta-data>\n	</dynamic-element>\n	<dynamic-element dataType=\"string\" name=\"eventName\" type=\"text\">\n		<meta-data locale=\"en_US\">\n			<entry name=\"fieldCssClass\"><![CDATA[aui-w50]]></entry>\n			<entry name=\"label\"><![CDATA[Event Name]]></entry>\n			<entry name=\"name\"><![CDATA[eventName]]></entry>\n			<entry name=\"predefinedValue\"><![CDATA[]]></entry>\n			<entry name=\"required\"><![CDATA[false]]></entry>\n			<entry name=\"showLabel\"><![CDATA[true]]></entry>\n			<entry name=\"tip\"><![CDATA[]]></entry>\n			<entry name=\"type\"><![CDATA[text]]></entry>\n			<entry name=\"width\"><![CDATA[50]]></entry>\n		</meta-data>\n	</dynamic-element>\n	<dynamic-element dataType=\"string\" name=\"eventTime\" type=\"text\">\n		<meta-data locale=\"en_US\">\n			<entry name=\"fieldCssClass\"><![CDATA[aui-w25]]></entry>\n			<entry name=\"label\"><![CDATA[Time]]></entry>\n			<entry name=\"name\"><![CDATA[eventTime]]></entry>\n			<entry name=\"predefinedValue\"><![CDATA[]]></entry>\n			<entry name=\"required\"><![CDATA[false]]></entry>\n			<entry name=\"showLabel\"><![CDATA[true]]></entry>\n			<entry name=\"tip\"><![CDATA[]]></entry>\n			<entry name=\"type\"><![CDATA[text]]></entry>\n			<entry name=\"width\"><![CDATA[25]]></entry>\n		</meta-data>\n	</dynamic-element>\n	<dynamic-element dataType=\"string\" name=\"location\" type=\"text\">\n		<meta-data locale=\"en_US\">\n			<entry name=\"fieldCssClass\"><![CDATA[aui-w50]]></entry>\n			<entry name=\"label\"><![CDATA[Location]]></entry>\n			<entry name=\"name\"><![CDATA[location]]></entry>\n			<entry name=\"predefinedValue\"><![CDATA[]]></entry>\n			<entry name=\"required\"><![CDATA[false]]></entry>\n			<entry name=\"showLabel\"><![CDATA[true]]></entry>\n			<entry name=\"tip\"><![CDATA[]]></entry>\n			<entry name=\"type\"><![CDATA[text]]></entry>\n			<entry name=\"width\"><![CDATA[50]]></entry>\n		</meta-data>\n	</dynamic-element>\n</root>','xml',0),('1bd88b51-e3b7-48ef-b488-cb91fdb3b904',10401,10180,10154,10158,'','2014-03-18 17:33:40','2014-03-18 17:33:40',10097,'Inventory','<?xml version=\'1.0\' encoding=\'UTF-8\'?><root available-locales=\"en_US\" default-locale=\"en_US\"><Name language-id=\"en_US\">Inventory</Name></root>','<?xml version=\'1.0\' encoding=\'UTF-8\'?><root available-locales=\"en_US\" default-locale=\"en_US\"><Description language-id=\"en_US\">Inventory</Description></root>','<?xml version=\"1.0\"?>\n\n<root available-locales=\"en_US\" default-locale=\"en_US\">\n	<dynamic-element dataType=\"string\" name=\"description\" type=\"textarea\">\n		<meta-data locale=\"en_US\">\n			<entry name=\"fieldCssClass\"><![CDATA[aui-w100]]></entry>\n			<entry name=\"label\"><![CDATA[Description]]></entry>\n			<entry name=\"predefinedValue\"><![CDATA[]]></entry>\n			<entry name=\"required\"><![CDATA[false]]></entry>\n			<entry name=\"showLabel\"><![CDATA[true]]></entry>\n			<entry name=\"style\"><![CDATA[]]></entry>\n			<entry name=\"tip\"><![CDATA[]]></entry>\n			<entry name=\"width\"><![CDATA[100]]></entry>\n		</meta-data>\n	</dynamic-element>\n	<dynamic-element dataType=\"string\" name=\"item\" type=\"text\">\n		<meta-data locale=\"en_US\">\n			<entry name=\"fieldCssClass\"><![CDATA[aui-w25]]></entry>\n			<entry name=\"label\"><![CDATA[Item]]></entry>\n			<entry name=\"predefinedValue\"><![CDATA[]]></entry>\n			<entry name=\"required\"><![CDATA[false]]></entry>\n			<entry name=\"showLabel\"><![CDATA[true]]></entry>\n			<entry name=\"style\"><![CDATA[]]></entry>\n			<entry name=\"tip\"><![CDATA[]]></entry>\n			<entry name=\"width\"><![CDATA[25]]></entry>\n		</meta-data>\n	</dynamic-element>\n	<dynamic-element dataType=\"string\" name=\"location\" type=\"text\">\n		<meta-data locale=\"en_US\">\n			<entry name=\"fieldCssClass\"><![CDATA[aui-w25]]></entry>\n			<entry name=\"label\"><![CDATA[Location]]></entry>\n			<entry name=\"predefinedValue\"><![CDATA[]]></entry>\n			<entry name=\"required\"><![CDATA[false]]></entry>\n			<entry name=\"showLabel\"><![CDATA[true]]></entry>\n			<entry name=\"style\"><![CDATA[]]></entry>\n			<entry name=\"tip\"><![CDATA[]]></entry>\n			<entry name=\"width\"><![CDATA[25]]></entry>\n		</meta-data>\n	</dynamic-element>\n	<dynamic-element dataType=\"date\" fieldNamespace=\"ddm\" name=\"purchaseDate\" type=\"ddm-date\">\n		<meta-data locale=\"en_US\">\n			<entry name=\"fieldCssClass\"><![CDATA[aui-w25]]></entry>\n			<entry name=\"label\"><![CDATA[Purchase Date]]></entry>\n			<entry name=\"predefinedValue\"><![CDATA[]]></entry>\n			<entry name=\"required\"><![CDATA[false]]></entry>\n			<entry name=\"showLabel\"><![CDATA[true]]></entry>\n			<entry name=\"style\"><![CDATA[]]></entry>\n			<entry name=\"tip\"><![CDATA[]]></entry>\n			<entry name=\"width\"><![CDATA[25]]></entry>\n		</meta-data>\n	</dynamic-element>\n	<dynamic-element dataType=\"double\" fieldNamespace=\"ddm\" name=\"purchasePrice\" type=\"ddm-number\">\n		<meta-data locale=\"en_US\">\n			<entry name=\"fieldCssClass\"><![CDATA[aui-w25]]></entry>\n			<entry name=\"label\"><![CDATA[Purchase Price]]></entry>\n			<entry name=\"name\"><![CDATA[purchasePrice]]></entry>\n			<entry name=\"predefinedValue\"><![CDATA[]]></entry>\n			<entry name=\"required\"><![CDATA[false]]></entry>\n			<entry name=\"showLabel\"><![CDATA[true]]></entry>\n			<entry name=\"tip\"><![CDATA[]]></entry>\n			<entry name=\"type\"><![CDATA[ddm-number]]></entry>\n			<entry name=\"width\"><![CDATA[25]]></entry>\n		</meta-data>\n	</dynamic-element>\n	<dynamic-element dataType=\"double\" fieldNamespace=\"ddm\" name=\"quantity\" type=\"ddm-number\">\n		<meta-data locale=\"en_US\">\n			<entry name=\"fieldCssClass\"><![CDATA[aui-w25]]></entry>\n			<entry name=\"label\"><![CDATA[Quantity]]></entry>\n			<entry name=\"name\"><![CDATA[quantity]]></entry>\n			<entry name=\"predefinedValue\"><![CDATA[]]></entry>\n			<entry name=\"required\"><![CDATA[false]]></entry>\n			<entry name=\"showLabel\"><![CDATA[true]]></entry>\n			<entry name=\"tip\"><![CDATA[]]></entry>\n			<entry name=\"type\"><![CDATA[ddm-number]]></entry>\n			<entry name=\"width\"><![CDATA[25]]></entry>\n		</meta-data>\n	</dynamic-element>\n</root>','xml',0),('a0182724-f1f7-48a1-9d91-634bc4d059f9',10402,10180,10154,10158,'','2014-03-18 17:33:40','2014-03-18 17:33:40',10097,'Issues Tracking','<?xml version=\'1.0\' encoding=\'UTF-8\'?><root available-locales=\"en_US\" default-locale=\"en_US\"><Name language-id=\"en_US\">Issues Tracking</Name></root>','<?xml version=\'1.0\' encoding=\'UTF-8\'?><root available-locales=\"en_US\" default-locale=\"en_US\"><Description language-id=\"en_US\">Issue Tracking</Description></root>','<?xml version=\"1.0\"?>\n\n<root available-locales=\"en_US\" default-locale=\"en_US\">\n	<dynamic-element dataType=\"string\" name=\"assignedTo\" type=\"text\">\n		<meta-data locale=\"en_US\">\n			<entry name=\"fieldCssClass\"><![CDATA[aui-w25]]></entry>\n			<entry name=\"label\"><![CDATA[Assigned To]]></entry>\n			<entry name=\"predefinedValue\"><![CDATA[]]></entry>\n			<entry name=\"required\"><![CDATA[false]]></entry>\n			<entry name=\"showLabel\"><![CDATA[true]]></entry>\n			<entry name=\"width\"><![CDATA[25]]></entry>\n		</meta-data>\n	</dynamic-element>\n	<dynamic-element dataType=\"file-upload\" fieldNamespace=\"ddm\" name=\"attachment\" type=\"ddm-fileupload\">\n		<meta-data locale=\"en_US\">\n			<entry name=\"acceptFiles\"><![CDATA[*]]></entry>\n			<entry name=\"folder\"><![CDATA[{\"folderId\":0,\"folderName\":\"Documents Home\"}]]></entry>\n			<entry name=\"label\"><![CDATA[Attachment]]></entry>\n			<entry name=\"name\"><![CDATA[attachment]]></entry>\n			<entry name=\"predefinedValue\"><![CDATA[]]></entry>\n			<entry name=\"required\"><![CDATA[false]]></entry>\n			<entry name=\"showLabel\"><![CDATA[true]]></entry>\n			<entry name=\"tip\"><![CDATA[Upload documents no larger than 3,000k.]]></entry>\n			<entry name=\"type\"><![CDATA[ddm-fileupload]]></entry>\n		</meta-data>\n	</dynamic-element>\n	<dynamic-element dataType=\"string\" name=\"comments\" type=\"textarea\">\n		<meta-data locale=\"en_US\">\n			<entry name=\"fieldCssClass\"><![CDATA[aui-w100]]></entry>\n			<entry name=\"label\"><![CDATA[Comments]]></entry>\n			<entry name=\"predefinedValue\"><![CDATA[]]></entry>\n			<entry name=\"required\"><![CDATA[false]]></entry>\n			<entry name=\"showLabel\"><![CDATA[true]]></entry>\n			<entry name=\"width\"><![CDATA[100]]></entry>\n		</meta-data>\n	</dynamic-element>\n	<dynamic-element dataType=\"string\" name=\"description\" type=\"textarea\">\n		<meta-data locale=\"en_US\">\n			<entry name=\"fieldCssClass\"><![CDATA[aui-w100]]></entry>\n			<entry name=\"label\"><![CDATA[Description]]></entry>\n			<entry name=\"predefinedValue\"><![CDATA[]]></entry>\n			<entry name=\"required\"><![CDATA[false]]></entry>\n			<entry name=\"showLabel\"><![CDATA[true]]></entry>\n			<entry name=\"width\"><![CDATA[100]]></entry>\n		</meta-data>\n	</dynamic-element>\n	<dynamic-element dataType=\"date\" fieldNamespace=\"ddm\" name=\"dueDate\" type=\"ddm-date\">\n		<meta-data locale=\"en_US\">\n			<entry name=\"label\"><![CDATA[Due Date]]></entry>\n			<entry name=\"predefinedValue\"><![CDATA[]]></entry>\n			<entry name=\"required\"><![CDATA[false]]></entry>\n			<entry name=\"showLabel\"><![CDATA[true]]></entry>\n		</meta-data>\n	</dynamic-element>\n	<dynamic-element dataType=\"string\" name=\"issueId\" type=\"text\">\n		<meta-data locale=\"en_US\">\n			<entry name=\"fieldCssClass\"><![CDATA[aui-w25]]></entry>\n			<entry name=\"label\"><![CDATA[Issue ID]]></entry>\n			<entry name=\"predefinedValue\"><![CDATA[]]></entry>\n			<entry name=\"required\"><![CDATA[false]]></entry>\n			<entry name=\"showLabel\"><![CDATA[true]]></entry>\n			<entry name=\"width\"><![CDATA[25]]></entry>\n		</meta-data>\n	</dynamic-element>\n	<dynamic-element dataType=\"string\" name=\"severity\" type=\"select\">\n		<dynamic-element name=\"critical\" type=\"option\" value=\"critical\">\n			<meta-data locale=\"en_US\">\n				<entry name=\"label\"><![CDATA[Critical]]></entry>\n				<entry name=\"multiple\"><![CDATA[false]]></entry>\n			</meta-data>\n		</dynamic-element>\n		<dynamic-element name=\"major\" type=\"option\" value=\"major\">\n			<meta-data locale=\"en_US\">\n				<entry name=\"label\"><![CDATA[Major]]></entry>\n			</meta-data>\n		</dynamic-element>\n		<dynamic-element name=\"minor\" type=\"option\" value=\"minor\">\n			<meta-data locale=\"en_US\">\n				<entry name=\"label\"><![CDATA[Minor]]></entry>\n			</meta-data>\n		</dynamic-element>\n		<dynamic-element name=\"trivial\" type=\"option\" value=\"trivial\">\n			<meta-data locale=\"en_US\">\n				<entry name=\"label\"><![CDATA[Trivial]]></entry>\n			</meta-data>\n		</dynamic-element>\n		<meta-data locale=\"en_US\">\n			<entry name=\"label\"><![CDATA[Severity]]></entry>\n			<entry name=\"predefinedValue\"><![CDATA[[\"minor\"]]]></entry>\n			<entry name=\"required\"><![CDATA[false]]></entry>\n			<entry name=\"showLabel\"><![CDATA[true]]></entry>\n		</meta-data>\n	</dynamic-element>\n	<dynamic-element dataType=\"string\" name=\"status\" type=\"select\">\n		<dynamic-element name=\"open\" type=\"option\" value=\"open\">\n			<meta-data locale=\"en_US\">\n				<entry name=\"label\"><![CDATA[Open]]></entry>\n				<entry name=\"multiple\"><![CDATA[false]]></entry>\n			</meta-data>\n		</dynamic-element>\n		<dynamic-element name=\"pending\" type=\"option\" value=\"pending\">\n			<meta-data locale=\"en_US\">\n				<entry name=\"label\"><![CDATA[Pending]]></entry>\n			</meta-data>\n		</dynamic-element>\n		<dynamic-element name=\"completed\" type=\"option\" value=\"completed\">\n			<meta-data locale=\"en_US\">\n				<entry name=\"label\"><![CDATA[Completed]]></entry>\n			</meta-data>\n		</dynamic-element>\n		<meta-data locale=\"en_US\">\n			<entry name=\"label\"><![CDATA[Status]]></entry>\n			<entry name=\"predefinedValue\"><![CDATA[[\"open\"]]]></entry>\n			<entry name=\"required\"><![CDATA[false]]></entry>\n			<entry name=\"showLabel\"><![CDATA[true]]></entry>\n		</meta-data>\n	</dynamic-element>\n	<dynamic-element dataType=\"string\" name=\"title\" type=\"text\">\n		<meta-data locale=\"en_US\">\n			<entry name=\"fieldCssClass\"><![CDATA[aui-w100]]></entry>\n			<entry name=\"label\"><![CDATA[Title]]></entry>\n			<entry name=\"predefinedValue\"><![CDATA[]]></entry>\n			<entry name=\"required\"><![CDATA[false]]></entry>\n			<entry name=\"showLabel\"><![CDATA[true]]></entry>\n			<entry name=\"width\"><![CDATA[100]]></entry>\n		</meta-data>\n	</dynamic-element>\n</root>','xml',0),('421a1107-d716-4341-95c5-10506473dd23',10403,10180,10154,10158,'','2014-03-18 17:33:40','2014-03-18 17:33:40',10097,'Meeting Minutes','<?xml version=\'1.0\' encoding=\'UTF-8\'?><root available-locales=\"en_US\" default-locale=\"en_US\"><Name language-id=\"en_US\">Meeting Minutes</Name></root>','<?xml version=\'1.0\' encoding=\'UTF-8\'?><root available-locales=\"en_US\" default-locale=\"en_US\"><Description language-id=\"en_US\">Meeting Minutes</Description></root>','<?xml version=\"1.0\"?>\n\n<root available-locales=\"en_US\" default-locale=\"en_US\">\n	<dynamic-element dataType=\"file-upload\" fieldNamespace=\"ddm\" name=\"attachment\" type=\"ddm-fileupload\">\n		<meta-data locale=\"en_US\">\n			<entry name=\"acceptFiles\"><![CDATA[*]]></entry>\n			<entry name=\"folder\"><![CDATA[{\"folderId\":0,\"folderName\":\"Documents Home\"}]]></entry>\n			<entry name=\"label\"><![CDATA[Attachment]]></entry>\n			<entry name=\"name\"><![CDATA[attachment]]></entry>\n			<entry name=\"predefinedValue\"><![CDATA[]]></entry>\n			<entry name=\"required\"><![CDATA[false]]></entry>\n			<entry name=\"showLabel\"><![CDATA[true]]></entry>\n			<entry name=\"tip\"><![CDATA[Upload documents no larger than 3,000k.]]></entry>\n			<entry name=\"type\"><![CDATA[ddm-fileupload]]></entry>\n		</meta-data>\n	</dynamic-element>\n	<dynamic-element dataType=\"string\" name=\"author\" type=\"text\">\n		<meta-data locale=\"en_US\">\n			<entry name=\"label\"><![CDATA[Author]]></entry>\n			<entry name=\"predefinedValue\"><![CDATA[]]></entry>\n			<entry name=\"required\"><![CDATA[false]]></entry>\n			<entry name=\"showLabel\"><![CDATA[true]]></entry>\n		</meta-data>\n	</dynamic-element>\n	<dynamic-element dataType=\"string\" name=\"description\" type=\"textarea\">\n		<meta-data locale=\"en_US\">\n			<entry name=\"fieldCssClass\"><![CDATA[aui-w100]]></entry>\n			<entry name=\"label\"><![CDATA[Description]]></entry>\n			<entry name=\"predefinedValue\"><![CDATA[]]></entry>\n			<entry name=\"required\"><![CDATA[false]]></entry>\n			<entry name=\"showLabel\"><![CDATA[true]]></entry>\n			<entry name=\"width\"><![CDATA[100]]></entry>\n		</meta-data>\n	</dynamic-element>\n	<dynamic-element dataType=\"string\" name=\"duration\" type=\"text\">\n		<meta-data locale=\"en_US\">\n			<entry name=\"label\"><![CDATA[Meeting Duration]]></entry>\n			<entry name=\"predefinedValue\"><![CDATA[]]></entry>\n			<entry name=\"required\"><![CDATA[false]]></entry>\n			<entry name=\"showLabel\"><![CDATA[true]]></entry>\n		</meta-data>\n	</dynamic-element>\n	<dynamic-element dataType=\"date\" fieldNamespace=\"ddm\" name=\"meetingDate\" type=\"ddm-date\">\n		<meta-data locale=\"en_US\">\n			<entry name=\"label\"><![CDATA[Meeting Date]]></entry>\n			<entry name=\"predefinedValue\"><![CDATA[]]></entry>\n			<entry name=\"required\"><![CDATA[false]]></entry>\n			<entry name=\"showLabel\"><![CDATA[true]]></entry>\n		</meta-data>\n	</dynamic-element>\n	<dynamic-element dataType=\"string\" name=\"minutes\" type=\"textarea\">\n		<meta-data locale=\"en_US\">\n			<entry name=\"fieldCssClass\"><![CDATA[aui-w100]]></entry>\n			<entry name=\"label\"><![CDATA[Minutes]]></entry>\n			<entry name=\"predefinedValue\"><![CDATA[]]></entry>\n			<entry name=\"required\"><![CDATA[false]]></entry>\n			<entry name=\"showLabel\"><![CDATA[true]]></entry>\n			<entry name=\"width\"><![CDATA[100]]></entry>\n		</meta-data>\n	</dynamic-element>\n	<dynamic-element dataType=\"string\" name=\"title\" type=\"text\">\n		<meta-data locale=\"en_US\">\n			<entry name=\"fieldCssClass\"><![CDATA[aui-w100]]></entry>\n			<entry name=\"label\"><![CDATA[Title]]></entry>\n			<entry name=\"predefinedValue\"><![CDATA[]]></entry>\n			<entry name=\"required\"><![CDATA[false]]></entry>\n			<entry name=\"showLabel\"><![CDATA[true]]></entry>\n			<entry name=\"width\"><![CDATA[100]]></entry>\n		</meta-data>\n	</dynamic-element>\n</root>','xml',0),('5b518b3e-c528-4d1b-8b56-f0ca351f0cb6',10404,10180,10154,10158,'','2014-03-18 17:33:40','2014-03-18 17:33:40',10097,'To Do','<?xml version=\'1.0\' encoding=\'UTF-8\'?><root available-locales=\"en_US\" default-locale=\"en_US\"><Name language-id=\"en_US\">To Do</Name></root>','<?xml version=\'1.0\' encoding=\'UTF-8\'?><root available-locales=\"en_US\" default-locale=\"en_US\"><Description language-id=\"en_US\">To Do</Description></root>','<?xml version=\"1.0\"?>\n\n<root available-locales=\"en_US\" default-locale=\"en_US\">\n	<dynamic-element dataType=\"string\" name=\"assignedTo\" type=\"text\">\n		<meta-data locale=\"en_US\">\n			<entry name=\"fieldCssClass\"><![CDATA[aui-w50]]></entry>\n			<entry name=\"label\"><![CDATA[Assigned To]]></entry>\n			<entry name=\"predefinedValue\"><![CDATA[]]></entry>\n			<entry name=\"required\"><![CDATA[false]]></entry>\n			<entry name=\"showLabel\"><![CDATA[true]]></entry>\n			<entry name=\"width\"><![CDATA[50]]></entry>\n		</meta-data>\n	</dynamic-element>\n	<dynamic-element dataType=\"file-upload\" fieldNamespace=\"ddm\" name=\"attachment\" type=\"ddm-fileupload\">\n		<meta-data locale=\"en_US\">\n			<entry name=\"acceptFiles\"><![CDATA[*]]></entry>\n			<entry name=\"folder\"><![CDATA[{\"folderId\":0,\"folderName\":\"Documents Home\"}]]></entry>\n			<entry name=\"label\"><![CDATA[Attachment]]></entry>\n			<entry name=\"name\"><![CDATA[attachment]]></entry>\n			<entry name=\"predefinedValue\"><![CDATA[]]></entry>\n			<entry name=\"required\"><![CDATA[false]]></entry>\n			<entry name=\"showLabel\"><![CDATA[true]]></entry>\n			<entry name=\"tip\"><![CDATA[Upload documents no larger than 3,000k.]]></entry>\n			<entry name=\"type\"><![CDATA[ddm-fileupload]]></entry>\n		</meta-data>\n	</dynamic-element>\n	<dynamic-element dataType=\"string\" name=\"comments\" type=\"textarea\">\n		<meta-data locale=\"en_US\">\n			<entry name=\"fieldCssClass\"><![CDATA[aui-w100]]></entry>\n			<entry name=\"label\"><![CDATA[Comments]]></entry>\n			<entry name=\"predefinedValue\"><![CDATA[]]></entry>\n			<entry name=\"required\"><![CDATA[false]]></entry>\n			<entry name=\"showLabel\"><![CDATA[true]]></entry>\n			<entry name=\"width\"><![CDATA[100]]></entry>\n		</meta-data>\n	</dynamic-element>\n	<dynamic-element dataType=\"string\" name=\"description\" type=\"textarea\">\n		<meta-data locale=\"en_US\">\n			<entry name=\"fieldCssClass\"><![CDATA[aui-w100]]></entry>\n			<entry name=\"label\"><![CDATA[Description]]></entry>\n			<entry name=\"predefinedValue\"><![CDATA[]]></entry>\n			<entry name=\"required\"><![CDATA[false]]></entry>\n			<entry name=\"showLabel\"><![CDATA[true]]></entry>\n			<entry name=\"width\"><![CDATA[100]]></entry>\n		</meta-data>\n	</dynamic-element>\n	<dynamic-element dataType=\"date\" fieldNamespace=\"ddm\" name=\"endDate\" type=\"ddm-date\">\n		<meta-data locale=\"en_US\">\n			<entry name=\"label\"><![CDATA[End Date]]></entry>\n			<entry name=\"predefinedValue\"><![CDATA[]]></entry>\n			<entry name=\"required\"><![CDATA[false]]></entry>\n			<entry name=\"showLabel\"><![CDATA[true]]></entry>\n		</meta-data>\n	</dynamic-element>\n	<dynamic-element dataType=\"integer\" fieldNamespace=\"ddm\" name=\"percentComplete\" type=\"ddm-integer\">\n		<meta-data locale=\"en_US\">\n			<entry name=\"fieldCssClass\"><![CDATA[aui-w25]]></entry>\n			<entry name=\"label\"><![CDATA[% Complete]]></entry>\n			<entry name=\"name\"><![CDATA[percentComplete]]></entry>\n			<entry name=\"predefinedValue\"><![CDATA[0]]></entry>\n			<entry name=\"required\"><![CDATA[false]]></entry>\n			<entry name=\"showLabel\"><![CDATA[true]]></entry>\n			<entry name=\"tip\"><![CDATA[]]></entry>\n			<entry name=\"type\"><![CDATA[ddm-integer]]></entry>\n			<entry name=\"width\"><![CDATA[25]]></entry>\n		</meta-data>\n	</dynamic-element>\n	<dynamic-element dataType=\"string\" name=\"severity\" type=\"select\">\n		<dynamic-element name=\"critical\" type=\"option\" value=\"critical\">\n			<meta-data locale=\"en_US\">\n				<entry name=\"label\"><![CDATA[Critical]]></entry>\n				<entry name=\"multiple\"><![CDATA[false]]></entry>\n			</meta-data>\n		</dynamic-element>\n		<dynamic-element name=\"major\" type=\"option\" value=\"major\">\n			<meta-data locale=\"en_US\">\n				<entry name=\"label\"><![CDATA[Major]]></entry>\n			</meta-data>\n		</dynamic-element>\n		<dynamic-element name=\"minor\" type=\"option\" value=\"minor\">\n			<meta-data locale=\"en_US\">\n				<entry name=\"label\"><![CDATA[Minor]]></entry>\n			</meta-data>\n		</dynamic-element>\n		<dynamic-element name=\"trivial\" type=\"option\" value=\"trivial\">\n			<meta-data locale=\"en_US\">\n				<entry name=\"label\"><![CDATA[Trivial]]></entry>\n			</meta-data>\n		</dynamic-element>\n		<meta-data locale=\"en_US\">\n			<entry name=\"label\"><![CDATA[Severity]]></entry>\n			<entry name=\"predefinedValue\"><![CDATA[[\"minor\"]]]></entry>\n			<entry name=\"required\"><![CDATA[false]]></entry>\n			<entry name=\"showLabel\"><![CDATA[true]]></entry>\n		</meta-data>\n	</dynamic-element>\n	<dynamic-element dataType=\"date\" fieldNamespace=\"ddm\" name=\"startDate\" type=\"ddm-date\">\n		<meta-data locale=\"en_US\">\n			<entry name=\"label\"><![CDATA[Start Date]]></entry>\n			<entry name=\"predefinedValue\"><![CDATA[]]></entry>\n			<entry name=\"required\"><![CDATA[false]]></entry>\n			<entry name=\"showLabel\"><![CDATA[true]]></entry>\n		</meta-data>\n	</dynamic-element>\n	<dynamic-element dataType=\"string\" name=\"status\" type=\"select\">\n		<dynamic-element name=\"open\" type=\"option\" value=\"open\">\n			<meta-data locale=\"en_US\">\n				<entry name=\"label\"><![CDATA[Open]]></entry>\n				<entry name=\"multiple\"><![CDATA[false]]></entry>\n			</meta-data>\n		</dynamic-element>\n		<dynamic-element name=\"pending\" type=\"option\" value=\"pending\">\n			<meta-data locale=\"en_US\">\n				<entry name=\"label\"><![CDATA[Pending]]></entry>\n			</meta-data>\n		</dynamic-element>\n		<dynamic-element name=\"completed\" type=\"option\" value=\"completed\">\n			<meta-data locale=\"en_US\">\n				<entry name=\"label\"><![CDATA[Completed]]></entry>\n			</meta-data>\n		</dynamic-element>\n		<meta-data locale=\"en_US\">\n			<entry name=\"label\"><![CDATA[Status]]></entry>\n			<entry name=\"predefinedValue\"><![CDATA[[\"open\"]]]></entry>\n			<entry name=\"required\"><![CDATA[false]]></entry>\n			<entry name=\"showLabel\"><![CDATA[true]]></entry>\n		</meta-data>\n	</dynamic-element>\n	<dynamic-element dataType=\"string\" name=\"title\" type=\"text\">\n		<meta-data locale=\"en_US\">\n			<entry name=\"fieldCssClass\"><![CDATA[aui-w50]]></entry>\n			<entry name=\"label\"><![CDATA[Title]]></entry>\n			<entry name=\"predefinedValue\"><![CDATA[]]></entry>\n			<entry name=\"required\"><![CDATA[false]]></entry>\n			<entry name=\"showLabel\"><![CDATA[true]]></entry>\n			<entry name=\"width\"><![CDATA[50]]></entry>\n		</meta-data>\n	</dynamic-element>\n</root>','xml',0),('82db2e0d-0f81-432e-9e49-7d0ed6390355',10575,10557,10154,10196,'Test Test','2014-03-18 17:43:41','2014-03-18 17:43:41',10097,'10574','<?xml version=\'1.0\' encoding=\'UTF-8\'?><root available-locales=\"en_US\" default-locale=\"en_US\"><Name language-id=\"en_US\">Data Definition Name</Name></root>','<?xml version=\'1.0\' encoding=\'UTF-8\'?><root available-locales=\"en_US\" default-locale=\"en_US\"><Description language-id=\"en_US\">Data Definition Description</Description></root>','<?xml version=\"1.0\"?>\n\n<root available-locales=\"en_US\" default-locale=\"en_US\">\n	<dynamic-element dataType=\"string\" name=\"text\" type=\"text\">\n		<meta-data locale=\"en_US\">\n			<entry name=\"label\"><![CDATA[Text]]></entry>\n			<entry name=\"showLabel\"><![CDATA[true]]></entry>\n			<entry name=\"required\"><![CDATA[false]]></entry>\n			<entry name=\"predefinedValue\"><![CDATA[]]></entry>\n			<entry name=\"tip\"><![CDATA[]]></entry>\n			<entry name=\"width\"><![CDATA[25]]></entry>\n			<entry name=\"fieldCssClass\"><![CDATA[aui-w25]]></entry>\n		</meta-data>\n	</dynamic-element>\n</root>','xml',0);
/*!40000 ALTER TABLE `DDMStructure` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `DDMStructureLink`
--

DROP TABLE IF EXISTS `DDMStructureLink`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `DDMStructureLink` (
  `structureLinkId` bigint(20) NOT NULL,
  `classNameId` bigint(20) DEFAULT NULL,
  `classPK` bigint(20) DEFAULT NULL,
  `structureId` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`structureLinkId`),
  UNIQUE KEY `IX_C803899D` (`classPK`),
  KEY `IX_D43E4208` (`classNameId`),
  KEY `IX_17692B58` (`structureId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `DDMStructureLink`
--

LOCK TABLES `DDMStructureLink` WRITE;
/*!40000 ALTER TABLE `DDMStructureLink` DISABLE KEYS */;
INSERT INTO `DDMStructureLink` VALUES (10580,10097,10579,10575),(10804,10089,10801,10308);
/*!40000 ALTER TABLE `DDMStructureLink` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `DDMTemplate`
--

DROP TABLE IF EXISTS `DDMTemplate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `DDMTemplate` (
  `uuid_` varchar(75) DEFAULT NULL,
  `templateId` bigint(20) NOT NULL,
  `groupId` bigint(20) DEFAULT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `userId` bigint(20) DEFAULT NULL,
  `userName` varchar(75) DEFAULT NULL,
  `createDate` datetime DEFAULT NULL,
  `modifiedDate` datetime DEFAULT NULL,
  `structureId` bigint(20) DEFAULT NULL,
  `name` longtext,
  `description` longtext,
  `type_` varchar(75) DEFAULT NULL,
  `mode_` varchar(75) DEFAULT NULL,
  `language` varchar(75) DEFAULT NULL,
  `script` longtext,
  PRIMARY KEY (`templateId`),
  UNIQUE KEY `IX_1AA75CE3` (`uuid_`,`groupId`),
  KEY `IX_DB24DDDD` (`groupId`),
  KEY `IX_33BEF579` (`language`),
  KEY `IX_C9757A51` (`structureId`),
  KEY `IX_5BC0E264` (`structureId`,`type_`),
  KEY `IX_5B019FE8` (`structureId`,`type_`,`mode_`),
  KEY `IX_C4F283C8` (`type_`),
  KEY `IX_F2A243A7` (`uuid_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `DDMTemplate`
--

LOCK TABLES `DDMTemplate` WRITE;
/*!40000 ALTER TABLE `DDMTemplate` DISABLE KEYS */;
INSERT INTO `DDMTemplate` VALUES ('a3f6ee69-066b-438f-8854-c55517fb0f9f',10586,10557,10154,10196,'Test Test','2014-03-18 17:44:25','2014-03-18 17:44:25',10575,'<?xml version=\'1.0\' encoding=\'UTF-8\'?><root available-locales=\"en_US\" default-locale=\"en_US\"><Name language-id=\"en_US\">Data Definition Form Template Name</Name></root>','','detail','create','xsd','<root available-locales=\"en_US\" default-locale=\"en_US\"><dynamic-element dataType=\"string\" name=\"text\" type=\"text\"><meta-data locale=\"en_US\"><entry name=\"label\"><![CDATA[Text]]></entry><entry name=\"showLabel\"><![CDATA[true]]></entry><entry name=\"required\"><![CDATA[false]]></entry><entry name=\"predefinedValue\"><![CDATA[]]></entry><entry name=\"tip\"><![CDATA[]]></entry><entry name=\"width\"><![CDATA[25]]></entry><entry name=\"fieldCssClass\"><![CDATA[aui-w25]]></entry></meta-data></dynamic-element></root>'),('6ab76d43-25b1-4772-934b-cf546ef05fe4',10588,10557,10154,10196,'Test Test','2014-03-18 17:44:44','2014-03-18 17:44:44',10575,'<?xml version=\'1.0\' encoding=\'UTF-8\'?><root available-locales=\"en_US\" default-locale=\"en_US\"><Name language-id=\"en_US\">Data Definition FreeMarker Display Template Name</Name></root>','','list','','vm',' #set ($ddlRecordService = $serviceLocator.findService(\'com.liferay.portlet.dynamicdatalists.service.DDLRecordLocalService\'))\n #set ($recordSetId = $getterUtil.getInteger($reserved_record_set_id.data, 0))\n #set ($records = $ddlRecordService.getRecords($recordSetId))\n #foreach($record in $records)\n #set ($fields = $record.getFields())\n #set ($nameField = $fields.get(\"text\"))\n <div style=\"padding-top: 10px;\">\n <img height=\"100\" src=\'/documents/ddm/${className}/${classPK}/${fileName}\' width=\"100\" />\n <span style=\"padding-left: 5px;\">\n $nameField.getValue()\n <span>\n </div>\n #end\n');
/*!40000 ALTER TABLE `DDMTemplate` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `DLContent`
--

DROP TABLE IF EXISTS `DLContent`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `DLContent` (
  `contentId` bigint(20) NOT NULL,
  `groupId` bigint(20) DEFAULT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `repositoryId` bigint(20) DEFAULT NULL,
  `path_` varchar(255) DEFAULT NULL,
  `version` varchar(75) DEFAULT NULL,
  `data_` longblob,
  `size_` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`contentId`),
  UNIQUE KEY `IX_FDD1AAA8` (`companyId`,`repositoryId`,`path_`,`version`),
  KEY `IX_6A83A66A` (`companyId`,`repositoryId`),
  KEY `IX_EB531760` (`companyId`,`repositoryId`,`path_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `DLContent`
--

LOCK TABLES `DLContent` WRITE;
/*!40000 ALTER TABLE `DLContent` DISABLE KEYS */;
INSERT INTO `DLContent` VALUES (10439,0,0,0,'10437.png','1.0','�PNG\r\n\Z\n\0\0\0\rIHDR\0\0\0P\0\0\0l\0\0\0rˢ,\0\0\0	pHYs\0\0\0\0\0��\0\0�IDATx��\\ypWz��{}Lϡ�H�t!!#q�56, ��02v`���dC�J�o���c������k�v�I%�Ty��m��7h9ls���8�$$�����3}��?j���H��WS]��ݯ��������c,�]�0!TC���v;s�9.�c,��p�??�����\r�>p�\0c,��R\n\'�WV��>R9�����N�>�sw���3+J�u�x��2�TMG�}����`$S��i��||AaA~f	�A)�,/�7����.v^nl>�U��s/-{|���������[�ǵ`N���5gε�����8��{�uO:ǭ����5�����w{>���|<�z��5n�r���al.���~�����;/��\'{5M�sQ�[�t���gϷ������c^�jiE��#_6uv]y���!�\\�����\'�������5U�=;.��K�惏:��QV`\0�y��Rg�(���SW��~��/�(��b\0@\0�P2��{bau��c�O\\�*˒�\'�F���z�NQ�;��pތ3��Ϝ�X]U6��_��|���$;c�p|˺+�~��r�ы�²\"jh�� �]\r�vVWO�t�J��Z����̊$��ġ��AE)���\'�_��M��X\03ٕ���%�9����\0���\\�/7`-��\"�rnn��p��s<^|��H��ҢS�����1\n�g\'aJ�z�(5�aPÎ�#jP�ÌQ�0ð��w���UM=N��yy�^���P�~��Νi�(\0��iXJ���`�\0���?F>�\0��kM���qK쮸��\0����T��3\00����\0R�\"�0�pH�blEI\"a��c���2|ҠK����nE\0AB}��H2j�xI<4$3�@*���!��c\'I�!��%.�u����vMMe)�2�$�\0s�����bJ)�lys�\0`ݚ�C���wK����ҽ�a��	�� J\0�1V�4{b.\0x<��3��F\"��f�.�G��;L\rm�[�1�$�0iH�z���㶗Z[[�>�/(��������ӧ>��ⱋ����}���_d˺����nic��w\nXWSI�s*f���5��D<>eڬ��s55��z���})��&������/��a�E�����F	!�#�H� �\"�\0�	����)]S����u��/�c��Q;[�������Ӛ\0<x��	�^z�0�euBx�;#��Eu��qW^�V��f��$N�Y�VRgF2\0���T]�\r��-D����aMZJi2��4�n�)MK��]\0,��G&���E���Hi�%>\0���r�ȹ� :\"G�#-(\Z�,�?��ϛ�����/������p9%�ɲ�Iw0B�����גּ����|��9B���Ғ��{�Ͽs�l��̙H$J�	��y>_mm\r\0`B\0�X�����{U�WJ�,���Ρ��>ݔJ�Y�g]�K�J�TT�)�x,�űS�f�n+2��3GOTUN�dy���J�d��a�D m���KK)��ݹ�]01��i�\"������y��05���N�N\r�\\�2#9�oWֱ�n��bZ�\"��ԴA�\0ȟT�W^T��%S�kwE��A\rU�l��b�RJ�9\n1�ԔF�j�2t�{&J\rCW��J��5&�^�`Z�\'\0O\0�\0<��J#�H���x`�a|�}!$ˢ$�Y�� <=��QÖx�6����D���mf̮;D�648�	`�D�ΞQ��iK�^Fx�@��$S�S�p�_��`��U�Ģp$Bl�;34c�c�$�K��-Y|5pM �n�R������)�۶�J��,�v]�KJ&ߝli���q$�N)�9ِY��aiA\0�������1y\Z��Ν{/K<cm���uy���^8\Z	/�7k��9��M�/����a�2	�W�1(���߹�D����x4���E��{�����i3�h��Q ��\\\n��Ձ�c\nu*v�{���(\0|����PH�������6?wo%L\"�X$(��CH\"�(\0 ˲INY�,h��F��^�\0N�d[ċ��8�J�1I��e��X���[�dv�`l,�\'����0�5L��Q��q��<�c��(���T�.�*��HUU�ɤ�3�/;���HD��D� \"A0R\0�\Z�\r�m�+\"���@�kFB��L+��>n��4-��n��7�w�].ww����~Jm\'�\r\r.�9\0\\ok�.�`ʘD#��Pj̩Vr�R�����e�9�ôB��������������3f���f�k�r�=\0���6lLĳ�&Dѡ8�7��3P#�fA��3�8����{����b�cL�@yr�c5\'Qt�c=Xw݆o��F�4�����+q�[M���:!�a�`0���_PP�v��\"Wi�1G�1�~���<�������>��ш�a�t!�\0\0�p8\nɲ��z}>���!�+��O6q�h1ƌ1�����4������_�e����zo;z�)%l�l�\0:�:%��CߥiZ0�� 8����x�N�,��1`�Y��`M��.���QJc�X$	�s�I�$������*m2�f\"	8��)��h4�pvE�$I�e�����(��H��OA���f��-���ˌ���c�a���X,Ə�ю\"� �(�KA�p3�H�<k�i7�n�I�?�V��J�R+�1��#��\Z���j�:��x�F�y?<�3��M�BDQ�e��vGcQ�0`4�b�ߑ.��agߕq��S�<�zV�:7\"˃s\Z��ŀM�z�w@�&W��K�bק�>�a�Q���#;�,>�������3���t֥��nd��5�Q��5[{�QG�u��Wu8��D\"��(�㡡!Q%I�_�K�j;#���T\'��o9��i�c�����p�T	gmN��ԩS���?��eY��R�\'?�ɦM�.^���x���֭[W�X�|��&��5�7>9m�X�4��C�䅌h�<��͗�\0I�����;��\n\07����ƣG��B!����o�۷���bΜ9>����:u]O�9M���9o7�y�xK��4#���xq�efZ�J�.�H3f���ON��x�X,VRR��joo/\0l۶��_���EQӴ��.EQ&O��i�����B�P(���N�SӴ��^M�rss����񸙟������4f�}Z`#^�3���0mӪ!i\Z%��~���_~9l߾}׮]\0��hÆ\rn��ĉ���+W�\\�l�+����|>�g�}�jժ��z륗^z��\'�?��ݽe˖իW�]�v������/].�믿�v�ړ\'O�\\.��}�ȑ��z�w�Q%M�ޑ[\Z���B-Ӭ�o��Gr2~̅Z[[��hNN�G~~~WW�֭[;::����._���?���p8B�Pww��o�����r����^}�զ���{n�֭�T�g?�YGGGMMMOOϞ={8!۳gO ����e�zu�q�&u3\'Zc�F�$�v����#�\0躾cǎ\r6\0������_����>\n������}�ݝ;w����޽����|(|����~ZYY��/��替��/~��̚5\0z{{ׯ_/¡C���h8>z����^�b��ii�����bL2�a��[��4���\'M������aܙq����\n\0�w�>r�B����Rz��%x��˗/O�R\0P__�k׮�7�>}:s[�6mZ]]]CCC[[B(�_����,����&�&x��2�%�|��<3s��][9�5�Y{����v{�^]׿��o�QPP\0�������������l�ƍ\'O�lii��ڰaCCC����]q�[�-i���M�F ���`L]�|��F+f0�RV\'i\n�_պ>e�\0x��g�o߮iځ�n�̙3O�:�U��r������ܼhѢ������o}���EQ]�����~������K�,1C�4�#u[ wZ� ����2��ʥMfk>ԓ\'O>��c�\0Mӊ��w�����*`.�y晷�~��?�innnoo�k��V]]}��1~�!Q)��$����������u�޽\0�L&	!����֭{��\0��_,))�D\"��︡4	�t��\'������z����i����,˜r����9s�̙3���.\\@�\\.NN\0�ױ�a˖-۱cG<߶m�k��VTT��o���q��t:	!��/]�����S�O>�d˖-\0�����p���^}}=�Ҵ&I���B\0�����>�{��]�xb�_orܪ�v\r!�L&�_���	!~�����T���ɲ\n�b������EikkkiiEq�����D\"�H\\�~��t����Nt]?|�p\"�X�x���r�$I���n����uuuUUU��d�\Z 3�n�����������f\0�T�|v�DwO`��\n����%i$��r��d��4���!��:����:\0��Z]]][[��UU%�����|>��4޹$Ik֬�\'�I�0���!���������`���EEE�p�,�����I��7��{��z��8\0�}���ѯN5��Gb�¶Vm2��7f�!�fo��0�<����o� Boo����}\0���{�W4M��v�l\0\Z��\'�ꌚ�q�������셎�K=USJ�0�r��w޲\'񺮯\\��ĉ�(��Ԉ���u�#M����C��ΖM.�}��&�X�x~[{�>;�RI���Hxf�J���o�򤬧��Ey��G�\n׎�j���\0��/�������n�����\'�1���J��#ٵ]�z�m�ӑM�PM{I�#i��)��766��;�f��i�������\\�?x���TV,]�E2�-�1M:��#i)K������..��Y��M ��Gb������7_��n�4D6�>����������3�w�n�p�kZuŚ�K&Mz��\Z=�|��hҦgV��u�5NU��~~�ȗ�\"̛]�`n���� |J�/8x������h,>ov횕K<ng�mڙbǥ�Ott�`�K�&��M..���x���3�\"�X�o�r��˽}��Z:�`��Κ^�9Ld�=�A;������u�w�zX�u�0�w�2c�`����J�f�N}dj�$\nY���i���C�p$�j$�|;XI�������M��u8F���\0U�SC��;A\0\0\0\0IEND�B`�',5176),(10440,0,0,0,'10438.png','1.0','�PNG\r\n\Z\n\0\0\0\rIHDR\0\0\0�\0\0\0�\0\0\0��g-\0\0\0sRGB\0���\0\0\0bKGD\0�\0�\0�����\0\0\0	pHYs\0\0\0\0\0��\0\0\0tIME�(\0-���\0\0�IDATx��]y�\\U����^�W�	�$ @4���1����0�,��\"�	����̈��}�爣3�(��2DE�qaD\\��\"� `LH����-�����y�tUWUw��>���kyﾻ��9�s�-@�P(\n�B�P(\n�B�P(\n�B�P(\n�B�P(\n�B�P(\n�B�P(\n�B�P(��^o`%�N�6�\0$�P	8�������H1�SnpD\0���L�ɔ�ۿ��\0�$\0��xS��$3II�\0�^��A��/6u�=����W�\0��o*���}FQ�>��S�^���=������}����ޟeY�����_^�x� �\"\'�{^�OHz\0��ܹg�HP�TnWф0X�p�I�=e���A�M~1H�}/�	$[[������%����Y�R��X8*�CU�fo{�������`�M�ʝq�/��v#���\0Aܰ��˚A,��?�v�P�2G�1>}��i�\0�>���ʥ4z��Km{ �p[੕�p���ظ	��旯�а����\Z+W�mZ���\\qޛ1{V?]U��M/x^�}�Q1}	�y�JX[I:	P	|����S��*�����L\0!��\'ʶ�L�mc�3� \'�B	��ȗK��@�#\n��Tn5�3�����J P\r��jj�/�������\0�pl�\\�`�P�o �0P��_P��P��\n������V� 2\r�~���c�@?|��\'qSۭ`R5������]f5-oxĠ\ZV��`��D�~�n�3`��N�$��az~&��W�������S��,ۂ�R�VI�J��,]��t��a��R�����p�}�-�MD����^��Y9�4πO3����D_ؾd#�\'��Xob6�0gf�ͩN�ʹQ��a.��f�8iJ\08��#0dR,��Z�I��gb�]k�+�c�sϮ�Q�sr�8��`ФXo2l�^���ߩ:-��iC@��P���$6	�P�a��)(=!B�;B��=T|A=ΐ�┨�D��/��^�Up(���ٍ�,h^�3�$XgR�3)�l��ӯO���o�\0���@�C��I��۴�|��J�RN���H��0�i�\0�\niF����f䛖������&�ۡ�ó�I�4#M��8U��9R���q�nn�����}�tG���:���%��vP�l5;E���\0��\0}a^�D��1g����%��.�����I���a8�G%��z���CFgSz��b�K�̤0�D��z0<<|o�V{�&�\'��I�26�(�Ue�_�s�c���%��@[;zY��T\"n��e˖�u���SD�k��S&��6�s��̋��]�oo�f$��1s��˙0��̌<<�r\r�Y����G`��3�׼9h(�g��j�o?�$Yk	����u4�6!~����l�~6�0bsˆ$���f㰽g�_o^�/�����O��2��} �p�;�U%`���c�����w�U<̨x��֧���y����x���(Ȧ��xگ��[\'�	�`�<�`��b}=�m��4ӄT%`S��{8j�` �vy��8Æ�|6Æ8C�~>*Ӕ�cI��|���n֕�g<�J>��N�L�|J�q�nA��(@�G���R�}��N�*�ڂ7�����ء�/�޻kR:�|�>���f�\0U�urǪ��j�Z�ß��z�aФȨjW	�	�0����TR����]=�]pa8�sD���H2��\Zc�P��0C���f�2m8N��k)��M�uK��/8u�l��-m�Y}9�����pʱ���;�lJP%���j���--G�٦�D6�w��Z�A\0�$A��Z�i*\"\0<��Ìj��CX	���p�l��k�S���z���4q��&�i�l�w�zԼ��[x�\'�>��	.z�	x�q��݈�^� h���?���e����\'R}� �x��9�0�&ηN�Ö�H�ğW�Ê������Cu\0�sk��+��+�2�e�sM�o����]d��WO�~$��\r:\'�F7&�+�]�Lo7#�բp��&İ)�/-�v*�0�m6J>��*����t�|��]%�V^�`(��n��]��M�zL@8�צ��i�`�n���X#q���1ґ:ҤI�gY�c:TN[̈|��\0L���\"��}��8�^�f�i�ᰅ�\0\0N:��>wxMRo`��	��P��S��t�O����=g�mŜx�¶�>��8��][�@o�jN��%�)7Tno+W�lpz͊���k����\0�\0F�{��2���\0�^\"a�؀�5�DU�#�<r�����;s�\\���3�Bg�qhhhɭ߹�\"���N��))Q��B�O��>�я�	��V7���l\nJz��|���Z�/Y�|�ڛo�q]%�Ʊ��J��U������w&�\0��(۵$S\0ibM�K�Փ.~\'	�\rb/��\0���)\n�B�P(\n�B�P(��D�6�n�P?�&\"\'�ྸ�_I��w�۟�Uȓ\0 ��%�\\?��~VE�\Z\0�t�t1�O��./�{,�w���0���1\'�Q�\0\\`��}�u\0ψ�r\0�c��B�z5�������L�����~��Ɲ���\Z����v�x\r��HF�O\0>�Z�a��1:j���2e\\ ��	����niq��P\0M����\0X^j[�S&Ґ�a5���!oq?I�\"� �~C����L2���sOpM����?�qw��D7��u+UI�\'\"o%���L�b�;�\0YC�ɉ�Db�c\"�����s-nI�r�PL#\"k��{� ���-=�P0n�\0ָkǮ��,��u��ߵw�}\'\"�\0�RD��a�]?��$��|7��\'D~�b�֓<�4�$�G����{;�����OnV�1f���?E:�5��$�up��	��Hu|-)U\05�7|W/����1\0�Ӧ�\r[Ie���TJ��s\0�[T��i�W8���D=�A���	J�E�ƾ��,iѾo��\0�%��B?��Z��.̕Jo�5�d��Ҩr&;�?�Y�8��\\�Z������)����:(�g���ĘƐP���\0W�`I5�M� �&��y�|���\Z�˃(�31�OM� �(���M=���\0��P\n�L�`W��c�ifkM	l���m�,����zj�\"�Ҥ���A�\"?\'R�\Z&;];w%��q�]�ץ�J\0��a��v�a�#EsI^���WlC$�\\(\"?+���oEd����0<��pח���7�a跲EdQA\\\'#yOE�6�qDa���<�ܾ�^Gq��\0�eY痤�E\0~�`o��l�V��z�&���8@[�$���\\/צ��J��$�hYm�<�����\0���\"����@�mmw���\0>�FN\0p���\'��?�8�6ŶGJ�ђ�\0�颜C���\'1fXD�x��霤����~!\"���p���k���_--��1�C����+C!)�ю� �<�G;	7L�.\'���5,J�����J$�Ȱt����}XDvv�?�Z��pj�����z�C5^����U��K �6p��#KR�=��<:�`Ɇ$��A�<���	�YN`�A��pj؀����d���}��_�{���h��{\0F\n���ki��J����V�\"r�����~?1f�p��H�;;b�N���V��\Z]+\0�_��	ɽ\0��\r7�C���R��&�x�gJ��ND�b\"��]�[!H���|��2D�G���N�^�������M	�!��(e�|���O����Tb��J�6��V���!����BID���Z�AQ�-��b{�a�Gi���6I+I^�|��x�E�\n�hn�� \"�\0�xG}0������t�������?�ѱ`�����vW\0��8�6m����-�=���\0ʹ�\0.�$5˥<�ő�I����g��u����(:)1���,���8�%:�+�9@�������#����axZ���YNo��\Z�ovv�^��u$�	�h���5 \"/!y�Jõ��ȥ�1��{^&\"{����ȳ-��C\0��������2v�!�A-�SKI���w}��[;�S�W6��	���2;M���z��[\n�TnC�-$�H��\"rKb��.&�a\"�<�A���ۥٵ�X&\"\'[D^��>���o�Y�ȩ%	X�����>ݓt�i��|@��|����<��\0<ԊXN��$w��x�QIry���7����lH!y�+��m�^��8�W2;�F7�/����\0|�1�61��]�a��`\0�Eb��&�����r�&:i��c�e�㧩��OR��,\"G����֮i�^�\0XD��d\"rTEW&�lh�_��\0�P\Z��v�o�H@�#׶O*[p�,r�@�r��P�OR��+�>��{cV��N�I���k�$ו%����\r�3\r[Vj?����ۍB$yRE�H���	>���s��.�6l�j�>PC����H��<=+�\"�Uc�V\0�#G!\r�����n����8�3\n��܍�\0��#9��b�`�ƭs�E?�ܲ$�3�o��p>����U��������7wQ��nᕈ��u(�\0\\�h� �^��L	؃H��&���\0�.��{\"r��������w.�N�>L���ڵJ�y.�a��.���}&�����1�\0������ꏃ(j��H�������S�g>-\"up+���(�Y	�ۋ�s��K��}\0n�hv�Ŝ�Ǝ��ԊĘ�������������x=�5$���bo���9$HD��ȼz\"g���6��X�:7�1~�J��V��E�`\0+1��B`\0K�0�ka����Lg�-��d�����r�����O�G��<Sy�=�\r\0>�Bj]QZ4|i�ҸAi��+��:���e�\0�Qt���\0^��흦>5���Hi�\0�g����NA���A��1_S�	�m�Rk���(r�>���*{F�(7LVD�k�\0\n���}\'Z��Ծ�M��I��×nrM#9��9\"�3����\0��$�J�eC9�0�1mi2��x�Or��q	������!\0�m���Y3�&���|����Y��S���QTC~@��\\!\"���yp/��\0�K���|�1���V)mn�܍�4�U\"���q�C�cp��?�h;�b��nY#��1)�k2��m�D��mJ��\0���\Z�����M)�Qt!Ʌ\"��R�UE�?���W��I�yl��Gr9�ߑ<ح�I��A�38�$��5kg��~���E���T���e㉊m\Z��~��(�\\e+��-7��>��׻f�*k,[GHz\r�=�[�\0�F��X�\Z�ג��}v�$J?���ȯ\ZƼ\n��1����a�&��-�>�8y(��񘻂�D҅<�eCVFED�\"i����l�3\0�\r�Iw�`�$��z\0w���\0	g1ކ:�\"yg�d�@D��u?O���!<\0�;_��-`�~���-$w���m�,��p�;��ObX�dR=��by��\0<\0�B�P(\n�B�P(\n�B�P(\n�B�P(\n�B�P(\n�B�P(\n�B�P(\n�B�P(\n�B�P(�f�%�`Ćh�\0\0\0\0IEND�B`�',5695),(10794,0,10154,10778,'1','1.0','This is a *.txt document.\nThis is a *.txt document.\nThis is a *.txt document.\nThis is a *.txt document.\nThis is a *.txt document.\nThis is a *.txt document.\nThis is a *.txt document.\nThis is a *.txt document.\nThis is a *.txt document.\nThis is a *.txt document.',259);
/*!40000 ALTER TABLE `DLContent` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `DLFileEntry`
--

DROP TABLE IF EXISTS `DLFileEntry`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `DLFileEntry` (
  `uuid_` varchar(75) DEFAULT NULL,
  `fileEntryId` bigint(20) NOT NULL,
  `groupId` bigint(20) DEFAULT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `userId` bigint(20) DEFAULT NULL,
  `userName` varchar(75) DEFAULT NULL,
  `versionUserId` bigint(20) DEFAULT NULL,
  `versionUserName` varchar(75) DEFAULT NULL,
  `createDate` datetime DEFAULT NULL,
  `modifiedDate` datetime DEFAULT NULL,
  `repositoryId` bigint(20) DEFAULT NULL,
  `folderId` bigint(20) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `extension` varchar(75) DEFAULT NULL,
  `mimeType` varchar(75) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `description` longtext,
  `extraSettings` longtext,
  `fileEntryTypeId` bigint(20) DEFAULT NULL,
  `version` varchar(75) DEFAULT NULL,
  `size_` bigint(20) DEFAULT NULL,
  `readCount` int(11) DEFAULT NULL,
  `smallImageId` bigint(20) DEFAULT NULL,
  `largeImageId` bigint(20) DEFAULT NULL,
  `custom1ImageId` bigint(20) DEFAULT NULL,
  `custom2ImageId` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`fileEntryId`),
  UNIQUE KEY `IX_5391712` (`groupId`,`folderId`,`name`),
  UNIQUE KEY `IX_ED5CA615` (`groupId`,`folderId`,`title`),
  UNIQUE KEY `IX_BC2E7E6A` (`uuid_`,`groupId`),
  KEY `IX_4CB1B2B4` (`companyId`),
  KEY `IX_F4AF5636` (`groupId`),
  KEY `IX_93CF8193` (`groupId`,`folderId`),
  KEY `IX_29D0AF28` (`groupId`,`folderId`,`fileEntryTypeId`),
  KEY `IX_43261870` (`groupId`,`userId`),
  KEY `IX_D20C434D` (`groupId`,`userId`,`folderId`),
  KEY `IX_64F0FE40` (`uuid_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `DLFileEntry`
--

LOCK TABLES `DLFileEntry` WRITE;
/*!40000 ALTER TABLE `DLFileEntry` DISABLE KEYS */;
INSERT INTO `DLFileEntry` VALUES ('6cb91ae9-12bb-4442-b7dd-1b6df193154e',10792,10778,10154,10196,'Test Test',10196,'Test Test','2014-03-18 17:55:13','2014-03-18 17:55:13',10778,0,'1','txt','text/plain','DM Document Title','DM Document Description','',0,'1.0',259,0,0,0,0,0);
/*!40000 ALTER TABLE `DLFileEntry` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `DLFileEntryMetadata`
--

DROP TABLE IF EXISTS `DLFileEntryMetadata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `DLFileEntryMetadata` (
  `uuid_` varchar(75) DEFAULT NULL,
  `fileEntryMetadataId` bigint(20) NOT NULL,
  `DDMStorageId` bigint(20) DEFAULT NULL,
  `DDMStructureId` bigint(20) DEFAULT NULL,
  `fileEntryTypeId` bigint(20) DEFAULT NULL,
  `fileEntryId` bigint(20) DEFAULT NULL,
  `fileVersionId` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`fileEntryMetadataId`),
  UNIQUE KEY `IX_7332B44F` (`DDMStructureId`,`fileVersionId`),
  KEY `IX_4F40FE5E` (`fileEntryId`),
  KEY `IX_A44636C9` (`fileEntryId`,`fileVersionId`),
  KEY `IX_F8E90438` (`fileEntryTypeId`),
  KEY `IX_1FE9C04` (`fileVersionId`),
  KEY `IX_D49AB5D1` (`uuid_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `DLFileEntryMetadata`
--

LOCK TABLES `DLFileEntryMetadata` WRITE;
/*!40000 ALTER TABLE `DLFileEntryMetadata` DISABLE KEYS */;
INSERT INTO `DLFileEntryMetadata` VALUES ('26d5416c-1e84-44d7-8ef9-67a1b1a1f1a2',10801,10802,10308,0,10792,10793);
/*!40000 ALTER TABLE `DLFileEntryMetadata` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `DLFileEntryType`
--

DROP TABLE IF EXISTS `DLFileEntryType`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `DLFileEntryType` (
  `uuid_` varchar(75) DEFAULT NULL,
  `fileEntryTypeId` bigint(20) NOT NULL,
  `groupId` bigint(20) DEFAULT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `userId` bigint(20) DEFAULT NULL,
  `userName` varchar(75) DEFAULT NULL,
  `createDate` datetime DEFAULT NULL,
  `modifiedDate` datetime DEFAULT NULL,
  `name` varchar(75) DEFAULT NULL,
  `description` longtext,
  PRIMARY KEY (`fileEntryTypeId`),
  UNIQUE KEY `IX_E9B6A85B` (`groupId`,`name`),
  UNIQUE KEY `IX_1399D844` (`uuid_`,`groupId`),
  KEY `IX_4501FD9C` (`groupId`),
  KEY `IX_90724726` (`uuid_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `DLFileEntryType`
--

LOCK TABLES `DLFileEntryType` WRITE;
/*!40000 ALTER TABLE `DLFileEntryType` DISABLE KEYS */;
INSERT INTO `DLFileEntryType` VALUES ('bcd4839b-c50b-4591-8cb5-9f99244f0a63',0,0,0,0,'','2014-03-18 17:33:31','2014-03-18 17:33:31','Basic Document',''),('0c18999b-e1d8-4e1a-a6eb-f23f8f3134b8',10300,10192,10154,10158,'','2014-03-18 17:33:39','2014-03-18 17:33:39','Contract','Legal Contracts'),('1b6bae0b-a340-4a8e-a9f6-6226b39c9d1b',10302,10192,10154,10158,'','2014-03-18 17:33:39','2014-03-18 17:33:39','Marketing Banner','Marketing Banner'),('5fff7bec-6c68-4bed-9ae9-92432f773859',10304,10192,10154,10158,'','2014-03-18 17:33:39','2014-03-18 17:33:39','Online Training','Online Training'),('73b58585-93c7-4e02-bf7b-002641a4eab6',10306,10192,10154,10158,'','2014-03-18 17:33:39','2014-03-18 17:33:39','Sales Presentation','Sales Presentation');
/*!40000 ALTER TABLE `DLFileEntryType` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `DLFileEntryTypes_DDMStructures`
--

DROP TABLE IF EXISTS `DLFileEntryTypes_DDMStructures`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `DLFileEntryTypes_DDMStructures` (
  `fileEntryTypeId` bigint(20) NOT NULL,
  `structureId` bigint(20) NOT NULL,
  PRIMARY KEY (`fileEntryTypeId`,`structureId`),
  KEY `IX_8373EC7C` (`fileEntryTypeId`),
  KEY `IX_F147CF3F` (`structureId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `DLFileEntryTypes_DDMStructures`
--

LOCK TABLES `DLFileEntryTypes_DDMStructures` WRITE;
/*!40000 ALTER TABLE `DLFileEntryTypes_DDMStructures` DISABLE KEYS */;
INSERT INTO `DLFileEntryTypes_DDMStructures` VALUES (10300,10301),(10302,10298),(10302,10303),(10304,10297),(10304,10305),(10306,10299),(10306,10307);
/*!40000 ALTER TABLE `DLFileEntryTypes_DDMStructures` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `DLFileEntryTypes_DLFolders`
--

DROP TABLE IF EXISTS `DLFileEntryTypes_DLFolders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `DLFileEntryTypes_DLFolders` (
  `fileEntryTypeId` bigint(20) NOT NULL,
  `folderId` bigint(20) NOT NULL,
  PRIMARY KEY (`fileEntryTypeId`,`folderId`),
  KEY `IX_5BB6AD6C` (`fileEntryTypeId`),
  KEY `IX_6E00A2EC` (`folderId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `DLFileEntryTypes_DLFolders`
--

LOCK TABLES `DLFileEntryTypes_DLFolders` WRITE;
/*!40000 ALTER TABLE `DLFileEntryTypes_DLFolders` DISABLE KEYS */;
/*!40000 ALTER TABLE `DLFileEntryTypes_DLFolders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `DLFileRank`
--

DROP TABLE IF EXISTS `DLFileRank`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `DLFileRank` (
  `fileRankId` bigint(20) NOT NULL,
  `groupId` bigint(20) DEFAULT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `userId` bigint(20) DEFAULT NULL,
  `createDate` datetime DEFAULT NULL,
  `fileEntryId` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`fileRankId`),
  UNIQUE KEY `IX_38F0315` (`companyId`,`userId`,`fileEntryId`),
  KEY `IX_A65A1F8B` (`fileEntryId`),
  KEY `IX_BAFB116E` (`groupId`,`userId`),
  KEY `IX_EED06670` (`userId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `DLFileRank`
--

LOCK TABLES `DLFileRank` WRITE;
/*!40000 ALTER TABLE `DLFileRank` DISABLE KEYS */;
/*!40000 ALTER TABLE `DLFileRank` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `DLFileShortcut`
--

DROP TABLE IF EXISTS `DLFileShortcut`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `DLFileShortcut` (
  `uuid_` varchar(75) DEFAULT NULL,
  `fileShortcutId` bigint(20) NOT NULL,
  `groupId` bigint(20) DEFAULT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `userId` bigint(20) DEFAULT NULL,
  `userName` varchar(75) DEFAULT NULL,
  `createDate` datetime DEFAULT NULL,
  `modifiedDate` datetime DEFAULT NULL,
  `repositoryId` bigint(20) DEFAULT NULL,
  `folderId` bigint(20) DEFAULT NULL,
  `toFileEntryId` bigint(20) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `statusByUserId` bigint(20) DEFAULT NULL,
  `statusByUserName` varchar(75) DEFAULT NULL,
  `statusDate` datetime DEFAULT NULL,
  PRIMARY KEY (`fileShortcutId`),
  UNIQUE KEY `IX_FDB4A946` (`uuid_`,`groupId`),
  KEY `IX_B0051937` (`groupId`,`folderId`),
  KEY `IX_ECCE311D` (`groupId`,`folderId`,`status`),
  KEY `IX_4B7247F6` (`toFileEntryId`),
  KEY `IX_4831EBE4` (`uuid_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `DLFileShortcut`
--

LOCK TABLES `DLFileShortcut` WRITE;
/*!40000 ALTER TABLE `DLFileShortcut` DISABLE KEYS */;
/*!40000 ALTER TABLE `DLFileShortcut` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `DLFileVersion`
--

DROP TABLE IF EXISTS `DLFileVersion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `DLFileVersion` (
  `uuid_` varchar(75) DEFAULT NULL,
  `fileVersionId` bigint(20) NOT NULL,
  `groupId` bigint(20) DEFAULT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `userId` bigint(20) DEFAULT NULL,
  `userName` varchar(75) DEFAULT NULL,
  `createDate` datetime DEFAULT NULL,
  `modifiedDate` datetime DEFAULT NULL,
  `repositoryId` bigint(20) DEFAULT NULL,
  `folderId` bigint(20) DEFAULT NULL,
  `fileEntryId` bigint(20) DEFAULT NULL,
  `extension` varchar(75) DEFAULT NULL,
  `mimeType` varchar(75) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `description` longtext,
  `changeLog` varchar(75) DEFAULT NULL,
  `extraSettings` longtext,
  `fileEntryTypeId` bigint(20) DEFAULT NULL,
  `version` varchar(75) DEFAULT NULL,
  `size_` bigint(20) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `statusByUserId` bigint(20) DEFAULT NULL,
  `statusByUserName` varchar(75) DEFAULT NULL,
  `statusDate` datetime DEFAULT NULL,
  PRIMARY KEY (`fileVersionId`),
  UNIQUE KEY `IX_E2815081` (`fileEntryId`,`version`),
  UNIQUE KEY `IX_C99B2650` (`uuid_`,`groupId`),
  KEY `IX_C68DC967` (`fileEntryId`),
  KEY `IX_D47BB14D` (`fileEntryId`,`status`),
  KEY `IX_DFD809D3` (`groupId`,`folderId`,`status`),
  KEY `IX_4BFABB9A` (`uuid_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `DLFileVersion`
--

LOCK TABLES `DLFileVersion` WRITE;
/*!40000 ALTER TABLE `DLFileVersion` DISABLE KEYS */;
INSERT INTO `DLFileVersion` VALUES ('1c1e8579-a531-4a98-ab37-0ebbc047d591',10793,10778,10154,10196,'Test Test','2014-03-18 17:55:13','2014-03-18 17:55:13',10778,0,10792,'txt','text/plain','DM Document Title','DM Document Description','','',0,'1.0',259,0,10196,'Test Test','2014-03-18 17:55:13');
/*!40000 ALTER TABLE `DLFileVersion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `DLFolder`
--

DROP TABLE IF EXISTS `DLFolder`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `DLFolder` (
  `uuid_` varchar(75) DEFAULT NULL,
  `folderId` bigint(20) NOT NULL,
  `groupId` bigint(20) DEFAULT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `userId` bigint(20) DEFAULT NULL,
  `userName` varchar(75) DEFAULT NULL,
  `createDate` datetime DEFAULT NULL,
  `modifiedDate` datetime DEFAULT NULL,
  `repositoryId` bigint(20) DEFAULT NULL,
  `mountPoint` tinyint(4) DEFAULT NULL,
  `parentFolderId` bigint(20) DEFAULT NULL,
  `name` varchar(100) DEFAULT NULL,
  `description` longtext,
  `lastPostDate` datetime DEFAULT NULL,
  `defaultFileEntryTypeId` bigint(20) DEFAULT NULL,
  `overrideFileEntryTypes` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`folderId`),
  UNIQUE KEY `IX_902FD874` (`groupId`,`parentFolderId`,`name`),
  UNIQUE KEY `IX_3CC1DED2` (`uuid_`,`groupId`),
  KEY `IX_A74DB14C` (`companyId`),
  KEY `IX_F2EA1ACE` (`groupId`),
  KEY `IX_49C37475` (`groupId`,`parentFolderId`),
  KEY `IX_2A048EA0` (`groupId`,`parentFolderId`,`mountPoint`),
  KEY `IX_51556082` (`parentFolderId`,`name`),
  KEY `IX_EE29C715` (`repositoryId`),
  KEY `IX_CBC408D8` (`uuid_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `DLFolder`
--

LOCK TABLES `DLFolder` WRITE;
/*!40000 ALTER TABLE `DLFolder` DISABLE KEYS */;
/*!40000 ALTER TABLE `DLFolder` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `DLSync`
--

DROP TABLE IF EXISTS `DLSync`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `DLSync` (
  `syncId` bigint(20) NOT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `createDate` datetime DEFAULT NULL,
  `modifiedDate` datetime DEFAULT NULL,
  `fileId` bigint(20) DEFAULT NULL,
  `fileUuid` varchar(75) DEFAULT NULL,
  `repositoryId` bigint(20) DEFAULT NULL,
  `parentFolderId` bigint(20) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `description` longtext,
  `event` varchar(75) DEFAULT NULL,
  `type_` varchar(75) DEFAULT NULL,
  `version` varchar(75) DEFAULT NULL,
  PRIMARY KEY (`syncId`),
  UNIQUE KEY `IX_F9821AB4` (`fileId`),
  KEY `IX_B53EC783` (`companyId`,`modifiedDate`,`repositoryId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `DLSync`
--

LOCK TABLES `DLSync` WRITE;
/*!40000 ALTER TABLE `DLSync` DISABLE KEYS */;
INSERT INTO `DLSync` VALUES (10800,10154,'2014-03-18 17:55:13','2014-03-18 17:55:13',10792,'6cb91ae9-12bb-4442-b7dd-1b6df193154e',10778,0,'DM Document Title','DM Document Description','add','file','1.0');
/*!40000 ALTER TABLE `DLSync` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `EmailAddress`
--

DROP TABLE IF EXISTS `EmailAddress`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `EmailAddress` (
  `emailAddressId` bigint(20) NOT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `userId` bigint(20) DEFAULT NULL,
  `userName` varchar(75) DEFAULT NULL,
  `createDate` datetime DEFAULT NULL,
  `modifiedDate` datetime DEFAULT NULL,
  `classNameId` bigint(20) DEFAULT NULL,
  `classPK` bigint(20) DEFAULT NULL,
  `address` varchar(75) DEFAULT NULL,
  `typeId` int(11) DEFAULT NULL,
  `primary_` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`emailAddressId`),
  KEY `IX_1BB072CA` (`companyId`),
  KEY `IX_49D2DEC4` (`companyId`,`classNameId`),
  KEY `IX_551A519F` (`companyId`,`classNameId`,`classPK`),
  KEY `IX_2A2CB130` (`companyId`,`classNameId`,`classPK`,`primary_`),
  KEY `IX_7B43CD8` (`userId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `EmailAddress`
--

LOCK TABLES `EmailAddress` WRITE;
/*!40000 ALTER TABLE `EmailAddress` DISABLE KEYS */;
INSERT INTO `EmailAddress` VALUES (10877,10154,10196,'Test Test','2014-03-18 18:02:33','2014-03-18 18:02:47',10022,10197,'liferayportal01@liferay.com',11003,1);
/*!40000 ALTER TABLE `EmailAddress` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ExpandoColumn`
--

DROP TABLE IF EXISTS `ExpandoColumn`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ExpandoColumn` (
  `columnId` bigint(20) NOT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `tableId` bigint(20) DEFAULT NULL,
  `name` varchar(75) DEFAULT NULL,
  `type_` int(11) DEFAULT NULL,
  `defaultData` longtext,
  `typeSettings` longtext,
  PRIMARY KEY (`columnId`),
  UNIQUE KEY `IX_FEFC8DA7` (`tableId`,`name`),
  KEY `IX_A8C0CBE8` (`tableId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ExpandoColumn`
--

LOCK TABLES `ExpandoColumn` WRITE;
/*!40000 ALTER TABLE `ExpandoColumn` DISABLE KEYS */;
INSERT INTO `ExpandoColumn` VALUES (10847,10154,10846,'boolean',1,'','');
/*!40000 ALTER TABLE `ExpandoColumn` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ExpandoRow`
--

DROP TABLE IF EXISTS `ExpandoRow`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ExpandoRow` (
  `rowId_` bigint(20) NOT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `tableId` bigint(20) DEFAULT NULL,
  `classPK` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`rowId_`),
  UNIQUE KEY `IX_81EFBFF5` (`tableId`,`classPK`),
  KEY `IX_D3F5D7AE` (`tableId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ExpandoRow`
--

LOCK TABLES `ExpandoRow` WRITE;
/*!40000 ALTER TABLE `ExpandoRow` DISABLE KEYS */;
INSERT INTO `ExpandoRow` VALUES (10875,10154,10846,10196);
/*!40000 ALTER TABLE `ExpandoRow` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ExpandoTable`
--

DROP TABLE IF EXISTS `ExpandoTable`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ExpandoTable` (
  `tableId` bigint(20) NOT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `classNameId` bigint(20) DEFAULT NULL,
  `name` varchar(75) DEFAULT NULL,
  PRIMARY KEY (`tableId`),
  UNIQUE KEY `IX_37562284` (`companyId`,`classNameId`,`name`),
  KEY `IX_B5AE8A85` (`companyId`,`classNameId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ExpandoTable`
--

LOCK TABLES `ExpandoTable` WRITE;
/*!40000 ALTER TABLE `ExpandoTable` DISABLE KEYS */;
INSERT INTO `ExpandoTable` VALUES (10705,10154,10002,'CUSTOM_FIELDS'),(10846,10154,10005,'CUSTOM_FIELDS');
/*!40000 ALTER TABLE `ExpandoTable` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ExpandoValue`
--

DROP TABLE IF EXISTS `ExpandoValue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ExpandoValue` (
  `valueId` bigint(20) NOT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `tableId` bigint(20) DEFAULT NULL,
  `columnId` bigint(20) DEFAULT NULL,
  `rowId_` bigint(20) DEFAULT NULL,
  `classNameId` bigint(20) DEFAULT NULL,
  `classPK` bigint(20) DEFAULT NULL,
  `data_` longtext,
  PRIMARY KEY (`valueId`),
  UNIQUE KEY `IX_9DDD21E5` (`columnId`,`rowId_`),
  UNIQUE KEY `IX_D27B03E7` (`tableId`,`columnId`,`classPK`),
  KEY `IX_B29FEF17` (`classNameId`,`classPK`),
  KEY `IX_F7DD0987` (`columnId`),
  KEY `IX_9112A7A0` (`rowId_`),
  KEY `IX_F0566A77` (`tableId`),
  KEY `IX_1BD3F4C` (`tableId`,`classPK`),
  KEY `IX_CA9AFB7C` (`tableId`,`columnId`),
  KEY `IX_B71E92D5` (`tableId`,`rowId_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ExpandoValue`
--

LOCK TABLES `ExpandoValue` WRITE;
/*!40000 ALTER TABLE `ExpandoValue` DISABLE KEYS */;
INSERT INTO `ExpandoValue` VALUES (10876,10154,10846,10847,10875,10005,10196,'false');
/*!40000 ALTER TABLE `ExpandoValue` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Group_`
--

DROP TABLE IF EXISTS `Group_`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Group_` (
  `groupId` bigint(20) NOT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `creatorUserId` bigint(20) DEFAULT NULL,
  `classNameId` bigint(20) DEFAULT NULL,
  `classPK` bigint(20) DEFAULT NULL,
  `parentGroupId` bigint(20) DEFAULT NULL,
  `liveGroupId` bigint(20) DEFAULT NULL,
  `name` varchar(150) DEFAULT NULL,
  `description` longtext,
  `type_` int(11) DEFAULT NULL,
  `typeSettings` longtext,
  `friendlyURL` varchar(100) DEFAULT NULL,
  `site` tinyint(4) DEFAULT NULL,
  `active_` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`groupId`),
  UNIQUE KEY `IX_D0D5E397` (`companyId`,`classNameId`,`classPK`),
  UNIQUE KEY `IX_5DE0BE11` (`companyId`,`classNameId`,`liveGroupId`,`name`),
  UNIQUE KEY `IX_5BDDB872` (`companyId`,`friendlyURL`),
  UNIQUE KEY `IX_BBCA55B` (`companyId`,`liveGroupId`,`name`),
  UNIQUE KEY `IX_5AA68501` (`companyId`,`name`),
  KEY `IX_ABA5CEC2` (`companyId`),
  KEY `IX_16218A38` (`liveGroupId`),
  KEY `IX_7B590A7A` (`type_`,`active_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Group_`
--

LOCK TABLES `Group_` WRITE;
/*!40000 ALTER TABLE `Group_` DISABLE KEYS */;
INSERT INTO `Group_` VALUES (10172,10154,10158,10001,10172,0,0,'Control Panel','',3,'','/control_panel',1,1),(10180,10154,10158,10001,10180,0,0,'Guest','',1,'false-robots.txt=User-Agent: *_SAFE_NEWLINE_CHARACTER_Disallow:_SAFE_NEWLINE_CHARACTER_Sitemap: http://localhost/sitemap.xml\n','/guest',1,1),(10189,10154,10158,10188,10158,0,0,'User Personal Site','',3,'','/personal_site',0,1),(10192,10154,10158,10021,10154,0,0,'10154','',0,'','/null',0,1),(10198,10154,10196,10005,10196,0,0,'10196','',0,'','/test',0,1),(10310,10154,10158,10027,10309,0,0,'10309','',0,'','/template-10309',0,1),(10320,10154,10158,10027,10319,0,0,'10319','',0,'','/template-10319',0,1),(10329,10154,10158,10027,10328,0,0,'10328','',0,'','/template-10328',0,1),(10338,10154,10158,10031,10337,0,0,'10337','',0,'','/template-10337',0,1),(10364,10154,10158,10031,10363,0,0,'10363','',0,'','/template-10363',0,1),(10450,10154,10196,10001,10450,0,0,'Member Site','',1,'','/member-site',1,1),(10460,10154,10458,10005,10458,0,0,'10458','',0,'','/usersn',0,1),(10467,10154,10196,10001,10467,0,0,'Wiki Site','',1,'','/wiki-site',1,1),(10509,10154,10196,10001,10509,0,0,'WebContent Site','',1,'','/webcontent-site',1,1),(10522,10154,10196,10001,10522,0,0,'Social Activity Site','',1,'','/social-activity-site',1,1),(10547,10154,10196,10027,10546,0,0,'10546','',0,'','/template-10546',0,1),(10557,10154,10196,10001,10557,0,0,'Dynamic Data List Display Site','',1,'','/dynamic-data-list-display-site',1,1),(10591,10154,10196,10031,10590,0,0,'10590','',0,'','/template-10590',0,1),(10603,10154,10601,10005,10601,0,0,'10601','',0,'','/userpp',0,1),(10646,10154,10196,10001,10646,0,0,'Site Name','',2,'','/site-name',1,1),(10652,10154,10650,10005,10650,0,0,'10650','',0,'','/usersmsn',0,1),(10679,10154,10196,10001,10679,0,0,'Staging Site','',1,'staged-portlet_166=true\nstaged-portlet_8=true\nbranchingPublic=true\nstaged-portlet_161=true\nstaged-portlet_108=true\nstagedRemotely=false\nstaged-portlet_107=true\nbranchingPrivate=true\nstaged-portlet_56=true\nstaged-portlet_15=true\nstaged-portlet_28=true\nstaged-portlet_39=true\nstaged-portlet_54=true\nstaged-portlet_19=true\nstaged-portlet_110=true\nstaged-portlet_36=true\nstaged-portlet_20=true\nstaged-portlet_59=true\nstaged-portlet_25=true\nstaged=true\n','/staging-site',1,1),(10688,10154,10196,10001,10688,0,10679,'Staging Site (Staging)','',1,'','/staging-site-staging',0,1),(10761,10154,10196,10001,10761,0,0,'AP Site','',1,'','/ap-site',1,1),(10778,10154,10196,10001,10778,0,0,'Documents and Media Site','',1,'','/documents-and-media-site',1,1),(10807,10154,10196,10001,10807,0,0,'MDR Site','',1,'','/mdr-site',1,1),(10850,10154,10848,10005,10848,0,0,'10848','',0,'','/usercf',0,1),(10857,10154,10196,10001,10857,0,0,'Blogs Site','',1,'','/blogs-site',1,1),(10903,10154,10196,10031,10902,0,0,'10902','',0,'','/template-10902',0,1),(10922,10154,10196,10001,10922,0,0,'AP Export Site A','',1,'','/ap-export-site-a',1,1),(10946,10154,10196,10001,10946,0,0,'AP Import Site B','',1,'','/ap-import-site-b',1,1);
/*!40000 ALTER TABLE `Group_` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Groups_Orgs`
--

DROP TABLE IF EXISTS `Groups_Orgs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Groups_Orgs` (
  `groupId` bigint(20) NOT NULL,
  `organizationId` bigint(20) NOT NULL,
  PRIMARY KEY (`groupId`,`organizationId`),
  KEY `IX_75267DCA` (`groupId`),
  KEY `IX_6BBB7682` (`organizationId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Groups_Orgs`
--

LOCK TABLES `Groups_Orgs` WRITE;
/*!40000 ALTER TABLE `Groups_Orgs` DISABLE KEYS */;
/*!40000 ALTER TABLE `Groups_Orgs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Groups_Permissions`
--

DROP TABLE IF EXISTS `Groups_Permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Groups_Permissions` (
  `groupId` bigint(20) NOT NULL,
  `permissionId` bigint(20) NOT NULL,
  PRIMARY KEY (`groupId`,`permissionId`),
  KEY `IX_C48736B` (`groupId`),
  KEY `IX_EC97689D` (`permissionId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Groups_Permissions`
--

LOCK TABLES `Groups_Permissions` WRITE;
/*!40000 ALTER TABLE `Groups_Permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `Groups_Permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Groups_Roles`
--

DROP TABLE IF EXISTS `Groups_Roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Groups_Roles` (
  `groupId` bigint(20) NOT NULL,
  `roleId` bigint(20) NOT NULL,
  PRIMARY KEY (`groupId`,`roleId`),
  KEY `IX_84471FD2` (`groupId`),
  KEY `IX_3103EF3D` (`roleId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Groups_Roles`
--

LOCK TABLES `Groups_Roles` WRITE;
/*!40000 ALTER TABLE `Groups_Roles` DISABLE KEYS */;
INSERT INTO `Groups_Roles` VALUES (10450,10455);
/*!40000 ALTER TABLE `Groups_Roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Groups_UserGroups`
--

DROP TABLE IF EXISTS `Groups_UserGroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Groups_UserGroups` (
  `groupId` bigint(20) NOT NULL,
  `userGroupId` bigint(20) NOT NULL,
  PRIMARY KEY (`groupId`,`userGroupId`),
  KEY `IX_31FB749A` (`groupId`),
  KEY `IX_3B69160F` (`userGroupId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Groups_UserGroups`
--

LOCK TABLES `Groups_UserGroups` WRITE;
/*!40000 ALTER TABLE `Groups_UserGroups` DISABLE KEYS */;
/*!40000 ALTER TABLE `Groups_UserGroups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Image`
--

DROP TABLE IF EXISTS `Image`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Image` (
  `imageId` bigint(20) NOT NULL,
  `modifiedDate` datetime DEFAULT NULL,
  `text_` longtext,
  `type_` varchar(75) DEFAULT NULL,
  `height` int(11) DEFAULT NULL,
  `width` int(11) DEFAULT NULL,
  `size_` int(11) DEFAULT NULL,
  PRIMARY KEY (`imageId`),
  KEY `IX_6A925A4D` (`size_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Image`
--

LOCK TABLES `Image` WRITE;
/*!40000 ALTER TABLE `Image` DISABLE KEYS */;
INSERT INTO `Image` VALUES (10437,'2014-03-18 17:35:03','','png',108,80,5176),(10438,'2014-03-18 17:35:03','','png',160,160,5695);
/*!40000 ALTER TABLE `Image` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `JournalArticle`
--

DROP TABLE IF EXISTS `JournalArticle`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `JournalArticle` (
  `uuid_` varchar(75) DEFAULT NULL,
  `id_` bigint(20) NOT NULL,
  `resourcePrimKey` bigint(20) DEFAULT NULL,
  `groupId` bigint(20) DEFAULT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `userId` bigint(20) DEFAULT NULL,
  `userName` varchar(75) DEFAULT NULL,
  `createDate` datetime DEFAULT NULL,
  `modifiedDate` datetime DEFAULT NULL,
  `classNameId` bigint(20) DEFAULT NULL,
  `classPK` bigint(20) DEFAULT NULL,
  `articleId` varchar(75) DEFAULT NULL,
  `version` double DEFAULT NULL,
  `title` longtext,
  `urlTitle` varchar(150) DEFAULT NULL,
  `description` longtext,
  `content` longtext,
  `type_` varchar(75) DEFAULT NULL,
  `structureId` varchar(75) DEFAULT NULL,
  `templateId` varchar(75) DEFAULT NULL,
  `layoutUuid` varchar(75) DEFAULT NULL,
  `displayDate` datetime DEFAULT NULL,
  `expirationDate` datetime DEFAULT NULL,
  `reviewDate` datetime DEFAULT NULL,
  `indexable` tinyint(4) DEFAULT NULL,
  `smallImage` tinyint(4) DEFAULT NULL,
  `smallImageId` bigint(20) DEFAULT NULL,
  `smallImageURL` longtext,
  `status` int(11) DEFAULT NULL,
  `statusByUserId` bigint(20) DEFAULT NULL,
  `statusByUserName` varchar(75) DEFAULT NULL,
  `statusDate` datetime DEFAULT NULL,
  PRIMARY KEY (`id_`),
  UNIQUE KEY `IX_85C52EEC` (`groupId`,`articleId`,`version`),
  UNIQUE KEY `IX_3463D95B` (`uuid_`,`groupId`),
  KEY `IX_DFF98523` (`companyId`),
  KEY `IX_323DF109` (`companyId`,`status`),
  KEY `IX_3D070845` (`companyId`,`version`),
  KEY `IX_E82F322B` (`companyId`,`version`,`status`),
  KEY `IX_9356F865` (`groupId`),
  KEY `IX_68C0F69C` (`groupId`,`articleId`),
  KEY `IX_4D5CD982` (`groupId`,`articleId`,`status`),
  KEY `IX_9CE6E0FA` (`groupId`,`classNameId`,`classPK`),
  KEY `IX_A2534AC2` (`groupId`,`classNameId`,`layoutUuid`),
  KEY `IX_91E78C35` (`groupId`,`classNameId`,`structureId`),
  KEY `IX_F43B9FF2` (`groupId`,`classNameId`,`templateId`),
  KEY `IX_3C028C1E` (`groupId`,`layoutUuid`),
  KEY `IX_301D024B` (`groupId`,`status`),
  KEY `IX_2E207659` (`groupId`,`structureId`),
  KEY `IX_8DEAE14E` (`groupId`,`templateId`),
  KEY `IX_22882D02` (`groupId`,`urlTitle`),
  KEY `IX_D2D249E8` (`groupId`,`urlTitle`,`status`),
  KEY `IX_F0A26B29` (`groupId`,`version`,`status`),
  KEY `IX_33F49D16` (`resourcePrimKey`),
  KEY `IX_3E2765FC` (`resourcePrimKey`,`status`),
  KEY `IX_EF9B7028` (`smallImageId`),
  KEY `IX_8E8710D9` (`structureId`),
  KEY `IX_9106F6CE` (`templateId`),
  KEY `IX_F029602F` (`uuid_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `JournalArticle`
--

LOCK TABLES `JournalArticle` WRITE;
/*!40000 ALTER TABLE `JournalArticle` DISABLE KEYS */;
INSERT INTO `JournalArticle` VALUES ('a67b6320-b61d-4aa9-a980-37644658abf1',10962,10963,10946,10154,10196,'Test Test','2014-07-08 22:49:18','2014-07-08 22:49:19',0,0,'10961',1,'<?xml version=\'1.0\' encoding=\'UTF-8\'?><root available-locales=\"en_US\" default-locale=\"en_US\"><Title language-id=\"en_US\">WC Webcontent Title</Title></root>','wc-webcontent-title','','<?xml version=\"1.0\"?>\n\n<root available-locales=\"en_US\" default-locale=\"en_US\">\n	<static-content language-id=\"en_US\">&lt;p&gt; WC WebContent Content&lt;/p&gt;</static-content>\n</root>','general','','','','2014-07-08 22:48:00',NULL,NULL,1,0,10964,'',0,10196,'Test Test','2014-07-08 22:49:19'),('94f87c8b-0e29-4675-895a-4ad5bcc3d924',11008,10963,10946,10154,10196,'Test Test','2014-07-08 23:04:16','2014-07-08 23:04:16',0,0,'10961',1.1,'<?xml version=\'1.0\' encoding=\'UTF-8\'?><root available-locales=\"en_US\" default-locale=\"en_US\"><Title language-id=\"en_US\">WC Webcontent Title</Title></root>','wc-webcontent-title','','<?xml version=\"1.0\"?>\n\n<root available-locales=\"en_US\" default-locale=\"en_US\">\n	<static-content language-id=\"en_US\">&lt;p&gt; WC WebContent Content&lt;/p&gt;</static-content>\n</root>','general','','','44c6d238-b819-4053-a4c0-7894532f1d12','2014-07-08 22:48:00',NULL,NULL,1,0,10964,'',0,10196,'Test Test','2014-07-08 23:04:16');
/*!40000 ALTER TABLE `JournalArticle` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `JournalArticleImage`
--

DROP TABLE IF EXISTS `JournalArticleImage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `JournalArticleImage` (
  `articleImageId` bigint(20) NOT NULL,
  `groupId` bigint(20) DEFAULT NULL,
  `articleId` varchar(75) DEFAULT NULL,
  `version` double DEFAULT NULL,
  `elInstanceId` varchar(75) DEFAULT NULL,
  `elName` varchar(75) DEFAULT NULL,
  `languageId` varchar(75) DEFAULT NULL,
  `tempImage` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`articleImageId`),
  UNIQUE KEY `IX_103D6207` (`groupId`,`articleId`,`version`,`elInstanceId`,`elName`,`languageId`),
  KEY `IX_3B51BB68` (`groupId`),
  KEY `IX_158B526F` (`groupId`,`articleId`,`version`),
  KEY `IX_D4121315` (`tempImage`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `JournalArticleImage`
--

LOCK TABLES `JournalArticleImage` WRITE;
/*!40000 ALTER TABLE `JournalArticleImage` DISABLE KEYS */;
/*!40000 ALTER TABLE `JournalArticleImage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `JournalArticleResource`
--

DROP TABLE IF EXISTS `JournalArticleResource`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `JournalArticleResource` (
  `uuid_` varchar(75) DEFAULT NULL,
  `resourcePrimKey` bigint(20) NOT NULL,
  `groupId` bigint(20) DEFAULT NULL,
  `articleId` varchar(75) DEFAULT NULL,
  PRIMARY KEY (`resourcePrimKey`),
  UNIQUE KEY `IX_88DF994A` (`groupId`,`articleId`),
  UNIQUE KEY `IX_84AB0309` (`uuid_`,`groupId`),
  KEY `IX_F8433677` (`groupId`),
  KEY `IX_DCD1FAC1` (`uuid_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `JournalArticleResource`
--

LOCK TABLES `JournalArticleResource` WRITE;
/*!40000 ALTER TABLE `JournalArticleResource` DISABLE KEYS */;
INSERT INTO `JournalArticleResource` VALUES ('739823fb-a21f-4b58-a0f5-977a5315e3f1',10963,10946,'10961');
/*!40000 ALTER TABLE `JournalArticleResource` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `JournalContentSearch`
--

DROP TABLE IF EXISTS `JournalContentSearch`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `JournalContentSearch` (
  `contentSearchId` bigint(20) NOT NULL,
  `groupId` bigint(20) DEFAULT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `privateLayout` tinyint(4) DEFAULT NULL,
  `layoutId` bigint(20) DEFAULT NULL,
  `portletId` varchar(200) DEFAULT NULL,
  `articleId` varchar(75) DEFAULT NULL,
  PRIMARY KEY (`contentSearchId`),
  UNIQUE KEY `IX_C3AA93B8` (`groupId`,`privateLayout`,`layoutId`,`portletId`,`articleId`),
  KEY `IX_9207CB31` (`articleId`),
  KEY `IX_6838E427` (`groupId`,`articleId`),
  KEY `IX_20962903` (`groupId`,`privateLayout`),
  KEY `IX_7CC7D73E` (`groupId`,`privateLayout`,`articleId`),
  KEY `IX_B3B318DC` (`groupId`,`privateLayout`,`layoutId`),
  KEY `IX_7ACC74C9` (`groupId`,`privateLayout`,`layoutId`,`portletId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `JournalContentSearch`
--

LOCK TABLES `JournalContentSearch` WRITE;
/*!40000 ALTER TABLE `JournalContentSearch` DISABLE KEYS */;
/*!40000 ALTER TABLE `JournalContentSearch` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `JournalFeed`
--

DROP TABLE IF EXISTS `JournalFeed`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `JournalFeed` (
  `uuid_` varchar(75) DEFAULT NULL,
  `id_` bigint(20) NOT NULL,
  `groupId` bigint(20) DEFAULT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `userId` bigint(20) DEFAULT NULL,
  `userName` varchar(75) DEFAULT NULL,
  `createDate` datetime DEFAULT NULL,
  `modifiedDate` datetime DEFAULT NULL,
  `feedId` varchar(75) DEFAULT NULL,
  `name` varchar(75) DEFAULT NULL,
  `description` longtext,
  `type_` varchar(75) DEFAULT NULL,
  `structureId` varchar(75) DEFAULT NULL,
  `templateId` varchar(75) DEFAULT NULL,
  `rendererTemplateId` varchar(75) DEFAULT NULL,
  `delta` int(11) DEFAULT NULL,
  `orderByCol` varchar(75) DEFAULT NULL,
  `orderByType` varchar(75) DEFAULT NULL,
  `targetLayoutFriendlyUrl` varchar(255) DEFAULT NULL,
  `targetPortletId` varchar(75) DEFAULT NULL,
  `contentField` varchar(75) DEFAULT NULL,
  `feedType` varchar(75) DEFAULT NULL,
  `feedVersion` double DEFAULT NULL,
  PRIMARY KEY (`id_`),
  UNIQUE KEY `IX_65576CBC` (`groupId`,`feedId`),
  UNIQUE KEY `IX_39031F51` (`uuid_`,`groupId`),
  KEY `IX_35A2DB2F` (`groupId`),
  KEY `IX_50C36D79` (`uuid_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `JournalFeed`
--

LOCK TABLES `JournalFeed` WRITE;
/*!40000 ALTER TABLE `JournalFeed` DISABLE KEYS */;
INSERT INTO `JournalFeed` VALUES ('1adb8d83-4d1e-4180-83e5-d8f4a791b9ed',10521,10509,10154,10196,'Test Test','2014-03-18 17:39:56','2014-03-18 17:39:56','10520','Feed Name','','','','','',10,'modified-date','asc','/web/guest/home','','web-content-description','atom',1);
/*!40000 ALTER TABLE `JournalFeed` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `JournalStructure`
--

DROP TABLE IF EXISTS `JournalStructure`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `JournalStructure` (
  `uuid_` varchar(75) DEFAULT NULL,
  `id_` bigint(20) NOT NULL,
  `groupId` bigint(20) DEFAULT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `userId` bigint(20) DEFAULT NULL,
  `userName` varchar(75) DEFAULT NULL,
  `createDate` datetime DEFAULT NULL,
  `modifiedDate` datetime DEFAULT NULL,
  `structureId` varchar(75) DEFAULT NULL,
  `parentStructureId` varchar(75) DEFAULT NULL,
  `name` longtext,
  `description` longtext,
  `xsd` longtext,
  PRIMARY KEY (`id_`),
  UNIQUE KEY `IX_AB6E9996` (`groupId`,`structureId`),
  UNIQUE KEY `IX_42E86E58` (`uuid_`,`groupId`),
  KEY `IX_B97F5608` (`groupId`),
  KEY `IX_CA0BD48C` (`groupId`,`parentStructureId`),
  KEY `IX_4FA67B72` (`parentStructureId`),
  KEY `IX_8831E4FC` (`structureId`),
  KEY `IX_6702CA92` (`uuid_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `JournalStructure`
--

LOCK TABLES `JournalStructure` WRITE;
/*!40000 ALTER TABLE `JournalStructure` DISABLE KEYS */;
/*!40000 ALTER TABLE `JournalStructure` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `JournalTemplate`
--

DROP TABLE IF EXISTS `JournalTemplate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `JournalTemplate` (
  `uuid_` varchar(75) DEFAULT NULL,
  `id_` bigint(20) NOT NULL,
  `groupId` bigint(20) DEFAULT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `userId` bigint(20) DEFAULT NULL,
  `userName` varchar(75) DEFAULT NULL,
  `createDate` datetime DEFAULT NULL,
  `modifiedDate` datetime DEFAULT NULL,
  `templateId` varchar(75) DEFAULT NULL,
  `structureId` varchar(75) DEFAULT NULL,
  `name` longtext,
  `description` longtext,
  `xsl` longtext,
  `langType` varchar(75) DEFAULT NULL,
  `cacheable` tinyint(4) DEFAULT NULL,
  `smallImage` tinyint(4) DEFAULT NULL,
  `smallImageId` bigint(20) DEFAULT NULL,
  `smallImageURL` longtext,
  PRIMARY KEY (`id_`),
  UNIQUE KEY `IX_E802AA3C` (`groupId`,`templateId`),
  UNIQUE KEY `IX_62D1B3AD` (`uuid_`,`groupId`),
  KEY `IX_77923653` (`groupId`),
  KEY `IX_1701CB2B` (`groupId`,`structureId`),
  KEY `IX_25FFB6FA` (`smallImageId`),
  KEY `IX_45F5A7C7` (`structureId`),
  KEY `IX_1B12CA20` (`templateId`),
  KEY `IX_2857419D` (`uuid_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `JournalTemplate`
--

LOCK TABLES `JournalTemplate` WRITE;
/*!40000 ALTER TABLE `JournalTemplate` DISABLE KEYS */;
/*!40000 ALTER TABLE `JournalTemplate` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Layout`
--

DROP TABLE IF EXISTS `Layout`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Layout` (
  `uuid_` varchar(75) DEFAULT NULL,
  `plid` bigint(20) NOT NULL,
  `groupId` bigint(20) DEFAULT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `createDate` datetime DEFAULT NULL,
  `modifiedDate` datetime DEFAULT NULL,
  `privateLayout` tinyint(4) DEFAULT NULL,
  `layoutId` bigint(20) DEFAULT NULL,
  `parentLayoutId` bigint(20) DEFAULT NULL,
  `name` longtext,
  `title` longtext,
  `description` longtext,
  `keywords` longtext,
  `robots` longtext,
  `type_` varchar(75) DEFAULT NULL,
  `typeSettings` longtext,
  `hidden_` tinyint(4) DEFAULT NULL,
  `friendlyURL` varchar(255) DEFAULT NULL,
  `iconImage` tinyint(4) DEFAULT NULL,
  `iconImageId` bigint(20) DEFAULT NULL,
  `themeId` varchar(75) DEFAULT NULL,
  `colorSchemeId` varchar(75) DEFAULT NULL,
  `wapThemeId` varchar(75) DEFAULT NULL,
  `wapColorSchemeId` varchar(75) DEFAULT NULL,
  `css` longtext,
  `priority` int(11) DEFAULT NULL,
  `layoutPrototypeUuid` varchar(75) DEFAULT NULL,
  `layoutPrototypeLinkEnabled` tinyint(4) DEFAULT NULL,
  `sourcePrototypeLayoutUuid` varchar(75) DEFAULT NULL,
  PRIMARY KEY (`plid`),
  UNIQUE KEY `IX_BC2C4231` (`groupId`,`privateLayout`,`friendlyURL`),
  UNIQUE KEY `IX_7162C27C` (`groupId`,`privateLayout`,`layoutId`),
  UNIQUE KEY `IX_CED31606` (`uuid_`,`groupId`),
  KEY `IX_C7FBC998` (`companyId`),
  KEY `IX_C099D61A` (`groupId`),
  KEY `IX_705F5AA3` (`groupId`,`privateLayout`),
  KEY `IX_6DE88B06` (`groupId`,`privateLayout`,`parentLayoutId`),
  KEY `IX_8CE8C0D9` (`groupId`,`privateLayout`,`sourcePrototypeLayoutUuid`),
  KEY `IX_1A1B61D2` (`groupId`,`privateLayout`,`type_`),
  KEY `IX_23922F7D` (`iconImageId`),
  KEY `IX_D0822724` (`uuid_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Layout`
--

LOCK TABLES `Layout` WRITE;
/*!40000 ALTER TABLE `Layout` DISABLE KEYS */;
INSERT INTO `Layout` VALUES ('5f8df68c-f783-4fce-bbbf-6027a3ece931',10175,10172,10154,'2014-03-18 17:33:37','2014-03-18 17:33:37',1,1,0,'<?xml version=\'1.0\' encoding=\'UTF-8\'?><root available-locales=\"en_US\" default-locale=\"en_US\"><Name language-id=\"en_US\">Control Panel</Name></root>','','','','','control_panel','',0,'/manage',0,0,'','','','','',0,'',0,''),('8145f555-3baa-41d3-9da0-381e986322c0',10183,10180,10154,'2014-03-18 17:33:37','2014-03-18 17:33:37',0,1,0,'<?xml version=\'1.0\' encoding=\'UTF-8\'?><root available-locales=\"en_US\" default-locale=\"en_US\"><Name language-id=\"en_US\">Welcome</Name></root>','','','','','portlet','layout-template-id=2_columns_ii\ncolumn-2=47,\ncolumn-1=58,\n',0,'/home',0,0,'','','','','',0,'',0,''),('b1ceed55-cc7a-4179-b10f-47a76b5fbacb',10313,10310,10154,'2014-03-18 17:33:39','2014-03-18 17:33:39',1,1,0,'<?xml version=\'1.0\' encoding=\'UTF-8\'?><root available-locales=\"en_US\" default-locale=\"en_US\"><Name language-id=\"en_US\">Blog</Name></root>','','','','','portlet','layout-template-id=2_columns_iii\ncolumn-2=148_INSTANCE_f17fUnsqGfzI,114,\ncolumn-1=33,\n',0,'/layout',0,0,'','','','','',0,'',0,''),('3f4a975b-7592-4b34-a631-893cc8db3c05',10323,10320,10154,'2014-03-18 17:33:39','2014-03-18 17:33:39',1,1,0,'<?xml version=\'1.0\' encoding=\'UTF-8\'?><root available-locales=\"en_US\" default-locale=\"en_US\"><Name language-id=\"en_US\">Content Display Page</Name></root>','','','','','portlet','default-asset-publisher-portlet-id=101_INSTANCE_W5RTN7RddrzG\nlayout-template-id=2_columns_ii\ncolumn-2=3,101_INSTANCE_W5RTN7RddrzG,\ncolumn-1=141_INSTANCE_JpyReXKz8j1h,122_INSTANCE_B10hMf3MF3IL,\n',0,'/layout',0,0,'','','','','',0,'',0,''),('0505d773-1792-4600-8468-4f58397bac4d',10332,10329,10154,'2014-03-18 17:33:39','2014-03-18 17:33:39',1,1,0,'<?xml version=\'1.0\' encoding=\'UTF-8\'?><root available-locales=\"en_US\" default-locale=\"en_US\"><Name language-id=\"en_US\">Wiki</Name></root>','','','','','portlet','layout-template-id=2_columns_iii\ncolumn-2=122_INSTANCE_rh1044zpsuXg,141_INSTANCE_qDRgg008E4yU,\ncolumn-1=36,\n',0,'/layout',0,0,'','','','','',0,'',0,''),('ac0396c6-5dc7-4910-b5df-cd5d5f669a44',10346,10338,10154,'2014-03-18 17:33:40','2014-03-18 17:33:40',1,1,0,'<?xml version=\'1.0\' encoding=\'UTF-8\'?><root available-locales=\"en_US\" default-locale=\"en_US\"><Name language-id=\"en_US\">Home</Name></root>','','','','','portlet','layout-template-id=2_columns_iii\ncolumn-2=3,59_INSTANCE_EUMN74faVU2q,180,\ncolumn-1=19,\n',0,'/home',0,0,'','','','','',0,'',0,''),('68b9e97e-6704-4bdd-a629-b5080424ba66',10352,10338,10154,'2014-03-18 17:33:40','2014-03-18 17:33:40',1,2,0,'<?xml version=\'1.0\' encoding=\'UTF-8\'?><root available-locales=\"en_US\" default-locale=\"en_US\"><Name language-id=\"en_US\">Calendar</Name></root>','','','','','portlet','layout-template-id=2_columns_iii\ncolumn-2=101_INSTANCE_MKtINt5wJgBs,\ncolumn-1=8,\n',0,'/calendar',0,0,'','','','','',1,'',0,''),('b70ac1c4-22d4-4315-8cea-e9ac88f403ae',10358,10338,10154,'2014-03-18 17:33:40','2014-03-18 17:33:40',1,3,0,'<?xml version=\'1.0\' encoding=\'UTF-8\'?><root available-locales=\"en_US\" default-locale=\"en_US\"><Name language-id=\"en_US\">Wiki</Name></root>','','','','','portlet','layout-template-id=2_columns_iii\ncolumn-2=122_INSTANCE_ULdJ5tQrw1PT,148_INSTANCE_BTyrP5uWpSYO,\ncolumn-1=36,\n',0,'/wiki',0,0,'','','','','',2,'',0,''),('f3d28e34-4668-42ad-961c-a93328091cdb',10372,10364,10154,'2014-03-18 17:33:40','2014-03-18 17:33:40',1,1,0,'<?xml version=\'1.0\' encoding=\'UTF-8\'?><root available-locales=\"en_US\" default-locale=\"en_US\"><Name language-id=\"en_US\">Home</Name></root>','','','','','portlet','layout-template-id=2_columns_i\ncolumn-2=3,82,101_INSTANCE_7qLpq9y7sD92,\ncolumn-1=116,\n',0,'/home',0,0,'','','','','',0,'',0,''),('b7d5c630-e428-48d0-ad5a-552300c910f5',10380,10364,10154,'2014-03-18 17:33:40','2014-03-18 17:33:40',1,2,0,'<?xml version=\'1.0\' encoding=\'UTF-8\'?><root available-locales=\"en_US\" default-locale=\"en_US\"><Name language-id=\"en_US\">Documents and Media</Name></root>','','','','','portlet','layout-template-id=1_column\ncolumn-1=20,\n',0,'/documents',0,0,'','','','','',1,'',0,''),('885e9cc7-d901-4b88-a8a5-fb94e5338c21',10386,10364,10154,'2014-03-18 17:33:40','2014-03-18 17:33:40',1,3,0,'<?xml version=\'1.0\' encoding=\'UTF-8\'?><root available-locales=\"en_US\" default-locale=\"en_US\"><Name language-id=\"en_US\">Calendar</Name></root>','','','','','portlet','layout-template-id=2_columns_iii\ncolumn-2=101_INSTANCE_zgzOtyEtDk5S,\ncolumn-1=8,\n',0,'/calendar',0,0,'','','','','',2,'',0,''),('cd4243a4-9d74-42f1-a6c5-15393385935c',10392,10364,10154,'2014-03-18 17:33:40','2014-03-18 17:33:40',1,4,0,'<?xml version=\'1.0\' encoding=\'UTF-8\'?><root available-locales=\"en_US\" default-locale=\"en_US\"><Name language-id=\"en_US\">News</Name></root>','','','','','portlet','layout-template-id=2_columns_iii\ncolumn-2=39_INSTANCE_kWXDv7thyhvD,\ncolumn-1=39_INSTANCE_B0kQ9IYKwPHm,\n',0,'/news',0,0,'','','','','',3,'',0,''),('f0cc20ff-5ebe-443e-9242-15d9841e5175',10409,10198,10154,'2014-03-18 17:34:21','2014-03-18 17:34:21',1,1,0,'<?xml version=\'1.0\' encoding=\'UTF-8\'?><root available-locales=\"en_US\" default-locale=\"en_US\"><Name language-id=\"en_US\">Welcome</Name></root>','','','','','portlet','layout-template-id=2_columns_ii\ncolumn-2=29,8,\ncolumn-1=82,23,11,\n',0,'/home',0,0,'','','','','',0,'',0,''),('5d10fe0f-b573-44dc-8816-3d1b55f588dd',10414,10198,10154,'2014-03-18 17:34:21','2014-03-18 17:34:21',0,1,0,'<?xml version=\'1.0\' encoding=\'UTF-8\'?><root available-locales=\"en_US\" default-locale=\"en_US\"><Name language-id=\"en_US\">Welcome</Name></root>','','','','','portlet','layout-template-id=2_columns_ii\ncolumn-2=33,\ncolumn-1=82,3,\n',0,'/home',0,0,'','','','','',0,'',0,''),('a8f09633-75a9-41ce-95a0-59cf249ab99a',10424,10180,10154,'2014-03-18 17:34:33','2014-03-18 17:34:43',0,2,0,'<?xml version=\'1.0\' encoding=\'UTF-8\'?><root available-locales=\"en_US\" default-locale=\"en_US\"><Name language-id=\"en_US\">Software Catalog Page</Name></root>','','','','','portlet','layout-template-id=2_columns_ii\ncolumn-1=98\n',0,'/software-catalog-page',0,0,'','','','','',1,'',0,''),('0af682df-3bb6-4a87-a20f-ae74b11420c7',10472,10467,10154,'2014-03-18 17:37:44','2014-03-18 17:37:54',0,1,0,'<?xml version=\'1.0\' encoding=\'UTF-8\'?><root available-locales=\"en_US\" default-locale=\"en_US\"><Name language-id=\"en_US\">Wiki Test Page</Name></root>','','','','','portlet','layout-template-id=2_columns_ii\ncolumn-1=36\n',0,'/wiki-test-page',0,0,'','','','','',0,'',0,''),('7486826a-6b6c-49fd-9b35-2f0eab7982b4',10498,10180,10154,'2014-03-18 17:38:43','2014-03-18 17:38:59',0,3,0,'<?xml version=\'1.0\' encoding=\'UTF-8\'?><root available-locales=\"en_US\" default-locale=\"en_US\"><Name language-id=\"en_US\">Polls Display Page</Name></root>','','','','','portlet','layout-template-id=2_columns_ii\ncolumn-1=59_INSTANCE_uhIWLYUlw5T8\n',0,'/polls-display-page',0,0,'','','','','',2,'',0,''),('3a114dfd-4f49-4c2c-9cbc-f2296577be0c',10513,10509,10154,'2014-03-18 17:39:42','2014-03-18 17:39:42',0,1,0,'<?xml version=\'1.0\' encoding=\'UTF-8\'?><root available-locales=\"en_US\" default-locale=\"en_US\"><Name language-id=\"en_US\">Web Content Display Page</Name></root>','','','','','portlet','layout-template-id=2_columns_ii\n',0,'/web-content-display-page',0,0,'','','','','',0,'',0,''),('4474bbda-4b1b-42ec-89e4-d777f6a2b8e2',10526,10522,10154,'2014-03-18 17:41:35','2014-03-18 17:41:45',0,1,0,'<?xml version=\'1.0\' encoding=\'UTF-8\'?><root available-locales=\"en_US\" default-locale=\"en_US\"><Name language-id=\"en_US\">Social Activity Page</Name></root>','','','','','portlet','layout-template-id=2_columns_ii\ncolumn-1=84\n',0,'/social-activity-page',0,0,'','','','','',0,'',0,''),('6da088a8-eb31-40ff-9eec-3ee17eb02f34',10550,10547,10154,'2014-03-18 17:42:28','2014-03-18 17:42:28',1,1,0,'<?xml version=\'1.0\' encoding=\'UTF-8\'?><root available-locales=\"en_US\" default-locale=\"en_US\"><Name language-id=\"en_US\">Page Template Name</Name></root>','','','','','portlet','layout-template-id=2_columns_ii\n',0,'/layout',0,0,'','','','','',0,'',0,''),('56d9f289-9536-49b0-8ae3-da181d49b363',10561,10557,10154,'2014-03-18 17:43:11','2014-03-18 17:43:53',0,1,0,'<?xml version=\'1.0\' encoding=\'UTF-8\'?><root available-locales=\"en_US\" default-locale=\"en_US\"><Name language-id=\"en_US\">Dynamic Data List Display Page</Name></root>','','','','','portlet','layout-template-id=2_columns_ii\ncolumn-1=169_INSTANCE_Xc3UrpdLcuH0\n',0,'/dynamic-data-list-display-page',0,0,'','','','','',0,'',0,''),('8a500a02-f6ba-4596-a48e-c6c1041aff1c',10594,10591,10154,'2014-03-18 17:45:09','2014-03-18 17:45:09',1,1,0,'<?xml version=\'1.0\' encoding=\'UTF-8\'?><root available-locales=\"en_US\" default-locale=\"en_US\"><Name language-id=\"en_US\">home</Name></root>','','','','','portlet','layout-template-id=2_columns_ii\n',0,'/home',0,0,'','','','','',0,'',0,''),('fc75cb07-b0b2-409b-b753-51da841c6f4c',10610,10603,10154,'2014-03-18 17:46:17','2014-03-18 17:46:17',1,1,0,'<?xml version=\'1.0\' encoding=\'UTF-8\'?><root available-locales=\"en_US\" default-locale=\"en_US\"><Name language-id=\"en_US\">Welcome</Name></root>','','','','','portlet','layout-template-id=2_columns_ii\ncolumn-2=29,8,\ncolumn-1=82,23,11,\n',0,'/home',0,0,'','','','','',0,'',0,''),('c06fe8af-9555-48b5-b235-bb54e85186e1',10615,10603,10154,'2014-03-18 17:46:17','2014-03-18 17:46:17',0,1,0,'<?xml version=\'1.0\' encoding=\'UTF-8\'?><root available-locales=\"en_US\" default-locale=\"en_US\"><Name language-id=\"en_US\">Welcome</Name></root>','','','','','portlet','layout-template-id=2_columns_ii\ncolumn-2=33,\ncolumn-1=82,3,\n',0,'/home',0,0,'','','','','',0,'',0,''),('ef79153d-3d84-49b9-809c-28a478d71da5',10627,10180,10154,'2014-03-18 17:48:15','2014-03-18 17:48:25',0,4,0,'<?xml version=\'1.0\' encoding=\'UTF-8\'?><root available-locales=\"en_US\" default-locale=\"en_US\"><Name language-id=\"en_US\">Shopping Page</Name></root>','','','','','portlet','layout-template-id=2_columns_ii\ncolumn-1=34\n',0,'/shopping-page',0,0,'','','','','',3,'',0,''),('fef489a5-96ba-4923-a3e4-3a90268bcd39',10659,10652,10154,'2014-03-18 17:50:07','2014-03-18 17:50:07',1,1,0,'<?xml version=\'1.0\' encoding=\'UTF-8\'?><root available-locales=\"en_US\" default-locale=\"en_US\"><Name language-id=\"en_US\">Welcome</Name></root>','','','','','portlet','layout-template-id=2_columns_ii\ncolumn-2=29,8,\ncolumn-1=82,23,11,\n',0,'/home',0,0,'','','','','',0,'',0,''),('cf505337-732e-41d5-b5e2-7a93055e236e',10664,10652,10154,'2014-03-18 17:50:07','2014-03-18 17:50:07',0,1,0,'<?xml version=\'1.0\' encoding=\'UTF-8\'?><root available-locales=\"en_US\" default-locale=\"en_US\"><Name language-id=\"en_US\">Welcome</Name></root>','','','','','portlet','layout-template-id=2_columns_ii\ncolumn-2=33,\ncolumn-1=82,3,\n',0,'/home',0,0,'','','','','',0,'',0,''),('355c3b82-e1f0-494c-ac7f-5b20f9520bc0',10683,10679,10154,'2014-03-18 17:51:23','2014-03-18 17:51:23',0,1,0,'<?xml version=\'1.0\' encoding=\'UTF-8\'?><root available-locales=\"en_US\" default-locale=\"en_US\"><Name language-id=\"en_US\">Message Boards Page</Name></root>','','','','','portlet','layout-template-id=2_columns_ii\n',0,'/message-boards-page',0,0,'','','','','',0,'',0,''),('355c3b82-e1f0-494c-ac7f-5b20f9520bc0',10706,10688,10154,NULL,NULL,0,1,0,'<?xml version=\'1.0\' encoding=\'UTF-8\'?><root available-locales=\"en_US\" default-locale=\"en_US\"><Name language-id=\"en_US\">Message Boards Page</Name></root>','','','','','portlet','layout-template-id=2_columns_ii\n',0,'/message-boards-page',0,0,'','','','','',0,'',0,''),('a638c396-286e-48b6-ba7e-14f27b5daa97',10737,10180,10154,'2014-03-18 17:52:33','2014-03-18 17:52:44',0,5,0,'<?xml version=\'1.0\' encoding=\'UTF-8\'?><root available-locales=\"en_US\" default-locale=\"en_US\"><Name language-id=\"en_US\">Bookmarks Page</Name></root>','','','','','portlet','layout-template-id=2_columns_ii\ncolumn-1=28\n',0,'/bookmarks-page',0,0,'','','','','',4,'',0,''),('7b351d4a-9a37-4e70-8aec-4334a3112b3f',10765,10761,10154,'2014-03-18 17:53:44','2014-03-18 17:54:11',0,1,0,'<?xml version=\'1.0\' encoding=\'UTF-8\'?><root available-locales=\"en_US\" default-locale=\"en_US\"><Name language-id=\"en_US\">Asset Publisher Page</Name></root>','','','','','portlet','layout-template-id=2_columns_ii\ncolumn-1=33,19,101_INSTANCE_U6JjXcjOEdCZ\n',0,'/asset-publisher-page',0,0,'','','','','',0,'',0,''),('d9aa8f9b-9241-4a09-bcf7-f007a42df9e3',10782,10778,10154,'2014-03-18 17:54:53','2014-03-18 17:55:03',0,1,0,'<?xml version=\'1.0\' encoding=\'UTF-8\'?><root available-locales=\"en_US\" default-locale=\"en_US\"><Name language-id=\"en_US\">Documents and Media Page</Name></root>','','','','','portlet','layout-template-id=2_columns_ii\ncolumn-1=20\n',0,'/documents-and-media-page',0,0,'','','','','',0,'',0,''),('87836a50-728a-4be2-a59e-625e61f22e4b',10811,10807,10154,'2014-03-18 17:57:43','2014-03-18 17:57:43',0,1,0,'<?xml version=\'1.0\' encoding=\'UTF-8\'?><root available-locales=\"en_US\" default-locale=\"en_US\"><Name language-id=\"en_US\">MDR Page</Name></root>','','','','','portlet','layout-template-id=2_columns_ii\n',0,'/mdr-page',0,0,'','','','','',0,'',0,''),('c0a3eb44-1cfc-43df-a56c-04a73896d47c',10821,10180,10154,'2014-03-18 17:58:52','2014-03-18 17:59:00',0,6,0,'<?xml version=\'1.0\' encoding=\'UTF-8\'?><root available-locales=\"en_US\" default-locale=\"en_US\"><Name language-id=\"en_US\">Calendar Page</Name></root>','','','','','portlet','layout-template-id=2_columns_ii\ncolumn-1=8\n',0,'/calendar-page',0,0,'','','','','',5,'',0,''),('acbd30c6-6337-4d7f-8c70-9da5d13936da',10832,10180,10154,'2014-03-18 17:59:30','2014-03-18 17:59:38',0,7,0,'<?xml version=\'1.0\' encoding=\'UTF-8\'?><root available-locales=\"en_US\" default-locale=\"en_US\"><Name language-id=\"en_US\">Announcements Page</Name></root>','','','','','portlet','layout-template-id=2_columns_ii\ncolumn-1=84\n',0,'/announcements-page',0,0,'','','','','',6,'',0,''),('5fee8037-a1d4-411e-9dfa-ea7dc196e80f',10861,10857,10154,'2014-03-18 18:01:31','2014-03-18 18:01:53',0,1,0,'<?xml version=\'1.0\' encoding=\'UTF-8\'?><root available-locales=\"en_US\" default-locale=\"en_US\"><Name language-id=\"en_US\">Blogs Page</Name></root>','','','','','portlet','layout-template-id=2_columns_ii\ncolumn-1=33\n',0,'/blogs-page',0,0,'','','','','',0,'',0,''),('ed87633c-75b6-4e07-9883-cb8e18d88788',10906,10903,10154,'2014-07-08 22:42:33','2014-07-08 22:42:33',1,1,0,'<?xml version=\'1.0\' encoding=\'UTF-8\'?><root available-locales=\"en_US\" default-locale=\"en_US\"><Name language-id=\"en_US\">home</Name></root>','','','','','portlet','layout-template-id=2_columns_ii\n',0,'/home',0,0,'','','','','',0,'',0,''),('a51cee7c-b1e4-40ad-8e99-174628ed420b',10914,10903,10154,'2014-07-08 22:43:02','2014-07-08 22:43:07',1,2,0,'<?xml version=\'1.0\' encoding=\'UTF-8\'?><root available-locales=\"en_US\" default-locale=\"en_US\"><Name language-id=\"en_US\">Test Page Name</Name></root>','','','','','portlet','layout-template-id=2_columns_ii\ncolumn-1=101_INSTANCE_H0n9dLx4hP21\n',0,'/test-page-name',0,0,'','','','','',1,'',0,''),('fd95e16f-51aa-425e-afd5-2e5ea1b23642',10940,10922,10154,NULL,NULL,0,1,0,'<?xml version=\'1.0\' encoding=\'UTF-8\'?><root available-locales=\"en_US\" default-locale=\"en_US\"><Name language-id=\"en_US\">home</Name></root>','','','','','portlet','layout-template-id=2_columns_ii\n',0,'/home',0,0,'','','','','',0,'',0,'ed87633c-75b6-4e07-9883-cb8e18d88788'),('44c6d238-b819-4053-a4c0-7894532f1d12',10941,10922,10154,NULL,NULL,0,2,0,'<?xml version=\'1.0\' encoding=\'UTF-8\'?><root available-locales=\"en_US\" default-locale=\"en_US\"><Name language-id=\"en_US\">Test Page Name</Name></root>','','','','','portlet','layout-template-id=2_columns_ii\ncolumn-1=101_INSTANCE_H0n9dLx4hP21\n',0,'/test-page-name',0,0,'','','','','',1,'',0,'a51cee7c-b1e4-40ad-8e99-174628ed420b'),('fd95e16f-51aa-425e-afd5-2e5ea1b23642',10954,10946,10154,NULL,NULL,0,1,0,'<?xml version=\'1.0\' encoding=\'UTF-8\'?><root available-locales=\"en_US\" default-locale=\"en_US\"><Name language-id=\"en_US\">home</Name></root>','','','','','portlet','layout-template-id=2_columns_ii\n',0,'/home',0,0,'','','','','',0,'',0,'ed87633c-75b6-4e07-9883-cb8e18d88788'),('44c6d238-b819-4053-a4c0-7894532f1d12',10955,10946,10154,NULL,'2014-07-08 23:04:24',0,2,0,'<?xml version=\'1.0\' encoding=\'UTF-8\'?><root available-locales=\"en_US\" default-locale=\"en_US\"><Name language-id=\"en_US\">Test Page Name</Name></root>','','','','','portlet','default-asset-publisher-portlet-id=101_INSTANCE_H0n9dLx4hP21\nlayout-template-id=2_columns_ii\ncolumn-1=101_INSTANCE_H0n9dLx4hP21,\n',0,'/test-page-name',0,0,'','','','','',1,'',0,'a51cee7c-b1e4-40ad-8e99-174628ed420b');
/*!40000 ALTER TABLE `Layout` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `LayoutBranch`
--

DROP TABLE IF EXISTS `LayoutBranch`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `LayoutBranch` (
  `LayoutBranchId` bigint(20) NOT NULL,
  `groupId` bigint(20) DEFAULT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `userId` bigint(20) DEFAULT NULL,
  `userName` varchar(75) DEFAULT NULL,
  `layoutSetBranchId` bigint(20) DEFAULT NULL,
  `plid` bigint(20) DEFAULT NULL,
  `name` varchar(75) DEFAULT NULL,
  `description` longtext,
  `master` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`LayoutBranchId`),
  UNIQUE KEY `IX_FD57097D` (`layoutSetBranchId`,`plid`,`name`),
  KEY `IX_6C226433` (`layoutSetBranchId`),
  KEY `IX_2C42603E` (`layoutSetBranchId`,`plid`),
  KEY `IX_A705FF94` (`layoutSetBranchId`,`plid`,`master`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `LayoutBranch`
--

LOCK TABLES `LayoutBranch` WRITE;
/*!40000 ALTER TABLE `LayoutBranch` DISABLE KEYS */;
INSERT INTO `LayoutBranch` VALUES (10716,10688,10154,10196,'Test Test',10715,10706,'main-variation','',1);
/*!40000 ALTER TABLE `LayoutBranch` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `LayoutPrototype`
--

DROP TABLE IF EXISTS `LayoutPrototype`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `LayoutPrototype` (
  `uuid_` varchar(75) DEFAULT NULL,
  `layoutPrototypeId` bigint(20) NOT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `name` longtext,
  `description` longtext,
  `settings_` longtext,
  `active_` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`layoutPrototypeId`),
  KEY `IX_30616AAA` (`companyId`),
  KEY `IX_557A639F` (`companyId`,`active_`),
  KEY `IX_CEF72136` (`uuid_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `LayoutPrototype`
--

LOCK TABLES `LayoutPrototype` WRITE;
/*!40000 ALTER TABLE `LayoutPrototype` DISABLE KEYS */;
INSERT INTO `LayoutPrototype` VALUES ('2a24b00f-582e-4f1b-acff-2c8b84335be5',10309,10154,'<?xml version=\'1.0\' encoding=\'UTF-8\'?><root available-locales=\"en_US\" default-locale=\"en_US\"><Name language-id=\"en_US\">Blog</Name></root>','Create, edit, and view blogs from this page. Explore topics using tags, and connect with other members that blog.','',1),('536cf620-b49a-46ba-bd4f-5775b955717c',10319,10154,'<?xml version=\'1.0\' encoding=\'UTF-8\'?><root available-locales=\"en_US\" default-locale=\"en_US\"><Name language-id=\"en_US\">Content Display Page</Name></root>','Create, edit, and explore web content with this page. Search available content, explore related content with tags, and browse content categories.','',1),('1e5a4b95-b662-43f9-bd93-e86ac0df19eb',10328,10154,'<?xml version=\'1.0\' encoding=\'UTF-8\'?><root available-locales=\"en_US\" default-locale=\"en_US\"><Name language-id=\"en_US\">Wiki</Name></root>','Collaborate with members through the wiki on this page. Discover related content through tags, and navigate quickly and easily with categories.','',1),('9f1bd2a4-c69d-4737-b241-6c395ee05db7',10546,10154,'<?xml version=\'1.0\' encoding=\'UTF-8\'?><root available-locales=\"en_US\" default-locale=\"en_US\"><Name language-id=\"en_US\">Page Template Name</Name></root>','','',1);
/*!40000 ALTER TABLE `LayoutPrototype` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `LayoutRevision`
--

DROP TABLE IF EXISTS `LayoutRevision`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `LayoutRevision` (
  `layoutRevisionId` bigint(20) NOT NULL,
  `groupId` bigint(20) DEFAULT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `userId` bigint(20) DEFAULT NULL,
  `userName` varchar(75) DEFAULT NULL,
  `createDate` datetime DEFAULT NULL,
  `modifiedDate` datetime DEFAULT NULL,
  `layoutSetBranchId` bigint(20) DEFAULT NULL,
  `layoutBranchId` bigint(20) DEFAULT NULL,
  `parentLayoutRevisionId` bigint(20) DEFAULT NULL,
  `head` tinyint(4) DEFAULT NULL,
  `major` tinyint(4) DEFAULT NULL,
  `plid` bigint(20) DEFAULT NULL,
  `privateLayout` tinyint(4) DEFAULT NULL,
  `name` longtext,
  `title` longtext,
  `description` longtext,
  `keywords` longtext,
  `robots` longtext,
  `typeSettings` longtext,
  `iconImage` tinyint(4) DEFAULT NULL,
  `iconImageId` bigint(20) DEFAULT NULL,
  `themeId` varchar(75) DEFAULT NULL,
  `colorSchemeId` varchar(75) DEFAULT NULL,
  `wapThemeId` varchar(75) DEFAULT NULL,
  `wapColorSchemeId` varchar(75) DEFAULT NULL,
  `css` longtext,
  `status` int(11) DEFAULT NULL,
  `statusByUserId` bigint(20) DEFAULT NULL,
  `statusByUserName` varchar(75) DEFAULT NULL,
  `statusDate` datetime DEFAULT NULL,
  PRIMARY KEY (`layoutRevisionId`),
  KEY `IX_43E8286A` (`head`,`plid`),
  KEY `IX_314B621A` (`layoutSetBranchId`),
  KEY `IX_A9AC086E` (`layoutSetBranchId`,`head`),
  KEY `IX_E10AC39` (`layoutSetBranchId`,`head`,`plid`),
  KEY `IX_13984800` (`layoutSetBranchId`,`layoutBranchId`,`plid`),
  KEY `IX_4A84AF43` (`layoutSetBranchId`,`parentLayoutRevisionId`,`plid`),
  KEY `IX_B7B914E5` (`layoutSetBranchId`,`plid`),
  KEY `IX_70DA9ECB` (`layoutSetBranchId`,`plid`,`status`),
  KEY `IX_7FFAE700` (`layoutSetBranchId`,`status`),
  KEY `IX_9329C9D6` (`plid`),
  KEY `IX_8EC3D2BC` (`plid`,`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `LayoutRevision`
--

LOCK TABLES `LayoutRevision` WRITE;
/*!40000 ALTER TABLE `LayoutRevision` DISABLE KEYS */;
INSERT INTO `LayoutRevision` VALUES (10717,10688,10154,10196,'Test Test','2014-03-18 17:51:44','2014-03-18 17:51:44',10715,10716,0,1,0,10706,0,'<?xml version=\'1.0\' encoding=\'UTF-8\'?><root available-locales=\"en_US\" default-locale=\"en_US\"><Name language-id=\"en_US\">Message Boards Page</Name></root>','','','','','layout-template-id=2_columns_ii\n',0,0,'','','','','',0,10196,'Test Test','2014-03-18 17:51:44'),(10726,10688,10154,10196,'Test Test','2014-03-18 17:51:56','2014-03-18 17:51:56',10715,10716,10717,0,0,10706,0,'<?xml version=\'1.0\' encoding=\'UTF-8\'?><root available-locales=\"en_US\" default-locale=\"en_US\"><Name language-id=\"en_US\">Message Boards Page</Name></root>','','','','','layout-template-id=2_columns_ii\ncolumn-1=19\n',0,0,'','','','','',2,0,'','2014-03-18 17:51:56');
/*!40000 ALTER TABLE `LayoutRevision` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `LayoutSet`
--

DROP TABLE IF EXISTS `LayoutSet`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `LayoutSet` (
  `layoutSetId` bigint(20) NOT NULL,
  `groupId` bigint(20) DEFAULT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `createDate` datetime DEFAULT NULL,
  `modifiedDate` datetime DEFAULT NULL,
  `privateLayout` tinyint(4) DEFAULT NULL,
  `logo` tinyint(4) DEFAULT NULL,
  `logoId` bigint(20) DEFAULT NULL,
  `themeId` varchar(75) DEFAULT NULL,
  `colorSchemeId` varchar(75) DEFAULT NULL,
  `wapThemeId` varchar(75) DEFAULT NULL,
  `wapColorSchemeId` varchar(75) DEFAULT NULL,
  `css` longtext,
  `pageCount` int(11) DEFAULT NULL,
  `settings_` longtext,
  `layoutSetPrototypeUuid` varchar(75) DEFAULT NULL,
  `layoutSetPrototypeLinkEnabled` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`layoutSetId`),
  UNIQUE KEY `IX_48550691` (`groupId`,`privateLayout`),
  KEY `IX_A40B8BEC` (`groupId`),
  KEY `IX_72BBA8B7` (`layoutSetPrototypeUuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `LayoutSet`
--

LOCK TABLES `LayoutSet` WRITE;
/*!40000 ALTER TABLE `LayoutSet` DISABLE KEYS */;
INSERT INTO `LayoutSet` VALUES (10173,10172,10154,'2014-03-18 17:33:37','2014-03-18 17:33:37',1,0,0,'classic','01','mobile','01','',1,'','',0),(10174,10172,10154,'2014-03-18 17:33:37','2014-03-18 17:33:37',0,0,0,'classic','01','mobile','01','',0,'','',0),(10181,10180,10154,'2014-03-18 17:33:37','2014-03-18 17:33:37',1,0,0,'classic','01','mobile','01','',0,'','',0),(10182,10180,10154,'2014-03-18 17:33:37','2014-03-18 17:59:30',0,0,0,'classic','01','mobile','01','',7,'','',0),(10190,10189,10154,'2014-03-18 17:33:37','2014-03-18 17:33:37',1,0,0,'classic','01','mobile','01','',0,'','',0),(10191,10189,10154,'2014-03-18 17:33:37','2014-03-18 17:33:37',0,0,0,'classic','01','mobile','01','',0,'','',0),(10193,10192,10154,'2014-03-18 17:33:37','2014-03-18 17:33:37',1,0,0,'classic','01','mobile','01','',0,'','',0),(10194,10192,10154,'2014-03-18 17:33:37','2014-03-18 17:33:37',0,0,0,'classic','01','mobile','01','',0,'','',0),(10199,10198,10154,'2014-03-18 17:33:37','2014-03-18 17:34:21',1,0,0,'classic','01','mobile','01','',1,'','',0),(10200,10198,10154,'2014-03-18 17:33:37','2014-03-18 17:34:21',0,0,0,'classic','01','mobile','01','',1,'','',0),(10311,10310,10154,'2014-03-18 17:33:39','2014-03-18 17:33:39',1,0,0,'classic','01','mobile','01','',1,'','',0),(10312,10310,10154,'2014-03-18 17:33:39','2014-03-18 17:33:39',0,0,0,'classic','01','mobile','01','',0,'','',0),(10321,10320,10154,'2014-03-18 17:33:39','2014-03-18 17:33:39',1,0,0,'classic','01','mobile','01','',1,'','',0),(10322,10320,10154,'2014-03-18 17:33:39','2014-03-18 17:33:39',0,0,0,'classic','01','mobile','01','',0,'','',0),(10330,10329,10154,'2014-03-18 17:33:39','2014-03-18 17:33:39',1,0,0,'classic','01','mobile','01','',1,'','',0),(10331,10329,10154,'2014-03-18 17:33:39','2014-03-18 17:33:39',0,0,0,'classic','01','mobile','01','',0,'','',0),(10339,10338,10154,'2014-03-18 17:33:39','2014-03-18 17:33:40',1,0,0,'classic','01','mobile','01','',3,'','',0),(10340,10338,10154,'2014-03-18 17:33:39','2014-03-18 17:33:39',0,0,0,'classic','01','mobile','01','',0,'','',0),(10365,10364,10154,'2014-03-18 17:33:40','2014-03-18 17:33:40',1,0,0,'classic','01','mobile','01','',4,'','',0),(10366,10364,10154,'2014-03-18 17:33:40','2014-03-18 17:33:40',0,0,0,'classic','01','mobile','01','',0,'','',0),(10451,10450,10154,'2014-03-18 17:35:41','2014-03-18 17:35:41',1,0,0,'classic','01','mobile','01','',0,'','',0),(10452,10450,10154,'2014-03-18 17:35:41','2014-03-18 17:35:41',0,0,0,'classic','01','mobile','01','',0,'','',0),(10461,10460,10154,'2014-03-18 17:36:49','2014-03-18 17:36:49',1,0,0,'classic','01','mobile','01','',0,'','',0),(10462,10460,10154,'2014-03-18 17:36:49','2014-03-18 17:36:49',0,0,0,'classic','01','mobile','01','',0,'','',0),(10468,10467,10154,'2014-03-18 17:37:26','2014-03-18 17:37:26',1,0,0,'classic','01','mobile','01','',0,'','',0),(10469,10467,10154,'2014-03-18 17:37:26','2014-03-18 17:37:44',0,0,0,'classic','01','mobile','01','',1,'','',0),(10510,10509,10154,'2014-03-18 17:39:28','2014-03-18 17:39:28',1,0,0,'classic','01','mobile','01','',0,'','',0),(10511,10509,10154,'2014-03-18 17:39:28','2014-03-18 17:39:42',0,0,0,'classic','01','mobile','01','',1,'','',0),(10523,10522,10154,'2014-03-18 17:41:21','2014-03-18 17:41:21',1,0,0,'classic','01','mobile','01','',0,'','',0),(10524,10522,10154,'2014-03-18 17:41:21','2014-03-18 17:41:35',0,0,0,'classic','01','mobile','01','',1,'','',0),(10548,10547,10154,'2014-03-18 17:42:28','2014-03-18 17:42:28',1,0,0,'classic','01','mobile','01','',1,'','',0),(10549,10547,10154,'2014-03-18 17:42:28','2014-03-18 17:42:28',0,0,0,'classic','01','mobile','01','',0,'','',0),(10558,10557,10154,'2014-03-18 17:42:56','2014-03-18 17:42:56',1,0,0,'classic','01','mobile','01','',0,'','',0),(10559,10557,10154,'2014-03-18 17:42:56','2014-03-18 17:43:11',0,0,0,'classic','01','mobile','01','',1,'','',0),(10592,10591,10154,'2014-03-18 17:45:09','2014-03-18 17:45:09',1,0,0,'classic','01','mobile','01','',1,'','',0),(10593,10591,10154,'2014-03-18 17:45:09','2014-03-18 17:45:09',0,0,0,'classic','01','mobile','01','',0,'','',0),(10604,10603,10154,'2014-03-18 17:45:50','2014-03-18 17:46:17',1,0,0,'classic','01','mobile','01','',1,'','',0),(10605,10603,10154,'2014-03-18 17:45:50','2014-03-18 17:46:17',0,0,0,'classic','01','mobile','01','',1,'','',0),(10647,10646,10154,'2014-03-18 17:49:28','2014-03-18 17:49:28',1,0,0,'classic','01','mobile','01','',0,'','',0),(10648,10646,10154,'2014-03-18 17:49:28','2014-03-18 17:49:28',0,0,0,'classic','01','mobile','01','',0,'','',0),(10653,10652,10154,'2014-03-18 17:49:40','2014-03-18 17:50:07',1,0,0,'classic','01','mobile','01','',1,'','',0),(10654,10652,10154,'2014-03-18 17:49:40','2014-03-18 17:50:07',0,0,0,'classic','01','mobile','01','',1,'','',0),(10680,10679,10154,'2014-03-18 17:51:07','2014-03-18 17:51:43',1,0,0,'classic','01','mobile','01','',0,'','',0),(10681,10679,10154,'2014-03-18 17:51:07','2014-03-18 17:51:44',0,0,0,'classic','01','mobile','01','',1,'last-publish-date=1395165103667\n','',0),(10689,10688,10154,'2014-03-18 17:51:43','2014-03-18 17:51:43',1,0,0,'classic','01','mobile','01','',0,'','',0),(10690,10688,10154,'2014-03-18 17:51:43','2014-03-18 17:51:44',0,0,0,'classic','01','mobile','01','',1,'','',0),(10762,10761,10154,'2014-03-18 17:53:27','2014-03-18 17:53:27',1,0,0,'classic','01','mobile','01','',0,'','',0),(10763,10761,10154,'2014-03-18 17:53:27','2014-03-18 17:53:44',0,0,0,'classic','01','mobile','01','',1,'','',0),(10779,10778,10154,'2014-03-18 17:54:37','2014-03-18 17:54:37',1,0,0,'classic','01','mobile','01','',0,'','',0),(10780,10778,10154,'2014-03-18 17:54:37','2014-03-18 17:54:53',0,0,0,'classic','01','mobile','01','',1,'','',0),(10808,10807,10154,'2014-03-18 17:57:27','2014-03-18 17:57:27',1,0,0,'classic','01','mobile','01','',0,'','',0),(10809,10807,10154,'2014-03-18 17:57:27','2014-03-18 17:57:43',0,0,0,'classic','01','mobile','01','',1,'','',0),(10851,10850,10154,'2014-03-18 18:00:30','2014-03-18 18:00:30',1,0,0,'classic','01','mobile','01','',0,'','',0),(10852,10850,10154,'2014-03-18 18:00:30','2014-03-18 18:00:30',0,0,0,'classic','01','mobile','01','',0,'','',0),(10858,10857,10154,'2014-03-18 18:01:16','2014-03-18 18:01:16',1,0,0,'classic','01','mobile','01','',0,'','',0),(10859,10857,10154,'2014-03-18 18:01:16','2014-03-18 18:01:31',0,0,0,'classic','01','mobile','01','',1,'','',0),(10904,10903,10154,'2014-07-08 22:42:33','2014-07-08 22:43:07',1,0,0,'classic','01','mobile','01','',2,'','',0),(10905,10903,10154,'2014-07-08 22:42:33','2014-07-08 22:42:33',0,0,0,'classic','01','mobile','01','',0,'','',0),(10923,10922,10154,'2014-07-08 22:45:00','2014-07-08 22:45:00',1,0,0,'classic','01','mobile','01','',0,'','',0),(10924,10922,10154,'2014-07-08 22:45:00','2014-07-08 22:45:01',0,0,0,'classic','01','mobile','01','',2,'last-merge-time=1404859501272\n','05f2799b-2f37-4848-b281-aaa21c22ce99',1),(10947,10946,10154,'2014-07-08 22:46:27','2014-07-08 22:46:27',1,0,0,'classic','01','mobile','01','',0,'','',0),(10948,10946,10154,'2014-07-08 22:46:27','2014-07-08 22:47:38',0,0,0,'classic','01','mobile','01','',2,'last-merge-time=1404859501272','',0);
/*!40000 ALTER TABLE `LayoutSet` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `LayoutSetBranch`
--

DROP TABLE IF EXISTS `LayoutSetBranch`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `LayoutSetBranch` (
  `layoutSetBranchId` bigint(20) NOT NULL,
  `groupId` bigint(20) DEFAULT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `userId` bigint(20) DEFAULT NULL,
  `userName` varchar(75) DEFAULT NULL,
  `createDate` datetime DEFAULT NULL,
  `modifiedDate` datetime DEFAULT NULL,
  `privateLayout` tinyint(4) DEFAULT NULL,
  `name` varchar(75) DEFAULT NULL,
  `description` longtext,
  `master` tinyint(4) DEFAULT NULL,
  `logo` tinyint(4) DEFAULT NULL,
  `logoId` bigint(20) DEFAULT NULL,
  `themeId` varchar(75) DEFAULT NULL,
  `colorSchemeId` varchar(75) DEFAULT NULL,
  `wapThemeId` varchar(75) DEFAULT NULL,
  `wapColorSchemeId` varchar(75) DEFAULT NULL,
  `css` longtext,
  `settings_` longtext,
  `layoutSetPrototypeUuid` varchar(75) DEFAULT NULL,
  `layoutSetPrototypeLinkEnabled` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`layoutSetBranchId`),
  UNIQUE KEY `IX_5FF18552` (`groupId`,`privateLayout`,`name`),
  KEY `IX_8FF5D6EA` (`groupId`),
  KEY `IX_C4079FD3` (`groupId`,`privateLayout`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `LayoutSetBranch`
--

LOCK TABLES `LayoutSetBranch` WRITE;
/*!40000 ALTER TABLE `LayoutSetBranch` DISABLE KEYS */;
INSERT INTO `LayoutSetBranch` VALUES (10715,10688,10154,10196,'Test Test','2014-03-18 17:51:44','2014-03-18 17:51:44',0,'main-variation','Main Site Pages Variation of Staging Site',1,0,0,'classic','01','mobile','01','','','',0),(10721,10688,10154,10196,'Test Test','2014-03-18 17:51:44','2014-03-18 17:51:44',1,'main-variation','Main Site Pages Variation of Staging Site',1,0,0,'classic','01','mobile','01','','','',0);
/*!40000 ALTER TABLE `LayoutSetBranch` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `LayoutSetPrototype`
--

DROP TABLE IF EXISTS `LayoutSetPrototype`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `LayoutSetPrototype` (
  `uuid_` varchar(75) DEFAULT NULL,
  `layoutSetPrototypeId` bigint(20) NOT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `createDate` datetime DEFAULT NULL,
  `modifiedDate` datetime DEFAULT NULL,
  `name` longtext,
  `description` longtext,
  `settings_` longtext,
  `active_` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`layoutSetPrototypeId`),
  KEY `IX_55F63D98` (`companyId`),
  KEY `IX_9178FC71` (`companyId`,`active_`),
  KEY `IX_C5D69B24` (`uuid_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `LayoutSetPrototype`
--

LOCK TABLES `LayoutSetPrototype` WRITE;
/*!40000 ALTER TABLE `LayoutSetPrototype` DISABLE KEYS */;
INSERT INTO `LayoutSetPrototype` VALUES ('39029029-be3d-40b1-b724-42991b5fe124',10337,10154,'2014-03-18 17:33:39','2014-03-18 17:33:40','<?xml version=\'1.0\' encoding=\'UTF-8\'?><root available-locales=\"en_US\" default-locale=\"en_US\"><Name language-id=\"en_US\">Community Site</Name></root>','Site with Forums, Calendar and Wiki','layoutsUpdateable=true\n',1),('34fd9e6b-b1fe-4a53-8c09-4e4efd09b5b7',10363,10154,'2014-03-18 17:33:40','2014-03-18 17:33:40','<?xml version=\'1.0\' encoding=\'UTF-8\'?><root available-locales=\"en_US\" default-locale=\"en_US\"><Name language-id=\"en_US\">Intranet Site</Name></root>','Site with Documents, Calendar and News','layoutsUpdateable=true\n',1),('b2f8c85d-16e1-47e2-abe3-38253d7870da',10590,10154,'2014-03-18 17:45:09','2014-03-18 17:45:09','<?xml version=\'1.0\' encoding=\'UTF-8\'?><root available-locales=\"en_US\" default-locale=\"en_US\"><Name language-id=\"en_US\">Site Template Name</Name></root>','','layoutsUpdateable=true\n',1),('05f2799b-2f37-4848-b281-aaa21c22ce99',10902,10154,'2014-07-08 22:42:33','2014-07-08 22:43:07','<?xml version=\'1.0\' encoding=\'UTF-8\'?><root available-locales=\"en_US\" default-locale=\"en_US\"><Name language-id=\"en_US\">AP Site Template</Name></root>','','layoutsUpdateable=true\n',1);
/*!40000 ALTER TABLE `LayoutSetPrototype` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ListType`
--

DROP TABLE IF EXISTS `ListType`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ListType` (
  `listTypeId` int(11) NOT NULL,
  `name` varchar(75) DEFAULT NULL,
  `type_` varchar(75) DEFAULT NULL,
  PRIMARY KEY (`listTypeId`),
  KEY `IX_2932DD37` (`type_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ListType`
--

LOCK TABLES `ListType` WRITE;
/*!40000 ALTER TABLE `ListType` DISABLE KEYS */;
INSERT INTO `ListType` VALUES (10000,'billing','com.liferay.portal.model.Account.address'),(10001,'other','com.liferay.portal.model.Account.address'),(10002,'p-o-box','com.liferay.portal.model.Account.address'),(10003,'shipping','com.liferay.portal.model.Account.address'),(10004,'email-address','com.liferay.portal.model.Account.emailAddress'),(10005,'email-address-2','com.liferay.portal.model.Account.emailAddress'),(10006,'email-address-3','com.liferay.portal.model.Account.emailAddress'),(10007,'fax','com.liferay.portal.model.Account.phone'),(10008,'local','com.liferay.portal.model.Account.phone'),(10009,'other','com.liferay.portal.model.Account.phone'),(10010,'toll-free','com.liferay.portal.model.Account.phone'),(10011,'tty','com.liferay.portal.model.Account.phone'),(10012,'intranet','com.liferay.portal.model.Account.website'),(10013,'public','com.liferay.portal.model.Account.website'),(11000,'business','com.liferay.portal.model.Contact.address'),(11001,'other','com.liferay.portal.model.Contact.address'),(11002,'personal','com.liferay.portal.model.Contact.address'),(11003,'email-address','com.liferay.portal.model.Contact.emailAddress'),(11004,'email-address-2','com.liferay.portal.model.Contact.emailAddress'),(11005,'email-address-3','com.liferay.portal.model.Contact.emailAddress'),(11006,'business','com.liferay.portal.model.Contact.phone'),(11007,'business-fax','com.liferay.portal.model.Contact.phone'),(11008,'mobile-phone','com.liferay.portal.model.Contact.phone'),(11009,'other','com.liferay.portal.model.Contact.phone'),(11010,'pager','com.liferay.portal.model.Contact.phone'),(11011,'personal','com.liferay.portal.model.Contact.phone'),(11012,'personal-fax','com.liferay.portal.model.Contact.phone'),(11013,'tty','com.liferay.portal.model.Contact.phone'),(11014,'dr','com.liferay.portal.model.Contact.prefix'),(11015,'mr','com.liferay.portal.model.Contact.prefix'),(11016,'mrs','com.liferay.portal.model.Contact.prefix'),(11017,'ms','com.liferay.portal.model.Contact.prefix'),(11020,'ii','com.liferay.portal.model.Contact.suffix'),(11021,'iii','com.liferay.portal.model.Contact.suffix'),(11022,'iv','com.liferay.portal.model.Contact.suffix'),(11023,'jr','com.liferay.portal.model.Contact.suffix'),(11024,'phd','com.liferay.portal.model.Contact.suffix'),(11025,'sr','com.liferay.portal.model.Contact.suffix'),(11026,'blog','com.liferay.portal.model.Contact.website'),(11027,'business','com.liferay.portal.model.Contact.website'),(11028,'other','com.liferay.portal.model.Contact.website'),(11029,'personal','com.liferay.portal.model.Contact.website'),(12000,'billing','com.liferay.portal.model.Organization.address'),(12001,'other','com.liferay.portal.model.Organization.address'),(12002,'p-o-box','com.liferay.portal.model.Organization.address'),(12003,'shipping','com.liferay.portal.model.Organization.address'),(12004,'email-address','com.liferay.portal.model.Organization.emailAddress'),(12005,'email-address-2','com.liferay.portal.model.Organization.emailAddress'),(12006,'email-address-3','com.liferay.portal.model.Organization.emailAddress'),(12007,'fax','com.liferay.portal.model.Organization.phone'),(12008,'local','com.liferay.portal.model.Organization.phone'),(12009,'other','com.liferay.portal.model.Organization.phone'),(12010,'toll-free','com.liferay.portal.model.Organization.phone'),(12011,'tty','com.liferay.portal.model.Organization.phone'),(12012,'administrative','com.liferay.portal.model.Organization.service'),(12013,'contracts','com.liferay.portal.model.Organization.service'),(12014,'donation','com.liferay.portal.model.Organization.service'),(12015,'retail','com.liferay.portal.model.Organization.service'),(12016,'training','com.liferay.portal.model.Organization.service'),(12017,'full-member','com.liferay.portal.model.Organization.status'),(12018,'provisional-member','com.liferay.portal.model.Organization.status'),(12019,'intranet','com.liferay.portal.model.Organization.website'),(12020,'public','com.liferay.portal.model.Organization.website');
/*!40000 ALTER TABLE `ListType` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Lock_`
--

DROP TABLE IF EXISTS `Lock_`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Lock_` (
  `uuid_` varchar(75) DEFAULT NULL,
  `lockId` bigint(20) NOT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `userId` bigint(20) DEFAULT NULL,
  `userName` varchar(75) DEFAULT NULL,
  `createDate` datetime DEFAULT NULL,
  `className` varchar(75) DEFAULT NULL,
  `key_` varchar(200) DEFAULT NULL,
  `owner` varchar(255) DEFAULT NULL,
  `inheritable` tinyint(4) DEFAULT NULL,
  `expirationDate` datetime DEFAULT NULL,
  PRIMARY KEY (`lockId`),
  UNIQUE KEY `IX_DD635956` (`className`,`key_`,`owner`),
  KEY `IX_228562AD` (`className`,`key_`),
  KEY `IX_E3F1286B` (`expirationDate`),
  KEY `IX_13C5CD3A` (`uuid_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Lock_`
--

LOCK TABLES `Lock_` WRITE;
/*!40000 ALTER TABLE `Lock_` DISABLE KEYS */;
/*!40000 ALTER TABLE `Lock_` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MBBan`
--

DROP TABLE IF EXISTS `MBBan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `MBBan` (
  `banId` bigint(20) NOT NULL,
  `groupId` bigint(20) DEFAULT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `userId` bigint(20) DEFAULT NULL,
  `userName` varchar(75) DEFAULT NULL,
  `createDate` datetime DEFAULT NULL,
  `modifiedDate` datetime DEFAULT NULL,
  `banUserId` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`banId`),
  UNIQUE KEY `IX_8ABC4E3B` (`groupId`,`banUserId`),
  KEY `IX_69951A25` (`banUserId`),
  KEY `IX_5C3FF12A` (`groupId`),
  KEY `IX_48814BBA` (`userId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MBBan`
--

LOCK TABLES `MBBan` WRITE;
/*!40000 ALTER TABLE `MBBan` DISABLE KEYS */;
/*!40000 ALTER TABLE `MBBan` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MBCategory`
--

DROP TABLE IF EXISTS `MBCategory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `MBCategory` (
  `uuid_` varchar(75) DEFAULT NULL,
  `categoryId` bigint(20) NOT NULL,
  `groupId` bigint(20) DEFAULT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `userId` bigint(20) DEFAULT NULL,
  `userName` varchar(75) DEFAULT NULL,
  `createDate` datetime DEFAULT NULL,
  `modifiedDate` datetime DEFAULT NULL,
  `parentCategoryId` bigint(20) DEFAULT NULL,
  `name` varchar(75) DEFAULT NULL,
  `description` longtext,
  `displayStyle` varchar(75) DEFAULT NULL,
  `threadCount` int(11) DEFAULT NULL,
  `messageCount` int(11) DEFAULT NULL,
  `lastPostDate` datetime DEFAULT NULL,
  PRIMARY KEY (`categoryId`),
  UNIQUE KEY `IX_F7D28C2F` (`uuid_`,`groupId`),
  KEY `IX_BC735DCF` (`companyId`),
  KEY `IX_BB870C11` (`groupId`),
  KEY `IX_ED292508` (`groupId`,`parentCategoryId`),
  KEY `IX_C2626EDB` (`uuid_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MBCategory`
--

LOCK TABLES `MBCategory` WRITE;
/*!40000 ALTER TABLE `MBCategory` DISABLE KEYS */;
INSERT INTO `MBCategory` VALUES ('f6d4c688-a351-470f-9bcd-158f73dc366d',10735,10688,10154,10196,'Test Test','2014-03-18 17:52:07','2014-03-18 17:52:07',0,'MB Category Name','','default',0,0,NULL);
/*!40000 ALTER TABLE `MBCategory` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MBDiscussion`
--

DROP TABLE IF EXISTS `MBDiscussion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `MBDiscussion` (
  `discussionId` bigint(20) NOT NULL,
  `classNameId` bigint(20) DEFAULT NULL,
  `classPK` bigint(20) DEFAULT NULL,
  `threadId` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`discussionId`),
  UNIQUE KEY `IX_33A4DE38` (`classNameId`,`classPK`),
  UNIQUE KEY `IX_B5CA2DC` (`threadId`),
  KEY `IX_79D0120B` (`classNameId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MBDiscussion`
--

LOCK TABLES `MBDiscussion` WRITE;
/*!40000 ALTER TABLE `MBDiscussion` DISABLE KEYS */;
INSERT INTO `MBDiscussion` VALUES (10179,10002,10175,10177),(10187,10002,10183,10185),(10318,10002,10313,10315),(10327,10002,10323,10325),(10336,10002,10332,10334),(10350,10002,10346,10348),(10356,10002,10352,10354),(10362,10002,10358,10360),(10376,10002,10372,10374),(10384,10002,10380,10382),(10390,10002,10386,10388),(10396,10002,10392,10394),(10413,10002,10409,10411),(10418,10002,10414,10416),(10428,10002,10424,10426),(10444,10147,10435,10442),(10476,10002,10472,10474),(10488,10013,10483,10486),(10502,10002,10498,10500),(10517,10002,10513,10515),(10530,10002,10526,10528),(10554,10002,10550,10552),(10565,10002,10561,10563),(10598,10002,10594,10596),(10614,10002,10610,10612),(10619,10002,10615,10617),(10631,10002,10627,10629),(10663,10002,10659,10661),(10668,10002,10664,10666),(10687,10002,10683,10685),(10741,10002,10737,10739),(10769,10002,10765,10767),(10786,10002,10782,10784),(10799,10010,10792,10797),(10815,10002,10811,10813),(10825,10002,10821,10823),(10836,10002,10832,10834),(10865,10002,10861,10863),(10910,10002,10906,10908),(10918,10002,10914,10916),(10969,10108,10963,10967);
/*!40000 ALTER TABLE `MBDiscussion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MBMailingList`
--

DROP TABLE IF EXISTS `MBMailingList`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `MBMailingList` (
  `uuid_` varchar(75) DEFAULT NULL,
  `mailingListId` bigint(20) NOT NULL,
  `groupId` bigint(20) DEFAULT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `userId` bigint(20) DEFAULT NULL,
  `userName` varchar(75) DEFAULT NULL,
  `createDate` datetime DEFAULT NULL,
  `modifiedDate` datetime DEFAULT NULL,
  `categoryId` bigint(20) DEFAULT NULL,
  `emailAddress` varchar(75) DEFAULT NULL,
  `inProtocol` varchar(75) DEFAULT NULL,
  `inServerName` varchar(75) DEFAULT NULL,
  `inServerPort` int(11) DEFAULT NULL,
  `inUseSSL` tinyint(4) DEFAULT NULL,
  `inUserName` varchar(75) DEFAULT NULL,
  `inPassword` varchar(75) DEFAULT NULL,
  `inReadInterval` int(11) DEFAULT NULL,
  `outEmailAddress` varchar(75) DEFAULT NULL,
  `outCustom` tinyint(4) DEFAULT NULL,
  `outServerName` varchar(75) DEFAULT NULL,
  `outServerPort` int(11) DEFAULT NULL,
  `outUseSSL` tinyint(4) DEFAULT NULL,
  `outUserName` varchar(75) DEFAULT NULL,
  `outPassword` varchar(75) DEFAULT NULL,
  `allowAnonymous` tinyint(4) DEFAULT NULL,
  `active_` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`mailingListId`),
  UNIQUE KEY `IX_76CE9CDD` (`groupId`,`categoryId`),
  UNIQUE KEY `IX_E858F170` (`uuid_`,`groupId`),
  KEY `IX_BFEB984F` (`active_`),
  KEY `IX_4115EC7A` (`uuid_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MBMailingList`
--

LOCK TABLES `MBMailingList` WRITE;
/*!40000 ALTER TABLE `MBMailingList` DISABLE KEYS */;
INSERT INTO `MBMailingList` VALUES ('33435453-8136-4f7c-9cf3-106cbd7c4942',10736,10688,10154,10196,'Test Test','2014-03-18 17:52:07','2014-03-18 17:52:07',10735,'','pop3','',110,0,'','',5,'',0,'',25,0,'','',0,0);
/*!40000 ALTER TABLE `MBMailingList` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MBMessage`
--

DROP TABLE IF EXISTS `MBMessage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `MBMessage` (
  `uuid_` varchar(75) DEFAULT NULL,
  `messageId` bigint(20) NOT NULL,
  `groupId` bigint(20) DEFAULT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `userId` bigint(20) DEFAULT NULL,
  `userName` varchar(75) DEFAULT NULL,
  `createDate` datetime DEFAULT NULL,
  `modifiedDate` datetime DEFAULT NULL,
  `classNameId` bigint(20) DEFAULT NULL,
  `classPK` bigint(20) DEFAULT NULL,
  `categoryId` bigint(20) DEFAULT NULL,
  `threadId` bigint(20) DEFAULT NULL,
  `rootMessageId` bigint(20) DEFAULT NULL,
  `parentMessageId` bigint(20) DEFAULT NULL,
  `subject` varchar(75) DEFAULT NULL,
  `body` longtext,
  `format` varchar(75) DEFAULT NULL,
  `attachments` tinyint(4) DEFAULT NULL,
  `anonymous` tinyint(4) DEFAULT NULL,
  `priority` double DEFAULT NULL,
  `allowPingbacks` tinyint(4) DEFAULT NULL,
  `answer` tinyint(4) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `statusByUserId` bigint(20) DEFAULT NULL,
  `statusByUserName` varchar(75) DEFAULT NULL,
  `statusDate` datetime DEFAULT NULL,
  PRIMARY KEY (`messageId`),
  UNIQUE KEY `IX_8D12316E` (`uuid_`,`groupId`),
  KEY `IX_51A8D44D` (`classNameId`,`classPK`),
  KEY `IX_F6687633` (`classNameId`,`classPK`,`status`),
  KEY `IX_B1432D30` (`companyId`),
  KEY `IX_1AD93C16` (`companyId`,`status`),
  KEY `IX_5B153FB2` (`groupId`),
  KEY `IX_1073AB9F` (`groupId`,`categoryId`),
  KEY `IX_4257DB85` (`groupId`,`categoryId`,`status`),
  KEY `IX_B674AB58` (`groupId`,`categoryId`,`threadId`),
  KEY `IX_CBFDBF0A` (`groupId`,`categoryId`,`threadId`,`answer`),
  KEY `IX_385E123E` (`groupId`,`categoryId`,`threadId`,`status`),
  KEY `IX_ED39AC98` (`groupId`,`status`),
  KEY `IX_8EB8C5EC` (`groupId`,`userId`),
  KEY `IX_377858D2` (`groupId`,`userId`,`status`),
  KEY `IX_75B95071` (`threadId`),
  KEY `IX_9D7C3B23` (`threadId`,`answer`),
  KEY `IX_A7038CD7` (`threadId`,`parentMessageId`),
  KEY `IX_9DC8E57` (`threadId`,`status`),
  KEY `IX_7A040C32` (`userId`),
  KEY `IX_59F9CE5C` (`userId`,`classNameId`),
  KEY `IX_ABEB6D07` (`userId`,`classNameId`,`classPK`),
  KEY `IX_4A4BB4ED` (`userId`,`classNameId`,`classPK`,`status`),
  KEY `IX_3321F142` (`userId`,`classNameId`,`status`),
  KEY `IX_C57B16BC` (`uuid_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MBMessage`
--

LOCK TABLES `MBMessage` WRITE;
/*!40000 ALTER TABLE `MBMessage` DISABLE KEYS */;
INSERT INTO `MBMessage` VALUES ('e46c2d1d-3090-4cc7-ac28-bdbbc6027935',10176,10172,10154,10158,'','2014-03-18 17:33:37','2014-03-18 17:33:37',10002,10175,-1,10177,10176,0,'10175','10175','bbcode',0,1,0,0,0,0,10158,'','2014-03-18 17:33:37'),('b6298931-eaf0-4fc4-8d42-d07d9fd835f9',10184,10180,10154,10158,'','2014-03-18 17:33:37','2014-03-18 17:33:37',10002,10183,-1,10185,10184,0,'10183','10183','bbcode',0,1,0,0,0,0,10158,'','2014-03-18 17:33:37'),('bb2314d6-1d96-4501-8e21-4843dd569fec',10314,10310,10154,10158,'','2014-03-18 17:33:39','2014-03-18 17:33:39',10002,10313,-1,10315,10314,0,'10313','10313','bbcode',0,1,0,0,0,0,10158,'','2014-03-18 17:33:39'),('f863ef6d-96a5-4e97-829a-b4fe8c512e44',10324,10320,10154,10158,'','2014-03-18 17:33:39','2014-03-18 17:33:39',10002,10323,-1,10325,10324,0,'10323','10323','bbcode',0,1,0,0,0,0,10158,'','2014-03-18 17:33:39'),('4218d01f-d180-4648-a299-3afb3da0b521',10333,10329,10154,10158,'','2014-03-18 17:33:39','2014-03-18 17:33:39',10002,10332,-1,10334,10333,0,'10332','10332','bbcode',0,1,0,0,0,0,10158,'','2014-03-18 17:33:39'),('57bb9ac3-ceb4-4b12-9cc1-d1f4dbfa8bec',10347,10338,10154,10158,'','2014-03-18 17:33:40','2014-03-18 17:33:40',10002,10346,-1,10348,10347,0,'10346','10346','bbcode',0,1,0,0,0,0,10158,'','2014-03-18 17:33:40'),('30531bfa-404d-499c-a795-a70fbb3125df',10353,10338,10154,10158,'','2014-03-18 17:33:40','2014-03-18 17:33:40',10002,10352,-1,10354,10353,0,'10352','10352','bbcode',0,1,0,0,0,0,10158,'','2014-03-18 17:33:40'),('f26790f6-baa1-4063-9ce1-0ba0e34d72d3',10359,10338,10154,10158,'','2014-03-18 17:33:40','2014-03-18 17:33:40',10002,10358,-1,10360,10359,0,'10358','10358','bbcode',0,1,0,0,0,0,10158,'','2014-03-18 17:33:40'),('6d7e5dab-a32c-446c-80bb-5997ce53c1db',10373,10364,10154,10158,'','2014-03-18 17:33:40','2014-03-18 17:33:40',10002,10372,-1,10374,10373,0,'10372','10372','bbcode',0,1,0,0,0,0,10158,'','2014-03-18 17:33:40'),('6e5d1e57-9c2d-4985-a6dd-6177cca9e552',10381,10364,10154,10158,'','2014-03-18 17:33:40','2014-03-18 17:33:40',10002,10380,-1,10382,10381,0,'10380','10380','bbcode',0,1,0,0,0,0,10158,'','2014-03-18 17:33:40'),('d8bed651-7fca-477e-be43-52822e5fbf36',10387,10364,10154,10158,'','2014-03-18 17:33:40','2014-03-18 17:33:40',10002,10386,-1,10388,10387,0,'10386','10386','bbcode',0,1,0,0,0,0,10158,'','2014-03-18 17:33:40'),('331edc1e-5015-4f12-823f-d6e4b5b62ca0',10393,10364,10154,10158,'','2014-03-18 17:33:40','2014-03-18 17:33:40',10002,10392,-1,10394,10393,0,'10392','10392','bbcode',0,1,0,0,0,0,10158,'','2014-03-18 17:33:40'),('155b37ca-c514-42a0-a1a9-7962f3c50995',10410,10198,10154,10196,'Test Test','2014-03-18 17:34:21','2014-03-18 17:34:21',10002,10409,-1,10411,10410,0,'10409','10409','bbcode',0,0,0,0,0,0,10196,'Test Test','2014-03-18 17:34:21'),('981a5003-102d-468c-8157-d9615971870b',10415,10198,10154,10196,'Test Test','2014-03-18 17:34:21','2014-03-18 17:34:21',10002,10414,-1,10416,10415,0,'10414','10414','bbcode',0,0,0,0,0,0,10196,'Test Test','2014-03-18 17:34:21'),('f52ecc7d-4c70-4b49-995d-e38ad91fabaf',10425,10180,10154,10196,'Test Test','2014-03-18 17:34:33','2014-03-18 17:34:33',10002,10424,-1,10426,10425,0,'10424','10424','bbcode',0,0,0,0,0,0,10196,'Test Test','2014-03-18 17:34:33'),('f5101096-864b-421e-958c-4e143669e4fd',10441,10180,10154,10196,'Test Test','2014-03-18 17:35:03','2014-03-18 17:35:03',10147,10435,-1,10442,10441,0,'10435','10435','bbcode',0,0,0,0,0,0,10196,'Test Test','2014-03-18 17:35:03'),('381f0d58-f788-4274-b67b-05a00f68afda',10473,10467,10154,10196,'Test Test','2014-03-18 17:37:44','2014-03-18 17:37:44',10002,10472,-1,10474,10473,0,'10472','10472','bbcode',0,0,0,0,0,0,10196,'Test Test','2014-03-18 17:37:44'),('6b291213-4a32-4a04-a0df-9ce0b1435fe3',10485,10467,10154,10196,'Test Test','2014-03-18 17:37:54','2014-03-18 17:37:54',10013,10483,-1,10486,10485,0,'10483','10483','bbcode',0,0,0,0,0,0,10196,'Test Test','2014-03-18 17:37:54'),('b7cd8b1d-3e55-436e-b678-d0c23daf5812',10499,10180,10154,10196,'Test Test','2014-03-18 17:38:43','2014-03-18 17:38:43',10002,10498,-1,10500,10499,0,'10498','10498','bbcode',0,0,0,0,0,0,10196,'Test Test','2014-03-18 17:38:43'),('2e3cc653-40e4-417a-ae78-07802b82b1ab',10514,10509,10154,10196,'Test Test','2014-03-18 17:39:42','2014-03-18 17:39:42',10002,10513,-1,10515,10514,0,'10513','10513','bbcode',0,0,0,0,0,0,10196,'Test Test','2014-03-18 17:39:42'),('7beacb85-d3ba-46cb-90fc-f12ee454f115',10527,10522,10154,10196,'Test Test','2014-03-18 17:41:35','2014-03-18 17:41:35',10002,10526,-1,10528,10527,0,'10526','10526','bbcode',0,0,0,0,0,0,10196,'Test Test','2014-03-18 17:41:35'),('ddee02bb-92ec-4fb4-854f-4a5ef92f9448',10551,10547,10154,10196,'Test Test','2014-03-18 17:42:28','2014-03-18 17:42:28',10002,10550,-1,10552,10551,0,'10550','10550','bbcode',0,0,0,0,0,0,10196,'Test Test','2014-03-18 17:42:28'),('51879ae9-4a4f-4058-ab57-af15ff1ad1d1',10562,10557,10154,10196,'Test Test','2014-03-18 17:43:11','2014-03-18 17:43:11',10002,10561,-1,10563,10562,0,'10561','10561','bbcode',0,0,0,0,0,0,10196,'Test Test','2014-03-18 17:43:11'),('60b917bb-0a2b-4194-9daf-53929e590c9e',10595,10591,10154,10196,'Test Test','2014-03-18 17:45:09','2014-03-18 17:45:09',10002,10594,-1,10596,10595,0,'10594','10594','bbcode',0,0,0,0,0,0,10196,'Test Test','2014-03-18 17:45:09'),('9ac1918d-f73f-4a05-bd47-81ec59f457a0',10611,10603,10154,10601,'userPPfn userPPln','2014-03-18 17:46:17','2014-03-18 17:46:17',10002,10610,-1,10612,10611,0,'10610','10610','bbcode',0,0,0,0,0,0,10601,'userPPfn userPPln','2014-03-18 17:46:17'),('4b8bc74e-3084-4dcf-b800-dd1d7ef61d4d',10616,10603,10154,10601,'userPPfn userPPln','2014-03-18 17:46:17','2014-03-18 17:46:17',10002,10615,-1,10617,10616,0,'10615','10615','bbcode',0,0,0,0,0,0,10601,'userPPfn userPPln','2014-03-18 17:46:17'),('15c8194a-e203-44e6-bd16-55975923a635',10628,10180,10154,10196,'Test Test','2014-03-18 17:48:15','2014-03-18 17:48:15',10002,10627,-1,10629,10628,0,'10627','10627','bbcode',0,0,0,0,0,0,10196,'Test Test','2014-03-18 17:48:15'),('61dbbcb8-8710-4687-9c3c-32367e4a0631',10660,10652,10154,10650,'userSMfn userSMln','2014-03-18 17:50:07','2014-03-18 17:50:07',10002,10659,-1,10661,10660,0,'10659','10659','bbcode',0,0,0,0,0,0,10650,'userSMfn userSMln','2014-03-18 17:50:07'),('517f7fbc-dd62-4ade-8c28-6e0a857d0db9',10665,10652,10154,10650,'userSMfn userSMln','2014-03-18 17:50:07','2014-03-18 17:50:07',10002,10664,-1,10666,10665,0,'10664','10664','bbcode',0,0,0,0,0,0,10650,'userSMfn userSMln','2014-03-18 17:50:07'),('97d6d8c4-2738-4a0e-b6bc-b12debf5acc9',10684,10679,10154,10196,'Test Test','2014-03-18 17:51:23','2014-03-18 17:51:23',10002,10683,-1,10685,10684,0,'10683','10683','bbcode',0,0,0,0,0,0,10196,'Test Test','2014-03-18 17:51:23'),('618f8f7e-22a8-4b17-a392-2429aae5f537',10738,10180,10154,10196,'Test Test','2014-03-18 17:52:33','2014-03-18 17:52:33',10002,10737,-1,10739,10738,0,'10737','10737','bbcode',0,0,0,0,0,0,10196,'Test Test','2014-03-18 17:52:33'),('0c4cf9b3-69a8-4234-a42c-02f5cec1718f',10766,10761,10154,10196,'Test Test','2014-03-18 17:53:44','2014-03-18 17:53:44',10002,10765,-1,10767,10766,0,'10765','10765','bbcode',0,0,0,0,0,0,10196,'Test Test','2014-03-18 17:53:44'),('58ccfe7c-6690-4948-9659-623af0c3006b',10783,10778,10154,10196,'Test Test','2014-03-18 17:54:53','2014-03-18 17:54:53',10002,10782,-1,10784,10783,0,'10782','10782','bbcode',0,0,0,0,0,0,10196,'Test Test','2014-03-18 17:54:53'),('c732763a-ab1c-4346-81d7-8fe1be895fca',10796,10778,10154,10196,'Test Test','2014-03-18 17:55:13','2014-03-18 17:55:13',10010,10792,-1,10797,10796,0,'10792','10792','bbcode',0,0,0,0,0,0,10196,'Test Test','2014-03-18 17:55:13'),('a5bce8e8-d779-490d-a724-6c932d8444e9',10812,10807,10154,10196,'Test Test','2014-03-18 17:57:43','2014-03-18 17:57:43',10002,10811,-1,10813,10812,0,'10811','10811','bbcode',0,0,0,0,0,0,10196,'Test Test','2014-03-18 17:57:43'),('123d1319-4195-49c4-9c4c-4aa2825863a9',10822,10180,10154,10196,'Test Test','2014-03-18 17:58:52','2014-03-18 17:58:52',10002,10821,-1,10823,10822,0,'10821','10821','bbcode',0,0,0,0,0,0,10196,'Test Test','2014-03-18 17:58:52'),('4babf646-7de3-4b5d-8f50-66374f9d8efb',10833,10180,10154,10196,'Test Test','2014-03-18 17:59:30','2014-03-18 17:59:30',10002,10832,-1,10834,10833,0,'10832','10832','bbcode',0,0,0,0,0,0,10196,'Test Test','2014-03-18 17:59:30'),('9855e2e9-9762-4102-90ce-85c6e23df491',10862,10857,10154,10196,'Test Test','2014-03-18 18:01:31','2014-03-18 18:01:31',10002,10861,-1,10863,10862,0,'10861','10861','bbcode',0,0,0,0,0,0,10196,'Test Test','2014-03-18 18:01:31'),('df30eaa1-9eab-4810-92d2-6e1e7fea3e83',10907,10903,10154,10196,'Test Test','2014-07-08 22:42:33','2014-07-08 22:42:33',10002,10906,-1,10908,10907,0,'10906','10906','bbcode',0,0,0,0,0,0,10196,'Test Test','2014-07-08 22:42:33'),('9bec5b45-20ce-4a2a-b492-b3140d44b980',10915,10903,10154,10196,'Test Test','2014-07-08 22:43:02','2014-07-08 22:43:02',10002,10914,-1,10916,10915,0,'10914','10914','bbcode',0,0,0,0,0,0,10196,'Test Test','2014-07-08 22:43:02'),('7b4fb5d0-84f6-4b91-a957-03146374df0c',10966,10946,10154,10196,'Test Test','2014-07-08 22:49:19','2014-07-08 22:49:19',10108,10963,-1,10967,10966,0,'10963','10963','bbcode',0,0,0,0,0,0,10196,'Test Test','2014-07-08 22:49:19');
/*!40000 ALTER TABLE `MBMessage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MBStatsUser`
--

DROP TABLE IF EXISTS `MBStatsUser`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `MBStatsUser` (
  `statsUserId` bigint(20) NOT NULL,
  `groupId` bigint(20) DEFAULT NULL,
  `userId` bigint(20) DEFAULT NULL,
  `messageCount` int(11) DEFAULT NULL,
  `lastPostDate` datetime DEFAULT NULL,
  PRIMARY KEY (`statsUserId`),
  UNIQUE KEY `IX_9168E2C9` (`groupId`,`userId`),
  KEY `IX_A00A898F` (`groupId`),
  KEY `IX_D33A5445` (`groupId`,`userId`,`messageCount`),
  KEY `IX_847F92B5` (`userId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MBStatsUser`
--

LOCK TABLES `MBStatsUser` WRITE;
/*!40000 ALTER TABLE `MBStatsUser` DISABLE KEYS */;
/*!40000 ALTER TABLE `MBStatsUser` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MBThread`
--

DROP TABLE IF EXISTS `MBThread`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `MBThread` (
  `threadId` bigint(20) NOT NULL,
  `groupId` bigint(20) DEFAULT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `categoryId` bigint(20) DEFAULT NULL,
  `rootMessageId` bigint(20) DEFAULT NULL,
  `rootMessageUserId` bigint(20) DEFAULT NULL,
  `messageCount` int(11) DEFAULT NULL,
  `viewCount` int(11) DEFAULT NULL,
  `lastPostByUserId` bigint(20) DEFAULT NULL,
  `lastPostDate` datetime DEFAULT NULL,
  `priority` double DEFAULT NULL,
  `question` tinyint(4) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `statusByUserId` bigint(20) DEFAULT NULL,
  `statusByUserName` varchar(75) DEFAULT NULL,
  `statusDate` datetime DEFAULT NULL,
  PRIMARY KEY (`threadId`),
  KEY `IX_41F6DC8A` (`categoryId`,`priority`),
  KEY `IX_95C0EA45` (`groupId`),
  KEY `IX_9A2D11B2` (`groupId`,`categoryId`),
  KEY `IX_50F1904A` (`groupId`,`categoryId`,`lastPostDate`),
  KEY `IX_485F7E98` (`groupId`,`categoryId`,`status`),
  KEY `IX_E1E7142B` (`groupId`,`status`),
  KEY `IX_AEDD9CB5` (`lastPostDate`,`priority`),
  KEY `IX_CC993ECB` (`rootMessageId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MBThread`
--

LOCK TABLES `MBThread` WRITE;
/*!40000 ALTER TABLE `MBThread` DISABLE KEYS */;
INSERT INTO `MBThread` VALUES (10177,10172,10154,-1,10176,10158,1,0,0,'2014-03-18 17:33:37',0,0,0,10158,'','2014-03-18 17:33:37'),(10185,10180,10154,-1,10184,10158,1,0,0,'2014-03-18 17:33:37',0,0,0,10158,'','2014-03-18 17:33:37'),(10315,10310,10154,-1,10314,10158,1,0,0,'2014-03-18 17:33:39',0,0,0,10158,'','2014-03-18 17:33:39'),(10325,10320,10154,-1,10324,10158,1,0,0,'2014-03-18 17:33:39',0,0,0,10158,'','2014-03-18 17:33:39'),(10334,10329,10154,-1,10333,10158,1,0,0,'2014-03-18 17:33:39',0,0,0,10158,'','2014-03-18 17:33:39'),(10348,10338,10154,-1,10347,10158,1,0,0,'2014-03-18 17:33:40',0,0,0,10158,'','2014-03-18 17:33:40'),(10354,10338,10154,-1,10353,10158,1,0,0,'2014-03-18 17:33:40',0,0,0,10158,'','2014-03-18 17:33:40'),(10360,10338,10154,-1,10359,10158,1,0,0,'2014-03-18 17:33:40',0,0,0,10158,'','2014-03-18 17:33:40'),(10374,10364,10154,-1,10373,10158,1,0,0,'2014-03-18 17:33:40',0,0,0,10158,'','2014-03-18 17:33:40'),(10382,10364,10154,-1,10381,10158,1,0,0,'2014-03-18 17:33:40',0,0,0,10158,'','2014-03-18 17:33:40'),(10388,10364,10154,-1,10387,10158,1,0,0,'2014-03-18 17:33:40',0,0,0,10158,'','2014-03-18 17:33:40'),(10394,10364,10154,-1,10393,10158,1,0,0,'2014-03-18 17:33:40',0,0,0,10158,'','2014-03-18 17:33:40'),(10411,10198,10154,-1,10410,10196,1,0,10196,'2014-03-18 17:34:21',0,0,0,10196,'Test Test','2014-03-18 17:34:21'),(10416,10198,10154,-1,10415,10196,1,0,10196,'2014-03-18 17:34:21',0,0,0,10196,'Test Test','2014-03-18 17:34:21'),(10426,10180,10154,-1,10425,10196,1,0,10196,'2014-03-18 17:34:33',0,0,0,10196,'Test Test','2014-03-18 17:34:33'),(10442,10180,10154,-1,10441,10196,1,0,10196,'2014-03-18 17:35:03',0,0,0,10196,'Test Test','2014-03-18 17:35:03'),(10474,10467,10154,-1,10473,10196,1,0,10196,'2014-03-18 17:37:44',0,0,0,10196,'Test Test','2014-03-18 17:37:44'),(10486,10467,10154,-1,10485,10196,1,0,10196,'2014-03-18 17:37:54',0,0,0,10196,'Test Test','2014-03-18 17:37:54'),(10500,10180,10154,-1,10499,10196,1,0,10196,'2014-03-18 17:38:43',0,0,0,10196,'Test Test','2014-03-18 17:38:43'),(10515,10509,10154,-1,10514,10196,1,0,10196,'2014-03-18 17:39:42',0,0,0,10196,'Test Test','2014-03-18 17:39:42'),(10528,10522,10154,-1,10527,10196,1,0,10196,'2014-03-18 17:41:35',0,0,0,10196,'Test Test','2014-03-18 17:41:35'),(10552,10547,10154,-1,10551,10196,1,0,10196,'2014-03-18 17:42:28',0,0,0,10196,'Test Test','2014-03-18 17:42:28'),(10563,10557,10154,-1,10562,10196,1,0,10196,'2014-03-18 17:43:11',0,0,0,10196,'Test Test','2014-03-18 17:43:11'),(10596,10591,10154,-1,10595,10196,1,0,10196,'2014-03-18 17:45:09',0,0,0,10196,'Test Test','2014-03-18 17:45:09'),(10612,10603,10154,-1,10611,10601,1,0,10601,'2014-03-18 17:46:17',0,0,0,10601,'userPPfn userPPln','2014-03-18 17:46:17'),(10617,10603,10154,-1,10616,10601,1,0,10601,'2014-03-18 17:46:17',0,0,0,10601,'userPPfn userPPln','2014-03-18 17:46:17'),(10629,10180,10154,-1,10628,10196,1,0,10196,'2014-03-18 17:48:15',0,0,0,10196,'Test Test','2014-03-18 17:48:15'),(10661,10652,10154,-1,10660,10650,1,0,10650,'2014-03-18 17:50:07',0,0,0,10650,'userSMfn userSMln','2014-03-18 17:50:07'),(10666,10652,10154,-1,10665,10650,1,0,10650,'2014-03-18 17:50:07',0,0,0,10650,'userSMfn userSMln','2014-03-18 17:50:07'),(10685,10679,10154,-1,10684,10196,1,0,10196,'2014-03-18 17:51:23',0,0,0,10196,'Test Test','2014-03-18 17:51:23'),(10739,10180,10154,-1,10738,10196,1,0,10196,'2014-03-18 17:52:33',0,0,0,10196,'Test Test','2014-03-18 17:52:33'),(10767,10761,10154,-1,10766,10196,1,0,10196,'2014-03-18 17:53:44',0,0,0,10196,'Test Test','2014-03-18 17:53:44'),(10784,10778,10154,-1,10783,10196,1,0,10196,'2014-03-18 17:54:53',0,0,0,10196,'Test Test','2014-03-18 17:54:53'),(10797,10778,10154,-1,10796,10196,1,0,10196,'2014-03-18 17:55:13',0,0,0,10196,'Test Test','2014-03-18 17:55:13'),(10813,10807,10154,-1,10812,10196,1,0,10196,'2014-03-18 17:57:43',0,0,0,10196,'Test Test','2014-03-18 17:57:43'),(10823,10180,10154,-1,10822,10196,1,0,10196,'2014-03-18 17:58:52',0,0,0,10196,'Test Test','2014-03-18 17:58:52'),(10834,10180,10154,-1,10833,10196,1,0,10196,'2014-03-18 17:59:30',0,0,0,10196,'Test Test','2014-03-18 17:59:30'),(10863,10857,10154,-1,10862,10196,1,0,10196,'2014-03-18 18:01:31',0,0,0,10196,'Test Test','2014-03-18 18:01:31'),(10908,10903,10154,-1,10907,10196,1,0,10196,'2014-07-08 22:42:33',0,0,0,10196,'Test Test','2014-07-08 22:42:33'),(10916,10903,10154,-1,10915,10196,1,0,10196,'2014-07-08 22:43:02',0,0,0,10196,'Test Test','2014-07-08 22:43:02'),(10967,10946,10154,-1,10966,10196,1,0,10196,'2014-07-08 22:49:19',0,0,0,10196,'Test Test','2014-07-08 22:49:19');
/*!40000 ALTER TABLE `MBThread` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MBThreadFlag`
--

DROP TABLE IF EXISTS `MBThreadFlag`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `MBThreadFlag` (
  `threadFlagId` bigint(20) NOT NULL,
  `userId` bigint(20) DEFAULT NULL,
  `modifiedDate` datetime DEFAULT NULL,
  `threadId` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`threadFlagId`),
  KEY `IX_8CB0A24A` (`threadId`),
  KEY `IX_A28004B` (`userId`),
  KEY `IX_33781904` (`userId`,`threadId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MBThreadFlag`
--

LOCK TABLES `MBThreadFlag` WRITE;
/*!40000 ALTER TABLE `MBThreadFlag` DISABLE KEYS */;
/*!40000 ALTER TABLE `MBThreadFlag` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MDRAction`
--

DROP TABLE IF EXISTS `MDRAction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `MDRAction` (
  `uuid_` varchar(75) DEFAULT NULL,
  `actionId` bigint(20) NOT NULL,
  `groupId` bigint(20) DEFAULT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `userId` bigint(20) DEFAULT NULL,
  `userName` varchar(75) DEFAULT NULL,
  `createDate` datetime DEFAULT NULL,
  `modifiedDate` datetime DEFAULT NULL,
  `classNameId` bigint(20) DEFAULT NULL,
  `classPK` bigint(20) DEFAULT NULL,
  `ruleGroupInstanceId` bigint(20) DEFAULT NULL,
  `name` longtext,
  `description` longtext,
  `type_` varchar(255) DEFAULT NULL,
  `typeSettings` longtext,
  PRIMARY KEY (`actionId`),
  UNIQUE KEY `IX_75BE36AD` (`uuid_`,`groupId`),
  KEY `IX_FD90786C` (`ruleGroupInstanceId`),
  KEY `IX_77BB5E9D` (`uuid_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MDRAction`
--

LOCK TABLES `MDRAction` WRITE;
/*!40000 ALTER TABLE `MDRAction` DISABLE KEYS */;
INSERT INTO `MDRAction` VALUES ('66bb1153-ac9a-4267-a5d0-171ee4c071a6',10820,10807,10154,10196,'Test Test','2014-03-18 17:58:29','2014-03-18 17:58:29',10029,10809,10819,'<?xml version=\'1.0\' encoding=\'UTF-8\'?><root available-locales=\"en_US\" default-locale=\"en_US\"><Name language-id=\"en_US\">MDR Action Name</Name></root>','','com.liferay.portal.mobile.device.rulegroup.action.impl.SimpleRedirectActionHandler','url=www.liferay.com\n');
/*!40000 ALTER TABLE `MDRAction` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MDRRule`
--

DROP TABLE IF EXISTS `MDRRule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `MDRRule` (
  `uuid_` varchar(75) DEFAULT NULL,
  `ruleId` bigint(20) NOT NULL,
  `groupId` bigint(20) DEFAULT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `userId` bigint(20) DEFAULT NULL,
  `userName` varchar(75) DEFAULT NULL,
  `createDate` datetime DEFAULT NULL,
  `modifiedDate` datetime DEFAULT NULL,
  `ruleGroupId` bigint(20) DEFAULT NULL,
  `name` longtext,
  `description` longtext,
  `type_` varchar(255) DEFAULT NULL,
  `typeSettings` longtext,
  PRIMARY KEY (`ruleId`),
  UNIQUE KEY `IX_F3EFDCB3` (`uuid_`,`groupId`),
  KEY `IX_4F4293F1` (`ruleGroupId`),
  KEY `IX_EA63B9D7` (`uuid_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MDRRule`
--

LOCK TABLES `MDRRule` WRITE;
/*!40000 ALTER TABLE `MDRRule` DISABLE KEYS */;
INSERT INTO `MDRRule` VALUES ('132486b6-249f-4238-8980-17e13de93bb6',10818,10807,10154,10196,'Test Test','2014-03-18 17:58:01','2014-03-18 17:58:01',10817,'<?xml version=\'1.0\' encoding=\'UTF-8\'?><root available-locales=\"en_US\" default-locale=\"en_US\"><Name language-id=\"en_US\">MDR Name</Name></root>','','com.liferay.portal.mobile.device.rulegroup.rule.impl.SimpleRuleHandler','');
/*!40000 ALTER TABLE `MDRRule` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MDRRuleGroup`
--

DROP TABLE IF EXISTS `MDRRuleGroup`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `MDRRuleGroup` (
  `uuid_` varchar(75) DEFAULT NULL,
  `ruleGroupId` bigint(20) NOT NULL,
  `groupId` bigint(20) DEFAULT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `userId` bigint(20) DEFAULT NULL,
  `userName` varchar(75) DEFAULT NULL,
  `createDate` datetime DEFAULT NULL,
  `modifiedDate` datetime DEFAULT NULL,
  `name` longtext,
  `description` longtext,
  PRIMARY KEY (`ruleGroupId`),
  UNIQUE KEY `IX_46665CC4` (`uuid_`,`groupId`),
  KEY `IX_5849891C` (`groupId`),
  KEY `IX_7F26B2A6` (`uuid_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MDRRuleGroup`
--

LOCK TABLES `MDRRuleGroup` WRITE;
/*!40000 ALTER TABLE `MDRRuleGroup` DISABLE KEYS */;
INSERT INTO `MDRRuleGroup` VALUES ('b95f4bd2-c844-4a00-96b8-7331c5f98ede',10817,10807,10154,10196,'Test Test','2014-03-18 17:57:55','2014-03-18 17:57:55','<?xml version=\'1.0\' encoding=\'UTF-8\'?><root available-locales=\"en_US\" default-locale=\"en_US\"><Name language-id=\"en_US\">MDR Group Name</Name></root>','');
/*!40000 ALTER TABLE `MDRRuleGroup` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MDRRuleGroupInstance`
--

DROP TABLE IF EXISTS `MDRRuleGroupInstance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `MDRRuleGroupInstance` (
  `uuid_` varchar(75) DEFAULT NULL,
  `ruleGroupInstanceId` bigint(20) NOT NULL,
  `groupId` bigint(20) DEFAULT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `userId` bigint(20) DEFAULT NULL,
  `userName` varchar(75) DEFAULT NULL,
  `createDate` datetime DEFAULT NULL,
  `modifiedDate` datetime DEFAULT NULL,
  `classNameId` bigint(20) DEFAULT NULL,
  `classPK` bigint(20) DEFAULT NULL,
  `ruleGroupId` bigint(20) DEFAULT NULL,
  `priority` int(11) DEFAULT NULL,
  PRIMARY KEY (`ruleGroupInstanceId`),
  UNIQUE KEY `IX_808A0036` (`classNameId`,`classPK`,`ruleGroupId`),
  UNIQUE KEY `IX_9CBC6A39` (`uuid_`,`groupId`),
  KEY `IX_C95A08D8` (`classNameId`,`classPK`),
  KEY `IX_22DAB85C` (`groupId`,`classNameId`,`classPK`),
  KEY `IX_BF3E642B` (`ruleGroupId`),
  KEY `IX_B6A6BD91` (`uuid_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MDRRuleGroupInstance`
--

LOCK TABLES `MDRRuleGroupInstance` WRITE;
/*!40000 ALTER TABLE `MDRRuleGroupInstance` DISABLE KEYS */;
INSERT INTO `MDRRuleGroupInstance` VALUES ('701ec010-c352-43fb-bc77-1e1ec1d11038',10819,10807,0,10196,'Test Test','2014-03-18 17:58:14','2014-03-18 17:58:14',10029,10809,10817,0);
/*!40000 ALTER TABLE `MDRRuleGroupInstance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MembershipRequest`
--

DROP TABLE IF EXISTS `MembershipRequest`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `MembershipRequest` (
  `membershipRequestId` bigint(20) NOT NULL,
  `groupId` bigint(20) DEFAULT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `userId` bigint(20) DEFAULT NULL,
  `createDate` datetime DEFAULT NULL,
  `comments` longtext,
  `replyComments` longtext,
  `replyDate` datetime DEFAULT NULL,
  `replierUserId` bigint(20) DEFAULT NULL,
  `statusId` int(11) DEFAULT NULL,
  PRIMARY KEY (`membershipRequestId`),
  KEY `IX_8A1CC4B` (`groupId`),
  KEY `IX_C28C72EC` (`groupId`,`statusId`),
  KEY `IX_35AA8FA6` (`groupId`,`userId`,`statusId`),
  KEY `IX_66D70879` (`userId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MembershipRequest`
--

LOCK TABLES `MembershipRequest` WRITE;
/*!40000 ALTER TABLE `MembershipRequest` DISABLE KEYS */;
INSERT INTO `MembershipRequest` VALUES (10678,10646,10154,10650,'2014-03-18 17:50:42','Request Membership Comment','',NULL,0,0);
/*!40000 ALTER TABLE `MembershipRequest` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `OrgGroupPermission`
--

DROP TABLE IF EXISTS `OrgGroupPermission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `OrgGroupPermission` (
  `organizationId` bigint(20) NOT NULL,
  `groupId` bigint(20) NOT NULL,
  `permissionId` bigint(20) NOT NULL,
  PRIMARY KEY (`organizationId`,`groupId`,`permissionId`),
  KEY `IX_A425F71A` (`groupId`),
  KEY `IX_6C53DA4E` (`permissionId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `OrgGroupPermission`
--

LOCK TABLES `OrgGroupPermission` WRITE;
/*!40000 ALTER TABLE `OrgGroupPermission` DISABLE KEYS */;
/*!40000 ALTER TABLE `OrgGroupPermission` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `OrgGroupRole`
--

DROP TABLE IF EXISTS `OrgGroupRole`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `OrgGroupRole` (
  `organizationId` bigint(20) NOT NULL,
  `groupId` bigint(20) NOT NULL,
  `roleId` bigint(20) NOT NULL,
  PRIMARY KEY (`organizationId`,`groupId`,`roleId`),
  KEY `IX_4A527DD3` (`groupId`),
  KEY `IX_AB044D1C` (`roleId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `OrgGroupRole`
--

LOCK TABLES `OrgGroupRole` WRITE;
/*!40000 ALTER TABLE `OrgGroupRole` DISABLE KEYS */;
/*!40000 ALTER TABLE `OrgGroupRole` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `OrgLabor`
--

DROP TABLE IF EXISTS `OrgLabor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `OrgLabor` (
  `orgLaborId` bigint(20) NOT NULL,
  `organizationId` bigint(20) DEFAULT NULL,
  `typeId` int(11) DEFAULT NULL,
  `sunOpen` int(11) DEFAULT NULL,
  `sunClose` int(11) DEFAULT NULL,
  `monOpen` int(11) DEFAULT NULL,
  `monClose` int(11) DEFAULT NULL,
  `tueOpen` int(11) DEFAULT NULL,
  `tueClose` int(11) DEFAULT NULL,
  `wedOpen` int(11) DEFAULT NULL,
  `wedClose` int(11) DEFAULT NULL,
  `thuOpen` int(11) DEFAULT NULL,
  `thuClose` int(11) DEFAULT NULL,
  `friOpen` int(11) DEFAULT NULL,
  `friClose` int(11) DEFAULT NULL,
  `satOpen` int(11) DEFAULT NULL,
  `satClose` int(11) DEFAULT NULL,
  PRIMARY KEY (`orgLaborId`),
  KEY `IX_6AF0D434` (`organizationId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `OrgLabor`
--

LOCK TABLES `OrgLabor` WRITE;
/*!40000 ALTER TABLE `OrgLabor` DISABLE KEYS */;
/*!40000 ALTER TABLE `OrgLabor` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Organization_`
--

DROP TABLE IF EXISTS `Organization_`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Organization_` (
  `organizationId` bigint(20) NOT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `parentOrganizationId` bigint(20) DEFAULT NULL,
  `treePath` longtext,
  `name` varchar(100) DEFAULT NULL,
  `type_` varchar(75) DEFAULT NULL,
  `recursable` tinyint(4) DEFAULT NULL,
  `regionId` bigint(20) DEFAULT NULL,
  `countryId` bigint(20) DEFAULT NULL,
  `statusId` int(11) DEFAULT NULL,
  `comments` longtext,
  PRIMARY KEY (`organizationId`),
  UNIQUE KEY `IX_E301BDF5` (`companyId`,`name`),
  KEY `IX_834BCEB6` (`companyId`),
  KEY `IX_418E4522` (`companyId`,`parentOrganizationId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Organization_`
--

LOCK TABLES `Organization_` WRITE;
/*!40000 ALTER TABLE `Organization_` DISABLE KEYS */;
/*!40000 ALTER TABLE `Organization_` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PasswordPolicy`
--

DROP TABLE IF EXISTS `PasswordPolicy`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `PasswordPolicy` (
  `passwordPolicyId` bigint(20) NOT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `userId` bigint(20) DEFAULT NULL,
  `userName` varchar(75) DEFAULT NULL,
  `createDate` datetime DEFAULT NULL,
  `modifiedDate` datetime DEFAULT NULL,
  `defaultPolicy` tinyint(4) DEFAULT NULL,
  `name` varchar(75) DEFAULT NULL,
  `description` longtext,
  `changeable` tinyint(4) DEFAULT NULL,
  `changeRequired` tinyint(4) DEFAULT NULL,
  `minAge` bigint(20) DEFAULT NULL,
  `checkSyntax` tinyint(4) DEFAULT NULL,
  `allowDictionaryWords` tinyint(4) DEFAULT NULL,
  `minAlphanumeric` int(11) DEFAULT NULL,
  `minLength` int(11) DEFAULT NULL,
  `minLowerCase` int(11) DEFAULT NULL,
  `minNumbers` int(11) DEFAULT NULL,
  `minSymbols` int(11) DEFAULT NULL,
  `minUpperCase` int(11) DEFAULT NULL,
  `history` tinyint(4) DEFAULT NULL,
  `historyCount` int(11) DEFAULT NULL,
  `expireable` tinyint(4) DEFAULT NULL,
  `maxAge` bigint(20) DEFAULT NULL,
  `warningTime` bigint(20) DEFAULT NULL,
  `graceLimit` int(11) DEFAULT NULL,
  `lockout` tinyint(4) DEFAULT NULL,
  `maxFailure` int(11) DEFAULT NULL,
  `lockoutDuration` bigint(20) DEFAULT NULL,
  `requireUnlock` tinyint(4) DEFAULT NULL,
  `resetFailureCount` bigint(20) DEFAULT NULL,
  `resetTicketMaxAge` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`passwordPolicyId`),
  UNIQUE KEY `IX_3FBFA9F4` (`companyId`,`name`),
  KEY `IX_2C1142E` (`companyId`,`defaultPolicy`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PasswordPolicy`
--

LOCK TABLES `PasswordPolicy` WRITE;
/*!40000 ALTER TABLE `PasswordPolicy` DISABLE KEYS */;
INSERT INTO `PasswordPolicy` VALUES (10195,10154,10158,'','2014-03-18 17:33:37','2014-03-18 17:33:37',1,'Default Password Policy','Default Password Policy',1,1,0,0,1,0,6,0,1,0,1,0,6,0,8640000,86400,0,0,3,0,1,600,86400),(10600,10154,10196,'Test Test','2014-03-18 17:45:35','2014-03-18 17:45:41',0,'Password Policy Name','Password Policy Description',1,0,0,0,0,0,0,0,0,0,0,1,2,0,1209600,43200,0,0,0,0,1,300,0);
/*!40000 ALTER TABLE `PasswordPolicy` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PasswordPolicyRel`
--

DROP TABLE IF EXISTS `PasswordPolicyRel`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `PasswordPolicyRel` (
  `passwordPolicyRelId` bigint(20) NOT NULL,
  `passwordPolicyId` bigint(20) DEFAULT NULL,
  `classNameId` bigint(20) DEFAULT NULL,
  `classPK` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`passwordPolicyRelId`),
  KEY `IX_C3A17327` (`classNameId`,`classPK`),
  KEY `IX_CD25266E` (`passwordPolicyId`),
  KEY `IX_ED7CF243` (`passwordPolicyId`,`classNameId`,`classPK`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PasswordPolicyRel`
--

LOCK TABLES `PasswordPolicyRel` WRITE;
/*!40000 ALTER TABLE `PasswordPolicyRel` DISABLE KEYS */;
INSERT INTO `PasswordPolicyRel` VALUES (10622,10600,10005,10601);
/*!40000 ALTER TABLE `PasswordPolicyRel` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PasswordTracker`
--

DROP TABLE IF EXISTS `PasswordTracker`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `PasswordTracker` (
  `passwordTrackerId` bigint(20) NOT NULL,
  `userId` bigint(20) DEFAULT NULL,
  `createDate` datetime DEFAULT NULL,
  `password_` varchar(75) DEFAULT NULL,
  PRIMARY KEY (`passwordTrackerId`),
  KEY `IX_326F75BD` (`userId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PasswordTracker`
--

LOCK TABLES `PasswordTracker` WRITE;
/*!40000 ALTER TABLE `PasswordTracker` DISABLE KEYS */;
INSERT INTO `PasswordTracker` VALUES (10623,10601,'2014-03-18 17:47:03','qUqP5cyxm6YcTAhz05Hph5gvu9M=');
/*!40000 ALTER TABLE `PasswordTracker` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Permission_`
--

DROP TABLE IF EXISTS `Permission_`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Permission_` (
  `permissionId` bigint(20) NOT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `actionId` varchar(75) DEFAULT NULL,
  `resourceId` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`permissionId`),
  UNIQUE KEY `IX_4D19C2B8` (`actionId`,`resourceId`),
  KEY `IX_F090C113` (`resourceId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Permission_`
--

LOCK TABLES `Permission_` WRITE;
/*!40000 ALTER TABLE `Permission_` DISABLE KEYS */;
/*!40000 ALTER TABLE `Permission_` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Phone`
--

DROP TABLE IF EXISTS `Phone`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Phone` (
  `phoneId` bigint(20) NOT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `userId` bigint(20) DEFAULT NULL,
  `userName` varchar(75) DEFAULT NULL,
  `createDate` datetime DEFAULT NULL,
  `modifiedDate` datetime DEFAULT NULL,
  `classNameId` bigint(20) DEFAULT NULL,
  `classPK` bigint(20) DEFAULT NULL,
  `number_` varchar(75) DEFAULT NULL,
  `extension` varchar(75) DEFAULT NULL,
  `typeId` int(11) DEFAULT NULL,
  `primary_` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`phoneId`),
  KEY `IX_9F704A14` (`companyId`),
  KEY `IX_A2E4AFBA` (`companyId`,`classNameId`),
  KEY `IX_9A53569` (`companyId`,`classNameId`,`classPK`),
  KEY `IX_812CE07A` (`companyId`,`classNameId`,`classPK`,`primary_`),
  KEY `IX_F202B9CE` (`userId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Phone`
--

LOCK TABLES `Phone` WRITE;
/*!40000 ALTER TABLE `Phone` DISABLE KEYS */;
INSERT INTO `Phone` VALUES (10878,10154,10196,'Test Test','2014-03-18 18:02:40','2014-03-18 18:02:47',10022,10197,'123-123-1234','123',11006,1);
/*!40000 ALTER TABLE `Phone` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PluginSetting`
--

DROP TABLE IF EXISTS `PluginSetting`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `PluginSetting` (
  `pluginSettingId` bigint(20) NOT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `pluginId` varchar(75) DEFAULT NULL,
  `pluginType` varchar(75) DEFAULT NULL,
  `roles` longtext,
  `active_` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`pluginSettingId`),
  UNIQUE KEY `IX_7171B2E8` (`companyId`,`pluginId`,`pluginType`),
  KEY `IX_B9746445` (`companyId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PluginSetting`
--

LOCK TABLES `PluginSetting` WRITE;
/*!40000 ALTER TABLE `PluginSetting` DISABLE KEYS */;
INSERT INTO `PluginSetting` VALUES (10806,10154,'classic','theme','User',1);
/*!40000 ALTER TABLE `PluginSetting` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PollsChoice`
--

DROP TABLE IF EXISTS `PollsChoice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `PollsChoice` (
  `uuid_` varchar(75) DEFAULT NULL,
  `choiceId` bigint(20) NOT NULL,
  `questionId` bigint(20) DEFAULT NULL,
  `name` varchar(75) DEFAULT NULL,
  `description` longtext,
  PRIMARY KEY (`choiceId`),
  UNIQUE KEY `IX_D76DD2CF` (`questionId`,`name`),
  KEY `IX_EC370F10` (`questionId`),
  KEY `IX_6660B399` (`uuid_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PollsChoice`
--

LOCK TABLES `PollsChoice` WRITE;
/*!40000 ALTER TABLE `PollsChoice` DISABLE KEYS */;
INSERT INTO `PollsChoice` VALUES ('e3275d3e-dd5e-4c4e-857b-d72ea9985407',10496,10495,'a','<?xml version=\'1.0\' encoding=\'UTF-8\'?><root available-locales=\"en_US\" default-locale=\"en_US\"><Description language-id=\"en_US\">Choice A</Description></root>'),('289dc5f4-f586-4aca-8209-b20779bfd2fa',10497,10495,'b','<?xml version=\'1.0\' encoding=\'UTF-8\'?><root available-locales=\"en_US\" default-locale=\"en_US\"><Description language-id=\"en_US\">Choice B</Description></root>');
/*!40000 ALTER TABLE `PollsChoice` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PollsQuestion`
--

DROP TABLE IF EXISTS `PollsQuestion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `PollsQuestion` (
  `uuid_` varchar(75) DEFAULT NULL,
  `questionId` bigint(20) NOT NULL,
  `groupId` bigint(20) DEFAULT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `userId` bigint(20) DEFAULT NULL,
  `userName` varchar(75) DEFAULT NULL,
  `createDate` datetime DEFAULT NULL,
  `modifiedDate` datetime DEFAULT NULL,
  `title` longtext,
  `description` longtext,
  `expirationDate` datetime DEFAULT NULL,
  `lastVoteDate` datetime DEFAULT NULL,
  PRIMARY KEY (`questionId`),
  UNIQUE KEY `IX_F3C9F36` (`uuid_`,`groupId`),
  KEY `IX_9FF342EA` (`groupId`),
  KEY `IX_51F087F4` (`uuid_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PollsQuestion`
--

LOCK TABLES `PollsQuestion` WRITE;
/*!40000 ALTER TABLE `PollsQuestion` DISABLE KEYS */;
INSERT INTO `PollsQuestion` VALUES ('6752773d-0654-4241-8c7c-4475abf6904c',10495,10180,10154,10196,'Test Test','2014-03-18 17:38:37','2014-03-18 17:38:37','<?xml version=\'1.0\' encoding=\'UTF-8\'?><root available-locales=\"en_US\" default-locale=\"en_US\"><Title language-id=\"en_US\">Polls Title</Title></root>','<?xml version=\'1.0\' encoding=\'UTF-8\'?><root available-locales=\"en_US\" default-locale=\"en_US\"><Description language-id=\"en_US\">Polls Question</Description></root>',NULL,'2014-03-18 17:39:04');
/*!40000 ALTER TABLE `PollsQuestion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PollsVote`
--

DROP TABLE IF EXISTS `PollsVote`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `PollsVote` (
  `voteId` bigint(20) NOT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `userId` bigint(20) DEFAULT NULL,
  `userName` varchar(75) DEFAULT NULL,
  `createDate` datetime DEFAULT NULL,
  `modifiedDate` datetime DEFAULT NULL,
  `questionId` bigint(20) DEFAULT NULL,
  `choiceId` bigint(20) DEFAULT NULL,
  `voteDate` datetime DEFAULT NULL,
  PRIMARY KEY (`voteId`),
  UNIQUE KEY `IX_1BBFD4D3` (`questionId`,`userId`),
  KEY `IX_D5DF7B54` (`choiceId`),
  KEY `IX_12112599` (`questionId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PollsVote`
--

LOCK TABLES `PollsVote` WRITE;
/*!40000 ALTER TABLE `PollsVote` DISABLE KEYS */;
INSERT INTO `PollsVote` VALUES (10508,10154,10196,'Test Test','2014-03-18 17:39:04','2014-03-18 17:39:04',10495,10496,'2014-03-18 17:39:04');
/*!40000 ALTER TABLE `PollsVote` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PortalPreferences`
--

DROP TABLE IF EXISTS `PortalPreferences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `PortalPreferences` (
  `portalPreferencesId` bigint(20) NOT NULL,
  `ownerId` bigint(20) DEFAULT NULL,
  `ownerType` int(11) DEFAULT NULL,
  `preferences` longtext,
  PRIMARY KEY (`portalPreferencesId`),
  KEY `IX_D1F795F1` (`ownerId`,`ownerType`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PortalPreferences`
--

LOCK TABLES `PortalPreferences` WRITE;
/*!40000 ALTER TABLE `PortalPreferences` DISABLE KEYS */;
INSERT INTO `PortalPreferences` VALUES (10153,0,1,'<portlet-preferences />'),(10160,10154,1,'<portlet-preferences />'),(10405,10158,4,'<portlet-preferences />'),(10419,10196,4,'<portlet-preferences><preference><name>129#password-policies-order-by-col</name><value>name</value></preference><preference><name>125#users-order-by-col</name><value>last-name</value></preference><preference><name>125#groups-order-by-type</name><value>asc</value></preference><preference><name>129#password-policies-order-by-type</name><value>asc</value></preference><preference><name>125#groups-order-by-col</name><value>name</value></preference><preference><name>com.liferay.portal.util.SessionClicks#assetTagPropertiesPanel</name><value>open</value></preference><preference><name>125#users-order-by-type</name><value>asc</value></preference><preference><name>com.liferay.portal.kernel.staging.Staging#layoutBranchId-10715-10706</name><value>10716</value></preference></portlet-preferences>'),(10620,10601,4,'<portlet-preferences />'),(10669,10650,4,'<portlet-preferences />');
/*!40000 ALTER TABLE `PortalPreferences` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Portlet`
--

DROP TABLE IF EXISTS `Portlet`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Portlet` (
  `id_` bigint(20) NOT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `portletId` varchar(200) DEFAULT NULL,
  `roles` longtext,
  `active_` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`id_`),
  UNIQUE KEY `IX_12B5E51D` (`companyId`,`portletId`),
  KEY `IX_80CC9508` (`companyId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Portlet`
--

LOCK TABLES `Portlet` WRITE;
/*!40000 ALTER TABLE `Portlet` DISABLE KEYS */;
INSERT INTO `Portlet` VALUES (10202,10154,'98','',1),(10203,10154,'66','',1),(10204,10154,'180','',1),(10205,10154,'27','',1),(10206,10154,'152','',1),(10207,10154,'134','',1),(10208,10154,'130','',1),(10209,10154,'122','',1),(10210,10154,'36','',1),(10211,10154,'26','',1),(10212,10154,'104','',1),(10213,10154,'175','',1),(10214,10154,'153','',1),(10215,10154,'64','',1),(10216,10154,'129','',1),(10217,10154,'179','',1),(10218,10154,'173','',1),(10219,10154,'100','',1),(10220,10154,'19','',1),(10221,10154,'157','',1),(10222,10154,'128','',1),(10223,10154,'181','',1),(10224,10154,'154','',1),(10225,10154,'148','',1),(10226,10154,'11','',1),(10227,10154,'29','',1),(10228,10154,'158','',1),(10229,10154,'178','',1),(10230,10154,'8','',1),(10231,10154,'58','',1),(10232,10154,'71','',1),(10233,10154,'97','',1),(10234,10154,'39','',1),(10235,10154,'177','',1),(10236,10154,'85','',1),(10237,10154,'118','',1),(10238,10154,'107','',1),(10239,10154,'30','',1),(10240,10154,'147','',1),(10241,10154,'48','',1),(10242,10154,'125','',1),(10243,10154,'161','',1),(10244,10154,'146','',1),(10245,10154,'62','',1),(10246,10154,'162','',1),(10247,10154,'176','',1),(10248,10154,'108','',1),(10249,10154,'84','',1),(10250,10154,'101','',1),(10251,10154,'121','',1),(10252,10154,'143','',1),(10253,10154,'77','',1),(10254,10154,'167','',1),(10255,10154,'115','',1),(10256,10154,'56','',1),(10257,10154,'16','',1),(10258,10154,'111','',1),(10259,10154,'3','',1),(10260,10154,'23','',1),(10261,10154,'20','',1),(10262,10154,'83','',1),(10263,10154,'164','',1),(10264,10154,'99','',1),(10265,10154,'70','',1),(10266,10154,'141','',1),(10267,10154,'9','',1),(10268,10154,'28','',1),(10269,10154,'137','',1),(10270,10154,'47','',1),(10271,10154,'15','',1),(10272,10154,'116','',1),(10273,10154,'82','',1),(10274,10154,'151','',1),(10275,10154,'54','',1),(10276,10154,'34','',1),(10277,10154,'169','',1),(10278,10154,'132','',1),(10279,10154,'61','',1),(10280,10154,'73','',1),(10281,10154,'31','',1),(10282,10154,'136','',1),(10283,10154,'50','',1),(10284,10154,'127','',1),(10285,10154,'25','',1),(10286,10154,'166','',1),(10287,10154,'33','',1),(10288,10154,'150','',1),(10289,10154,'114','',1),(10290,10154,'149','',1),(10291,10154,'67','',1),(10292,10154,'110','',1),(10293,10154,'59','',1),(10294,10154,'135','',1),(10295,10154,'131','',1),(10296,10154,'102','',1),(10901,10154,'1_WAR_quartzupgradeportlet','',1);
/*!40000 ALTER TABLE `Portlet` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PortletItem`
--

DROP TABLE IF EXISTS `PortletItem`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `PortletItem` (
  `portletItemId` bigint(20) NOT NULL,
  `groupId` bigint(20) DEFAULT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `userId` bigint(20) DEFAULT NULL,
  `userName` varchar(75) DEFAULT NULL,
  `createDate` datetime DEFAULT NULL,
  `modifiedDate` datetime DEFAULT NULL,
  `name` varchar(75) DEFAULT NULL,
  `portletId` varchar(75) DEFAULT NULL,
  `classNameId` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`portletItemId`),
  KEY `IX_96BDD537` (`groupId`,`classNameId`),
  KEY `IX_D699243F` (`groupId`,`name`,`portletId`,`classNameId`),
  KEY `IX_2C61314E` (`groupId`,`portletId`),
  KEY `IX_E922D6C0` (`groupId`,`portletId`,`classNameId`),
  KEY `IX_8E71167F` (`groupId`,`portletId`,`classNameId`,`name`),
  KEY `IX_33B8CE8D` (`groupId`,`portletId`,`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PortletItem`
--

LOCK TABLES `PortletItem` WRITE;
/*!40000 ALTER TABLE `PortletItem` DISABLE KEYS */;
/*!40000 ALTER TABLE `PortletItem` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PortletPreferences`
--

DROP TABLE IF EXISTS `PortletPreferences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `PortletPreferences` (
  `portletPreferencesId` bigint(20) NOT NULL,
  `ownerId` bigint(20) DEFAULT NULL,
  `ownerType` int(11) DEFAULT NULL,
  `plid` bigint(20) DEFAULT NULL,
  `portletId` varchar(200) DEFAULT NULL,
  `preferences` longtext,
  PRIMARY KEY (`portletPreferencesId`),
  UNIQUE KEY `IX_C7057FF7` (`ownerId`,`ownerType`,`plid`,`portletId`),
  KEY `IX_E4F13E6E` (`ownerId`,`ownerType`,`plid`),
  KEY `IX_D5EDA3A1` (`ownerType`,`plid`,`portletId`),
  KEY `IX_F15C1C4F` (`plid`),
  KEY `IX_D340DB76` (`plid`,`portletId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PortletPreferences`
--

LOCK TABLES `PortletPreferences` WRITE;
/*!40000 ALTER TABLE `PortletPreferences` DISABLE KEYS */;
INSERT INTO `PortletPreferences` VALUES (10351,0,3,10346,'3','<portlet-preferences><preference><name>portletSetupShowBorders</name><value>false</value></preference></portlet-preferences>'),(10357,0,3,10352,'101_INSTANCE_MKtINt5wJgBs','<portlet-preferences><preference><name>portletSetupUseCustomTitle</name><value>true</value></preference><preference><name>anyAssetType</name><value>false</value></preference><preference><name>classNameIds</name><value>10009</value></preference><preference><name>portletSetupTitle_en_US</name><value>Upcoming Events</value></preference></portlet-preferences>'),(10377,0,3,10372,'3','<portlet-preferences><preference><name>portletSetupShowBorders</name><value>false</value></preference></portlet-preferences>'),(10378,0,3,10372,'82','<portlet-preferences><preference><name>displayStyle</name><value>3</value></preference></portlet-preferences>'),(10379,0,3,10372,'101_INSTANCE_7qLpq9y7sD92','<portlet-preferences><preference><name>portletSetupUseCustomTitle</name><value>true</value></preference><preference><name>portletSetupTitle_en_US</name><value>Recent Content</value></preference></portlet-preferences>'),(10385,0,3,10380,'20','<portlet-preferences><preference><name>portletSetupShowBorders</name><value>false</value></preference></portlet-preferences>'),(10391,0,3,10386,'101_INSTANCE_zgzOtyEtDk5S','<portlet-preferences><preference><name>portletSetupUseCustomTitle</name><value>true</value></preference><preference><name>anyAssetType</name><value>false</value></preference><preference><name>classNameIds</name><value>10009</value></preference><preference><name>portletSetupTitle_en_US</name><value>Upcoming Events</value></preference></portlet-preferences>'),(10397,0,3,10392,'39_INSTANCE_B0kQ9IYKwPHm','<portlet-preferences><preference><name>portletSetupUseCustomTitle</name><value>true</value></preference><preference><name>expandedEntriesPerFeed</name><value>3</value></preference><preference><name>urls</name><value>http://partners.userland.com/nytRss/technology.xml</value></preference><preference><name>items-per-channel</name><value>2</value></preference><preference><name>portletSetupTitle_en_US</name><value>Technology news</value></preference></portlet-preferences>'),(10398,0,3,10392,'39_INSTANCE_kWXDv7thyhvD','<portlet-preferences><preference><name>portletSetupUseCustomTitle</name><value>true</value></preference><preference><name>expandedEntriesPerFeed</name><value>0</value></preference><preference><name>urls</name><value>http://www.liferay.com/en/about-us/news/-/blogs/rss</value></preference><preference><name>titles</name><value>Liferay Press Releases</value></preference><preference><name>items-per-channel</name><value>2</value></preference><preference><name>portletSetupTitle_en_US</name><value>Liferay news</value></preference></portlet-preferences>'),(10406,0,3,10183,'103','<portlet-preferences />'),(10407,0,3,10183,'47','<portlet-preferences />'),(10408,0,3,10183,'58','<portlet-preferences />'),(10420,0,3,10183,'145','<portlet-preferences />'),(10421,0,3,10183,'terms-of-use','<portlet-preferences />'),(10422,0,3,10183,'password-reminder','<portlet-preferences />'),(10423,0,3,10183,'88','<portlet-preferences />'),(10429,0,3,10424,'103','<portlet-preferences />'),(10430,0,3,10424,'145','<portlet-preferences />'),(10431,0,3,10424,'87','<portlet-preferences />'),(10432,0,3,10424,'98','<portlet-preferences />'),(10447,0,3,10175,'160','<portlet-preferences />'),(10448,0,3,10175,'145','<portlet-preferences />'),(10449,0,3,10175,'134','<portlet-preferences />'),(10454,0,3,10175,'128','<portlet-preferences />'),(10457,0,3,10175,'125','<portlet-preferences />'),(10471,0,3,10175,'156','<portlet-preferences />'),(10477,0,3,10472,'103','<portlet-preferences />'),(10478,0,3,10472,'145','<portlet-preferences />'),(10479,0,3,10472,'87','<portlet-preferences />'),(10480,0,3,10472,'36','<portlet-preferences />'),(10490,10467,2,0,'154','<portlet-preferences />'),(10491,0,3,10175,'154','<portlet-preferences />'),(10493,10180,2,0,'25','<portlet-preferences />'),(10494,0,3,10175,'25','<portlet-preferences />'),(10503,0,3,10498,'103','<portlet-preferences />'),(10504,0,3,10498,'145','<portlet-preferences />'),(10505,0,3,10498,'87','<portlet-preferences />'),(10506,0,3,10498,'59_INSTANCE_uhIWLYUlw5T8','<portlet-preferences><preference><name>questionId</name><value>10495</value></preference></portlet-preferences>'),(10507,0,3,10498,'86','<portlet-preferences />'),(10518,10509,2,0,'15','<portlet-preferences />'),(10519,0,3,10175,'15','<portlet-preferences />'),(10531,10180,2,0,'15','<portlet-preferences />'),(10532,0,3,10526,'103','<portlet-preferences />'),(10533,0,3,10526,'145','<portlet-preferences />'),(10534,0,3,10526,'87','<portlet-preferences />'),(10535,10154,1,0,'84','<portlet-preferences />'),(10536,0,3,10526,'84','<portlet-preferences />'),(10537,0,3,10175,'179','<portlet-preferences />'),(10544,0,3,10175,'161','<portlet-preferences />'),(10545,0,3,10175,'146','<portlet-preferences />'),(10566,0,3,10561,'103','<portlet-preferences />'),(10567,0,3,10561,'145','<portlet-preferences />'),(10568,0,3,10561,'87','<portlet-preferences />'),(10569,0,3,10561,'169_INSTANCE_Xc3UrpdLcuH0','<portlet-preferences><preference><name>recordSetId</name><value>10579</value></preference></portlet-preferences>'),(10572,0,3,10175,'167','<portlet-preferences />'),(10573,0,3,10175,'166','<portlet-preferences />'),(10576,0,3,10561,'167','<portlet-preferences />'),(10577,0,3,10561,'166','<portlet-preferences />'),(10587,10557,2,0,'15','<portlet-preferences />'),(10589,0,3,10175,'149','<portlet-preferences />'),(10599,0,3,10175,'129','<portlet-preferences />'),(10621,0,3,10183,'new-password','<portlet-preferences />'),(10624,0,3,10175,'165','<portlet-preferences />'),(10632,0,3,10627,'103','<portlet-preferences />'),(10633,0,3,10627,'145','<portlet-preferences />'),(10634,0,3,10627,'87','<portlet-preferences />'),(10635,10180,2,0,'34','<portlet-preferences />'),(10636,0,3,10627,'34','<portlet-preferences />'),(10670,0,3,10659,'103','<portlet-preferences />'),(10671,0,3,10659,'11','<portlet-preferences />'),(10672,0,3,10659,'23','<portlet-preferences />'),(10673,0,3,10659,'29','<portlet-preferences />'),(10674,10652,2,0,'8','<portlet-preferences />'),(10675,0,3,10659,'8','<portlet-preferences />'),(10676,0,3,10659,'82','<portlet-preferences />'),(10677,0,3,10659,'145','<portlet-preferences />'),(10692,10679,2,0,'19','<portlet-preferences xmlns=\"http://java.sun.com/xml/ns/portlet/portlet-app_2_0.xsd\">\n			<preference>\n				<name>priorities</name>\n				<value>Urgent,/message_boards/priority_urgent.png,3.0</value>\n				<value>Sticky,/message_boards/priority_sticky.png,2.0</value>\n				<value>Announcement,/message_boards/priority_announcement.png,1.0</value>\n			</preference>\n			<preference>\n				<name>ranks</name>\n				<value>Youngling=0</value>\n				<value>Padawan=25</value>\n				<value>Jedi Knight=100</value>\n				<value>Jedi Master=250</value>\n				<value>Jedi Council Member=500</value>\n				<value>Yoda=1000</value>\n				<value>Moderator=organization:Message Boards Administrator</value>\n				<value>Moderator=organization-role:Message Boards Administrator</value>\n				<value>Moderator=regular-role:Message Boards Administrator</value>\n				<value>Moderator=site-role:Message Boards Administrator</value>\n				<value>Moderator=user-group:Message Boards Administrator</value>\n			</preference>\n		</portlet-preferences>'),(10693,10679,2,0,'8','<portlet-preferences />'),(10694,0,3,10683,'161','<portlet-preferences />'),(10695,0,3,10683,'162','<portlet-preferences />'),(10696,0,3,10683,'56','<portlet-preferences />'),(10697,0,3,10683,'20','<portlet-preferences />'),(10698,0,3,10683,'28','<portlet-preferences />'),(10699,10679,2,0,'15','<portlet-preferences />'),(10700,10679,2,0,'25','<portlet-preferences />'),(10701,0,3,10683,'166','<portlet-preferences />'),(10702,10679,2,0,'33','<portlet-preferences />'),(10707,10688,2,0,'19','<?xml version=\"1.0\"?>\n\n<portlet-preferences xmlns=\"http://java.sun.com/xml/ns/portlet/portlet-app_2_0.xsd\" owner-id=\"10679\" owner-type=\"2\" default-user=\"false\" plid=\"0\" portlet-id=\"19\">\n			\n	<preference>\n				\n		<name>priorities</name>\n				\n		<value>Urgent,/message_boards/priority_urgent.png,3.0</value>\n				\n		<value>Sticky,/message_boards/priority_sticky.png,2.0</value>\n				\n		<value>Announcement,/message_boards/priority_announcement.png,1.0</value>\n			\n	</preference>\n			\n	<preference>\n				\n		<name>ranks</name>\n				\n		<value>Youngling=0</value>\n				\n		<value>Padawan=25</value>\n				\n		<value>Jedi Knight=100</value>\n				\n		<value>Jedi Master=250</value>\n				\n		<value>Jedi Council Member=500</value>\n				\n		<value>Yoda=1000</value>\n				\n		<value>Moderator=organization:Message Boards Administrator</value>\n				\n		<value>Moderator=organization-role:Message Boards Administrator</value>\n				\n		<value>Moderator=regular-role:Message Boards Administrator</value>\n				\n		<value>Moderator=site-role:Message Boards Administrator</value>\n				\n		<value>Moderator=user-group:Message Boards Administrator</value>\n			\n	</preference>\n		\n</portlet-preferences>'),(10708,10688,2,0,'8','<?xml version=\"1.0\"?>\n\n<portlet-preferences owner-id=\"10679\" owner-type=\"2\" default-user=\"false\" plid=\"0\" portlet-id=\"8\"/>'),(10709,0,3,10706,'20','<portlet-preferences></portlet-preferences>'),(10710,10688,2,0,'15','<?xml version=\"1.0\"?>\n\n<portlet-preferences owner-id=\"10679\" owner-type=\"2\" default-user=\"false\" plid=\"0\" portlet-id=\"15\"/>'),(10711,0,3,10706,'15','<portlet-preferences></portlet-preferences>'),(10712,10688,2,0,'25','<?xml version=\"1.0\"?>\n\n<portlet-preferences owner-id=\"10679\" owner-type=\"2\" default-user=\"false\" plid=\"0\" portlet-id=\"25\"/>'),(10713,0,3,10706,'166','<portlet-preferences></portlet-preferences>'),(10714,10688,2,0,'33','<?xml version=\"1.0\"?>\n\n<portlet-preferences owner-id=\"10679\" owner-type=\"2\" default-user=\"false\" plid=\"0\" portlet-id=\"33\"/>'),(10718,0,3,10717,'20','<portlet-preferences></portlet-preferences>'),(10719,0,3,10717,'15','<portlet-preferences></portlet-preferences>'),(10720,0,3,10717,'166','<portlet-preferences></portlet-preferences>'),(10722,0,3,10717,'103','<portlet-preferences />'),(10723,0,3,10717,'145','<portlet-preferences />'),(10724,0,3,10717,'170','<portlet-preferences />'),(10725,0,3,10717,'87','<portlet-preferences />'),(10727,0,3,10726,'103','<portlet-preferences />'),(10728,0,3,10726,'145','<portlet-preferences />'),(10729,0,3,10726,'15','<portlet-preferences></portlet-preferences>'),(10730,0,3,10726,'166','<portlet-preferences></portlet-preferences>'),(10731,0,3,10726,'170','<portlet-preferences />'),(10732,0,3,10726,'20','<portlet-preferences></portlet-preferences>'),(10733,0,3,10726,'87','<portlet-preferences />'),(10734,0,3,10726,'19','<portlet-preferences xmlns=\"http://java.sun.com/xml/ns/portlet/portlet-app_2_0.xsd\">\n			<preference>\n				<name>priorities</name>\n				<value>Urgent,/message_boards/priority_urgent.png,3.0</value>\n				<value>Sticky,/message_boards/priority_sticky.png,2.0</value>\n				<value>Announcement,/message_boards/priority_announcement.png,1.0</value>\n			</preference>\n			<preference>\n				<name>ranks</name>\n				<value>Youngling=0</value>\n				<value>Padawan=25</value>\n				<value>Jedi Knight=100</value>\n				<value>Jedi Master=250</value>\n				<value>Jedi Council Member=500</value>\n				<value>Yoda=1000</value>\n				<value>Moderator=organization:Message Boards Administrator</value>\n				<value>Moderator=organization-role:Message Boards Administrator</value>\n				<value>Moderator=regular-role:Message Boards Administrator</value>\n				<value>Moderator=site-role:Message Boards Administrator</value>\n				<value>Moderator=user-group:Message Boards Administrator</value>\n			</preference>\n		</portlet-preferences>'),(10742,0,3,10737,'103','<portlet-preferences />'),(10743,0,3,10737,'145','<portlet-preferences />'),(10744,0,3,10737,'87','<portlet-preferences />'),(10745,0,3,10737,'28','<portlet-preferences />'),(10770,0,3,10765,'103','<portlet-preferences />'),(10771,0,3,10765,'145','<portlet-preferences />'),(10772,0,3,10765,'87','<portlet-preferences />'),(10773,0,3,10765,'101_INSTANCE_U6JjXcjOEdCZ','<portlet-preferences />'),(10774,10761,2,0,'19','<portlet-preferences xmlns=\"http://java.sun.com/xml/ns/portlet/portlet-app_2_0.xsd\">\n			<preference>\n				<name>priorities</name>\n				<value>Urgent,/message_boards/priority_urgent.png,3.0</value>\n				<value>Sticky,/message_boards/priority_sticky.png,2.0</value>\n				<value>Announcement,/message_boards/priority_announcement.png,1.0</value>\n			</preference>\n			<preference>\n				<name>ranks</name>\n				<value>Youngling=0</value>\n				<value>Padawan=25</value>\n				<value>Jedi Knight=100</value>\n				<value>Jedi Master=250</value>\n				<value>Jedi Council Member=500</value>\n				<value>Yoda=1000</value>\n				<value>Moderator=organization:Message Boards Administrator</value>\n				<value>Moderator=organization-role:Message Boards Administrator</value>\n				<value>Moderator=regular-role:Message Boards Administrator</value>\n				<value>Moderator=site-role:Message Boards Administrator</value>\n				<value>Moderator=user-group:Message Boards Administrator</value>\n			</preference>\n		</portlet-preferences>'),(10775,0,3,10765,'19','<portlet-preferences xmlns=\"http://java.sun.com/xml/ns/portlet/portlet-app_2_0.xsd\">\n			<preference>\n				<name>priorities</name>\n				<value>Urgent,/message_boards/priority_urgent.png,3.0</value>\n				<value>Sticky,/message_boards/priority_sticky.png,2.0</value>\n				<value>Announcement,/message_boards/priority_announcement.png,1.0</value>\n			</preference>\n			<preference>\n				<name>ranks</name>\n				<value>Youngling=0</value>\n				<value>Padawan=25</value>\n				<value>Jedi Knight=100</value>\n				<value>Jedi Master=250</value>\n				<value>Jedi Council Member=500</value>\n				<value>Yoda=1000</value>\n				<value>Moderator=organization:Message Boards Administrator</value>\n				<value>Moderator=organization-role:Message Boards Administrator</value>\n				<value>Moderator=regular-role:Message Boards Administrator</value>\n				<value>Moderator=site-role:Message Boards Administrator</value>\n				<value>Moderator=user-group:Message Boards Administrator</value>\n			</preference>\n		</portlet-preferences>'),(10776,10761,2,0,'33','<portlet-preferences />'),(10777,0,3,10765,'33','<portlet-preferences />'),(10787,0,3,10782,'103','<portlet-preferences />'),(10788,0,3,10782,'145','<portlet-preferences />'),(10789,0,3,10782,'87','<portlet-preferences />'),(10790,0,3,10782,'20','<portlet-preferences />'),(10805,0,3,10175,'132','<portlet-preferences />'),(10816,0,3,10175,'178','<portlet-preferences />'),(10826,0,3,10821,'103','<portlet-preferences />'),(10827,0,3,10821,'145','<portlet-preferences />'),(10828,0,3,10821,'87','<portlet-preferences />'),(10829,10180,2,0,'8','<portlet-preferences />'),(10830,0,3,10821,'8','<portlet-preferences />'),(10831,0,3,10175,'8','<portlet-preferences />'),(10837,0,3,10832,'103','<portlet-preferences />'),(10838,0,3,10832,'145','<portlet-preferences />'),(10839,0,3,10832,'87','<portlet-preferences />'),(10840,0,3,10832,'84','<portlet-preferences />'),(10841,0,3,10175,'2','<portlet-preferences />'),(10845,0,3,10175,'139','<portlet-preferences />'),(10866,0,3,10175,'99','<portlet-preferences />'),(10869,0,3,10861,'103','<portlet-preferences />'),(10870,0,3,10861,'145','<portlet-preferences />'),(10871,0,3,10861,'87','<portlet-preferences />'),(10872,10857,2,0,'33','<portlet-preferences />'),(10873,0,3,10861,'33','<portlet-preferences />'),(10911,0,3,10175,'49','<portlet-preferences />'),(10912,0,3,10906,'103','<portlet-preferences />'),(10913,0,3,10906,'145','<portlet-preferences />'),(10919,0,3,10914,'103','<portlet-preferences />'),(10920,0,3,10914,'145','<portlet-preferences />'),(10921,0,3,10914,'101_INSTANCE_H0n9dLx4hP21','<portlet-preferences />'),(10927,10903,2,0,'19','<portlet-preferences xmlns=\"http://java.sun.com/xml/ns/portlet/portlet-app_2_0.xsd\">\n			<preference>\n				<name>priorities</name>\n				<value>Urgent,/message_boards/priority_urgent.png,3.0</value>\n				<value>Sticky,/message_boards/priority_sticky.png,2.0</value>\n				<value>Announcement,/message_boards/priority_announcement.png,1.0</value>\n			</preference>\n			<preference>\n				<name>ranks</name>\n				<value>Youngling=0</value>\n				<value>Padawan=25</value>\n				<value>Jedi Knight=100</value>\n				<value>Jedi Master=250</value>\n				<value>Jedi Council Member=500</value>\n				<value>Yoda=1000</value>\n				<value>Moderator=organization:Message Boards Administrator</value>\n				<value>Moderator=organization-role:Message Boards Administrator</value>\n				<value>Moderator=regular-role:Message Boards Administrator</value>\n				<value>Moderator=site-role:Message Boards Administrator</value>\n				<value>Moderator=user-group:Message Boards Administrator</value>\n			</preference>\n		</portlet-preferences>'),(10928,10903,2,0,'8','<portlet-preferences />'),(10929,0,3,10906,'161','<portlet-preferences />'),(10930,0,3,10906,'162','<portlet-preferences />'),(10931,0,3,10906,'56','<portlet-preferences />'),(10932,0,3,10906,'20','<portlet-preferences />'),(10933,0,3,10906,'28','<portlet-preferences />'),(10934,10903,2,0,'15','<portlet-preferences />'),(10935,10903,2,0,'25','<portlet-preferences />'),(10936,0,3,10906,'166','<portlet-preferences />'),(10937,10903,2,0,'33','<portlet-preferences />'),(10942,0,3,10940,'20','<portlet-preferences></portlet-preferences>'),(10943,0,3,10940,'15','<portlet-preferences></portlet-preferences>'),(10944,0,3,10940,'166','<portlet-preferences></portlet-preferences>'),(10945,0,3,10941,'101_INSTANCE_H0n9dLx4hP21','<portlet-preferences></portlet-preferences>'),(10950,10922,2,0,'8','<portlet-preferences />'),(10951,0,3,10940,'56','<portlet-preferences />'),(10952,0,3,10940,'28','<portlet-preferences />'),(10953,10922,2,0,'15','<portlet-preferences />'),(10956,10946,2,0,'8','<?xml version=\"1.0\"?>\n\n<portlet-preferences owner-id=\"10922\" owner-type=\"2\" default-user=\"false\" plid=\"0\" portlet-id=\"8\"/>'),(10957,0,3,10954,'20','<portlet-preferences></portlet-preferences>'),(10958,10946,2,0,'15','<?xml version=\"1.0\"?>\n\n<portlet-preferences owner-id=\"10922\" owner-type=\"2\" default-user=\"false\" plid=\"0\" portlet-id=\"15\"/>'),(10959,0,3,10954,'15','<portlet-preferences></portlet-preferences>'),(10960,0,3,10955,'101_INSTANCE_H0n9dLx4hP21','<portlet-preferences><preference><name>abstractLength</name><value>200</value></preference><preference><name>classTypeIdsJournalArticleAssetRendererFactory</name><value></value></preference><preference><name>assetTitle</name><value></value></preference><preference><name>enableRss</name><value>false</value></preference><preference><name>showAvailableLocales</name><value>false</value></preference><preference><name>paginationType</name><value>none</value></preference><preference><name>classTypeIds</name><value>NULL_VALUE</value></preference><preference><name>anyClassTypeJournalArticleAssetRendererFactory</name><value>true</value></preference><preference><name>enableFlags</name><value>false</value></preference><preference><name>mergeUrlTags</name><value>true</value></preference><preference><name>queryValues0</name></preference><preference><name>enableRatings</name><value>false</value></preference><preference><name>queryName0</name><value>assetTags</value></preference><preference><name>customUserAttributes</name><value></value></preference><preference><name>orderByColumn2</name><value>title</value></preference><preference><name>rssDelta</name><value>20</value></preference><preference><name>extensions</name><value>NULL_VALUE</value></preference><preference><name>metadataFields</name><value></value></preference><preference><name>showAssetTitle</name><value>true</value></preference><preference><name>rssName</name><value>Asset Publisher</value></preference><preference><name>selectionStyle</name><value>dynamic</value></preference><preference><name>orderByColumn1</name><value>modifiedDate</value></preference><preference><name>defaultScope</name><value>Group_default</value></preference><preference><name>excludeZeroViewCount</name><value>false</value></preference><preference><name>orderByType2</name><value>ASC</value></preference><preference><name>showMetadataDescriptions</name><value>true</value></preference><preference><name>enableRelatedAssets</name><value>true</value></preference><preference><name>socialBookmarksDisplayPosition</name><value>bottom</value></preference><preference><name>mergeLayoutTags</name><value>false</value></preference><preference><name>socialBookmarksDisplayStyle</name><value>horizontal</value></preference><preference><name>enablePrint</name><value>false</value></preference><preference><name>queryAndOperator0</name><value>false</value></preference><preference><name>showOnlyLayoutAssets</name><value>false</value></preference><preference><name>enablePermissions</name><value>false</value></preference><preference><name>assetVocabularyId</name><value></value></preference><preference><name>assetLinkBehavior</name><value>showFullContent</value></preference><preference><name>enableCommentRatings</name><value>false</value></preference><preference><name>enableSocialBookmarks</name><value>true</value></preference><preference><name>delta</name><value>20</value></preference><preference><name>anyClassTypeDLFileEntryAssetRendererFactory</name><value>true</value></preference><preference><name>rssFormat</name><value>atom10</value></preference><preference><name>showContextLink</name><value>true</value></preference><preference><name>rssDisplayStyle</name><value>abstract</value></preference><preference><name>scopeIds</name><value>Group_default</value></preference><preference><name>displayStyle</name><value>abstracts</value></preference><preference><name>enableComments</name><value>false</value></preference><preference><name>classTypeIdsDLFileEntryAssetRendererFactory</name><value>10306,10304,10300,10302</value></preference><preference><name>queryContains0</name><value>true</value></preference><preference><name>anyAssetType</name><value>true</value></preference><preference><name>orderByType1</name><value>DESC</value></preference><preference><name>classNameIds</name><value>10007</value><value>10011</value><value>10108</value><value>10009</value><value>10008</value><value>10010</value><value>10013</value></preference></portlet-preferences>'),(10970,0,3,10954,'103','<portlet-preferences />'),(10971,0,3,10954,'145','<portlet-preferences />'),(10972,0,3,10955,'103','<portlet-preferences />'),(10973,0,3,10955,'145','<portlet-preferences />'),(11001,0,3,10940,'103','<portlet-preferences />'),(11002,0,3,10940,'145','<portlet-preferences />'),(11003,0,3,10941,'103','<portlet-preferences />'),(11004,0,3,10941,'145','<portlet-preferences />'),(11005,0,3,10941,'49','<portlet-preferences />'),(11007,0,3,10955,'86','<portlet-preferences />'),(11010,0,3,10955,'49','<portlet-preferences />');
/*!40000 ALTER TABLE `PortletPreferences` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `QUARTZ_BLOB_TRIGGERS`
--

DROP TABLE IF EXISTS `QUARTZ_BLOB_TRIGGERS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `QUARTZ_BLOB_TRIGGERS` (
  `SCHED_NAME` varchar(120) NOT NULL,
  `TRIGGER_NAME` varchar(200) NOT NULL,
  `TRIGGER_GROUP` varchar(200) NOT NULL,
  `BLOB_DATA` longblob,
  PRIMARY KEY (`SCHED_NAME`,`TRIGGER_NAME`,`TRIGGER_GROUP`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `QUARTZ_BLOB_TRIGGERS`
--

LOCK TABLES `QUARTZ_BLOB_TRIGGERS` WRITE;
/*!40000 ALTER TABLE `QUARTZ_BLOB_TRIGGERS` DISABLE KEYS */;
/*!40000 ALTER TABLE `QUARTZ_BLOB_TRIGGERS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `QUARTZ_CALENDARS`
--

DROP TABLE IF EXISTS `QUARTZ_CALENDARS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `QUARTZ_CALENDARS` (
  `SCHED_NAME` varchar(120) NOT NULL,
  `CALENDAR_NAME` varchar(200) NOT NULL,
  `CALENDAR` longblob NOT NULL,
  PRIMARY KEY (`SCHED_NAME`,`CALENDAR_NAME`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `QUARTZ_CALENDARS`
--

LOCK TABLES `QUARTZ_CALENDARS` WRITE;
/*!40000 ALTER TABLE `QUARTZ_CALENDARS` DISABLE KEYS */;
/*!40000 ALTER TABLE `QUARTZ_CALENDARS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `QUARTZ_CRON_TRIGGERS`
--

DROP TABLE IF EXISTS `QUARTZ_CRON_TRIGGERS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `QUARTZ_CRON_TRIGGERS` (
  `SCHED_NAME` varchar(120) NOT NULL,
  `TRIGGER_NAME` varchar(200) NOT NULL,
  `TRIGGER_GROUP` varchar(200) NOT NULL,
  `CRON_EXPRESSION` varchar(200) NOT NULL,
  `TIME_ZONE_ID` varchar(80) DEFAULT NULL,
  PRIMARY KEY (`SCHED_NAME`,`TRIGGER_NAME`,`TRIGGER_GROUP`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `QUARTZ_CRON_TRIGGERS`
--

LOCK TABLES `QUARTZ_CRON_TRIGGERS` WRITE;
/*!40000 ALTER TABLE `QUARTZ_CRON_TRIGGERS` DISABLE KEYS */;
/*!40000 ALTER TABLE `QUARTZ_CRON_TRIGGERS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `QUARTZ_FIRED_TRIGGERS`
--

DROP TABLE IF EXISTS `QUARTZ_FIRED_TRIGGERS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `QUARTZ_FIRED_TRIGGERS` (
  `SCHED_NAME` varchar(120) NOT NULL,
  `ENTRY_ID` varchar(95) NOT NULL,
  `TRIGGER_NAME` varchar(200) NOT NULL,
  `TRIGGER_GROUP` varchar(200) NOT NULL,
  `INSTANCE_NAME` varchar(200) NOT NULL,
  `FIRED_TIME` bigint(20) NOT NULL,
  `PRIORITY` int(11) NOT NULL,
  `STATE` varchar(16) NOT NULL,
  `JOB_NAME` varchar(200) DEFAULT NULL,
  `JOB_GROUP` varchar(200) DEFAULT NULL,
  `IS_NONCONCURRENT` tinyint(4) DEFAULT NULL,
  `REQUESTS_RECOVERY` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`SCHED_NAME`,`ENTRY_ID`),
  KEY `IX_BE3835E5` (`SCHED_NAME`,`TRIGGER_NAME`,`TRIGGER_GROUP`),
  KEY `IX_4BD722BM` (`SCHED_NAME`,`TRIGGER_GROUP`),
  KEY `IX_204D31E8` (`SCHED_NAME`,`INSTANCE_NAME`),
  KEY `IX_339E078M` (`SCHED_NAME`,`INSTANCE_NAME`,`REQUESTS_RECOVERY`),
  KEY `IX_5005E3AF` (`SCHED_NAME`,`JOB_NAME`,`JOB_GROUP`),
  KEY `IX_BC2F03B0` (`SCHED_NAME`,`JOB_GROUP`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `QUARTZ_FIRED_TRIGGERS`
--

LOCK TABLES `QUARTZ_FIRED_TRIGGERS` WRITE;
/*!40000 ALTER TABLE `QUARTZ_FIRED_TRIGGERS` DISABLE KEYS */;
/*!40000 ALTER TABLE `QUARTZ_FIRED_TRIGGERS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `QUARTZ_JOB_DETAILS`
--

DROP TABLE IF EXISTS `QUARTZ_JOB_DETAILS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `QUARTZ_JOB_DETAILS` (
  `SCHED_NAME` varchar(120) NOT NULL,
  `JOB_NAME` varchar(200) NOT NULL,
  `JOB_GROUP` varchar(200) NOT NULL,
  `DESCRIPTION` varchar(250) DEFAULT NULL,
  `JOB_CLASS_NAME` varchar(250) NOT NULL,
  `IS_DURABLE` tinyint(4) NOT NULL,
  `IS_NONCONCURRENT` tinyint(4) NOT NULL,
  `IS_UPDATE_DATA` tinyint(4) NOT NULL,
  `REQUESTS_RECOVERY` tinyint(4) NOT NULL,
  `JOB_DATA` longblob,
  PRIMARY KEY (`SCHED_NAME`,`JOB_NAME`,`JOB_GROUP`),
  KEY `IX_88328984` (`SCHED_NAME`,`JOB_GROUP`),
  KEY `IX_779BCA37` (`SCHED_NAME`,`REQUESTS_RECOVERY`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `QUARTZ_JOB_DETAILS`
--

LOCK TABLES `QUARTZ_JOB_DETAILS` WRITE;
/*!40000 ALTER TABLE `QUARTZ_JOB_DETAILS` DISABLE KEYS */;
/*!40000 ALTER TABLE `QUARTZ_JOB_DETAILS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `QUARTZ_LOCKS`
--

DROP TABLE IF EXISTS `QUARTZ_LOCKS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `QUARTZ_LOCKS` (
  `SCHED_NAME` varchar(120) NOT NULL,
  `LOCK_NAME` varchar(40) NOT NULL,
  PRIMARY KEY (`SCHED_NAME`,`LOCK_NAME`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `QUARTZ_LOCKS`
--

LOCK TABLES `QUARTZ_LOCKS` WRITE;
/*!40000 ALTER TABLE `QUARTZ_LOCKS` DISABLE KEYS */;
/*!40000 ALTER TABLE `QUARTZ_LOCKS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `QUARTZ_PAUSED_TRIGGER_GRPS`
--

DROP TABLE IF EXISTS `QUARTZ_PAUSED_TRIGGER_GRPS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `QUARTZ_PAUSED_TRIGGER_GRPS` (
  `SCHED_NAME` varchar(120) NOT NULL,
  `TRIGGER_GROUP` varchar(200) NOT NULL,
  PRIMARY KEY (`SCHED_NAME`,`TRIGGER_GROUP`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `QUARTZ_PAUSED_TRIGGER_GRPS`
--

LOCK TABLES `QUARTZ_PAUSED_TRIGGER_GRPS` WRITE;
/*!40000 ALTER TABLE `QUARTZ_PAUSED_TRIGGER_GRPS` DISABLE KEYS */;
/*!40000 ALTER TABLE `QUARTZ_PAUSED_TRIGGER_GRPS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `QUARTZ_SCHEDULER_STATE`
--

DROP TABLE IF EXISTS `QUARTZ_SCHEDULER_STATE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `QUARTZ_SCHEDULER_STATE` (
  `SCHED_NAME` varchar(120) NOT NULL,
  `INSTANCE_NAME` varchar(200) NOT NULL,
  `LAST_CHECKIN_TIME` bigint(20) NOT NULL,
  `CHECKIN_INTERVAL` bigint(20) NOT NULL,
  PRIMARY KEY (`SCHED_NAME`,`INSTANCE_NAME`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `QUARTZ_SCHEDULER_STATE`
--

LOCK TABLES `QUARTZ_SCHEDULER_STATE` WRITE;
/*!40000 ALTER TABLE `QUARTZ_SCHEDULER_STATE` DISABLE KEYS */;
/*!40000 ALTER TABLE `QUARTZ_SCHEDULER_STATE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `QUARTZ_SIMPLE_TRIGGERS`
--

DROP TABLE IF EXISTS `QUARTZ_SIMPLE_TRIGGERS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `QUARTZ_SIMPLE_TRIGGERS` (
  `SCHED_NAME` varchar(120) NOT NULL,
  `TRIGGER_NAME` varchar(200) NOT NULL,
  `TRIGGER_GROUP` varchar(200) NOT NULL,
  `REPEAT_COUNT` bigint(20) NOT NULL,
  `REPEAT_INTERVAL` bigint(20) NOT NULL,
  `TIMES_TRIGGERED` bigint(20) NOT NULL,
  PRIMARY KEY (`SCHED_NAME`,`TRIGGER_NAME`,`TRIGGER_GROUP`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `QUARTZ_SIMPLE_TRIGGERS`
--

LOCK TABLES `QUARTZ_SIMPLE_TRIGGERS` WRITE;
/*!40000 ALTER TABLE `QUARTZ_SIMPLE_TRIGGERS` DISABLE KEYS */;
/*!40000 ALTER TABLE `QUARTZ_SIMPLE_TRIGGERS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `QUARTZ_SIMPROP_TRIGGERS`
--

DROP TABLE IF EXISTS `QUARTZ_SIMPROP_TRIGGERS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `QUARTZ_SIMPROP_TRIGGERS` (
  `SCHED_NAME` varchar(120) NOT NULL,
  `TRIGGER_NAME` varchar(200) NOT NULL,
  `TRIGGER_GROUP` varchar(200) NOT NULL,
  `STR_PROP_1` varchar(512) DEFAULT NULL,
  `STR_PROP_2` varchar(512) DEFAULT NULL,
  `STR_PROP_3` varchar(512) DEFAULT NULL,
  `INT_PROP_1` int(11) DEFAULT NULL,
  `INT_PROP_2` int(11) DEFAULT NULL,
  `LONG_PROP_1` bigint(20) DEFAULT NULL,
  `LONG_PROP_2` bigint(20) DEFAULT NULL,
  `DEC_PROP_1` decimal(13,4) DEFAULT NULL,
  `DEC_PROP_2` decimal(13,4) DEFAULT NULL,
  `BOOL_PROP_1` tinyint(4) DEFAULT NULL,
  `BOOL_PROP_2` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`SCHED_NAME`,`TRIGGER_NAME`,`TRIGGER_GROUP`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `QUARTZ_SIMPROP_TRIGGERS`
--

LOCK TABLES `QUARTZ_SIMPROP_TRIGGERS` WRITE;
/*!40000 ALTER TABLE `QUARTZ_SIMPROP_TRIGGERS` DISABLE KEYS */;
/*!40000 ALTER TABLE `QUARTZ_SIMPROP_TRIGGERS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `QUARTZ_TRIGGERS`
--

DROP TABLE IF EXISTS `QUARTZ_TRIGGERS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `QUARTZ_TRIGGERS` (
  `SCHED_NAME` varchar(120) NOT NULL,
  `TRIGGER_NAME` varchar(200) NOT NULL,
  `TRIGGER_GROUP` varchar(200) NOT NULL,
  `JOB_NAME` varchar(200) NOT NULL,
  `JOB_GROUP` varchar(200) NOT NULL,
  `DESCRIPTION` varchar(250) DEFAULT NULL,
  `NEXT_FIRE_TIME` bigint(20) DEFAULT NULL,
  `PREV_FIRE_TIME` bigint(20) DEFAULT NULL,
  `PRIORITY` int(11) DEFAULT NULL,
  `TRIGGER_STATE` varchar(16) NOT NULL,
  `TRIGGER_TYPE` varchar(8) NOT NULL,
  `START_TIME` bigint(20) NOT NULL,
  `END_TIME` bigint(20) DEFAULT NULL,
  `CALENDAR_NAME` varchar(200) DEFAULT NULL,
  `MISFIRE_INSTR` int(11) DEFAULT NULL,
  `JOB_DATA` longblob,
  PRIMARY KEY (`SCHED_NAME`,`TRIGGER_NAME`,`TRIGGER_GROUP`),
  KEY `IX_186442A4` (`SCHED_NAME`,`TRIGGER_NAME`,`TRIGGER_GROUP`,`TRIGGER_STATE`),
  KEY `IX_1BA1F9DC` (`SCHED_NAME`,`TRIGGER_GROUP`),
  KEY `IX_91CA7CCE` (`SCHED_NAME`,`TRIGGER_GROUP`,`NEXT_FIRE_TIME`,`TRIGGER_STATE`,`MISFIRE_INSTR`),
  KEY `IX_D219AFDE` (`SCHED_NAME`,`TRIGGER_GROUP`,`TRIGGER_STATE`),
  KEY `IX_A85822A0` (`SCHED_NAME`,`JOB_NAME`,`JOB_GROUP`),
  KEY `IX_8AA50BE1` (`SCHED_NAME`,`JOB_GROUP`),
  KEY `IX_EEFE382A` (`SCHED_NAME`,`NEXT_FIRE_TIME`),
  KEY `IX_F026CF4C` (`SCHED_NAME`,`NEXT_FIRE_TIME`,`TRIGGER_STATE`),
  KEY `IX_F2DD7C7E` (`SCHED_NAME`,`NEXT_FIRE_TIME`,`TRIGGER_STATE`,`MISFIRE_INSTR`),
  KEY `IX_1F92813C` (`SCHED_NAME`,`NEXT_FIRE_TIME`,`MISFIRE_INSTR`),
  KEY `IX_99108B6E` (`SCHED_NAME`,`TRIGGER_STATE`),
  KEY `IX_CD7132D0` (`SCHED_NAME`,`CALENDAR_NAME`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `QUARTZ_TRIGGERS`
--

LOCK TABLES `QUARTZ_TRIGGERS` WRITE;
/*!40000 ALTER TABLE `QUARTZ_TRIGGERS` DISABLE KEYS */;
/*!40000 ALTER TABLE `QUARTZ_TRIGGERS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `RatingsEntry`
--

DROP TABLE IF EXISTS `RatingsEntry`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `RatingsEntry` (
  `entryId` bigint(20) NOT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `userId` bigint(20) DEFAULT NULL,
  `userName` varchar(75) DEFAULT NULL,
  `createDate` datetime DEFAULT NULL,
  `modifiedDate` datetime DEFAULT NULL,
  `classNameId` bigint(20) DEFAULT NULL,
  `classPK` bigint(20) DEFAULT NULL,
  `score` double DEFAULT NULL,
  PRIMARY KEY (`entryId`),
  UNIQUE KEY `IX_B47E3C11` (`userId`,`classNameId`,`classPK`),
  KEY `IX_16184D57` (`classNameId`,`classPK`),
  KEY `IX_A1A8CB8B` (`classNameId`,`classPK`,`score`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `RatingsEntry`
--

LOCK TABLES `RatingsEntry` WRITE;
/*!40000 ALTER TABLE `RatingsEntry` DISABLE KEYS */;
/*!40000 ALTER TABLE `RatingsEntry` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `RatingsStats`
--

DROP TABLE IF EXISTS `RatingsStats`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `RatingsStats` (
  `statsId` bigint(20) NOT NULL,
  `classNameId` bigint(20) DEFAULT NULL,
  `classPK` bigint(20) DEFAULT NULL,
  `totalEntries` int(11) DEFAULT NULL,
  `totalScore` double DEFAULT NULL,
  `averageScore` double DEFAULT NULL,
  PRIMARY KEY (`statsId`),
  UNIQUE KEY `IX_A6E99284` (`classNameId`,`classPK`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `RatingsStats`
--

LOCK TABLES `RatingsStats` WRITE;
/*!40000 ALTER TABLE `RatingsStats` DISABLE KEYS */;
INSERT INTO `RatingsStats` VALUES (10445,10147,10435,0,0,0);
/*!40000 ALTER TABLE `RatingsStats` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Region`
--

DROP TABLE IF EXISTS `Region`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Region` (
  `regionId` bigint(20) NOT NULL,
  `countryId` bigint(20) DEFAULT NULL,
  `regionCode` varchar(75) DEFAULT NULL,
  `name` varchar(75) DEFAULT NULL,
  `active_` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`regionId`),
  KEY `IX_2D9A426F` (`active_`),
  KEY `IX_16D87CA7` (`countryId`),
  KEY `IX_11FB3E42` (`countryId`,`active_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Region`
--

LOCK TABLES `Region` WRITE;
/*!40000 ALTER TABLE `Region` DISABLE KEYS */;
INSERT INTO `Region` VALUES (1001,1,'AB','Alberta',1),(1002,1,'BC','British Columbia',1),(1003,1,'MB','Manitoba',1),(1004,1,'NB','New Brunswick',1),(1005,1,'NL','Newfoundland and Labrador',1),(1006,1,'NT','Northwest Territories',1),(1007,1,'NS','Nova Scotia',1),(1008,1,'NU','Nunavut',1),(1009,1,'ON','Ontario',1),(1010,1,'PE','Prince Edward Island',1),(1011,1,'QC','Quebec',1),(1012,1,'SK','Saskatchewan',1),(1013,1,'YT','Yukon',1),(2001,2,'CN-34','Anhui',1),(2002,2,'CN-92','Aomen',1),(2003,2,'CN-11','Beijing',1),(2004,2,'CN-50','Chongqing',1),(2005,2,'CN-35','Fujian',1),(2006,2,'CN-62','Gansu',1),(2007,2,'CN-44','Guangdong',1),(2008,2,'CN-45','Guangxi',1),(2009,2,'CN-52','Guizhou',1),(2010,2,'CN-46','Hainan',1),(2011,2,'CN-13','Hebei',1),(2012,2,'CN-23','Heilongjiang',1),(2013,2,'CN-41','Henan',1),(2014,2,'CN-42','Hubei',1),(2015,2,'CN-43','Hunan',1),(2016,2,'CN-32','Jiangsu',1),(2017,2,'CN-36','Jiangxi',1),(2018,2,'CN-22','Jilin',1),(2019,2,'CN-21','Liaoning',1),(2020,2,'CN-15','Nei Mongol',1),(2021,2,'CN-64','Ningxia',1),(2022,2,'CN-63','Qinghai',1),(2023,2,'CN-61','Shaanxi',1),(2024,2,'CN-37','Shandong',1),(2025,2,'CN-31','Shanghai',1),(2026,2,'CN-14','Shanxi',1),(2027,2,'CN-51','Sichuan',1),(2028,2,'CN-71','Taiwan',1),(2029,2,'CN-12','Tianjin',1),(2030,2,'CN-91','Xianggang',1),(2031,2,'CN-65','Xinjiang',1),(2032,2,'CN-54','Xizang',1),(2033,2,'CN-53','Yunnan',1),(2034,2,'CN-33','Zhejiang',1),(3001,3,'A','Alsace',1),(3002,3,'B','Aquitaine',1),(3003,3,'C','Auvergne',1),(3004,3,'P','Basse-Normandie',1),(3005,3,'D','Bourgogne',1),(3006,3,'E','Bretagne',1),(3007,3,'F','Centre',1),(3008,3,'G','Champagne-Ardenne',1),(3009,3,'H','Corse',1),(3010,3,'GF','Guyane',1),(3011,3,'I','Franche Comté',1),(3012,3,'GP','Guadeloupe',1),(3013,3,'Q','Haute-Normandie',1),(3014,3,'J','Île-de-France',1),(3015,3,'K','Languedoc-Roussillon',1),(3016,3,'L','Limousin',1),(3017,3,'M','Lorraine',1),(3018,3,'MQ','Martinique',1),(3019,3,'N','Midi-Pyrénées',1),(3020,3,'O','Nord Pas de Calais',1),(3021,3,'R','Pays de la Loire',1),(3022,3,'S','Picardie',1),(3023,3,'T','Poitou-Charentes',1),(3024,3,'U','Provence-Alpes-Côte-d\'Azur',1),(3025,3,'RE','Réunion',1),(3026,3,'V','Rhône-Alpes',1),(4001,4,'BW','Baden-Württemberg',1),(4002,4,'BY','Bayern',1),(4003,4,'BE','Berlin',1),(4004,4,'BR','Brandenburg',1),(4005,4,'HB','Bremen',1),(4006,4,'HH','Hamburg',1),(4007,4,'HE','Hessen',1),(4008,4,'MV','Mecklenburg-Vorpommern',1),(4009,4,'NI','Niedersachsen',1),(4010,4,'NW','Nordrhein-Westfalen',1),(4011,4,'RP','Rheinland-Pfalz',1),(4012,4,'SL','Saarland',1),(4013,4,'SN','Sachsen',1),(4014,4,'ST','Sachsen-Anhalt',1),(4015,4,'SH','Schleswig-Holstein',1),(4016,4,'TH','Thüringen',1),(8001,8,'AG','Agrigento',1),(8002,8,'AL','Alessandria',1),(8003,8,'AN','Ancona',1),(8004,8,'AO','Aosta',1),(8005,8,'AR','Arezzo',1),(8006,8,'AP','Ascoli Piceno',1),(8007,8,'AT','Asti',1),(8008,8,'AV','Avellino',1),(8009,8,'BA','Bari',1),(8010,8,'BT','Barletta-Andria-Trani',1),(8011,8,'BL','Belluno',1),(8012,8,'BN','Benevento',1),(8013,8,'BG','Bergamo',1),(8014,8,'BI','Biella',1),(8015,8,'BO','Bologna',1),(8016,8,'BZ','Bolzano',1),(8017,8,'BS','Brescia',1),(8018,8,'BR','Brindisi',1),(8019,8,'CA','Cagliari',1),(8020,8,'CL','Caltanissetta',1),(8021,8,'CB','Campobasso',1),(8022,8,'CI','Carbonia-Iglesias',1),(8023,8,'CE','Caserta',1),(8024,8,'CT','Catania',1),(8025,8,'CZ','Catanzaro',1),(8026,8,'CH','Chieti',1),(8027,8,'CO','Como',1),(8028,8,'CS','Cosenza',1),(8029,8,'CR','Cremona',1),(8030,8,'KR','Crotone',1),(8031,8,'CN','Cuneo',1),(8032,8,'EN','Enna',1),(8033,8,'FM','Fermo',1),(8034,8,'FE','Ferrara',1),(8035,8,'FI','Firenze',1),(8036,8,'FG','Foggia',1),(8037,8,'FC','Forli-Cesena',1),(8038,8,'FR','Frosinone',1),(8039,8,'GE','Genova',1),(8040,8,'GO','Gorizia',1),(8041,8,'GR','Grosseto',1),(8042,8,'IM','Imperia',1),(8043,8,'IS','Isernia',1),(8044,8,'AQ','L\'Aquila',1),(8045,8,'SP','La Spezia',1),(8046,8,'LT','Latina',1),(8047,8,'LE','Lecce',1),(8048,8,'LC','Lecco',1),(8049,8,'LI','Livorno',1),(8050,8,'LO','Lodi',1),(8051,8,'LU','Lucca',1),(8052,8,'MC','Macerata',1),(8053,8,'MN','Mantova',1),(8054,8,'MS','Massa-Carrara',1),(8055,8,'MT','Matera',1),(8056,8,'MA','Medio Campidano',1),(8057,8,'ME','Messina',1),(8058,8,'MI','Milano',1),(8059,8,'MO','Modena',1),(8060,8,'MZ','Monza',1),(8061,8,'NA','Napoli',1),(8062,8,'NO','Novara',1),(8063,8,'NU','Nuoro',1),(8064,8,'OG','Ogliastra',1),(8065,8,'OT','Olbia-Tempio',1),(8066,8,'OR','Oristano',1),(8067,8,'PD','Padova',1),(8068,8,'PA','Palermo',1),(8069,8,'PR','Parma',1),(8070,8,'PV','Pavia',1),(8071,8,'PG','Perugia',1),(8072,8,'PU','Pesaro e Urbino',1),(8073,8,'PE','Pescara',1),(8074,8,'PC','Piacenza',1),(8075,8,'PI','Pisa',1),(8076,8,'PT','Pistoia',1),(8077,8,'PN','Pordenone',1),(8078,8,'PZ','Potenza',1),(8079,8,'PO','Prato',1),(8080,8,'RG','Ragusa',1),(8081,8,'RA','Ravenna',1),(8082,8,'RC','Reggio Calabria',1),(8083,8,'RE','Reggio Emilia',1),(8084,8,'RI','Rieti',1),(8085,8,'RN','Rimini',1),(8086,8,'RM','Roma',1),(8087,8,'RO','Rovigo',1),(8088,8,'SA','Salerno',1),(8089,8,'SS','Sassari',1),(8090,8,'SV','Savona',1),(8091,8,'SI','Siena',1),(8092,8,'SR','Siracusa',1),(8093,8,'SO','Sondrio',1),(8094,8,'TA','Taranto',1),(8095,8,'TE','Teramo',1),(8096,8,'TR','Terni',1),(8097,8,'TO','Torino',1),(8098,8,'TP','Trapani',1),(8099,8,'TN','Trento',1),(8100,8,'TV','Treviso',1),(8101,8,'TS','Trieste',1),(8102,8,'UD','Udine',1),(8103,8,'VA','Varese',1),(8104,8,'VE','Venezia',1),(8105,8,'VB','Verbano-Cusio-Ossola',1),(8106,8,'VC','Vercelli',1),(8107,8,'VR','Verona',1),(8108,8,'VV','Vibo Valentia',1),(8109,8,'VI','Vicenza',1),(8110,8,'VT','Viterbo',1),(11001,11,'DR','Drenthe',1),(11002,11,'FL','Flevoland',1),(11003,11,'FR','Friesland',1),(11004,11,'GE','Gelderland',1),(11005,11,'GR','Groningen',1),(11006,11,'LI','Limburg',1),(11007,11,'NB','Noord-Brabant',1),(11008,11,'NH','Noord-Holland',1),(11009,11,'OV','Overijssel',1),(11010,11,'UT','Utrecht',1),(11011,11,'ZE','Zeeland',1),(11012,11,'ZH','Zuid-Holland',1),(15001,15,'AN','Andalusia',1),(15002,15,'AR','Aragon',1),(15003,15,'AS','Asturias',1),(15004,15,'IB','Balearic Islands',1),(15005,15,'PV','Basque Country',1),(15006,15,'CN','Canary Islands',1),(15007,15,'CB','Cantabria',1),(15008,15,'CL','Castile and Leon',1),(15009,15,'CM','Castile-La Mancha',1),(15010,15,'CT','Catalonia',1),(15011,15,'CE','Ceuta',1),(15012,15,'EX','Extremadura',1),(15013,15,'GA','Galicia',1),(15014,15,'LO','La Rioja',1),(15015,15,'M','Madrid',1),(15016,15,'ML','Melilla',1),(15017,15,'MU','Murcia',1),(15018,15,'NA','Navarra',1),(15019,15,'VC','Valencia',1),(19001,19,'AL','Alabama',1),(19002,19,'AK','Alaska',1),(19003,19,'AZ','Arizona',1),(19004,19,'AR','Arkansas',1),(19005,19,'CA','California',1),(19006,19,'CO','Colorado',1),(19007,19,'CT','Connecticut',1),(19008,19,'DC','District of Columbia',1),(19009,19,'DE','Delaware',1),(19010,19,'FL','Florida',1),(19011,19,'GA','Georgia',1),(19012,19,'HI','Hawaii',1),(19013,19,'ID','Idaho',1),(19014,19,'IL','Illinois',1),(19015,19,'IN','Indiana',1),(19016,19,'IA','Iowa',1),(19017,19,'KS','Kansas',1),(19018,19,'KY','Kentucky ',1),(19019,19,'LA','Louisiana ',1),(19020,19,'ME','Maine',1),(19021,19,'MD','Maryland',1),(19022,19,'MA','Massachusetts',1),(19023,19,'MI','Michigan',1),(19024,19,'MN','Minnesota',1),(19025,19,'MS','Mississippi',1),(19026,19,'MO','Missouri',1),(19027,19,'MT','Montana',1),(19028,19,'NE','Nebraska',1),(19029,19,'NV','Nevada',1),(19030,19,'NH','New Hampshire',1),(19031,19,'NJ','New Jersey',1),(19032,19,'NM','New Mexico',1),(19033,19,'NY','New York',1),(19034,19,'NC','North Carolina',1),(19035,19,'ND','North Dakota',1),(19036,19,'OH','Ohio',1),(19037,19,'OK','Oklahoma ',1),(19038,19,'OR','Oregon',1),(19039,19,'PA','Pennsylvania',1),(19040,19,'PR','Puerto Rico',1),(19041,19,'RI','Rhode Island',1),(19042,19,'SC','South Carolina',1),(19043,19,'SD','South Dakota',1),(19044,19,'TN','Tennessee',1),(19045,19,'TX','Texas',1),(19046,19,'UT','Utah',1),(19047,19,'VT','Vermont',1),(19048,19,'VA','Virginia',1),(19049,19,'WA','Washington',1),(19050,19,'WV','West Virginia',1),(19051,19,'WI','Wisconsin',1),(19052,19,'WY','Wyoming',1),(32001,32,'ACT','Australian Capital Territory',1),(32002,32,'NSW','New South Wales',1),(32003,32,'NT','Northern Territory',1),(32004,32,'QLD','Queensland',1),(32005,32,'SA','South Australia',1),(32006,32,'TAS','Tasmania',1),(32007,32,'VIC','Victoria',1),(32008,32,'WA','Western Australia',1),(144001,144,'MX-AGS','Aguascalientes',1),(144002,144,'MX-BCN','Baja California',1),(144003,144,'MX-BCS','Baja California Sur',1),(144004,144,'MX-CAM','Campeche',1),(144005,144,'MX-CHP','Chiapas',1),(144006,144,'MX-CHI','Chihuahua',1),(144007,144,'MX-COA','Coahuila',1),(144008,144,'MX-COL','Colima',1),(144009,144,'MX-DUR','Durango',1),(144010,144,'MX-GTO','Guanajuato',1),(144011,144,'MX-GRO','Guerrero',1),(144012,144,'MX-HGO','Hidalgo',1),(144013,144,'MX-JAL','Jalisco',1),(144014,144,'MX-MEX','Mexico',1),(144015,144,'MX-MIC','Michoacan',1),(144016,144,'MX-MOR','Morelos',1),(144017,144,'MX-NAY','Nayarit',1),(144018,144,'MX-NLE','Nuevo Leon',1),(144019,144,'MX-OAX','Oaxaca',1),(144020,144,'MX-PUE','Puebla',1),(144021,144,'MX-QRO','Queretaro',1),(144023,144,'MX-ROO','Quintana Roo',1),(144024,144,'MX-SLP','San Luis Potosí',1),(144025,144,'MX-SIN','Sinaloa',1),(144026,144,'MX-SON','Sonora',1),(144027,144,'MX-TAB','Tabasco',1),(144028,144,'MX-TAM','Tamaulipas',1),(144029,144,'MX-TLX','Tlaxcala',1),(144030,144,'MX-VER','Veracruz',1),(144031,144,'MX-YUC','Yucatan',1),(144032,144,'MX-ZAC','Zacatecas',1),(164001,164,'01','Østfold',1),(164002,164,'02','Akershus',1),(164003,164,'03','Oslo',1),(164004,164,'04','Hedmark',1),(164005,164,'05','Oppland',1),(164006,164,'06','Buskerud',1),(164007,164,'07','Vestfold',1),(164008,164,'08','Telemark',1),(164009,164,'09','Aust-Agder',1),(164010,164,'10','Vest-Agder',1),(164011,164,'11','Rogaland',1),(164012,164,'12','Hordaland',1),(164013,164,'14','Sogn og Fjordane',1),(164014,164,'15','Møre of Romsdal',1),(164015,164,'16','Sør-Trøndelag',1),(164016,164,'17','Nord-Trøndelag',1),(164017,164,'18','Nordland',1),(164018,164,'19','Troms',1),(164019,164,'20','Finnmark',1),(202001,202,'AG','Aargau',1),(202002,202,'AR','Appenzell Ausserrhoden',1),(202003,202,'AI','Appenzell Innerrhoden',1),(202004,202,'BL','Basel-Landschaft',1),(202005,202,'BS','Basel-Stadt',1),(202006,202,'BE','Bern',1),(202007,202,'FR','Fribourg',1),(202008,202,'GE','Geneva',1),(202009,202,'GL','Glarus',1),(202010,202,'GR','Graubünden',1),(202011,202,'JU','Jura',1),(202012,202,'LU','Lucerne',1),(202013,202,'NE','Neuchâtel',1),(202014,202,'NW','Nidwalden',1),(202015,202,'OW','Obwalden',1),(202016,202,'SH','Schaffhausen',1),(202017,202,'SZ','Schwyz',1),(202018,202,'SO','Solothurn',1),(202019,202,'SG','St. Gallen',1),(202020,202,'TG','Thurgau',1),(202021,202,'TI','Ticino',1),(202022,202,'UR','Uri',1),(202023,202,'VS','Valais',1),(202024,202,'VD','Vaud',1),(202025,202,'ZG','Zug',1),(202026,202,'ZH','Zürich',1);
/*!40000 ALTER TABLE `Region` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Release_`
--

DROP TABLE IF EXISTS `Release_`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Release_` (
  `releaseId` bigint(20) NOT NULL,
  `createDate` datetime DEFAULT NULL,
  `modifiedDate` datetime DEFAULT NULL,
  `servletContextName` varchar(75) DEFAULT NULL,
  `buildNumber` int(11) DEFAULT NULL,
  `buildDate` datetime DEFAULT NULL,
  `verified` tinyint(4) DEFAULT NULL,
  `testString` varchar(1024) DEFAULT NULL,
  PRIMARY KEY (`releaseId`),
  KEY `IX_8BD6BCA7` (`servletContextName`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Release_`
--

LOCK TABLES `Release_` WRITE;
/*!40000 ALTER TABLE `Release_` DISABLE KEYS */;
INSERT INTO `Release_` VALUES (1,'2014-03-18 10:33:25','2014-07-08 23:01:59','portal',6110,'2012-02-15 00:00:00',1,'You take the blue pill, the story ends, you wake up in your bed and believe whatever you want to believe. You take the red pill, you stay in Wonderland, and I show you how deep the rabbit hole goes.');
/*!40000 ALTER TABLE `Release_` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Repository`
--

DROP TABLE IF EXISTS `Repository`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Repository` (
  `uuid_` varchar(75) DEFAULT NULL,
  `repositoryId` bigint(20) NOT NULL,
  `groupId` bigint(20) DEFAULT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `userId` bigint(20) DEFAULT NULL,
  `userName` varchar(75) DEFAULT NULL,
  `createDate` datetime DEFAULT NULL,
  `modifiedDate` datetime DEFAULT NULL,
  `classNameId` bigint(20) DEFAULT NULL,
  `name` varchar(75) DEFAULT NULL,
  `description` longtext,
  `portletId` varchar(75) DEFAULT NULL,
  `typeSettings` longtext,
  `dlFolderId` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`repositoryId`),
  UNIQUE KEY `IX_11641E26` (`uuid_`,`groupId`),
  KEY `IX_5253B1FA` (`groupId`),
  KEY `IX_74C17B04` (`uuid_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Repository`
--

LOCK TABLES `Repository` WRITE;
/*!40000 ALTER TABLE `Repository` DISABLE KEYS */;
/*!40000 ALTER TABLE `Repository` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `RepositoryEntry`
--

DROP TABLE IF EXISTS `RepositoryEntry`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `RepositoryEntry` (
  `uuid_` varchar(75) DEFAULT NULL,
  `repositoryEntryId` bigint(20) NOT NULL,
  `groupId` bigint(20) DEFAULT NULL,
  `repositoryId` bigint(20) DEFAULT NULL,
  `mappedId` varchar(75) DEFAULT NULL,
  PRIMARY KEY (`repositoryEntryId`),
  UNIQUE KEY `IX_9BDCF489` (`repositoryId`,`mappedId`),
  UNIQUE KEY `IX_354AA664` (`uuid_`,`groupId`),
  KEY `IX_B7034B27` (`repositoryId`),
  KEY `IX_B9B1506` (`uuid_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `RepositoryEntry`
--

LOCK TABLES `RepositoryEntry` WRITE;
/*!40000 ALTER TABLE `RepositoryEntry` DISABLE KEYS */;
/*!40000 ALTER TABLE `RepositoryEntry` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ResourceAction`
--

DROP TABLE IF EXISTS `ResourceAction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ResourceAction` (
  `resourceActionId` bigint(20) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `actionId` varchar(75) DEFAULT NULL,
  `bitwiseValue` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`resourceActionId`),
  UNIQUE KEY `IX_EDB9986E` (`name`,`actionId`),
  KEY `IX_81F2DB09` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ResourceAction`
--

LOCK TABLES `ResourceAction` WRITE;
/*!40000 ALTER TABLE `ResourceAction` DISABLE KEYS */;
INSERT INTO `ResourceAction` VALUES (1,'com.liferay.portlet.softwarecatalog','ADD_FRAMEWORK_VERSION',2),(2,'com.liferay.portlet.softwarecatalog','ADD_PRODUCT_ENTRY',4),(3,'com.liferay.portlet.softwarecatalog','PERMISSIONS',8),(4,'com.liferay.portal.model.Team','ASSIGN_MEMBERS',2),(5,'com.liferay.portal.model.Team','DELETE',4),(6,'com.liferay.portal.model.Team','PERMISSIONS',8),(7,'com.liferay.portal.model.Team','UPDATE',16),(8,'com.liferay.portal.model.Team','VIEW',1),(9,'com.liferay.portal.model.PasswordPolicy','ASSIGN_MEMBERS',2),(10,'com.liferay.portal.model.PasswordPolicy','DELETE',4),(11,'com.liferay.portal.model.PasswordPolicy','PERMISSIONS',8),(12,'com.liferay.portal.model.PasswordPolicy','UPDATE',16),(13,'com.liferay.portal.model.PasswordPolicy','VIEW',1),(14,'com.liferay.portlet.blogs.model.BlogsEntry','ADD_DISCUSSION',2),(15,'com.liferay.portlet.blogs.model.BlogsEntry','DELETE',4),(16,'com.liferay.portlet.blogs.model.BlogsEntry','DELETE_DISCUSSION',8),(17,'com.liferay.portlet.blogs.model.BlogsEntry','PERMISSIONS',16),(18,'com.liferay.portlet.blogs.model.BlogsEntry','UPDATE',32),(19,'com.liferay.portlet.blogs.model.BlogsEntry','UPDATE_DISCUSSION',64),(20,'com.liferay.portlet.blogs.model.BlogsEntry','VIEW',1),(21,'com.liferay.portlet.dynamicdatamapping.model.DDMTemplate','DELETE',2),(22,'com.liferay.portlet.dynamicdatamapping.model.DDMTemplate','PERMISSIONS',4),(23,'com.liferay.portlet.dynamicdatamapping.model.DDMTemplate','UPDATE',8),(24,'com.liferay.portlet.dynamicdatamapping.model.DDMTemplate','VIEW',1),(25,'com.liferay.portlet.journal.model.JournalFeed','DELETE',2),(26,'com.liferay.portlet.journal.model.JournalFeed','PERMISSIONS',4),(27,'com.liferay.portlet.journal.model.JournalFeed','UPDATE',8),(28,'com.liferay.portlet.journal.model.JournalFeed','VIEW',1),(29,'com.liferay.portlet.wiki.model.WikiNode','ADD_ATTACHMENT',2),(30,'com.liferay.portlet.wiki.model.WikiNode','ADD_PAGE',4),(31,'com.liferay.portlet.wiki.model.WikiNode','DELETE',8),(32,'com.liferay.portlet.wiki.model.WikiNode','IMPORT',16),(33,'com.liferay.portlet.wiki.model.WikiNode','PERMISSIONS',32),(34,'com.liferay.portlet.wiki.model.WikiNode','SUBSCRIBE',64),(35,'com.liferay.portlet.wiki.model.WikiNode','UPDATE',128),(36,'com.liferay.portlet.wiki.model.WikiNode','VIEW',1),(37,'com.liferay.portlet.announcements.model.AnnouncementsEntry','DELETE',2),(38,'com.liferay.portlet.announcements.model.AnnouncementsEntry','UPDATE',4),(39,'com.liferay.portlet.announcements.model.AnnouncementsEntry','VIEW',1),(40,'com.liferay.portlet.announcements.model.AnnouncementsEntry','PERMISSIONS',8),(41,'com.liferay.portlet.bookmarks','ADD_ENTRY',2),(42,'com.liferay.portlet.bookmarks','ADD_FOLDER',4),(43,'com.liferay.portlet.bookmarks','PERMISSIONS',8),(44,'com.liferay.portlet.bookmarks','VIEW',1),(45,'com.liferay.portlet.mobiledevicerules.model.MDRRuleGroupInstance','DELETE',2),(46,'com.liferay.portlet.mobiledevicerules.model.MDRRuleGroupInstance','PERMISSIONS',4),(47,'com.liferay.portlet.mobiledevicerules.model.MDRRuleGroupInstance','UPDATE',8),(48,'com.liferay.portlet.mobiledevicerules.model.MDRRuleGroupInstance','VIEW',1),(49,'com.liferay.portlet.asset.model.AssetVocabulary','DELETE',2),(50,'com.liferay.portlet.asset.model.AssetVocabulary','PERMISSIONS',4),(51,'com.liferay.portlet.asset.model.AssetVocabulary','UPDATE',8),(52,'com.liferay.portlet.asset.model.AssetVocabulary','VIEW',1),(53,'com.liferay.portlet.documentlibrary.model.DLFolder','ACCESS',2),(54,'com.liferay.portlet.documentlibrary.model.DLFolder','ADD_DOCUMENT',4),(55,'com.liferay.portlet.documentlibrary.model.DLFolder','ADD_SHORTCUT',8),(56,'com.liferay.portlet.documentlibrary.model.DLFolder','ADD_SUBFOLDER',16),(57,'com.liferay.portlet.documentlibrary.model.DLFolder','DELETE',32),(58,'com.liferay.portlet.documentlibrary.model.DLFolder','PERMISSIONS',64),(59,'com.liferay.portlet.documentlibrary.model.DLFolder','UPDATE',128),(60,'com.liferay.portlet.documentlibrary.model.DLFolder','VIEW',1),(61,'com.liferay.portlet.expando.model.ExpandoColumn','DELETE',2),(62,'com.liferay.portlet.expando.model.ExpandoColumn','PERMISSIONS',4),(63,'com.liferay.portlet.expando.model.ExpandoColumn','UPDATE',8),(64,'com.liferay.portlet.expando.model.ExpandoColumn','VIEW',1),(65,'com.liferay.portlet.documentlibrary','ADD_DOCUMENT',2),(66,'com.liferay.portlet.documentlibrary','ADD_DOCUMENT_TYPE',4),(67,'com.liferay.portlet.documentlibrary','ADD_FOLDER',8),(68,'com.liferay.portlet.documentlibrary','ADD_REPOSITORY',16),(69,'com.liferay.portlet.documentlibrary','ADD_STRUCTURE',32),(70,'com.liferay.portlet.documentlibrary','ADD_SHORTCUT',64),(71,'com.liferay.portlet.documentlibrary','PERMISSIONS',128),(72,'com.liferay.portlet.documentlibrary','UPDATE',256),(73,'com.liferay.portlet.documentlibrary','VIEW',1),(74,'com.liferay.portlet.calendar.model.CalEvent','ADD_DISCUSSION',2),(75,'com.liferay.portlet.calendar.model.CalEvent','DELETE',4),(76,'com.liferay.portlet.calendar.model.CalEvent','DELETE_DISCUSSION',8),(77,'com.liferay.portlet.calendar.model.CalEvent','PERMISSIONS',16),(78,'com.liferay.portlet.calendar.model.CalEvent','UPDATE',32),(79,'com.liferay.portlet.calendar.model.CalEvent','UPDATE_DISCUSSION',64),(80,'com.liferay.portlet.calendar.model.CalEvent','VIEW',1),(81,'com.liferay.portlet.shopping.model.ShoppingCategory','ADD_ITEM',2),(82,'com.liferay.portlet.shopping.model.ShoppingCategory','ADD_SUBCATEGORY',4),(83,'com.liferay.portlet.shopping.model.ShoppingCategory','DELETE',8),(84,'com.liferay.portlet.shopping.model.ShoppingCategory','PERMISSIONS',16),(85,'com.liferay.portlet.shopping.model.ShoppingCategory','UPDATE',32),(86,'com.liferay.portlet.shopping.model.ShoppingCategory','VIEW',1),(87,'com.liferay.portlet.documentlibrary.model.DLFileShortcut','ADD_DISCUSSION',2),(88,'com.liferay.portlet.documentlibrary.model.DLFileShortcut','DELETE',4),(89,'com.liferay.portlet.documentlibrary.model.DLFileShortcut','DELETE_DISCUSSION',8),(90,'com.liferay.portlet.documentlibrary.model.DLFileShortcut','PERMISSIONS',16),(91,'com.liferay.portlet.documentlibrary.model.DLFileShortcut','UPDATE',32),(92,'com.liferay.portlet.documentlibrary.model.DLFileShortcut','UPDATE_DISCUSSION',64),(93,'com.liferay.portlet.documentlibrary.model.DLFileShortcut','VIEW',1),(94,'com.liferay.portlet.journal','ADD_ARTICLE',2),(95,'com.liferay.portlet.journal','ADD_FEED',4),(96,'com.liferay.portlet.journal','ADD_STRUCTURE',8),(97,'com.liferay.portlet.journal','ADD_TEMPLATE',16),(98,'com.liferay.portlet.journal','SUBSCRIBE',32),(99,'com.liferay.portlet.journal','PERMISSIONS',64),(100,'com.liferay.portlet.calendar','ADD_EVENT',2),(101,'com.liferay.portlet.calendar','EXPORT_ALL_EVENTS',4),(102,'com.liferay.portlet.calendar','PERMISSIONS',8),(103,'com.liferay.portal.model.LayoutPrototype','DELETE',2),(104,'com.liferay.portal.model.LayoutPrototype','PERMISSIONS',4),(105,'com.liferay.portal.model.LayoutPrototype','UPDATE',8),(106,'com.liferay.portal.model.LayoutPrototype','VIEW',1),(107,'com.liferay.portlet.dynamicdatalists.model.DDLRecordSet','ADD_RECORD',2),(108,'com.liferay.portlet.dynamicdatalists.model.DDLRecordSet','DELETE',4),(109,'com.liferay.portlet.dynamicdatalists.model.DDLRecordSet','PERMISSIONS',8),(110,'com.liferay.portlet.dynamicdatalists.model.DDLRecordSet','UPDATE',16),(111,'com.liferay.portlet.dynamicdatalists.model.DDLRecordSet','VIEW',1),(112,'com.liferay.portal.model.Organization','ASSIGN_MEMBERS',2),(113,'com.liferay.portal.model.Organization','ASSIGN_USER_ROLES',4),(114,'com.liferay.portal.model.Organization','DELETE',8),(115,'com.liferay.portal.model.Organization','MANAGE_ANNOUNCEMENTS',16),(116,'com.liferay.portal.model.Organization','MANAGE_SUBORGANIZATIONS',32),(117,'com.liferay.portal.model.Organization','MANAGE_USERS',64),(118,'com.liferay.portal.model.Organization','PERMISSIONS',128),(119,'com.liferay.portal.model.Organization','UPDATE',256),(120,'com.liferay.portal.model.Organization','VIEW',1),(121,'com.liferay.portlet.softwarecatalog.model.SCLicense','DELETE',2),(122,'com.liferay.portlet.softwarecatalog.model.SCLicense','PERMISSIONS',4),(123,'com.liferay.portlet.softwarecatalog.model.SCLicense','UPDATE',8),(124,'com.liferay.portlet.softwarecatalog.model.SCLicense','VIEW',1),(125,'com.liferay.portlet.documentlibrary.model.DLFileEntryType','DELETE',2),(126,'com.liferay.portlet.documentlibrary.model.DLFileEntryType','PERMISSIONS',4),(127,'com.liferay.portlet.documentlibrary.model.DLFileEntryType','UPDATE',8),(128,'com.liferay.portlet.documentlibrary.model.DLFileEntryType','VIEW',1),(129,'com.liferay.portlet.journal.model.JournalTemplate','DELETE',2),(130,'com.liferay.portlet.journal.model.JournalTemplate','PERMISSIONS',4),(131,'com.liferay.portlet.journal.model.JournalTemplate','UPDATE',8),(132,'com.liferay.portlet.journal.model.JournalTemplate','VIEW',1),(133,'com.liferay.portlet.journal.model.JournalArticle','ADD_DISCUSSION',2),(134,'com.liferay.portlet.journal.model.JournalArticle','DELETE',4),(135,'com.liferay.portlet.journal.model.JournalArticle','DELETE_DISCUSSION',8),(136,'com.liferay.portlet.journal.model.JournalArticle','EXPIRE',16),(137,'com.liferay.portlet.journal.model.JournalArticle','PERMISSIONS',32),(138,'com.liferay.portlet.journal.model.JournalArticle','UPDATE',64),(139,'com.liferay.portlet.journal.model.JournalArticle','UPDATE_DISCUSSION',128),(140,'com.liferay.portlet.journal.model.JournalArticle','VIEW',1),(141,'com.liferay.portlet.dynamicdatalists','ADD_RECORD_SET',2),(142,'com.liferay.portlet.dynamicdatalists','ADD_STRUCTURE',4),(143,'com.liferay.portlet.dynamicdatalists','ADD_TEMPLATE',8),(144,'com.liferay.portlet.dynamicdatalists','PERMISSIONS',16),(145,'com.liferay.portlet.bookmarks.model.BookmarksFolder','ACCESS',2),(146,'com.liferay.portlet.bookmarks.model.BookmarksFolder','ADD_ENTRY',4),(147,'com.liferay.portlet.bookmarks.model.BookmarksFolder','ADD_SUBFOLDER',8),(148,'com.liferay.portlet.bookmarks.model.BookmarksFolder','DELETE',16),(149,'com.liferay.portlet.bookmarks.model.BookmarksFolder','PERMISSIONS',32),(150,'com.liferay.portlet.bookmarks.model.BookmarksFolder','UPDATE',64),(151,'com.liferay.portlet.bookmarks.model.BookmarksFolder','VIEW',1),(152,'com.liferay.portal.model.Group','ADD_LAYOUT',2),(153,'com.liferay.portal.model.Group','ADD_LAYOUT_BRANCH',4),(154,'com.liferay.portal.model.Group','ADD_LAYOUT_SET_BRANCH',8),(155,'com.liferay.portal.model.Group','ASSIGN_MEMBERS',16),(156,'com.liferay.portal.model.Group','ASSIGN_USER_ROLES',32),(157,'com.liferay.portal.model.Group','CONFIGURE_PORTLETS',64),(158,'com.liferay.portal.model.Group','DELETE',128),(159,'com.liferay.portal.model.Group','EXPORT_IMPORT_LAYOUTS',256),(160,'com.liferay.portal.model.Group','EXPORT_IMPORT_PORTLET_INFO',512),(161,'com.liferay.portal.model.Group','MANAGE_ANNOUNCEMENTS',1024),(162,'com.liferay.portal.model.Group','MANAGE_ARCHIVED_SETUPS',2048),(163,'com.liferay.portal.model.Group','MANAGE_LAYOUTS',4096),(164,'com.liferay.portal.model.Group','MANAGE_STAGING',8192),(165,'com.liferay.portal.model.Group','MANAGE_TEAMS',16384),(166,'com.liferay.portal.model.Group','PERMISSIONS',32768),(167,'com.liferay.portal.model.Group','PUBLISH_STAGING',65536),(168,'com.liferay.portal.model.Group','PUBLISH_TO_REMOTE',131072),(169,'com.liferay.portal.model.Group','UPDATE',262144),(170,'com.liferay.portal.model.Group','VIEW',1),(171,'com.liferay.portal.model.Group','VIEW_MEMBERS',524288),(172,'com.liferay.portal.model.Group','VIEW_STAGING',1048576),(173,'com.liferay.portlet.journal.model.JournalStructure','DELETE',2),(174,'com.liferay.portlet.journal.model.JournalStructure','PERMISSIONS',4),(175,'com.liferay.portlet.journal.model.JournalStructure','UPDATE',8),(176,'com.liferay.portlet.journal.model.JournalStructure','VIEW',1),(177,'com.liferay.portlet.asset.model.AssetTag','DELETE',2),(178,'com.liferay.portlet.asset.model.AssetTag','PERMISSIONS',4),(179,'com.liferay.portlet.asset.model.AssetTag','UPDATE',8),(180,'com.liferay.portlet.asset.model.AssetTag','VIEW',1),(181,'com.liferay.portal.model.Layout','ADD_DISCUSSION',2),(182,'com.liferay.portal.model.Layout','ADD_LAYOUT',4),(183,'com.liferay.portal.model.Layout','CONFIGURE_PORTLETS',8),(184,'com.liferay.portal.model.Layout','CUSTOMIZE',16),(185,'com.liferay.portal.model.Layout','DELETE',32),(186,'com.liferay.portal.model.Layout','DELETE_DISCUSSION',64),(187,'com.liferay.portal.model.Layout','PERMISSIONS',128),(188,'com.liferay.portal.model.Layout','UPDATE',256),(189,'com.liferay.portal.model.Layout','UPDATE_DISCUSSION',512),(190,'com.liferay.portal.model.Layout','VIEW',1),(191,'com.liferay.portlet.asset','ADD_TAG',2),(192,'com.liferay.portlet.asset','PERMISSIONS',4),(193,'com.liferay.portlet.asset','ADD_CATEGORY',8),(194,'com.liferay.portlet.asset','ADD_VOCABULARY',16),(195,'com.liferay.portal.model.LayoutBranch','DELETE',2),(196,'com.liferay.portal.model.LayoutBranch','PERMISSIONS',4),(197,'com.liferay.portal.model.LayoutBranch','UPDATE',8),(198,'com.liferay.portal.model.LayoutSetBranch','DELETE',2),(199,'com.liferay.portal.model.LayoutSetBranch','MERGE',4),(200,'com.liferay.portal.model.LayoutSetBranch','PERMISSIONS',8),(201,'com.liferay.portal.model.LayoutSetBranch','UPDATE',16),(202,'com.liferay.portlet.messageboards','ADD_CATEGORY',2),(203,'com.liferay.portlet.messageboards','ADD_FILE',4),(204,'com.liferay.portlet.messageboards','ADD_MESSAGE',8),(205,'com.liferay.portlet.messageboards','BAN_USER',16),(206,'com.liferay.portlet.messageboards','MOVE_THREAD',32),(207,'com.liferay.portlet.messageboards','LOCK_THREAD',64),(208,'com.liferay.portlet.messageboards','PERMISSIONS',128),(209,'com.liferay.portlet.messageboards','REPLY_TO_MESSAGE',256),(210,'com.liferay.portlet.messageboards','SUBSCRIBE',512),(211,'com.liferay.portlet.messageboards','UPDATE_THREAD_PRIORITY',1024),(212,'com.liferay.portlet.messageboards','VIEW',1),(213,'com.liferay.portlet.polls','ADD_QUESTION',2),(214,'com.liferay.portlet.polls','PERMISSIONS',4),(215,'com.liferay.portlet.shopping.model.ShoppingItem','DELETE',2),(216,'com.liferay.portlet.shopping.model.ShoppingItem','PERMISSIONS',4),(217,'com.liferay.portlet.shopping.model.ShoppingItem','UPDATE',8),(218,'com.liferay.portlet.shopping.model.ShoppingItem','VIEW',1),(219,'com.liferay.portlet.bookmarks.model.BookmarksEntry','DELETE',2),(220,'com.liferay.portlet.bookmarks.model.BookmarksEntry','PERMISSIONS',4),(221,'com.liferay.portlet.bookmarks.model.BookmarksEntry','UPDATE',8),(222,'com.liferay.portlet.bookmarks.model.BookmarksEntry','VIEW',1),(223,'com.liferay.portlet.softwarecatalog.model.SCProductEntry','ADD_DISCUSSION',2),(224,'com.liferay.portlet.softwarecatalog.model.SCProductEntry','DELETE',4),(225,'com.liferay.portlet.softwarecatalog.model.SCProductEntry','DELETE_DISCUSSION',8),(226,'com.liferay.portlet.softwarecatalog.model.SCProductEntry','PERMISSIONS',16),(227,'com.liferay.portlet.softwarecatalog.model.SCProductEntry','UPDATE',32),(228,'com.liferay.portlet.softwarecatalog.model.SCProductEntry','UPDATE_DISCUSSION',64),(229,'com.liferay.portlet.softwarecatalog.model.SCProductEntry','VIEW',1),(230,'com.liferay.portal.model.User','DELETE',2),(231,'com.liferay.portal.model.User','IMPERSONATE',4),(232,'com.liferay.portal.model.User','PERMISSIONS',8),(233,'com.liferay.portal.model.User','UPDATE',16),(234,'com.liferay.portal.model.User','VIEW',1),(235,'com.liferay.portal.model.LayoutSetPrototype','DELETE',2),(236,'com.liferay.portal.model.LayoutSetPrototype','PERMISSIONS',4),(237,'com.liferay.portal.model.LayoutSetPrototype','UPDATE',8),(238,'com.liferay.portal.model.LayoutSetPrototype','VIEW',1),(239,'com.liferay.portlet.shopping','ADD_CATEGORY',2),(240,'com.liferay.portlet.shopping','ADD_ITEM',4),(241,'com.liferay.portlet.shopping','MANAGE_COUPONS',8),(242,'com.liferay.portlet.shopping','MANAGE_ORDERS',16),(243,'com.liferay.portlet.shopping','PERMISSIONS',32),(244,'com.liferay.portlet.shopping','VIEW',1),(245,'com.liferay.portlet.softwarecatalog.model.SCFrameworkVersion','DELETE',2),(246,'com.liferay.portlet.softwarecatalog.model.SCFrameworkVersion','PERMISSIONS',4),(247,'com.liferay.portlet.softwarecatalog.model.SCFrameworkVersion','UPDATE',8),(248,'com.liferay.portlet.wiki','ADD_NODE',2),(249,'com.liferay.portlet.wiki','PERMISSIONS',4),(250,'com.liferay.portlet.polls.model.PollsQuestion','ADD_VOTE',2),(251,'com.liferay.portlet.polls.model.PollsQuestion','DELETE',4),(252,'com.liferay.portlet.polls.model.PollsQuestion','PERMISSIONS',8),(253,'com.liferay.portlet.polls.model.PollsQuestion','UPDATE',16),(254,'com.liferay.portlet.polls.model.PollsQuestion','VIEW',1),(255,'com.liferay.portlet.shopping.model.ShoppingOrder','DELETE',2),(256,'com.liferay.portlet.shopping.model.ShoppingOrder','PERMISSIONS',4),(257,'com.liferay.portlet.shopping.model.ShoppingOrder','UPDATE',8),(258,'com.liferay.portlet.shopping.model.ShoppingOrder','VIEW',1),(259,'com.liferay.portal.model.UserGroup','ASSIGN_MEMBERS',2),(260,'com.liferay.portal.model.UserGroup','DELETE',4),(261,'com.liferay.portal.model.UserGroup','MANAGE_ANNOUNCEMENTS',8),(262,'com.liferay.portal.model.UserGroup','PERMISSIONS',16),(263,'com.liferay.portal.model.UserGroup','UPDATE',32),(264,'com.liferay.portal.model.UserGroup','VIEW',1),(265,'com.liferay.portal.model.Role','ASSIGN_MEMBERS',2),(266,'com.liferay.portal.model.Role','DEFINE_PERMISSIONS',4),(267,'com.liferay.portal.model.Role','DELETE',8),(268,'com.liferay.portal.model.Role','MANAGE_ANNOUNCEMENTS',16),(269,'com.liferay.portal.model.Role','PERMISSIONS',32),(270,'com.liferay.portal.model.Role','UPDATE',64),(271,'com.liferay.portal.model.Role','VIEW',1),(272,'com.liferay.portlet.messageboards.model.MBCategory','ADD_FILE',2),(273,'com.liferay.portlet.messageboards.model.MBCategory','ADD_MESSAGE',4),(274,'com.liferay.portlet.messageboards.model.MBCategory','ADD_SUBCATEGORY',8),(275,'com.liferay.portlet.messageboards.model.MBCategory','DELETE',16),(276,'com.liferay.portlet.messageboards.model.MBCategory','LOCK_THREAD',32),(277,'com.liferay.portlet.messageboards.model.MBCategory','MOVE_THREAD',64),(278,'com.liferay.portlet.messageboards.model.MBCategory','PERMISSIONS',128),(279,'com.liferay.portlet.messageboards.model.MBCategory','REPLY_TO_MESSAGE',256),(280,'com.liferay.portlet.messageboards.model.MBCategory','SUBSCRIBE',512),(281,'com.liferay.portlet.messageboards.model.MBCategory','UPDATE',1024),(282,'com.liferay.portlet.messageboards.model.MBCategory','UPDATE_THREAD_PRIORITY',2048),(283,'com.liferay.portlet.messageboards.model.MBCategory','VIEW',1),(284,'com.liferay.portlet.mobiledevicerules','ADD_RULE_GROUP',2),(285,'com.liferay.portlet.mobiledevicerules','ADD_RULE_GROUP_INSTANCE',4),(286,'com.liferay.portlet.mobiledevicerules','CONFIGURATION',8),(287,'com.liferay.portlet.mobiledevicerules','VIEW',1),(288,'com.liferay.portlet.mobiledevicerules','PERMISSIONS',16),(289,'com.liferay.portlet.dynamicdatamapping.model.DDMStructure','DELETE',2),(290,'com.liferay.portlet.dynamicdatamapping.model.DDMStructure','PERMISSIONS',4),(291,'com.liferay.portlet.dynamicdatamapping.model.DDMStructure','UPDATE',8),(292,'com.liferay.portlet.dynamicdatamapping.model.DDMStructure','VIEW',1),(293,'com.liferay.portlet.wiki.model.WikiPage','ADD_DISCUSSION',2),(294,'com.liferay.portlet.wiki.model.WikiPage','DELETE',4),(295,'com.liferay.portlet.wiki.model.WikiPage','DELETE_DISCUSSION',8),(296,'com.liferay.portlet.wiki.model.WikiPage','PERMISSIONS',16),(297,'com.liferay.portlet.wiki.model.WikiPage','SUBSCRIBE',32),(298,'com.liferay.portlet.wiki.model.WikiPage','UPDATE',64),(299,'com.liferay.portlet.wiki.model.WikiPage','UPDATE_DISCUSSION',128),(300,'com.liferay.portlet.wiki.model.WikiPage','VIEW',1),(301,'com.liferay.portlet.asset.model.AssetCategory','ADD_CATEGORY',2),(302,'com.liferay.portlet.asset.model.AssetCategory','DELETE',4),(303,'com.liferay.portlet.asset.model.AssetCategory','PERMISSIONS',8),(304,'com.liferay.portlet.asset.model.AssetCategory','UPDATE',16),(305,'com.liferay.portlet.asset.model.AssetCategory','VIEW',1),(306,'com.liferay.portlet.mobiledevicerules.model.MDRRuleGroup','DELETE',2),(307,'com.liferay.portlet.mobiledevicerules.model.MDRRuleGroup','PERMISSIONS',4),(308,'com.liferay.portlet.mobiledevicerules.model.MDRRuleGroup','UPDATE',8),(309,'com.liferay.portlet.mobiledevicerules.model.MDRRuleGroup','VIEW',1),(310,'com.liferay.portlet.messageboards.model.MBMessage','DELETE',2),(311,'com.liferay.portlet.messageboards.model.MBMessage','PERMISSIONS',4),(312,'com.liferay.portlet.messageboards.model.MBMessage','SUBSCRIBE',8),(313,'com.liferay.portlet.messageboards.model.MBMessage','UPDATE',16),(314,'com.liferay.portlet.messageboards.model.MBMessage','VIEW',1),(315,'com.liferay.portlet.messageboards.model.MBThread','SUBSCRIBE',2),(316,'com.liferay.portlet.messageboards.model.MBThread','PERMISSIONS',4),(317,'com.liferay.portlet.blogs','ADD_ENTRY',2),(318,'com.liferay.portlet.blogs','PERMISSIONS',4),(319,'com.liferay.portlet.blogs','SUBSCRIBE',8),(320,'com.liferay.portlet.documentlibrary.model.DLFileEntry','ADD_DISCUSSION',2),(321,'com.liferay.portlet.documentlibrary.model.DLFileEntry','DELETE',4),(322,'com.liferay.portlet.documentlibrary.model.DLFileEntry','DELETE_DISCUSSION',8),(323,'com.liferay.portlet.documentlibrary.model.DLFileEntry','PERMISSIONS',16),(324,'com.liferay.portlet.documentlibrary.model.DLFileEntry','UPDATE',32),(325,'com.liferay.portlet.documentlibrary.model.DLFileEntry','UPDATE_DISCUSSION',64),(326,'com.liferay.portlet.documentlibrary.model.DLFileEntry','VIEW',1),(327,'98','ACCESS_IN_CONTROL_PANEL',2),(328,'98','ADD_TO_PAGE',4),(329,'98','CONFIGURATION',8),(330,'98','VIEW',1),(331,'98','PERMISSIONS',16),(332,'66','VIEW',1),(333,'66','ADD_TO_PAGE',2),(334,'66','CONFIGURATION',4),(335,'66','PERMISSIONS',8),(336,'156','VIEW',1),(337,'156','ADD_TO_PAGE',2),(338,'156','ACCESS_IN_CONTROL_PANEL',4),(339,'156','CONFIGURATION',8),(340,'156','PERMISSIONS',16),(341,'180','VIEW',1),(342,'180','ADD_TO_PAGE',2),(343,'180','CONFIGURATION',4),(344,'180','PERMISSIONS',8),(345,'152','ACCESS_IN_CONTROL_PANEL',2),(346,'152','CONFIGURATION',4),(347,'152','VIEW',1),(348,'152','PERMISSIONS',8),(349,'27','VIEW',1),(350,'27','ADD_TO_PAGE',2),(351,'27','CONFIGURATION',4),(352,'27','PERMISSIONS',8),(353,'88','VIEW',1),(354,'88','ADD_TO_PAGE',2),(355,'88','CONFIGURATION',4),(356,'88','PERMISSIONS',8),(357,'87','VIEW',1),(358,'87','ADD_TO_PAGE',2),(359,'87','CONFIGURATION',4),(360,'87','PERMISSIONS',8),(361,'134','ACCESS_IN_CONTROL_PANEL',2),(362,'134','CONFIGURATION',4),(363,'134','VIEW',1),(364,'134','PERMISSIONS',8),(365,'130','ACCESS_IN_CONTROL_PANEL',2),(366,'130','CONFIGURATION',4),(367,'130','VIEW',1),(368,'130','PERMISSIONS',8),(369,'122','VIEW',1),(370,'122','ADD_TO_PAGE',2),(371,'122','CONFIGURATION',4),(372,'122','PERMISSIONS',8),(373,'36','ADD_TO_PAGE',2),(374,'36','CONFIGURATION',4),(375,'36','VIEW',1),(376,'36','PERMISSIONS',8),(377,'26','VIEW',1),(378,'26','ADD_TO_PAGE',2),(379,'26','CONFIGURATION',4),(380,'26','PERMISSIONS',8),(381,'104','VIEW',1),(382,'104','ADD_TO_PAGE',2),(383,'104','ACCESS_IN_CONTROL_PANEL',4),(384,'104','CONFIGURATION',8),(385,'104','PERMISSIONS',16),(386,'175','VIEW',1),(387,'175','ADD_TO_PAGE',2),(388,'175','CONFIGURATION',4),(389,'175','PERMISSIONS',8),(390,'64','VIEW',1),(391,'64','ADD_TO_PAGE',2),(392,'64','CONFIGURATION',4),(393,'64','PERMISSIONS',8),(394,'153','ACCESS_IN_CONTROL_PANEL',2),(395,'153','CONFIGURATION',4),(396,'153','VIEW',1),(397,'153','PERMISSIONS',8),(398,'129','ACCESS_IN_CONTROL_PANEL',2),(399,'129','CONFIGURATION',4),(400,'129','VIEW',1),(401,'129','PERMISSIONS',8),(402,'179','VIEW',1),(403,'179','ADD_TO_PAGE',2),(404,'179','ACCESS_IN_CONTROL_PANEL',4),(405,'179','CONFIGURATION',8),(406,'179','PERMISSIONS',16),(407,'173','VIEW',1),(408,'173','ADD_TO_PAGE',2),(409,'173','ACCESS_IN_CONTROL_PANEL',4),(410,'173','CONFIGURATION',8),(411,'173','PERMISSIONS',16),(412,'100','VIEW',1),(413,'100','ADD_TO_PAGE',2),(414,'100','CONFIGURATION',4),(415,'100','PERMISSIONS',8),(416,'157','ACCESS_IN_CONTROL_PANEL',2),(417,'157','CONFIGURATION',4),(418,'157','VIEW',1),(419,'157','PERMISSIONS',8),(420,'19','ADD_TO_PAGE',2),(421,'19','CONFIGURATION',4),(422,'19','VIEW',1),(423,'19','PERMISSIONS',8),(424,'160','VIEW',1),(425,'160','ADD_TO_PAGE',2),(426,'160','CONFIGURATION',4),(427,'160','PERMISSIONS',8),(428,'128','ACCESS_IN_CONTROL_PANEL',2),(429,'128','CONFIGURATION',4),(430,'128','VIEW',1),(431,'128','PERMISSIONS',8),(432,'181','VIEW',1),(433,'181','ADD_TO_PAGE',2),(434,'181','CONFIGURATION',4),(435,'181','PERMISSIONS',8),(436,'86','VIEW',1),(437,'86','ADD_TO_PAGE',2),(438,'86','CONFIGURATION',4),(439,'86','PERMISSIONS',8),(440,'154','ACCESS_IN_CONTROL_PANEL',2),(441,'154','CONFIGURATION',4),(442,'154','VIEW',1),(443,'154','PERMISSIONS',8),(444,'148','VIEW',1),(445,'148','ADD_TO_PAGE',2),(446,'148','CONFIGURATION',4),(447,'148','PERMISSIONS',8),(448,'11','ADD_TO_PAGE',2),(449,'11','CONFIGURATION',4),(450,'11','VIEW',1),(451,'11','PERMISSIONS',8),(452,'29','ADD_TO_PAGE',2),(453,'29','CONFIGURATION',4),(454,'29','VIEW',1),(455,'29','PERMISSIONS',8),(456,'174','VIEW',1),(457,'174','ADD_TO_PAGE',2),(458,'174','ACCESS_IN_CONTROL_PANEL',4),(459,'174','CONFIGURATION',8),(460,'174','PERMISSIONS',16),(461,'158','ACCESS_IN_CONTROL_PANEL',2),(462,'158','CONFIGURATION',4),(463,'158','VIEW',1),(464,'158','PERMISSIONS',8),(465,'178','VIEW',1),(466,'178','ADD_TO_PAGE',2),(467,'178','ACCESS_IN_CONTROL_PANEL',4),(468,'178','CONFIGURATION',8),(469,'178','PERMISSIONS',16),(470,'124','VIEW',1),(471,'124','ADD_TO_PAGE',2),(472,'124','CONFIGURATION',4),(473,'124','PERMISSIONS',8),(474,'8','ACCESS_IN_CONTROL_PANEL',2),(475,'8','ADD_TO_PAGE',4),(476,'8','CONFIGURATION',8),(477,'8','VIEW',1),(478,'8','PERMISSIONS',16),(479,'58','ADD_TO_PAGE',2),(480,'58','CONFIGURATION',4),(481,'58','VIEW',1),(482,'58','PERMISSIONS',8),(483,'97','VIEW',1),(484,'97','ADD_TO_PAGE',2),(485,'97','CONFIGURATION',4),(486,'97','PERMISSIONS',8),(487,'71','ADD_TO_PAGE',2),(488,'71','CONFIGURATION',4),(489,'71','VIEW',1),(490,'71','PERMISSIONS',8),(491,'39','VIEW',1),(492,'39','ADD_TO_PAGE',2),(493,'39','CONFIGURATION',4),(494,'39','PERMISSIONS',8),(495,'177','CONFIGURATION',2),(496,'177','VIEW',1),(497,'177','ADD_TO_PAGE',4),(498,'177','PERMISSIONS',8),(499,'177','ACCESS_IN_CONTROL_PANEL',16),(500,'170','VIEW',1),(501,'170','ADD_TO_PAGE',2),(502,'170','CONFIGURATION',4),(503,'170','PERMISSIONS',8),(504,'85','ADD_TO_PAGE',2),(505,'85','CONFIGURATION',4),(506,'85','VIEW',1),(507,'85','PERMISSIONS',8),(508,'118','VIEW',1),(509,'118','ADD_TO_PAGE',2),(510,'118','CONFIGURATION',4),(511,'118','PERMISSIONS',8),(512,'107','VIEW',1),(513,'107','ADD_TO_PAGE',2),(514,'107','CONFIGURATION',4),(515,'107','PERMISSIONS',8),(516,'30','VIEW',1),(517,'30','ADD_TO_PAGE',2),(518,'30','CONFIGURATION',4),(519,'30','PERMISSIONS',8),(520,'147','ACCESS_IN_CONTROL_PANEL',2),(521,'147','CONFIGURATION',4),(522,'147','VIEW',1),(523,'147','PERMISSIONS',8),(524,'48','VIEW',1),(525,'48','ADD_TO_PAGE',2),(526,'48','CONFIGURATION',4),(527,'48','PERMISSIONS',8),(528,'125','ACCESS_IN_CONTROL_PANEL',2),(529,'125','CONFIGURATION',4),(530,'125','EXPORT_USER',8),(531,'125','VIEW',1),(532,'125','PERMISSIONS',16),(533,'161','ACCESS_IN_CONTROL_PANEL',2),(534,'161','CONFIGURATION',4),(535,'161','VIEW',1),(536,'161','PERMISSIONS',8),(537,'144','VIEW',1),(538,'144','ADD_TO_PAGE',2),(539,'144','CONFIGURATION',4),(540,'144','PERMISSIONS',8),(541,'146','ACCESS_IN_CONTROL_PANEL',2),(542,'146','CONFIGURATION',4),(543,'146','VIEW',1),(544,'146','PERMISSIONS',8),(545,'62','VIEW',1),(546,'62','ADD_TO_PAGE',2),(547,'62','CONFIGURATION',4),(548,'62','PERMISSIONS',8),(549,'162','ACCESS_IN_CONTROL_PANEL',2),(550,'162','CONFIGURATION',4),(551,'162','VIEW',1),(552,'162','PERMISSIONS',8),(553,'176','VIEW',1),(554,'176','ADD_TO_PAGE',2),(555,'176','ACCESS_IN_CONTROL_PANEL',4),(556,'176','CONFIGURATION',8),(557,'176','PERMISSIONS',16),(558,'172','VIEW',1),(559,'172','ADD_TO_PAGE',2),(560,'172','CONFIGURATION',4),(561,'172','PERMISSIONS',8),(562,'108','VIEW',1),(563,'108','ADD_TO_PAGE',2),(564,'108','CONFIGURATION',4),(565,'108','PERMISSIONS',8),(566,'139','ACCESS_IN_CONTROL_PANEL',2),(567,'139','ADD_EXPANDO',4),(568,'139','CONFIGURATION',8),(569,'139','VIEW',1),(570,'139','PERMISSIONS',16),(571,'84','ADD_ENTRY',2),(572,'84','ADD_TO_PAGE',4),(573,'84','CONFIGURATION',8),(574,'84','VIEW',1),(575,'84','PERMISSIONS',16),(576,'101','VIEW',1),(577,'101','ADD_TO_PAGE',2),(578,'101','CONFIGURATION',4),(579,'101','PERMISSIONS',8),(580,'121','VIEW',1),(581,'121','ADD_TO_PAGE',2),(582,'121','CONFIGURATION',4),(583,'121','PERMISSIONS',8),(584,'49','VIEW',1),(585,'49','ADD_TO_PAGE',2),(586,'49','CONFIGURATION',4),(587,'49','PERMISSIONS',8),(588,'143','VIEW',1),(589,'143','ADD_TO_PAGE',2),(590,'143','CONFIGURATION',4),(591,'143','PERMISSIONS',8),(592,'167','ACCESS_IN_CONTROL_PANEL',2),(593,'167','ADD_TO_PAGE',4),(594,'167','CONFIGURATION',8),(595,'167','VIEW',1),(596,'167','PERMISSIONS',16),(597,'77','VIEW',1),(598,'77','ADD_TO_PAGE',2),(599,'77','CONFIGURATION',4),(600,'77','PERMISSIONS',8),(601,'115','VIEW',1),(602,'115','ADD_TO_PAGE',2),(603,'115','CONFIGURATION',4),(604,'115','PERMISSIONS',8),(605,'56','ADD_TO_PAGE',2),(606,'56','CONFIGURATION',4),(607,'56','VIEW',1),(608,'56','PERMISSIONS',8),(609,'142','VIEW',1),(610,'142','ADD_TO_PAGE',2),(611,'142','CONFIGURATION',4),(612,'142','PERMISSIONS',8),(613,'111','VIEW',1),(614,'111','ADD_TO_PAGE',2),(615,'111','CONFIGURATION',4),(616,'111','PERMISSIONS',8),(617,'16','PREFERENCES',2),(618,'16','GUEST_PREFERENCES',4),(619,'16','VIEW',1),(620,'16','ADD_TO_PAGE',8),(621,'16','CONFIGURATION',16),(622,'16','PERMISSIONS',32),(623,'3','VIEW',1),(624,'3','ADD_TO_PAGE',2),(625,'3','CONFIGURATION',4),(626,'3','PERMISSIONS',8),(627,'20','ACCESS_IN_CONTROL_PANEL',2),(628,'20','ADD_TO_PAGE',4),(629,'20','CONFIGURATION',8),(630,'20','VIEW',1),(631,'20','PERMISSIONS',16),(632,'23','VIEW',1),(633,'23','ADD_TO_PAGE',2),(634,'23','CONFIGURATION',4),(635,'23','PERMISSIONS',8),(636,'145','VIEW',1),(637,'145','ADD_TO_PAGE',2),(638,'145','CONFIGURATION',4),(639,'145','PERMISSIONS',8),(640,'83','ADD_ENTRY',2),(641,'83','ADD_TO_PAGE',4),(642,'83','CONFIGURATION',8),(643,'83','VIEW',1),(644,'83','PERMISSIONS',16),(645,'99','ACCESS_IN_CONTROL_PANEL',2),(646,'99','CONFIGURATION',4),(647,'99','VIEW',1),(648,'99','PERMISSIONS',8),(649,'70','VIEW',1),(650,'70','ADD_TO_PAGE',2),(651,'70','CONFIGURATION',4),(652,'70','PERMISSIONS',8),(653,'164','VIEW',1),(654,'164','ADD_TO_PAGE',2),(655,'164','CONFIGURATION',4),(656,'164','PERMISSIONS',8),(657,'141','VIEW',1),(658,'141','ADD_TO_PAGE',2),(659,'141','CONFIGURATION',4),(660,'141','PERMISSIONS',8),(661,'9','VIEW',1),(662,'9','ADD_TO_PAGE',2),(663,'9','CONFIGURATION',4),(664,'9','PERMISSIONS',8),(665,'137','ACCESS_IN_CONTROL_PANEL',2),(666,'137','CONFIGURATION',4),(667,'137','VIEW',1),(668,'137','PERMISSIONS',8),(669,'28','ACCESS_IN_CONTROL_PANEL',2),(670,'28','ADD_TO_PAGE',4),(671,'28','CONFIGURATION',8),(672,'28','VIEW',1),(673,'28','PERMISSIONS',16),(674,'133','VIEW',1),(675,'133','ADD_TO_PAGE',2),(676,'133','CONFIGURATION',4),(677,'133','PERMISSIONS',8),(678,'116','VIEW',1),(679,'116','ADD_TO_PAGE',2),(680,'116','CONFIGURATION',4),(681,'116','PERMISSIONS',8),(682,'15','ACCESS_IN_CONTROL_PANEL',2),(683,'15','ADD_TO_PAGE',4),(684,'15','CONFIGURATION',8),(685,'15','VIEW',1),(686,'15','PERMISSIONS',16),(687,'47','VIEW',1),(688,'47','ADD_TO_PAGE',2),(689,'47','CONFIGURATION',4),(690,'47','PERMISSIONS',8),(691,'82','VIEW',1),(692,'82','ADD_TO_PAGE',2),(693,'82','CONFIGURATION',4),(694,'82','PERMISSIONS',8),(695,'103','VIEW',1),(696,'103','ADD_TO_PAGE',2),(697,'103','CONFIGURATION',4),(698,'103','PERMISSIONS',8),(699,'151','ACCESS_IN_CONTROL_PANEL',2),(700,'151','CONFIGURATION',4),(701,'151','VIEW',1),(702,'151','PERMISSIONS',8),(703,'140','VIEW',1),(704,'140','ADD_TO_PAGE',2),(705,'140','ACCESS_IN_CONTROL_PANEL',4),(706,'140','CONFIGURATION',8),(707,'140','PERMISSIONS',16),(708,'54','VIEW',1),(709,'54','ADD_TO_PAGE',2),(710,'54','CONFIGURATION',4),(711,'54','PERMISSIONS',8),(712,'169','VIEW',1),(713,'169','ADD_TO_PAGE',2),(714,'169','CONFIGURATION',4),(715,'169','PERMISSIONS',8),(716,'132','ACCESS_IN_CONTROL_PANEL',2),(717,'132','CONFIGURATION',4),(718,'132','VIEW',1),(719,'132','PERMISSIONS',8),(720,'34','ADD_TO_PAGE',2),(721,'34','CONFIGURATION',4),(722,'34','VIEW',1),(723,'34','PERMISSIONS',8),(724,'61','VIEW',1),(725,'61','ADD_TO_PAGE',2),(726,'61','CONFIGURATION',4),(727,'61','PERMISSIONS',8),(728,'73','ADD_TO_PAGE',2),(729,'73','CONFIGURATION',4),(730,'73','VIEW',1),(731,'73','PERMISSIONS',8),(732,'31','VIEW',1),(733,'31','ADD_TO_PAGE',2),(734,'31','CONFIGURATION',4),(735,'31','PERMISSIONS',8),(736,'165','VIEW',1),(737,'165','ADD_TO_PAGE',2),(738,'165','ACCESS_IN_CONTROL_PANEL',4),(739,'165','CONFIGURATION',8),(740,'165','PERMISSIONS',16),(741,'136','ACCESS_IN_CONTROL_PANEL',2),(742,'136','CONFIGURATION',4),(743,'136','VIEW',1),(744,'136','PERMISSIONS',8),(745,'127','VIEW',1),(746,'127','ADD_TO_PAGE',2),(747,'127','ACCESS_IN_CONTROL_PANEL',4),(748,'127','CONFIGURATION',8),(749,'127','PERMISSIONS',16),(750,'50','VIEW',1),(751,'50','ADD_TO_PAGE',2),(752,'50','CONFIGURATION',4),(753,'50','PERMISSIONS',8),(754,'25','ACCESS_IN_CONTROL_PANEL',2),(755,'25','CONFIGURATION',4),(756,'25','VIEW',1),(757,'25','PERMISSIONS',8),(758,'166','ACCESS_IN_CONTROL_PANEL',2),(759,'166','ADD_TO_PAGE',4),(760,'166','CONFIGURATION',8),(761,'166','VIEW',1),(762,'166','PERMISSIONS',16),(763,'90','ADD_COMMUNITY',2),(764,'90','ADD_LAYOUT_PROTOTYPE',4),(765,'90','ADD_LAYOUT_SET_PROTOTYPE',8),(766,'90','ADD_LICENSE',16),(767,'90','ADD_ORGANIZATION',32),(768,'90','ADD_PASSWORD_POLICY',64),(769,'90','ADD_ROLE',128),(770,'90','ADD_USER',256),(771,'90','ADD_USER_GROUP',512),(772,'90','CONFIGURATION',1024),(773,'90','EXPORT_USER',2048),(774,'90','UNLINK_LAYOUT_SET_PROTOTYPE',4096),(775,'90','VIEW_CONTROL_PANEL',8192),(776,'90','ADD_TO_PAGE',16384),(777,'90','PERMISSIONS',32768),(778,'90','VIEW',1),(779,'150','ACCESS_IN_CONTROL_PANEL',2),(780,'150','CONFIGURATION',4),(781,'150','VIEW',1),(782,'150','PERMISSIONS',8),(783,'113','VIEW',1),(784,'113','ADD_TO_PAGE',2),(785,'113','CONFIGURATION',4),(786,'113','PERMISSIONS',8),(787,'33','ADD_TO_PAGE',2),(788,'33','CONFIGURATION',4),(789,'33','VIEW',1),(790,'33','PERMISSIONS',8),(791,'2','VIEW',1),(792,'2','ADD_TO_PAGE',2),(793,'2','ACCESS_IN_CONTROL_PANEL',4),(794,'2','CONFIGURATION',8),(795,'2','PERMISSIONS',16),(796,'119','VIEW',1),(797,'119','ADD_TO_PAGE',2),(798,'119','CONFIGURATION',4),(799,'119','PERMISSIONS',8),(800,'114','VIEW',1),(801,'114','ADD_TO_PAGE',2),(802,'114','CONFIGURATION',4),(803,'114','PERMISSIONS',8),(804,'149','ACCESS_IN_CONTROL_PANEL',2),(805,'149','CONFIGURATION',4),(806,'149','VIEW',1),(807,'149','PERMISSIONS',8),(808,'67','VIEW',1),(809,'67','ADD_TO_PAGE',2),(810,'67','CONFIGURATION',4),(811,'67','PERMISSIONS',8),(812,'110','VIEW',1),(813,'110','ADD_TO_PAGE',2),(814,'110','CONFIGURATION',4),(815,'110','PERMISSIONS',8),(816,'135','ACCESS_IN_CONTROL_PANEL',2),(817,'135','CONFIGURATION',4),(818,'135','VIEW',1),(819,'135','PERMISSIONS',8),(820,'59','VIEW',1),(821,'59','ADD_TO_PAGE',2),(822,'59','CONFIGURATION',4),(823,'59','PERMISSIONS',8),(824,'131','ACCESS_IN_CONTROL_PANEL',2),(825,'131','CONFIGURATION',4),(826,'131','VIEW',1),(827,'131','PERMISSIONS',8),(828,'102','VIEW',1),(829,'102','ADD_TO_PAGE',2),(830,'102','CONFIGURATION',4),(831,'102','PERMISSIONS',8),(901,'1_WAR_quartzupgradeportlet','VIEW',1),(902,'1_WAR_quartzupgradeportlet','ADD_TO_PAGE',2),(903,'1_WAR_quartzupgradeportlet','CONFIGURATION',4),(904,'1_WAR_quartzupgradeportlet','PERMISSIONS',8);
/*!40000 ALTER TABLE `ResourceAction` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ResourceBlock`
--

DROP TABLE IF EXISTS `ResourceBlock`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ResourceBlock` (
  `resourceBlockId` bigint(20) NOT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `groupId` bigint(20) DEFAULT NULL,
  `name` varchar(75) DEFAULT NULL,
  `permissionsHash` varchar(75) DEFAULT NULL,
  `referenceCount` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`resourceBlockId`),
  UNIQUE KEY `IX_AEEA209C` (`companyId`,`groupId`,`name`,`permissionsHash`),
  KEY `IX_DA30B086` (`companyId`,`groupId`,`name`),
  KEY `IX_2D4CC782` (`companyId`,`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ResourceBlock`
--

LOCK TABLES `ResourceBlock` WRITE;
/*!40000 ALTER TABLE `ResourceBlock` DISABLE KEYS */;
INSERT INTO `ResourceBlock` VALUES (3,10154,10180,'com.liferay.portlet.bookmarks.model.BookmarksEntry','2d488243dc82ff6c4e99e796fbbfb70003512f5a',1),(6,10154,10180,'com.liferay.portlet.bookmarks.model.BookmarksFolder','1681650c00ca338ab389d9f361c899d718cf0606',1);
/*!40000 ALTER TABLE `ResourceBlock` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ResourceBlockPermission`
--

DROP TABLE IF EXISTS `ResourceBlockPermission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ResourceBlockPermission` (
  `resourceBlockPermissionId` bigint(20) NOT NULL,
  `resourceBlockId` bigint(20) DEFAULT NULL,
  `roleId` bigint(20) DEFAULT NULL,
  `actionIds` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`resourceBlockPermissionId`),
  UNIQUE KEY `IX_D63D20BB` (`resourceBlockId`,`roleId`),
  KEY `IX_4AB3756` (`resourceBlockId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ResourceBlockPermission`
--

LOCK TABLES `ResourceBlockPermission` WRITE;
/*!40000 ALTER TABLE `ResourceBlockPermission` DISABLE KEYS */;
INSERT INTO `ResourceBlockPermission` VALUES (10750,3,10162,1),(10751,3,10163,15),(10752,3,10170,1),(10758,6,10162,1),(10759,6,10163,127),(10760,6,10170,5);
/*!40000 ALTER TABLE `ResourceBlockPermission` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ResourceCode`
--

DROP TABLE IF EXISTS `ResourceCode`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ResourceCode` (
  `codeId` bigint(20) NOT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `scope` int(11) DEFAULT NULL,
  PRIMARY KEY (`codeId`),
  UNIQUE KEY `IX_A32C097E` (`companyId`,`name`,`scope`),
  KEY `IX_717FDD47` (`companyId`),
  KEY `IX_AACAFF40` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ResourceCode`
--

LOCK TABLES `ResourceCode` WRITE;
/*!40000 ALTER TABLE `ResourceCode` DISABLE KEYS */;
/*!40000 ALTER TABLE `ResourceCode` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ResourcePermission`
--

DROP TABLE IF EXISTS `ResourcePermission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ResourcePermission` (
  `resourcePermissionId` bigint(20) NOT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `scope` int(11) DEFAULT NULL,
  `primKey` varchar(255) DEFAULT NULL,
  `roleId` bigint(20) DEFAULT NULL,
  `ownerId` bigint(20) DEFAULT NULL,
  `actionIds` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`resourcePermissionId`),
  KEY `IX_88705859` (`companyId`,`name`,`primKey`,`ownerId`),
  KEY `IX_C94C7708` (`companyId`,`name`,`primKey`,`roleId`,`actionIds`),
  KEY `IX_60B99860` (`companyId`,`name`,`scope`),
  KEY `IX_2200AA69` (`companyId`,`name`,`scope`,`primKey`),
  KEY `IX_8D83D0CE` (`companyId`,`name`,`scope`,`primKey`,`roleId`),
  KEY `IX_D2E2B644` (`companyId`,`name`,`scope`,`primKey`,`roleId`,`actionIds`),
  KEY `IX_4A1F4402` (`companyId`,`name`,`scope`,`primKey`,`roleId`,`ownerId`,`actionIds`),
  KEY `IX_26284944` (`companyId`,`primKey`),
  KEY `IX_A37A0588` (`roleId`),
  KEY `IX_F4555981` (`scope`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ResourcePermission`
--

LOCK TABLES `ResourcePermission` WRITE;
/*!40000 ALTER TABLE `ResourcePermission` DISABLE KEYS */;
INSERT INTO `ResourcePermission` VALUES (161,10154,'100',1,'10154',10164,0,2),(162,10154,'100',1,'10154',10165,0,2),(27,10154,'100',2,'10189',10165,0,1),(210,10154,'101',1,'10154',10162,0,2),(211,10154,'101',1,'10154',10164,0,2),(212,10154,'101',1,'10154',10165,0,2),(58,10154,'101',2,'10189',10165,0,1),(340,10154,'101',4,'10323_LAYOUT_101_INSTANCE_W5RTN7RddrzG',10162,0,1),(338,10154,'101',4,'10323_LAYOUT_101_INSTANCE_W5RTN7RddrzG',10163,0,15),(339,10154,'101',4,'10323_LAYOUT_101_INSTANCE_W5RTN7RddrzG',10170,0,1),(717,10154,'101',4,'10765_LAYOUT_101_INSTANCE_U6JjXcjOEdCZ',10162,0,1),(715,10154,'101',4,'10765_LAYOUT_101_INSTANCE_U6JjXcjOEdCZ',10163,0,15),(716,10154,'101',4,'10765_LAYOUT_101_INSTANCE_U6JjXcjOEdCZ',10170,0,1),(929,10154,'101',4,'10914_LAYOUT_101_INSTANCE_H0n9dLx4hP21',10162,0,1),(927,10154,'101',4,'10914_LAYOUT_101_INSTANCE_H0n9dLx4hP21',10163,0,15),(928,10154,'101',4,'10914_LAYOUT_101_INSTANCE_H0n9dLx4hP21',10170,0,1),(941,10154,'101',4,'10941_LAYOUT_101_INSTANCE_H0n9dLx4hP21',10162,0,1),(942,10154,'101',4,'10941_LAYOUT_101_INSTANCE_H0n9dLx4hP21',10163,0,15),(943,10154,'101',4,'10941_LAYOUT_101_INSTANCE_H0n9dLx4hP21',10170,0,1),(966,10154,'101',4,'10955_LAYOUT_101_INSTANCE_H0n9dLx4hP21',10162,0,1),(964,10154,'101',4,'10955_LAYOUT_101_INSTANCE_H0n9dLx4hP21',10163,0,15),(965,10154,'101',4,'10955_LAYOUT_101_INSTANCE_H0n9dLx4hP21',10170,0,1),(297,10154,'102',1,'10154',10162,0,2),(298,10154,'102',1,'10154',10164,0,2),(299,10154,'102',1,'10154',10165,0,2),(104,10154,'102',2,'10189',10165,0,1),(391,10154,'103',4,'10183_LAYOUT_103',10162,0,1),(389,10154,'103',4,'10183_LAYOUT_103',10163,0,15),(390,10154,'103',4,'10183_LAYOUT_103',10170,0,1),(410,10154,'103',4,'10424_LAYOUT_103',10162,0,1),(408,10154,'103',4,'10424_LAYOUT_103',10163,0,15),(409,10154,'103',4,'10424_LAYOUT_103',10170,0,1),(453,10154,'103',4,'10472_LAYOUT_103',10162,0,1),(451,10154,'103',4,'10472_LAYOUT_103',10163,0,15),(452,10154,'103',4,'10472_LAYOUT_103',10170,0,1),(487,10154,'103',4,'10498_LAYOUT_103',10162,0,1),(485,10154,'103',4,'10498_LAYOUT_103',10163,0,15),(486,10154,'103',4,'10498_LAYOUT_103',10170,0,1),(518,10154,'103',4,'10526_LAYOUT_103',10162,0,1),(516,10154,'103',4,'10526_LAYOUT_103',10163,0,15),(517,10154,'103',4,'10526_LAYOUT_103',10170,0,1),(549,10154,'103',4,'10561_LAYOUT_103',10162,0,1),(547,10154,'103',4,'10561_LAYOUT_103',10163,0,15),(548,10154,'103',4,'10561_LAYOUT_103',10170,0,1),(604,10154,'103',4,'10627_LAYOUT_103',10162,0,1),(602,10154,'103',4,'10627_LAYOUT_103',10163,0,15),(603,10154,'103',4,'10627_LAYOUT_103',10170,0,1),(631,10154,'103',4,'10659_LAYOUT_103',10162,0,1),(629,10154,'103',4,'10659_LAYOUT_103',10163,0,15),(630,10154,'103',4,'10659_LAYOUT_103',10164,0,1),(665,10154,'103',4,'10706_LAYOUT_103',10162,0,1),(663,10154,'103',4,'10706_LAYOUT_103',10163,0,15),(664,10154,'103',4,'10706_LAYOUT_103',10170,0,1),(689,10154,'103',4,'10737_LAYOUT_103',10162,0,1),(687,10154,'103',4,'10737_LAYOUT_103',10163,0,15),(688,10154,'103',4,'10737_LAYOUT_103',10170,0,1),(708,10154,'103',4,'10765_LAYOUT_103',10162,0,1),(706,10154,'103',4,'10765_LAYOUT_103',10163,0,15),(707,10154,'103',4,'10765_LAYOUT_103',10170,0,1),(734,10154,'103',4,'10782_LAYOUT_103',10162,0,1),(732,10154,'103',4,'10782_LAYOUT_103',10163,0,15),(733,10154,'103',4,'10782_LAYOUT_103',10170,0,1),(765,10154,'103',4,'10821_LAYOUT_103',10162,0,1),(763,10154,'103',4,'10821_LAYOUT_103',10163,0,15),(764,10154,'103',4,'10821_LAYOUT_103',10170,0,1),(784,10154,'103',4,'10832_LAYOUT_103',10162,0,1),(782,10154,'103',4,'10832_LAYOUT_103',10163,0,15),(783,10154,'103',4,'10832_LAYOUT_103',10170,0,1),(813,10154,'103',4,'10861_LAYOUT_103',10162,0,1),(811,10154,'103',4,'10861_LAYOUT_103',10163,0,15),(812,10154,'103',4,'10861_LAYOUT_103',10170,0,1),(914,10154,'103',4,'10906_LAYOUT_103',10162,0,1),(912,10154,'103',4,'10906_LAYOUT_103',10163,0,15),(913,10154,'103',4,'10906_LAYOUT_103',10170,0,1),(923,10154,'103',4,'10914_LAYOUT_103',10162,0,1),(921,10154,'103',4,'10914_LAYOUT_103',10163,0,15),(922,10154,'103',4,'10914_LAYOUT_103',10170,0,1),(1003,10154,'103',4,'10940_LAYOUT_103',10162,0,1),(1001,10154,'103',4,'10940_LAYOUT_103',10163,0,15),(1002,10154,'103',4,'10940_LAYOUT_103',10170,0,1),(1009,10154,'103',4,'10941_LAYOUT_103',10162,0,1),(1007,10154,'103',4,'10941_LAYOUT_103',10163,0,15),(1008,10154,'103',4,'10941_LAYOUT_103',10170,0,1),(957,10154,'103',4,'10954_LAYOUT_103',10162,0,1),(955,10154,'103',4,'10954_LAYOUT_103',10163,0,15),(956,10154,'103',4,'10954_LAYOUT_103',10170,0,1),(963,10154,'103',4,'10955_LAYOUT_103',10162,0,1),(961,10154,'103',4,'10955_LAYOUT_103',10163,0,15),(962,10154,'103',4,'10955_LAYOUT_103',10170,0,1),(150,10154,'104',1,'10154',10161,0,2),(20,10154,'104',2,'10189',10165,0,1),(197,10154,'107',1,'10154',10164,0,2),(198,10154,'107',1,'10154',10165,0,2),(46,10154,'107',2,'10189',10165,0,1),(206,10154,'108',1,'10154',10164,0,2),(207,10154,'108',1,'10154',10165,0,2),(56,10154,'108',2,'10189',10165,0,1),(171,10154,'11',1,'10154',10164,0,2),(172,10154,'11',1,'10154',10165,0,2),(34,10154,'11',2,'10189',10165,0,1),(632,10154,'11',4,'10659_LAYOUT_11',10163,0,15),(293,10154,'110',1,'10154',10164,0,2),(294,10154,'110',1,'10154',10165,0,2),(100,10154,'110',2,'10189',10165,0,1),(232,10154,'111',1,'10154',10161,0,2),(66,10154,'111',2,'10189',10165,0,1),(288,10154,'114',1,'10154',10162,0,2),(289,10154,'114',1,'10154',10164,0,2),(290,10154,'114',1,'10154',10165,0,2),(97,10154,'114',2,'10189',10165,0,1),(325,10154,'114',4,'10313_LAYOUT_114',10162,0,1),(323,10154,'114',4,'10313_LAYOUT_114',10163,0,15),(324,10154,'114',4,'10313_LAYOUT_114',10170,0,1),(224,10154,'115',1,'10154',10162,0,2),(225,10154,'115',1,'10154',10164,0,2),(226,10154,'115',1,'10154',10165,0,2),(63,10154,'115',2,'10189',10165,0,1),(259,10154,'116',1,'10154',10162,0,2),(260,10154,'116',1,'10154',10164,0,2),(261,10154,'116',1,'10154',10165,0,2),(80,10154,'116',2,'10189',10165,0,1),(194,10154,'118',1,'10154',10162,0,2),(195,10154,'118',1,'10154',10164,0,2),(196,10154,'118',1,'10154',10165,0,2),(45,10154,'118',2,'10189',10165,0,1),(213,10154,'121',1,'10154',10162,0,2),(214,10154,'121',1,'10154',10164,0,2),(215,10154,'121',1,'10154',10165,0,2),(59,10154,'121',2,'10189',10165,0,1),(143,10154,'122',1,'10154',10162,0,2),(144,10154,'122',1,'10154',10164,0,2),(145,10154,'122',1,'10154',10165,0,2),(17,10154,'122',2,'10189',10165,0,1),(334,10154,'122',4,'10323_LAYOUT_122_INSTANCE_B10hMf3MF3IL',10162,0,1),(332,10154,'122',4,'10323_LAYOUT_122_INSTANCE_B10hMf3MF3IL',10163,0,15),(333,10154,'122',4,'10323_LAYOUT_122_INSTANCE_B10hMf3MF3IL',10170,0,1),(350,10154,'122',4,'10332_LAYOUT_122_INSTANCE_rh1044zpsuXg',10162,0,1),(348,10154,'122',4,'10332_LAYOUT_122_INSTANCE_rh1044zpsuXg',10163,0,15),(349,10154,'122',4,'10332_LAYOUT_122_INSTANCE_rh1044zpsuXg',10170,0,1),(50,10154,'125',2,'10189',10165,0,1),(442,10154,'125',4,'10175_LAYOUT_125',10162,0,1),(440,10154,'125',4,'10175_LAYOUT_125',10163,0,31),(441,10154,'125',4,'10175_LAYOUT_125',10170,0,1),(282,10154,'127',1,'10154',10161,0,2),(92,10154,'127',2,'10189',10165,0,1),(30,10154,'128',2,'10189',10165,0,1),(437,10154,'128',4,'10175_LAYOUT_128',10162,0,1),(435,10154,'128',4,'10175_LAYOUT_128',10163,0,15),(436,10154,'128',4,'10175_LAYOUT_128',10170,0,1),(24,10154,'129',2,'10189',10165,0,1),(589,10154,'129',4,'10175_LAYOUT_129',10162,0,1),(587,10154,'129',4,'10175_LAYOUT_129',10163,0,15),(588,10154,'129',4,'10175_LAYOUT_129',10170,0,1),(16,10154,'130',2,'10189',10165,0,1),(103,10154,'131',2,'10189',10165,0,1),(86,10154,'132',2,'10189',10165,0,1),(752,10154,'132',4,'10175_LAYOUT_132',10162,0,1),(750,10154,'132',4,'10175_LAYOUT_132',10163,0,15),(751,10154,'132',4,'10175_LAYOUT_132',10170,0,1),(15,10154,'134',2,'10189',10165,0,1),(433,10154,'134',4,'10175_LAYOUT_134',10162,0,1),(431,10154,'134',4,'10175_LAYOUT_134',10163,0,15),(432,10154,'134',4,'10175_LAYOUT_134',10170,0,1),(102,10154,'135',2,'10189',10165,0,1),(90,10154,'136',2,'10189',10165,0,1),(77,10154,'137',2,'10189',10165,0,1),(797,10154,'139',4,'10175_LAYOUT_139',10163,0,31),(248,10154,'141',1,'10154',10162,0,2),(249,10154,'141',1,'10154',10164,0,2),(250,10154,'141',1,'10154',10165,0,2),(74,10154,'141',2,'10189',10165,0,1),(331,10154,'141',4,'10323_LAYOUT_141_INSTANCE_JpyReXKz8j1h',10162,0,1),(329,10154,'141',4,'10323_LAYOUT_141_INSTANCE_JpyReXKz8j1h',10163,0,15),(330,10154,'141',4,'10323_LAYOUT_141_INSTANCE_JpyReXKz8j1h',10170,0,1),(353,10154,'141',4,'10332_LAYOUT_141_INSTANCE_qDRgg008E4yU',10162,0,1),(351,10154,'141',4,'10332_LAYOUT_141_INSTANCE_qDRgg008E4yU',10163,0,15),(352,10154,'141',4,'10332_LAYOUT_141_INSTANCE_qDRgg008E4yU',10170,0,1),(216,10154,'143',1,'10154',10162,0,2),(217,10154,'143',1,'10154',10164,0,2),(218,10154,'143',1,'10154',10165,0,2),(60,10154,'143',2,'10189',10165,0,1),(430,10154,'145',4,'10175_LAYOUT_145',10162,0,1),(428,10154,'145',4,'10175_LAYOUT_145',10163,0,15),(429,10154,'145',4,'10175_LAYOUT_145',10170,0,1),(404,10154,'145',4,'10183_LAYOUT_145',10162,0,1),(402,10154,'145',4,'10183_LAYOUT_145',10163,0,15),(403,10154,'145',4,'10183_LAYOUT_145',10170,0,1),(413,10154,'145',4,'10424_LAYOUT_145',10162,0,1),(411,10154,'145',4,'10424_LAYOUT_145',10163,0,15),(412,10154,'145',4,'10424_LAYOUT_145',10170,0,1),(456,10154,'145',4,'10472_LAYOUT_145',10162,0,1),(454,10154,'145',4,'10472_LAYOUT_145',10163,0,15),(455,10154,'145',4,'10472_LAYOUT_145',10170,0,1),(490,10154,'145',4,'10498_LAYOUT_145',10162,0,1),(488,10154,'145',4,'10498_LAYOUT_145',10163,0,15),(489,10154,'145',4,'10498_LAYOUT_145',10170,0,1),(521,10154,'145',4,'10526_LAYOUT_145',10162,0,1),(519,10154,'145',4,'10526_LAYOUT_145',10163,0,15),(520,10154,'145',4,'10526_LAYOUT_145',10170,0,1),(552,10154,'145',4,'10561_LAYOUT_145',10162,0,1),(550,10154,'145',4,'10561_LAYOUT_145',10163,0,15),(551,10154,'145',4,'10561_LAYOUT_145',10170,0,1),(607,10154,'145',4,'10627_LAYOUT_145',10162,0,1),(605,10154,'145',4,'10627_LAYOUT_145',10163,0,15),(606,10154,'145',4,'10627_LAYOUT_145',10170,0,1),(648,10154,'145',4,'10659_LAYOUT_145',10162,0,1),(646,10154,'145',4,'10659_LAYOUT_145',10163,0,15),(647,10154,'145',4,'10659_LAYOUT_145',10164,0,1),(668,10154,'145',4,'10706_LAYOUT_145',10162,0,1),(666,10154,'145',4,'10706_LAYOUT_145',10163,0,15),(667,10154,'145',4,'10706_LAYOUT_145',10170,0,1),(692,10154,'145',4,'10737_LAYOUT_145',10162,0,1),(690,10154,'145',4,'10737_LAYOUT_145',10163,0,15),(691,10154,'145',4,'10737_LAYOUT_145',10170,0,1),(711,10154,'145',4,'10765_LAYOUT_145',10162,0,1),(709,10154,'145',4,'10765_LAYOUT_145',10163,0,15),(710,10154,'145',4,'10765_LAYOUT_145',10170,0,1),(737,10154,'145',4,'10782_LAYOUT_145',10162,0,1),(735,10154,'145',4,'10782_LAYOUT_145',10163,0,15),(736,10154,'145',4,'10782_LAYOUT_145',10170,0,1),(768,10154,'145',4,'10821_LAYOUT_145',10162,0,1),(766,10154,'145',4,'10821_LAYOUT_145',10163,0,15),(767,10154,'145',4,'10821_LAYOUT_145',10170,0,1),(787,10154,'145',4,'10832_LAYOUT_145',10162,0,1),(785,10154,'145',4,'10832_LAYOUT_145',10163,0,15),(786,10154,'145',4,'10832_LAYOUT_145',10170,0,1),(816,10154,'145',4,'10861_LAYOUT_145',10162,0,1),(814,10154,'145',4,'10861_LAYOUT_145',10163,0,15),(815,10154,'145',4,'10861_LAYOUT_145',10170,0,1),(917,10154,'145',4,'10906_LAYOUT_145',10162,0,1),(915,10154,'145',4,'10906_LAYOUT_145',10163,0,15),(916,10154,'145',4,'10906_LAYOUT_145',10170,0,1),(926,10154,'145',4,'10914_LAYOUT_145',10162,0,1),(924,10154,'145',4,'10914_LAYOUT_145',10163,0,15),(925,10154,'145',4,'10914_LAYOUT_145',10170,0,1),(1006,10154,'145',4,'10940_LAYOUT_145',10162,0,1),(1004,10154,'145',4,'10940_LAYOUT_145',10163,0,15),(1005,10154,'145',4,'10940_LAYOUT_145',10170,0,1),(1012,10154,'145',4,'10941_LAYOUT_145',10162,0,1),(1010,10154,'145',4,'10941_LAYOUT_145',10163,0,15),(1011,10154,'145',4,'10941_LAYOUT_145',10170,0,1),(960,10154,'145',4,'10954_LAYOUT_145',10162,0,1),(958,10154,'145',4,'10954_LAYOUT_145',10163,0,15),(959,10154,'145',4,'10954_LAYOUT_145',10170,0,1),(969,10154,'145',4,'10955_LAYOUT_145',10162,0,1),(967,10154,'145',4,'10955_LAYOUT_145',10163,0,15),(968,10154,'145',4,'10955_LAYOUT_145',10170,0,1),(52,10154,'146',2,'10189',10165,0,1),(536,10154,'146',4,'10175_LAYOUT_146',10162,0,1),(534,10154,'146',4,'10175_LAYOUT_146',10163,0,15),(535,10154,'146',4,'10175_LAYOUT_146',10170,0,1),(115,10154,'147',2,'10189',10164,0,2),(48,10154,'147',2,'10189',10165,0,1),(168,10154,'148',1,'10154',10162,0,2),(169,10154,'148',1,'10154',10164,0,2),(170,10154,'148',1,'10154',10165,0,2),(33,10154,'148',2,'10189',10165,0,1),(322,10154,'148',4,'10313_LAYOUT_148_INSTANCE_f17fUnsqGfzI',10162,0,1),(320,10154,'148',4,'10313_LAYOUT_148_INSTANCE_f17fUnsqGfzI',10163,0,15),(321,10154,'148',4,'10313_LAYOUT_148_INSTANCE_f17fUnsqGfzI',10170,0,1),(98,10154,'149',2,'10189',10165,0,1),(582,10154,'149',4,'10175_LAYOUT_149',10162,0,1),(580,10154,'149',4,'10175_LAYOUT_149',10163,0,15),(581,10154,'149',4,'10175_LAYOUT_149',10170,0,1),(257,10154,'15',1,'10154',10164,0,4),(258,10154,'15',1,'10154',10165,0,4),(122,10154,'15',2,'10189',10164,0,2),(79,10154,'15',2,'10189',10165,0,1),(506,10154,'15',4,'10175_LAYOUT_15',10162,0,1),(504,10154,'15',4,'10175_LAYOUT_15',10163,0,31),(505,10154,'15',4,'10175_LAYOUT_15',10170,0,1),(96,10154,'150',2,'10189',10165,0,1),(82,10154,'151',2,'10189',10165,0,1),(109,10154,'152',2,'10189',10164,0,2),(14,10154,'152',2,'10189',10165,0,1),(1,10154,'153',1,'10154',10165,0,2),(22,10154,'153',2,'10189',10165,0,1),(112,10154,'154',2,'10189',10164,0,2),(32,10154,'154',2,'10189',10165,0,1),(471,10154,'154',4,'10175_LAYOUT_154',10163,0,15),(447,10154,'156',4,'10175_LAYOUT_156',10162,0,1),(445,10154,'156',4,'10175_LAYOUT_156',10163,0,31),(446,10154,'156',4,'10175_LAYOUT_156',10170,0,1),(29,10154,'157',2,'10189',10165,0,1),(2,10154,'158',1,'10154',10165,0,2),(36,10154,'158',2,'10189',10165,0,1),(230,10154,'16',1,'10154',10164,0,8),(231,10154,'16',1,'10154',10165,0,8),(65,10154,'16',2,'10189',10165,0,1),(427,10154,'160',4,'10175_LAYOUT_160',10162,0,1),(425,10154,'160',4,'10175_LAYOUT_160',10163,0,15),(426,10154,'160',4,'10175_LAYOUT_160',10170,0,1),(116,10154,'161',2,'10189',10164,0,2),(51,10154,'161',2,'10189',10165,0,1),(533,10154,'161',4,'10175_LAYOUT_161',10162,0,1),(531,10154,'161',4,'10175_LAYOUT_161',10163,0,15),(532,10154,'161',4,'10175_LAYOUT_161',10170,0,1),(117,10154,'162',2,'10189',10164,0,2),(54,10154,'162',2,'10189',10165,0,1),(243,10154,'164',1,'10154',10162,0,2),(244,10154,'164',1,'10154',10164,0,2),(245,10154,'164',1,'10154',10165,0,2),(71,10154,'164',2,'10189',10165,0,1),(598,10154,'165',4,'10175_LAYOUT_165',10162,0,1),(596,10154,'165',4,'10175_LAYOUT_165',10163,0,31),(597,10154,'165',4,'10175_LAYOUT_165',10170,0,1),(283,10154,'166',1,'10154',10164,0,4),(284,10154,'166',1,'10154',10165,0,4),(94,10154,'166',2,'10189',10165,0,1),(568,10154,'166',4,'10175_LAYOUT_166',10162,0,1),(566,10154,'166',4,'10175_LAYOUT_166',10163,0,31),(567,10154,'166',4,'10175_LAYOUT_166',10170,0,1),(575,10154,'166',4,'10561_LAYOUT_166',10162,0,1),(573,10154,'166',4,'10561_LAYOUT_166',10163,0,31),(574,10154,'166',4,'10561_LAYOUT_166',10170,0,1),(222,10154,'167',1,'10154',10164,0,4),(223,10154,'167',1,'10154',10165,0,4),(118,10154,'167',2,'10189',10164,0,2),(62,10154,'167',2,'10189',10165,0,1),(564,10154,'167',4,'10175_LAYOUT_167',10162,0,1),(562,10154,'167',4,'10175_LAYOUT_167',10163,0,31),(563,10154,'167',4,'10175_LAYOUT_167',10170,0,1),(572,10154,'167',4,'10561_LAYOUT_167',10162,0,1),(570,10154,'167',4,'10561_LAYOUT_167',10163,0,31),(571,10154,'167',4,'10561_LAYOUT_167',10170,0,1),(269,10154,'169',1,'10154',10164,0,2),(270,10154,'169',1,'10154',10165,0,2),(85,10154,'169',2,'10189',10165,0,1),(558,10154,'169',4,'10561_LAYOUT_169_INSTANCE_Xc3UrpdLcuH0',10162,0,1),(556,10154,'169',4,'10561_LAYOUT_169_INSTANCE_Xc3UrpdLcuH0',10163,0,15),(557,10154,'169',4,'10561_LAYOUT_169_INSTANCE_Xc3UrpdLcuH0',10170,0,1),(671,10154,'170',4,'10706_LAYOUT_170',10162,0,1),(669,10154,'170',4,'10706_LAYOUT_170',10163,0,15),(670,10154,'170',4,'10706_LAYOUT_170',10170,0,1),(158,10154,'173',1,'10154',10162,0,2),(159,10154,'173',1,'10154',10164,0,2),(160,10154,'173',1,'10154',10165,0,2),(111,10154,'173',2,'10189',10164,0,4),(26,10154,'173',2,'10189',10165,0,1),(151,10154,'175',1,'10154',10162,0,2),(152,10154,'175',1,'10154',10164,0,2),(153,10154,'175',1,'10154',10165,0,2),(21,10154,'175',2,'10189',10165,0,1),(205,10154,'176',1,'10154',10161,0,2),(55,10154,'176',2,'10189',10165,0,1),(189,10154,'177',1,'10154',10164,0,4),(190,10154,'177',1,'10154',10165,0,4),(43,10154,'177',2,'10189',10165,0,1),(175,10154,'178',1,'10154',10164,0,2),(176,10154,'178',1,'10154',10165,0,2),(113,10154,'178',2,'10189',10164,0,4),(37,10154,'178',2,'10189',10165,0,1),(759,10154,'178',4,'10175_LAYOUT_178',10162,0,1),(757,10154,'178',4,'10175_LAYOUT_178',10163,0,31),(758,10154,'178',4,'10175_LAYOUT_178',10170,0,1),(157,10154,'179',1,'10154',10161,0,2),(110,10154,'179',2,'10189',10164,0,4),(25,10154,'179',2,'10189',10165,0,1),(530,10154,'179',4,'10175_LAYOUT_179',10162,0,1),(528,10154,'179',4,'10175_LAYOUT_179',10163,0,31),(529,10154,'179',4,'10175_LAYOUT_179',10170,0,1),(138,10154,'180',1,'10154',10162,0,2),(139,10154,'180',1,'10154',10164,0,2),(140,10154,'180',1,'10154',10165,0,2),(12,10154,'180',2,'10189',10165,0,1),(165,10154,'181',1,'10154',10162,0,2),(166,10154,'181',1,'10154',10164,0,2),(167,10154,'181',1,'10154',10165,0,2),(31,10154,'181',2,'10189',10165,0,1),(163,10154,'19',1,'10154',10164,0,2),(164,10154,'19',1,'10154',10165,0,2),(28,10154,'19',2,'10189',10165,0,1),(677,10154,'19',4,'10706_LAYOUT_19',10162,0,1),(675,10154,'19',4,'10706_LAYOUT_19',10163,0,15),(676,10154,'19',4,'10706_LAYOUT_19',10170,0,1),(720,10154,'19',4,'10765_LAYOUT_19',10162,0,1),(718,10154,'19',4,'10765_LAYOUT_19',10163,0,15),(719,10154,'19',4,'10765_LAYOUT_19',10170,0,1),(901,10154,'1_WAR_quartzupgradeportlet',1,'10154',10161,0,2),(902,10154,'1_WAR_quartzupgradeportlet',1,'10154',10162,0,2),(903,10154,'1_WAR_quartzupgradeportlet',1,'10154',10164,0,2),(904,10154,'1_WAR_quartzupgradeportlet',1,'10154',10165,0,2),(796,10154,'2',4,'10175_LAYOUT_2',10162,0,1),(794,10154,'2',4,'10175_LAYOUT_2',10163,0,31),(795,10154,'2',4,'10175_LAYOUT_2',10170,0,1),(238,10154,'20',1,'10154',10162,0,4),(239,10154,'20',1,'10154',10164,0,4),(240,10154,'20',1,'10154',10165,0,4),(119,10154,'20',2,'10189',10164,0,2),(69,10154,'20',2,'10189',10165,0,1),(743,10154,'20',4,'10782_LAYOUT_20',10162,0,1),(741,10154,'20',4,'10782_LAYOUT_20',10163,0,31),(742,10154,'20',4,'10782_LAYOUT_20',10170,0,1),(236,10154,'23',1,'10154',10164,0,2),(237,10154,'23',1,'10154',10165,0,2),(68,10154,'23',2,'10189',10165,0,1),(635,10154,'23',4,'10659_LAYOUT_23',10162,0,1),(633,10154,'23',4,'10659_LAYOUT_23',10163,0,15),(634,10154,'23',4,'10659_LAYOUT_23',10164,0,1),(123,10154,'25',2,'10189',10164,0,2),(93,10154,'25',2,'10189',10165,0,1),(477,10154,'25',4,'10175_LAYOUT_25',10162,0,1),(475,10154,'25',4,'10175_LAYOUT_25',10163,0,15),(476,10154,'25',4,'10175_LAYOUT_25',10170,0,1),(148,10154,'26',1,'10154',10164,0,2),(149,10154,'26',1,'10154',10165,0,2),(19,10154,'26',2,'10189',10165,0,1),(141,10154,'27',1,'10154',10164,0,2),(142,10154,'27',1,'10154',10165,0,2),(13,10154,'27',2,'10189',10165,0,1),(252,10154,'28',1,'10154',10164,0,4),(253,10154,'28',1,'10154',10165,0,4),(121,10154,'28',2,'10189',10164,0,2),(76,10154,'28',2,'10189',10165,0,1),(698,10154,'28',4,'10737_LAYOUT_28',10162,0,1),(696,10154,'28',4,'10737_LAYOUT_28',10163,0,31),(697,10154,'28',4,'10737_LAYOUT_28',10170,0,1),(173,10154,'29',1,'10154',10164,0,2),(174,10154,'29',1,'10154',10165,0,2),(35,10154,'29',2,'10189',10165,0,1),(638,10154,'29',4,'10659_LAYOUT_29',10162,0,1),(636,10154,'29',4,'10659_LAYOUT_29',10163,0,15),(637,10154,'29',4,'10659_LAYOUT_29',10164,0,1),(233,10154,'3',1,'10154',10162,0,2),(234,10154,'3',1,'10154',10164,0,2),(235,10154,'3',1,'10154',10165,0,2),(67,10154,'3',2,'10189',10165,0,1),(337,10154,'3',4,'10323_LAYOUT_3',10162,0,1),(335,10154,'3',4,'10323_LAYOUT_3',10163,0,15),(336,10154,'3',4,'10323_LAYOUT_3',10170,0,1),(199,10154,'30',1,'10154',10164,0,2),(200,10154,'30',1,'10154',10165,0,2),(47,10154,'30',2,'10189',10165,0,1),(276,10154,'31',1,'10154',10162,0,2),(277,10154,'31',1,'10154',10164,0,2),(278,10154,'31',1,'10154',10165,0,2),(89,10154,'31',2,'10189',10165,0,1),(285,10154,'33',1,'10154',10162,0,2),(286,10154,'33',1,'10154',10164,0,2),(287,10154,'33',1,'10154',10165,0,2),(95,10154,'33',2,'10189',10165,0,1),(318,10154,'33',4,'10313_LAYOUT_33',10162,0,1),(316,10154,'33',4,'10313_LAYOUT_33',10163,0,15),(317,10154,'33',4,'10313_LAYOUT_33',10170,0,1),(726,10154,'33',4,'10765_LAYOUT_33',10162,0,1),(724,10154,'33',4,'10765_LAYOUT_33',10163,0,15),(725,10154,'33',4,'10765_LAYOUT_33',10170,0,1),(822,10154,'33',4,'10861_LAYOUT_33',10162,0,1),(820,10154,'33',4,'10861_LAYOUT_33',10163,0,15),(821,10154,'33',4,'10861_LAYOUT_33',10170,0,1),(267,10154,'34',1,'10154',10164,0,2),(268,10154,'34',1,'10154',10165,0,2),(84,10154,'34',2,'10189',10165,0,1),(613,10154,'34',4,'10627_LAYOUT_34',10162,0,1),(611,10154,'34',4,'10627_LAYOUT_34',10163,0,15),(612,10154,'34',4,'10627_LAYOUT_34',10170,0,1),(146,10154,'36',1,'10154',10164,0,2),(147,10154,'36',1,'10154',10165,0,2),(18,10154,'36',2,'10189',10165,0,1),(346,10154,'36',4,'10332_LAYOUT_36',10162,0,1),(344,10154,'36',4,'10332_LAYOUT_36',10163,0,15),(345,10154,'36',4,'10332_LAYOUT_36',10170,0,1),(462,10154,'36',4,'10472_LAYOUT_36',10162,0,1),(460,10154,'36',4,'10472_LAYOUT_36',10163,0,15),(461,10154,'36',4,'10472_LAYOUT_36',10170,0,1),(187,10154,'39',1,'10154',10164,0,2),(188,10154,'39',1,'10154',10165,0,2),(42,10154,'39',2,'10189',10165,0,1),(254,10154,'47',1,'10154',10162,0,2),(255,10154,'47',1,'10154',10164,0,2),(256,10154,'47',1,'10154',10165,0,2),(78,10154,'47',2,'10189',10165,0,1),(394,10154,'47',4,'10183_LAYOUT_47',10162,0,1),(392,10154,'47',4,'10183_LAYOUT_47',10163,0,15),(393,10154,'47',4,'10183_LAYOUT_47',10170,0,1),(201,10154,'48',1,'10154',10164,0,2),(202,10154,'48',1,'10154',10165,0,2),(49,10154,'48',2,'10189',10165,0,1),(911,10154,'49',4,'10175_LAYOUT_49',10162,0,1),(909,10154,'49',4,'10175_LAYOUT_49',10163,0,15),(910,10154,'49',4,'10175_LAYOUT_49',10170,0,1),(1015,10154,'49',4,'10941_LAYOUT_49',10162,0,1),(1013,10154,'49',4,'10941_LAYOUT_49',10163,0,15),(1014,10154,'49',4,'10941_LAYOUT_49',10170,0,1),(1024,10154,'49',4,'10955_LAYOUT_49',10162,0,1),(1022,10154,'49',4,'10955_LAYOUT_49',10163,0,15),(1023,10154,'49',4,'10955_LAYOUT_49',10170,0,1),(279,10154,'50',1,'10154',10162,0,2),(280,10154,'50',1,'10154',10164,0,2),(281,10154,'50',1,'10154',10165,0,2),(91,10154,'50',2,'10189',10165,0,1),(265,10154,'54',1,'10154',10164,0,2),(266,10154,'54',1,'10154',10165,0,2),(83,10154,'54',2,'10189',10165,0,1),(227,10154,'56',1,'10154',10162,0,2),(228,10154,'56',1,'10154',10164,0,2),(229,10154,'56',1,'10154',10165,0,2),(64,10154,'56',2,'10189',10165,0,1),(179,10154,'58',1,'10154',10162,0,2),(180,10154,'58',1,'10154',10164,0,2),(181,10154,'58',1,'10154',10165,0,2),(39,10154,'58',2,'10189',10165,0,1),(397,10154,'58',4,'10183_LAYOUT_58',10162,0,1),(395,10154,'58',4,'10183_LAYOUT_58',10163,0,15),(396,10154,'58',4,'10183_LAYOUT_58',10170,0,1),(295,10154,'59',1,'10154',10164,0,2),(296,10154,'59',1,'10154',10165,0,2),(101,10154,'59',2,'10189',10165,0,1),(496,10154,'59',4,'10498_LAYOUT_59_INSTANCE_uhIWLYUlw5T8',10162,0,1),(494,10154,'59',4,'10498_LAYOUT_59_INSTANCE_uhIWLYUlw5T8',10163,0,15),(495,10154,'59',4,'10498_LAYOUT_59_INSTANCE_uhIWLYUlw5T8',10170,0,1),(271,10154,'61',1,'10154',10164,0,2),(272,10154,'61',1,'10154',10165,0,2),(87,10154,'61',2,'10189',10165,0,1),(203,10154,'62',1,'10154',10164,0,2),(204,10154,'62',1,'10154',10165,0,2),(53,10154,'62',2,'10189',10165,0,1),(154,10154,'64',1,'10154',10162,0,2),(155,10154,'64',1,'10154',10164,0,2),(156,10154,'64',1,'10154',10165,0,2),(23,10154,'64',2,'10189',10165,0,1),(136,10154,'66',1,'10154',10164,0,2),(137,10154,'66',1,'10154',10165,0,2),(11,10154,'66',2,'10189',10165,0,1),(291,10154,'67',1,'10154',10164,0,2),(292,10154,'67',1,'10154',10165,0,2),(99,10154,'67',2,'10189',10165,0,1),(246,10154,'70',1,'10154',10164,0,2),(247,10154,'70',1,'10154',10165,0,2),(73,10154,'70',2,'10189',10165,0,1),(182,10154,'71',1,'10154',10162,0,2),(183,10154,'71',1,'10154',10164,0,2),(184,10154,'71',1,'10154',10165,0,2),(40,10154,'71',2,'10189',10165,0,1),(273,10154,'73',1,'10154',10162,0,2),(274,10154,'73',1,'10154',10164,0,2),(275,10154,'73',1,'10154',10165,0,2),(88,10154,'73',2,'10189',10165,0,1),(219,10154,'77',1,'10154',10162,0,2),(220,10154,'77',1,'10154',10164,0,2),(221,10154,'77',1,'10154',10165,0,2),(61,10154,'77',2,'10189',10165,0,1),(177,10154,'8',1,'10154',10164,0,4),(178,10154,'8',1,'10154',10165,0,4),(114,10154,'8',2,'10189',10164,0,2),(38,10154,'8',2,'10189',10165,0,1),(778,10154,'8',4,'10175_LAYOUT_8',10162,0,1),(776,10154,'8',4,'10175_LAYOUT_8',10163,0,31),(777,10154,'8',4,'10175_LAYOUT_8',10170,0,1),(641,10154,'8',4,'10659_LAYOUT_8',10162,0,1),(639,10154,'8',4,'10659_LAYOUT_8',10163,0,31),(640,10154,'8',4,'10659_LAYOUT_8',10164,0,1),(774,10154,'8',4,'10821_LAYOUT_8',10162,0,1),(772,10154,'8',4,'10821_LAYOUT_8',10163,0,31),(773,10154,'8',4,'10821_LAYOUT_8',10170,0,1),(262,10154,'82',1,'10154',10162,0,2),(263,10154,'82',1,'10154',10164,0,2),(264,10154,'82',1,'10154',10165,0,2),(81,10154,'82',2,'10189',10165,0,1),(645,10154,'82',4,'10659_LAYOUT_82',10162,0,1),(643,10154,'82',4,'10659_LAYOUT_82',10163,0,15),(644,10154,'82',4,'10659_LAYOUT_82',10164,0,1),(241,10154,'83',1,'10154',10164,0,4),(242,10154,'83',1,'10154',10165,0,4),(70,10154,'83',2,'10189',10165,0,1),(208,10154,'84',1,'10154',10164,0,4),(209,10154,'84',1,'10154',10165,0,4),(57,10154,'84',2,'10189',10165,0,1),(527,10154,'84',4,'10526_LAYOUT_84',10162,0,1),(525,10154,'84',4,'10526_LAYOUT_84',10163,0,31),(526,10154,'84',4,'10526_LAYOUT_84',10170,0,1),(793,10154,'84',4,'10832_LAYOUT_84',10162,0,1),(791,10154,'84',4,'10832_LAYOUT_84',10163,0,31),(792,10154,'84',4,'10832_LAYOUT_84',10170,0,1),(191,10154,'85',1,'10154',10162,0,2),(192,10154,'85',1,'10154',10164,0,2),(193,10154,'85',1,'10154',10165,0,2),(44,10154,'85',2,'10189',10165,0,1),(499,10154,'86',4,'10498_LAYOUT_86',10162,0,1),(497,10154,'86',4,'10498_LAYOUT_86',10163,0,15),(498,10154,'86',4,'10498_LAYOUT_86',10170,0,1),(1021,10154,'86',4,'10955_LAYOUT_86',10162,0,1),(1019,10154,'86',4,'10955_LAYOUT_86',10163,0,15),(1020,10154,'86',4,'10955_LAYOUT_86',10170,0,1),(416,10154,'87',4,'10424_LAYOUT_87',10162,0,1),(414,10154,'87',4,'10424_LAYOUT_87',10163,0,15),(415,10154,'87',4,'10424_LAYOUT_87',10170,0,1),(459,10154,'87',4,'10472_LAYOUT_87',10162,0,1),(457,10154,'87',4,'10472_LAYOUT_87',10163,0,15),(458,10154,'87',4,'10472_LAYOUT_87',10170,0,1),(493,10154,'87',4,'10498_LAYOUT_87',10162,0,1),(491,10154,'87',4,'10498_LAYOUT_87',10163,0,15),(492,10154,'87',4,'10498_LAYOUT_87',10170,0,1),(524,10154,'87',4,'10526_LAYOUT_87',10162,0,1),(522,10154,'87',4,'10526_LAYOUT_87',10163,0,15),(523,10154,'87',4,'10526_LAYOUT_87',10170,0,1),(555,10154,'87',4,'10561_LAYOUT_87',10162,0,1),(553,10154,'87',4,'10561_LAYOUT_87',10163,0,15),(554,10154,'87',4,'10561_LAYOUT_87',10170,0,1),(610,10154,'87',4,'10627_LAYOUT_87',10162,0,1),(608,10154,'87',4,'10627_LAYOUT_87',10163,0,15),(609,10154,'87',4,'10627_LAYOUT_87',10170,0,1),(674,10154,'87',4,'10706_LAYOUT_87',10162,0,1),(672,10154,'87',4,'10706_LAYOUT_87',10163,0,15),(673,10154,'87',4,'10706_LAYOUT_87',10170,0,1),(695,10154,'87',4,'10737_LAYOUT_87',10162,0,1),(693,10154,'87',4,'10737_LAYOUT_87',10163,0,15),(694,10154,'87',4,'10737_LAYOUT_87',10170,0,1),(714,10154,'87',4,'10765_LAYOUT_87',10162,0,1),(712,10154,'87',4,'10765_LAYOUT_87',10163,0,15),(713,10154,'87',4,'10765_LAYOUT_87',10170,0,1),(740,10154,'87',4,'10782_LAYOUT_87',10162,0,1),(738,10154,'87',4,'10782_LAYOUT_87',10163,0,15),(739,10154,'87',4,'10782_LAYOUT_87',10170,0,1),(771,10154,'87',4,'10821_LAYOUT_87',10162,0,1),(769,10154,'87',4,'10821_LAYOUT_87',10163,0,15),(770,10154,'87',4,'10821_LAYOUT_87',10170,0,1),(790,10154,'87',4,'10832_LAYOUT_87',10162,0,1),(788,10154,'87',4,'10832_LAYOUT_87',10163,0,15),(789,10154,'87',4,'10832_LAYOUT_87',10170,0,1),(819,10154,'87',4,'10861_LAYOUT_87',10162,0,1),(817,10154,'87',4,'10861_LAYOUT_87',10163,0,15),(818,10154,'87',4,'10861_LAYOUT_87',10170,0,1),(251,10154,'9',1,'10154',10161,0,2),(75,10154,'9',2,'10189',10165,0,1),(9,10154,'90',1,'10154',10165,0,8192),(185,10154,'97',1,'10154',10164,0,2),(186,10154,'97',1,'10154',10165,0,2),(41,10154,'97',2,'10189',10165,0,1),(134,10154,'98',1,'10154',10164,0,4),(135,10154,'98',1,'10154',10165,0,4),(108,10154,'98',2,'10189',10164,0,2),(10,10154,'98',2,'10189',10165,0,1),(419,10154,'98',4,'10424_LAYOUT_98',10162,0,1),(417,10154,'98',4,'10424_LAYOUT_98',10163,0,31),(418,10154,'98',4,'10424_LAYOUT_98',10170,0,1),(120,10154,'99',2,'10189',10164,0,2),(72,10154,'99',2,'10189',10165,0,1),(806,10154,'99',4,'10175_LAYOUT_99',10162,0,1),(804,10154,'99',4,'10175_LAYOUT_99',10163,0,15),(805,10154,'99',4,'10175_LAYOUT_99',10170,0,1),(124,10154,'com.liferay.portal.model.Group',2,'10189',10164,0,4096),(434,10154,'com.liferay.portal.model.Group',4,'10450',10163,0,2097151),(444,10154,'com.liferay.portal.model.Group',4,'10467',10163,0,2097151),(500,10154,'com.liferay.portal.model.Group',4,'10509',10163,0,2097151),(511,10154,'com.liferay.portal.model.Group',4,'10522',10163,0,2097151),(543,10154,'com.liferay.portal.model.Group',4,'10557',10163,0,2097151),(623,10154,'com.liferay.portal.model.Group',4,'10646',10163,0,2097151),(649,10154,'com.liferay.portal.model.Group',4,'10679',10163,0,2097151),(653,10154,'com.liferay.portal.model.Group',4,'10688',10163,0,2097151),(702,10154,'com.liferay.portal.model.Group',4,'10761',10163,0,2097151),(728,10154,'com.liferay.portal.model.Group',4,'10778',10163,0,2097151),(753,10154,'com.liferay.portal.model.Group',4,'10807',10163,0,2097151),(800,10154,'com.liferay.portal.model.Group',4,'10857',10163,0,2097151),(930,10154,'com.liferay.portal.model.Group',4,'10922',10163,0,2097151),(944,10154,'com.liferay.portal.model.Group',4,'10946',10163,0,2097151),(105,10154,'com.liferay.portal.model.Layout',2,'10189',10165,0,1),(5,10154,'com.liferay.portal.model.Layout',4,'10175',10162,0,1),(3,10154,'com.liferay.portal.model.Layout',4,'10175',10163,10158,1023),(4,10154,'com.liferay.portal.model.Layout',4,'10175',10170,0,3),(8,10154,'com.liferay.portal.model.Layout',4,'10183',10162,0,1),(6,10154,'com.liferay.portal.model.Layout',4,'10183',10163,10158,1023),(7,10154,'com.liferay.portal.model.Layout',4,'10183',10170,0,3),(313,10154,'com.liferay.portal.model.Layout',4,'10313',10163,10158,1023),(314,10154,'com.liferay.portal.model.Layout',4,'10313',10170,0,3),(327,10154,'com.liferay.portal.model.Layout',4,'10323',10163,10158,1023),(328,10154,'com.liferay.portal.model.Layout',4,'10323',10170,0,3),(342,10154,'com.liferay.portal.model.Layout',4,'10332',10163,10158,1023),(343,10154,'com.liferay.portal.model.Layout',4,'10332',10170,0,3),(360,10154,'com.liferay.portal.model.Layout',4,'10346',10162,0,1),(358,10154,'com.liferay.portal.model.Layout',4,'10346',10163,10158,1023),(359,10154,'com.liferay.portal.model.Layout',4,'10346',10170,0,3),(363,10154,'com.liferay.portal.model.Layout',4,'10352',10162,0,1),(361,10154,'com.liferay.portal.model.Layout',4,'10352',10163,10158,1023),(362,10154,'com.liferay.portal.model.Layout',4,'10352',10170,0,3),(366,10154,'com.liferay.portal.model.Layout',4,'10358',10162,0,1),(364,10154,'com.liferay.portal.model.Layout',4,'10358',10163,10158,1023),(365,10154,'com.liferay.portal.model.Layout',4,'10358',10170,0,3),(373,10154,'com.liferay.portal.model.Layout',4,'10372',10162,0,1),(371,10154,'com.liferay.portal.model.Layout',4,'10372',10163,10158,1023),(372,10154,'com.liferay.portal.model.Layout',4,'10372',10170,0,3),(376,10154,'com.liferay.portal.model.Layout',4,'10380',10162,0,1),(374,10154,'com.liferay.portal.model.Layout',4,'10380',10163,10158,1023),(375,10154,'com.liferay.portal.model.Layout',4,'10380',10170,0,3),(379,10154,'com.liferay.portal.model.Layout',4,'10386',10162,0,1),(377,10154,'com.liferay.portal.model.Layout',4,'10386',10163,10158,1023),(378,10154,'com.liferay.portal.model.Layout',4,'10386',10170,0,3),(382,10154,'com.liferay.portal.model.Layout',4,'10392',10162,0,1),(380,10154,'com.liferay.portal.model.Layout',4,'10392',10163,10158,1023),(381,10154,'com.liferay.portal.model.Layout',4,'10392',10170,0,3),(398,10154,'com.liferay.portal.model.Layout',4,'10409',10163,10196,1023),(401,10154,'com.liferay.portal.model.Layout',4,'10414',10162,0,1),(399,10154,'com.liferay.portal.model.Layout',4,'10414',10163,10196,1023),(400,10154,'com.liferay.portal.model.Layout',4,'10414',10164,0,3),(407,10154,'com.liferay.portal.model.Layout',4,'10424',10162,0,1),(405,10154,'com.liferay.portal.model.Layout',4,'10424',10163,10196,1023),(406,10154,'com.liferay.portal.model.Layout',4,'10424',10170,0,3),(450,10154,'com.liferay.portal.model.Layout',4,'10472',10162,0,1),(448,10154,'com.liferay.portal.model.Layout',4,'10472',10163,10196,1023),(449,10154,'com.liferay.portal.model.Layout',4,'10472',10170,0,3),(484,10154,'com.liferay.portal.model.Layout',4,'10498',10162,0,1),(482,10154,'com.liferay.portal.model.Layout',4,'10498',10163,10196,1023),(483,10154,'com.liferay.portal.model.Layout',4,'10498',10170,0,3),(503,10154,'com.liferay.portal.model.Layout',4,'10513',10162,0,1),(501,10154,'com.liferay.portal.model.Layout',4,'10513',10163,10196,1023),(502,10154,'com.liferay.portal.model.Layout',4,'10513',10170,0,3),(514,10154,'com.liferay.portal.model.Layout',4,'10526',10162,0,1),(512,10154,'com.liferay.portal.model.Layout',4,'10526',10163,10196,1023),(513,10154,'com.liferay.portal.model.Layout',4,'10526',10170,0,3),(538,10154,'com.liferay.portal.model.Layout',4,'10550',10163,10196,1023),(539,10154,'com.liferay.portal.model.Layout',4,'10550',10170,0,3),(546,10154,'com.liferay.portal.model.Layout',4,'10561',10162,0,1),(544,10154,'com.liferay.portal.model.Layout',4,'10561',10163,10196,1023),(545,10154,'com.liferay.portal.model.Layout',4,'10561',10170,0,3),(586,10154,'com.liferay.portal.model.Layout',4,'10594',10162,0,1),(584,10154,'com.liferay.portal.model.Layout',4,'10594',10163,10196,1023),(585,10154,'com.liferay.portal.model.Layout',4,'10594',10170,0,3),(592,10154,'com.liferay.portal.model.Layout',4,'10610',10163,10601,1023),(595,10154,'com.liferay.portal.model.Layout',4,'10615',10162,0,1),(593,10154,'com.liferay.portal.model.Layout',4,'10615',10163,10601,1023),(594,10154,'com.liferay.portal.model.Layout',4,'10615',10164,0,3),(601,10154,'com.liferay.portal.model.Layout',4,'10627',10162,0,1),(599,10154,'com.liferay.portal.model.Layout',4,'10627',10163,10196,1023),(600,10154,'com.liferay.portal.model.Layout',4,'10627',10170,0,3),(625,10154,'com.liferay.portal.model.Layout',4,'10659',10163,10650,1023),(628,10154,'com.liferay.portal.model.Layout',4,'10664',10162,0,1),(626,10154,'com.liferay.portal.model.Layout',4,'10664',10163,10650,1023),(627,10154,'com.liferay.portal.model.Layout',4,'10664',10164,0,3),(652,10154,'com.liferay.portal.model.Layout',4,'10683',10162,0,1),(650,10154,'com.liferay.portal.model.Layout',4,'10683',10163,10196,1023),(651,10154,'com.liferay.portal.model.Layout',4,'10683',10170,0,3),(660,10154,'com.liferay.portal.model.Layout',4,'10706',10162,0,1),(658,10154,'com.liferay.portal.model.Layout',4,'10706',10163,10196,1023),(659,10154,'com.liferay.portal.model.Layout',4,'10706',10170,0,3),(686,10154,'com.liferay.portal.model.Layout',4,'10737',10162,0,1),(684,10154,'com.liferay.portal.model.Layout',4,'10737',10163,10196,1023),(685,10154,'com.liferay.portal.model.Layout',4,'10737',10170,0,3),(705,10154,'com.liferay.portal.model.Layout',4,'10765',10162,0,1),(703,10154,'com.liferay.portal.model.Layout',4,'10765',10163,10196,1023),(704,10154,'com.liferay.portal.model.Layout',4,'10765',10170,0,3),(731,10154,'com.liferay.portal.model.Layout',4,'10782',10162,0,1),(729,10154,'com.liferay.portal.model.Layout',4,'10782',10163,10196,1023),(730,10154,'com.liferay.portal.model.Layout',4,'10782',10170,0,3),(756,10154,'com.liferay.portal.model.Layout',4,'10811',10162,0,1),(754,10154,'com.liferay.portal.model.Layout',4,'10811',10163,10196,1023),(755,10154,'com.liferay.portal.model.Layout',4,'10811',10170,0,3),(762,10154,'com.liferay.portal.model.Layout',4,'10821',10162,0,1),(760,10154,'com.liferay.portal.model.Layout',4,'10821',10163,10196,1023),(761,10154,'com.liferay.portal.model.Layout',4,'10821',10170,0,3),(781,10154,'com.liferay.portal.model.Layout',4,'10832',10162,0,1),(779,10154,'com.liferay.portal.model.Layout',4,'10832',10163,10196,1023),(780,10154,'com.liferay.portal.model.Layout',4,'10832',10170,0,3),(803,10154,'com.liferay.portal.model.Layout',4,'10861',10162,0,1),(801,10154,'com.liferay.portal.model.Layout',4,'10861',10163,10196,1023),(802,10154,'com.liferay.portal.model.Layout',4,'10861',10170,0,3),(908,10154,'com.liferay.portal.model.Layout',4,'10906',10162,0,1),(906,10154,'com.liferay.portal.model.Layout',4,'10906',10163,10196,1023),(907,10154,'com.liferay.portal.model.Layout',4,'10906',10170,0,3),(920,10154,'com.liferay.portal.model.Layout',4,'10914',10162,0,1),(918,10154,'com.liferay.portal.model.Layout',4,'10914',10163,10196,1023),(919,10154,'com.liferay.portal.model.Layout',4,'10914',10170,0,3),(937,10154,'com.liferay.portal.model.Layout',4,'10940',10162,0,1),(935,10154,'com.liferay.portal.model.Layout',4,'10940',10163,10158,1023),(936,10154,'com.liferay.portal.model.Layout',4,'10940',10170,0,3),(940,10154,'com.liferay.portal.model.Layout',4,'10941',10162,0,1),(938,10154,'com.liferay.portal.model.Layout',4,'10941',10163,10158,1023),(939,10154,'com.liferay.portal.model.Layout',4,'10941',10170,0,3),(947,10154,'com.liferay.portal.model.Layout',4,'10954',10162,0,1),(945,10154,'com.liferay.portal.model.Layout',4,'10954',10163,10196,1023),(946,10154,'com.liferay.portal.model.Layout',4,'10954',10170,0,3),(950,10154,'com.liferay.portal.model.Layout',4,'10955',10162,0,1),(948,10154,'com.liferay.portal.model.Layout',4,'10955',10163,10196,1023),(949,10154,'com.liferay.portal.model.Layout',4,'10955',10170,0,3),(312,10154,'com.liferay.portal.model.LayoutPrototype',4,'10309',10163,10158,15),(326,10154,'com.liferay.portal.model.LayoutPrototype',4,'10319',10163,10158,15),(341,10154,'com.liferay.portal.model.LayoutPrototype',4,'10328',10163,10158,15),(537,10154,'com.liferay.portal.model.LayoutPrototype',4,'10546',10163,10196,15),(661,10154,'com.liferay.portal.model.LayoutSetBranch',4,'10715',10163,10196,30),(662,10154,'com.liferay.portal.model.LayoutSetBranch',4,'10721',10163,10196,30),(354,10154,'com.liferay.portal.model.LayoutSetPrototype',4,'10337',10163,10158,15),(367,10154,'com.liferay.portal.model.LayoutSetPrototype',4,'10363',10163,10158,15),(583,10154,'com.liferay.portal.model.LayoutSetPrototype',4,'10590',10163,10196,15),(905,10154,'com.liferay.portal.model.LayoutSetPrototype',4,'10902',10163,10196,15),(590,10154,'com.liferay.portal.model.PasswordPolicy',4,'10600',10163,10196,31),(438,10154,'com.liferay.portal.model.Role',4,'10455',10163,10196,127),(439,10154,'com.liferay.portal.model.Role',4,'10456',10163,10196,127),(133,10154,'com.liferay.portal.model.User',4,'10196',10163,10196,31),(443,10154,'com.liferay.portal.model.User',4,'10458',10163,10196,31),(591,10154,'com.liferay.portal.model.User',4,'10601',10163,10196,31),(624,10154,'com.liferay.portal.model.User',4,'10650',10163,10196,31),(799,10154,'com.liferay.portal.model.User',4,'10848',10163,10196,31),(125,10154,'com.liferay.portlet.asset',2,'10189',10164,0,30),(807,10154,'com.liferay.portlet.asset',4,'10857',10163,0,30),(810,10154,'com.liferay.portlet.asset.model.AssetTag',4,'10867',10162,0,1),(808,10154,'com.liferay.portlet.asset.model.AssetTag',4,'10867',10163,10196,15),(809,10154,'com.liferay.portlet.asset.model.AssetTag',4,'10867',10170,0,1),(315,10154,'com.liferay.portlet.asset.model.AssetVocabulary',4,'10316',10163,10158,15),(470,10154,'com.liferay.portlet.asset.model.AssetVocabulary',4,'10489',10163,10158,15),(654,10154,'com.liferay.portlet.asset.model.AssetVocabulary',4,'10703',10163,10158,15),(657,10154,'com.liferay.portlet.asset.model.AssetVocabulary',4,'10704',10162,0,1),(655,10154,'com.liferay.portlet.asset.model.AssetVocabulary',4,'10704',10163,10158,15),(656,10154,'com.liferay.portlet.asset.model.AssetVocabulary',4,'10704',10170,0,1),(931,10154,'com.liferay.portlet.asset.model.AssetVocabulary',4,'10938',10163,10158,15),(934,10154,'com.liferay.portlet.asset.model.AssetVocabulary',4,'10939',10162,0,1),(932,10154,'com.liferay.portlet.asset.model.AssetVocabulary',4,'10939',10163,10158,15),(933,10154,'com.liferay.portlet.asset.model.AssetVocabulary',4,'10939',10170,0,1),(126,10154,'com.liferay.portlet.blogs',2,'10189',10164,0,14),(106,10154,'com.liferay.portlet.blogs',2,'10189',10165,0,14),(319,10154,'com.liferay.portlet.blogs',4,'10310',10163,0,14),(727,10154,'com.liferay.portlet.blogs',4,'10761',10163,0,14),(823,10154,'com.liferay.portlet.blogs',4,'10857',10163,0,14),(127,10154,'com.liferay.portlet.bookmarks',2,'10189',10164,0,15),(701,10154,'com.liferay.portlet.bookmarks',4,'10180',10162,0,1),(699,10154,'com.liferay.portlet.bookmarks',4,'10180',10163,0,15),(700,10154,'com.liferay.portlet.bookmarks',4,'10180',10170,0,3),(128,10154,'com.liferay.portlet.calendar',2,'10189',10164,0,14),(107,10154,'com.liferay.portlet.calendar',2,'10189',10165,0,14),(775,10154,'com.liferay.portlet.calendar',4,'10180',10163,0,14),(642,10154,'com.liferay.portlet.calendar',4,'10652',10163,0,14),(129,10154,'com.liferay.portlet.documentlibrary',2,'10189',10164,0,511),(746,10154,'com.liferay.portlet.documentlibrary',4,'10778',10162,0,1),(744,10154,'com.liferay.portlet.documentlibrary',4,'10778',10163,0,511),(745,10154,'com.liferay.portlet.documentlibrary',4,'10778',10170,0,75),(749,10154,'com.liferay.portlet.documentlibrary.model.DLFileEntry',4,'10792',10162,0,3),(747,10154,'com.liferay.portlet.documentlibrary.model.DLFileEntry',4,'10792',10163,10196,127),(748,10154,'com.liferay.portlet.documentlibrary.model.DLFileEntry',4,'10792',10170,0,3),(304,10154,'com.liferay.portlet.documentlibrary.model.DLFileEntryType',4,'10300',10163,10158,15),(306,10154,'com.liferay.portlet.documentlibrary.model.DLFileEntryType',4,'10302',10163,10158,15),(308,10154,'com.liferay.portlet.documentlibrary.model.DLFileEntryType',4,'10304',10163,10158,15),(310,10154,'com.liferay.portlet.documentlibrary.model.DLFileEntryType',4,'10306',10163,10158,15),(565,10154,'com.liferay.portlet.dynamicdatalists',4,'10557',10163,0,30),(576,10154,'com.liferay.portlet.dynamicdatalists.model.DDLRecordSet',4,'10579',10163,10196,31),(300,10154,'com.liferay.portlet.dynamicdatamapping.model.DDMStructure',4,'10297',10163,10158,15),(301,10154,'com.liferay.portlet.dynamicdatamapping.model.DDMStructure',4,'10298',10163,10158,15),(302,10154,'com.liferay.portlet.dynamicdatamapping.model.DDMStructure',4,'10299',10163,10158,15),(303,10154,'com.liferay.portlet.dynamicdatamapping.model.DDMStructure',4,'10301',10163,10158,15),(305,10154,'com.liferay.portlet.dynamicdatamapping.model.DDMStructure',4,'10303',10163,10158,15),(307,10154,'com.liferay.portlet.dynamicdatamapping.model.DDMStructure',4,'10305',10163,10158,15),(309,10154,'com.liferay.portlet.dynamicdatamapping.model.DDMStructure',4,'10307',10163,10158,15),(311,10154,'com.liferay.portlet.dynamicdatamapping.model.DDMStructure',4,'10308',10163,10158,15),(383,10154,'com.liferay.portlet.dynamicdatamapping.model.DDMStructure',4,'10399',10163,10158,15),(384,10154,'com.liferay.portlet.dynamicdatamapping.model.DDMStructure',4,'10400',10163,10158,15),(385,10154,'com.liferay.portlet.dynamicdatamapping.model.DDMStructure',4,'10401',10163,10158,15),(386,10154,'com.liferay.portlet.dynamicdatamapping.model.DDMStructure',4,'10402',10163,10158,15),(387,10154,'com.liferay.portlet.dynamicdatamapping.model.DDMStructure',4,'10403',10163,10158,15),(388,10154,'com.liferay.portlet.dynamicdatamapping.model.DDMStructure',4,'10404',10163,10158,15),(569,10154,'com.liferay.portlet.dynamicdatamapping.model.DDMStructure',4,'10575',10163,10196,15),(577,10154,'com.liferay.portlet.dynamicdatamapping.model.DDMTemplate',4,'10586',10163,10196,15),(579,10154,'com.liferay.portlet.dynamicdatamapping.model.DDMTemplate',4,'10588',10163,10196,15),(798,10154,'com.liferay.portlet.expando.model.ExpandoColumn',4,'10847',10163,0,15),(515,10154,'com.liferay.portlet.journal',4,'10180',10163,0,126),(507,10154,'com.liferay.portlet.journal',4,'10509',10163,0,126),(578,10154,'com.liferay.portlet.journal',4,'10557',10163,0,126),(951,10154,'com.liferay.portlet.journal',4,'10946',10163,0,126),(954,10154,'com.liferay.portlet.journal.model.JournalArticle',4,'10963',10162,0,3),(952,10154,'com.liferay.portlet.journal.model.JournalArticle',4,'10963',10163,10196,255),(953,10154,'com.liferay.portlet.journal.model.JournalArticle',4,'10963',10170,0,3),(510,10154,'com.liferay.portlet.journal.model.JournalFeed',4,'10521',10162,0,1),(508,10154,'com.liferay.portlet.journal.model.JournalFeed',4,'10521',10163,10196,15),(509,10154,'com.liferay.portlet.journal.model.JournalFeed',4,'10521',10170,0,1),(130,10154,'com.liferay.portlet.messageboards',2,'10189',10164,0,2047),(680,10154,'com.liferay.portlet.messageboards',4,'10688',10162,0,1),(678,10154,'com.liferay.portlet.messageboards',4,'10688',10163,0,2047),(679,10154,'com.liferay.portlet.messageboards',4,'10688',10170,0,781),(723,10154,'com.liferay.portlet.messageboards',4,'10761',10162,0,1),(721,10154,'com.liferay.portlet.messageboards',4,'10761',10163,0,2047),(722,10154,'com.liferay.portlet.messageboards',4,'10761',10170,0,781),(683,10154,'com.liferay.portlet.messageboards.model.MBCategory',4,'10735',10162,0,1),(681,10154,'com.liferay.portlet.messageboards.model.MBCategory',4,'10735',10163,10196,4095),(682,10154,'com.liferay.portlet.messageboards.model.MBCategory',4,'10735',10170,0,775),(131,10154,'com.liferay.portlet.polls',2,'10189',10164,0,6),(478,10154,'com.liferay.portlet.polls',4,'10180',10163,0,6),(481,10154,'com.liferay.portlet.polls.model.PollsQuestion',4,'10495',10162,0,1),(479,10154,'com.liferay.portlet.polls.model.PollsQuestion',4,'10495',10163,10196,31),(480,10154,'com.liferay.portlet.polls.model.PollsQuestion',4,'10495',10170,0,3),(616,10154,'com.liferay.portlet.shopping',4,'10180',10162,0,1),(614,10154,'com.liferay.portlet.shopping',4,'10180',10163,0,63),(615,10154,'com.liferay.portlet.shopping',4,'10180',10170,0,1),(619,10154,'com.liferay.portlet.shopping.model.ShoppingCategory',4,'10637',10162,0,1),(617,10154,'com.liferay.portlet.shopping.model.ShoppingCategory',4,'10637',10163,10196,63),(618,10154,'com.liferay.portlet.shopping.model.ShoppingCategory',4,'10637',10170,0,1),(622,10154,'com.liferay.portlet.shopping.model.ShoppingItem',4,'10638',10162,0,1),(620,10154,'com.liferay.portlet.shopping.model.ShoppingItem',4,'10638',10163,10196,15),(621,10154,'com.liferay.portlet.shopping.model.ShoppingItem',4,'10638',10170,0,1),(420,10154,'com.liferay.portlet.softwarecatalog',4,'10180',10163,0,14),(421,10154,'com.liferay.portlet.softwarecatalog.model.SCFrameworkVersion',4,'10433',10163,10196,14),(424,10154,'com.liferay.portlet.softwarecatalog.model.SCProductEntry',4,'10435',10162,0,3),(422,10154,'com.liferay.portlet.softwarecatalog.model.SCProductEntry',4,'10435',10163,10196,127),(423,10154,'com.liferay.portlet.softwarecatalog.model.SCProductEntry',4,'10435',10170,0,3),(132,10154,'com.liferay.portlet.wiki',2,'10189',10164,0,6),(347,10154,'com.liferay.portlet.wiki',4,'10329',10163,0,6),(463,10154,'com.liferay.portlet.wiki',4,'10467',10163,0,6),(466,10154,'com.liferay.portlet.wiki.model.WikiNode',4,'10481',10162,0,1),(464,10154,'com.liferay.portlet.wiki.model.WikiNode',4,'10481',10163,10196,255),(465,10154,'com.liferay.portlet.wiki.model.WikiNode',4,'10481',10170,0,71),(474,10154,'com.liferay.portlet.wiki.model.WikiNode',4,'10492',10162,0,1),(472,10154,'com.liferay.portlet.wiki.model.WikiNode',4,'10492',10163,10196,255),(473,10154,'com.liferay.portlet.wiki.model.WikiNode',4,'10492',10170,0,71),(469,10154,'com.liferay.portlet.wiki.model.WikiPage',4,'10483',10162,0,3),(467,10154,'com.liferay.portlet.wiki.model.WikiPage',4,'10483',10163,10196,255),(468,10154,'com.liferay.portlet.wiki.model.WikiPage',4,'10483',10170,0,99);
/*!40000 ALTER TABLE `ResourcePermission` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ResourceTypePermission`
--

DROP TABLE IF EXISTS `ResourceTypePermission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ResourceTypePermission` (
  `resourceTypePermissionId` bigint(20) NOT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `groupId` bigint(20) DEFAULT NULL,
  `name` varchar(75) DEFAULT NULL,
  `roleId` bigint(20) DEFAULT NULL,
  `actionIds` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`resourceTypePermissionId`),
  UNIQUE KEY `IX_BA497163` (`companyId`,`groupId`,`name`,`roleId`),
  KEY `IX_7D81F66F` (`companyId`,`name`,`roleId`),
  KEY `IX_A82690E2` (`roleId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ResourceTypePermission`
--

LOCK TABLES `ResourceTypePermission` WRITE;
/*!40000 ALTER TABLE `ResourceTypePermission` DISABLE KEYS */;
/*!40000 ALTER TABLE `ResourceTypePermission` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Resource_`
--

DROP TABLE IF EXISTS `Resource_`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Resource_` (
  `resourceId` bigint(20) NOT NULL,
  `codeId` bigint(20) DEFAULT NULL,
  `primKey` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`resourceId`),
  UNIQUE KEY `IX_67DE7856` (`codeId`,`primKey`),
  KEY `IX_2578FBD3` (`codeId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Resource_`
--

LOCK TABLES `Resource_` WRITE;
/*!40000 ALTER TABLE `Resource_` DISABLE KEYS */;
/*!40000 ALTER TABLE `Resource_` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Role_`
--

DROP TABLE IF EXISTS `Role_`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Role_` (
  `roleId` bigint(20) NOT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `classNameId` bigint(20) DEFAULT NULL,
  `classPK` bigint(20) DEFAULT NULL,
  `name` varchar(75) DEFAULT NULL,
  `title` longtext,
  `description` longtext,
  `type_` int(11) DEFAULT NULL,
  `subtype` varchar(75) DEFAULT NULL,
  PRIMARY KEY (`roleId`),
  UNIQUE KEY `IX_A88E424E` (`companyId`,`classNameId`,`classPK`),
  UNIQUE KEY `IX_EBC931B8` (`companyId`,`name`),
  KEY `IX_449A10B9` (`companyId`),
  KEY `IX_F436EC8E` (`name`),
  KEY `IX_5EB4E2FB` (`subtype`),
  KEY `IX_CBE204` (`type_`,`subtype`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Role_`
--

LOCK TABLES `Role_` WRITE;
/*!40000 ALTER TABLE `Role_` DISABLE KEYS */;
INSERT INTO `Role_` VALUES (10161,10154,10004,10161,'Administrator','','<?xml version=\'1.0\' encoding=\'UTF-8\'?><root available-locales=\"en_US\" default-locale=\"en_US\"><Description language-id=\"en_US\">Administrators are super users who can do anything.</Description></root>',1,''),(10162,10154,10004,10162,'Guest','','<?xml version=\'1.0\' encoding=\'UTF-8\'?><root available-locales=\"en_US\" default-locale=\"en_US\"><Description language-id=\"en_US\">Unauthenticated users always have this role.</Description></root>',1,''),(10163,10154,10004,10163,'Owner','','<?xml version=\'1.0\' encoding=\'UTF-8\'?><root available-locales=\"en_US\" default-locale=\"en_US\"><Description language-id=\"en_US\">This is an implied role with respect to the objects users create.</Description></root>',1,''),(10164,10154,10004,10164,'Power User','','<?xml version=\'1.0\' encoding=\'UTF-8\'?><root available-locales=\"en_US\" default-locale=\"en_US\"><Description language-id=\"en_US\">Power Users have their own personal site.</Description></root>',1,''),(10165,10154,10004,10165,'User','','<?xml version=\'1.0\' encoding=\'UTF-8\'?><root available-locales=\"en_US\" default-locale=\"en_US\"><Description language-id=\"en_US\">Authenticated users should be assigned this role.</Description></root>',1,''),(10166,10154,10004,10166,'Organization Administrator','','<?xml version=\'1.0\' encoding=\'UTF-8\'?><root available-locales=\"en_US\" default-locale=\"en_US\"><Description language-id=\"en_US\">Organization Administrators are super users of their organization but cannot make other users into Organization Administrators.</Description></root>',3,''),(10167,10154,10004,10167,'Organization Owner','','<?xml version=\'1.0\' encoding=\'UTF-8\'?><root available-locales=\"en_US\" default-locale=\"en_US\"><Description language-id=\"en_US\">Organization Owners are super users of their organization and can assign organization roles to users.</Description></root>',3,''),(10168,10154,10004,10168,'Organization User','','<?xml version=\'1.0\' encoding=\'UTF-8\'?><root available-locales=\"en_US\" default-locale=\"en_US\"><Description language-id=\"en_US\">All users who belong to an organization have this role within that organization.</Description></root>',3,''),(10169,10154,10004,10169,'Site Administrator','','<?xml version=\'1.0\' encoding=\'UTF-8\'?><root available-locales=\"en_US\" default-locale=\"en_US\"><Description language-id=\"en_US\">Site Administrators are super users of their site but cannot make other users into Site Administrators.</Description></root>',2,''),(10170,10154,10004,10170,'Site Member','','<?xml version=\'1.0\' encoding=\'UTF-8\'?><root available-locales=\"en_US\" default-locale=\"en_US\"><Description language-id=\"en_US\">All users who belong to a site have this role within that site.</Description></root>',2,''),(10171,10154,10004,10171,'Site Owner','','<?xml version=\'1.0\' encoding=\'UTF-8\'?><root available-locales=\"en_US\" default-locale=\"en_US\"><Description language-id=\"en_US\">Site Owners are super users of their site and can assign site roles to users.</Description></root>',2,''),(10455,10154,10004,10455,'Roles Regrole Name','','',1,''),(10456,10154,10004,10456,'Roles Orgrole Name','','',2,'');
/*!40000 ALTER TABLE `Role_` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Roles_Permissions`
--

DROP TABLE IF EXISTS `Roles_Permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Roles_Permissions` (
  `roleId` bigint(20) NOT NULL,
  `permissionId` bigint(20) NOT NULL,
  PRIMARY KEY (`roleId`,`permissionId`),
  KEY `IX_7A3619C6` (`permissionId`),
  KEY `IX_E04E486D` (`roleId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Roles_Permissions`
--

LOCK TABLES `Roles_Permissions` WRITE;
/*!40000 ALTER TABLE `Roles_Permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `Roles_Permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SCFrameworkVersi_SCProductVers`
--

DROP TABLE IF EXISTS `SCFrameworkVersi_SCProductVers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `SCFrameworkVersi_SCProductVers` (
  `frameworkVersionId` bigint(20) NOT NULL,
  `productVersionId` bigint(20) NOT NULL,
  PRIMARY KEY (`frameworkVersionId`,`productVersionId`),
  KEY `IX_3BB93ECA` (`frameworkVersionId`),
  KEY `IX_E8D33FF9` (`productVersionId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SCFrameworkVersi_SCProductVers`
--

LOCK TABLES `SCFrameworkVersi_SCProductVers` WRITE;
/*!40000 ALTER TABLE `SCFrameworkVersi_SCProductVers` DISABLE KEYS */;
INSERT INTO `SCFrameworkVersi_SCProductVers` VALUES (10433,10446);
/*!40000 ALTER TABLE `SCFrameworkVersi_SCProductVers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SCFrameworkVersion`
--

DROP TABLE IF EXISTS `SCFrameworkVersion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `SCFrameworkVersion` (
  `frameworkVersionId` bigint(20) NOT NULL,
  `groupId` bigint(20) DEFAULT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `userId` bigint(20) DEFAULT NULL,
  `userName` varchar(75) DEFAULT NULL,
  `createDate` datetime DEFAULT NULL,
  `modifiedDate` datetime DEFAULT NULL,
  `name` varchar(75) DEFAULT NULL,
  `url` longtext,
  `active_` tinyint(4) DEFAULT NULL,
  `priority` int(11) DEFAULT NULL,
  PRIMARY KEY (`frameworkVersionId`),
  KEY `IX_C98C0D78` (`companyId`),
  KEY `IX_272991FA` (`groupId`),
  KEY `IX_6E1764F` (`groupId`,`active_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SCFrameworkVersion`
--

LOCK TABLES `SCFrameworkVersion` WRITE;
/*!40000 ALTER TABLE `SCFrameworkVersion` DISABLE KEYS */;
INSERT INTO `SCFrameworkVersion` VALUES (10433,10180,10154,10196,'Test Test','2014-03-18 17:34:50','2014-03-18 17:34:50','SC Framework Version Name','www.FrameworkVersion.com',1,0);
/*!40000 ALTER TABLE `SCFrameworkVersion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SCLicense`
--

DROP TABLE IF EXISTS `SCLicense`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `SCLicense` (
  `licenseId` bigint(20) NOT NULL,
  `name` varchar(75) DEFAULT NULL,
  `url` longtext,
  `openSource` tinyint(4) DEFAULT NULL,
  `active_` tinyint(4) DEFAULT NULL,
  `recommended` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`licenseId`),
  KEY `IX_1C841592` (`active_`),
  KEY `IX_5327BB79` (`active_`,`recommended`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SCLicense`
--

LOCK TABLES `SCLicense` WRITE;
/*!40000 ALTER TABLE `SCLicense` DISABLE KEYS */;
INSERT INTO `SCLicense` VALUES (10434,'SC License Name','www.SCLicense.com',1,1,1);
/*!40000 ALTER TABLE `SCLicense` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SCLicenses_SCProductEntries`
--

DROP TABLE IF EXISTS `SCLicenses_SCProductEntries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `SCLicenses_SCProductEntries` (
  `licenseId` bigint(20) NOT NULL,
  `productEntryId` bigint(20) NOT NULL,
  PRIMARY KEY (`licenseId`,`productEntryId`),
  KEY `IX_27006638` (`licenseId`),
  KEY `IX_D7710A66` (`productEntryId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SCLicenses_SCProductEntries`
--

LOCK TABLES `SCLicenses_SCProductEntries` WRITE;
/*!40000 ALTER TABLE `SCLicenses_SCProductEntries` DISABLE KEYS */;
INSERT INTO `SCLicenses_SCProductEntries` VALUES (10434,10435);
/*!40000 ALTER TABLE `SCLicenses_SCProductEntries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SCProductEntry`
--

DROP TABLE IF EXISTS `SCProductEntry`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `SCProductEntry` (
  `productEntryId` bigint(20) NOT NULL,
  `groupId` bigint(20) DEFAULT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `userId` bigint(20) DEFAULT NULL,
  `userName` varchar(75) DEFAULT NULL,
  `createDate` datetime DEFAULT NULL,
  `modifiedDate` datetime DEFAULT NULL,
  `name` varchar(75) DEFAULT NULL,
  `type_` varchar(75) DEFAULT NULL,
  `tags` varchar(255) DEFAULT NULL,
  `shortDescription` longtext,
  `longDescription` longtext,
  `pageURL` longtext,
  `author` varchar(75) DEFAULT NULL,
  `repoGroupId` varchar(75) DEFAULT NULL,
  `repoArtifactId` varchar(75) DEFAULT NULL,
  PRIMARY KEY (`productEntryId`),
  KEY `IX_5D25244F` (`companyId`),
  KEY `IX_72F87291` (`groupId`),
  KEY `IX_98E6A9CB` (`groupId`,`userId`),
  KEY `IX_7311E812` (`repoGroupId`,`repoArtifactId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SCProductEntry`
--

LOCK TABLES `SCProductEntry` WRITE;
/*!40000 ALTER TABLE `SCProductEntry` DISABLE KEYS */;
INSERT INTO `SCProductEntry` VALUES (10435,10180,10154,10196,'Test Test','2014-03-18 17:35:03','2014-03-18 17:35:10','SC Product Test Name','portlet','','SC Short Product Description','','http://www.ProductTest.com','Test Test','1','1');
/*!40000 ALTER TABLE `SCProductEntry` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SCProductScreenshot`
--

DROP TABLE IF EXISTS `SCProductScreenshot`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `SCProductScreenshot` (
  `productScreenshotId` bigint(20) NOT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `groupId` bigint(20) DEFAULT NULL,
  `productEntryId` bigint(20) DEFAULT NULL,
  `thumbnailId` bigint(20) DEFAULT NULL,
  `fullImageId` bigint(20) DEFAULT NULL,
  `priority` int(11) DEFAULT NULL,
  PRIMARY KEY (`productScreenshotId`),
  KEY `IX_AE8224CC` (`fullImageId`),
  KEY `IX_467956FD` (`productEntryId`),
  KEY `IX_DA913A55` (`productEntryId`,`priority`),
  KEY `IX_6C572DAC` (`thumbnailId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SCProductScreenshot`
--

LOCK TABLES `SCProductScreenshot` WRITE;
/*!40000 ALTER TABLE `SCProductScreenshot` DISABLE KEYS */;
INSERT INTO `SCProductScreenshot` VALUES (10436,10154,10180,10435,10437,10438,0);
/*!40000 ALTER TABLE `SCProductScreenshot` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SCProductVersion`
--

DROP TABLE IF EXISTS `SCProductVersion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `SCProductVersion` (
  `productVersionId` bigint(20) NOT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `userId` bigint(20) DEFAULT NULL,
  `userName` varchar(75) DEFAULT NULL,
  `createDate` datetime DEFAULT NULL,
  `modifiedDate` datetime DEFAULT NULL,
  `productEntryId` bigint(20) DEFAULT NULL,
  `version` varchar(75) DEFAULT NULL,
  `changeLog` longtext,
  `downloadPageURL` longtext,
  `directDownloadURL` varchar(2000) DEFAULT NULL,
  `repoStoreArtifact` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`productVersionId`),
  KEY `IX_7020130F` (`directDownloadURL`(255)),
  KEY `IX_8377A211` (`productEntryId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SCProductVersion`
--

LOCK TABLES `SCProductVersion` WRITE;
/*!40000 ALTER TABLE `SCProductVersion` DISABLE KEYS */;
INSERT INTO `SCProductVersion` VALUES (10446,10154,10196,'Test Test','2014-03-18 17:35:10','2014-03-18 17:35:10',10435,'Product Version Name','This is a log for product version','http://www.liferay.com','',0);
/*!40000 ALTER TABLE `SCProductVersion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ServiceComponent`
--

DROP TABLE IF EXISTS `ServiceComponent`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ServiceComponent` (
  `serviceComponentId` bigint(20) NOT NULL,
  `buildNamespace` varchar(75) DEFAULT NULL,
  `buildNumber` bigint(20) DEFAULT NULL,
  `buildDate` bigint(20) DEFAULT NULL,
  `data_` longtext,
  PRIMARY KEY (`serviceComponentId`),
  UNIQUE KEY `IX_4F0315B8` (`buildNamespace`,`buildNumber`),
  KEY `IX_7338606F` (`buildNamespace`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ServiceComponent`
--

LOCK TABLES `ServiceComponent` WRITE;
/*!40000 ALTER TABLE `ServiceComponent` DISABLE KEYS */;
/*!40000 ALTER TABLE `ServiceComponent` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Shard`
--

DROP TABLE IF EXISTS `Shard`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Shard` (
  `shardId` bigint(20) NOT NULL,
  `classNameId` bigint(20) DEFAULT NULL,
  `classPK` bigint(20) DEFAULT NULL,
  `name` varchar(75) DEFAULT NULL,
  PRIMARY KEY (`shardId`),
  KEY `IX_DA5F4359` (`classNameId`,`classPK`),
  KEY `IX_941BA8C3` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Shard`
--

LOCK TABLES `Shard` WRITE;
/*!40000 ALTER TABLE `Shard` DISABLE KEYS */;
INSERT INTO `Shard` VALUES (10155,10021,10154,'default');
/*!40000 ALTER TABLE `Shard` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ShoppingCart`
--

DROP TABLE IF EXISTS `ShoppingCart`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ShoppingCart` (
  `cartId` bigint(20) NOT NULL,
  `groupId` bigint(20) DEFAULT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `userId` bigint(20) DEFAULT NULL,
  `userName` varchar(75) DEFAULT NULL,
  `createDate` datetime DEFAULT NULL,
  `modifiedDate` datetime DEFAULT NULL,
  `itemIds` longtext,
  `couponCodes` varchar(75) DEFAULT NULL,
  `altShipping` int(11) DEFAULT NULL,
  `insure` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`cartId`),
  UNIQUE KEY `IX_FC46FE16` (`groupId`,`userId`),
  KEY `IX_C28B41DC` (`groupId`),
  KEY `IX_54101CC8` (`userId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ShoppingCart`
--

LOCK TABLES `ShoppingCart` WRITE;
/*!40000 ALTER TABLE `ShoppingCart` DISABLE KEYS */;
/*!40000 ALTER TABLE `ShoppingCart` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ShoppingCategory`
--

DROP TABLE IF EXISTS `ShoppingCategory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ShoppingCategory` (
  `categoryId` bigint(20) NOT NULL,
  `groupId` bigint(20) DEFAULT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `userId` bigint(20) DEFAULT NULL,
  `userName` varchar(75) DEFAULT NULL,
  `createDate` datetime DEFAULT NULL,
  `modifiedDate` datetime DEFAULT NULL,
  `parentCategoryId` bigint(20) DEFAULT NULL,
  `name` varchar(75) DEFAULT NULL,
  `description` longtext,
  PRIMARY KEY (`categoryId`),
  KEY `IX_5F615D3E` (`groupId`),
  KEY `IX_1E6464F5` (`groupId`,`parentCategoryId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ShoppingCategory`
--

LOCK TABLES `ShoppingCategory` WRITE;
/*!40000 ALTER TABLE `ShoppingCategory` DISABLE KEYS */;
INSERT INTO `ShoppingCategory` VALUES (10637,10180,10154,10196,'Test Test','2014-03-18 17:48:29','2014-03-18 17:48:29',0,'Category Name','Category Description');
/*!40000 ALTER TABLE `ShoppingCategory` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ShoppingCoupon`
--

DROP TABLE IF EXISTS `ShoppingCoupon`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ShoppingCoupon` (
  `couponId` bigint(20) NOT NULL,
  `groupId` bigint(20) DEFAULT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `userId` bigint(20) DEFAULT NULL,
  `userName` varchar(75) DEFAULT NULL,
  `createDate` datetime DEFAULT NULL,
  `modifiedDate` datetime DEFAULT NULL,
  `code_` varchar(75) DEFAULT NULL,
  `name` varchar(75) DEFAULT NULL,
  `description` longtext,
  `startDate` datetime DEFAULT NULL,
  `endDate` datetime DEFAULT NULL,
  `active_` tinyint(4) DEFAULT NULL,
  `limitCategories` longtext,
  `limitSkus` longtext,
  `minOrder` double DEFAULT NULL,
  `discount` double DEFAULT NULL,
  `discountType` varchar(75) DEFAULT NULL,
  PRIMARY KEY (`couponId`),
  UNIQUE KEY `IX_DC60CFAE` (`code_`),
  KEY `IX_3251AF16` (`groupId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ShoppingCoupon`
--

LOCK TABLES `ShoppingCoupon` WRITE;
/*!40000 ALTER TABLE `ShoppingCoupon` DISABLE KEYS */;
/*!40000 ALTER TABLE `ShoppingCoupon` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ShoppingItem`
--

DROP TABLE IF EXISTS `ShoppingItem`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ShoppingItem` (
  `itemId` bigint(20) NOT NULL,
  `groupId` bigint(20) DEFAULT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `userId` bigint(20) DEFAULT NULL,
  `userName` varchar(75) DEFAULT NULL,
  `createDate` datetime DEFAULT NULL,
  `modifiedDate` datetime DEFAULT NULL,
  `categoryId` bigint(20) DEFAULT NULL,
  `sku` varchar(75) DEFAULT NULL,
  `name` varchar(200) DEFAULT NULL,
  `description` longtext,
  `properties` longtext,
  `fields_` tinyint(4) DEFAULT NULL,
  `fieldsQuantities` longtext,
  `minQuantity` int(11) DEFAULT NULL,
  `maxQuantity` int(11) DEFAULT NULL,
  `price` double DEFAULT NULL,
  `discount` double DEFAULT NULL,
  `taxable` tinyint(4) DEFAULT NULL,
  `shipping` double DEFAULT NULL,
  `useShippingFormula` tinyint(4) DEFAULT NULL,
  `requiresShipping` tinyint(4) DEFAULT NULL,
  `stockQuantity` int(11) DEFAULT NULL,
  `featured_` tinyint(4) DEFAULT NULL,
  `sale_` tinyint(4) DEFAULT NULL,
  `smallImage` tinyint(4) DEFAULT NULL,
  `smallImageId` bigint(20) DEFAULT NULL,
  `smallImageURL` longtext,
  `mediumImage` tinyint(4) DEFAULT NULL,
  `mediumImageId` bigint(20) DEFAULT NULL,
  `mediumImageURL` longtext,
  `largeImage` tinyint(4) DEFAULT NULL,
  `largeImageId` bigint(20) DEFAULT NULL,
  `largeImageURL` longtext,
  PRIMARY KEY (`itemId`),
  UNIQUE KEY `IX_1C717CA6` (`companyId`,`sku`),
  KEY `IX_FEFE7D76` (`groupId`,`categoryId`),
  KEY `IX_903DC750` (`largeImageId`),
  KEY `IX_D217AB30` (`mediumImageId`),
  KEY `IX_FF203304` (`smallImageId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ShoppingItem`
--

LOCK TABLES `ShoppingItem` WRITE;
/*!40000 ALTER TABLE `ShoppingItem` DISABLE KEYS */;
INSERT INTO `ShoppingItem` VALUES (10638,10180,10154,10196,'Test Test','2014-03-18 17:48:34','2014-03-18 17:49:01',0,'ITEM SKU','Item Name','Item Description','Item Properties',1,'1,',1,10,10,0.1,1,1,1,0,0,0,1,0,10639,'',0,10640,'',0,10641,'');
/*!40000 ALTER TABLE `ShoppingItem` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ShoppingItemField`
--

DROP TABLE IF EXISTS `ShoppingItemField`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ShoppingItemField` (
  `itemFieldId` bigint(20) NOT NULL,
  `itemId` bigint(20) DEFAULT NULL,
  `name` varchar(75) DEFAULT NULL,
  `values_` longtext,
  `description` longtext,
  PRIMARY KEY (`itemFieldId`),
  KEY `IX_6D5F9B87` (`itemId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ShoppingItemField`
--

LOCK TABLES `ShoppingItemField` WRITE;
/*!40000 ALTER TABLE `ShoppingItemField` DISABLE KEYS */;
INSERT INTO `ShoppingItemField` VALUES (10643,10638,'Field Name','Field Values','Field Description');
/*!40000 ALTER TABLE `ShoppingItemField` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ShoppingItemPrice`
--

DROP TABLE IF EXISTS `ShoppingItemPrice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ShoppingItemPrice` (
  `itemPriceId` bigint(20) NOT NULL,
  `itemId` bigint(20) DEFAULT NULL,
  `minQuantity` int(11) DEFAULT NULL,
  `maxQuantity` int(11) DEFAULT NULL,
  `price` double DEFAULT NULL,
  `discount` double DEFAULT NULL,
  `taxable` tinyint(4) DEFAULT NULL,
  `shipping` double DEFAULT NULL,
  `useShippingFormula` tinyint(4) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  PRIMARY KEY (`itemPriceId`),
  KEY `IX_EA6FD516` (`itemId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ShoppingItemPrice`
--

LOCK TABLES `ShoppingItemPrice` WRITE;
/*!40000 ALTER TABLE `ShoppingItemPrice` DISABLE KEYS */;
INSERT INTO `ShoppingItemPrice` VALUES (10644,10638,1,10,10,0.1,1,1,1,1),(10645,10638,0,0,0,0,1,0,1,2);
/*!40000 ALTER TABLE `ShoppingItemPrice` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ShoppingOrder`
--

DROP TABLE IF EXISTS `ShoppingOrder`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ShoppingOrder` (
  `orderId` bigint(20) NOT NULL,
  `groupId` bigint(20) DEFAULT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `userId` bigint(20) DEFAULT NULL,
  `userName` varchar(75) DEFAULT NULL,
  `createDate` datetime DEFAULT NULL,
  `modifiedDate` datetime DEFAULT NULL,
  `number_` varchar(75) DEFAULT NULL,
  `tax` double DEFAULT NULL,
  `shipping` double DEFAULT NULL,
  `altShipping` varchar(75) DEFAULT NULL,
  `requiresShipping` tinyint(4) DEFAULT NULL,
  `insure` tinyint(4) DEFAULT NULL,
  `insurance` double DEFAULT NULL,
  `couponCodes` varchar(75) DEFAULT NULL,
  `couponDiscount` double DEFAULT NULL,
  `billingFirstName` varchar(75) DEFAULT NULL,
  `billingLastName` varchar(75) DEFAULT NULL,
  `billingEmailAddress` varchar(75) DEFAULT NULL,
  `billingCompany` varchar(75) DEFAULT NULL,
  `billingStreet` varchar(75) DEFAULT NULL,
  `billingCity` varchar(75) DEFAULT NULL,
  `billingState` varchar(75) DEFAULT NULL,
  `billingZip` varchar(75) DEFAULT NULL,
  `billingCountry` varchar(75) DEFAULT NULL,
  `billingPhone` varchar(75) DEFAULT NULL,
  `shipToBilling` tinyint(4) DEFAULT NULL,
  `shippingFirstName` varchar(75) DEFAULT NULL,
  `shippingLastName` varchar(75) DEFAULT NULL,
  `shippingEmailAddress` varchar(75) DEFAULT NULL,
  `shippingCompany` varchar(75) DEFAULT NULL,
  `shippingStreet` varchar(75) DEFAULT NULL,
  `shippingCity` varchar(75) DEFAULT NULL,
  `shippingState` varchar(75) DEFAULT NULL,
  `shippingZip` varchar(75) DEFAULT NULL,
  `shippingCountry` varchar(75) DEFAULT NULL,
  `shippingPhone` varchar(75) DEFAULT NULL,
  `ccName` varchar(75) DEFAULT NULL,
  `ccType` varchar(75) DEFAULT NULL,
  `ccNumber` varchar(75) DEFAULT NULL,
  `ccExpMonth` int(11) DEFAULT NULL,
  `ccExpYear` int(11) DEFAULT NULL,
  `ccVerNumber` varchar(75) DEFAULT NULL,
  `comments` longtext,
  `ppTxnId` varchar(75) DEFAULT NULL,
  `ppPaymentStatus` varchar(75) DEFAULT NULL,
  `ppPaymentGross` double DEFAULT NULL,
  `ppReceiverEmail` varchar(75) DEFAULT NULL,
  `ppPayerEmail` varchar(75) DEFAULT NULL,
  `sendOrderEmail` tinyint(4) DEFAULT NULL,
  `sendShippingEmail` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`orderId`),
  UNIQUE KEY `IX_D7D6E87A` (`number_`),
  KEY `IX_1D15553E` (`groupId`),
  KEY `IX_119B5630` (`groupId`,`userId`,`ppPaymentStatus`),
  KEY `IX_F474FD89` (`ppTxnId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ShoppingOrder`
--

LOCK TABLES `ShoppingOrder` WRITE;
/*!40000 ALTER TABLE `ShoppingOrder` DISABLE KEYS */;
/*!40000 ALTER TABLE `ShoppingOrder` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ShoppingOrderItem`
--

DROP TABLE IF EXISTS `ShoppingOrderItem`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ShoppingOrderItem` (
  `orderItemId` bigint(20) NOT NULL,
  `orderId` bigint(20) DEFAULT NULL,
  `itemId` varchar(75) DEFAULT NULL,
  `sku` varchar(75) DEFAULT NULL,
  `name` varchar(200) DEFAULT NULL,
  `description` longtext,
  `properties` longtext,
  `price` double DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  `shippedDate` datetime DEFAULT NULL,
  PRIMARY KEY (`orderItemId`),
  KEY `IX_B5F82C7A` (`orderId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ShoppingOrderItem`
--

LOCK TABLES `ShoppingOrderItem` WRITE;
/*!40000 ALTER TABLE `ShoppingOrderItem` DISABLE KEYS */;
/*!40000 ALTER TABLE `ShoppingOrderItem` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SocialActivity`
--

DROP TABLE IF EXISTS `SocialActivity`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `SocialActivity` (
  `activityId` bigint(20) NOT NULL,
  `groupId` bigint(20) DEFAULT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `userId` bigint(20) DEFAULT NULL,
  `createDate` bigint(20) DEFAULT NULL,
  `mirrorActivityId` bigint(20) DEFAULT NULL,
  `classNameId` bigint(20) DEFAULT NULL,
  `classPK` bigint(20) DEFAULT NULL,
  `type_` int(11) DEFAULT NULL,
  `extraData` longtext,
  `receiverUserId` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`activityId`),
  UNIQUE KEY `IX_8F32DEC9` (`groupId`,`userId`,`createDate`,`classNameId`,`classPK`,`type_`,`receiverUserId`),
  KEY `IX_82E39A0C` (`classNameId`),
  KEY `IX_A853C757` (`classNameId`,`classPK`),
  KEY `IX_64B1BC66` (`companyId`),
  KEY `IX_2A2468` (`groupId`),
  KEY `IX_FB604DC7` (`groupId`,`userId`,`classNameId`,`classPK`,`type_`,`receiverUserId`),
  KEY `IX_1271F25F` (`mirrorActivityId`),
  KEY `IX_1F00C374` (`mirrorActivityId`,`classNameId`,`classPK`),
  KEY `IX_121CA3CB` (`receiverUserId`),
  KEY `IX_3504B8BC` (`userId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SocialActivity`
--

LOCK TABLES `SocialActivity` WRITE;
/*!40000 ALTER TABLE `SocialActivity` DISABLE KEYS */;
INSERT INTO `SocialActivity` VALUES (1,10467,10154,10196,1395164274658,0,10013,10483,1,'',0),(2,10180,10154,10196,1395165170688,0,10008,10746,1,'',0),(3,10778,10154,10196,1395165313399,0,10010,10792,1,'',0);
/*!40000 ALTER TABLE `SocialActivity` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SocialActivityAchievement`
--

DROP TABLE IF EXISTS `SocialActivityAchievement`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `SocialActivityAchievement` (
  `activityAchievementId` bigint(20) NOT NULL,
  `groupId` bigint(20) DEFAULT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `userId` bigint(20) DEFAULT NULL,
  `createDate` bigint(20) DEFAULT NULL,
  `name` varchar(75) DEFAULT NULL,
  `firstInGroup` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`activityAchievementId`),
  UNIQUE KEY `IX_D4390CAA` (`groupId`,`userId`,`name`),
  KEY `IX_E14B1F1` (`groupId`),
  KEY `IX_83E16F2F` (`groupId`,`firstInGroup`),
  KEY `IX_8F6408F0` (`groupId`,`name`),
  KEY `IX_C8FD892B` (`groupId`,`userId`),
  KEY `IX_AABC18E9` (`groupId`,`userId`,`firstInGroup`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SocialActivityAchievement`
--

LOCK TABLES `SocialActivityAchievement` WRITE;
/*!40000 ALTER TABLE `SocialActivityAchievement` DISABLE KEYS */;
/*!40000 ALTER TABLE `SocialActivityAchievement` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SocialActivityCounter`
--

DROP TABLE IF EXISTS `SocialActivityCounter`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `SocialActivityCounter` (
  `activityCounterId` bigint(20) NOT NULL,
  `groupId` bigint(20) DEFAULT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `classNameId` bigint(20) DEFAULT NULL,
  `classPK` bigint(20) DEFAULT NULL,
  `name` varchar(75) DEFAULT NULL,
  `ownerType` int(11) DEFAULT NULL,
  `currentValue` int(11) DEFAULT NULL,
  `totalValue` int(11) DEFAULT NULL,
  `graceValue` int(11) DEFAULT NULL,
  `startPeriod` int(11) DEFAULT NULL,
  `endPeriod` int(11) DEFAULT NULL,
  PRIMARY KEY (`activityCounterId`),
  UNIQUE KEY `IX_1B7E3B67` (`groupId`,`classNameId`,`classPK`,`name`,`ownerType`,`endPeriod`),
  UNIQUE KEY `IX_374B35AE` (`groupId`,`classNameId`,`classPK`,`name`,`ownerType`,`startPeriod`),
  KEY `IX_A4B9A23B` (`classNameId`,`classPK`),
  KEY `IX_926CDD04` (`groupId`,`classNameId`,`classPK`,`ownerType`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SocialActivityCounter`
--

LOCK TABLES `SocialActivityCounter` WRITE;
/*!40000 ALTER TABLE `SocialActivityCounter` DISABLE KEYS */;
/*!40000 ALTER TABLE `SocialActivityCounter` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SocialActivityLimit`
--

DROP TABLE IF EXISTS `SocialActivityLimit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `SocialActivityLimit` (
  `activityLimitId` bigint(20) NOT NULL,
  `groupId` bigint(20) DEFAULT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `userId` bigint(20) DEFAULT NULL,
  `classNameId` bigint(20) DEFAULT NULL,
  `classPK` bigint(20) DEFAULT NULL,
  `activityType` int(11) DEFAULT NULL,
  `activityCounterName` varchar(75) DEFAULT NULL,
  `value` varchar(75) DEFAULT NULL,
  PRIMARY KEY (`activityLimitId`),
  UNIQUE KEY `IX_F1C1A617` (`groupId`,`userId`,`classNameId`,`classPK`,`activityType`,`activityCounterName`),
  KEY `IX_B15863FA` (`classNameId`,`classPK`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SocialActivityLimit`
--

LOCK TABLES `SocialActivityLimit` WRITE;
/*!40000 ALTER TABLE `SocialActivityLimit` DISABLE KEYS */;
/*!40000 ALTER TABLE `SocialActivityLimit` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SocialActivitySetting`
--

DROP TABLE IF EXISTS `SocialActivitySetting`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `SocialActivitySetting` (
  `activitySettingId` bigint(20) NOT NULL,
  `groupId` bigint(20) DEFAULT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `classNameId` bigint(20) DEFAULT NULL,
  `activityType` int(11) DEFAULT NULL,
  `name` varchar(75) DEFAULT NULL,
  `value` varchar(1024) DEFAULT NULL,
  PRIMARY KEY (`activitySettingId`),
  KEY `IX_384788CD` (`groupId`,`activityType`),
  KEY `IX_1E9CF33B` (`groupId`,`classNameId`,`activityType`),
  KEY `IX_D984AABA` (`groupId`,`classNameId`,`activityType`,`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SocialActivitySetting`
--

LOCK TABLES `SocialActivitySetting` WRITE;
/*!40000 ALTER TABLE `SocialActivitySetting` DISABLE KEYS */;
INSERT INTO `SocialActivitySetting` VALUES (10538,10522,10154,10007,0,'enabled','true'),(10539,10522,10154,10007,10001,'contribution','{\"enabled\":true,\"limitValue\":0,\"ownerType\":3,\"value\":0,\"limitEnabled\":true,\"limitPeriod\":1}'),(10540,10522,10154,10007,10001,'popularity','{\"enabled\":true,\"limitValue\":0,\"ownerType\":2,\"value\":0,\"limitEnabled\":true,\"limitPeriod\":1}'),(10541,10522,10154,10007,10003,'participation','{\"enabled\":true,\"limitValue\":0,\"ownerType\":1,\"value\":0,\"limitEnabled\":true,\"limitPeriod\":1}'),(10542,10522,10154,10007,3,'contribution','{\"enabled\":true,\"limitValue\":0,\"ownerType\":3,\"value\":0,\"limitEnabled\":true,\"limitPeriod\":1}'),(10543,10522,10154,10007,3,'popularity','{\"enabled\":true,\"limitValue\":0,\"ownerType\":2,\"value\":0,\"limitEnabled\":true,\"limitPeriod\":1}');
/*!40000 ALTER TABLE `SocialActivitySetting` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SocialRelation`
--

DROP TABLE IF EXISTS `SocialRelation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `SocialRelation` (
  `uuid_` varchar(75) DEFAULT NULL,
  `relationId` bigint(20) NOT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `createDate` bigint(20) DEFAULT NULL,
  `userId1` bigint(20) DEFAULT NULL,
  `userId2` bigint(20) DEFAULT NULL,
  `type_` int(11) DEFAULT NULL,
  PRIMARY KEY (`relationId`),
  UNIQUE KEY `IX_12A92145` (`userId1`,`userId2`,`type_`),
  KEY `IX_61171E99` (`companyId`),
  KEY `IX_95135D1C` (`companyId`,`type_`),
  KEY `IX_C31A64C6` (`type_`),
  KEY `IX_5A40CDCC` (`userId1`),
  KEY `IX_4B52BE89` (`userId1`,`type_`),
  KEY `IX_B5C9C690` (`userId1`,`userId2`),
  KEY `IX_5A40D18D` (`userId2`),
  KEY `IX_3F9C2FA8` (`userId2`,`type_`),
  KEY `IX_F0CA24A5` (`uuid_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SocialRelation`
--

LOCK TABLES `SocialRelation` WRITE;
/*!40000 ALTER TABLE `SocialRelation` DISABLE KEYS */;
/*!40000 ALTER TABLE `SocialRelation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SocialRequest`
--

DROP TABLE IF EXISTS `SocialRequest`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `SocialRequest` (
  `uuid_` varchar(75) DEFAULT NULL,
  `requestId` bigint(20) NOT NULL,
  `groupId` bigint(20) DEFAULT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `userId` bigint(20) DEFAULT NULL,
  `createDate` bigint(20) DEFAULT NULL,
  `modifiedDate` bigint(20) DEFAULT NULL,
  `classNameId` bigint(20) DEFAULT NULL,
  `classPK` bigint(20) DEFAULT NULL,
  `type_` int(11) DEFAULT NULL,
  `extraData` longtext,
  `receiverUserId` bigint(20) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  PRIMARY KEY (`requestId`),
  UNIQUE KEY `IX_36A90CA7` (`userId`,`classNameId`,`classPK`,`type_`,`receiverUserId`),
  UNIQUE KEY `IX_4F973EFE` (`uuid_`,`groupId`),
  KEY `IX_D3425487` (`classNameId`,`classPK`,`type_`,`receiverUserId`,`status`),
  KEY `IX_A90FE5A0` (`companyId`),
  KEY `IX_32292ED1` (`receiverUserId`),
  KEY `IX_D9380CB7` (`receiverUserId`,`status`),
  KEY `IX_80F7A9C2` (`userId`),
  KEY `IX_CC86A444` (`userId`,`classNameId`,`classPK`,`type_`,`status`),
  KEY `IX_AB5906A8` (`userId`,`status`),
  KEY `IX_49D5872C` (`uuid_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SocialRequest`
--

LOCK TABLES `SocialRequest` WRITE;
/*!40000 ALTER TABLE `SocialRequest` DISABLE KEYS */;
/*!40000 ALTER TABLE `SocialRequest` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Subscription`
--

DROP TABLE IF EXISTS `Subscription`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Subscription` (
  `subscriptionId` bigint(20) NOT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `userId` bigint(20) DEFAULT NULL,
  `userName` varchar(75) DEFAULT NULL,
  `createDate` datetime DEFAULT NULL,
  `modifiedDate` datetime DEFAULT NULL,
  `classNameId` bigint(20) DEFAULT NULL,
  `classPK` bigint(20) DEFAULT NULL,
  `frequency` varchar(75) DEFAULT NULL,
  PRIMARY KEY (`subscriptionId`),
  UNIQUE KEY `IX_2E1A92D4` (`companyId`,`userId`,`classNameId`,`classPK`),
  KEY `IX_786D171A` (`companyId`,`classNameId`,`classPK`),
  KEY `IX_54243AFD` (`userId`),
  KEY `IX_E8F34171` (`userId`,`classNameId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Subscription`
--

LOCK TABLES `Subscription` WRITE;
/*!40000 ALTER TABLE `Subscription` DISABLE KEYS */;
/*!40000 ALTER TABLE `Subscription` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Team`
--

DROP TABLE IF EXISTS `Team`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Team` (
  `teamId` bigint(20) NOT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `userId` bigint(20) DEFAULT NULL,
  `userName` varchar(75) DEFAULT NULL,
  `createDate` datetime DEFAULT NULL,
  `modifiedDate` datetime DEFAULT NULL,
  `groupId` bigint(20) DEFAULT NULL,
  `name` varchar(75) DEFAULT NULL,
  `description` longtext,
  PRIMARY KEY (`teamId`),
  UNIQUE KEY `IX_143DC786` (`groupId`,`name`),
  KEY `IX_AE6E9907` (`groupId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Team`
--

LOCK TABLES `Team` WRITE;
/*!40000 ALTER TABLE `Team` DISABLE KEYS */;
/*!40000 ALTER TABLE `Team` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Ticket`
--

DROP TABLE IF EXISTS `Ticket`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Ticket` (
  `ticketId` bigint(20) NOT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `createDate` datetime DEFAULT NULL,
  `classNameId` bigint(20) DEFAULT NULL,
  `classPK` bigint(20) DEFAULT NULL,
  `key_` varchar(75) DEFAULT NULL,
  `type_` int(11) DEFAULT NULL,
  `extraInfo` longtext,
  `expirationDate` datetime DEFAULT NULL,
  PRIMARY KEY (`ticketId`),
  KEY `IX_B2468446` (`key_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Ticket`
--

LOCK TABLES `Ticket` WRITE;
/*!40000 ALTER TABLE `Ticket` DISABLE KEYS */;
/*!40000 ALTER TABLE `Ticket` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `UserGroup`
--

DROP TABLE IF EXISTS `UserGroup`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `UserGroup` (
  `userGroupId` bigint(20) NOT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `parentUserGroupId` bigint(20) DEFAULT NULL,
  `name` varchar(75) DEFAULT NULL,
  `description` longtext,
  `addedByLDAPImport` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`userGroupId`),
  UNIQUE KEY `IX_23EAD0D` (`companyId`,`name`),
  KEY `IX_524FEFCE` (`companyId`),
  KEY `IX_69771487` (`companyId`,`parentUserGroupId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `UserGroup`
--

LOCK TABLES `UserGroup` WRITE;
/*!40000 ALTER TABLE `UserGroup` DISABLE KEYS */;
/*!40000 ALTER TABLE `UserGroup` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `UserGroupGroupRole`
--

DROP TABLE IF EXISTS `UserGroupGroupRole`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `UserGroupGroupRole` (
  `userGroupId` bigint(20) NOT NULL,
  `groupId` bigint(20) NOT NULL,
  `roleId` bigint(20) NOT NULL,
  PRIMARY KEY (`userGroupId`,`groupId`,`roleId`),
  KEY `IX_CCBE4063` (`groupId`),
  KEY `IX_CAB0CCC8` (`groupId`,`roleId`),
  KEY `IX_1CDF88C` (`roleId`),
  KEY `IX_DCDED558` (`userGroupId`),
  KEY `IX_73C52252` (`userGroupId`,`groupId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `UserGroupGroupRole`
--

LOCK TABLES `UserGroupGroupRole` WRITE;
/*!40000 ALTER TABLE `UserGroupGroupRole` DISABLE KEYS */;
/*!40000 ALTER TABLE `UserGroupGroupRole` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `UserGroupRole`
--

DROP TABLE IF EXISTS `UserGroupRole`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `UserGroupRole` (
  `userId` bigint(20) NOT NULL,
  `groupId` bigint(20) NOT NULL,
  `roleId` bigint(20) NOT NULL,
  PRIMARY KEY (`userId`,`groupId`,`roleId`),
  KEY `IX_1B988D7A` (`groupId`),
  KEY `IX_871412DF` (`groupId`,`roleId`),
  KEY `IX_887A2C95` (`roleId`),
  KEY `IX_887BE56A` (`userId`),
  KEY `IX_4D040680` (`userId`,`groupId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `UserGroupRole`
--

LOCK TABLES `UserGroupRole` WRITE;
/*!40000 ALTER TABLE `UserGroupRole` DISABLE KEYS */;
INSERT INTO `UserGroupRole` VALUES (10196,10450,10171),(10196,10467,10171),(10196,10509,10171),(10196,10522,10171),(10196,10557,10171),(10196,10646,10171),(10196,10679,10171),(10196,10688,10171),(10196,10761,10171),(10196,10778,10171),(10196,10807,10171),(10196,10857,10171),(10196,10922,10171),(10196,10946,10171);
/*!40000 ALTER TABLE `UserGroupRole` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `UserGroups_Teams`
--

DROP TABLE IF EXISTS `UserGroups_Teams`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `UserGroups_Teams` (
  `userGroupId` bigint(20) NOT NULL,
  `teamId` bigint(20) NOT NULL,
  PRIMARY KEY (`userGroupId`,`teamId`),
  KEY `IX_31FB0B08` (`teamId`),
  KEY `IX_7F187E63` (`userGroupId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `UserGroups_Teams`
--

LOCK TABLES `UserGroups_Teams` WRITE;
/*!40000 ALTER TABLE `UserGroups_Teams` DISABLE KEYS */;
/*!40000 ALTER TABLE `UserGroups_Teams` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `UserIdMapper`
--

DROP TABLE IF EXISTS `UserIdMapper`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `UserIdMapper` (
  `userIdMapperId` bigint(20) NOT NULL,
  `userId` bigint(20) DEFAULT NULL,
  `type_` varchar(75) DEFAULT NULL,
  `description` varchar(75) DEFAULT NULL,
  `externalUserId` varchar(75) DEFAULT NULL,
  PRIMARY KEY (`userIdMapperId`),
  UNIQUE KEY `IX_41A32E0D` (`type_`,`externalUserId`),
  UNIQUE KEY `IX_D1C44A6E` (`userId`,`type_`),
  KEY `IX_E60EA987` (`userId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `UserIdMapper`
--

LOCK TABLES `UserIdMapper` WRITE;
/*!40000 ALTER TABLE `UserIdMapper` DISABLE KEYS */;
/*!40000 ALTER TABLE `UserIdMapper` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `UserNotificationEvent`
--

DROP TABLE IF EXISTS `UserNotificationEvent`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `UserNotificationEvent` (
  `uuid_` varchar(75) DEFAULT NULL,
  `userNotificationEventId` bigint(20) NOT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `userId` bigint(20) DEFAULT NULL,
  `type_` varchar(75) DEFAULT NULL,
  `timestamp` bigint(20) DEFAULT NULL,
  `deliverBy` bigint(20) DEFAULT NULL,
  `payload` longtext,
  `archived` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`userNotificationEventId`),
  KEY `IX_3E5D78C4` (`userId`),
  KEY `IX_3DBB361A` (`userId`,`archived`),
  KEY `IX_ECD8CFEA` (`uuid_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `UserNotificationEvent`
--

LOCK TABLES `UserNotificationEvent` WRITE;
/*!40000 ALTER TABLE `UserNotificationEvent` DISABLE KEYS */;
/*!40000 ALTER TABLE `UserNotificationEvent` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `UserTracker`
--

DROP TABLE IF EXISTS `UserTracker`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `UserTracker` (
  `userTrackerId` bigint(20) NOT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `userId` bigint(20) DEFAULT NULL,
  `modifiedDate` datetime DEFAULT NULL,
  `sessionId` varchar(200) DEFAULT NULL,
  `remoteAddr` varchar(75) DEFAULT NULL,
  `remoteHost` varchar(75) DEFAULT NULL,
  `userAgent` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`userTrackerId`),
  KEY `IX_29BA1CF5` (`companyId`),
  KEY `IX_46B0AE8E` (`sessionId`),
  KEY `IX_E4EFBA8D` (`userId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `UserTracker`
--

LOCK TABLES `UserTracker` WRITE;
/*!40000 ALTER TABLE `UserTracker` DISABLE KEYS */;
INSERT INTO `UserTracker` VALUES (1,10154,10196,'2014-03-18 17:35:20','594BCDF1960D8A0FF7D2C3ACF8D7FE3C','127.0.0.1','127.0.0.1','Mozilla/5.0 (Windows NT 6.1; WOW64; rv:22.0) Gecko/20100101 Firefox/22.0'),(2,10154,10196,'2014-03-18 17:37:11','C6A0696D76A395DFED1257D36D95CA97','127.0.0.1','127.0.0.1','Mozilla/5.0 (Windows NT 6.1; WOW64; rv:22.0) Gecko/20100101 Firefox/22.0'),(3,10154,10196,'2014-03-18 17:38:23','9CF3AF967D8681E63F1BB9301AE62104','127.0.0.1','127.0.0.1','Mozilla/5.0 (Windows NT 6.1; WOW64; rv:22.0) Gecko/20100101 Firefox/22.0'),(4,10154,10196,'2014-03-18 17:39:13','0732D1108074EC190ADCBD2C8FBBBDEA','127.0.0.1','127.0.0.1','Mozilla/5.0 (Windows NT 6.1; WOW64; rv:22.0) Gecko/20100101 Firefox/22.0'),(5,10154,10196,'2014-03-18 17:41:07','BE46A2A55577C60178F46F194CA73D26','127.0.0.1','127.0.0.1','Mozilla/5.0 (Windows NT 6.1; WOW64; rv:22.0) Gecko/20100101 Firefox/22.0'),(6,10154,10196,'2014-03-18 17:42:12','AB124DE84898064CA8FD1864F0EC6BB5','127.0.0.1','127.0.0.1','Mozilla/5.0 (Windows NT 6.1; WOW64; rv:22.0) Gecko/20100101 Firefox/22.0'),(7,10154,10196,'2014-03-18 17:42:41','D54AD87584D32EC368A2666235AFDD1D','127.0.0.1','127.0.0.1','Mozilla/5.0 (Windows NT 6.1; WOW64; rv:22.0) Gecko/20100101 Firefox/22.0'),(8,10154,10196,'2014-03-18 17:44:55','0C99071BCF14A8C54A5FA1688FD5D305','127.0.0.1','127.0.0.1','Mozilla/5.0 (Windows NT 6.1; WOW64; rv:22.0) Gecko/20100101 Firefox/22.0'),(9,10154,10196,'2014-03-18 17:45:20','481E5D3B79A6BAF210FFDA5BE62E15FD','127.0.0.1','127.0.0.1','Mozilla/5.0 (Windows NT 6.1; WOW64; rv:22.0) Gecko/20100101 Firefox/22.0'),(11,10154,10601,'2014-03-18 17:46:26','75B9647B9916FFD3ADBA8BF59D15D71C','127.0.0.1','127.0.0.1','Mozilla/5.0 (Windows NT 6.1; WOW64; rv:22.0) Gecko/20100101 Firefox/22.0'),(13,10154,10601,'2014-03-18 17:47:16','1C382FBA3CCB1A8DB1D9569F13601DCC','127.0.0.1','127.0.0.1','Mozilla/5.0 (Windows NT 6.1; WOW64; rv:22.0) Gecko/20100101 Firefox/22.0'),(14,10154,10196,'2014-03-18 17:47:32','B950A6849ADB857A50CEDC9D3469CACB','127.0.0.1','127.0.0.1','Mozilla/5.0 (Windows NT 6.1; WOW64; rv:22.0) Gecko/20100101 Firefox/22.0'),(15,10154,10196,'2014-03-18 17:48:02','7C65A755CFC6CF3C7BEC70F9DFE80395','127.0.0.1','127.0.0.1','Mozilla/5.0 (Windows NT 6.1; WOW64; rv:22.0) Gecko/20100101 Firefox/22.0'),(16,10154,10196,'2014-03-18 17:49:12','066834C771ADB14CD639A9E3FC243D3D','127.0.0.1','127.0.0.1','Mozilla/5.0 (Windows NT 6.1; WOW64; rv:22.0) Gecko/20100101 Firefox/22.0'),(17,10154,10196,'2014-03-18 17:50:03','01A8EE88BF546EEA9A239A6F9A3582AB','127.0.0.1','127.0.0.1','Mozilla/5.0 (Windows NT 6.1; WOW64; rv:22.0) Gecko/20100101 Firefox/22.0'),(18,10154,10650,'2014-03-18 17:50:15','A02C3EA9E2CF75E27B1EF846B1A60E73','127.0.0.1','127.0.0.1','Mozilla/5.0 (Windows NT 6.1; WOW64; rv:22.0) Gecko/20100101 Firefox/22.0'),(19,10154,10196,'2014-03-18 17:50:24','6D36AA5EA8C44978ADF1108B2E52C483','127.0.0.1','127.0.0.1','Mozilla/5.0 (Windows NT 6.1; WOW64; rv:22.0) Gecko/20100101 Firefox/22.0'),(20,10154,10650,'2014-03-18 17:50:52','A008F65ADFBB0112B5992AF91A2E41FD','127.0.0.1','127.0.0.1','Mozilla/5.0 (Windows NT 6.1; WOW64; rv:22.0) Gecko/20100101 Firefox/22.0'),(21,10154,10196,'2014-03-18 17:52:21','08A79B9E807DA9689BE9AF46FE812DC5','127.0.0.1','127.0.0.1','Mozilla/5.0 (Windows NT 6.1; WOW64; rv:22.0) Gecko/20100101 Firefox/22.0'),(22,10154,10196,'2014-03-18 17:53:10','11575BA41BBB0D50DEEBB12AB1E9E08A','127.0.0.1','127.0.0.1','Mozilla/5.0 (Windows NT 6.1; WOW64; rv:22.0) Gecko/20100101 Firefox/22.0'),(23,10154,10196,'2014-03-18 17:54:22','45BF58B7C1BF43377F2D3B132772CDD3','127.0.0.1','127.0.0.1','Mozilla/5.0 (Windows NT 6.1; WOW64; rv:22.0) Gecko/20100101 Firefox/22.0'),(24,10154,10196,'2014-03-18 17:56:35','1B1350AD691114193884F2507E1BD0BD','127.0.0.1','127.0.0.1','Mozilla/5.0 (Windows NT 6.1; WOW64; rv:22.0) Gecko/20100101 Firefox/22.0'),(25,10154,10196,'2014-03-18 17:57:10','0AA37526021A5D238FA54B1915F566BE','127.0.0.1','127.0.0.1','Mozilla/5.0 (Windows NT 6.1; WOW64; rv:22.0) Gecko/20100101 Firefox/22.0'),(26,10154,10196,'2014-03-18 17:58:41','3A0B0BF4BBF22F8FDF6893912EC55325','127.0.0.1','127.0.0.1','Mozilla/5.0 (Windows NT 6.1; WOW64; rv:22.0) Gecko/20100101 Firefox/22.0'),(27,10154,10196,'2014-03-18 17:59:19','3741C14C52EA3F873B30658AA8BCE907','127.0.0.1','127.0.0.1','Mozilla/5.0 (Windows NT 6.1; WOW64; rv:22.0) Gecko/20100101 Firefox/22.0'),(28,10154,10196,'2014-03-18 18:00:03','83A23FA603EC2C6A1EC9C3A1F38B0C64','127.0.0.1','127.0.0.1','Mozilla/5.0 (Windows NT 6.1; WOW64; rv:22.0) Gecko/20100101 Firefox/22.0'),(29,10154,10196,'2014-03-18 18:01:00','76BFE413497783860C8AFC9B30F610C0','127.0.0.1','127.0.0.1','Mozilla/5.0 (Windows NT 6.1; WOW64; rv:22.0) Gecko/20100101 Firefox/22.0'),(30,10154,10196,'2014-03-18 18:02:08','CACABFA1B51A7C20C98F5B6891B58C40','127.0.0.1','127.0.0.1','Mozilla/5.0 (Windows NT 6.1; WOW64; rv:22.0) Gecko/20100101 Firefox/22.0');
/*!40000 ALTER TABLE `UserTracker` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `UserTrackerPath`
--

DROP TABLE IF EXISTS `UserTrackerPath`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `UserTrackerPath` (
  `userTrackerPathId` bigint(20) NOT NULL,
  `userTrackerId` bigint(20) DEFAULT NULL,
  `path_` longtext,
  `pathDate` datetime DEFAULT NULL,
  PRIMARY KEY (`userTrackerPathId`),
  KEY `IX_14D8BCC0` (`userTrackerId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `UserTrackerPath`
--

LOCK TABLES `UserTrackerPath` WRITE;
/*!40000 ALTER TABLE `UserTrackerPath` DISABLE KEYS */;
INSERT INTO `UserTrackerPath` VALUES (1,1,'/portal/layout?p_l_id=10183&p_v_l_s_g_id=0','2014-03-18 17:34:21'),(2,1,'/portal/update_terms_of_use','2014-03-18 17:34:24'),(3,1,'/portal/layout?p_l_id=10183&p_v_l_s_g_id=0','2014-03-18 17:34:24'),(4,1,'/portal/update_reminder_query','2014-03-18 17:34:28'),(5,1,'/portal/layout?p_l_id=10183&p_v_l_s_g_id=0','2014-03-18 17:34:28'),(6,1,'/portal/layout?p_l_id=10183&p_v_l_s_g_id=0','2014-03-18 17:34:30'),(7,1,'/layouts_admin/update_page','2014-03-18 17:34:33'),(8,1,'/portal/layout?p_l_id=10424&p_v_l_s_g_id=0','2014-03-18 17:34:34'),(9,1,'/portal/layout?p_l_id=10183&p_v_l_s_g_id=0','2014-03-18 17:34:37'),(10,1,'/portal/layout?p_l_id=10424&p_v_l_s_g_id=0','2014-03-18 17:34:38'),(11,1,'/portal/update_layout','2014-03-18 17:34:43'),(12,1,'/portal/layout?p_l_id=10424&p_v_l_s_g_id=0&p_p_state=normal&p_p_lifecycle=0&p_p_id=98&_98_tabs1=framework_versions&_98_struts_action=%2Fsoftware_catalog%2Fview&p_p_mode=view','2014-03-18 17:34:46'),(13,1,'/portal/layout?p_l_id=10424&p_v_l_s_g_id=0&p_p_state=normal&p_p_lifecycle=0&p_p_id=98&_98_struts_action=%2Fsoftware_catalog%2Fedit_framework_version&p_p_mode=view','2014-03-18 17:34:47'),(14,1,'/portal/layout?p_l_id=10424&p_v_l_s_g_id=0','2014-03-18 17:34:50'),(15,1,'/portal/layout?p_l_id=10424&p_v_l_s_g_id=0&p_p_state=normal&p_p_lifecycle=0&p_p_id=98&_98_tabs1=framework_versions&_98_struts_action=%2Fsoftware_catalog%2Fview&p_p_mode=view','2014-03-18 17:34:50'),(16,1,'/portal/layout?p_l_id=10424&p_v_l_s_g_id=0&p_p_state=normal&p_p_lifecycle=0&p_p_id=98&_98_tabs1=licenses&_98_struts_action=%2Fsoftware_catalog%2Fview&p_p_mode=view','2014-03-18 17:34:52'),(17,1,'/portal/layout?p_l_id=10424&p_v_l_s_g_id=0&p_p_state=normal&p_p_lifecycle=0&p_p_id=98&_98_struts_action=%2Fsoftware_catalog%2Fedit_license&p_p_mode=view','2014-03-18 17:34:53'),(18,1,'/portal/layout?p_l_id=10424&p_v_l_s_g_id=0','2014-03-18 17:34:54'),(19,1,'/portal/layout?p_l_id=10424&p_v_l_s_g_id=0&p_p_state=normal&p_p_lifecycle=0&p_p_id=98&_98_tabs1=licenses&_98_struts_action=%2Fsoftware_catalog%2Fview&p_p_mode=view','2014-03-18 17:34:54'),(20,1,'/portal/layout?p_l_id=10424&p_v_l_s_g_id=0&p_p_state=normal&p_p_lifecycle=0&p_p_id=98&_98_tabs1=products&_98_struts_action=%2Fsoftware_catalog%2Fview&p_p_mode=view','2014-03-18 17:34:56'),(21,1,'/portal/layout?p_l_id=10424&p_v_l_s_g_id=0&p_p_state=normal&p_p_lifecycle=0&p_p_id=98&_98_struts_action=%2Fsoftware_catalog%2Fedit_product_entry&p_p_mode=view','2014-03-18 17:34:57'),(22,1,'/portal/layout?p_l_id=10424&p_v_l_s_g_id=0','2014-03-18 17:35:02'),(23,1,'/portal/layout?p_l_id=10424&p_v_l_s_g_id=0','2014-03-18 17:35:03'),(24,1,'/portal/layout?p_l_id=10424&p_v_l_s_g_id=0&p_p_state=normal&p_p_lifecycle=0&p_p_id=98&_98_tabs1=products&_98_struts_action=%2Fsoftware_catalog%2Fview&p_p_mode=view','2014-03-18 17:35:03'),(25,1,'/portal/layout?p_l_id=10424&p_v_l_s_g_id=0&p_p_state=normal&p_p_lifecycle=0&p_p_id=98&_98_tabs1=products&_98_struts_action=%2Fsoftware_catalog%2Fview&p_p_mode=view','2014-03-18 17:35:05'),(26,1,'/portal/layout?p_l_id=10424&p_v_l_s_g_id=0&p_p_state=normal&p_p_lifecycle=0&p_p_id=98&_98_productEntryId=10435&_98_struts_action=%2Fsoftware_catalog%2Fview_product_entry&p_p_mode=view','2014-03-18 17:35:06'),(27,1,'/portal/layout?p_l_id=10424&p_v_l_s_g_id=0&p_p_state=normal&p_p_lifecycle=0&p_p_id=98&_98_productEntryId=10435&_98_struts_action=%2Fsoftware_catalog%2Fedit_product_version&p_p_mode=view','2014-03-18 17:35:08'),(28,1,'/portal/layout?p_l_id=10424&p_v_l_s_g_id=0','2014-03-18 17:35:10'),(29,1,'/portal/layout?p_l_id=10424&p_v_l_s_g_id=0&p_p_state=normal&p_p_lifecycle=0&p_p_id=98&_98_productEntryId=10435&_98_struts_action=%2Fsoftware_catalog%2Fview_product_entry&p_p_mode=view','2014-03-18 17:35:10'),(30,1,'/portal/layout?p_l_id=10183&p_v_l_s_g_id=0','2014-03-18 17:35:16'),(31,1,'/portal/layout?p_l_id=10183&p_v_l_s_g_id=0','2014-03-18 17:35:19'),(32,1,'/portal/logout','2014-03-18 17:35:20'),(33,2,'/portal/layout?p_l_id=10183&p_v_l_s_g_id=0','2014-03-18 17:35:24'),(34,2,'/portal/layout?p_l_id=10183&p_v_l_s_g_id=0','2014-03-18 17:35:27'),(35,2,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:35:29'),(36,2,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:35:32'),(37,2,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:35:36'),(38,2,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:35:41'),(39,2,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:35:41'),(40,2,'/portal/layout?p_l_id=10183&p_v_l_s_g_id=0','2014-03-18 17:35:45'),(41,2,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:35:48'),(42,2,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:35:49'),(43,2,'/portal/layout?p_l_id=10183&p_v_l_s_g_id=0','2014-03-18 17:35:50'),(44,2,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:35:52'),(45,2,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:35:54'),(46,2,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:35:55'),(47,2,'/portal/layout?p_l_id=10183&p_v_l_s_g_id=0','2014-03-18 17:35:57'),(48,2,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:35:59'),(49,2,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:36:00'),(50,2,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:36:03'),(51,2,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:36:05'),(52,2,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:36:06'),(53,2,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:36:08'),(54,2,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:36:10'),(55,2,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:36:12'),(56,2,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:36:14'),(57,2,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:36:16'),(58,2,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:36:19'),(59,2,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:36:19'),(60,2,'/portal/layout?p_l_id=10183&p_v_l_s_g_id=0','2014-03-18 17:36:20'),(61,2,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:36:22'),(62,2,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:36:24'),(63,2,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:36:25'),(64,2,'/portal/layout?p_l_id=10183&p_v_l_s_g_id=0','2014-03-18 17:36:26'),(65,2,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:36:28'),(66,2,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:36:29'),(67,2,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:36:33'),(68,2,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:36:35'),(69,2,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:36:35'),(70,2,'/portal/layout?p_l_id=10183&p_v_l_s_g_id=0','2014-03-18 17:36:36'),(71,2,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:36:38'),(72,2,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:36:40'),(73,2,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:36:41'),(74,2,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:36:44'),(75,2,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:36:49'),(76,2,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:36:49'),(77,2,'/portal/json_service','2014-03-18 17:36:55'),(78,2,'/portal/layout?p_l_id=10183&p_v_l_s_g_id=0','2014-03-18 17:36:58'),(79,2,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:36:59'),(80,2,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:37:01'),(81,2,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:37:02'),(82,2,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:37:04'),(83,2,'/portal/layout?p_l_id=10183&p_v_l_s_g_id=0','2014-03-18 17:37:07'),(84,2,'/portal/layout?p_l_id=10183&p_v_l_s_g_id=0','2014-03-18 17:37:10'),(85,2,'/portal/logout','2014-03-18 17:37:11'),(86,3,'/portal/layout?p_l_id=10183&p_v_l_s_g_id=0','2014-03-18 17:37:16'),(87,3,'/portal/layout?p_l_id=10183&p_v_l_s_g_id=0','2014-03-18 17:37:19'),(88,3,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:37:20'),(89,3,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:37:21'),(90,3,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:37:24'),(91,3,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:37:26'),(92,3,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:37:26'),(93,3,'/portal/layout?p_l_id=10183&p_v_l_s_g_id=0','2014-03-18 17:37:29'),(94,3,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:37:31'),(95,3,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:37:32'),(96,3,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:37:34'),(97,3,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:37:35'),(98,3,'/layouts_admin/get_layouts','2014-03-18 17:37:39'),(99,3,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:37:41'),(100,3,'/layouts_admin/get_layouts','2014-03-18 17:37:42'),(101,3,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:37:44'),(102,3,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:37:44'),(103,3,'/layouts_admin/get_layouts','2014-03-18 17:37:45'),(104,3,'/portal/layout?p_l_id=10472&p_v_l_s_g_id=0','2014-03-18 17:37:49'),(105,3,'/portal/layout?p_l_id=10472&p_v_l_s_g_id=0','2014-03-18 17:37:50'),(106,3,'/portal/update_layout','2014-03-18 17:37:54'),(107,3,'/portal/layout?p_l_id=10183&p_v_l_s_g_id=0','2014-03-18 17:37:57'),(108,3,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:37:58'),(109,3,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:38:00'),(110,3,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:38:01'),(111,3,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:38:03'),(112,3,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:38:06'),(113,3,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:38:06'),(114,3,'/portal/layout?p_l_id=10472&p_v_l_s_g_id=0','2014-03-18 17:38:11'),(115,3,'/portal/layout?p_l_id=10472&p_v_l_s_g_id=0','2014-03-18 17:38:12'),(116,3,'/portal/layout?p_l_id=10472&p_v_l_s_g_id=0','2014-03-18 17:38:13'),(117,3,'/portal/layout?p_l_id=10183&p_v_l_s_g_id=0','2014-03-18 17:38:20'),(118,3,'/portal/layout?p_l_id=10183&p_v_l_s_g_id=0','2014-03-18 17:38:22'),(119,3,'/portal/logout','2014-03-18 17:38:23'),(120,4,'/portal/layout?p_l_id=10183&p_v_l_s_g_id=0','2014-03-18 17:38:27'),(121,4,'/portal/layout?p_l_id=10183&p_v_l_s_g_id=0','2014-03-18 17:38:29'),(122,4,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:38:31'),(123,4,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:38:32'),(124,4,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:38:34'),(125,4,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:38:37'),(126,4,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:38:37'),(127,4,'/portal/layout?p_l_id=10183&p_v_l_s_g_id=0','2014-03-18 17:38:41'),(128,4,'/layouts_admin/update_page','2014-03-18 17:38:43'),(129,4,'/portal/layout?p_l_id=10498&p_v_l_s_g_id=0','2014-03-18 17:38:43'),(130,4,'/portal/layout?p_l_id=10183&p_v_l_s_g_id=0','2014-03-18 17:38:45'),(131,4,'/portal/layout?p_l_id=10498&p_v_l_s_g_id=0','2014-03-18 17:38:46'),(132,4,'/portal/layout?p_l_id=10183&p_v_l_s_g_id=0','2014-03-18 17:38:48'),(133,4,'/portal/layout?p_l_id=10498&p_v_l_s_g_id=0','2014-03-18 17:38:49'),(134,4,'/portal/update_layout','2014-03-18 17:38:53'),(135,4,'/portal/layout?p_l_id=10498&p_v_l_s_g_id=0','2014-03-18 17:38:57'),(136,4,'/portal/layout?p_l_id=10498&p_v_l_s_g_id=0','2014-03-18 17:38:59'),(137,4,'/portal/layout?p_l_id=10183&p_v_l_s_g_id=0','2014-03-18 17:39:02'),(138,4,'/portal/layout?p_l_id=10498&p_v_l_s_g_id=0','2014-03-18 17:39:02'),(139,4,'/portal/layout?p_l_id=10498&p_v_l_s_g_id=0','2014-03-18 17:39:04'),(140,4,'/portal/layout?p_l_id=10498&p_v_l_s_g_id=0','2014-03-18 17:39:04'),(141,4,'/portal/layout?p_l_id=10183&p_v_l_s_g_id=0','2014-03-18 17:39:10'),(142,4,'/portal/layout?p_l_id=10183&p_v_l_s_g_id=0','2014-03-18 17:39:12'),(143,4,'/portal/logout','2014-03-18 17:39:13'),(144,5,'/portal/layout?p_l_id=10183&p_v_l_s_g_id=0','2014-03-18 17:39:17'),(145,5,'/portal/layout?p_l_id=10183&p_v_l_s_g_id=0','2014-03-18 17:39:20'),(146,5,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:39:21'),(147,5,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:39:23'),(148,5,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:39:25'),(149,5,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:39:28'),(150,5,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:39:28'),(151,5,'/portal/layout?p_l_id=10183&p_v_l_s_g_id=0','2014-03-18 17:39:30'),(152,5,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:39:32'),(153,5,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:39:33'),(154,5,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:39:35'),(155,5,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:39:37'),(156,5,'/layouts_admin/get_layouts','2014-03-18 17:39:37'),(157,5,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:39:38'),(158,5,'/layouts_admin/get_layouts','2014-03-18 17:39:39'),(159,5,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:39:42'),(160,5,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:39:42'),(161,5,'/layouts_admin/get_layouts','2014-03-18 17:39:43'),(162,5,'/portal/layout?p_l_id=10183&p_v_l_s_g_id=0','2014-03-18 17:39:44'),(163,5,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:39:46'),(164,5,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:39:48'),(165,5,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:39:49'),(166,5,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:39:52'),(167,5,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:39:53'),(168,5,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:39:56'),(169,5,'/portal/layout?p_l_id=10183&p_v_l_s_g_id=0','2014-03-18 17:41:02'),(170,5,'/portal/layout?p_l_id=10183&p_v_l_s_g_id=0','2014-03-18 17:41:05'),(171,5,'/portal/logout','2014-03-18 17:41:07'),(172,6,'/portal/layout?p_l_id=10183&p_v_l_s_g_id=0','2014-03-18 17:41:11'),(173,6,'/portal/layout?p_l_id=10183&p_v_l_s_g_id=0','2014-03-18 17:41:13'),(174,6,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:41:15'),(175,6,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:41:16'),(176,6,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:41:19'),(177,6,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:41:21'),(178,6,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:41:21'),(179,6,'/portal/layout?p_l_id=10183&p_v_l_s_g_id=0','2014-03-18 17:41:23'),(180,6,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:41:25'),(181,6,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:41:27'),(182,6,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:41:29'),(183,6,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:41:30'),(184,6,'/layouts_admin/get_layouts','2014-03-18 17:41:31'),(185,6,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:41:32'),(186,6,'/layouts_admin/get_layouts','2014-03-18 17:41:33'),(187,6,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:41:35'),(188,6,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:41:35'),(189,6,'/layouts_admin/get_layouts','2014-03-18 17:41:36'),(190,6,'/portal/layout?p_l_id=10526&p_v_l_s_g_id=0','2014-03-18 17:41:40'),(191,6,'/portal/layout?p_l_id=10526&p_v_l_s_g_id=0','2014-03-18 17:41:41'),(192,6,'/portal/update_layout','2014-03-18 17:41:45'),(193,6,'/portal/layout?p_l_id=10183&p_v_l_s_g_id=0','2014-03-18 17:41:46'),(194,6,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:41:48'),(195,6,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:41:50'),(196,6,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:41:51'),(197,6,'/portal/json_service','2014-03-18 17:41:52'),(198,6,'/portal/json_service','2014-03-18 17:41:53'),(199,6,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:41:53'),(200,6,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:41:53'),(201,6,'/portal/json_service','2014-03-18 17:41:54'),(202,6,'/portal/layout?p_l_id=10183&p_v_l_s_g_id=0','2014-03-18 17:41:55'),(203,6,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:41:57'),(204,6,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:41:58'),(205,6,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:42:00'),(206,6,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:42:02'),(207,6,'/portal/layout?p_l_id=10183&p_v_l_s_g_id=0','2014-03-18 17:42:08'),(208,6,'/portal/layout?p_l_id=10183&p_v_l_s_g_id=0','2014-03-18 17:42:11'),(209,6,'/portal/logout','2014-03-18 17:42:12'),(210,7,'/portal/layout?p_l_id=10183&p_v_l_s_g_id=0','2014-03-18 17:42:18'),(211,7,'/portal/layout?p_l_id=10183&p_v_l_s_g_id=0','2014-03-18 17:42:20'),(212,7,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:42:21'),(213,7,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:42:22'),(214,7,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:42:25'),(215,7,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:42:28'),(216,7,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:42:28'),(217,7,'/portal/layout?p_l_id=10183&p_v_l_s_g_id=0','2014-03-18 17:42:36'),(218,7,'/portal/layout?p_l_id=10183&p_v_l_s_g_id=0','2014-03-18 17:42:39'),(219,7,'/portal/logout','2014-03-18 17:42:41'),(220,8,'/portal/layout?p_l_id=10183&p_v_l_s_g_id=0','2014-03-18 17:42:45'),(221,8,'/portal/layout?p_l_id=10183&p_v_l_s_g_id=0','2014-03-18 17:42:49'),(222,8,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:42:50'),(223,8,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:42:51'),(224,8,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:42:54'),(225,8,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:42:56'),(226,8,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:42:56'),(227,8,'/portal/layout?p_l_id=10183&p_v_l_s_g_id=0','2014-03-18 17:42:59'),(228,8,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:43:00'),(229,8,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:43:01'),(230,8,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:43:04'),(231,8,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:43:06'),(232,8,'/layouts_admin/get_layouts','2014-03-18 17:43:06'),(233,8,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:43:08'),(234,8,'/layouts_admin/get_layouts','2014-03-18 17:43:09'),(235,8,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:43:11'),(236,8,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:43:11'),(237,8,'/layouts_admin/get_layouts','2014-03-18 17:43:12'),(238,8,'/portal/layout?p_l_id=10561&p_v_l_s_g_id=0','2014-03-18 17:43:15'),(239,8,'/portal/layout?p_l_id=10561&p_v_l_s_g_id=0','2014-03-18 17:43:16'),(240,8,'/portal/update_layout','2014-03-18 17:43:21'),(241,8,'/portal/layout?p_l_id=10183&p_v_l_s_g_id=0','2014-03-18 17:43:22'),(242,8,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:43:24'),(243,8,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:43:26'),(244,8,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:43:27'),(245,8,'/portal/portlet_url','2014-03-18 17:43:29'),(246,8,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:43:30'),(247,8,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:43:32'),(248,8,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:43:41'),(249,8,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:43:41'),(250,8,'/portal/layout?p_l_id=10561&p_v_l_s_g_id=0','2014-03-18 17:43:45'),(251,8,'/portal/layout?p_l_id=10561&p_v_l_s_g_id=0','2014-03-18 17:43:46'),(252,8,'/portal/layout?p_l_id=10561&p_v_l_s_g_id=0','2014-03-18 17:43:47'),(253,8,'/portal/portlet_url','2014-03-18 17:43:49'),(254,8,'/portal/layout?p_l_id=10561&p_v_l_s_g_id=0','2014-03-18 17:43:49'),(255,8,'/portal/layout?p_l_id=10561&p_v_l_s_g_id=0','2014-03-18 17:43:51'),(256,8,'/portal/layout?p_l_id=10561&p_v_l_s_g_id=0','2014-03-18 17:43:53'),(257,8,'/portal/layout?p_l_id=10561&p_v_l_s_g_id=0','2014-03-18 17:43:53'),(258,8,'/portal/layout?p_l_id=10561&p_v_l_s_g_id=0','2014-03-18 17:43:57'),(259,8,'/portal/layout?p_l_id=10561&p_v_l_s_g_id=0','2014-03-18 17:43:58'),(260,8,'/portal/layout?p_l_id=10561&p_v_l_s_g_id=0','2014-03-18 17:43:59'),(261,8,'/portal/layout?p_l_id=10561&p_v_l_s_g_id=0','2014-03-18 17:44:03'),(262,8,'/portal/layout?p_l_id=10561&p_v_l_s_g_id=0','2014-03-18 17:44:03'),(263,8,'/portal/layout?p_l_id=10561&p_v_l_s_g_id=0','2014-03-18 17:44:06'),(264,8,'/portal/layout?p_l_id=10183&p_v_l_s_g_id=0','2014-03-18 17:44:07'),(265,8,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:44:09'),(266,8,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:44:11'),(267,8,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:44:12'),(268,8,'/portal/portlet_url','2014-03-18 17:44:14'),(269,8,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:44:15'),(270,8,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:44:17'),(271,8,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:44:19'),(272,8,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:44:21'),(273,8,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:44:25'),(274,8,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:44:25'),(275,8,'/portal/layout?p_l_id=10183&p_v_l_s_g_id=0','2014-03-18 17:44:27'),(276,8,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:44:28'),(277,8,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:44:30'),(278,8,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:44:31'),(279,8,'/portal/portlet_url','2014-03-18 17:44:33'),(280,8,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:44:33'),(281,8,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:44:35'),(282,8,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:44:37'),(283,8,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:44:38'),(284,8,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:44:40'),(285,8,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:44:44'),(286,8,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:44:44'),(287,8,'/portal/layout?p_l_id=10183&p_v_l_s_g_id=0','2014-03-18 17:44:50'),(288,8,'/portal/layout?p_l_id=10183&p_v_l_s_g_id=0','2014-03-18 17:44:53'),(289,8,'/portal/logout','2014-03-18 17:44:55'),(290,9,'/portal/layout?p_l_id=10183&p_v_l_s_g_id=0','2014-03-18 17:44:59'),(291,9,'/portal/layout?p_l_id=10183&p_v_l_s_g_id=0','2014-03-18 17:45:00'),(292,9,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:45:02'),(293,9,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:45:03'),(294,9,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:45:06'),(295,9,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:45:09'),(296,9,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:45:09'),(297,9,'/portal/layout?p_l_id=10183&p_v_l_s_g_id=0','2014-03-18 17:45:16'),(298,9,'/portal/layout?p_l_id=10183&p_v_l_s_g_id=0','2014-03-18 17:45:19'),(299,9,'/portal/logout','2014-03-18 17:45:20'),(317,11,'/portal/layout?p_l_id=10183&p_v_l_s_g_id=0','2014-03-18 17:46:17'),(318,11,'/portal/update_terms_of_use','2014-03-18 17:46:18'),(319,11,'/portal/layout?p_l_id=10183&p_v_l_s_g_id=0','2014-03-18 17:46:18'),(320,11,'/portal/update_password','2014-03-18 17:46:20'),(321,11,'/portal/layout?p_l_id=10183&p_v_l_s_g_id=0','2014-03-18 17:46:20'),(322,11,'/portal/update_reminder_query','2014-03-18 17:46:22'),(323,11,'/portal/layout?p_l_id=10183&p_v_l_s_g_id=0','2014-03-18 17:46:22'),(324,11,'/portal/layout?p_l_id=10183&p_v_l_s_g_id=0','2014-03-18 17:46:25'),(325,11,'/portal/logout','2014-03-18 17:46:26'),(343,13,'/portal/layout?p_l_id=10183&p_v_l_s_g_id=0','2014-03-18 17:47:12'),(344,13,'/portal/layout?p_l_id=10183&p_v_l_s_g_id=0','2014-03-18 17:47:15'),(345,13,'/portal/logout','2014-03-18 17:47:16'),(346,14,'/portal/layout?p_l_id=10183&p_v_l_s_g_id=0','2014-03-18 17:47:21'),(347,14,'/portal/layout?p_l_id=10183&p_v_l_s_g_id=0','2014-03-18 17:47:28'),(348,14,'/portal/layout?p_l_id=10183&p_v_l_s_g_id=0','2014-03-18 17:47:30'),(349,14,'/portal/logout','2014-03-18 17:47:32'),(350,15,'/portal/layout?p_l_id=10183&p_v_l_s_g_id=0','2014-03-18 17:47:36'),(351,15,'/portal/layout?p_l_id=10183&p_v_l_s_g_id=0','2014-03-18 17:47:38'),(352,15,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:47:39'),(353,15,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:47:41'),(354,15,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:47:44'),(355,15,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:47:44'),(356,15,'/portal/layout?p_l_id=10183&p_v_l_s_g_id=0','2014-03-18 17:47:46'),(357,15,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:47:47'),(358,15,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:47:49'),(359,15,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:47:52'),(360,15,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:47:52'),(361,15,'/portal/layout?p_l_id=10183&p_v_l_s_g_id=0','2014-03-18 17:47:58'),(362,15,'/portal/layout?p_l_id=10183&p_v_l_s_g_id=0','2014-03-18 17:48:01'),(363,15,'/portal/logout','2014-03-18 17:48:02'),(364,16,'/portal/layout?p_l_id=10183&p_v_l_s_g_id=0','2014-03-18 17:48:06'),(365,16,'/portal/layout?p_l_id=10183&p_v_l_s_g_id=0','2014-03-18 17:48:12'),(366,16,'/layouts_admin/update_page','2014-03-18 17:48:15'),(367,16,'/portal/layout?p_l_id=10627&p_v_l_s_g_id=0','2014-03-18 17:48:15'),(368,16,'/portal/layout?p_l_id=10183&p_v_l_s_g_id=0','2014-03-18 17:48:17'),(369,16,'/portal/layout?p_l_id=10627&p_v_l_s_g_id=0','2014-03-18 17:48:18'),(370,16,'/portal/layout?p_l_id=10183&p_v_l_s_g_id=0','2014-03-18 17:48:20'),(371,16,'/portal/layout?p_l_id=10627&p_v_l_s_g_id=0','2014-03-18 17:48:21'),(372,16,'/portal/update_layout','2014-03-18 17:48:25'),(373,16,'/portal/layout?p_l_id=10627&p_v_l_s_g_id=0','2014-03-18 17:48:27'),(374,16,'/portal/layout?p_l_id=10627&p_v_l_s_g_id=0','2014-03-18 17:48:29'),(375,16,'/portal/layout?p_l_id=10627&p_v_l_s_g_id=0','2014-03-18 17:48:29'),(376,16,'/portal/layout?p_l_id=10627&p_v_l_s_g_id=0','2014-03-18 17:48:31'),(377,16,'/portal/layout?p_l_id=10627&p_v_l_s_g_id=0','2014-03-18 17:48:34'),(378,16,'/portal/layout?p_l_id=10627&p_v_l_s_g_id=0','2014-03-18 17:48:34'),(379,16,'/portal/layout?p_l_id=10627&p_v_l_s_g_id=0','2014-03-18 17:48:38'),(380,16,'/portal/layout?p_l_id=10627&p_v_l_s_g_id=0','2014-03-18 17:48:39'),(381,16,'/portal/layout?p_l_id=10627&p_v_l_s_g_id=0','2014-03-18 17:48:41'),(382,16,'/portal/layout?p_l_id=10627&p_v_l_s_g_id=0','2014-03-18 17:48:53'),(383,16,'/portal/layout?p_l_id=10627&p_v_l_s_g_id=0','2014-03-18 17:48:53'),(384,16,'/portal/layout?p_l_id=10627&p_v_l_s_g_id=0','2014-03-18 17:48:56'),(385,16,'/portal/layout?p_l_id=10627&p_v_l_s_g_id=0','2014-03-18 17:48:57'),(386,16,'/portal/layout?p_l_id=10627&p_v_l_s_g_id=0','2014-03-18 17:49:01'),(387,16,'/portal/layout?p_l_id=10627&p_v_l_s_g_id=0','2014-03-18 17:49:01'),(388,16,'/portal/layout?p_l_id=10627&p_v_l_s_g_id=0','2014-03-18 17:49:03'),(389,16,'/portal/layout?p_l_id=10183&p_v_l_s_g_id=0','2014-03-18 17:49:07'),(390,16,'/portal/layout?p_l_id=10183&p_v_l_s_g_id=0','2014-03-18 17:49:10'),(391,16,'/portal/logout','2014-03-18 17:49:12'),(392,17,'/portal/layout?p_l_id=10183&p_v_l_s_g_id=0','2014-03-18 17:49:16'),(393,17,'/portal/layout?p_l_id=10183&p_v_l_s_g_id=0','2014-03-18 17:49:19'),(394,17,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:49:20'),(395,17,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:49:22'),(396,17,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:49:25'),(397,17,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:49:28'),(398,17,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:49:28'),(399,17,'/portal/layout?p_l_id=10183&p_v_l_s_g_id=0','2014-03-18 17:49:31'),(400,17,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:49:33'),(401,17,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:49:34'),(402,17,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:49:36'),(403,17,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:49:40'),(404,17,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:49:40'),(405,17,'/portal/json_service','2014-03-18 17:49:41'),(406,17,'/portal/json_service','2014-03-18 17:49:41'),(407,17,'/portal/layout?p_l_id=10183&p_v_l_s_g_id=0','2014-03-18 17:49:44'),(408,17,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:49:46'),(409,17,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:49:47'),(410,17,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:49:49'),(411,17,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:49:51'),(412,17,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:49:53'),(413,17,'/portal/json_service','2014-03-18 17:49:54'),(414,17,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:49:57'),(415,17,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:49:57'),(416,17,'/portal/json_service','2014-03-18 17:49:58'),(417,17,'/portal/layout?p_l_id=10183&p_v_l_s_g_id=0','2014-03-18 17:50:01'),(418,17,'/portal/logout','2014-03-18 17:50:03'),(419,18,'/portal/layout?p_l_id=10183&p_v_l_s_g_id=0','2014-03-18 17:50:07'),(420,18,'/portal/update_terms_of_use','2014-03-18 17:50:08'),(421,18,'/portal/layout?p_l_id=10183&p_v_l_s_g_id=0','2014-03-18 17:50:08'),(422,18,'/portal/update_password','2014-03-18 17:50:10'),(423,18,'/portal/layout?p_l_id=10183&p_v_l_s_g_id=0','2014-03-18 17:50:10'),(424,18,'/portal/update_reminder_query','2014-03-18 17:50:12'),(425,18,'/portal/layout?p_l_id=10183&p_v_l_s_g_id=0','2014-03-18 17:50:12'),(426,18,'/portal/layout?p_l_id=10183&p_v_l_s_g_id=0','2014-03-18 17:50:14'),(427,18,'/portal/logout','2014-03-18 17:50:15'),(428,19,'/portal/layout?p_l_id=10183&p_v_l_s_g_id=0','2014-03-18 17:50:20'),(429,19,'/portal/layout?p_l_id=10183&p_v_l_s_g_id=0','2014-03-18 17:50:23'),(430,19,'/portal/logout','2014-03-18 17:50:24'),(431,20,'/portal/layout?p_l_id=10183&p_v_l_s_g_id=0','2014-03-18 17:50:29'),(432,20,'/portal/layout?p_l_id=10659&p_v_l_s_g_id=0','2014-03-18 17:50:30'),(433,20,'/portal/layout?p_l_id=10659&p_v_l_s_g_id=0','2014-03-18 17:50:36'),(434,20,'/portal/layout?p_l_id=10659&p_v_l_s_g_id=0','2014-03-18 17:50:39'),(435,20,'/portal/layout?p_l_id=10659&p_v_l_s_g_id=0','2014-03-18 17:50:40'),(436,20,'/portal/layout?p_l_id=10659&p_v_l_s_g_id=0','2014-03-18 17:50:42'),(437,20,'/portal/layout?p_l_id=10659&p_v_l_s_g_id=0','2014-03-18 17:50:42'),(438,20,'/portal/layout?p_l_id=10183&p_v_l_s_g_id=0','2014-03-18 17:50:48'),(439,20,'/portal/layout?p_l_id=10183&p_v_l_s_g_id=0','2014-03-18 17:50:51'),(440,20,'/portal/logout','2014-03-18 17:50:52'),(441,21,'/portal/layout?p_l_id=10183&p_v_l_s_g_id=0','2014-03-18 17:50:56'),(442,21,'/portal/layout?p_l_id=10183&p_v_l_s_g_id=0','2014-03-18 17:50:59'),(443,21,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:51:01'),(444,21,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:51:02'),(445,21,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:51:05'),(446,21,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:51:07'),(447,21,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:51:07'),(448,21,'/portal/layout?p_l_id=10183&p_v_l_s_g_id=0','2014-03-18 17:51:10'),(449,21,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:51:12'),(450,21,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:51:13'),(451,21,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:51:15'),(452,21,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:51:17'),(453,21,'/layouts_admin/get_layouts','2014-03-18 17:51:18'),(454,21,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:51:19'),(455,21,'/layouts_admin/get_layouts','2014-03-18 17:51:20'),(456,21,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:51:23'),(457,21,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:51:23'),(458,21,'/layouts_admin/get_layouts','2014-03-18 17:51:24'),(459,21,'/portal/layout?p_l_id=10183&p_v_l_s_g_id=0','2014-03-18 17:51:25'),(460,21,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:51:27'),(461,21,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:51:29'),(462,21,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:51:30'),(463,21,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:51:43'),(464,21,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:51:44'),(465,21,'/portal/layout?p_l_id=10706&p_v_l_s_g_id=0','2014-03-18 17:51:49'),(466,21,'/portal/layout?p_l_id=10706&p_v_l_s_g_id=0','2014-03-18 17:51:51'),(467,21,'/portal/update_layout','2014-03-18 17:51:56'),(468,21,'/staging_bar/view_layout_revision_details','2014-03-18 17:51:57'),(469,21,'/portal/layout?p_l_id=10706&p_v_l_s_g_id=0','2014-03-18 17:52:01'),(470,21,'/portal/layout?p_l_id=10706&p_v_l_s_g_id=0','2014-03-18 17:52:03'),(471,21,'/portal/layout?p_l_id=10706&p_v_l_s_g_id=0','2014-03-18 17:52:04'),(472,21,'/portal/layout?p_l_id=10706&p_v_l_s_g_id=0','2014-03-18 17:52:07'),(473,21,'/portal/layout?p_l_id=10706&p_v_l_s_g_id=0','2014-03-18 17:52:07'),(474,21,'/portal/layout?p_l_id=10183&p_v_l_s_g_id=0','2014-03-18 17:52:18'),(475,21,'/portal/layout?p_l_id=10183&p_v_l_s_g_id=0','2014-03-18 17:52:20'),(476,21,'/portal/logout','2014-03-18 17:52:21'),(477,22,'/portal/layout?p_l_id=10183&p_v_l_s_g_id=0','2014-03-18 17:52:26'),(478,22,'/portal/layout?p_l_id=10183&p_v_l_s_g_id=0','2014-03-18 17:52:31'),(479,22,'/layouts_admin/update_page','2014-03-18 17:52:33'),(480,22,'/portal/layout?p_l_id=10737&p_v_l_s_g_id=0','2014-03-18 17:52:33'),(481,22,'/portal/layout?p_l_id=10183&p_v_l_s_g_id=0','2014-03-18 17:52:36'),(482,22,'/portal/layout?p_l_id=10737&p_v_l_s_g_id=0','2014-03-18 17:52:37'),(483,22,'/portal/layout?p_l_id=10183&p_v_l_s_g_id=0','2014-03-18 17:52:39'),(484,22,'/portal/layout?p_l_id=10737&p_v_l_s_g_id=0','2014-03-18 17:52:40'),(485,22,'/portal/update_layout','2014-03-18 17:52:44'),(486,22,'/portal/layout?p_l_id=10737&p_v_l_s_g_id=0','2014-03-18 17:52:46'),(487,22,'/portal/layout?p_l_id=10737&p_v_l_s_g_id=0','2014-03-18 17:52:50'),(488,22,'/portal/layout?p_l_id=10737&p_v_l_s_g_id=0','2014-03-18 17:52:50'),(489,22,'/portal/layout?p_l_id=10183&p_v_l_s_g_id=0','2014-03-18 17:52:54'),(490,22,'/portal/layout?p_l_id=10737&p_v_l_s_g_id=0','2014-03-18 17:52:55'),(491,22,'/portal/layout?p_l_id=10737&p_v_l_s_g_id=0','2014-03-18 17:52:56'),(492,22,'/portal/layout?p_l_id=10737&p_v_l_s_g_id=0','2014-03-18 17:52:58'),(493,22,'/portal/layout?p_l_id=10737&p_v_l_s_g_id=0','2014-03-18 17:52:59'),(494,22,'/portal/layout?p_l_id=10183&p_v_l_s_g_id=0','2014-03-18 17:53:06'),(495,22,'/portal/layout?p_l_id=10183&p_v_l_s_g_id=0','2014-03-18 17:53:09'),(496,22,'/portal/logout','2014-03-18 17:53:10'),(497,23,'/portal/layout?p_l_id=10183&p_v_l_s_g_id=0','2014-03-18 17:53:15'),(498,23,'/portal/layout?p_l_id=10183&p_v_l_s_g_id=0','2014-03-18 17:53:19'),(499,23,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:53:21'),(500,23,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:53:22'),(501,23,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:53:25'),(502,23,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:53:27'),(503,23,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:53:27'),(504,23,'/portal/layout?p_l_id=10183&p_v_l_s_g_id=0','2014-03-18 17:53:30'),(505,23,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:53:32'),(506,23,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:53:33'),(507,23,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:53:36'),(508,23,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:53:38'),(509,23,'/layouts_admin/get_layouts','2014-03-18 17:53:39'),(510,23,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:53:40'),(511,23,'/layouts_admin/get_layouts','2014-03-18 17:53:41'),(512,23,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:53:44'),(513,23,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:53:44'),(514,23,'/layouts_admin/get_layouts','2014-03-18 17:53:45'),(515,23,'/portal/layout?p_l_id=10765&p_v_l_s_g_id=0','2014-03-18 17:53:50'),(516,23,'/portal/layout?p_l_id=10765&p_v_l_s_g_id=0','2014-03-18 17:53:51'),(517,23,'/portal/update_layout','2014-03-18 17:53:55'),(518,23,'/portal/layout?p_l_id=10765&p_v_l_s_g_id=0','2014-03-18 17:53:59'),(519,23,'/portal/layout?p_l_id=10765&p_v_l_s_g_id=0','2014-03-18 17:54:00'),(520,23,'/portal/update_layout','2014-03-18 17:54:04'),(521,23,'/portal/layout?p_l_id=10765&p_v_l_s_g_id=0','2014-03-18 17:54:07'),(522,23,'/portal/layout?p_l_id=10765&p_v_l_s_g_id=0','2014-03-18 17:54:08'),(523,23,'/portal/update_layout','2014-03-18 17:54:11'),(524,23,'/portal/layout?p_l_id=10765&p_v_l_s_g_id=0','2014-03-18 17:54:12'),(525,23,'/portal/layout?p_l_id=10183&p_v_l_s_g_id=0','2014-03-18 17:54:18'),(526,23,'/portal/layout?p_l_id=10183&p_v_l_s_g_id=0','2014-03-18 17:54:20'),(527,23,'/portal/logout','2014-03-18 17:54:22'),(528,24,'/portal/layout?p_l_id=10183&p_v_l_s_g_id=0','2014-03-18 17:54:26'),(529,24,'/portal/layout?p_l_id=10183&p_v_l_s_g_id=0','2014-03-18 17:54:29'),(530,24,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:54:30'),(531,24,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:54:32'),(532,24,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:54:35'),(533,24,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:54:37'),(534,24,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:54:37'),(535,24,'/portal/layout?p_l_id=10183&p_v_l_s_g_id=0','2014-03-18 17:54:39'),(536,24,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:54:41'),(537,24,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:54:43'),(538,24,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:54:45'),(539,24,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:54:48'),(540,24,'/layouts_admin/get_layouts','2014-03-18 17:54:48'),(541,24,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:54:50'),(542,24,'/layouts_admin/get_layouts','2014-03-18 17:54:51'),(543,24,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:54:53'),(544,24,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:54:53'),(545,24,'/layouts_admin/get_layouts','2014-03-18 17:54:54'),(546,24,'/portal/layout?p_l_id=10782&p_v_l_s_g_id=0','2014-03-18 17:54:58'),(547,24,'/portal/layout?p_l_id=10782&p_v_l_s_g_id=0','2014-03-18 17:54:59'),(548,24,'/portal/update_layout','2014-03-18 17:55:03'),(549,24,'/portal/layout?p_l_id=10782&p_v_l_s_g_id=0','2014-03-18 17:55:09'),(550,24,'/portal/layout?p_l_id=10782&p_v_l_s_g_id=0','2014-03-18 17:55:13'),(551,24,'/portal/layout?p_l_id=10782&p_v_l_s_g_id=0','2014-03-18 17:55:13'),(552,24,'/portal/upload_progress_poller?uploadProgressId=dlFileEntryUploadProgress','2014-03-18 17:55:14'),(553,24,'/portal/layout?p_l_id=10782&p_v_l_s_g_id=0','2014-03-18 17:55:18'),(554,24,'/portal/layout?p_l_id=10782&p_v_l_s_g_id=0','2014-03-18 17:55:20'),(555,24,'/portal/layout?p_l_id=10183&p_v_l_s_g_id=0','2014-03-18 17:56:31'),(556,24,'/portal/layout?p_l_id=10183&p_v_l_s_g_id=0','2014-03-18 17:56:33'),(557,24,'/portal/logout','2014-03-18 17:56:35'),(558,25,'/portal/layout?p_l_id=10183&p_v_l_s_g_id=0','2014-03-18 17:56:40'),(559,25,'/portal/layout?p_l_id=10183&p_v_l_s_g_id=0','2014-03-18 17:56:42'),(560,25,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:56:43'),(561,25,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:56:44'),(562,25,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:56:46'),(563,25,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:56:47'),(564,25,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:56:49'),(565,25,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:56:49'),(566,25,'/portal/layout?p_l_id=10183&p_v_l_s_g_id=0','2014-03-18 17:56:51'),(567,25,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:56:53'),(568,25,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:56:54'),(569,25,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:56:56'),(570,25,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:56:57'),(571,25,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:56:58'),(572,25,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:56:58'),(573,25,'/portal/layout?p_l_id=10183&p_v_l_s_g_id=0','2014-03-18 17:57:05'),(574,25,'/portal/layout?p_l_id=10183&p_v_l_s_g_id=0','2014-03-18 17:57:08'),(575,25,'/portal/logout','2014-03-18 17:57:10'),(576,26,'/portal/layout?p_l_id=10183&p_v_l_s_g_id=0','2014-03-18 17:57:14'),(577,26,'/portal/layout?p_l_id=10183&p_v_l_s_g_id=0','2014-03-18 17:57:17'),(578,26,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:57:19'),(579,26,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:57:20'),(580,26,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:57:24'),(581,26,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:57:27'),(582,26,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:57:27'),(583,26,'/portal/layout?p_l_id=10183&p_v_l_s_g_id=0','2014-03-18 17:57:30'),(584,26,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:57:32'),(585,26,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:57:33'),(586,26,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:57:35'),(587,26,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:57:37'),(588,26,'/layouts_admin/get_layouts','2014-03-18 17:57:38'),(589,26,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:57:40'),(590,26,'/layouts_admin/get_layouts','2014-03-18 17:57:40'),(591,26,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:57:43'),(592,26,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:57:43'),(593,26,'/layouts_admin/get_layouts','2014-03-18 17:57:44'),(594,26,'/portal/layout?p_l_id=10183&p_v_l_s_g_id=0','2014-03-18 17:57:46'),(595,26,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:57:47'),(596,26,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:57:49'),(597,26,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:57:51'),(598,26,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:57:53'),(599,26,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:57:55'),(600,26,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:57:55'),(601,26,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:57:57'),(602,26,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:57:59'),(603,26,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:58:01'),(604,26,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:58:01'),(605,26,'/portal/layout?p_l_id=10183&p_v_l_s_g_id=0','2014-03-18 17:58:04'),(606,26,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:58:05'),(607,26,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:58:08'),(608,26,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:58:09'),(609,26,'/layouts_admin/get_layouts','2014-03-18 17:58:10'),(610,26,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:58:12'),(611,26,'/portal/json_service','2014-03-18 17:58:14'),(612,26,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:58:14'),(613,26,'/layouts_admin/get_layouts','2014-03-18 17:58:15'),(614,26,'/portal/layout?p_l_id=10183&p_v_l_s_g_id=0','2014-03-18 17:58:17'),(615,26,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:58:18'),(616,26,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:58:20'),(617,26,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:58:21'),(618,26,'/layouts_admin/get_layouts','2014-03-18 17:58:22'),(619,26,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:58:24'),(620,26,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:58:26'),(621,26,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:58:28'),(622,26,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:58:29'),(623,26,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:58:29'),(624,26,'/portal/layout?p_l_id=10183&p_v_l_s_g_id=0','2014-03-18 17:58:37'),(625,26,'/portal/layout?p_l_id=10183&p_v_l_s_g_id=0','2014-03-18 17:58:40'),(626,26,'/portal/logout','2014-03-18 17:58:41'),(627,27,'/portal/layout?p_l_id=10183&p_v_l_s_g_id=0','2014-03-18 17:58:46'),(628,27,'/portal/layout?p_l_id=10183&p_v_l_s_g_id=0','2014-03-18 17:58:50'),(629,27,'/layouts_admin/update_page','2014-03-18 17:58:52'),(630,27,'/portal/layout?p_l_id=10821&p_v_l_s_g_id=0','2014-03-18 17:58:52'),(631,27,'/portal/layout?p_l_id=10183&p_v_l_s_g_id=0','2014-03-18 17:58:55'),(632,27,'/portal/layout?p_l_id=10821&p_v_l_s_g_id=0','2014-03-18 17:58:56'),(633,27,'/portal/update_layout','2014-03-18 17:59:00'),(634,27,'/portal/layout?p_l_id=10183&p_v_l_s_g_id=0','2014-03-18 17:59:01'),(635,27,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:59:02'),(636,27,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:59:04'),(637,27,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:59:06'),(638,27,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:59:07'),(639,27,'/portal/layout?p_l_id=10183&p_v_l_s_g_id=0','2014-03-18 17:59:14'),(640,27,'/portal/layout?p_l_id=10183&p_v_l_s_g_id=0','2014-03-18 17:59:17'),(641,27,'/portal/logout','2014-03-18 17:59:19'),(642,28,'/portal/layout?p_l_id=10183&p_v_l_s_g_id=0','2014-03-18 17:59:23'),(643,28,'/portal/layout?p_l_id=10183&p_v_l_s_g_id=0','2014-03-18 17:59:27'),(644,28,'/layouts_admin/update_page','2014-03-18 17:59:30'),(645,28,'/portal/layout?p_l_id=10832&p_v_l_s_g_id=0','2014-03-18 17:59:30'),(646,28,'/portal/layout?p_l_id=10183&p_v_l_s_g_id=0','2014-03-18 17:59:33'),(647,28,'/portal/layout?p_l_id=10832&p_v_l_s_g_id=0','2014-03-18 17:59:33'),(648,28,'/portal/update_layout','2014-03-18 17:59:38'),(649,28,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:59:39'),(650,28,'/portal/json_service','2014-03-18 17:59:40'),(651,28,'/portal/json_service','2014-03-18 17:59:40'),(652,28,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:59:43'),(653,28,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 17:59:43'),(654,28,'/portal/json_service','2014-03-18 17:59:44'),(655,28,'/portal/layout?p_l_id=10183&p_v_l_s_g_id=0','2014-03-18 17:59:47'),(656,28,'/portal/layout?p_l_id=10832&p_v_l_s_g_id=0','2014-03-18 17:59:48'),(657,28,'/portal/layout?p_l_id=10832&p_v_l_s_g_id=0','2014-03-18 17:59:51'),(658,28,'/portal/layout?p_l_id=10832&p_v_l_s_g_id=0','2014-03-18 17:59:52'),(659,28,'/portal/layout?p_l_id=10832&p_v_l_s_g_id=0','2014-03-18 17:59:53'),(660,28,'/portal/layout?p_l_id=10183&p_v_l_s_g_id=0','2014-03-18 17:59:59'),(661,28,'/portal/layout?p_l_id=10183&p_v_l_s_g_id=0','2014-03-18 18:00:01'),(662,28,'/portal/logout','2014-03-18 18:00:03'),(663,29,'/portal/layout?p_l_id=10183&p_v_l_s_g_id=0','2014-03-18 18:00:07'),(664,29,'/portal/layout?p_l_id=10183&p_v_l_s_g_id=0','2014-03-18 18:00:10'),(665,29,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 18:00:11'),(666,29,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 18:00:13'),(667,29,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 18:00:15'),(668,29,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 18:00:17'),(669,29,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 18:00:19'),(670,29,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 18:00:19'),(671,29,'/portal/layout?p_l_id=10183&p_v_l_s_g_id=0','2014-03-18 18:00:21'),(672,29,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 18:00:23'),(673,29,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 18:00:24'),(674,29,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 18:00:27'),(675,29,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 18:00:30'),(676,29,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 18:00:30'),(677,29,'/portal/json_service','2014-03-18 18:00:31'),(678,29,'/portal/layout?p_l_id=10183&p_v_l_s_g_id=0','2014-03-18 18:00:34'),(679,29,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 18:00:36'),(680,29,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 18:00:38'),(681,29,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 18:00:39'),(682,29,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 18:00:42'),(683,29,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 18:00:44'),(684,29,'/portal/json_service','2014-03-18 18:00:45'),(685,29,'/portal/layout?p_l_id=10183&p_v_l_s_g_id=0','2014-03-18 18:00:55'),(686,29,'/portal/layout?p_l_id=10183&p_v_l_s_g_id=0','2014-03-18 18:00:58'),(687,29,'/portal/logout','2014-03-18 18:01:00'),(688,30,'/portal/layout?p_l_id=10183&p_v_l_s_g_id=0','2014-03-18 18:01:04'),(689,30,'/portal/layout?p_l_id=10183&p_v_l_s_g_id=0','2014-03-18 18:01:07'),(690,30,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 18:01:09'),(691,30,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 18:01:10'),(692,30,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 18:01:13'),(693,30,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 18:01:16'),(694,30,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 18:01:16'),(695,30,'/portal/layout?p_l_id=10183&p_v_l_s_g_id=0','2014-03-18 18:01:18'),(696,30,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 18:01:20'),(697,30,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 18:01:21'),(698,30,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 18:01:24'),(699,30,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 18:01:26'),(700,30,'/layouts_admin/get_layouts','2014-03-18 18:01:26'),(701,30,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 18:01:28'),(702,30,'/layouts_admin/get_layouts','2014-03-18 18:01:29'),(703,30,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 18:01:31'),(704,30,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 18:01:31'),(705,30,'/layouts_admin/get_layouts','2014-03-18 18:01:32'),(706,30,'/portal/layout?p_l_id=10183&p_v_l_s_g_id=0','2014-03-18 18:01:33'),(707,30,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 18:01:35'),(708,30,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 18:01:37'),(709,30,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 18:01:39'),(710,30,'/portal/json_service','2014-03-18 18:01:40'),(711,30,'/portal/portlet_url','2014-03-18 18:01:41'),(712,30,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 18:01:41'),(713,30,'/portal/session_click','2014-03-18 18:01:44'),(714,30,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 18:01:46'),(715,30,'/portal/json_service','2014-03-18 18:01:46'),(716,30,'/portal/portlet_url','2014-03-18 18:01:46'),(717,30,'/portal/layout?p_l_id=10175&p_v_l_s_g_id=0','2014-03-18 18:01:46'),(718,30,'/portal/layout?p_l_id=10861&p_v_l_s_g_id=0','2014-03-18 18:01:49'),(719,30,'/portal/layout?p_l_id=10861&p_v_l_s_g_id=0','2014-03-18 18:01:50'),(720,30,'/portal/update_layout','2014-03-18 18:01:53'),(721,30,'/portal/layout?p_l_id=10861&p_v_l_s_g_id=0','2014-03-18 18:01:55'),(722,30,'/portal/layout?p_l_id=10183&p_v_l_s_g_id=0','2014-03-18 18:02:02'),(723,30,'/portal/layout?p_l_id=10183&p_v_l_s_g_id=0','2014-03-18 18:02:06'),(724,30,'/portal/logout','2014-03-18 18:02:08');
/*!40000 ALTER TABLE `UserTrackerPath` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `User_`
--

DROP TABLE IF EXISTS `User_`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `User_` (
  `uuid_` varchar(75) DEFAULT NULL,
  `userId` bigint(20) NOT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `createDate` datetime DEFAULT NULL,
  `modifiedDate` datetime DEFAULT NULL,
  `defaultUser` tinyint(4) DEFAULT NULL,
  `contactId` bigint(20) DEFAULT NULL,
  `password_` varchar(75) DEFAULT NULL,
  `passwordEncrypted` tinyint(4) DEFAULT NULL,
  `passwordReset` tinyint(4) DEFAULT NULL,
  `passwordModifiedDate` datetime DEFAULT NULL,
  `digest` varchar(255) DEFAULT NULL,
  `reminderQueryQuestion` varchar(75) DEFAULT NULL,
  `reminderQueryAnswer` varchar(75) DEFAULT NULL,
  `graceLoginCount` int(11) DEFAULT NULL,
  `screenName` varchar(75) DEFAULT NULL,
  `emailAddress` varchar(75) DEFAULT NULL,
  `facebookId` bigint(20) DEFAULT NULL,
  `openId` varchar(1024) DEFAULT NULL,
  `portraitId` bigint(20) DEFAULT NULL,
  `languageId` varchar(75) DEFAULT NULL,
  `timeZoneId` varchar(75) DEFAULT NULL,
  `greeting` varchar(255) DEFAULT NULL,
  `comments` longtext,
  `firstName` varchar(75) DEFAULT NULL,
  `middleName` varchar(75) DEFAULT NULL,
  `lastName` varchar(75) DEFAULT NULL,
  `jobTitle` varchar(100) DEFAULT NULL,
  `loginDate` datetime DEFAULT NULL,
  `loginIP` varchar(75) DEFAULT NULL,
  `lastLoginDate` datetime DEFAULT NULL,
  `lastLoginIP` varchar(75) DEFAULT NULL,
  `lastFailedLoginDate` datetime DEFAULT NULL,
  `failedLoginAttempts` int(11) DEFAULT NULL,
  `lockout` tinyint(4) DEFAULT NULL,
  `lockoutDate` datetime DEFAULT NULL,
  `agreedToTermsOfUse` tinyint(4) DEFAULT NULL,
  `emailAddressVerified` tinyint(4) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  PRIMARY KEY (`userId`),
  UNIQUE KEY `IX_615E9F7A` (`companyId`,`emailAddress`),
  UNIQUE KEY `IX_C5806019` (`companyId`,`screenName`),
  UNIQUE KEY `IX_9782AD88` (`companyId`,`userId`),
  UNIQUE KEY `IX_5ADBE171` (`contactId`),
  KEY `IX_3A1E834E` (`companyId`),
  KEY `IX_6EF03E4E` (`companyId`,`defaultUser`),
  KEY `IX_1D731F03` (`companyId`,`facebookId`),
  KEY `IX_89509087` (`companyId`,`openId`(255)),
  KEY `IX_F6039434` (`companyId`,`status`),
  KEY `IX_762F63C6` (`emailAddress`),
  KEY `IX_A18034A4` (`portraitId`),
  KEY `IX_E0422BDA` (`uuid_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `User_`
--

LOCK TABLES `User_` WRITE;
/*!40000 ALTER TABLE `User_` DISABLE KEYS */;
INSERT INTO `User_` VALUES ('73c74878-d597-49a7-81c5-877bac48abec',10158,10154,'2014-03-18 17:33:36','2014-03-18 17:33:36',1,10159,'password',0,0,NULL,'5533ed38b5e33c076a804bb4bca644f9,528f53719430814f22dbf509e0faa0c4,528f53719430814f22dbf509e0faa0c4','','',0,'10158','default@liferay.com',0,'',0,'en_US','GMT','Welcome!','','','','','','2014-03-18 17:33:36','',NULL,'',NULL,0,0,NULL,1,0,0),('ff49757e-f39c-4371-b396-19017d5b0289',10196,10154,'2014-03-18 17:33:37','2014-03-18 18:02:47',0,10197,'qUqP5cyxm6YcTAhz05Hph5gvu9M=',1,0,NULL,'e5d86c6f3672e52795891c3597f20de0,751da756639bc033b572ba2e7849b589,8f3d267131c99bf7ba6ade3481d748b4','what-is-your-father\'s-middle-name','test',0,'test','test@liferay.com',0,'',0,'en_US','Pacific/Midway','Welcome Test Test!','','Test','','Test','','2014-07-08 22:41:35','127.0.0.1','2014-03-18 18:02:13','127.0.0.1',NULL,0,0,NULL,1,1,0),('ec952fc4-62dc-4851-8a4f-c13ddb755aea',10458,10154,'2014-03-18 17:36:49','2014-03-18 17:36:49',0,10459,'9Fyse+4OX/RQqyiTySoZ2sZ3QQA=',1,1,NULL,'','','',0,'usersn','userea@liferay.com',0,'',0,'en_US','GMT','Welcome userfn userln!','','userfn','','userln','',NULL,'',NULL,'',NULL,0,0,NULL,0,0,0),('8ae5f590-b4df-44c0-b2ad-351328b5bdb9',10601,10154,'2014-03-18 17:45:50','2014-03-18 17:47:03',0,10602,'w9ROMe8CoaZhmZ0PSMRGW9run60=',1,0,'2014-03-18 17:47:03','0136ce4cb0109115dc5fe03059dbb770,584f10d0b6ef9daa98c5fcf8e55d678e,c219319f547a250b81563bf67b9e9951','what-is-your-father\'s-middle-name','test',0,'userpp','userpp@liferay.com',0,'',0,'en_US','Pacific/Midway','Welcome userPPfn userPPln!','','userPPfn','','userPPln','','2014-03-18 17:47:12','127.0.0.1','2014-03-18 17:46:17','127.0.0.1',NULL,0,0,NULL,1,0,0),('5373112c-bc4a-48f6-9283-96169924aeaf',10650,10154,'2014-03-18 17:49:40','2014-03-18 17:49:57',0,10651,'qUqP5cyxm6YcTAhz05Hph5gvu9M=',1,0,'2014-03-18 17:50:10','13d957655349630cde5693a84993bd42,c2a95ed4405fe600e2a614a6c9aa1ec5,30dcd44c6d3ed39d8f415a22e060e6ee','what-is-your-father\'s-middle-name','test',0,'usersmsn','usersm@liferay.com',0,'',0,'en_US','Pacific/Midway','Welcome userSMfn userSMln!','','userSMfn','','userSMln','','2014-03-18 17:50:29','127.0.0.1','2014-03-18 17:50:07','127.0.0.1',NULL,0,0,NULL,1,0,0),('673c1241-2cc0-4b83-946c-caf94cc3d36b',10848,10154,'2014-03-18 18:00:30','2014-03-18 18:00:30',0,10849,'zMzMrmXfn6958b2uQ1pRzi9ldyc=',1,1,NULL,'','','',0,'usercf','usercf@liferay.com',0,'',0,'en_US','GMT','Welcome userCFfn userCFln!','','userCFfn','','userCFln','',NULL,'',NULL,'',NULL,0,0,NULL,0,0,0);
/*!40000 ALTER TABLE `User_` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Users_Groups`
--

DROP TABLE IF EXISTS `Users_Groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Users_Groups` (
  `userId` bigint(20) NOT NULL,
  `groupId` bigint(20) NOT NULL,
  PRIMARY KEY (`userId`,`groupId`),
  KEY `IX_C4F9E699` (`groupId`),
  KEY `IX_F10B6C6B` (`userId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Users_Groups`
--

LOCK TABLES `Users_Groups` WRITE;
/*!40000 ALTER TABLE `Users_Groups` DISABLE KEYS */;
INSERT INTO `Users_Groups` VALUES (10196,10180),(10196,10450),(10196,10467),(10196,10509),(10196,10522),(10196,10557),(10196,10646),(10196,10679),(10196,10688),(10196,10761),(10196,10778),(10196,10807),(10196,10857),(10196,10922),(10196,10946);
/*!40000 ALTER TABLE `Users_Groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Users_Orgs`
--

DROP TABLE IF EXISTS `Users_Orgs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Users_Orgs` (
  `userId` bigint(20) NOT NULL,
  `organizationId` bigint(20) NOT NULL,
  PRIMARY KEY (`userId`,`organizationId`),
  KEY `IX_7EF4EC0E` (`organizationId`),
  KEY `IX_FB646CA6` (`userId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Users_Orgs`
--

LOCK TABLES `Users_Orgs` WRITE;
/*!40000 ALTER TABLE `Users_Orgs` DISABLE KEYS */;
/*!40000 ALTER TABLE `Users_Orgs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Users_Permissions`
--

DROP TABLE IF EXISTS `Users_Permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Users_Permissions` (
  `userId` bigint(20) NOT NULL,
  `permissionId` bigint(20) NOT NULL,
  PRIMARY KEY (`userId`,`permissionId`),
  KEY `IX_8AE58A91` (`permissionId`),
  KEY `IX_C26AA64D` (`userId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Users_Permissions`
--

LOCK TABLES `Users_Permissions` WRITE;
/*!40000 ALTER TABLE `Users_Permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `Users_Permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Users_Roles`
--

DROP TABLE IF EXISTS `Users_Roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Users_Roles` (
  `userId` bigint(20) NOT NULL,
  `roleId` bigint(20) NOT NULL,
  PRIMARY KEY (`userId`,`roleId`),
  KEY `IX_C19E5F31` (`roleId`),
  KEY `IX_C1A01806` (`userId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Users_Roles`
--

LOCK TABLES `Users_Roles` WRITE;
/*!40000 ALTER TABLE `Users_Roles` DISABLE KEYS */;
INSERT INTO `Users_Roles` VALUES (10196,10161),(10158,10162),(10196,10164),(10458,10164),(10601,10164),(10650,10164),(10848,10164),(10196,10165),(10458,10165),(10601,10165),(10650,10165),(10848,10165);
/*!40000 ALTER TABLE `Users_Roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Users_Teams`
--

DROP TABLE IF EXISTS `Users_Teams`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Users_Teams` (
  `userId` bigint(20) NOT NULL,
  `teamId` bigint(20) NOT NULL,
  PRIMARY KEY (`userId`,`teamId`),
  KEY `IX_4D06AD51` (`teamId`),
  KEY `IX_A098EFBF` (`userId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Users_Teams`
--

LOCK TABLES `Users_Teams` WRITE;
/*!40000 ALTER TABLE `Users_Teams` DISABLE KEYS */;
/*!40000 ALTER TABLE `Users_Teams` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Users_UserGroups`
--

DROP TABLE IF EXISTS `Users_UserGroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Users_UserGroups` (
  `userGroupId` bigint(20) NOT NULL,
  `userId` bigint(20) NOT NULL,
  PRIMARY KEY (`userGroupId`,`userId`),
  KEY `IX_66FF2503` (`userGroupId`),
  KEY `IX_BE8102D6` (`userId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Users_UserGroups`
--

LOCK TABLES `Users_UserGroups` WRITE;
/*!40000 ALTER TABLE `Users_UserGroups` DISABLE KEYS */;
/*!40000 ALTER TABLE `Users_UserGroups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `VirtualHost`
--

DROP TABLE IF EXISTS `VirtualHost`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `VirtualHost` (
  `virtualHostId` bigint(20) NOT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `layoutSetId` bigint(20) DEFAULT NULL,
  `hostname` varchar(75) DEFAULT NULL,
  PRIMARY KEY (`virtualHostId`),
  UNIQUE KEY `IX_A083D394` (`companyId`,`layoutSetId`),
  UNIQUE KEY `IX_431A3960` (`hostname`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `VirtualHost`
--

LOCK TABLES `VirtualHost` WRITE;
/*!40000 ALTER TABLE `VirtualHost` DISABLE KEYS */;
INSERT INTO `VirtualHost` VALUES (10157,10154,0,'localhost');
/*!40000 ALTER TABLE `VirtualHost` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `WebDAVProps`
--

DROP TABLE IF EXISTS `WebDAVProps`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `WebDAVProps` (
  `webDavPropsId` bigint(20) NOT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `createDate` datetime DEFAULT NULL,
  `modifiedDate` datetime DEFAULT NULL,
  `classNameId` bigint(20) DEFAULT NULL,
  `classPK` bigint(20) DEFAULT NULL,
  `props` longtext,
  PRIMARY KEY (`webDavPropsId`),
  UNIQUE KEY `IX_97DFA146` (`classNameId`,`classPK`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `WebDAVProps`
--

LOCK TABLES `WebDAVProps` WRITE;
/*!40000 ALTER TABLE `WebDAVProps` DISABLE KEYS */;
/*!40000 ALTER TABLE `WebDAVProps` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Website`
--

DROP TABLE IF EXISTS `Website`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Website` (
  `websiteId` bigint(20) NOT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `userId` bigint(20) DEFAULT NULL,
  `userName` varchar(75) DEFAULT NULL,
  `createDate` datetime DEFAULT NULL,
  `modifiedDate` datetime DEFAULT NULL,
  `classNameId` bigint(20) DEFAULT NULL,
  `classPK` bigint(20) DEFAULT NULL,
  `url` longtext,
  `typeId` int(11) DEFAULT NULL,
  `primary_` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`websiteId`),
  KEY `IX_96F07007` (`companyId`),
  KEY `IX_4F0F0CA7` (`companyId`,`classNameId`),
  KEY `IX_F960131C` (`companyId`,`classNameId`,`classPK`),
  KEY `IX_1AA07A6D` (`companyId`,`classNameId`,`classPK`,`primary_`),
  KEY `IX_F75690BB` (`userId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Website`
--

LOCK TABLES `Website` WRITE;
/*!40000 ALTER TABLE `Website` DISABLE KEYS */;
INSERT INTO `Website` VALUES (10879,10154,10196,'Test Test','2014-03-18 18:02:47','2014-03-18 18:02:47',10022,10197,'http://www.liferayportal01.com',11029,1);
/*!40000 ALTER TABLE `Website` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `WikiNode`
--

DROP TABLE IF EXISTS `WikiNode`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `WikiNode` (
  `uuid_` varchar(75) DEFAULT NULL,
  `nodeId` bigint(20) NOT NULL,
  `groupId` bigint(20) DEFAULT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `userId` bigint(20) DEFAULT NULL,
  `userName` varchar(75) DEFAULT NULL,
  `createDate` datetime DEFAULT NULL,
  `modifiedDate` datetime DEFAULT NULL,
  `name` varchar(75) DEFAULT NULL,
  `description` longtext,
  `lastPostDate` datetime DEFAULT NULL,
  PRIMARY KEY (`nodeId`),
  UNIQUE KEY `IX_920CD8B1` (`groupId`,`name`),
  UNIQUE KEY `IX_7609B2AE` (`uuid_`,`groupId`),
  KEY `IX_5D6FE3F0` (`companyId`),
  KEY `IX_B480A672` (`groupId`),
  KEY `IX_6C112D7C` (`uuid_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `WikiNode`
--

LOCK TABLES `WikiNode` WRITE;
/*!40000 ALTER TABLE `WikiNode` DISABLE KEYS */;
INSERT INTO `WikiNode` VALUES ('603a82d4-3c94-4649-a01d-94e8dd86e463',10481,10467,10154,10196,'Test Test','2014-03-18 17:37:54','2014-03-18 17:37:54','Main','','2014-03-18 17:37:54'),('1398f66b-0281-4682-8ffc-1b0d8d45c76f',10492,10467,10154,10196,'Test Test','2014-03-18 17:38:06','2014-03-18 17:38:06','Wiki Node Name','Wiki Node Description',NULL);
/*!40000 ALTER TABLE `WikiNode` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `WikiPage`
--

DROP TABLE IF EXISTS `WikiPage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `WikiPage` (
  `uuid_` varchar(75) DEFAULT NULL,
  `pageId` bigint(20) NOT NULL,
  `resourcePrimKey` bigint(20) DEFAULT NULL,
  `groupId` bigint(20) DEFAULT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `userId` bigint(20) DEFAULT NULL,
  `userName` varchar(75) DEFAULT NULL,
  `createDate` datetime DEFAULT NULL,
  `modifiedDate` datetime DEFAULT NULL,
  `nodeId` bigint(20) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `version` double DEFAULT NULL,
  `minorEdit` tinyint(4) DEFAULT NULL,
  `content` longtext,
  `summary` longtext,
  `format` varchar(75) DEFAULT NULL,
  `head` tinyint(4) DEFAULT NULL,
  `parentTitle` varchar(255) DEFAULT NULL,
  `redirectTitle` varchar(255) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `statusByUserId` bigint(20) DEFAULT NULL,
  `statusByUserName` varchar(75) DEFAULT NULL,
  `statusDate` datetime DEFAULT NULL,
  PRIMARY KEY (`pageId`),
  UNIQUE KEY `IX_3D4AF476` (`nodeId`,`title`,`version`),
  UNIQUE KEY `IX_2CD67C81` (`resourcePrimKey`,`nodeId`,`version`),
  UNIQUE KEY `IX_899D3DFB` (`uuid_`,`groupId`),
  KEY `IX_A2001730` (`format`),
  KEY `IX_C8A9C476` (`nodeId`),
  KEY `IX_E7F635CA` (`nodeId`,`head`),
  KEY `IX_65E84AF4` (`nodeId`,`head`,`parentTitle`),
  KEY `IX_9F7655DA` (`nodeId`,`head`,`parentTitle`,`status`),
  KEY `IX_432F0AB0` (`nodeId`,`head`,`status`),
  KEY `IX_46EEF3C8` (`nodeId`,`parentTitle`),
  KEY `IX_1ECC7656` (`nodeId`,`redirectTitle`),
  KEY `IX_546F2D5C` (`nodeId`,`status`),
  KEY `IX_997EEDD2` (`nodeId`,`title`),
  KEY `IX_E745EA26` (`nodeId`,`title`,`head`),
  KEY `IX_BEA33AB8` (`nodeId`,`title`,`status`),
  KEY `IX_B771D67` (`resourcePrimKey`,`nodeId`),
  KEY `IX_94D1054D` (`resourcePrimKey`,`nodeId`,`status`),
  KEY `IX_FBBE7C96` (`userId`,`nodeId`,`status`),
  KEY `IX_9C0E478F` (`uuid_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `WikiPage`
--

LOCK TABLES `WikiPage` WRITE;
/*!40000 ALTER TABLE `WikiPage` DISABLE KEYS */;
INSERT INTO `WikiPage` VALUES ('91081b0b-53ae-411b-8958-4fe6102540cb',10482,10483,10467,10154,10196,'Test Test','2014-03-18 17:37:54','2014-03-18 17:37:54',10481,'FrontPage',1,1,'','New','creole',1,'','',0,10196,'Test Test','2014-03-18 17:37:54');
/*!40000 ALTER TABLE `WikiPage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `WikiPageResource`
--

DROP TABLE IF EXISTS `WikiPageResource`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `WikiPageResource` (
  `uuid_` varchar(75) DEFAULT NULL,
  `resourcePrimKey` bigint(20) NOT NULL,
  `nodeId` bigint(20) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`resourcePrimKey`),
  UNIQUE KEY `IX_21277664` (`nodeId`,`title`),
  KEY `IX_BE898221` (`uuid_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `WikiPageResource`
--

LOCK TABLES `WikiPageResource` WRITE;
/*!40000 ALTER TABLE `WikiPageResource` DISABLE KEYS */;
INSERT INTO `WikiPageResource` VALUES ('9eb9b7b0-9200-43dc-b96e-80307d3debab',10483,10481,'FrontPage');
/*!40000 ALTER TABLE `WikiPageResource` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `WorkflowDefinitionLink`
--

DROP TABLE IF EXISTS `WorkflowDefinitionLink`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `WorkflowDefinitionLink` (
  `workflowDefinitionLinkId` bigint(20) NOT NULL,
  `groupId` bigint(20) DEFAULT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `userId` bigint(20) DEFAULT NULL,
  `userName` varchar(75) DEFAULT NULL,
  `createDate` datetime DEFAULT NULL,
  `modifiedDate` datetime DEFAULT NULL,
  `classNameId` bigint(20) DEFAULT NULL,
  `classPK` bigint(20) DEFAULT NULL,
  `typePK` bigint(20) DEFAULT NULL,
  `workflowDefinitionName` varchar(75) DEFAULT NULL,
  `workflowDefinitionVersion` int(11) DEFAULT NULL,
  PRIMARY KEY (`workflowDefinitionLinkId`),
  KEY `IX_A8B0D276` (`companyId`),
  KEY `IX_A4DB1F0F` (`companyId`,`workflowDefinitionName`,`workflowDefinitionVersion`),
  KEY `IX_B6EE8C9E` (`groupId`,`companyId`,`classNameId`),
  KEY `IX_1E5B9905` (`groupId`,`companyId`,`classNameId`,`classPK`),
  KEY `IX_705B40EE` (`groupId`,`companyId`,`classNameId`,`classPK`,`typePK`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `WorkflowDefinitionLink`
--

LOCK TABLES `WorkflowDefinitionLink` WRITE;
/*!40000 ALTER TABLE `WorkflowDefinitionLink` DISABLE KEYS */;
/*!40000 ALTER TABLE `WorkflowDefinitionLink` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `WorkflowInstanceLink`
--

DROP TABLE IF EXISTS `WorkflowInstanceLink`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `WorkflowInstanceLink` (
  `workflowInstanceLinkId` bigint(20) NOT NULL,
  `groupId` bigint(20) DEFAULT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `userId` bigint(20) DEFAULT NULL,
  `userName` varchar(75) DEFAULT NULL,
  `createDate` datetime DEFAULT NULL,
  `modifiedDate` datetime DEFAULT NULL,
  `classNameId` bigint(20) DEFAULT NULL,
  `classPK` bigint(20) DEFAULT NULL,
  `workflowInstanceId` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`workflowInstanceLinkId`),
  KEY `IX_415A7007` (`groupId`,`companyId`,`classNameId`,`classPK`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `WorkflowInstanceLink`
--

LOCK TABLES `WorkflowInstanceLink` WRITE;
/*!40000 ALTER TABLE `WorkflowInstanceLink` DISABLE KEYS */;
/*!40000 ALTER TABLE `WorkflowInstanceLink` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2014-07-08 16:05:44
