--
-- PostgreSQL database dump
--

SET statement_timeout = 0;
SET lock_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;

--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: account_; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE account_ (
    accountid bigint NOT NULL,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    parentaccountid bigint,
    name character varying(75),
    legalname character varying(75),
    legalid character varying(75),
    legaltype character varying(75),
    siccode character varying(75),
    tickersymbol character varying(75),
    industry character varying(75),
    type_ character varying(75),
    size_ character varying(75)
);


ALTER TABLE account_ OWNER TO root;

--
-- Name: address; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE address (
    uuid_ character varying(75),
    addressid bigint NOT NULL,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    classnameid bigint,
    classpk bigint,
    street1 character varying(75),
    street2 character varying(75),
    street3 character varying(75),
    city character varying(75),
    zip character varying(75),
    regionid bigint,
    countryid bigint,
    typeid integer,
    mailing boolean,
    primary_ boolean
);


ALTER TABLE address OWNER TO root;

--
-- Name: announcementsdelivery; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE announcementsdelivery (
    deliveryid bigint NOT NULL,
    companyid bigint,
    userid bigint,
    type_ character varying(75),
    email boolean,
    sms boolean,
    website boolean
);


ALTER TABLE announcementsdelivery OWNER TO root;

--
-- Name: announcementsentry; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE announcementsentry (
    uuid_ character varying(75),
    entryid bigint NOT NULL,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    classnameid bigint,
    classpk bigint,
    title character varying(75),
    content text,
    url text,
    type_ character varying(75),
    displaydate timestamp without time zone,
    expirationdate timestamp without time zone,
    priority integer,
    alert boolean
);


ALTER TABLE announcementsentry OWNER TO root;

--
-- Name: announcementsflag; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE announcementsflag (
    flagid bigint NOT NULL,
    userid bigint,
    createdate timestamp without time zone,
    entryid bigint,
    value integer
);


ALTER TABLE announcementsflag OWNER TO root;

--
-- Name: assetcategory; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE assetcategory (
    uuid_ character varying(75),
    categoryid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    parentcategoryid bigint,
    leftcategoryid bigint,
    rightcategoryid bigint,
    name character varying(75),
    title text,
    description text,
    vocabularyid bigint
);


ALTER TABLE assetcategory OWNER TO root;

--
-- Name: assetcategoryproperty; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE assetcategoryproperty (
    categorypropertyid bigint NOT NULL,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    categoryid bigint,
    key_ character varying(75),
    value character varying(75)
);


ALTER TABLE assetcategoryproperty OWNER TO root;

--
-- Name: assetentries_assetcategories; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE assetentries_assetcategories (
    categoryid bigint NOT NULL,
    entryid bigint NOT NULL
);


ALTER TABLE assetentries_assetcategories OWNER TO root;

--
-- Name: assetentries_assettags; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE assetentries_assettags (
    entryid bigint NOT NULL,
    tagid bigint NOT NULL
);


ALTER TABLE assetentries_assettags OWNER TO root;

--
-- Name: assetentry; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE assetentry (
    entryid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    classnameid bigint,
    classpk bigint,
    classuuid character varying(75),
    classtypeid bigint,
    visible boolean,
    startdate timestamp without time zone,
    enddate timestamp without time zone,
    publishdate timestamp without time zone,
    expirationdate timestamp without time zone,
    mimetype character varying(75),
    title text,
    description text,
    summary text,
    url text,
    layoutuuid character varying(75),
    height integer,
    width integer,
    priority double precision,
    viewcount integer
);


ALTER TABLE assetentry OWNER TO root;

--
-- Name: assetlink; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE assetlink (
    linkid bigint NOT NULL,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    entryid1 bigint,
    entryid2 bigint,
    type_ integer,
    weight integer
);


ALTER TABLE assetlink OWNER TO root;

--
-- Name: assettag; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE assettag (
    tagid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    name character varying(75),
    assetcount integer
);


ALTER TABLE assettag OWNER TO root;

--
-- Name: assettagproperty; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE assettagproperty (
    tagpropertyid bigint NOT NULL,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    tagid bigint,
    key_ character varying(75),
    value character varying(255)
);


ALTER TABLE assettagproperty OWNER TO root;

--
-- Name: assettagstats; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE assettagstats (
    tagstatsid bigint NOT NULL,
    tagid bigint,
    classnameid bigint,
    assetcount integer
);


ALTER TABLE assettagstats OWNER TO root;

--
-- Name: assetvocabulary; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE assetvocabulary (
    uuid_ character varying(75),
    vocabularyid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    name character varying(75),
    title text,
    description text,
    settings_ text
);


ALTER TABLE assetvocabulary OWNER TO root;

--
-- Name: backgroundtask; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE backgroundtask (
    backgroundtaskid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    name character varying(75),
    servletcontextnames character varying(255),
    taskexecutorclassname character varying(200),
    taskcontext text,
    completed boolean,
    completiondate timestamp without time zone,
    status integer,
    statusmessage text
);


ALTER TABLE backgroundtask OWNER TO root;

--
-- Name: blogsentry; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE blogsentry (
    uuid_ character varying(75),
    entryid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    title character varying(150),
    urltitle character varying(150),
    description text,
    content text,
    displaydate timestamp without time zone,
    allowpingbacks boolean,
    allowtrackbacks boolean,
    trackbacks text,
    smallimage boolean,
    smallimageid bigint,
    smallimageurl text,
    status integer,
    statusbyuserid bigint,
    statusbyusername character varying(75),
    statusdate timestamp without time zone
);


ALTER TABLE blogsentry OWNER TO root;

--
-- Name: blogsstatsuser; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE blogsstatsuser (
    statsuserid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    userid bigint,
    entrycount integer,
    lastpostdate timestamp without time zone,
    ratingstotalentries integer,
    ratingstotalscore double precision,
    ratingsaveragescore double precision
);


ALTER TABLE blogsstatsuser OWNER TO root;

--
-- Name: bookmarksentry; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE bookmarksentry (
    uuid_ character varying(75),
    entryid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    resourceblockid bigint,
    folderid bigint,
    treepath text,
    name character varying(255),
    url text,
    description text,
    visits integer,
    priority integer,
    status integer,
    statusbyuserid bigint,
    statusbyusername character varying(75),
    statusdate timestamp without time zone
);


ALTER TABLE bookmarksentry OWNER TO root;

--
-- Name: bookmarksfolder; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE bookmarksfolder (
    uuid_ character varying(75),
    folderid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    resourceblockid bigint,
    parentfolderid bigint,
    treepath text,
    name character varying(75),
    description text,
    status integer,
    statusbyuserid bigint,
    statusbyusername character varying(75),
    statusdate timestamp without time zone
);


ALTER TABLE bookmarksfolder OWNER TO root;

--
-- Name: browsertracker; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE browsertracker (
    browsertrackerid bigint NOT NULL,
    userid bigint,
    browserkey bigint
);


ALTER TABLE browsertracker OWNER TO root;

--
-- Name: calevent; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE calevent (
    uuid_ character varying(75),
    eventid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    title character varying(75),
    description text,
    location text,
    startdate timestamp without time zone,
    enddate timestamp without time zone,
    durationhour integer,
    durationminute integer,
    allday boolean,
    timezonesensitive boolean,
    type_ character varying(75),
    repeating boolean,
    recurrence text,
    remindby integer,
    firstreminder integer,
    secondreminder integer
);


ALTER TABLE calevent OWNER TO root;

--
-- Name: classname_; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE classname_ (
    classnameid bigint NOT NULL,
    value character varying(200)
);


ALTER TABLE classname_ OWNER TO root;

--
-- Name: clustergroup; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE clustergroup (
    clustergroupid bigint NOT NULL,
    name character varying(75),
    clusternodeids character varying(75),
    wholecluster boolean
);


ALTER TABLE clustergroup OWNER TO root;

--
-- Name: company; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE company (
    companyid bigint NOT NULL,
    accountid bigint,
    webid character varying(75),
    key_ text,
    mx character varying(75),
    homeurl text,
    logoid bigint,
    system boolean,
    maxusers integer,
    active_ boolean
);


ALTER TABLE company OWNER TO root;

--
-- Name: contact_; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE contact_ (
    contactid bigint NOT NULL,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    classnameid bigint,
    classpk bigint,
    accountid bigint,
    parentcontactid bigint,
    emailaddress character varying(75),
    firstname character varying(75),
    middlename character varying(75),
    lastname character varying(75),
    prefixid integer,
    suffixid integer,
    male boolean,
    birthday timestamp without time zone,
    smssn character varying(75),
    aimsn character varying(75),
    facebooksn character varying(75),
    icqsn character varying(75),
    jabbersn character varying(75),
    msnsn character varying(75),
    myspacesn character varying(75),
    skypesn character varying(75),
    twittersn character varying(75),
    ymsn character varying(75),
    employeestatusid character varying(75),
    employeenumber character varying(75),
    jobtitle character varying(100),
    jobclass character varying(75),
    hoursofoperation character varying(75)
);


ALTER TABLE contact_ OWNER TO root;

--
-- Name: counter; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE counter (
    name character varying(75) NOT NULL,
    currentid bigint
);


ALTER TABLE counter OWNER TO root;

--
-- Name: country; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE country (
    countryid bigint NOT NULL,
    name character varying(75),
    a2 character varying(75),
    a3 character varying(75),
    number_ character varying(75),
    idd_ character varying(75),
    ziprequired boolean,
    active_ boolean
);


ALTER TABLE country OWNER TO root;

--
-- Name: cyrususer; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE cyrususer (
    userid character varying(75) NOT NULL,
    password_ character varying(75) NOT NULL
);


ALTER TABLE cyrususer OWNER TO root;

--
-- Name: cyrusvirtual; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE cyrusvirtual (
    emailaddress character varying(75) NOT NULL,
    userid character varying(75) NOT NULL
);


ALTER TABLE cyrusvirtual OWNER TO root;

--
-- Name: ddlrecord; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE ddlrecord (
    uuid_ character varying(75),
    recordid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    userid bigint,
    username character varying(75),
    versionuserid bigint,
    versionusername character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    ddmstorageid bigint,
    recordsetid bigint,
    version character varying(75),
    displayindex integer
);


ALTER TABLE ddlrecord OWNER TO root;

--
-- Name: ddlrecordset; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE ddlrecordset (
    uuid_ character varying(75),
    recordsetid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    ddmstructureid bigint,
    recordsetkey character varying(75),
    name text,
    description text,
    mindisplayrows integer,
    scope integer
);


ALTER TABLE ddlrecordset OWNER TO root;

--
-- Name: ddlrecordversion; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE ddlrecordversion (
    recordversionid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    ddmstorageid bigint,
    recordsetid bigint,
    recordid bigint,
    version character varying(75),
    displayindex integer,
    status integer,
    statusbyuserid bigint,
    statusbyusername character varying(75),
    statusdate timestamp without time zone
);


ALTER TABLE ddlrecordversion OWNER TO root;

--
-- Name: ddmcontent; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE ddmcontent (
    uuid_ character varying(75),
    contentid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    name text,
    description text,
    xml text
);


ALTER TABLE ddmcontent OWNER TO root;

--
-- Name: ddmstoragelink; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE ddmstoragelink (
    uuid_ character varying(75),
    storagelinkid bigint NOT NULL,
    classnameid bigint,
    classpk bigint,
    structureid bigint
);


ALTER TABLE ddmstoragelink OWNER TO root;

--
-- Name: ddmstructure; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE ddmstructure (
    uuid_ character varying(75),
    structureid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    parentstructureid bigint,
    classnameid bigint,
    structurekey character varying(75),
    name text,
    description text,
    xsd text,
    storagetype character varying(75),
    type_ integer
);


ALTER TABLE ddmstructure OWNER TO root;

--
-- Name: ddmstructurelink; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE ddmstructurelink (
    structurelinkid bigint NOT NULL,
    classnameid bigint,
    classpk bigint,
    structureid bigint
);


ALTER TABLE ddmstructurelink OWNER TO root;

--
-- Name: ddmtemplate; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE ddmtemplate (
    uuid_ character varying(75),
    templateid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    classnameid bigint,
    classpk bigint,
    templatekey character varying(75),
    name text,
    description text,
    type_ character varying(75),
    mode_ character varying(75),
    language character varying(75),
    script text,
    cacheable boolean,
    smallimage boolean,
    smallimageid bigint,
    smallimageurl character varying(75)
);


ALTER TABLE ddmtemplate OWNER TO root;

--
-- Name: dlcontent; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE dlcontent (
    contentid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    repositoryid bigint,
    path_ character varying(255),
    version character varying(75),
    data_ oid,
    size_ bigint
);


ALTER TABLE dlcontent OWNER TO root;

--
-- Name: dlfileentry; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE dlfileentry (
    uuid_ character varying(75),
    fileentryid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    classnameid bigint,
    classpk bigint,
    repositoryid bigint,
    folderid bigint,
    treepath text,
    name character varying(255),
    extension character varying(75),
    mimetype character varying(75),
    title character varying(255),
    description text,
    extrasettings text,
    fileentrytypeid bigint,
    version character varying(75),
    size_ bigint,
    readcount integer,
    smallimageid bigint,
    largeimageid bigint,
    custom1imageid bigint,
    custom2imageid bigint,
    manualcheckinrequired boolean
);


ALTER TABLE dlfileentry OWNER TO root;

--
-- Name: dlfileentrymetadata; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE dlfileentrymetadata (
    uuid_ character varying(75),
    fileentrymetadataid bigint NOT NULL,
    ddmstorageid bigint,
    ddmstructureid bigint,
    fileentrytypeid bigint,
    fileentryid bigint,
    fileversionid bigint
);


ALTER TABLE dlfileentrymetadata OWNER TO root;

--
-- Name: dlfileentrytype; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE dlfileentrytype (
    uuid_ character varying(75),
    fileentrytypeid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    fileentrytypekey character varying(75),
    name text,
    description text
);


ALTER TABLE dlfileentrytype OWNER TO root;

--
-- Name: dlfileentrytypes_ddmstructures; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE dlfileentrytypes_ddmstructures (
    structureid bigint NOT NULL,
    fileentrytypeid bigint NOT NULL
);


ALTER TABLE dlfileentrytypes_ddmstructures OWNER TO root;

--
-- Name: dlfileentrytypes_dlfolders; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE dlfileentrytypes_dlfolders (
    fileentrytypeid bigint NOT NULL,
    folderid bigint NOT NULL
);


ALTER TABLE dlfileentrytypes_dlfolders OWNER TO root;

--
-- Name: dlfilerank; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE dlfilerank (
    filerankid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    userid bigint,
    createdate timestamp without time zone,
    fileentryid bigint,
    active_ boolean
);


ALTER TABLE dlfilerank OWNER TO root;

--
-- Name: dlfileshortcut; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE dlfileshortcut (
    uuid_ character varying(75),
    fileshortcutid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    repositoryid bigint,
    folderid bigint,
    tofileentryid bigint,
    treepath text,
    active_ boolean,
    status integer,
    statusbyuserid bigint,
    statusbyusername character varying(75),
    statusdate timestamp without time zone
);


ALTER TABLE dlfileshortcut OWNER TO root;

--
-- Name: dlfileversion; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE dlfileversion (
    uuid_ character varying(75),
    fileversionid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    repositoryid bigint,
    folderid bigint,
    fileentryid bigint,
    treepath text,
    extension character varying(75),
    mimetype character varying(75),
    title character varying(255),
    description text,
    changelog character varying(75),
    extrasettings text,
    fileentrytypeid bigint,
    version character varying(75),
    size_ bigint,
    checksum character varying(75),
    status integer,
    statusbyuserid bigint,
    statusbyusername character varying(75),
    statusdate timestamp without time zone
);


ALTER TABLE dlfileversion OWNER TO root;

--
-- Name: dlfolder; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE dlfolder (
    uuid_ character varying(75),
    folderid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    repositoryid bigint,
    mountpoint boolean,
    parentfolderid bigint,
    treepath text,
    name character varying(100),
    description text,
    lastpostdate timestamp without time zone,
    defaultfileentrytypeid bigint,
    hidden_ boolean,
    overridefileentrytypes boolean,
    status integer,
    statusbyuserid bigint,
    statusbyusername character varying(75),
    statusdate timestamp without time zone
);


ALTER TABLE dlfolder OWNER TO root;

--
-- Name: dlsyncevent; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE dlsyncevent (
    synceventid bigint NOT NULL,
    modifiedtime bigint,
    event character varying(75),
    type_ character varying(75),
    typepk bigint
);


ALTER TABLE dlsyncevent OWNER TO root;

--
-- Name: emailaddress; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE emailaddress (
    uuid_ character varying(75),
    emailaddressid bigint NOT NULL,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    classnameid bigint,
    classpk bigint,
    address character varying(75),
    typeid integer,
    primary_ boolean
);


ALTER TABLE emailaddress OWNER TO root;

--
-- Name: expandocolumn; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE expandocolumn (
    columnid bigint NOT NULL,
    companyid bigint,
    tableid bigint,
    name character varying(75),
    type_ integer,
    defaultdata text,
    typesettings text
);


ALTER TABLE expandocolumn OWNER TO root;

--
-- Name: expandorow; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE expandorow (
    rowid_ bigint NOT NULL,
    companyid bigint,
    modifieddate timestamp without time zone,
    tableid bigint,
    classpk bigint
);


ALTER TABLE expandorow OWNER TO root;

--
-- Name: expandotable; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE expandotable (
    tableid bigint NOT NULL,
    companyid bigint,
    classnameid bigint,
    name character varying(75)
);


ALTER TABLE expandotable OWNER TO root;

--
-- Name: expandovalue; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE expandovalue (
    valueid bigint NOT NULL,
    companyid bigint,
    tableid bigint,
    columnid bigint,
    rowid_ bigint,
    classnameid bigint,
    classpk bigint,
    data_ text
);


ALTER TABLE expandovalue OWNER TO root;

--
-- Name: group_; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE group_ (
    uuid_ character varying(75),
    groupid bigint NOT NULL,
    companyid bigint,
    creatoruserid bigint,
    classnameid bigint,
    classpk bigint,
    parentgroupid bigint,
    livegroupid bigint,
    treepath text,
    name character varying(150),
    description text,
    type_ integer,
    typesettings text,
    manualmembership boolean,
    membershiprestriction integer,
    friendlyurl character varying(255),
    site boolean,
    remotestaginggroupcount integer,
    active_ boolean
);


ALTER TABLE group_ OWNER TO root;

--
-- Name: groups_orgs; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE groups_orgs (
    groupid bigint NOT NULL,
    organizationid bigint NOT NULL
);


ALTER TABLE groups_orgs OWNER TO root;

--
-- Name: groups_roles; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE groups_roles (
    groupid bigint NOT NULL,
    roleid bigint NOT NULL
);


ALTER TABLE groups_roles OWNER TO root;

--
-- Name: groups_usergroups; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE groups_usergroups (
    groupid bigint NOT NULL,
    usergroupid bigint NOT NULL
);


ALTER TABLE groups_usergroups OWNER TO root;

--
-- Name: image; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE image (
    imageid bigint NOT NULL,
    modifieddate timestamp without time zone,
    type_ character varying(75),
    height integer,
    width integer,
    size_ integer
);


ALTER TABLE image OWNER TO root;

--
-- Name: journalarticle; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE journalarticle (
    uuid_ character varying(75),
    id_ bigint NOT NULL,
    resourceprimkey bigint,
    groupid bigint,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    folderid bigint,
    classnameid bigint,
    classpk bigint,
    treepath text,
    articleid character varying(75),
    version double precision,
    title text,
    urltitle character varying(150),
    description text,
    content text,
    type_ character varying(75),
    structureid character varying(75),
    templateid character varying(75),
    layoutuuid character varying(75),
    displaydate timestamp without time zone,
    expirationdate timestamp without time zone,
    reviewdate timestamp without time zone,
    indexable boolean,
    smallimage boolean,
    smallimageid bigint,
    smallimageurl text,
    status integer,
    statusbyuserid bigint,
    statusbyusername character varying(75),
    statusdate timestamp without time zone
);


ALTER TABLE journalarticle OWNER TO root;

--
-- Name: journalarticleimage; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE journalarticleimage (
    articleimageid bigint NOT NULL,
    groupid bigint,
    articleid character varying(75),
    version double precision,
    elinstanceid character varying(75),
    elname character varying(75),
    languageid character varying(75),
    tempimage boolean
);


ALTER TABLE journalarticleimage OWNER TO root;

--
-- Name: journalarticleresource; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE journalarticleresource (
    uuid_ character varying(75),
    resourceprimkey bigint NOT NULL,
    groupid bigint,
    articleid character varying(75)
);


ALTER TABLE journalarticleresource OWNER TO root;

--
-- Name: journalcontentsearch; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE journalcontentsearch (
    contentsearchid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    privatelayout boolean,
    layoutid bigint,
    portletid character varying(200),
    articleid character varying(75)
);


ALTER TABLE journalcontentsearch OWNER TO root;

--
-- Name: journalfeed; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE journalfeed (
    uuid_ character varying(75),
    id_ bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    feedid character varying(75),
    name character varying(75),
    description text,
    type_ character varying(75),
    structureid character varying(75),
    templateid character varying(75),
    renderertemplateid character varying(75),
    delta integer,
    orderbycol character varying(75),
    orderbytype character varying(75),
    targetlayoutfriendlyurl character varying(255),
    targetportletid character varying(75),
    contentfield character varying(75),
    feedformat character varying(75),
    feedversion double precision
);


ALTER TABLE journalfeed OWNER TO root;

--
-- Name: journalfolder; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE journalfolder (
    uuid_ character varying(75),
    folderid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    parentfolderid bigint,
    treepath text,
    name character varying(100),
    description text,
    status integer,
    statusbyuserid bigint,
    statusbyusername character varying(75),
    statusdate timestamp without time zone
);


ALTER TABLE journalfolder OWNER TO root;

--
-- Name: layout; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE layout (
    uuid_ character varying(75),
    plid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    privatelayout boolean,
    layoutid bigint,
    parentlayoutid bigint,
    name text,
    title text,
    description text,
    keywords text,
    robots text,
    type_ character varying(75),
    typesettings text,
    hidden_ boolean,
    friendlyurl character varying(255),
    iconimage boolean,
    iconimageid bigint,
    themeid character varying(75),
    colorschemeid character varying(75),
    wapthemeid character varying(75),
    wapcolorschemeid character varying(75),
    css text,
    priority integer,
    layoutprototypeuuid character varying(75),
    layoutprototypelinkenabled boolean,
    sourceprototypelayoutuuid character varying(75)
);


ALTER TABLE layout OWNER TO root;

--
-- Name: layoutbranch; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE layoutbranch (
    layoutbranchid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    userid bigint,
    username character varying(75),
    layoutsetbranchid bigint,
    plid bigint,
    name character varying(75),
    description text,
    master boolean
);


ALTER TABLE layoutbranch OWNER TO root;

--
-- Name: layoutfriendlyurl; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE layoutfriendlyurl (
    uuid_ character varying(75),
    layoutfriendlyurlid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    plid bigint,
    privatelayout boolean,
    friendlyurl character varying(255),
    languageid character varying(75)
);


ALTER TABLE layoutfriendlyurl OWNER TO root;

--
-- Name: layoutprototype; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE layoutprototype (
    uuid_ character varying(75),
    layoutprototypeid bigint NOT NULL,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    name text,
    description text,
    settings_ text,
    active_ boolean
);


ALTER TABLE layoutprototype OWNER TO root;

--
-- Name: layoutrevision; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE layoutrevision (
    layoutrevisionid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    layoutsetbranchid bigint,
    layoutbranchid bigint,
    parentlayoutrevisionid bigint,
    head boolean,
    major boolean,
    plid bigint,
    privatelayout boolean,
    name text,
    title text,
    description text,
    keywords text,
    robots text,
    typesettings text,
    iconimage boolean,
    iconimageid bigint,
    themeid character varying(75),
    colorschemeid character varying(75),
    wapthemeid character varying(75),
    wapcolorschemeid character varying(75),
    css text,
    status integer,
    statusbyuserid bigint,
    statusbyusername character varying(75),
    statusdate timestamp without time zone
);


ALTER TABLE layoutrevision OWNER TO root;

--
-- Name: layoutset; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE layoutset (
    layoutsetid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    privatelayout boolean,
    logo boolean,
    logoid bigint,
    themeid character varying(75),
    colorschemeid character varying(75),
    wapthemeid character varying(75),
    wapcolorschemeid character varying(75),
    css text,
    pagecount integer,
    settings_ text,
    layoutsetprototypeuuid character varying(75),
    layoutsetprototypelinkenabled boolean
);


ALTER TABLE layoutset OWNER TO root;

--
-- Name: layoutsetbranch; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE layoutsetbranch (
    layoutsetbranchid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    privatelayout boolean,
    name character varying(75),
    description text,
    master boolean,
    logo boolean,
    logoid bigint,
    themeid character varying(75),
    colorschemeid character varying(75),
    wapthemeid character varying(75),
    wapcolorschemeid character varying(75),
    css text,
    settings_ text,
    layoutsetprototypeuuid character varying(75),
    layoutsetprototypelinkenabled boolean
);


ALTER TABLE layoutsetbranch OWNER TO root;

--
-- Name: layoutsetprototype; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE layoutsetprototype (
    uuid_ character varying(75),
    layoutsetprototypeid bigint NOT NULL,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    name text,
    description text,
    settings_ text,
    active_ boolean
);


ALTER TABLE layoutsetprototype OWNER TO root;

--
-- Name: listtype; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE listtype (
    listtypeid integer NOT NULL,
    name character varying(75),
    type_ character varying(75)
);


ALTER TABLE listtype OWNER TO root;

--
-- Name: lock_; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE lock_ (
    uuid_ character varying(75),
    lockid bigint NOT NULL,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    classname character varying(75),
    key_ character varying(200),
    owner character varying(255),
    inheritable boolean,
    expirationdate timestamp without time zone
);


ALTER TABLE lock_ OWNER TO root;

--
-- Name: marketplace_app; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE marketplace_app (
    uuid_ character varying(75),
    appid bigint NOT NULL,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    remoteappid bigint,
    title character varying(75),
    description text,
    category character varying(75),
    iconurl text,
    version character varying(75)
);


ALTER TABLE marketplace_app OWNER TO root;

--
-- Name: marketplace_module; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE marketplace_module (
    uuid_ character varying(75),
    moduleid bigint NOT NULL,
    appid bigint,
    bundlesymbolicname character varying(500),
    bundleversion character varying(75),
    contextname character varying(75)
);


ALTER TABLE marketplace_module OWNER TO root;

--
-- Name: mbban; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE mbban (
    uuid_ character varying(75),
    banid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    banuserid bigint
);


ALTER TABLE mbban OWNER TO root;

--
-- Name: mbcategory; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE mbcategory (
    uuid_ character varying(75),
    categoryid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    parentcategoryid bigint,
    name character varying(75),
    description text,
    displaystyle character varying(75),
    threadcount integer,
    messagecount integer,
    lastpostdate timestamp without time zone,
    status integer,
    statusbyuserid bigint,
    statusbyusername character varying(75),
    statusdate timestamp without time zone
);


ALTER TABLE mbcategory OWNER TO root;

--
-- Name: mbdiscussion; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE mbdiscussion (
    uuid_ character varying(75),
    discussionid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    classnameid bigint,
    classpk bigint,
    threadid bigint
);


ALTER TABLE mbdiscussion OWNER TO root;

--
-- Name: mbmailinglist; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE mbmailinglist (
    uuid_ character varying(75),
    mailinglistid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    categoryid bigint,
    emailaddress character varying(75),
    inprotocol character varying(75),
    inservername character varying(75),
    inserverport integer,
    inusessl boolean,
    inusername character varying(75),
    inpassword character varying(75),
    inreadinterval integer,
    outemailaddress character varying(75),
    outcustom boolean,
    outservername character varying(75),
    outserverport integer,
    outusessl boolean,
    outusername character varying(75),
    outpassword character varying(75),
    allowanonymous boolean,
    active_ boolean
);


ALTER TABLE mbmailinglist OWNER TO root;

--
-- Name: mbmessage; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE mbmessage (
    uuid_ character varying(75),
    messageid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    classnameid bigint,
    classpk bigint,
    categoryid bigint,
    threadid bigint,
    rootmessageid bigint,
    parentmessageid bigint,
    subject character varying(75),
    body text,
    format character varying(75),
    anonymous boolean,
    priority double precision,
    allowpingbacks boolean,
    answer boolean,
    status integer,
    statusbyuserid bigint,
    statusbyusername character varying(75),
    statusdate timestamp without time zone
);


ALTER TABLE mbmessage OWNER TO root;

--
-- Name: mbstatsuser; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE mbstatsuser (
    statsuserid bigint NOT NULL,
    groupid bigint,
    userid bigint,
    messagecount integer,
    lastpostdate timestamp without time zone
);


ALTER TABLE mbstatsuser OWNER TO root;

--
-- Name: mbthread; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE mbthread (
    uuid_ character varying(75),
    threadid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    categoryid bigint,
    rootmessageid bigint,
    rootmessageuserid bigint,
    messagecount integer,
    viewcount integer,
    lastpostbyuserid bigint,
    lastpostdate timestamp without time zone,
    priority double precision,
    question boolean,
    status integer,
    statusbyuserid bigint,
    statusbyusername character varying(75),
    statusdate timestamp without time zone
);


ALTER TABLE mbthread OWNER TO root;

--
-- Name: mbthreadflag; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE mbthreadflag (
    uuid_ character varying(75),
    threadflagid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    threadid bigint
);


ALTER TABLE mbthreadflag OWNER TO root;

--
-- Name: mdraction; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE mdraction (
    uuid_ character varying(75),
    actionid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    classnameid bigint,
    classpk bigint,
    rulegroupinstanceid bigint,
    name text,
    description text,
    type_ character varying(255),
    typesettings text
);


ALTER TABLE mdraction OWNER TO root;

--
-- Name: mdrrule; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE mdrrule (
    uuid_ character varying(75),
    ruleid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    rulegroupid bigint,
    name text,
    description text,
    type_ character varying(255),
    typesettings text
);


ALTER TABLE mdrrule OWNER TO root;

--
-- Name: mdrrulegroup; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE mdrrulegroup (
    uuid_ character varying(75),
    rulegroupid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    name text,
    description text
);


ALTER TABLE mdrrulegroup OWNER TO root;

--
-- Name: mdrrulegroupinstance; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE mdrrulegroupinstance (
    uuid_ character varying(75),
    rulegroupinstanceid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    classnameid bigint,
    classpk bigint,
    rulegroupid bigint,
    priority integer
);


ALTER TABLE mdrrulegroupinstance OWNER TO root;

--
-- Name: membershiprequest; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE membershiprequest (
    membershiprequestid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    userid bigint,
    createdate timestamp without time zone,
    comments text,
    replycomments text,
    replydate timestamp without time zone,
    replieruserid bigint,
    statusid integer
);


ALTER TABLE membershiprequest OWNER TO root;

--
-- Name: organization_; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE organization_ (
    uuid_ character varying(75),
    organizationid bigint NOT NULL,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    parentorganizationid bigint,
    treepath text,
    name character varying(100),
    type_ character varying(75),
    recursable boolean,
    regionid bigint,
    countryid bigint,
    statusid integer,
    comments text
);


ALTER TABLE organization_ OWNER TO root;

--
-- Name: orggrouprole; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE orggrouprole (
    organizationid bigint NOT NULL,
    groupid bigint NOT NULL,
    roleid bigint NOT NULL
);


ALTER TABLE orggrouprole OWNER TO root;

--
-- Name: orglabor; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE orglabor (
    orglaborid bigint NOT NULL,
    organizationid bigint,
    typeid integer,
    sunopen integer,
    sunclose integer,
    monopen integer,
    monclose integer,
    tueopen integer,
    tueclose integer,
    wedopen integer,
    wedclose integer,
    thuopen integer,
    thuclose integer,
    friopen integer,
    friclose integer,
    satopen integer,
    satclose integer
);


ALTER TABLE orglabor OWNER TO root;

--
-- Name: passwordpolicy; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE passwordpolicy (
    uuid_ character varying(75),
    passwordpolicyid bigint NOT NULL,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    defaultpolicy boolean,
    name character varying(75),
    description text,
    changeable boolean,
    changerequired boolean,
    minage bigint,
    checksyntax boolean,
    allowdictionarywords boolean,
    minalphanumeric integer,
    minlength integer,
    minlowercase integer,
    minnumbers integer,
    minsymbols integer,
    minuppercase integer,
    regex character varying(75),
    history boolean,
    historycount integer,
    expireable boolean,
    maxage bigint,
    warningtime bigint,
    gracelimit integer,
    lockout boolean,
    maxfailure integer,
    lockoutduration bigint,
    requireunlock boolean,
    resetfailurecount bigint,
    resetticketmaxage bigint
);


ALTER TABLE passwordpolicy OWNER TO root;

--
-- Name: passwordpolicyrel; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE passwordpolicyrel (
    passwordpolicyrelid bigint NOT NULL,
    passwordpolicyid bigint,
    classnameid bigint,
    classpk bigint
);


ALTER TABLE passwordpolicyrel OWNER TO root;

--
-- Name: passwordtracker; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE passwordtracker (
    passwordtrackerid bigint NOT NULL,
    userid bigint,
    createdate timestamp without time zone,
    password_ character varying(75)
);


ALTER TABLE passwordtracker OWNER TO root;

--
-- Name: phone; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE phone (
    uuid_ character varying(75),
    phoneid bigint NOT NULL,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    classnameid bigint,
    classpk bigint,
    number_ character varying(75),
    extension character varying(75),
    typeid integer,
    primary_ boolean
);


ALTER TABLE phone OWNER TO root;

--
-- Name: pluginsetting; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE pluginsetting (
    pluginsettingid bigint NOT NULL,
    companyid bigint,
    pluginid character varying(75),
    plugintype character varying(75),
    roles text,
    active_ boolean
);


ALTER TABLE pluginsetting OWNER TO root;

--
-- Name: pollschoice; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE pollschoice (
    uuid_ character varying(75),
    choiceid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    questionid bigint,
    name character varying(75),
    description text
);


ALTER TABLE pollschoice OWNER TO root;

--
-- Name: pollsquestion; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE pollsquestion (
    uuid_ character varying(75),
    questionid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    title text,
    description text,
    expirationdate timestamp without time zone,
    lastvotedate timestamp without time zone
);


ALTER TABLE pollsquestion OWNER TO root;

--
-- Name: pollsvote; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE pollsvote (
    uuid_ character varying(75),
    voteid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    questionid bigint,
    choiceid bigint,
    votedate timestamp without time zone
);


ALTER TABLE pollsvote OWNER TO root;

--
-- Name: portalpreferences; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE portalpreferences (
    portalpreferencesid bigint NOT NULL,
    ownerid bigint,
    ownertype integer,
    preferences text
);


ALTER TABLE portalpreferences OWNER TO root;

--
-- Name: portlet; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE portlet (
    id_ bigint NOT NULL,
    companyid bigint,
    portletid character varying(200),
    roles text,
    active_ boolean
);


ALTER TABLE portlet OWNER TO root;

--
-- Name: portletitem; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE portletitem (
    portletitemid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    name character varying(75),
    portletid character varying(200),
    classnameid bigint
);


ALTER TABLE portletitem OWNER TO root;

--
-- Name: portletpreferences; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE portletpreferences (
    portletpreferencesid bigint NOT NULL,
    ownerid bigint,
    ownertype integer,
    plid bigint,
    portletid character varying(200),
    preferences text
);


ALTER TABLE portletpreferences OWNER TO root;

--
-- Name: quartz_blob_triggers; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE quartz_blob_triggers (
    sched_name character varying(120) NOT NULL,
    trigger_name character varying(200) NOT NULL,
    trigger_group character varying(200) NOT NULL,
    blob_data bytea
);


ALTER TABLE quartz_blob_triggers OWNER TO root;

--
-- Name: quartz_calendars; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE quartz_calendars (
    sched_name character varying(120) NOT NULL,
    calendar_name character varying(200) NOT NULL,
    calendar bytea NOT NULL
);


ALTER TABLE quartz_calendars OWNER TO root;

--
-- Name: quartz_cron_triggers; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE quartz_cron_triggers (
    sched_name character varying(120) NOT NULL,
    trigger_name character varying(200) NOT NULL,
    trigger_group character varying(200) NOT NULL,
    cron_expression character varying(200) NOT NULL,
    time_zone_id character varying(80)
);


ALTER TABLE quartz_cron_triggers OWNER TO root;

--
-- Name: quartz_fired_triggers; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE quartz_fired_triggers (
    sched_name character varying(120) NOT NULL,
    entry_id character varying(95) NOT NULL,
    trigger_name character varying(200) NOT NULL,
    trigger_group character varying(200) NOT NULL,
    instance_name character varying(200) NOT NULL,
    fired_time bigint NOT NULL,
    priority integer NOT NULL,
    state character varying(16) NOT NULL,
    job_name character varying(200),
    job_group character varying(200),
    is_nonconcurrent boolean,
    requests_recovery boolean
);


ALTER TABLE quartz_fired_triggers OWNER TO root;

--
-- Name: quartz_job_details; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE quartz_job_details (
    sched_name character varying(120) NOT NULL,
    job_name character varying(200) NOT NULL,
    job_group character varying(200) NOT NULL,
    description character varying(250),
    job_class_name character varying(250) NOT NULL,
    is_durable boolean NOT NULL,
    is_nonconcurrent boolean NOT NULL,
    is_update_data boolean NOT NULL,
    requests_recovery boolean NOT NULL,
    job_data bytea
);


ALTER TABLE quartz_job_details OWNER TO root;

--
-- Name: quartz_locks; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE quartz_locks (
    sched_name character varying(120) NOT NULL,
    lock_name character varying(40) NOT NULL
);


ALTER TABLE quartz_locks OWNER TO root;

--
-- Name: quartz_paused_trigger_grps; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE quartz_paused_trigger_grps (
    sched_name character varying(120) NOT NULL,
    trigger_group character varying(200) NOT NULL
);


ALTER TABLE quartz_paused_trigger_grps OWNER TO root;

--
-- Name: quartz_scheduler_state; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE quartz_scheduler_state (
    sched_name character varying(120) NOT NULL,
    instance_name character varying(200) NOT NULL,
    last_checkin_time bigint NOT NULL,
    checkin_interval bigint NOT NULL
);


ALTER TABLE quartz_scheduler_state OWNER TO root;

--
-- Name: quartz_simple_triggers; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE quartz_simple_triggers (
    sched_name character varying(120) NOT NULL,
    trigger_name character varying(200) NOT NULL,
    trigger_group character varying(200) NOT NULL,
    repeat_count bigint NOT NULL,
    repeat_interval bigint NOT NULL,
    times_triggered bigint NOT NULL
);


ALTER TABLE quartz_simple_triggers OWNER TO root;

--
-- Name: quartz_simprop_triggers; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE quartz_simprop_triggers (
    sched_name character varying(120) NOT NULL,
    trigger_name character varying(200) NOT NULL,
    trigger_group character varying(200) NOT NULL,
    str_prop_1 character varying(512),
    str_prop_2 character varying(512),
    str_prop_3 character varying(512),
    int_prop_1 integer,
    int_prop_2 integer,
    long_prop_1 bigint,
    long_prop_2 bigint,
    dec_prop_1 numeric(13,4),
    dec_prop_2 numeric(13,4),
    bool_prop_1 boolean,
    bool_prop_2 boolean
);


ALTER TABLE quartz_simprop_triggers OWNER TO root;

--
-- Name: quartz_triggers; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE quartz_triggers (
    sched_name character varying(120) NOT NULL,
    trigger_name character varying(200) NOT NULL,
    trigger_group character varying(200) NOT NULL,
    job_name character varying(200) NOT NULL,
    job_group character varying(200) NOT NULL,
    description character varying(250),
    next_fire_time bigint,
    prev_fire_time bigint,
    priority integer,
    trigger_state character varying(16) NOT NULL,
    trigger_type character varying(8) NOT NULL,
    start_time bigint NOT NULL,
    end_time bigint,
    calendar_name character varying(200),
    misfire_instr integer,
    job_data bytea
);


ALTER TABLE quartz_triggers OWNER TO root;

--
-- Name: ratingsentry; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE ratingsentry (
    entryid bigint NOT NULL,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    classnameid bigint,
    classpk bigint,
    score double precision
);


ALTER TABLE ratingsentry OWNER TO root;

--
-- Name: ratingsstats; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE ratingsstats (
    statsid bigint NOT NULL,
    classnameid bigint,
    classpk bigint,
    totalentries integer,
    totalscore double precision,
    averagescore double precision
);


ALTER TABLE ratingsstats OWNER TO root;

--
-- Name: region; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE region (
    regionid bigint NOT NULL,
    countryid bigint,
    regioncode character varying(75),
    name character varying(75),
    active_ boolean
);


ALTER TABLE region OWNER TO root;

--
-- Name: release_; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE release_ (
    releaseid bigint NOT NULL,
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    servletcontextname character varying(75),
    buildnumber integer,
    builddate timestamp without time zone,
    verified boolean,
    state_ integer,
    teststring character varying(1024)
);


ALTER TABLE release_ OWNER TO root;

--
-- Name: repository; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE repository (
    uuid_ character varying(75),
    repositoryid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    classnameid bigint,
    name character varying(75),
    description text,
    portletid character varying(200),
    typesettings text,
    dlfolderid bigint
);


ALTER TABLE repository OWNER TO root;

--
-- Name: repositoryentry; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE repositoryentry (
    uuid_ character varying(75),
    repositoryentryid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    repositoryid bigint,
    mappedid character varying(75),
    manualcheckinrequired boolean
);


ALTER TABLE repositoryentry OWNER TO root;

--
-- Name: resourceaction; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE resourceaction (
    resourceactionid bigint NOT NULL,
    name character varying(255),
    actionid character varying(75),
    bitwisevalue bigint
);


ALTER TABLE resourceaction OWNER TO root;

--
-- Name: resourceblock; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE resourceblock (
    resourceblockid bigint NOT NULL,
    companyid bigint,
    groupid bigint,
    name character varying(75),
    permissionshash character varying(75),
    referencecount bigint
);


ALTER TABLE resourceblock OWNER TO root;

--
-- Name: resourceblockpermission; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE resourceblockpermission (
    resourceblockpermissionid bigint NOT NULL,
    resourceblockid bigint,
    roleid bigint,
    actionids bigint
);


ALTER TABLE resourceblockpermission OWNER TO root;

--
-- Name: resourcepermission; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE resourcepermission (
    resourcepermissionid bigint NOT NULL,
    companyid bigint,
    name character varying(255),
    scope integer,
    primkey character varying(255),
    roleid bigint,
    ownerid bigint,
    actionids bigint
);


ALTER TABLE resourcepermission OWNER TO root;

--
-- Name: resourcetypepermission; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE resourcetypepermission (
    resourcetypepermissionid bigint NOT NULL,
    companyid bigint,
    groupid bigint,
    name character varying(75),
    roleid bigint,
    actionids bigint
);


ALTER TABLE resourcetypepermission OWNER TO root;

--
-- Name: role_; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE role_ (
    uuid_ character varying(75),
    roleid bigint NOT NULL,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    classnameid bigint,
    classpk bigint,
    name character varying(75),
    title text,
    description text,
    type_ integer,
    subtype character varying(75)
);


ALTER TABLE role_ OWNER TO root;

--
-- Name: scframeworkversi_scproductvers; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE scframeworkversi_scproductvers (
    frameworkversionid bigint NOT NULL,
    productversionid bigint NOT NULL
);


ALTER TABLE scframeworkversi_scproductvers OWNER TO root;

--
-- Name: scframeworkversion; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE scframeworkversion (
    frameworkversionid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    name character varying(75),
    url text,
    active_ boolean,
    priority integer
);


ALTER TABLE scframeworkversion OWNER TO root;

--
-- Name: sclicense; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE sclicense (
    licenseid bigint NOT NULL,
    name character varying(75),
    url text,
    opensource boolean,
    active_ boolean,
    recommended boolean
);


ALTER TABLE sclicense OWNER TO root;

--
-- Name: sclicenses_scproductentries; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE sclicenses_scproductentries (
    licenseid bigint NOT NULL,
    productentryid bigint NOT NULL
);


ALTER TABLE sclicenses_scproductentries OWNER TO root;

--
-- Name: scproductentry; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE scproductentry (
    productentryid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    name character varying(75),
    type_ character varying(75),
    tags character varying(255),
    shortdescription text,
    longdescription text,
    pageurl text,
    author character varying(75),
    repogroupid character varying(75),
    repoartifactid character varying(75)
);


ALTER TABLE scproductentry OWNER TO root;

--
-- Name: scproductscreenshot; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE scproductscreenshot (
    productscreenshotid bigint NOT NULL,
    companyid bigint,
    groupid bigint,
    productentryid bigint,
    thumbnailid bigint,
    fullimageid bigint,
    priority integer
);


ALTER TABLE scproductscreenshot OWNER TO root;

--
-- Name: scproductversion; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE scproductversion (
    productversionid bigint NOT NULL,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    productentryid bigint,
    version character varying(75),
    changelog text,
    downloadpageurl text,
    directdownloadurl character varying(2000),
    repostoreartifact boolean
);


ALTER TABLE scproductversion OWNER TO root;

--
-- Name: servicecomponent; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE servicecomponent (
    servicecomponentid bigint NOT NULL,
    buildnamespace character varying(75),
    buildnumber bigint,
    builddate bigint,
    data_ text
);


ALTER TABLE servicecomponent OWNER TO root;

--
-- Name: shard; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE shard (
    shardid bigint NOT NULL,
    classnameid bigint,
    classpk bigint,
    name character varying(75)
);


ALTER TABLE shard OWNER TO root;

--
-- Name: shoppingcart; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE shoppingcart (
    cartid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    itemids text,
    couponcodes character varying(75),
    altshipping integer,
    insure boolean
);


ALTER TABLE shoppingcart OWNER TO root;

--
-- Name: shoppingcategory; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE shoppingcategory (
    categoryid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    parentcategoryid bigint,
    name character varying(75),
    description text
);


ALTER TABLE shoppingcategory OWNER TO root;

--
-- Name: shoppingcoupon; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE shoppingcoupon (
    couponid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    code_ character varying(75),
    name character varying(75),
    description text,
    startdate timestamp without time zone,
    enddate timestamp without time zone,
    active_ boolean,
    limitcategories text,
    limitskus text,
    minorder double precision,
    discount double precision,
    discounttype character varying(75)
);


ALTER TABLE shoppingcoupon OWNER TO root;

--
-- Name: shoppingitem; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE shoppingitem (
    itemid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    categoryid bigint,
    sku character varying(75),
    name character varying(200),
    description text,
    properties text,
    fields_ boolean,
    fieldsquantities text,
    minquantity integer,
    maxquantity integer,
    price double precision,
    discount double precision,
    taxable boolean,
    shipping double precision,
    useshippingformula boolean,
    requiresshipping boolean,
    stockquantity integer,
    featured_ boolean,
    sale_ boolean,
    smallimage boolean,
    smallimageid bigint,
    smallimageurl text,
    mediumimage boolean,
    mediumimageid bigint,
    mediumimageurl text,
    largeimage boolean,
    largeimageid bigint,
    largeimageurl text
);


ALTER TABLE shoppingitem OWNER TO root;

--
-- Name: shoppingitemfield; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE shoppingitemfield (
    itemfieldid bigint NOT NULL,
    itemid bigint,
    name character varying(75),
    values_ text,
    description text
);


ALTER TABLE shoppingitemfield OWNER TO root;

--
-- Name: shoppingitemprice; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE shoppingitemprice (
    itempriceid bigint NOT NULL,
    itemid bigint,
    minquantity integer,
    maxquantity integer,
    price double precision,
    discount double precision,
    taxable boolean,
    shipping double precision,
    useshippingformula boolean,
    status integer
);


ALTER TABLE shoppingitemprice OWNER TO root;

--
-- Name: shoppingorder; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE shoppingorder (
    orderid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    number_ character varying(75),
    tax double precision,
    shipping double precision,
    altshipping character varying(75),
    requiresshipping boolean,
    insure boolean,
    insurance double precision,
    couponcodes character varying(75),
    coupondiscount double precision,
    billingfirstname character varying(75),
    billinglastname character varying(75),
    billingemailaddress character varying(75),
    billingcompany character varying(75),
    billingstreet character varying(75),
    billingcity character varying(75),
    billingstate character varying(75),
    billingzip character varying(75),
    billingcountry character varying(75),
    billingphone character varying(75),
    shiptobilling boolean,
    shippingfirstname character varying(75),
    shippinglastname character varying(75),
    shippingemailaddress character varying(75),
    shippingcompany character varying(75),
    shippingstreet character varying(75),
    shippingcity character varying(75),
    shippingstate character varying(75),
    shippingzip character varying(75),
    shippingcountry character varying(75),
    shippingphone character varying(75),
    ccname character varying(75),
    cctype character varying(75),
    ccnumber character varying(75),
    ccexpmonth integer,
    ccexpyear integer,
    ccvernumber character varying(75),
    comments text,
    pptxnid character varying(75),
    pppaymentstatus character varying(75),
    pppaymentgross double precision,
    ppreceiveremail character varying(75),
    pppayeremail character varying(75),
    sendorderemail boolean,
    sendshippingemail boolean
);


ALTER TABLE shoppingorder OWNER TO root;

--
-- Name: shoppingorderitem; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE shoppingorderitem (
    orderitemid bigint NOT NULL,
    orderid bigint,
    itemid character varying(75),
    sku character varying(75),
    name character varying(200),
    description text,
    properties text,
    price double precision,
    quantity integer,
    shippeddate timestamp without time zone
);


ALTER TABLE shoppingorderitem OWNER TO root;

--
-- Name: socialactivity; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE socialactivity (
    activityid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    userid bigint,
    createdate bigint,
    activitysetid bigint,
    mirroractivityid bigint,
    classnameid bigint,
    classpk bigint,
    parentclassnameid bigint,
    parentclasspk bigint,
    type_ integer,
    extradata text,
    receiveruserid bigint
);


ALTER TABLE socialactivity OWNER TO root;

--
-- Name: socialactivityachievement; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE socialactivityachievement (
    activityachievementid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    userid bigint,
    createdate bigint,
    name character varying(75),
    firstingroup boolean
);


ALTER TABLE socialactivityachievement OWNER TO root;

--
-- Name: socialactivitycounter; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE socialactivitycounter (
    activitycounterid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    classnameid bigint,
    classpk bigint,
    name character varying(75),
    ownertype integer,
    currentvalue integer,
    totalvalue integer,
    gracevalue integer,
    startperiod integer,
    endperiod integer,
    active_ boolean
);


ALTER TABLE socialactivitycounter OWNER TO root;

--
-- Name: socialactivitylimit; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE socialactivitylimit (
    activitylimitid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    userid bigint,
    classnameid bigint,
    classpk bigint,
    activitytype integer,
    activitycountername character varying(75),
    value character varying(75)
);


ALTER TABLE socialactivitylimit OWNER TO root;

--
-- Name: socialactivityset; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE socialactivityset (
    activitysetid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    userid bigint,
    createdate bigint,
    modifieddate bigint,
    classnameid bigint,
    classpk bigint,
    type_ integer,
    extradata text,
    activitycount integer
);


ALTER TABLE socialactivityset OWNER TO root;

--
-- Name: socialactivitysetting; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE socialactivitysetting (
    activitysettingid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    classnameid bigint,
    activitytype integer,
    name character varying(75),
    value character varying(1024)
);


ALTER TABLE socialactivitysetting OWNER TO root;

--
-- Name: socialrelation; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE socialrelation (
    uuid_ character varying(75),
    relationid bigint NOT NULL,
    companyid bigint,
    createdate bigint,
    userid1 bigint,
    userid2 bigint,
    type_ integer
);


ALTER TABLE socialrelation OWNER TO root;

--
-- Name: socialrequest; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE socialrequest (
    uuid_ character varying(75),
    requestid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    userid bigint,
    createdate bigint,
    modifieddate bigint,
    classnameid bigint,
    classpk bigint,
    type_ integer,
    extradata text,
    receiveruserid bigint,
    status integer
);


ALTER TABLE socialrequest OWNER TO root;

--
-- Name: subscription; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE subscription (
    subscriptionid bigint NOT NULL,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    classnameid bigint,
    classpk bigint,
    frequency character varying(75)
);


ALTER TABLE subscription OWNER TO root;

--
-- Name: systemevent; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE systemevent (
    systemeventid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    classnameid bigint,
    classpk bigint,
    classuuid character varying(75),
    referrerclassnameid bigint,
    parentsystemeventid bigint,
    systemeventsetkey bigint,
    type_ integer,
    extradata text
);


ALTER TABLE systemevent OWNER TO root;

--
-- Name: team; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE team (
    teamid bigint NOT NULL,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    groupid bigint,
    name character varying(75),
    description text
);


ALTER TABLE team OWNER TO root;

--
-- Name: ticket; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE ticket (
    ticketid bigint NOT NULL,
    companyid bigint,
    createdate timestamp without time zone,
    classnameid bigint,
    classpk bigint,
    key_ character varying(75),
    type_ integer,
    extrainfo text,
    expirationdate timestamp without time zone
);


ALTER TABLE ticket OWNER TO root;

--
-- Name: trashentry; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE trashentry (
    entryid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    classnameid bigint,
    classpk bigint,
    systemeventsetkey bigint,
    typesettings text,
    status integer
);


ALTER TABLE trashentry OWNER TO root;

--
-- Name: trashversion; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE trashversion (
    versionid bigint NOT NULL,
    entryid bigint,
    classnameid bigint,
    classpk bigint,
    typesettings text,
    status integer
);


ALTER TABLE trashversion OWNER TO root;

--
-- Name: user_; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE user_ (
    uuid_ character varying(75),
    userid bigint NOT NULL,
    companyid bigint,
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    defaultuser boolean,
    contactid bigint,
    password_ character varying(75),
    passwordencrypted boolean,
    passwordreset boolean,
    passwordmodifieddate timestamp without time zone,
    digest character varying(255),
    reminderqueryquestion character varying(75),
    reminderqueryanswer character varying(75),
    gracelogincount integer,
    screenname character varying(75),
    emailaddress character varying(75),
    facebookid bigint,
    ldapserverid bigint,
    openid character varying(1024),
    portraitid bigint,
    languageid character varying(75),
    timezoneid character varying(75),
    greeting character varying(255),
    comments text,
    firstname character varying(75),
    middlename character varying(75),
    lastname character varying(75),
    jobtitle character varying(100),
    logindate timestamp without time zone,
    loginip character varying(75),
    lastlogindate timestamp without time zone,
    lastloginip character varying(75),
    lastfailedlogindate timestamp without time zone,
    failedloginattempts integer,
    lockout boolean,
    lockoutdate timestamp without time zone,
    agreedtotermsofuse boolean,
    emailaddressverified boolean,
    status integer
);


ALTER TABLE user_ OWNER TO root;

--
-- Name: usergroup; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE usergroup (
    uuid_ character varying(75),
    usergroupid bigint NOT NULL,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    parentusergroupid bigint,
    name character varying(75),
    description text,
    addedbyldapimport boolean
);


ALTER TABLE usergroup OWNER TO root;

--
-- Name: usergroupgrouprole; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE usergroupgrouprole (
    usergroupid bigint NOT NULL,
    groupid bigint NOT NULL,
    roleid bigint NOT NULL
);


ALTER TABLE usergroupgrouprole OWNER TO root;

--
-- Name: usergrouprole; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE usergrouprole (
    userid bigint NOT NULL,
    groupid bigint NOT NULL,
    roleid bigint NOT NULL
);


ALTER TABLE usergrouprole OWNER TO root;

--
-- Name: usergroups_teams; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE usergroups_teams (
    teamid bigint NOT NULL,
    usergroupid bigint NOT NULL
);


ALTER TABLE usergroups_teams OWNER TO root;

--
-- Name: useridmapper; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE useridmapper (
    useridmapperid bigint NOT NULL,
    userid bigint,
    type_ character varying(75),
    description character varying(75),
    externaluserid character varying(75)
);


ALTER TABLE useridmapper OWNER TO root;

--
-- Name: usernotificationdelivery; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE usernotificationdelivery (
    usernotificationdeliveryid bigint NOT NULL,
    companyid bigint,
    userid bigint,
    portletid character varying(200),
    classnameid bigint,
    notificationtype integer,
    deliverytype integer,
    deliver boolean
);


ALTER TABLE usernotificationdelivery OWNER TO root;

--
-- Name: usernotificationevent; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE usernotificationevent (
    uuid_ character varying(75),
    usernotificationeventid bigint NOT NULL,
    companyid bigint,
    userid bigint,
    type_ character varying(75),
    "timestamp" bigint,
    deliverby bigint,
    delivered boolean,
    payload text,
    archived boolean
);


ALTER TABLE usernotificationevent OWNER TO root;

--
-- Name: users_groups; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE users_groups (
    groupid bigint NOT NULL,
    userid bigint NOT NULL
);


ALTER TABLE users_groups OWNER TO root;

--
-- Name: users_orgs; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE users_orgs (
    organizationid bigint NOT NULL,
    userid bigint NOT NULL
);


ALTER TABLE users_orgs OWNER TO root;

--
-- Name: users_roles; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE users_roles (
    roleid bigint NOT NULL,
    userid bigint NOT NULL
);


ALTER TABLE users_roles OWNER TO root;

--
-- Name: users_teams; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE users_teams (
    teamid bigint NOT NULL,
    userid bigint NOT NULL
);


ALTER TABLE users_teams OWNER TO root;

--
-- Name: users_usergroups; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE users_usergroups (
    userid bigint NOT NULL,
    usergroupid bigint NOT NULL
);


ALTER TABLE users_usergroups OWNER TO root;

--
-- Name: usertracker; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE usertracker (
    usertrackerid bigint NOT NULL,
    companyid bigint,
    userid bigint,
    modifieddate timestamp without time zone,
    sessionid character varying(200),
    remoteaddr character varying(75),
    remotehost character varying(75),
    useragent character varying(200)
);


ALTER TABLE usertracker OWNER TO root;

--
-- Name: usertrackerpath; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE usertrackerpath (
    usertrackerpathid bigint NOT NULL,
    usertrackerid bigint,
    path_ text,
    pathdate timestamp without time zone
);


ALTER TABLE usertrackerpath OWNER TO root;

--
-- Name: virtualhost; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE virtualhost (
    virtualhostid bigint NOT NULL,
    companyid bigint,
    layoutsetid bigint,
    hostname character varying(75)
);


ALTER TABLE virtualhost OWNER TO root;

--
-- Name: webdavprops; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE webdavprops (
    webdavpropsid bigint NOT NULL,
    companyid bigint,
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    classnameid bigint,
    classpk bigint,
    props text
);


ALTER TABLE webdavprops OWNER TO root;

--
-- Name: website; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE website (
    uuid_ character varying(75),
    websiteid bigint NOT NULL,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    classnameid bigint,
    classpk bigint,
    url text,
    typeid integer,
    primary_ boolean
);


ALTER TABLE website OWNER TO root;

--
-- Name: wikinode; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE wikinode (
    uuid_ character varying(75),
    nodeid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    name character varying(75),
    description text,
    lastpostdate timestamp without time zone,
    status integer,
    statusbyuserid bigint,
    statusbyusername character varying(75),
    statusdate timestamp without time zone
);


ALTER TABLE wikinode OWNER TO root;

--
-- Name: wikipage; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE wikipage (
    uuid_ character varying(75),
    pageid bigint NOT NULL,
    resourceprimkey bigint,
    groupid bigint,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    nodeid bigint,
    title character varying(255),
    version double precision,
    minoredit boolean,
    content text,
    summary text,
    format character varying(75),
    head boolean,
    parenttitle character varying(255),
    redirecttitle character varying(255),
    status integer,
    statusbyuserid bigint,
    statusbyusername character varying(75),
    statusdate timestamp without time zone
);


ALTER TABLE wikipage OWNER TO root;

--
-- Name: wikipageresource; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE wikipageresource (
    uuid_ character varying(75),
    resourceprimkey bigint NOT NULL,
    nodeid bigint,
    title character varying(255)
);


ALTER TABLE wikipageresource OWNER TO root;

--
-- Name: workflowdefinitionlink; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE workflowdefinitionlink (
    workflowdefinitionlinkid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    classnameid bigint,
    classpk bigint,
    typepk bigint,
    workflowdefinitionname character varying(75),
    workflowdefinitionversion integer
);


ALTER TABLE workflowdefinitionlink OWNER TO root;

--
-- Name: workflowinstancelink; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE workflowinstancelink (
    workflowinstancelinkid bigint NOT NULL,
    groupid bigint,
    companyid bigint,
    userid bigint,
    username character varying(75),
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    classnameid bigint,
    classpk bigint,
    workflowinstanceid bigint
);


ALTER TABLE workflowinstancelink OWNER TO root;

--
-- Data for Name: account_; Type: TABLE DATA; Schema: public; Owner: root
--

COPY account_ (accountid, companyid, userid, username, createdate, modifieddate, parentaccountid, name, legalname, legalid, legaltype, siccode, tickersymbol, industry, type_, size_) FROM stdin;
10157	10155	0		2017-03-10 17:05:59.237	2017-03-10 17:05:59.237	0	Liferay								
\.


--
-- Data for Name: address; Type: TABLE DATA; Schema: public; Owner: root
--

COPY address (uuid_, addressid, companyid, userid, username, createdate, modifieddate, classnameid, classpk, street1, street2, street3, city, zip, regionid, countryid, typeid, mailing, primary_) FROM stdin;
\.


--
-- Data for Name: announcementsdelivery; Type: TABLE DATA; Schema: public; Owner: root
--

COPY announcementsdelivery (deliveryid, companyid, userid, type_, email, sms, website) FROM stdin;
\.


--
-- Data for Name: announcementsentry; Type: TABLE DATA; Schema: public; Owner: root
--

COPY announcementsentry (uuid_, entryid, companyid, userid, username, createdate, modifieddate, classnameid, classpk, title, content, url, type_, displaydate, expirationdate, priority, alert) FROM stdin;
\.


--
-- Data for Name: announcementsflag; Type: TABLE DATA; Schema: public; Owner: root
--

COPY announcementsflag (flagid, userid, createdate, entryid, value) FROM stdin;
\.


--
-- Data for Name: assetcategory; Type: TABLE DATA; Schema: public; Owner: root
--

COPY assetcategory (uuid_, categoryid, groupid, companyid, userid, username, createdate, modifieddate, parentcategoryid, leftcategoryid, rightcategoryid, name, title, description, vocabularyid) FROM stdin;
\.


--
-- Data for Name: assetcategoryproperty; Type: TABLE DATA; Schema: public; Owner: root
--

COPY assetcategoryproperty (categorypropertyid, companyid, userid, username, createdate, modifieddate, categoryid, key_, value) FROM stdin;
\.


--
-- Data for Name: assetentries_assetcategories; Type: TABLE DATA; Schema: public; Owner: root
--

COPY assetentries_assetcategories (categoryid, entryid) FROM stdin;
\.


--
-- Data for Name: assetentries_assettags; Type: TABLE DATA; Schema: public; Owner: root
--

COPY assetentries_assettags (entryid, tagid) FROM stdin;
\.


--
-- Data for Name: assetentry; Type: TABLE DATA; Schema: public; Owner: root
--

COPY assetentry (entryid, groupid, companyid, userid, username, createdate, modifieddate, classnameid, classpk, classuuid, classtypeid, visible, startdate, enddate, publishdate, expirationdate, mimetype, title, description, summary, url, layoutuuid, height, width, priority, viewcount) FROM stdin;
10180	10173	10155	10159		2017-03-10 17:06:00.125	2017-03-10 17:06:00.125	10116	10178	70ab8045-d203-46bc-aec9-80c25244c77e	0	f	\N	\N	\N	\N	text/html	10176					0	0	0	0
10189	10182	10155	10159		2017-03-10 17:06:00.581	2017-03-10 17:06:00.581	10116	10187	3176cffe-8f06-493d-aa7a-3e49713e3fe6	0	f	\N	\N	\N	\N	text/html	10185					0	0	0	0
10204	10195	10155	10199	Test Test	2017-03-10 17:06:00.789	2017-03-10 17:06:00.789	10005	10199	8c7993af-d36e-48a6-9f4e-e6b2ad708801	0	f	\N	\N	\N	\N		Test Test					0	0	0	0
10325	10317	10155	10159		2017-03-10 17:06:03.223	2017-03-10 17:06:03.223	10116	10322	903ca121-d7d2-4d38-b431-9f0bc5b56893	0	f	\N	\N	\N	\N	text/html	10320					0	0	0	0
10336	10329	10155	10159		2017-03-10 17:06:03.425	2017-03-10 17:06:03.425	10116	10334	eaf52c89-f2a7-447e-ab30-8cc7fdabbebb	0	f	\N	\N	\N	\N	text/html	10332					0	0	0	0
10346	10339	10155	10159		2017-03-10 17:06:03.544	2017-03-10 17:06:03.544	10116	10344	e39d9bd0-b8f7-4e06-87a9-a56db2114a04	0	f	\N	\N	\N	\N	text/html	10342					0	0	0	0
10365	10350	10155	10159		2017-03-10 17:06:04.004	2017-03-10 17:06:04.004	10116	10363	8abd4560-2d9c-4702-9d01-efe9aaca2956	0	f	\N	\N	\N	\N	text/html	10361					0	0	0	0
10373	10350	10155	10159		2017-03-10 17:06:04.274	2017-03-10 17:06:04.274	10116	10371	96bdea03-14c6-45d8-adda-572f68d47638	0	f	\N	\N	\N	\N	text/html	10369					0	0	0	0
10391	10376	10155	10159		2017-03-10 17:06:04.518	2017-03-10 17:06:04.518	10116	10389	f105264c-e630-482a-aa5c-6e0e594e6436	0	f	\N	\N	\N	\N	text/html	10387					0	0	0	0
10400	10376	10155	10159		2017-03-10 17:06:04.652	2017-03-10 17:06:04.652	10116	10398	a7870874-7e45-4e37-963a-9db59ce7aef3	0	f	\N	\N	\N	\N	text/html	10396					0	0	0	0
10408	10376	10155	10159		2017-03-10 17:06:04.748	2017-03-10 17:06:04.748	10116	10406	2ed2f031-2968-4d08-a567-98b65c8c9dd1	0	f	\N	\N	\N	\N	text/html	10404					0	0	0	0
10445	10201	10155	10199	Test Test	2017-03-10 17:06:55.061	2017-03-10 17:06:55.061	10116	10443	d62caa73-a51b-43d7-b115-0b81d3b7890e	0	f	\N	\N	\N	\N	text/html	10441					0	0	0	0
10451	10201	10155	10199	Test Test	2017-03-10 17:06:55.135	2017-03-10 17:06:55.135	10116	10449	31048e36-1a71-498e-9662-c6b122d3fe88	0	f	\N	\N	\N	\N	text/html	10447					0	0	0	0
10460	10195	10155	10199	Test Test	2017-03-10 17:07:18.116	2017-03-10 17:07:39.338	10001	10457		0	f	\N	\N	\N	\N		Staging Site					0	0	0	0
10466	10195	10155	10199	Test Test	2017-03-10 17:07:39.368	2017-03-10 17:07:39.367	10001	10463		0	f	\N	\N	\N	\N		Staging Site (Staging)					0	0	0	0
10492	10463	10155	10199	Test Test	2017-03-10 17:08:17.149	2017-03-10 17:08:17.149	10116	10490	23060d18-5dc8-4446-ac41-4e7057f4854f	0	f	\N	\N	\N	\N	text/html	10488					0	0	0	0
10505	10463	10155	10199	Test Test	2017-03-10 17:08:51.986	2017-03-10 17:08:51.986	10116	10503	d62b9dc2-7a28-4734-af0d-1e070161d0e0	0	f	\N	\N	\N	\N	text/html	10499					0	0	0	0
10501	10463	10155	10199	Test Test	2017-03-10 17:08:51.774	2017-03-10 17:08:51.774	10109	10499	7d19640a-5caf-4298-a32d-c15bec4d4aa3	0	t	\N	\N	2017-03-10 17:08:00	\N	text/html	<?xml version='1.0' encoding='UTF-8'?><root available-locales="en_US" default-locale="en_US"><Title language-id="en_US">Web Content Title</Title></root>					0	0	0	1
\.


--
-- Data for Name: assetlink; Type: TABLE DATA; Schema: public; Owner: root
--

COPY assetlink (linkid, companyid, userid, username, createdate, entryid1, entryid2, type_, weight) FROM stdin;
\.


--
-- Data for Name: assettag; Type: TABLE DATA; Schema: public; Owner: root
--

COPY assettag (tagid, groupid, companyid, userid, username, createdate, modifieddate, name, assetcount) FROM stdin;
\.


--
-- Data for Name: assettagproperty; Type: TABLE DATA; Schema: public; Owner: root
--

COPY assettagproperty (tagpropertyid, companyid, userid, username, createdate, modifieddate, tagid, key_, value) FROM stdin;
\.


--
-- Data for Name: assettagstats; Type: TABLE DATA; Schema: public; Owner: root
--

COPY assettagstats (tagstatsid, tagid, classnameid, assetcount) FROM stdin;
\.


--
-- Data for Name: assetvocabulary; Type: TABLE DATA; Schema: public; Owner: root
--

COPY assetvocabulary (uuid_, vocabularyid, groupid, companyid, userid, username, createdate, modifieddate, name, title, description, settings_) FROM stdin;
089725cd-d654-4caa-81b7-cecb7d14a648	10324	10195	10155	10159		2017-03-10 17:06:03.225	2017-03-10 17:06:03.225	Topic	<?xml version='1.0' encoding='UTF-8'?><root available-locales="en_US" default-locale="en_US"><Title language-id="en_US">Topic</Title></root>		
8b44176c-f1a2-46fa-ba62-382405de086c	10470	10457	10155	10159		2017-03-10 17:07:40.124	2017-03-10 17:07:40.124	Topic	<?xml version='1.0' encoding='UTF-8'?><root available-locales="en_US" default-locale="en_US"><Title language-id="en_US">Topic</Title></root>		
8b44176c-f1a2-46fa-ba62-382405de086c	10471	10463	10155	10159		2017-03-10 17:07:40.303	2017-03-10 17:07:40.303	Topic	<?xml version='1.0' encoding='UTF-8'?><root available-locales="en_US" default-locale="en_US"><Title language-id="en_US">Topic</Title></root>		
\.


--
-- Data for Name: backgroundtask; Type: TABLE DATA; Schema: public; Owner: root
--

COPY backgroundtask (backgroundtaskid, groupid, companyid, userid, username, createdate, modifieddate, name, servletcontextnames, taskexecutorclassname, taskcontext, completed, completiondate, status, statusmessage) FROM stdin;
10467	10457	10155	10199	Test Test	2017-03-10 17:07:39.37	2017-03-10 17:07:40.415			com.liferay.portal.lar.backgroundtask.LayoutStagingBackgroundTaskExecutor	{"map":{"groupId":10457,"cmd":"publish_to_live","targetGroupId":10463,"sourceGroupId":10457,"parameterMap":{"map":{"THEME_REFERENCE":["true"],"PERMISSIONS":["true"],"DELETE_PORTLET_DATA":["false"],"UPDATE_LAST_PUBLISH_DATE":["true"],"USER_ID_STRATEGY":["CURRENT_USER_ID"],"DELETE_MISSING_LAYOUTS":["true"],"PORTLET_CONFIGURATION_ALL":["true"],"PORTLET_DATA":["true"],"PORTLET_CONFIGURATION":["true"],"LAYOUT_SET_SETTINGS":["false"],"PORTLET_DATA_ALL":["true"],"PERFORM_DIRECT_BINARY_IMPORT":["true"],"PORTLET_SETUP_ALL":["true"],"LOGO":["false"],"CATEGORIES":["true"],"LAYOUT_SET_PROTOTYPE_LINK_ENABLED":["false"],"DATA_STRATEGY":["DATA_STRATEGY_MIRROR_OVERWRITE"],"IGNORE_LAST_PUBLISH_DATE":["true"]},"javaClass":"java.util.HashMap"},"userId":10199,"fileName":"","exported":true,"validated":true,"privateLayout":false},"javaClass":"java.util.HashMap"}	t	2017-03-10 17:07:40.415	3	
10472	10463	10155	10199	Test Test	2017-03-10 17:07:40.358	2017-03-10 17:07:40.43			com.liferay.portal.lar.backgroundtask.StagingIndexingBackgroundTaskExecutor	{"map":{"portletDataContext":{"javaClass":"com.liferay.portal.lar.PortletDataContextImpl","serializable":{"startDate":null,"scopeGroupId":10463,"sourceGroupId":0,"assetCategoryUuidsMap":{"map":{},"javaClass":"java.util.HashMap"},"commentsMap":{"map":{},"javaClass":"java.util.HashMap"},"oldPlid":0,"endDate":null,"rootPortletId":null,"references":{"set":{},"javaClass":"java.util.HashSet"},"scopeType":null,"scopeLayoutUuid":null,"parameterMap":{"map":{"THEME_REFERENCE":["true"],"PERMISSIONS":["true"],"DELETE_PORTLET_DATA":["false"],"UPDATE_LAST_PUBLISH_DATE":["true"],"USER_ID_STRATEGY":["CURRENT_USER_ID"],"DELETE_MISSING_LAYOUTS":["true"],"PORTLET_CONFIGURATION_ALL":["true"],"PORTLET_DATA":["true"],"PORTLET_CONFIGURATION":["true"],"LAYOUT_SET_SETTINGS":["false"],"PORTLET_DATA_ALL":["true"],"PERFORM_DIRECT_BINARY_IMPORT":["true"],"PORTLET_SETUP_ALL":["true"],"LOGO":["false"],"CATEGORIES":["true"],"LAYOUT_SET_PROTOTYPE_LINK_ENABLED":["false"],"DATA_STRATEGY":["DATA_STRATEGY_MIRROR_OVERWRITE"],"IGNORE_LAST_PUBLISH_DATE":["true"]},"javaClass":"java.util.HashMap"},"primaryKeys":{"set":{},"javaClass":"java.util.HashSet"},"sourceCompanyGroupId":0,"expandoColumnsMap":{"map":{},"javaClass":"java.util.HashMap"},"notUniquePerLayout":{"set":{},"javaClass":"java.util.HashSet"},"companyGroupId":10195,"dataStrategy":"DATA_STRATEGY_MIRROR_OVERWRITE","assetLinksMap":{"map":{},"javaClass":"java.util.HashMap"},"deletionSystemEventModelTypes":{"set":{},"javaClass":"java.util.HashSet"},"assetCategoryIdsMap":{"map":{},"javaClass":"java.util.HashMap"},"groupId":10463,"permissionsMap":{"map":{},"javaClass":"java.util.HashMap"},"newPrimaryKeysMaps":{"map":{"com.liferay.portlet.wiki.model.WikiNode":{"map":{},"javaClass":"java.util.HashMap"},"com.liferay.portlet.asset.model.AssetCategory":{"map":{},"javaClass":"java.util.HashMap"},"com.liferay.portlet.asset.model.AssetVocabulary":{"map":{"10470":10471},"javaClass":"java.util.HashMap"}},"javaClass":"java.util.HashMap"},"sourceUserPersonalSiteGroupId":0,"sourceCompanyId":0,"plid":0,"scopedPrimaryKeys":{"set":{},"javaClass":"java.util.HashSet"},"companyId":10155,"userPersonalSiteGroupId":10192,"privateLayout":false,"assetTagNamesMap":{"map":{},"javaClass":"java.util.HashMap"}}},"userId":10199},"javaClass":"java.util.HashMap"}	t	2017-03-10 17:07:40.43	3	
\.


--
-- Data for Name: blogsentry; Type: TABLE DATA; Schema: public; Owner: root
--

COPY blogsentry (uuid_, entryid, groupid, companyid, userid, username, createdate, modifieddate, title, urltitle, description, content, displaydate, allowpingbacks, allowtrackbacks, trackbacks, smallimage, smallimageid, smallimageurl, status, statusbyuserid, statusbyusername, statusdate) FROM stdin;
\.


--
-- Data for Name: blogsstatsuser; Type: TABLE DATA; Schema: public; Owner: root
--

COPY blogsstatsuser (statsuserid, groupid, companyid, userid, entrycount, lastpostdate, ratingstotalentries, ratingstotalscore, ratingsaveragescore) FROM stdin;
\.


--
-- Data for Name: bookmarksentry; Type: TABLE DATA; Schema: public; Owner: root
--

COPY bookmarksentry (uuid_, entryid, groupid, companyid, userid, username, createdate, modifieddate, resourceblockid, folderid, treepath, name, url, description, visits, priority, status, statusbyuserid, statusbyusername, statusdate) FROM stdin;
\.


--
-- Data for Name: bookmarksfolder; Type: TABLE DATA; Schema: public; Owner: root
--

COPY bookmarksfolder (uuid_, folderid, groupid, companyid, userid, username, createdate, modifieddate, resourceblockid, parentfolderid, treepath, name, description, status, statusbyuserid, statusbyusername, statusdate) FROM stdin;
\.


--
-- Data for Name: browsertracker; Type: TABLE DATA; Schema: public; Owner: root
--

COPY browsertracker (browsertrackerid, userid, browserkey) FROM stdin;
\.


--
-- Data for Name: calevent; Type: TABLE DATA; Schema: public; Owner: root
--

COPY calevent (uuid_, eventid, groupid, companyid, userid, username, createdate, modifieddate, title, description, location, startdate, enddate, durationhour, durationminute, allday, timezonesensitive, type_, repeating, recurrence, remindby, firstreminder, secondreminder) FROM stdin;
\.


--
-- Data for Name: classname_; Type: TABLE DATA; Schema: public; Owner: root
--

COPY classname_ (classnameid, value) FROM stdin;
10001	com.liferay.portal.model.Group
10002	com.liferay.portal.model.Layout
10003	com.liferay.portal.model.Organization
10004	com.liferay.portal.model.Role
10005	com.liferay.portal.model.User
10006	com.liferay.portal.model.UserGroup
10007	com.liferay.portlet.blogs.model.BlogsEntry
10008	com.liferay.portlet.bookmarks.model.BookmarksEntry
10009	com.liferay.portlet.bookmarks.model.BookmarksFolder
10010	com.liferay.portlet.calendar.model.CalEvent
10011	com.liferay.portlet.documentlibrary.model.DLFileEntry
10012	com.liferay.portlet.documentlibrary.model.DLFolder
10013	com.liferay.portlet.journal.model.JournalFolder
10014	com.liferay.portlet.messageboards.model.MBMessage
10015	com.liferay.portlet.messageboards.model.MBThread
10016	com.liferay.portlet.wiki.model.WikiPage
10017	com.liferay.counter.model.Counter
10018	com.liferay.portal.kernel.workflow.WorkflowTask
10019	com.liferay.portal.model.Account
10020	com.liferay.portal.model.Address
10021	com.liferay.portal.model.BackgroundTask
10022	com.liferay.portal.model.BrowserTracker
10023	com.liferay.portal.model.ClassName
10024	com.liferay.portal.model.ClusterGroup
10025	com.liferay.portal.model.Company
10026	com.liferay.portal.model.Contact
10027	com.liferay.portal.model.Country
10028	com.liferay.portal.model.EmailAddress
10029	com.liferay.portal.model.Image
10030	com.liferay.portal.model.LayoutBranch
10031	com.liferay.portal.model.LayoutFriendlyURL
10032	com.liferay.portal.model.LayoutPrototype
10033	com.liferay.portal.model.LayoutRevision
10034	com.liferay.portal.model.LayoutSet
10035	com.liferay.portal.model.LayoutSetBranch
10036	com.liferay.portal.model.LayoutSetPrototype
10037	com.liferay.portal.model.ListType
10038	com.liferay.portal.model.Lock
10039	com.liferay.portal.model.MembershipRequest
10040	com.liferay.portal.model.OrgGroupRole
10041	com.liferay.portal.model.OrgLabor
10042	com.liferay.portal.model.PasswordPolicy
10043	com.liferay.portal.model.PasswordPolicyRel
10044	com.liferay.portal.model.PasswordTracker
10045	com.liferay.portal.model.Phone
10046	com.liferay.portal.model.PluginSetting
10047	com.liferay.portal.model.PortalPreferences
10048	com.liferay.portal.model.Portlet
10049	com.liferay.portal.model.PortletItem
10050	com.liferay.portal.model.PortletPreferences
10051	com.liferay.portal.model.Region
10052	com.liferay.portal.model.Release
10053	com.liferay.portal.model.Repository
10054	com.liferay.portal.model.RepositoryEntry
10055	com.liferay.portal.model.ResourceAction
10056	com.liferay.portal.model.ResourceBlock
10057	com.liferay.portal.model.ResourceBlockPermission
10058	com.liferay.portal.model.ResourcePermission
10059	com.liferay.portal.model.ResourceTypePermission
10060	com.liferay.portal.model.ServiceComponent
10061	com.liferay.portal.model.Shard
10062	com.liferay.portal.model.Subscription
10063	com.liferay.portal.model.SystemEvent
10064	com.liferay.portal.model.Team
10065	com.liferay.portal.model.Ticket
10066	com.liferay.portal.model.UserGroupGroupRole
10067	com.liferay.portal.model.UserGroupRole
10068	com.liferay.portal.model.UserIdMapper
10069	com.liferay.portal.model.UserNotificationDelivery
10070	com.liferay.portal.model.UserNotificationEvent
10071	com.liferay.portal.model.UserTracker
10072	com.liferay.portal.model.UserTrackerPath
10073	com.liferay.portal.model.VirtualHost
10074	com.liferay.portal.model.WebDAVProps
10075	com.liferay.portal.model.Website
10076	com.liferay.portal.model.WorkflowDefinitionLink
10077	com.liferay.portal.model.WorkflowInstanceLink
10078	com.liferay.portlet.announcements.model.AnnouncementsDelivery
10079	com.liferay.portlet.announcements.model.AnnouncementsEntry
10080	com.liferay.portlet.announcements.model.AnnouncementsFlag
10081	com.liferay.portlet.asset.model.AssetCategory
10082	com.liferay.portlet.asset.model.AssetCategoryProperty
10083	com.liferay.portlet.asset.model.AssetEntry
10084	com.liferay.portlet.asset.model.AssetLink
10085	com.liferay.portlet.asset.model.AssetTag
10086	com.liferay.portlet.asset.model.AssetTagProperty
10087	com.liferay.portlet.asset.model.AssetTagStats
10088	com.liferay.portlet.asset.model.AssetVocabulary
10089	com.liferay.portlet.blogs.model.BlogsStatsUser
10090	com.liferay.portlet.documentlibrary.model.DLContent
10091	com.liferay.portlet.documentlibrary.model.DLFileEntryMetadata
10092	com.liferay.portlet.documentlibrary.model.DLFileEntryType
10093	com.liferay.portlet.documentlibrary.model.DLFileRank
10094	com.liferay.portlet.documentlibrary.model.DLFileShortcut
10095	com.liferay.portlet.documentlibrary.model.DLFileVersion
10096	com.liferay.portlet.documentlibrary.model.DLSyncEvent
10097	com.liferay.portlet.dynamicdatalists.model.DDLRecord
10098	com.liferay.portlet.dynamicdatalists.model.DDLRecordSet
10099	com.liferay.portlet.dynamicdatalists.model.DDLRecordVersion
10100	com.liferay.portlet.dynamicdatamapping.model.DDMContent
10101	com.liferay.portlet.dynamicdatamapping.model.DDMStorageLink
10102	com.liferay.portlet.dynamicdatamapping.model.DDMStructure
10103	com.liferay.portlet.dynamicdatamapping.model.DDMStructureLink
10104	com.liferay.portlet.dynamicdatamapping.model.DDMTemplate
10105	com.liferay.portlet.expando.model.ExpandoColumn
10106	com.liferay.portlet.expando.model.ExpandoRow
10107	com.liferay.portlet.expando.model.ExpandoTable
10108	com.liferay.portlet.expando.model.ExpandoValue
10109	com.liferay.portlet.journal.model.JournalArticle
10110	com.liferay.portlet.journal.model.JournalArticleImage
10111	com.liferay.portlet.journal.model.JournalArticleResource
10112	com.liferay.portlet.journal.model.JournalContentSearch
10113	com.liferay.portlet.journal.model.JournalFeed
10114	com.liferay.portlet.messageboards.model.MBBan
10115	com.liferay.portlet.messageboards.model.MBCategory
10116	com.liferay.portlet.messageboards.model.MBDiscussion
10117	com.liferay.portlet.messageboards.model.MBMailingList
10118	com.liferay.portlet.messageboards.model.MBStatsUser
10119	com.liferay.portlet.messageboards.model.MBThreadFlag
10120	com.liferay.portlet.mobiledevicerules.model.MDRAction
10121	com.liferay.portlet.mobiledevicerules.model.MDRRule
10122	com.liferay.portlet.mobiledevicerules.model.MDRRuleGroup
10123	com.liferay.portlet.mobiledevicerules.model.MDRRuleGroupInstance
10124	com.liferay.portlet.polls.model.PollsChoice
10125	com.liferay.portlet.polls.model.PollsQuestion
10126	com.liferay.portlet.polls.model.PollsVote
10127	com.liferay.portlet.ratings.model.RatingsEntry
10128	com.liferay.portlet.ratings.model.RatingsStats
10129	com.liferay.portlet.shopping.model.ShoppingCart
10130	com.liferay.portlet.shopping.model.ShoppingCategory
10131	com.liferay.portlet.shopping.model.ShoppingCoupon
10132	com.liferay.portlet.shopping.model.ShoppingItem
10133	com.liferay.portlet.shopping.model.ShoppingItemField
10134	com.liferay.portlet.shopping.model.ShoppingItemPrice
10135	com.liferay.portlet.shopping.model.ShoppingOrder
10136	com.liferay.portlet.shopping.model.ShoppingOrderItem
10137	com.liferay.portlet.social.model.SocialActivity
10138	com.liferay.portlet.social.model.SocialActivityAchievement
10139	com.liferay.portlet.social.model.SocialActivityCounter
10140	com.liferay.portlet.social.model.SocialActivityLimit
10141	com.liferay.portlet.social.model.SocialActivitySet
10142	com.liferay.portlet.social.model.SocialActivitySetting
10143	com.liferay.portlet.social.model.SocialRelation
10144	com.liferay.portlet.social.model.SocialRequest
10145	com.liferay.portlet.softwarecatalog.model.SCFrameworkVersion
10146	com.liferay.portlet.softwarecatalog.model.SCLicense
10147	com.liferay.portlet.softwarecatalog.model.SCProductEntry
10148	com.liferay.portlet.softwarecatalog.model.SCProductScreenshot
10149	com.liferay.portlet.softwarecatalog.model.SCProductVersion
10150	com.liferay.portlet.trash.model.TrashEntry
10151	com.liferay.portlet.trash.model.TrashVersion
10152	com.liferay.portlet.wiki.model.WikiNode
10153	com.liferay.portlet.wiki.model.WikiPageResource
10191	com.liferay.portal.model.UserPersonalSite
10314	com.liferay.portlet.documentlibrary.util.RawMetadataProcessor
10422	com.liferay.portal.kernel.repository.model.FileEntry
10433	com.liferay.marketplace.model.App
10434	com.liferay.marketplace.model.Module
10469	com.liferay.portal.repository.liferayrepository.LiferayRepository
\.


--
-- Data for Name: clustergroup; Type: TABLE DATA; Schema: public; Owner: root
--

COPY clustergroup (clustergroupid, name, clusternodeids, wholecluster) FROM stdin;
\.


--
-- Data for Name: company; Type: TABLE DATA; Schema: public; Owner: root
--

COPY company (companyid, accountid, webid, key_, mx, homeurl, logoid, system, maxusers, active_) FROM stdin;
10155	10157	liferay.com	rO0ABXNyAB9qYXZheC5jcnlwdG8uc3BlYy5TZWNyZXRLZXlTcGVjW0cLZuIwYU0CAAJMAAlhbGdvcml0aG10ABJMamF2YS9sYW5nL1N0cmluZztbAANrZXl0AAJbQnhwdAADQUVTdXIAAltCrPMX+AYIVOACAAB4cAAAABASJHTelCFhn5S5ok/UliwJ	liferay.com		0	f	0	t
\.


--
-- Data for Name: contact_; Type: TABLE DATA; Schema: public; Owner: root
--

COPY contact_ (contactid, companyid, userid, username, createdate, modifieddate, classnameid, classpk, accountid, parentcontactid, emailaddress, firstname, middlename, lastname, prefixid, suffixid, male, birthday, smssn, aimsn, facebooksn, icqsn, jabbersn, msnsn, myspacesn, skypesn, twittersn, ymsn, employeestatusid, employeenumber, jobtitle, jobclass, hoursofoperation) FROM stdin;
10160	10155	10159		2017-03-10 17:05:59.183	2017-03-10 17:05:59.183	10005	10159	10157	0	default@liferay.com				0	0	t	2017-03-10 17:05:59.183															
10200	10155	10199		2017-03-10 17:06:00.789	2017-03-10 17:06:00.789	10005	10199	10157	0	test@liferay.com	Test		Test	0	0	t	1970-01-01 00:00:00															
\.


--
-- Data for Name: counter; Type: TABLE DATA; Schema: public; Owner: root
--

COPY counter (name, currentid) FROM stdin;
com.liferay.portal.model.Layout#10173#true	1
com.liferay.portal.model.Layout#10182#false	1
com.liferay.portal.model.Layout#10317#true	1
com.liferay.portal.model.Layout#10329#true	1
com.liferay.portal.model.Layout#10339#true	1
com.liferay.portal.model.Layout#10350#true	2
com.liferay.portal.model.Layout#10376#true	3
com.liferay.portal.model.ResourceAction	1200
com.liferay.portal.model.ResourcePermission	500
com.liferay.portal.model.Layout#10201#true	1
com.liferay.portal.model.Layout#10201#false	1
com.liferay.portal.model.Layout#10463#false	1
com.liferay.counter.model.Counter	10600
com.liferay.portlet.social.model.SocialActivity	100
\.


--
-- Data for Name: country; Type: TABLE DATA; Schema: public; Owner: root
--

COPY country (countryid, name, a2, a3, number_, idd_, ziprequired, active_) FROM stdin;
1	canada	CA	CAN	124	001	t	t
2	china	CN	CHN	156	086	t	t
3	france	FR	FRA	250	033	t	t
4	germany	DE	DEU	276	049	t	t
5	hong-kong	HK	HKG	344	852	t	t
6	hungary	HU	HUN	348	036	t	t
7	israel	IL	ISR	376	972	t	t
8	italy	IT	ITA	380	039	t	t
9	japan	JP	JPN	392	081	f	t
10	south-korea	KR	KOR	410	082	t	t
11	netherlands	NL	NLD	528	031	t	t
12	portugal	PT	PRT	620	351	t	t
13	russia	RU	RUS	643	007	t	t
14	singapore	SG	SGP	702	065	t	t
15	spain	ES	ESP	724	034	t	t
16	turkey	TR	TUR	792	090	t	t
17	vietnam	VN	VNM	704	084	t	t
18	united-kingdom	GB	GBR	826	044	t	t
19	united-states	US	USA	840	001	t	t
20	afghanistan	AF	AFG	4	093	t	t
21	albania	AL	ALB	8	355	t	t
22	algeria	DZ	DZA	12	213	t	t
23	american-samoa	AS	ASM	16	684	t	t
24	andorra	AD	AND	20	376	t	t
25	angola	AO	AGO	24	244	f	t
26	anguilla	AI	AIA	660	264	t	t
27	antarctica	AQ	ATA	10	672	t	t
28	antigua-barbuda	AG	ATG	28	268	f	t
29	argentina	AR	ARG	32	054	t	t
30	armenia	AM	ARM	51	374	t	t
31	aruba	AW	ABW	533	297	f	t
32	australia	AU	AUS	36	061	t	t
33	austria	AT	AUT	40	043	t	t
34	azerbaijan	AZ	AZE	31	994	t	t
35	bahamas	BS	BHS	44	242	f	t
36	bahrain	BH	BHR	48	973	t	t
37	bangladesh	BD	BGD	50	880	t	t
38	barbados	BB	BRB	52	246	t	t
39	belarus	BY	BLR	112	375	t	t
40	belgium	BE	BEL	56	032	t	t
41	belize	BZ	BLZ	84	501	f	t
42	benin	BJ	BEN	204	229	f	t
43	bermuda	BM	BMU	60	441	t	t
44	bhutan	BT	BTN	64	975	t	t
45	bolivia	BO	BOL	68	591	t	t
46	bosnia-herzegovina	BA	BIH	70	387	t	t
47	botswana	BW	BWA	72	267	f	t
48	brazil	BR	BRA	76	055	t	t
49	british-virgin-islands	VG	VGB	92	284	t	t
50	brunei	BN	BRN	96	673	t	t
51	bulgaria	BG	BGR	100	359	t	t
52	burkina-faso	BF	BFA	854	226	f	t
53	burma-myanmar	MM	MMR	104	095	t	t
54	burundi	BI	BDI	108	257	f	t
55	cambodia	KH	KHM	116	855	t	t
56	cameroon	CM	CMR	120	237	t	t
57	cape-verde-island	CV	CPV	132	238	t	t
58	cayman-islands	KY	CYM	136	345	t	t
59	central-african-republic	CF	CAF	140	236	f	t
60	chad	TD	TCD	148	235	t	t
61	chile	CL	CHL	152	056	t	t
62	christmas-island	CX	CXR	162	061	t	t
63	cocos-islands	CC	CCK	166	061	t	t
64	colombia	CO	COL	170	057	t	t
65	comoros	KM	COM	174	269	f	t
66	republic-of-congo	CD	COD	180	242	f	t
67	democratic-republic-of-congo	CG	COG	178	243	f	t
68	cook-islands	CK	COK	184	682	f	t
69	costa-rica	CR	CRI	188	506	t	t
70	croatia	HR	HRV	191	385	t	t
71	cuba	CU	CUB	192	053	t	t
72	cyprus	CY	CYP	196	357	t	t
73	czech-republic	CZ	CZE	203	420	t	t
74	denmark	DK	DNK	208	045	t	t
75	djibouti	DJ	DJI	262	253	f	t
76	dominica	DM	DMA	212	767	f	t
77	dominican-republic	DO	DOM	214	809	t	t
78	ecuador	EC	ECU	218	593	t	t
79	egypt	EG	EGY	818	020	t	t
80	el-salvador	SV	SLV	222	503	t	t
81	equatorial-guinea	GQ	GNQ	226	240	f	t
82	eritrea	ER	ERI	232	291	f	t
83	estonia	EE	EST	233	372	t	t
84	ethiopia	ET	ETH	231	251	t	t
85	faeroe-islands	FO	FRO	234	298	t	t
86	falkland-islands	FK	FLK	238	500	t	t
87	fiji-islands	FJ	FJI	242	679	f	t
88	finland	FI	FIN	246	358	t	t
89	french-guiana	GF	GUF	254	594	t	t
90	french-polynesia	PF	PYF	258	689	t	t
91	gabon	GA	GAB	266	241	t	t
92	gambia	GM	GMB	270	220	f	t
93	georgia	GE	GEO	268	995	t	t
94	ghana	GH	GHA	288	233	f	t
95	gibraltar	GI	GIB	292	350	t	t
96	greece	GR	GRC	300	030	t	t
97	greenland	GL	GRL	304	299	t	t
98	grenada	GD	GRD	308	473	f	t
99	guadeloupe	GP	GLP	312	590	t	t
100	guam	GU	GUM	316	671	t	t
101	guatemala	GT	GTM	320	502	t	t
102	guinea	GN	GIN	324	224	f	t
103	guinea-bissau	GW	GNB	624	245	t	t
104	guyana	GY	GUY	328	592	f	t
105	haiti	HT	HTI	332	509	t	t
106	honduras	HN	HND	340	504	t	t
107	iceland	IS	ISL	352	354	t	t
108	india	IN	IND	356	091	t	t
109	indonesia	ID	IDN	360	062	t	t
110	iran	IR	IRN	364	098	t	t
111	iraq	IQ	IRQ	368	964	t	t
112	ireland	IE	IRL	372	353	f	t
113	ivory-coast	CI	CIV	384	225	t	t
114	jamaica	JM	JAM	388	876	t	t
115	jordan	JO	JOR	400	962	t	t
116	kazakhstan	KZ	KAZ	398	007	t	t
117	kenya	KE	KEN	404	254	t	t
118	kiribati	KI	KIR	408	686	f	t
119	kuwait	KW	KWT	414	965	t	t
120	north-korea	KP	PRK	408	850	f	t
121	kyrgyzstan	KG	KGZ	471	996	t	t
122	laos	LA	LAO	418	856	t	t
123	latvia	LV	LVA	428	371	t	t
124	lebanon	LB	LBN	422	961	t	t
125	lesotho	LS	LSO	426	266	t	t
126	liberia	LR	LBR	430	231	t	t
127	libya	LY	LBY	434	218	t	t
128	liechtenstein	LI	LIE	438	423	t	t
129	lithuania	LT	LTU	440	370	t	t
130	luxembourg	LU	LUX	442	352	t	t
131	macau	MO	MAC	446	853	f	t
132	macedonia	MK	MKD	807	389	t	t
133	madagascar	MG	MDG	450	261	t	t
134	malawi	MW	MWI	454	265	f	t
135	malaysia	MY	MYS	458	060	t	t
136	maldives	MV	MDV	462	960	t	t
137	mali	ML	MLI	466	223	f	t
138	malta	MT	MLT	470	356	t	t
139	marshall-islands	MH	MHL	584	692	t	t
140	martinique	MQ	MTQ	474	596	t	t
141	mauritania	MR	MRT	478	222	f	t
142	mauritius	MU	MUS	480	230	f	t
143	mayotte-island	YT	MYT	175	269	t	t
144	mexico	MX	MEX	484	052	t	t
145	micronesia	FM	FSM	583	691	t	t
146	moldova	MD	MDA	498	373	t	t
147	monaco	MC	MCO	492	377	t	t
148	mongolia	MN	MNG	496	976	t	t
149	montenegro	ME	MNE	499	382	t	t
150	montserrat	MS	MSR	500	664	f	t
151	morocco	MA	MAR	504	212	t	t
152	mozambique	MZ	MOZ	508	258	t	t
153	namibia	NA	NAM	516	264	t	t
154	nauru	NR	NRU	520	674	f	t
155	nepal	NP	NPL	524	977	t	t
156	netherlands-antilles	AN	ANT	530	599	t	t
157	new-caledonia	NC	NCL	540	687	t	t
158	new-zealand	NZ	NZL	554	064	t	t
159	nicaragua	NI	NIC	558	505	t	t
160	niger	NE	NER	562	227	t	t
161	nigeria	NG	NGA	566	234	t	t
162	niue	NU	NIU	570	683	f	t
163	norfolk-island	NF	NFK	574	672	t	t
164	norway	NO	NOR	578	047	t	t
165	oman	OM	OMN	512	968	t	t
166	pakistan	PK	PAK	586	092	t	t
167	palau	PW	PLW	585	680	t	t
168	palestine	PS	PSE	275	970	t	t
169	panama	PA	PAN	591	507	t	t
170	papua-new-guinea	PG	PNG	598	675	t	t
171	paraguay	PY	PRY	600	595	t	t
172	peru	PE	PER	604	051	t	t
173	philippines	PH	PHL	608	063	t	t
174	poland	PL	POL	616	048	t	t
175	puerto-rico	PR	PRI	630	787	t	t
176	qatar	QA	QAT	634	974	f	t
177	reunion-island	RE	REU	638	262	t	t
178	romania	RO	ROU	642	040	t	t
179	rwanda	RW	RWA	646	250	f	t
180	st-helena	SH	SHN	654	290	t	t
181	st-kitts	KN	KNA	659	869	f	t
182	st-lucia	LC	LCA	662	758	f	t
183	st-pierre-miquelon	PM	SPM	666	508	t	t
184	st-vincent	VC	VCT	670	784	t	t
185	san-marino	SM	SMR	674	378	t	t
186	sao-tome-principe	ST	STP	678	239	f	t
187	saudi-arabia	SA	SAU	682	966	t	t
188	senegal	SN	SEN	686	221	t	t
189	serbia	RS	SRB	688	381	t	t
190	seychelles	SC	SYC	690	248	f	t
191	sierra-leone	SL	SLE	694	249	f	t
192	slovakia	SK	SVK	703	421	t	t
193	slovenia	SI	SVN	705	386	t	t
194	solomon-islands	SB	SLB	90	677	f	t
195	somalia	SO	SOM	706	252	f	t
196	south-africa	ZA	ZAF	710	027	t	t
197	sri-lanka	LK	LKA	144	094	t	t
198	sudan	SD	SDN	736	095	t	t
199	suriname	SR	SUR	740	597	f	t
200	swaziland	SZ	SWZ	748	268	t	t
201	sweden	SE	SWE	752	046	t	t
202	switzerland	CH	CHE	756	041	t	t
203	syria	SY	SYR	760	963	f	t
204	taiwan	TW	TWN	158	886	t	t
205	tajikistan	TJ	TJK	762	992	t	t
206	tanzania	TZ	TZA	834	255	f	t
207	thailand	TH	THA	764	066	t	t
208	togo	TG	TGO	768	228	t	t
209	tonga	TO	TON	776	676	f	t
210	trinidad-tobago	TT	TTO	780	868	f	t
211	tunisia	TN	TUN	788	216	t	t
212	turkmenistan	TM	TKM	795	993	t	t
213	turks-caicos	TC	TCA	796	649	t	t
214	tuvalu	TV	TUV	798	688	f	t
215	uganda	UG	UGA	800	256	f	t
216	ukraine	UA	UKR	804	380	t	t
217	united-arab-emirates	AE	ARE	784	971	f	t
218	uruguay	UY	URY	858	598	t	t
219	uzbekistan	UZ	UZB	860	998	t	t
220	vanuatu	VU	VUT	548	678	f	t
221	vatican-city	VA	VAT	336	039	t	t
222	venezuela	VE	VEN	862	058	t	t
223	wallis-futuna	WF	WLF	876	681	t	t
224	western-samoa	WS	WSM	882	685	t	t
225	yemen	YE	YEM	887	967	f	t
226	zambia	ZM	ZMB	894	260	t	t
227	zimbabwe	ZW	ZWE	716	263	f	t
228	aland-islands	AX	ALA	248	359	t	t
229	bonaire-st-eustatius-saba	BQ	BES	535	599	t	t
230	bouvet-island	BV	BVT	74	047	t	t
231	british-indian-ocean-territory	IO	IOT	86	246	t	t
232	curacao	CW	CUW	531	599	t	t
233	french-southern-territories	TF	ATF	260	033	f	t
234	guernsey	GG	GGY	831	044	t	t
235	heard-island-mcdonald-islands	HM	HMD	334	061	t	t
236	isle-of-man	IM	IMN	833	044	t	t
237	jersey	JE	JEY	832	044	t	t
238	northern-mariana-islands	MP	MNP	580	670	t	t
239	pitcairn	PN	PCN	612	649	t	t
240	south-georgia-south-sandwich-islands	GS	SGS	239	044	t	t
241	south-sudan	SS	SSD	728	211	t	t
242	sint-maarten	SX	SXM	534	721	t	t
243	st-barthelemy	BL	BLM	652	590	t	t
244	st-martin	MF	MAF	663	590	t	t
245	tokelau	TK	TKL	772	690	f	t
246	timor-leste	TL	TLS	626	670	t	t
247	united-states-minor-outlying-islands	UM	UMI	581	699	t	t
248	united-states-virgin-islands	VI	VIR	850	340	t	t
249	western-sahara	EH	ESH	732	212	t	t
\.


--
-- Data for Name: cyrususer; Type: TABLE DATA; Schema: public; Owner: root
--

COPY cyrususer (userid, password_) FROM stdin;
\.


--
-- Data for Name: cyrusvirtual; Type: TABLE DATA; Schema: public; Owner: root
--

COPY cyrusvirtual (emailaddress, userid) FROM stdin;
\.


--
-- Data for Name: ddlrecord; Type: TABLE DATA; Schema: public; Owner: root
--

COPY ddlrecord (uuid_, recordid, groupid, companyid, userid, username, versionuserid, versionusername, createdate, modifieddate, ddmstorageid, recordsetid, version, displayindex) FROM stdin;
\.


--
-- Data for Name: ddlrecordset; Type: TABLE DATA; Schema: public; Owner: root
--

COPY ddlrecordset (uuid_, recordsetid, groupid, companyid, userid, username, createdate, modifieddate, ddmstructureid, recordsetkey, name, description, mindisplayrows, scope) FROM stdin;
\.


--
-- Data for Name: ddlrecordversion; Type: TABLE DATA; Schema: public; Owner: root
--

COPY ddlrecordversion (recordversionid, groupid, companyid, userid, username, createdate, ddmstorageid, recordsetid, recordid, version, displayindex, status, statusbyuserid, statusbyusername, statusdate) FROM stdin;
\.


--
-- Data for Name: ddmcontent; Type: TABLE DATA; Schema: public; Owner: root
--

COPY ddmcontent (uuid_, contentid, groupid, companyid, userid, username, createdate, modifieddate, name, description, xml) FROM stdin;
\.


--
-- Data for Name: ddmstoragelink; Type: TABLE DATA; Schema: public; Owner: root
--

COPY ddmstoragelink (uuid_, storagelinkid, classnameid, classpk, structureid) FROM stdin;
\.


--
-- Data for Name: ddmstructure; Type: TABLE DATA; Schema: public; Owner: root
--

COPY ddmstructure (uuid_, structureid, groupid, companyid, userid, username, createdate, modifieddate, parentstructureid, classnameid, structurekey, name, description, xsd, storagetype, type_) FROM stdin;
d63bd961-b77d-4fc4-9b34-28cbf43d78b8	10303	10195	10155	10159		2017-03-10 17:06:02.523	2017-03-10 17:06:02.523	0	10091	LEARNING MODULE METADATA	<?xml version='1.0' encoding='UTF-8'?><root available-locales="en_US" default-locale="en_US"><Name language-id="en_US">Learning Module Metadata</Name></root>	<?xml version='1.0' encoding='UTF-8'?><root available-locales="en_US" default-locale="en_US"><Description language-id="en_US">Learning Module Metadata</Description></root>	<?xml version="1.0"?>\n\n<root available-locales="en_US" default-locale="en_US">\n\t<dynamic-element dataType="string" indexType="keyword" multiple="true" name="select2235" readOnly="false" required="false" showLabel="true" type="select">\n\t\t<dynamic-element name="home_edition" type="option" value="HE">\n\t\t\t<meta-data locale="en_US">\n\t\t\t\t<entry name="label"><![CDATA[Home Edition]]></entry>\n\t\t\t</meta-data>\n\t\t</dynamic-element>\n\t\t<dynamic-element name="business_edition" type="option" value="BE">\n\t\t\t<meta-data locale="en_US">\n\t\t\t\t<entry name="label"><![CDATA[Business Edition]]></entry>\n\t\t\t</meta-data>\n\t\t</dynamic-element>\n\t\t<dynamic-element name="enterprise_edition" type="option" value="EE">\n\t\t\t<meta-data locale="en_US">\n\t\t\t\t<entry name="label"><![CDATA[Enterprise Edition]]></entry>\n\t\t\t</meta-data>\n\t\t</dynamic-element>\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[Product]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="tip"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" indexType="keyword" multiple="true" name="select3212" readOnly="false" required="false" showLabel="true" type="select">\n\t\t<dynamic-element name="1_0" type="option" value="1">\n\t\t\t<meta-data locale="en_US">\n\t\t\t\t<entry name="label"><![CDATA[1.0]]></entry>\n\t\t\t</meta-data>\n\t\t</dynamic-element>\n\t\t<dynamic-element name="2_0" type="option" value="2">\n\t\t\t<meta-data locale="en_US">\n\t\t\t\t<entry name="label"><![CDATA[2.0]]></entry>\n\t\t\t</meta-data>\n\t\t</dynamic-element>\n\t\t<dynamic-element name="3_0" type="option" value="3">\n\t\t\t<meta-data locale="en_US">\n\t\t\t\t<entry name="label"><![CDATA[3.0]]></entry>\n\t\t\t</meta-data>\n\t\t</dynamic-element>\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[Version]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="tip"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" indexType="keyword" multiple="true" name="select4115" readOnly="false" required="false" showLabel="true" type="select">\n\t\t<dynamic-element name="administration" type="option" value="admin">\n\t\t\t<meta-data locale="en_US">\n\t\t\t\t<entry name="label"><![CDATA[Administration]]></entry>\n\t\t\t</meta-data>\n\t\t</dynamic-element>\n\t\t<dynamic-element name="installation" type="option" value="install">\n\t\t\t<meta-data locale="en_US">\n\t\t\t\t<entry name="label"><![CDATA[Installation]]></entry>\n\t\t\t</meta-data>\n\t\t</dynamic-element>\n\t\t<dynamic-element name="configuration" type="option" value="config">\n\t\t\t<meta-data locale="en_US">\n\t\t\t\t<entry name="label"><![CDATA[Configuration]]></entry>\n\t\t\t</meta-data>\n\t\t</dynamic-element>\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[Topics]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="tip"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" indexType="keyword" multiple="false" name="select5069" readOnly="false" required="false" showLabel="true" type="select">\n\t\t<dynamic-element name="beginner" type="option" value="beginner">\n\t\t\t<meta-data locale="en_US">\n\t\t\t\t<entry name="label"><![CDATA[Beginner]]></entry>\n\t\t\t</meta-data>\n\t\t</dynamic-element>\n\t\t<dynamic-element name="intermediate" type="option" value="intermediate">\n\t\t\t<meta-data locale="en_US">\n\t\t\t\t<entry name="label"><![CDATA[Intermediate]]></entry>\n\t\t\t</meta-data>\n\t\t</dynamic-element>\n\t\t<dynamic-element name="advanced" type="option" value="advanced">\n\t\t\t<meta-data locale="en_US">\n\t\t\t\t<entry name="label"><![CDATA[Advanced]]></entry>\n\t\t\t</meta-data>\n\t\t</dynamic-element>\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[Level]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="tip"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n</root>	xml	0
d0ba8ce0-c630-4b03-9136-c571631de91d	10304	10195	10155	10159		2017-03-10 17:06:02.599	2017-03-10 17:06:02.599	0	10091	MARKETING CAMPAIGN THEME METADATA	<?xml version='1.0' encoding='UTF-8'?><root available-locales="en_US" default-locale="en_US"><Name language-id="en_US">Marketing Campaign Theme Metadata</Name></root>	<?xml version='1.0' encoding='UTF-8'?><root available-locales="en_US" default-locale="en_US"><Description language-id="en_US">Marketing Campaign Theme Metadata</Description></root>	<?xml version="1.0"?>\n\n<root available-locales="en_US" default-locale="en_US">\n\t<dynamic-element dataType="string" indexType="keyword" multiple="false" name="select2305" readOnly="false" required="false" showLabel="true" type="select">\n\t\t<dynamic-element name="strong_company" type="option" value="strong">\n\t\t\t<meta-data locale="en_US">\n\t\t\t\t<entry name="label"><![CDATA[Strong Company]]></entry>\n\t\t\t</meta-data>\n\t\t</dynamic-element>\n\t\t<dynamic-element name="new_product_launch" type="option" value="product">\n\t\t\t<meta-data locale="en_US">\n\t\t\t\t<entry name="label"><![CDATA[New Product Launch]]></entry>\n\t\t\t</meta-data>\n\t\t</dynamic-element>\n\t\t<dynamic-element name="company_philosophy" type="option" value="philosophy">\n\t\t\t<meta-data locale="en_US">\n\t\t\t\t<entry name="label"><![CDATA[Company Philosophy]]></entry>\n\t\t\t</meta-data>\n\t\t</dynamic-element>\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[Select]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="tip"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" indexType="keyword" multiple="false" name="select3229" readOnly="false" required="false" showLabel="true" type="select">\n\t\t<dynamic-element name="your_trusted_advisor" type="option" value="advisor">\n\t\t\t<meta-data locale="en_US">\n\t\t\t\t<entry name="label"><![CDATA[Your Trusted Advisor]]></entry>\n\t\t\t</meta-data>\n\t\t</dynamic-element>\n\t\t<dynamic-element name="10_years_of_customer_solutions" type="option" value="solutions">\n\t\t\t<meta-data locale="en_US">\n\t\t\t\t<entry name="label"><![CDATA[10 Years of Customer Solutions]]></entry>\n\t\t\t</meta-data>\n\t\t</dynamic-element>\n\t\t<dynamic-element name="making_a_difference" type="option" value="difference">\n\t\t\t<meta-data locale="en_US">\n\t\t\t\t<entry name="label"><![CDATA[Making a Difference]]></entry>\n\t\t\t</meta-data>\n\t\t</dynamic-element>\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[Campaign Theme]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="tip"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" indexType="keyword" multiple="false" name="select4282" readOnly="false" required="false" showLabel="true" type="select">\n\t\t<dynamic-element name="awareness" type="option" value="awareness">\n\t\t\t<meta-data locale="en_US">\n\t\t\t\t<entry name="label"><![CDATA[Awareness]]></entry>\n\t\t\t</meta-data>\n\t\t</dynamic-element>\n\t\t<dynamic-element name="lead_generation" type="option" value="leads">\n\t\t\t<meta-data locale="en_US">\n\t\t\t\t<entry name="label"><![CDATA[Lead Generation]]></entry>\n\t\t\t</meta-data>\n\t\t</dynamic-element>\n\t\t<dynamic-element name="customer_service" type="option" value="service">\n\t\t\t<meta-data locale="en_US">\n\t\t\t\t<entry name="label"><![CDATA[Customer Service]]></entry>\n\t\t\t</meta-data>\n\t\t</dynamic-element>\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[Business Goal]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="tip"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n</root>	xml	0
a961b181-db1a-4053-ae59-19a301dc4d55	10305	10195	10155	10159		2017-03-10 17:06:02.614	2017-03-10 17:06:02.614	0	10091	MEETING METADATA	<?xml version='1.0' encoding='UTF-8'?><root available-locales="en_US" default-locale="en_US"><Name language-id="en_US">Meeting Metadata</Name></root>	<?xml version='1.0' encoding='UTF-8'?><root available-locales="en_US" default-locale="en_US"><Description language-id="en_US">Metadata for meeting</Description></root>	<?xml version="1.0"?>\n\n<root available-locales="en_US" default-locale="en_US">\n\t<dynamic-element dataType="date" fieldNamespace="ddm" indexType="keyword" name="ddm-date3054" readOnly="false" required="false" showLabel="true" type="ddm-date" width="25">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[Date]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="tip"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" indexType="keyword" name="text2217" readOnly="false" required="false" showLabel="true" type="text" width="25">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[Meeting Name]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="tip"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" indexType="keyword" name="text4569" readOnly="false" required="false" showLabel="true" type="text" width="25">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[Time]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="tip"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" indexType="keyword" name="text5638" readOnly="false" required="false" showLabel="true" type="text" width="25">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[Location]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="tip"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" indexType="text" name="textarea6584" readOnly="false" required="false" showLabel="true" type="textarea" width="25">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[Description]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="tip"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" indexType="text" name="textarea7502" readOnly="false" required="false" showLabel="true" type="textarea" width="25">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[Participants]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="tip"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n</root>	xml	0
2f797068-be97-4b7a-bb82-f7bb19663b15	10307	10195	10155	10159		2017-03-10 17:06:02.976	2017-03-10 17:06:02.976	0	10091	AUTO_A8C08EC2-CED6-4A44-A274-EB9A6FD298DA	<?xml version='1.0' encoding='UTF-8'?><root available-locales="en_US" default-locale="en_US"><Name language-id="en_US">Contract</Name></root>	<?xml version='1.0' encoding='UTF-8'?><root available-locales="en_US" default-locale="en_US"><Description language-id="en_US">Contract</Description></root>	<?xml version="1.0"?>\n\n<root available-locales="en_US" default-locale="en_US">\n\t<dynamic-element dataType="date" fieldNamespace="ddm" indexType="keyword" name="ddm-date18949" readOnly="false" required="false" showLabel="true" type="ddm-date" width="25">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[Effective Date]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="tip"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="date" fieldNamespace="ddm" indexType="keyword" name="ddm-date20127" readOnly="false" required="false" showLabel="true" type="ddm-date" width="25">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[Expiration Date]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="tip"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" indexType="keyword" multiple="false" name="select10264" readOnly="false" required="false" showLabel="true" type="select">\n\t\t<dynamic-element name="nda" type="option" value="NDA">\n\t\t\t<meta-data locale="en_US">\n\t\t\t\t<entry name="label"><![CDATA[NDA]]></entry>\n\t\t\t</meta-data>\n\t\t</dynamic-element>\n\t\t<dynamic-element name="msa" type="option" value="MSA">\n\t\t\t<meta-data locale="en_US">\n\t\t\t\t<entry name="label"><![CDATA[MSA]]></entry>\n\t\t\t</meta-data>\n\t\t</dynamic-element>\n\t\t<dynamic-element name="license_agreement" type="option" value="License">\n\t\t\t<meta-data locale="en_US">\n\t\t\t\t<entry name="label"><![CDATA[License Agreement]]></entry>\n\t\t\t</meta-data>\n\t\t</dynamic-element>\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[Contract Type]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="tip"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" indexType="keyword" multiple="false" name="select4893" readOnly="false" required="false" showLabel="true" type="select">\n\t\t<dynamic-element name="draft" type="option" value="Draft">\n\t\t\t<meta-data locale="en_US">\n\t\t\t\t<entry name="label"><![CDATA[Draft]]></entry>\n\t\t\t</meta-data>\n\t\t</dynamic-element>\n\t\t<dynamic-element name="in_review" type="option" value="Review">\n\t\t\t<meta-data locale="en_US">\n\t\t\t\t<entry name="label"><![CDATA[In Review]]></entry>\n\t\t\t</meta-data>\n\t\t</dynamic-element>\n\t\t<dynamic-element name="suspended" type="option" value="Suspended">\n\t\t\t<meta-data locale="en_US">\n\t\t\t\t<entry name="label"><![CDATA[Suspended]]></entry>\n\t\t\t</meta-data>\n\t\t</dynamic-element>\n\t\t<dynamic-element name="signed" type="option" value="Signed">\n\t\t\t<meta-data locale="en_US">\n\t\t\t\t<entry name="label"><![CDATA[Signed]]></entry>\n\t\t\t</meta-data>\n\t\t</dynamic-element>\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[Status]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="tip"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" indexType="keyword" name="text14822" readOnly="false" required="false" showLabel="true" type="text" width="25">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[Legal Reviewer]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="tip"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" indexType="keyword" name="text17700" readOnly="false" required="false" showLabel="true" type="text" width="25">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[Signing Authority]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="tip"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" indexType="keyword" name="text2087" readOnly="false" required="false" showLabel="true" type="text" width="25">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[Deal Name]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="tip"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n</root>	xml	1
7862c6cc-1077-4ea0-9da5-4f09781cc625	10309	10195	10155	10159		2017-03-10 17:06:03.012	2017-03-10 17:06:03.012	0	10091	AUTO_BDDE61DF-9189-4867-A985-08E5B4C45FDE	<?xml version='1.0' encoding='UTF-8'?><root available-locales="en_US" default-locale="en_US"><Name language-id="en_US">Marketing Banner</Name></root>	<?xml version='1.0' encoding='UTF-8'?><root available-locales="en_US" default-locale="en_US"><Description language-id="en_US">Marketing Banner</Description></root>	<?xml version="1.0"?>\n\n<root available-locales="en_US" default-locale="en_US">\n\t<dynamic-element dataType="string" indexType="keyword" name="radio5547" readOnly="false" required="false" showLabel="true" type="radio">\n\t\t<dynamic-element name="yes" type="option" value="yes">\n\t\t\t<meta-data locale="en_US">\n\t\t\t\t<entry name="label"><![CDATA[Yes]]></entry>\n\t\t\t</meta-data>\n\t\t</dynamic-element>\n\t\t<dynamic-element name="no" type="option" value="no">\n\t\t\t<meta-data locale="en_US">\n\t\t\t\t<entry name="label"><![CDATA[No]]></entry>\n\t\t\t</meta-data>\n\t\t</dynamic-element>\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[Needs Legal Review]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="tip"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" indexType="keyword" name="text2033" readOnly="false" required="false" showLabel="true" type="text" width="25">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[Banner Name]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="tip"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" indexType="text" name="textarea2873" readOnly="false" required="false" showLabel="true" type="textarea" width="25">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[Description]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="tip"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n</root>	xml	1
84318335-46f4-48b2-b802-293f31506a12	10311	10195	10155	10159		2017-03-10 17:06:03.037	2017-03-10 17:06:03.037	0	10091	AUTO_B3DE3C82-278E-4626-A83B-47F0F27D9654	<?xml version='1.0' encoding='UTF-8'?><root available-locales="en_US" default-locale="en_US"><Name language-id="en_US">Online Training</Name></root>	<?xml version='1.0' encoding='UTF-8'?><root available-locales="en_US" default-locale="en_US"><Description language-id="en_US">Online Training</Description></root>	<?xml version="1.0"?>\n\n<root available-locales="en_US" default-locale="en_US">\n\t<dynamic-element dataType="string" indexType="keyword" name="text2082" readOnly="false" required="false" showLabel="true" type="text" width="25">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[Lesson Title]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="tip"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" indexType="keyword" name="text2979" readOnly="false" required="false" showLabel="true" type="text" width="25">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[Author]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="tip"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n</root>	xml	1
d2b56ae8-69ca-4e04-9b3f-9d125c8da88a	10313	10195	10155	10159		2017-03-10 17:06:03.075	2017-03-10 17:06:03.075	0	10091	AUTO_5EFCC57D-E4B1-4E89-BD9B-65BEBD721B42	<?xml version='1.0' encoding='UTF-8'?><root available-locales="en_US" default-locale="en_US"><Name language-id="en_US">Sales Presentation</Name></root>	<?xml version='1.0' encoding='UTF-8'?><root available-locales="en_US" default-locale="en_US"><Description language-id="en_US">Sales Presentation</Description></root>	<?xml version="1.0"?>\n\n<root available-locales="en_US" default-locale="en_US">\n\t<dynamic-element dataType="string" indexType="keyword" multiple="false" name="select2890" readOnly="false" required="false" showLabel="true" type="select">\n\t\t<dynamic-element name="home_edition" type="option" value="HE">\n\t\t\t<meta-data locale="en_US">\n\t\t\t\t<entry name="label"><![CDATA[Home Edition]]></entry>\n\t\t\t</meta-data>\n\t\t</dynamic-element>\n\t\t<dynamic-element name="business_edition" type="option" value="BE">\n\t\t\t<meta-data locale="en_US">\n\t\t\t\t<entry name="label"><![CDATA[Business Edition]]></entry>\n\t\t\t</meta-data>\n\t\t</dynamic-element>\n\t\t<dynamic-element name="enterprise_edition" type="option" value="EE">\n\t\t\t<meta-data locale="en_US">\n\t\t\t\t<entry name="label"><![CDATA[Enterprise Edition]]></entry>\n\t\t\t</meta-data>\n\t\t</dynamic-element>\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[Product]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="tip"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" indexType="keyword" multiple="false" name="select3864" readOnly="false" required="false" showLabel="true" type="select">\n\t\t<dynamic-element name="1_0" type="option" value="1">\n\t\t\t<meta-data locale="en_US">\n\t\t\t\t<entry name="label"><![CDATA[1.0]]></entry>\n\t\t\t</meta-data>\n\t\t</dynamic-element>\n\t\t<dynamic-element name="2_0" type="option" value="2">\n\t\t\t<meta-data locale="en_US">\n\t\t\t\t<entry name="label"><![CDATA[2.0]]></entry>\n\t\t\t</meta-data>\n\t\t</dynamic-element>\n\t\t<dynamic-element name="3_0" type="option" value="3">\n\t\t\t<meta-data locale="en_US">\n\t\t\t\t<entry name="label"><![CDATA[3.0]]></entry>\n\t\t\t</meta-data>\n\t\t</dynamic-element>\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[Version]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="tip"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" indexType="keyword" multiple="true" name="select4831" readOnly="false" required="false" showLabel="true" type="select">\n\t\t<dynamic-element name="website" type="option" value="website">\n\t\t\t<meta-data locale="en_US">\n\t\t\t\t<entry name="label"><![CDATA[Website]]></entry>\n\t\t\t</meta-data>\n\t\t</dynamic-element>\n\t\t<dynamic-element name="collaboration" type="option" value="collaboration">\n\t\t\t<meta-data locale="en_US">\n\t\t\t\t<entry name="label"><![CDATA[Collaboration]]></entry>\n\t\t\t</meta-data>\n\t\t</dynamic-element>\n\t\t<dynamic-element name="intranet" type="option" value="intranet">\n\t\t\t<meta-data locale="en_US">\n\t\t\t\t<entry name="label"><![CDATA[Intranet]]></entry>\n\t\t\t</meta-data>\n\t\t</dynamic-element>\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[Areas of Interest]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="tip"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" indexType="keyword" multiple="true" name="select5929" readOnly="false" required="false" showLabel="true" type="select">\n\t\t<dynamic-element name="acme" type="option" value="acme">\n\t\t\t<meta-data locale="en_US">\n\t\t\t\t<entry name="label"><![CDATA[ACME]]></entry>\n\t\t\t</meta-data>\n\t\t</dynamic-element>\n\t\t<dynamic-element name="sevencogs" type="option" value="sevencogs">\n\t\t\t<meta-data locale="en_US">\n\t\t\t\t<entry name="label"><![CDATA[SevenCogs]]></entry>\n\t\t\t</meta-data>\n\t\t</dynamic-element>\n\t\t<dynamic-element name="freeplus" type="option" value="freeplus">\n\t\t\t<meta-data locale="en_US">\n\t\t\t\t<entry name="label"><![CDATA[FreePlus]]></entry>\n\t\t\t</meta-data>\n\t\t</dynamic-element>\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[Competitors]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="tip"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" indexType="keyword" name="text1993" readOnly="false" required="false" showLabel="true" type="text" width="25">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[Prospect Name]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="tip"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n</root>	xml	1
0a140fd5-792d-4fd9-abc1-e03959a0d9df	10315	10195	10155	10159		2017-03-10 17:06:03.137	2017-03-10 17:06:03.137	0	10314	TIKARAWMETADATA	<?xml version='1.0' encoding='UTF-8'?><root available-locales="en_US" default-locale="en_US"><Name language-id="en_US">TIKARAWMETADATA</Name></root>	<?xml version='1.0' encoding='UTF-8'?><root available-locales="en_US" default-locale="en_US"><Description language-id="en_US">TIKARAWMETADATA</Description></root>	<?xml version="1.0"?>\n\n<root available-locales="en_US" default-locale="en_US">\n\t<dynamic-element dataType="string" name="ClimateForcast_PROGRAM_ID" required="false" showLabel="true" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.ClimateForcast.PROGRAM_ID]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="ClimateForcast_COMMAND_LINE" required="false" showLabel="true" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.ClimateForcast.COMMAND_LINE]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="ClimateForcast_HISTORY" required="false" showLabel="true" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.ClimateForcast.HISTORY]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="ClimateForcast_TABLE_ID" required="false" showLabel="true" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.ClimateForcast.TABLE_ID]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="ClimateForcast_INSTITUTION" required="false" showLabel="true" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.ClimateForcast.INSTITUTION]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="ClimateForcast_SOURCE" required="false" showLabel="true" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.ClimateForcast.SOURCE]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="ClimateForcast_CONTACT" required="false" showLabel="true" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.ClimateForcast.CONTACT]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="ClimateForcast_PROJECT_ID" required="false" showLabel="true" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.ClimateForcast.PROJECT_ID]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="ClimateForcast_CONVENTIONS" required="false" showLabel="true" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.ClimateForcast.CONVENTIONS]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="ClimateForcast_REFERENCES" required="false" showLabel="true" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.ClimateForcast.REFERENCES]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="ClimateForcast_ACKNOWLEDGEMENT" required="false" showLabel="true" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.ClimateForcast.ACKNOWLEDGEMENT]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="ClimateForcast_REALIZATION" required="false" showLabel="true" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.ClimateForcast.REALIZATION]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="ClimateForcast_EXPERIMENT_ID" required="false" showLabel="true" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.ClimateForcast.EXPERIMENT_ID]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="ClimateForcast_COMMENT" required="false" showLabel="true" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.ClimateForcast.COMMENT]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="ClimateForcast_MODEL_NAME_ENGLISH" required="false" showLabel="true" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.ClimateForcast.MODEL_NAME_ENGLISH]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="CreativeCommons_LICENSE_URL" required="false" showLabel="true" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.CreativeCommons.LICENSE_URL]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="CreativeCommons_LICENSE_LOCATION" required="false" showLabel="true" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.CreativeCommons.LICENSE_LOCATION]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="CreativeCommons_WORK_TYPE" required="false" showLabel="true" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.CreativeCommons.WORK_TYPE]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="DublinCore_NAMESPACE_URI_DC" required="false" showLabel="true" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.DublinCore.NAMESPACE_URI_DC]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="DublinCore_NAMESPACE_URI_DC_TERMS" required="false" showLabel="true" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.DublinCore.NAMESPACE_URI_DC_TERMS]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="DublinCore_PREFIX_DC" required="false" showLabel="true" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.DublinCore.PREFIX_DC]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="DublinCore_PREFIX_DC_TERMS" required="false" showLabel="true" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.DublinCore.PREFIX_DC_TERMS]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="DublinCore_FORMAT" required="false" showLabel="true" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.DublinCore.FORMAT]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="DublinCore_IDENTIFIER" required="false" showLabel="true" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.DublinCore.IDENTIFIER]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="DublinCore_MODIFIED" required="false" showLabel="true" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.DublinCore.MODIFIED]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="DublinCore_CONTRIBUTOR" required="false" showLabel="true" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.DublinCore.CONTRIBUTOR]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="DublinCore_COVERAGE" required="false" showLabel="true" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.DublinCore.COVERAGE]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="DublinCore_CREATOR" required="false" showLabel="true" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.DublinCore.CREATOR]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="DublinCore_CREATED" required="false" showLabel="true" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.DublinCore.CREATED]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="DublinCore_DATE" required="false" showLabel="true" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.DublinCore.DATE]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="DublinCore_DESCRIPTION" required="false" showLabel="true" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.DublinCore.DESCRIPTION]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="DublinCore_LANGUAGE" required="false" showLabel="true" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.DublinCore.LANGUAGE]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="DublinCore_PUBLISHER" required="false" showLabel="true" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.DublinCore.PUBLISHER]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="DublinCore_RELATION" required="false" showLabel="true" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.DublinCore.RELATION]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="DublinCore_RIGHTS" required="false" showLabel="true" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.DublinCore.RIGHTS]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="DublinCore_SOURCE" required="false" showLabel="true" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.DublinCore.SOURCE]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="DublinCore_SUBJECT" required="false" showLabel="true" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.DublinCore.SUBJECT]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="DublinCore_TITLE" required="false" showLabel="true" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.DublinCore.TITLE]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="DublinCore_TYPE" required="false" showLabel="true" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.DublinCore.TYPE]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="Geographic_LATITUDE" required="false" showLabel="true" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.Geographic.LATITUDE]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="Geographic_LONGITUDE" required="false" showLabel="true" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.Geographic.LONGITUDE]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="Geographic_ALTITUDE" required="false" showLabel="true" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.Geographic.ALTITUDE]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="HttpHeaders_CONTENT_ENCODING" required="false" showLabel="true" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.HttpHeaders.CONTENT_ENCODING]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="HttpHeaders_CONTENT_LANGUAGE" required="false" showLabel="true" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.HttpHeaders.CONTENT_LANGUAGE]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="HttpHeaders_CONTENT_LENGTH" required="false" showLabel="true" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.HttpHeaders.CONTENT_LENGTH]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="HttpHeaders_CONTENT_LOCATION" required="false" showLabel="true" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.HttpHeaders.CONTENT_LOCATION]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="HttpHeaders_CONTENT_DISPOSITION" required="false" showLabel="true" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.HttpHeaders.CONTENT_DISPOSITION]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="HttpHeaders_CONTENT_MD5" required="false" showLabel="true" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.HttpHeaders.CONTENT_MD5]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="HttpHeaders_CONTENT_TYPE" required="false" showLabel="true" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.HttpHeaders.CONTENT_TYPE]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="HttpHeaders_LAST_MODIFIED" required="false" showLabel="true" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.HttpHeaders.LAST_MODIFIED]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="HttpHeaders_LOCATION" required="false" showLabel="true" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.HttpHeaders.LOCATION]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="Message_MESSAGE_RECIPIENT_ADDRESS" required="false" showLabel="true" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.Message.MESSAGE_RECIPIENT_ADDRESS]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="Message_MESSAGE_FROM" required="false" showLabel="true" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.Message.MESSAGE_FROM]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="Message_MESSAGE_TO" required="false" showLabel="true" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.Message.MESSAGE_TO]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="Message_MESSAGE_CC" required="false" showLabel="true" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.Message.MESSAGE_CC]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="Message_MESSAGE_BCC" required="false" showLabel="true" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.Message.MESSAGE_BCC]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="MSOffice_KEYWORDS" required="false" showLabel="true" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.MSOffice.KEYWORDS]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="MSOffice_COMMENTS" required="false" showLabel="true" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.MSOffice.COMMENTS]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="MSOffice_LAST_AUTHOR" required="false" showLabel="true" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.MSOffice.LAST_AUTHOR]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="MSOffice_AUTHOR" required="false" showLabel="true" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.MSOffice.AUTHOR]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="MSOffice_APPLICATION_NAME" required="false" showLabel="true" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.MSOffice.APPLICATION_NAME]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="MSOffice_REVISION_NUMBER" required="false" showLabel="true" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.MSOffice.REVISION_NUMBER]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="MSOffice_TEMPLATE" required="false" showLabel="true" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.MSOffice.TEMPLATE]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="MSOffice_TOTAL_TIME" required="false" showLabel="true" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.MSOffice.TOTAL_TIME]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="MSOffice_PRESENTATION_FORMAT" required="false" showLabel="true" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.MSOffice.PRESENTATION_FORMAT]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="MSOffice_NOTES" required="false" showLabel="true" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.MSOffice.NOTES]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="MSOffice_MANAGER" required="false" showLabel="true" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.MSOffice.MANAGER]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="MSOffice_APPLICATION_VERSION" required="false" showLabel="true" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.MSOffice.APPLICATION_VERSION]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="MSOffice_VERSION" required="false" showLabel="true" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.MSOffice.VERSION]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="MSOffice_CONTENT_STATUS" required="false" showLabel="true" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.MSOffice.CONTENT_STATUS]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="MSOffice_CATEGORY" required="false" showLabel="true" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.MSOffice.CATEGORY]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="MSOffice_COMPANY" required="false" showLabel="true" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.MSOffice.COMPANY]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="MSOffice_SECURITY" required="false" showLabel="true" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.MSOffice.SECURITY]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="MSOffice_SLIDE_COUNT" required="false" showLabel="true" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.MSOffice.SLIDE_COUNT]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="MSOffice_PAGE_COUNT" required="false" showLabel="true" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.MSOffice.PAGE_COUNT]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="MSOffice_PARAGRAPH_COUNT" required="false" showLabel="true" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.MSOffice.PARAGRAPH_COUNT]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="MSOffice_LINE_COUNT" required="false" showLabel="true" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.MSOffice.LINE_COUNT]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="MSOffice_WORD_COUNT" required="false" showLabel="true" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.MSOffice.WORD_COUNT]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="MSOffice_CHARACTER_COUNT" required="false" showLabel="true" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.MSOffice.CHARACTER_COUNT]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="MSOffice_CHARACTER_COUNT_WITH_SPACES" required="false" showLabel="true" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.MSOffice.CHARACTER_COUNT_WITH_SPACES]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="MSOffice_TABLE_COUNT" required="false" showLabel="true" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.MSOffice.TABLE_COUNT]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="MSOffice_IMAGE_COUNT" required="false" showLabel="true" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.MSOffice.IMAGE_COUNT]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="MSOffice_OBJECT_COUNT" required="false" showLabel="true" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.MSOffice.OBJECT_COUNT]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="MSOffice_EDIT_TIME" required="false" showLabel="true" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.MSOffice.EDIT_TIME]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="MSOffice_CREATION_DATE" required="false" showLabel="true" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.MSOffice.CREATION_DATE]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="MSOffice_LAST_SAVED" required="false" showLabel="true" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.MSOffice.LAST_SAVED]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="MSOffice_LAST_PRINTED" required="false" showLabel="true" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.MSOffice.LAST_PRINTED]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="MSOffice_USER_DEFINED_METADATA_NAME_PREFIX" required="false" showLabel="true" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.MSOffice.USER_DEFINED_METADATA_NAME_PREFIX]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="TIFF_BITS_PER_SAMPLE" required="false" showLabel="true" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.TIFF.BITS_PER_SAMPLE]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="TIFF_IMAGE_LENGTH" required="false" showLabel="true" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.TIFF.IMAGE_LENGTH]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="TIFF_IMAGE_WIDTH" required="false" showLabel="true" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.TIFF.IMAGE_WIDTH]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="TIFF_SAMPLES_PER_PIXEL" required="false" showLabel="true" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.TIFF.SAMPLES_PER_PIXEL]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="TIFF_FLASH_FIRED" required="false" showLabel="true" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.TIFF.FLASH_FIRED]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="TIFF_EXPOSURE_TIME" required="false" showLabel="true" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.TIFF.EXPOSURE_TIME]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="TIFF_F_NUMBER" required="false" showLabel="true" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.TIFF.F_NUMBER]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="TIFF_FOCAL_LENGTH" required="false" showLabel="true" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.TIFF.FOCAL_LENGTH]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="TIFF_ISO_SPEED_RATINGS" required="false" showLabel="true" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.TIFF.ISO_SPEED_RATINGS]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="TIFF_EQUIPMENT_MAKE" required="false" showLabel="true" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.TIFF.EQUIPMENT_MAKE]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="TIFF_EQUIPMENT_MODEL" required="false" showLabel="true" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.TIFF.EQUIPMENT_MODEL]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="TIFF_SOFTWARE" required="false" showLabel="true" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.TIFF.SOFTWARE]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="TIFF_ORIENTATION" required="false" showLabel="true" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.TIFF.ORIENTATION]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="TIFF_RESOLUTION_HORIZONTAL" required="false" showLabel="true" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.TIFF.RESOLUTION_HORIZONTAL]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="TIFF_RESOLUTION_VERTICAL" required="false" showLabel="true" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.TIFF.RESOLUTION_VERTICAL]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="TIFF_RESOLUTION_UNIT" required="false" showLabel="true" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.TIFF.RESOLUTION_UNIT]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="TIFF_ORIGINAL_DATE" required="false" showLabel="true" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.TIFF.ORIGINAL_DATE]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="TikaMetadataKeys_RESOURCE_NAME_KEY" required="false" showLabel="true" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.TikaMetadataKeys.RESOURCE_NAME_KEY]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="TikaMetadataKeys_PROTECTED" required="false" showLabel="true" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.TikaMetadataKeys.PROTECTED]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="TikaMetadataKeys_EMBEDDED_RELATIONSHIP_ID" required="false" showLabel="true" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.TikaMetadataKeys.EMBEDDED_RELATIONSHIP_ID]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="TikaMimeKeys_TIKA_MIME_FILE" required="false" showLabel="true" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.TikaMimeKeys.TIKA_MIME_FILE]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="TikaMimeKeys_MIME_TYPE_MAGIC" required="false" showLabel="true" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.TikaMimeKeys.MIME_TYPE_MAGIC]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="XMPDM_DURATION" required="false" showLabel="true" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.XMPDM.DURATION]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="XMPDM_ABS_PEAK_AUDIO_FILE_PATH" required="false" showLabel="true" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.XMPDM.ABS_PEAK_AUDIO_FILE_PATH]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="XMPDM_ALBUM" required="false" showLabel="true" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.XMPDM.ALBUM]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="XMPDM_ALT_TAPE_NAME" required="false" showLabel="true" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.XMPDM.ALT_TAPE_NAME]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="XMPDM_ARTIST" required="false" showLabel="true" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.XMPDM.ARTIST]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="XMPDM_AUDIO_MOD_DATE" required="false" showLabel="true" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.XMPDM.AUDIO_MOD_DATE]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="XMPDM_AUDIO_SAMPLE_RATE" required="false" showLabel="true" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.XMPDM.AUDIO_SAMPLE_RATE]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="XMPDM_AUDIO_SAMPLE_TYPE" required="false" showLabel="true" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.XMPDM.AUDIO_SAMPLE_TYPE]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="XMPDM_AUDIO_CHANNEL_TYPE" required="false" showLabel="true" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.XMPDM.AUDIO_CHANNEL_TYPE]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="XMPDM_AUDIO_COMPRESSOR" required="false" showLabel="true" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.XMPDM.AUDIO_COMPRESSOR]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="XMPDM_COMPOSER" required="false" showLabel="true" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.XMPDM.COMPOSER]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="XMPDM_COPYRIGHT" required="false" showLabel="true" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.XMPDM.COPYRIGHT]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="XMPDM_ENGINEER" required="false" showLabel="true" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.XMPDM.ENGINEER]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="XMPDM_FILE_DATA_RATE" required="false" showLabel="true" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.XMPDM.FILE_DATA_RATE]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="XMPDM_GENRE" required="false" showLabel="true" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.XMPDM.GENRE]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="XMPDM_INSTRUMENT" required="false" showLabel="true" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.XMPDM.INSTRUMENT]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="XMPDM_KEY" required="false" showLabel="true" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.XMPDM.KEY]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="XMPDM_LOG_COMMENT" required="false" showLabel="true" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.XMPDM.LOG_COMMENT]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="XMPDM_LOOP" required="false" showLabel="true" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.XMPDM.LOOP]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="XMPDM_NUMBER_OF_BEATS" required="false" showLabel="true" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.XMPDM.NUMBER_OF_BEATS]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="XMPDM_METADATA_MOD_DATE" required="false" showLabel="true" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.XMPDM.METADATA_MOD_DATE]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="XMPDM_PULL_DOWN" required="false" showLabel="true" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.XMPDM.PULL_DOWN]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="XMPDM_RELATIVE_PEAK_AUDIO_FILE_PATH" required="false" showLabel="true" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.XMPDM.RELATIVE_PEAK_AUDIO_FILE_PATH]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="XMPDM_RELEASE_DATE" required="false" showLabel="true" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.XMPDM.RELEASE_DATE]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="XMPDM_SCALE_TYPE" required="false" showLabel="true" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.XMPDM.SCALE_TYPE]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="XMPDM_SCENE" required="false" showLabel="true" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.XMPDM.SCENE]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="XMPDM_SHOT_DATE" required="false" showLabel="true" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.XMPDM.SHOT_DATE]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="XMPDM_SHOT_LOCATION" required="false" showLabel="true" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.XMPDM.SHOT_LOCATION]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="XMPDM_SHOT_NAME" required="false" showLabel="true" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.XMPDM.SHOT_NAME]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="XMPDM_SPEAKER_PLACEMENT" required="false" showLabel="true" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.XMPDM.SPEAKER_PLACEMENT]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="XMPDM_STRETCH_MODE" required="false" showLabel="true" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.XMPDM.STRETCH_MODE]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="XMPDM_TAPE_NAME" required="false" showLabel="true" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.XMPDM.TAPE_NAME]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="XMPDM_TEMPO" required="false" showLabel="true" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.XMPDM.TEMPO]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="XMPDM_TIME_SIGNATURE" required="false" showLabel="true" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.XMPDM.TIME_SIGNATURE]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="XMPDM_TRACK_NUMBER" required="false" showLabel="true" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.XMPDM.TRACK_NUMBER]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="XMPDM_VIDEO_ALPHA_MODE" required="false" showLabel="true" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.XMPDM.VIDEO_ALPHA_MODE]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="XMPDM_VIDEO_ALPHA_UNITY_IS_TRANSPARENT" required="false" showLabel="true" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.XMPDM.VIDEO_ALPHA_UNITY_IS_TRANSPARENT]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="XMPDM_VIDEO_COLOR_SPACE" required="false" showLabel="true" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.XMPDM.VIDEO_COLOR_SPACE]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="XMPDM_VIDEO_COMPRESSOR" required="false" showLabel="true" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.XMPDM.VIDEO_COMPRESSOR]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="XMPDM_VIDEO_FIELD_ORDER" required="false" showLabel="true" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.XMPDM.VIDEO_FIELD_ORDER]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="XMPDM_VIDEO_FRAME_RATE" required="false" showLabel="true" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.XMPDM.VIDEO_FRAME_RATE]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="XMPDM_VIDEO_MOD_DATE" required="false" showLabel="true" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.XMPDM.VIDEO_MOD_DATE]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="XMPDM_VIDEO_PIXEL_DEPTH" required="false" showLabel="true" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.XMPDM.VIDEO_PIXEL_DEPTH]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="XMPDM_VIDEO_PIXEL_ASPECT_RATIO" required="false" showLabel="true" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[metadata.XMPDM.VIDEO_PIXEL_ASPECT_RATIO]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n</root>	xml	0
bf53e538-2a6b-4075-8dac-5c7c0ae1c644	10412	10182	10155	10159		2017-03-10 17:06:04.835	2017-03-10 17:06:04.835	0	10098	CONTACTS	<?xml version='1.0' encoding='UTF-8'?><root available-locales="en_US" default-locale="en_US"><Name language-id="en_US">Contacts</Name></root>	<?xml version='1.0' encoding='UTF-8'?><root available-locales="en_US" default-locale="en_US"><Description language-id="en_US">Contacts</Description></root>	<?xml version="1.0"?>\n\n<root available-locales="en_US" default-locale="en_US">\n\t<dynamic-element dataType="string" name="company" required="false" showLabel="true" type="text" width="50">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[Company]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="email" required="false" showLabel="true" type="text" width="50">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[Email]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="firstName" required="false" showLabel="true" type="text" width="50">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[First Name]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" multiple="false" name="imService" required="false" showLabel="true" type="select">\n\t\t<dynamic-element name="aol" type="option" value="aol">\n\t\t\t<meta-data locale="en_US">\n\t\t\t\t<entry name="label"><![CDATA[AOL]]></entry>\n\t\t\t</meta-data>\n\t\t</dynamic-element>\n\t\t<dynamic-element name="yahoo" type="option" value="yahoo">\n\t\t\t<meta-data locale="en_US">\n\t\t\t\t<entry name="label"><![CDATA[Yahoo]]></entry>\n\t\t\t</meta-data>\n\t\t</dynamic-element>\n\t\t<dynamic-element name="gtalk" type="option" value="gtalk">\n\t\t\t<meta-data locale="en_US">\n\t\t\t\t<entry name="label"><![CDATA[GTalk]]></entry>\n\t\t\t</meta-data>\n\t\t</dynamic-element>\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[Instant Messenger Service]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[["gtalk"]]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="imUserName" required="false" showLabel="true" type="text" width="50">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[Instant Messenger]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="jobTitle" required="false" showLabel="true" type="text" width="50">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[Job Title]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="lastName" required="false" showLabel="true" type="text" width="50">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[Last Name]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="notes" required="false" showLabel="true" type="textarea" width="100">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[Notes]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="phoneMobile" required="false" showLabel="true" type="text" width="50">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[Phone (Mobile)]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="phoneOffice" required="false" showLabel="true" type="text" width="50">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[Phone (Office)]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n</root>	xml	0
d4fd5b59-90f8-441a-b544-c97a770db40f	10413	10182	10155	10159		2017-03-10 17:06:04.85	2017-03-10 17:06:04.85	0	10098	EVENTS	<?xml version='1.0' encoding='UTF-8'?><root available-locales="en_US" default-locale="en_US"><Name language-id="en_US">Events</Name></root>	<?xml version='1.0' encoding='UTF-8'?><root available-locales="en_US" default-locale="en_US"><Description language-id="en_US">Events</Description></root>	<?xml version="1.0"?>\n\n<root available-locales="en_US" default-locale="en_US">\n\t<dynamic-element dataType="document-library" fieldNamespace="ddm" name="attachment" required="false" showLabel="true" type="ddm-documentlibrary">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[Attachment]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="tip"><![CDATA[Upload documents no larger than 3,000k.]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="double" fieldNamespace="ddm" name="cost" required="false" showLabel="true" type="ddm-number" width="25">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[Cost]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="tip"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="description" required="false" showLabel="true" type="textarea" width="100">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[Description]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="tip"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="date" fieldNamespace="ddm" name="eventDate" required="false" showLabel="true" type="ddm-date" width="25">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[Date]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="tip"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="eventName" required="false" showLabel="true" type="text" width="50">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[Event Name]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="tip"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="eventTime" required="false" showLabel="true" type="text" width="25">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[Time]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="tip"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="location" required="false" showLabel="true" type="text" width="50">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[Location]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="tip"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n</root>	xml	0
8302b9bc-abd2-4909-a8c2-937a6d8be3bf	10414	10182	10155	10159		2017-03-10 17:06:04.863	2017-03-10 17:06:04.863	0	10098	INVENTORY	<?xml version='1.0' encoding='UTF-8'?><root available-locales="en_US" default-locale="en_US"><Name language-id="en_US">Inventory</Name></root>	<?xml version='1.0' encoding='UTF-8'?><root available-locales="en_US" default-locale="en_US"><Description language-id="en_US">Inventory</Description></root>	<?xml version="1.0"?>\n\n<root available-locales="en_US" default-locale="en_US">\n\t<dynamic-element dataType="string" name="description" required="false" showLabel="true" type="textarea" width="100">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[Description]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="style"><![CDATA[]]></entry>\n\t\t\t<entry name="tip"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="item" required="false" showLabel="true" type="text" width="25">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[Item]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="style"><![CDATA[]]></entry>\n\t\t\t<entry name="tip"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="location" required="false" showLabel="true" type="text" width="25">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[Location]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="style"><![CDATA[]]></entry>\n\t\t\t<entry name="tip"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="date" fieldNamespace="ddm" name="purchaseDate" required="false" showLabel="true" type="ddm-date" width="25">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[Purchase Date]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="style"><![CDATA[]]></entry>\n\t\t\t<entry name="tip"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="double" fieldNamespace="ddm" name="purchasePrice" required="false" showLabel="true" type="ddm-number" width="25">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[Purchase Price]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="tip"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="double" fieldNamespace="ddm" name="quantity" required="false" showLabel="true" type="ddm-number" width="25">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[Quantity]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="tip"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n</root>	xml	0
67de8d9e-ec6c-405f-b490-7f1db7d4f35f	10415	10182	10155	10159		2017-03-10 17:06:04.882	2017-03-10 17:06:04.882	0	10098	ISSUES TRACKING	<?xml version='1.0' encoding='UTF-8'?><root available-locales="en_US" default-locale="en_US"><Name language-id="en_US">Issues Tracking</Name></root>	<?xml version='1.0' encoding='UTF-8'?><root available-locales="en_US" default-locale="en_US"><Description language-id="en_US">Issue Tracking</Description></root>	<?xml version="1.0"?>\n\n<root available-locales="en_US" default-locale="en_US">\n\t<dynamic-element dataType="string" name="assignedTo" required="false" showLabel="true" type="text" width="25">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[Assigned To]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="document-library" fieldNamespace="ddm" name="attachment" required="false" showLabel="true" type="ddm-documentlibrary">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[Attachment]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="tip"><![CDATA[Upload documents no larger than 3,000k.]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="comments" required="false" showLabel="true" type="textarea" width="100">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[Comments]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="description" required="false" showLabel="true" type="textarea" width="100">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[Description]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="date" fieldNamespace="ddm" name="dueDate" required="false" showLabel="true" type="ddm-date">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[Due Date]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="issueId" required="false" showLabel="true" type="text" width="25">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[Issue ID]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" multiple="false" name="severity" required="false" showLabel="true" type="select">\n\t\t<dynamic-element name="critical" type="option" value="critical">\n\t\t\t<meta-data locale="en_US">\n\t\t\t\t<entry name="label"><![CDATA[Critical]]></entry>\n\t\t\t</meta-data>\n\t\t</dynamic-element>\n\t\t<dynamic-element name="major" type="option" value="major">\n\t\t\t<meta-data locale="en_US">\n\t\t\t\t<entry name="label"><![CDATA[Major]]></entry>\n\t\t\t</meta-data>\n\t\t</dynamic-element>\n\t\t<dynamic-element name="minor" type="option" value="minor">\n\t\t\t<meta-data locale="en_US">\n\t\t\t\t<entry name="label"><![CDATA[Minor]]></entry>\n\t\t\t</meta-data>\n\t\t</dynamic-element>\n\t\t<dynamic-element name="trivial" type="option" value="trivial">\n\t\t\t<meta-data locale="en_US">\n\t\t\t\t<entry name="label"><![CDATA[Trivial]]></entry>\n\t\t\t</meta-data>\n\t\t</dynamic-element>\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[Severity]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[["minor"]]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" multiple="false" name="status" required="false" showLabel="true" type="select">\n\t\t<dynamic-element name="open" type="option" value="open">\n\t\t\t<meta-data locale="en_US">\n\t\t\t\t<entry name="label"><![CDATA[Open]]></entry>\n\t\t\t</meta-data>\n\t\t</dynamic-element>\n\t\t<dynamic-element name="pending" type="option" value="pending">\n\t\t\t<meta-data locale="en_US">\n\t\t\t\t<entry name="label"><![CDATA[Pending]]></entry>\n\t\t\t</meta-data>\n\t\t</dynamic-element>\n\t\t<dynamic-element name="completed" type="option" value="completed">\n\t\t\t<meta-data locale="en_US">\n\t\t\t\t<entry name="label"><![CDATA[Completed]]></entry>\n\t\t\t</meta-data>\n\t\t</dynamic-element>\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[Status]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[["open"]]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="title" required="false" showLabel="true" type="text" width="100">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[Title]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n</root>	xml	0
77eab2d5-5f09-4554-81b4-b3b4e7833d3e	10416	10182	10155	10159		2017-03-10 17:06:04.942	2017-03-10 17:06:04.942	0	10098	MEETING MINUTES	<?xml version='1.0' encoding='UTF-8'?><root available-locales="en_US" default-locale="en_US"><Name language-id="en_US">Meeting Minutes</Name></root>	<?xml version='1.0' encoding='UTF-8'?><root available-locales="en_US" default-locale="en_US"><Description language-id="en_US">Meeting Minutes</Description></root>	<?xml version="1.0"?>\n\n<root available-locales="en_US" default-locale="en_US">\n\t<dynamic-element dataType="document-library" fieldNamespace="ddm" name="attachment" required="false" showLabel="true" type="ddm-documentlibrary">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[Attachment]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="tip"><![CDATA[Upload documents no larger than 3,000k.]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="author" required="false" showLabel="true" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[Author]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="description" required="false" showLabel="true" type="textarea" width="100">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[Description]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="duration" required="false" showLabel="true" type="text">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[Meeting Duration]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="date" fieldNamespace="ddm" name="meetingDate" required="false" showLabel="true" type="ddm-date">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[Meeting Date]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="minutes" required="false" showLabel="true" type="textarea" width="100">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[Minutes]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="title" required="false" showLabel="true" type="text" width="100">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[Title]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n</root>	xml	0
875eee6b-6def-40f7-9389-ddadc8fd57b8	10417	10182	10155	10159		2017-03-10 17:06:04.96	2017-03-10 17:06:04.96	0	10098	TO DO	<?xml version='1.0' encoding='UTF-8'?><root available-locales="en_US" default-locale="en_US"><Name language-id="en_US">To Do</Name></root>	<?xml version='1.0' encoding='UTF-8'?><root available-locales="en_US" default-locale="en_US"><Description language-id="en_US">To Do</Description></root>	<?xml version="1.0"?>\n\n<root available-locales="en_US" default-locale="en_US">\n\t<dynamic-element dataType="string" name="assignedTo" required="false" showLabel="true" type="text" width="50">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[Assigned To]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="document-library" fieldNamespace="ddm" name="attachment" required="false" showLabel="true" type="ddm-documentlibrary">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[Attachment]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t\t<entry name="tip"><![CDATA[Upload documents no larger than 3,000k.]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="comments" required="false" showLabel="true" type="textarea" width="100">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[Comments]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="description" required="false" showLabel="true" type="textarea" width="100">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[Description]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="date" fieldNamespace="ddm" name="endDate" required="false" showLabel="true" type="ddm-date">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[End Date]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="integer" fieldNamespace="ddm" name="percentComplete" required="false" showLabel="true" type="ddm-integer" width="25">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[% Complete]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[0]]></entry>\n\t\t\t<entry name="tip"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" multiple="false" name="severity" required="false" showLabel="true" type="select">\n\t\t<dynamic-element name="critical" type="option" value="critical">\n\t\t\t<meta-data locale="en_US">\n\t\t\t\t<entry name="label"><![CDATA[Critical]]></entry>\n\t\t\t</meta-data>\n\t\t</dynamic-element>\n\t\t<dynamic-element name="major" type="option" value="major">\n\t\t\t<meta-data locale="en_US">\n\t\t\t\t<entry name="label"><![CDATA[Major]]></entry>\n\t\t\t</meta-data>\n\t\t</dynamic-element>\n\t\t<dynamic-element name="minor" type="option" value="minor">\n\t\t\t<meta-data locale="en_US">\n\t\t\t\t<entry name="label"><![CDATA[Minor]]></entry>\n\t\t\t</meta-data>\n\t\t</dynamic-element>\n\t\t<dynamic-element name="trivial" type="option" value="trivial">\n\t\t\t<meta-data locale="en_US">\n\t\t\t\t<entry name="label"><![CDATA[Trivial]]></entry>\n\t\t\t</meta-data>\n\t\t</dynamic-element>\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[Severity]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[["minor"]]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="date" fieldNamespace="ddm" name="startDate" required="false" showLabel="true" type="ddm-date">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[Start Date]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" multiple="false" name="status" required="false" showLabel="true" type="select">\n\t\t<dynamic-element name="open" type="option" value="open">\n\t\t\t<meta-data locale="en_US">\n\t\t\t\t<entry name="label"><![CDATA[Open]]></entry>\n\t\t\t</meta-data>\n\t\t</dynamic-element>\n\t\t<dynamic-element name="pending" type="option" value="pending">\n\t\t\t<meta-data locale="en_US">\n\t\t\t\t<entry name="label"><![CDATA[Pending]]></entry>\n\t\t\t</meta-data>\n\t\t</dynamic-element>\n\t\t<dynamic-element name="completed" type="option" value="completed">\n\t\t\t<meta-data locale="en_US">\n\t\t\t\t<entry name="label"><![CDATA[Completed]]></entry>\n\t\t\t</meta-data>\n\t\t</dynamic-element>\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[Status]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[["open"]]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n\t<dynamic-element dataType="string" name="title" required="false" showLabel="true" type="text" width="50">\n\t\t<meta-data locale="en_US">\n\t\t\t<entry name="label"><![CDATA[Title]]></entry>\n\t\t\t<entry name="predefinedValue"><![CDATA[]]></entry>\n\t\t</meta-data>\n\t</dynamic-element>\n</root>	xml	0
\.


--
-- Data for Name: ddmstructurelink; Type: TABLE DATA; Schema: public; Owner: root
--

COPY ddmstructurelink (structurelinkid, classnameid, classpk, structureid) FROM stdin;
\.


--
-- Data for Name: ddmtemplate; Type: TABLE DATA; Schema: public; Owner: root
--

COPY ddmtemplate (uuid_, templateid, groupid, companyid, userid, username, createdate, modifieddate, classnameid, classpk, templatekey, name, description, type_, mode_, language, script, cacheable, smallimage, smallimageid, smallimageurl) FROM stdin;
b73162db-7fe7-4854-b684-617ee945ba42	10418	10195	10155	10159		2017-03-10 17:06:04.992	2017-03-10 17:06:04.992	10016	0	WIKI-SOCIAL-FTL	<?xml version='1.0' encoding='UTF-8'?><root available-locales="en_US" default-locale="en_US"><Name language-id="en_US">Social</Name></root>	<?xml version='1.0' encoding='UTF-8'?><root available-locales="en_US" default-locale="en_US"><Description language-id="en_US">Displays social bookmarks and ratings for wiki pages and their child pages.</Description></root>	display		ftl	<#assign liferay_ui = taglibLiferayHash["/WEB-INF/tld/liferay-ui.tld"] />\n\n<#assign wikiPageClassName = "com.liferay.portlet.wiki.model.WikiPage" />\n\n<#assign assetRenderer = assetEntry.getAssetRenderer() />\n\n<div class="taglib-header">\n\t<h1 class="header-title">${entry.getTitle()}</h1>\n</div>\n\n<div style="float: right;">\n\t<@getEditIcon />\n\n\t<@getPageDetailsIcon />\n\n\t<@getPrintIcon />\n</div>\n\n<div class="wiki-body">\n\t<div class="wiki-info">\n\t\t<span class="stats">${assetEntry.getViewCount()} <@liferay.language key="views" /></span> |\n\n\t\t<span class="date"><@liferay.language key="last-modified" /> ${dateUtil.getDate(entry.getModifiedDate(), "dd MMM yyyy - HH:mm:ss", locale)}</span>\n\n\t\t<span class="author"><@liferay.language key="by" /> ${htmlUtil.escape(portalUtil.getUserName(entry.getUserId(), entry.getUserName()))}</span>\n\t</div>\n\n\t<div class="wiki-content">\n\t\t<@liferay_ui["social-bookmarks"]\n\t\t\tdisplayStyle="normal"\n\t\t\ttarget="_blank"\n\t\t\ttitle=entry.getTitle()\n\t\t\turl=viewURL\n\t\t/>\n\n\t\t${formattedContent}\n\t</div>\n\n\t<div class="page-actions">\n\t\t<div class="article-actions">\n\t\t\t<@getAddChildPageIcon />\n\n\t\t\t<@getAttatchmentsIcon />\n\t\t</div>\n\t</div>\n\n\t <br />\n\n\t<@getRatings cssClass="page-ratings" entry=entry />\n\n\t<@getRelatedAssets />\n</div>\n\n<div class="page-categorization">\n\t<div class="page-categories">\n\t\t<#assign viewCategorizedPagesURL = renderResponse.createRenderURL() />\n\n\t\t${viewCategorizedPagesURL.setParameter("struts_action", "/wiki/view_categorized_pages")}\n\t\t${viewCategorizedPagesURL.setParameter("nodeId", entry.getNodeId()?string)}\n\n\t\t<@liferay_ui["asset-categories-summary"]\n\t\t\tclassName=wikiPageClassName\n\t\t\tclassPK=entry.getResourcePrimKey()\n\t\t\tportletURL=viewCategorizedPagesURL\n\t\t/>\n\t</div>\n\n\t<div class="page-tags">\n\t\t<#assign viewTaggedPagesURL = renderResponse.createRenderURL() />\n\n\t\t${viewTaggedPagesURL.setParameter("struts_action", "/wiki/view_tagged_pages")}\n\t\t${viewTaggedPagesURL.setParameter("nodeId", entry.getNodeId()?string)}\n\n\t\t<@liferay_ui["asset-tags-summary"]\n\t\t\tclassName=wikiPageClassName\n\t\t\tclassPK=entry.getResourcePrimKey()\n\t\t\tportletURL=viewTaggedPagesURL\n\t\t/>\n\t</div>\n</div>\n\n<#assign childPages = entry.getChildPages() />\n\n<#if (childPages?has_content)>\n\t<div class="child-pages">\n\t\t<h2><@liferay.language key="children-pages" /></h2>\n\n\t\t<table class="taglib-search-iterator">\n\t\t\t<tr class="portlet-section-header results-header">\n\t\t\t\t<th>\n\t\t\t\t\t<@liferay.language key="page" />\n\t\t\t\t</th>\n\t\t\t\t<th>\n\t\t\t\t\t<@liferay.language key="last-modified" />\n\t\t\t\t</th>\n\t\t\t\t<th>\n\t\t\t\t\t<@liferay.language key="ratings" />\n\t\t\t\t</th>\n\t\t\t</tr>\n\n\t\t\t<#list childPages as childPage>\n\t\t\t\t<tr class="results-row">\n\t\t\t\t\t<#assign viewPageURL = renderResponse.createRenderURL() />\n\n\t\t\t\t\t${viewPageURL.setParameter("struts_action", "/wiki/view")}\n\n\t\t\t\t\t<#assign childNode = childPage.getNode() />\n\n\t\t\t\t\t${viewPageURL.setParameter("nodeName", childNode.getName())}\n\t\t\t\t\t${viewPageURL.setParameter("title", childPage.getTitle())}\n\n\t\t\t\t\t<td>\n\t\t\t\t\t\t<a href="${viewPageURL}">${childPage.getTitle()}</a>\n\t\t\t\t\t</td>\n\t\t\t\t\t<td>\n\t\t\t\t\t\t<a href="${viewPageURL}">${dateUtil.getDate(childPage.getModifiedDate(),"dd MMM yyyy - HH:mm:ss", locale)} <@liferay.language key="by" /> ${htmlUtil.escape(portalUtil.getUserName(childPage.getUserId(), childPage.getUserName()))}</a>\n\t\t\t\t\t</td>\n\t\t\t\t\t<td>\n\t\t\t\t\t\t<@getRatings cssClass="child-ratings" entry=childPage />\n\t\t\t\t\t</td>\n\t\t\t\t</tr>\n\t\t\t</#list>\n\t\t</table>\n\t</div>\n</#if>\n\n<@getDiscussion />\n\n<#macro getAddChildPageIcon>\n\t<#if assetRenderer.hasEditPermission(themeDisplay.getPermissionChecker())>\n\t\t<#assign addPageURL = renderResponse.createRenderURL() />\n\n\t\t${addPageURL.setParameter("struts_action", "/wiki/edit_page")}\n\t\t${addPageURL.setParameter("redirect", currentURL)}\n\t\t${addPageURL.setParameter("nodeId", entry.getNodeId()?string)}\n\t\t${addPageURL.setParameter("title", "")}\n\t\t${addPageURL.setParameter("editTitle", "1")}\n\t\t${addPageURL.setParameter("parentTitle", entry.getTitle())}\n\n\t\t<@liferay_ui["icon"]\n\t\t\timage="add_article"\n\t\t\tlabel=true\n\t\t\tmessage="add-child-page"\n\t\t\turl=addPageURL?string\n\t\t/>\n\t</#if>\n</#macro>\n\n<#macro getAttatchmentsIcon>\n\t<#assign viewPageAttachmentsURL = renderResponse.createRenderURL() />\n\n\t${viewPageAttachmentsURL.setParameter("struts_action", "/wiki/view_page_attachments") }\n\n\t<@liferay_ui["icon"]\n\t\timage="clip"\n\t\tlabel=true\n\t\tmessage='${entry.getAttachmentsFileEntriesCount() + languageUtil.get(locale, "attachments")}'\n\t\turl=viewPageAttachmentsURL?string\n\t/>\n</#macro>\n\n<#macro getDiscussion>\n\t<#if validator.isNotNull(assetRenderer.getDiscussionPath()) && (enableComments == "true")>\n\t\t<br />\n\n\t\t<#assign discussionURL = renderResponse.createActionURL() />\n\n\t\t${discussionURL.setParameter("struts_action", "/wiki/" + assetRenderer.getDiscussionPath())}\n\n\t\t<@liferay_ui["discussion"]\n\t\t\tclassName=wikiPageClassName\n\t\t\tclassPK=entry.getResourcePrimKey()\n\t\t\tformAction=discussionURL?string\n\t\t\tformName="fm2"\n\t\t\tratingsEnabled=enableCommentRatings == "true"\n\t\t\tredirect=currentURL\n\t\t\tsubject=assetRenderer.getTitle(locale)\n\t\t\tuserId=assetRenderer.getUserId()\n\t\t/>\n\t</#if>\n</#macro>\n\n<#macro getEditIcon>\n\t<#if assetRenderer.hasEditPermission(themeDisplay.getPermissionChecker())>\n\t\t<#assign editPageURL = renderResponse.createRenderURL() />\n\n\t\t${editPageURL.setParameter("struts_action", "/wiki/edit_page")}\n\t\t${editPageURL.setParameter("redirect", currentURL)}\n\t\t${editPageURL.setParameter("nodeId", entry.getNodeId()?string)}\n\t\t${editPageURL.setParameter("title", entry.getTitle())}\n\n\t\t<@liferay_ui["icon"]\n\t\t\timage="edit"\n\t\t\tmessage=entry.getTitle()\n\t\t\turl=editPageURL?string\n\t\t/>\n\t</#if>\n</#macro>\n\n<#macro getPageDetailsIcon>\n\t<#assign viewPageDetailsURL = renderResponse.createRenderURL() />\n\n\t${viewPageDetailsURL.setParameter("struts_action", "/wiki/view_page_details")}\n\t${viewPageDetailsURL.setParameter("redirect", currentURL)}\n\n\t<@liferay_ui["icon"]\n\t\timage="history"\n\t\tmessage="details"\n\t\turl=viewPageDetailsURL?string\n\t/>\n</#macro>\n\n<#macro getPrintIcon>\n\t<#assign printURL = renderResponse.createRenderURL() />\n\n\t${printURL.setParameter("viewMode", "print")}\n\t${printURL.setWindowState("pop_up")}\n\n\t<#assign title = languageUtil.format(locale, "print-x-x", ["hide-accessible", htmlUtil.escape(assetRenderer.getTitle(locale))]) />\n\t<#assign taglibPrintURL = "javascript:Liferay.Util.openWindow({dialog: {width: 960}, id:'" + renderResponse.getNamespace() + "printAsset', title: '" + title + "', uri: '" + htmlUtil.escapeURL(printURL.toString()) + "'});" />\n\n\t<@liferay_ui["icon"]\n\t\timage="print"\n\t\tmessage="print"\n\t\turl=taglibPrintURL\n\t/>\n</#macro>\n\n<#macro getRatings\n\tcssClass\n\tentry\n>\n\t<#if enablePageRatings == "true">\n\t\t<div class="${cssClass}">\n\t\t\t<@liferay_ui["ratings"]\n\t\t\t\tclassName=wikiPageClassName\n\t\t\t\tclassPK=entry.getResourcePrimKey()\n\t\t\t/>\n\t\t</div>\n\t</#if>\n</#macro>\n\n<#macro getRelatedAssets>\n\t<#if assetEntry?? && (enableRelatedAssets == "true")>\n\t\t<@liferay_ui["asset-links"]\n\t\t\tassetEntryId=assetEntry.getEntryId()\n\t\t/>\n\t</#if>\n</#macro>	f	f	10419	
c63bf23e-dd97-4081-b0e9-dba7b790cc97	10420	10195	10155	10159		2017-03-10 17:06:05.026	2017-03-10 17:06:05.026	10081	0	ASSET-CATEGORIES-NAVIGATION-MULTI-COLUMN-LAYOUT-FTL	<?xml version='1.0' encoding='UTF-8'?><root available-locales="en_US" default-locale="en_US"><Name language-id="en_US">Multi Column Layout</Name></root>	<?xml version='1.0' encoding='UTF-8'?><root available-locales="en_US" default-locale="en_US"><Description language-id="en_US">Displays a column for each vocabulary. Each column includes the name of a vocabulary with the vocabulary's top level categories listed underneath.</Description></root>	display		ftl	<#assign aui = taglibLiferayHash["/WEB-INF/tld/aui.tld"] />\n\n<#if entries?has_content>\n\t<@aui.layout>\n\t\t<#list entries as entry>\n\t\t\t<@aui.column columnWidth=25>\n\t\t\t\t<div class="results-header">\n\t\t\t\t\t<h3>\n\t\t\t\t\t\t${entry.getName()}\n\t\t\t\t\t</h3>\n\t\t\t\t</div>\n\n\t\t\t\t<#assign categories = entry.getCategories()>\n\n\t\t\t\t<@displayCategories categories=categories />\n\t\t\t</@aui.column>\n\t\t</#list>\n\t</@aui.layout>\n</#if>\n\n<#macro displayCategories\n\tcategories\n>\n\t<#if categories?has_content>\n\t\t<ul class="categories">\n\t\t\t<#list categories as category>\n\t\t\t\t<li>\n\t\t\t\t\t<#assign categoryURL = renderResponse.createRenderURL()>\n\n\t\t\t\t\t${categoryURL.setParameter("resetCur", "true")}\n\t\t\t\t\t${categoryURL.setParameter("categoryId", category.getCategoryId()?string)}\n\n\t\t\t\t\t<a href="${categoryURL}">${category.getName()}</a>\n\n\t\t\t\t\t<#if serviceLocator??>\n\t\t\t\t\t\t<#assign assetCategoryService = serviceLocator.findService("com.liferay.portlet.asset.service.AssetCategoryService")>\n\n\t\t\t\t\t\t<#assign childCategories = assetCategoryService.getChildCategories(category.getCategoryId())>\n\n\t\t\t\t\t\t<@displayCategories categories=childCategories />\n\t\t\t\t\t</#if>\n\t\t\t\t</li>\n\t\t\t</#list>\n\t\t</ul>\n\t</#if>\n</#macro>	f	f	10421	
28e562a1-959e-4687-8d53-6de0b4ceb0ce	10423	10195	10155	10159		2017-03-10 17:06:05.042	2017-03-10 17:06:05.042	10422	0	DOCUMENTLIBRARY-CAROUSEL-FTL	<?xml version='1.0' encoding='UTF-8'?><root available-locales="en_US" default-locale="en_US"><Name language-id="en_US">Carousel</Name></root>	<?xml version='1.0' encoding='UTF-8'?><root available-locales="en_US" default-locale="en_US"><Description language-id="en_US">Displays images in a carousel.</Description></root>	display		ftl	<#assign aui = taglibLiferayHash["/WEB-INF/tld/aui.tld"] />\n<#assign liferay_portlet = taglibLiferayHash["/WEB-INF/tld/liferay-portlet.tld"] />\n\n<#if entries?has_content>\n\t<style>\n\t\t#<@liferay_portlet.namespace />carousel .carousel-item {\n\t\t\tbackground-color: #000;\n\t\t\theight: 250px;\n\t\t\toverflow: hidden;\n\t\t\ttext-align: center;\n\t\t\twidth: 700px;\n\t\t}\n\n\t\t#<@liferay_portlet.namespace />carousel .carousel-item img {\n\t\t\tmax-height: 250px;\n\t\t\tmax-width: 700px;\n\t\t}\n\t</style>\n\n\t<div id="<@liferay_portlet.namespace />carousel">\n\t\t<#assign imageMimeTypes = propsUtil.getArray("dl.file.entry.preview.image.mime.types") />\n\n\t\t<#list entries as entry>\n\t\t\t<#if imageMimeTypes?seq_contains(entry.getMimeType()) >\n\t\t\t\t<div class="carousel-item">\n\t\t\t\t\t<img src="${dlUtil.getPreviewURL(entry, entry.getFileVersion(), themeDisplay, "")}" />\n\t\t\t\t</div>\n\t\t\t</#if>\n\t\t</#list>\n\t</div>\n\n\t<@aui.script use="aui-carousel">\n\t\tnew A.Carousel(\n\t\t\t{\n\t\t\t\tcontentBox: '#<@liferay_portlet.namespace />carousel',\n\t\t\t\theight: 250,\n\t\t\t\tintervalTime: 2,\n\t\t\t\twidth: 700\n\t\t\t}\n\t\t).render();\n\t</@aui.script>\n</#if>	f	f	10424	
459f5e20-c674-4a06-a6ff-96c322f22607	10425	10195	10155	10159		2017-03-10 17:06:05.055	2017-03-10 17:06:05.055	10083	0	ASSET-PUBLISHER-RICH-SUMMARY-FTL	<?xml version='1.0' encoding='UTF-8'?><root available-locales="en_US" default-locale="en_US"><Name language-id="en_US">Rich Summary</Name></root>	<?xml version='1.0' encoding='UTF-8'?><root available-locales="en_US" default-locale="en_US"><Description language-id="en_US">Displays abstracts, icons, related assets, and print/edit actions for assets. Optionally include asset bookmarks and ratings.</Description></root>	display		ftl	<#assign liferay_ui = taglibLiferayHash["/WEB-INF/tld/liferay-ui.tld"] />\n\n<#list entries as entry>\n\t<#assign entry = entry />\n\n\t<#assign assetRenderer = entry.getAssetRenderer() />\n\n\t<#assign entryTitle = htmlUtil.escape(assetRenderer.getTitle(locale)) />\n\n\t<#assign viewURL = assetPublisherHelper.getAssetViewURL(renderRequest, renderResponse, entry) />\n\n\t<#if assetLinkBehavior != "showFullContent">\n\t\t<#assign viewURL = assetPublisherHelperImpl.getAssetViewURL(renderRequest, renderResponse, entry, true) />\n\t</#if>\n\n\t<div class="asset-abstract">\n\t\t<div class="lfr-meta-actions asset-actions">\n\t\t\t<@getPrintIcon />\n\n\t\t\t<@getFlagsIcon />\n\n\t\t\t<@getEditIcon />\n\t\t</div>\n\n\t\t<h3 class="asset-title">\n\t\t\t<a href="${viewURL}"><img alt="" src="${assetRenderer.getIconPath(renderRequest)}" />${entryTitle}</a>\n\t\t</h3>\n\n\t\t<@getMetadataField fieldName="tags" />\n\n\t\t<@getMetadataField fieldName="create-date" />\n\n\t\t<@getMetadataField fieldName="view-count" />\n\n\t\t<div class="asset-content">\n\t\t\t<@getSocialBookmarks />\n\n\t\t\t<div class="asset-summary">\n\t\t\t\t<@getMetadataField fieldName="author" />\n\n\t\t\t\t${htmlUtil.escape(assetRenderer.getSummary(locale))}\n\n\t\t\t\t<a href="${viewURL}"><@liferay.language key="read-more" /><span class="hide-accessible"><@liferay.language key="about" />${entryTitle}</span> &raquo;</a>\n\t\t\t</div>\n\n\t\t\t<@getRatings />\n\n\t\t\t<@getRelatedAssets />\n\n\t\t\t<@getDiscussion />\n\t\t</div>\n\t</div>\n\n</#list>\n\n<#macro getDiscussion>\n\t<#if validator.isNotNull(assetRenderer.getDiscussionPath()) && (enableComments == "true")>\n\t\t<br />\n\n\t\t<#assign discussionURL = renderResponse.createActionURL() />\n\n\t\t${discussionURL.setParameter("struts_action", "/asset_publisher/" + assetRenderer.getDiscussionPath())}\n\n\t\t<@liferay_ui["discussion"]\n\t\t\tclassName=entry.getClassName()\n\t\t\tclassPK=entry.getClassPK()\n\t\t\tformAction=discussionURL?string\n\t\t\tformName="fm" + entry.getClassPK()\n\t\t\tratingsEnabled=enableCommentRatings == "true"\n\t\t\tredirect=portalUtil.getCurrentURL(request)\n\t\t\tuserId=assetRenderer.getUserId()\n\t\t/>\n\t</#if>\n</#macro>\n\n<#macro getEditIcon>\n\t<#if assetRenderer.hasEditPermission(themeDisplay.getPermissionChecker())>\n\t\t<#assign redirectURL = renderResponse.createRenderURL() />\n\n\t\t${redirectURL.setParameter("struts_action", "/asset_publisher/add_asset_redirect")}\n\t\t${redirectURL.setWindowState("pop_up")}\n\n\t\t<#assign editPortletURL = assetRenderer.getURLEdit(renderRequest, renderResponse, windowStateFactory.getWindowState("pop_up"), redirectURL)!"" />\n\n\t\t<#if validator.isNotNull(editPortletURL)>\n\t\t\t<#assign title = languageUtil.format(locale, "edit-x", entryTitle) />\n\n\t\t\t<@liferay_ui["icon"]\n\t\t\t\timage="edit"\n\t\t\t\tmessage=title\n\t\t\t\turl="javascript:Liferay.Util.openWindow({dialog: {width: 960}, id:'" + renderResponse.getNamespace() + "editAsset', title: '" + title + "', uri:'" + htmlUtil.escapeURL(editPortletURL.toString()) + "'});"\n\t\t\t/>\n\t\t</#if>\n\t</#if>\n</#macro>\n\n<#macro getFlagsIcon>\n\t<#if enableFlags == "true">\n\t\t<@liferay_ui["flags"]\n\t\t\tclassName=entry.getClassName()\n\t\t\tclassPK=entry.getClassPK()\n\t\t\tcontentTitle=entry.getTitle(locale)\n\t\t\tlabel=false\n\t\t\treportedUserId=entry.getUserId()\n\t\t/>\n\t</#if>\n</#macro>\n\n<#macro getMetadataField\n\tfieldName\n>\n\t<#if stringUtil.split(metadataFields)?seq_contains(fieldName)>\n\t\t<span class="metadata-entry metadata-"${fieldName}">\n\t\t\t<#assign dateFormat = "dd MMM yyyy - HH:mm:ss" />\n\n\t\t\t<#if fieldName == "author">\n\t\t\t\t<@liferay.language key="by" /> ${portalUtil.getUserName(assetRenderer.getUserId(), assetRenderer.getUserName())}\n\t\t\t<#elseif fieldName == "categories">\n\t\t\t\t<@liferay_ui["asset-categories-summary"]\n\t\t\t\t\tclassName=entry.getClassName()\n\t\t\t\t\tclassPK=entry.getClassPK()\n\t\t\t\t\tportletURL=renderResponse.createRenderURL()\n\t\t\t\t/>\n\t\t\t<#elseif fieldName == "create-date">\n\t\t\t\t${dateUtil.getDate(entry.getCreateDate(), dateFormat, locale)}\n\t\t\t<#elseif fieldName == "expiration-date">\n\t\t\t\t${dateUtil.getDate(entry.getExpirationDate(), dateFormat, locale)}\n\t\t\t<#elseif fieldName == "modified-date">\n\t\t\t\t${dateUtil.getDate(entry.getModifiedDate(), dateFormat, locale)}\n\t\t\t<#elseif fieldName == "priority">\n\t\t\t\t${entry.getPriority()}\n\t\t\t<#elseif fieldName == "publish-date">\n\t\t\t\t${dateUtil.getDate(entry.getPublishDate(), dateFormat, locale)}\n\t\t\t<#elseif fieldName == "tags">\n\t\t\t\t<@liferay_ui["asset-tags-summary"]\n\t\t\t\t\tclassName=entry.getClassName()\n\t\t\t\t\tclassPK=entry.getClassPK()\n\t\t\t\t\tportletURL=renderResponse.createRenderURL()\n\t\t\t\t/>\n\t\t\t<#elseif fieldName == "view-count">\n\t\t\t\t<@liferay_ui["icon"]\n\t\t\t\t\timage="history"\n\t\t\t\t/>\n\n\t\t\t\t${entry.getViewCount()} <@liferay.language key="views" />\n\t\t\t</#if>\n\t\t</span>\n\t</#if>\n</#macro>\n\n<#macro getPrintIcon>\n\t<#if enablePrint == "true" >\n\t\t<#assign printURL = renderResponse.createRenderURL() />\n\n\t\t${printURL.setParameter("struts_action", "/asset_publisher/view_content")}\n\t\t${printURL.setParameter("assetEntryId", entry.getEntryId()?string)}\n\t\t${printURL.setParameter("viewMode", "print")}\n\t\t${printURL.setParameter("type", entry.getAssetRendererFactory().getType())}\n\n\t\t<#if (validator.isNotNull(assetRenderer.getUrlTitle()))>\n\t\t\t<#if (assetRenderer.getGroupId() != themeDisplay.getScopeGroupId())>\n\t\t\t\t${printURL.setParameter("groupId", assetRenderer.getGroupId()?string)}\n\t\t\t</#if>\n\n\t\t\t${printURL.setParameter("urlTitle", assetRenderer.getUrlTitle())}\n\t\t</#if>\n\n\t\t${printURL.setWindowState("pop_up")}\n\n\t\t<@liferay_ui["icon"]\n\t\t\timage="print"\n\t\t\tmessage="print"\n\t\t\turl="javascript:Liferay.Util.openWindow({id:'" + renderResponse.getNamespace() + "printAsset', title: '" + languageUtil.format(locale, "print-x-x", ["hide-accessible", entryTitle]) + "', uri: '" + htmlUtil.escapeURL(printURL.toString()) + "'});"\n\t\t/>\n\t</#if>\n</#macro>\n\n<#macro getRatings>\n\t<#if (enableRatings == "true")>\n\t\t<div class="asset-ratings">\n\t\t\t<@liferay_ui["ratings"]\n\t\t\t\tclassName=entry.getClassName()\n\t\t\t\tclassPK=entry.getClassPK()\n\t\t\t/>\n\t\t</div>\n\t</#if>\n</#macro>\n\n<#macro getRelatedAssets>\n\t<#if enableRelatedAssets == "true">\n\t\t<@liferay_ui["asset-links"]\n\t\t\tassetEntryId=entry.getEntryId()\n\t\t/>\n\t</#if>\n</#macro>\n\n<#macro getSocialBookmarks>\n\t<#if enableSocialBookmarks == "true">\n\t\t<@liferay_ui["social-bookmarks"]\n\t\t\tdisplayStyle="${socialBookmarksDisplayStyle}"\n\t\t\ttarget="_blank"\n\t\t\ttitle=entry.getTitle(locale)\n\t\t\turl=viewURL\n\t\t/>\n\t</#if>\n</#macro>	f	f	10426	
7aa4c8db-5279-4da5-ae24-f13fc414877f	10427	10195	10155	10159		2017-03-10 17:06:05.069	2017-03-10 17:06:05.069	10034	0	SITE-MAP-MULTI-COLUMN-LAYOUT-FTL	<?xml version='1.0' encoding='UTF-8'?><root available-locales="en_US" default-locale="en_US"><Name language-id="en_US">Multi Column Layout</Name></root>	<?xml version='1.0' encoding='UTF-8'?><root available-locales="en_US" default-locale="en_US"><Description language-id="en_US">Displays a column for each top level page. Each column includes the name of a top level page with the page's immediate children listed underneath.</Description></root>	display		ftl	<#assign aui = taglibLiferayHash["/WEB-INF/tld/aui.tld"] />\n\n<#if entries?has_content>\n\t<@aui.layout>\n\t\t<#list entries as entry>\n\t\t    <@aui.column columnWidth=25>\n\t\t\t\t<div class="results-header">\n\t\t\t\t\t<h3>\n\t\t\t\t\t\t<#assign layoutURL = portalUtil.getLayoutURL(entry, themeDisplay)>\n\n\t\t\t\t\t\t<a href="${layoutURL}">${entry.getName(locale)}</a>\n\t\t\t\t\t</h3>\n\t\t\t\t</div>\n\n\t\t\t\t<#assign pages = entry.getChildren()>\n\n\t\t\t\t<@displayPages pages = pages />\n\t\t    </@aui.column>\n\t\t</#list>\n\t</@aui.layout>\n</#if>\n\n<#macro displayPages\n\tpages\n>\n\t<#if pages?has_content>\n\t\t<ul class="child-pages">\n\t\t\t<#list pages as page>\n\t\t\t\t<li>\n\t\t\t\t\t<#assign pageLayoutURL = portalUtil.getLayoutURL(page, themeDisplay)>\n\n\t\t\t\t\t<a href="${pageLayoutURL}">${page.getName(locale)}</a>\n\n\t\t\t\t\t<#assign childPages = page.getChildren()>\n\n\t\t\t\t\t<@displayPages pages = childPages />\n\t\t\t\t</li>\n\t\t\t</#list>\n\t\t</ul>\n\t</#if>\n</#macro>	f	f	10428	
ca0ed853-6251-409a-b3e8-344dab49dd60	10429	10195	10155	10159		2017-03-10 17:06:05.077	2017-03-10 17:06:05.077	10085	0	ASSET-TAGS-NAVIGATION-COLOR-BY-POPULARITY-FTL	<?xml version='1.0' encoding='UTF-8'?><root available-locales="en_US" default-locale="en_US"><Name language-id="en_US">Color by Popularity</Name></root>	<?xml version='1.0' encoding='UTF-8'?><root available-locales="en_US" default-locale="en_US"><Description language-id="en_US">Displays asset tags colored by popularity: red (high), yellow (medium), and green (low).</Description></root>	display		ftl	<#if entries?has_content>\n\t<ul class="tag-items tag-list">\n\t\t<#assign scopeGroupId = getterUtil.getLong(scopeGroupId, themeDisplay.getScopeGroupId()) />\n\t\t<#assign classNameId = getterUtil.getLong(classNameId, 0) />\n\n\t\t<#assign maxCount = 1 />\n\t\t<#assign minCount = 1 />\n\n\t\t<#list entries as entry>\n\t\t\t<#assign maxCount = liferay.max(maxCount, entry.getAssetCount()) />\n\t\t\t<#assign minCount = liferay.min(minCount, entry.getAssetCount()) />\n\t\t</#list>\n\n\t\t<#assign multiplier = 1 />\n\n\t\t<#if maxCount != minCount>\n\t\t\t<#assign multiplier = 3 / (maxCount - minCount) />\n\t\t</#if>\n\n\t\t<#list entries as entry>\n\t\t\t<li class="taglib-asset-tags-summary">\n\t\t\t\t<#assign popularity = (maxCount - (maxCount - (entry.getAssetCount() - minCount))) * multiplier />\n\n\t\t\t\t<#if popularity < 1>\n\t\t\t\t\t<#assign color = "green" />\n\t\t\t\t<#elseif (popularity >= 1) && (popularity < 2)>\n\t\t\t\t\t<#assign color = "orange" />\n\t\t\t\t<#else>\n\t\t\t\t\t<#assign color = "red" />\n\t\t\t\t</#if>\n\n\t\t\t\t<#assign tagURL = renderResponse.createRenderURL() />\n\n\t\t\t\t${tagURL.setParameter("resetCur", "true")}\n\t\t\t\t${tagURL.setParameter("tag", entry.getName())}\n\n\t\t\t\t<a class ="tag" style="color: ${color};" href="${tagURL}">\n\t\t\t\t\t${entry.getName()}\n\n\t\t\t\t\t<#if (showAssetCount == "true")>\n\t\t\t\t\t\t<span class="tag-asset-count">(${count})</span>\n\t\t\t\t\t</#if>\n\t\t\t\t</a>\n\t\t\t</li>\n\t\t</#list>\n\t</ul>\n\n\t<br style="clear: both;" />\n</#if>	f	f	10430	
80d80d0d-8fb4-4223-b065-e0e01031eb85	10431	10195	10155	10159		2017-03-10 17:06:05.086	2017-03-10 17:06:05.086	10007	0	BLOGS-BASIC-FTL	<?xml version='1.0' encoding='UTF-8'?><root available-locales="en_US" default-locale="en_US"><Name language-id="en_US">Basic</Name></root>	<?xml version='1.0' encoding='UTF-8'?><root available-locales="en_US" default-locale="en_US"><Description language-id="en_US">Displays titles, authors, and abstracts compactly for blog entries.</Description></root>	display		ftl	<#assign liferay_ui = taglibLiferayHash["/WEB-INF/tld/liferay-ui.tld"] />\n\n<#list entries as entry>\n\t<div class="entry">\n\t\t<#assign viewURL = renderResponse.createRenderURL() />\n\n\t\t${viewURL.setParameter("struts_action", "/blogs/view_entry")}\n\t\t${viewURL.setParameter("redirect", currentURL)}\n\t\t${viewURL.setParameter("urlTitle", entry.getUrlTitle())}\n\n\t\t<div class="entry-content">\n\t\t\t<div class="entry-title">\n\t\t\t\t<h2><a href="${viewURL}">${htmlUtil.escape(entry.getTitle())}</a></h2>\n\t\t\t</div>\n\t\t</div>\n\n\t\t<div class="entry-body">\n\t\t\t<div class="entry-author">\n\t\t\t\t<@liferay.language key="written-by" /> ${htmlUtil.escape(portalUtil.getUserName(entry.getUserId(), entry.getUserName()))}\n\t\t\t</div>\n\n\t\t\t<#assign summary = entry.getDescription() />\n\n\t\t\t<#if (validator.isNull(summary))>\n\t\t\t\t<#assign summary = entry.getContent() />\n\t\t\t</#if>\n\n\t\t\t${stringUtil.shorten(htmlUtil.stripHtml(summary), 100)}\n\n\t\t\t<a href="${viewURL}"><@liferay.language key="read-more" /> <span class="hide-accessible"><@liferay.language key="about"/>${htmlUtil.escape(entry.getTitle())}</span> &raquo;</a>\n\t\t</div>\n\n\t\t<div class="entry-footer">\n\t\t\t<span class="entry-date">\n\t\t\t\t${dateUtil.getDate(entry.getCreateDate(), "dd MMM yyyy - HH:mm:ss", locale)}\n\t\t\t</span>\n\n\t\t\t<#assign blogsEntryClassName = "com.liferay.portlet.blogs.model.BlogsEntry" />\n\n\t\t\t<#if (enableFlags == "true")>\n\t\t\t\t<@liferay_ui["flags"]\n\t\t\t\t\tclassName=blogsEntryClassName\n\t\t\t\t\tclassPK=entry.getEntryId()\n\t\t\t\t\tcontentTitle=entry.getTitle()\n\t\t\t\t\treportedUserId=entry.getUserId()\n\t\t\t\t/>\n\t\t\t</#if>\n\n\t\t\t<span class="entry-categories">\n\t\t\t\t<@liferay_ui["asset-categories-summary"]\n\t\t\t\t\tclassName=blogsEntryClassName\n\t\t\t\t\tclassPK=entry.getEntryId()\n\t\t\t\t\tportletURL=renderResponse.createRenderURL()\n\t\t\t\t/>\n\t\t\t</span>\n\n\t\t\t<span class="entry-tags">\n\t\t\t\t<@liferay_ui["asset-tags-summary"]\n\t\t\t\t\tclassName=blogsEntryClassName\n\t\t\t\t\tclassPK=entry.getEntryId()\n\t\t\t\t\tportletURL=renderResponse.createRenderURL()\n\t\t\t\t/>\n\t\t\t</span>\n\t\t</div>\n\t</div>\n\n\t<div class="separator"><!-- --></div>\n</#list>	f	f	10432	
\.


--
-- Data for Name: dlcontent; Type: TABLE DATA; Schema: public; Owner: root
--

COPY dlcontent (contentid, groupid, companyid, repositoryid, path_, version, data_, size_) FROM stdin;
\.


--
-- Data for Name: dlfileentry; Type: TABLE DATA; Schema: public; Owner: root
--

COPY dlfileentry (uuid_, fileentryid, groupid, companyid, userid, username, createdate, modifieddate, classnameid, classpk, repositoryid, folderid, treepath, name, extension, mimetype, title, description, extrasettings, fileentrytypeid, version, size_, readcount, smallimageid, largeimageid, custom1imageid, custom2imageid, manualcheckinrequired) FROM stdin;
\.


--
-- Data for Name: dlfileentrymetadata; Type: TABLE DATA; Schema: public; Owner: root
--

COPY dlfileentrymetadata (uuid_, fileentrymetadataid, ddmstorageid, ddmstructureid, fileentrytypeid, fileentryid, fileversionid) FROM stdin;
\.


--
-- Data for Name: dlfileentrytype; Type: TABLE DATA; Schema: public; Owner: root
--

COPY dlfileentrytype (uuid_, fileentrytypeid, groupid, companyid, userid, username, createdate, modifieddate, fileentrytypekey, name, description) FROM stdin;
bc6a7a29-3943-4e89-8b7d-7029f26d3674	0	0	0	0		2017-03-10 17:05:53.836	2017-03-10 17:05:53.836	BASIC-DOCUMENT	<?xml version='1.0' encoding='UTF-8'?><root available-locales="en_US" default-locale="en_US"><Name language-id="en_US">basic-document</Name></root>	
a8c08ec2-ced6-4a44-a274-eb9a6fd298da	10306	10195	10155	10159		2017-03-10 17:06:02.987	2017-03-10 17:06:02.987	CONTRACT	<?xml version='1.0' encoding='UTF-8'?><root available-locales="en_US" default-locale="en_US"><Name language-id="en_US">Contract</Name></root>	<?xml version='1.0' encoding='UTF-8'?><root available-locales="en_US" default-locale="en_US"><Description language-id="en_US">Contract</Description></root>
bdde61df-9189-4867-a985-08e5b4c45fde	10308	10195	10155	10159		2017-03-10 17:06:03.019	2017-03-10 17:06:03.019	MARKETING BANNER	<?xml version='1.0' encoding='UTF-8'?><root available-locales="en_US" default-locale="en_US"><Name language-id="en_US">Marketing Banner</Name></root>	<?xml version='1.0' encoding='UTF-8'?><root available-locales="en_US" default-locale="en_US"><Description language-id="en_US">Marketing Banner</Description></root>
b3de3c82-278e-4626-a83b-47f0f27d9654	10310	10195	10155	10159		2017-03-10 17:06:03.046	2017-03-10 17:06:03.046	ONLINE TRAINING	<?xml version='1.0' encoding='UTF-8'?><root available-locales="en_US" default-locale="en_US"><Name language-id="en_US">Online Training</Name></root>	<?xml version='1.0' encoding='UTF-8'?><root available-locales="en_US" default-locale="en_US"><Description language-id="en_US">Online Training</Description></root>
5efcc57d-e4b1-4e89-bd9b-65bebd721b42	10312	10195	10155	10159		2017-03-10 17:06:03.083	2017-03-10 17:06:03.083	SALES PRESENTATION	<?xml version='1.0' encoding='UTF-8'?><root available-locales="en_US" default-locale="en_US"><Name language-id="en_US">Sales Presentation</Name></root>	<?xml version='1.0' encoding='UTF-8'?><root available-locales="en_US" default-locale="en_US"><Description language-id="en_US">Sales Presentation</Description></root>
\.


--
-- Data for Name: dlfileentrytypes_ddmstructures; Type: TABLE DATA; Schema: public; Owner: root
--

COPY dlfileentrytypes_ddmstructures (structureid, fileentrytypeid) FROM stdin;
10307	10306
10304	10308
10309	10308
10303	10310
10311	10310
10305	10312
10313	10312
\.


--
-- Data for Name: dlfileentrytypes_dlfolders; Type: TABLE DATA; Schema: public; Owner: root
--

COPY dlfileentrytypes_dlfolders (fileentrytypeid, folderid) FROM stdin;
\.


--
-- Data for Name: dlfilerank; Type: TABLE DATA; Schema: public; Owner: root
--

COPY dlfilerank (filerankid, groupid, companyid, userid, createdate, fileentryid, active_) FROM stdin;
\.


--
-- Data for Name: dlfileshortcut; Type: TABLE DATA; Schema: public; Owner: root
--

COPY dlfileshortcut (uuid_, fileshortcutid, groupid, companyid, userid, username, createdate, modifieddate, repositoryid, folderid, tofileentryid, treepath, active_, status, statusbyuserid, statusbyusername, statusdate) FROM stdin;
\.


--
-- Data for Name: dlfileversion; Type: TABLE DATA; Schema: public; Owner: root
--

COPY dlfileversion (uuid_, fileversionid, groupid, companyid, userid, username, createdate, modifieddate, repositoryid, folderid, fileentryid, treepath, extension, mimetype, title, description, changelog, extrasettings, fileentrytypeid, version, size_, checksum, status, statusbyuserid, statusbyusername, statusdate) FROM stdin;
\.


--
-- Data for Name: dlfolder; Type: TABLE DATA; Schema: public; Owner: root
--

COPY dlfolder (uuid_, folderid, groupid, companyid, userid, username, createdate, modifieddate, repositoryid, mountpoint, parentfolderid, treepath, name, description, lastpostdate, defaultfileentrytypeid, hidden_, overridefileentrytypes, status, statusbyuserid, statusbyusername, statusdate) FROM stdin;
\.


--
-- Data for Name: dlsyncevent; Type: TABLE DATA; Schema: public; Owner: root
--

COPY dlsyncevent (synceventid, modifiedtime, event, type_, typepk) FROM stdin;
\.


--
-- Data for Name: emailaddress; Type: TABLE DATA; Schema: public; Owner: root
--

COPY emailaddress (uuid_, emailaddressid, companyid, userid, username, createdate, modifieddate, classnameid, classpk, address, typeid, primary_) FROM stdin;
\.


--
-- Data for Name: expandocolumn; Type: TABLE DATA; Schema: public; Owner: root
--

COPY expandocolumn (columnid, companyid, tableid, name, type_, defaultdata, typesettings) FROM stdin;
10438	10155	10437	clientId	15		
\.


--
-- Data for Name: expandorow; Type: TABLE DATA; Schema: public; Owner: root
--

COPY expandorow (rowid_, companyid, modifieddate, tableid, classpk) FROM stdin;
\.


--
-- Data for Name: expandotable; Type: TABLE DATA; Schema: public; Owner: root
--

COPY expandotable (tableid, companyid, classnameid, name) FROM stdin;
10437	10155	10005	MP
\.


--
-- Data for Name: expandovalue; Type: TABLE DATA; Schema: public; Owner: root
--

COPY expandovalue (valueid, companyid, tableid, columnid, rowid_, classnameid, classpk, data_) FROM stdin;
\.


--
-- Data for Name: group_; Type: TABLE DATA; Schema: public; Owner: root
--

COPY group_ (uuid_, groupid, companyid, creatoruserid, classnameid, classpk, parentgroupid, livegroupid, treepath, name, description, type_, typesettings, manualmembership, membershiprestriction, friendlyurl, site, remotestaginggroupcount, active_) FROM stdin;
610b2caf-4317-4c7d-b6a7-8328db1d1281	10173	10155	10159	10001	10173	0	0	/10173/	Control Panel		3		t	0	/control_panel	f	0	t
17e1158b-942c-42e1-811a-c4899c2c77ea	10182	10155	10159	10001	10182	0	0	/10182/	Guest		1		t	0	/guest	t	0	t
235925a1-81d3-4406-b11f-24a15f8c4d3f	10192	10155	10159	10191	10159	0	0	/10192/	User Personal Site		3		t	0	/personal_site	f	0	t
4f1007d4-a871-46e4-91ae-45555e834cb5	10195	10155	10159	10025	10155	0	0	/10195/	10155		0		t	0	/global	t	0	t
1cf0610e-ac55-4d3d-a2f2-6f3503ecd2a4	10201	10155	10199	10005	10199	0	0	/10201/	10199		0		t	0	/test	f	0	t
86d59515-5194-456d-bb24-c7133e0f3796	10317	10155	10159	10032	10316	0	0	/10317/	10316		0		t	0	/template-10316	f	0	t
9f448c11-77ff-4392-b4c6-5c6d6a022885	10329	10155	10159	10032	10328	0	0	/10329/	10328		0		t	0	/template-10328	f	0	t
a56f47c7-23fc-41cb-879a-1382292dbd31	10339	10155	10159	10032	10338	0	0	/10339/	10338		0		t	0	/template-10338	f	0	t
218f6398-a2bd-4268-a2c1-fa2792f6e753	10350	10155	10159	10036	10349	0	0	/10350/	10349		0		t	0	/template-10349	f	0	t
04bb07a3-5cf7-4433-9948-11635b5116e7	10376	10155	10159	10036	10375	0	0	/10376/	10375		0		t	0	/template-10375	f	0	t
58cdfa3d-715f-457c-b19c-350bfdfb9765	10463	10155	10199	10001	10463	0	10457	/10463/	Staging Site (Staging)		1		t	0	/staging-site-staging	f	0	t
5791286a-f4f0-46d5-bf86-2b5c6c4af6bd	10457	10155	10199	10001	10457	0	0	/10457/	Staging Site		1	branchingPrivate=false\nbranchingPublic=false\nbreadcrumbShowParentGroups=true\ncontentSharingWithChildrenEnabled=-1\ndirectoryIndexingEnabled=false\ninheritLocales=true\nlanguageId=en_US\nlocales=ca_ES,zh_CN,en_US,fi_FI,fr_FR,de_DE,iw_IL,hu_HU,ja_JP,pt_BR,es_ES\nstaged=true\nstaged-portlet_15=true\nstaged-portlet_161=true\nstaged-portlet_167=true\nstaged-portlet_178=true\nstaged-portlet_183=true\nstaged-portlet_19=true\nstaged-portlet_20=true\nstaged-portlet_25=true\nstaged-portlet_28=true\nstaged-portlet_36=true\nstagedRemotely=false\ntrashEnabled=true\n	t	0	/staging-site	t	0	t
\.


--
-- Data for Name: groups_orgs; Type: TABLE DATA; Schema: public; Owner: root
--

COPY groups_orgs (groupid, organizationid) FROM stdin;
\.


--
-- Data for Name: groups_roles; Type: TABLE DATA; Schema: public; Owner: root
--

COPY groups_roles (groupid, roleid) FROM stdin;
\.


--
-- Data for Name: groups_usergroups; Type: TABLE DATA; Schema: public; Owner: root
--

COPY groups_usergroups (groupid, usergroupid) FROM stdin;
\.


--
-- Data for Name: image; Type: TABLE DATA; Schema: public; Owner: root
--

COPY image (imageid, modifieddate, type_, height, width, size_) FROM stdin;
\.


--
-- Data for Name: journalarticle; Type: TABLE DATA; Schema: public; Owner: root
--

COPY journalarticle (uuid_, id_, resourceprimkey, groupid, companyid, userid, username, createdate, modifieddate, folderid, classnameid, classpk, treepath, articleid, version, title, urltitle, description, content, type_, structureid, templateid, layoutuuid, displaydate, expirationdate, reviewdate, indexable, smallimage, smallimageid, smallimageurl, status, statusbyuserid, statusbyusername, statusdate) FROM stdin;
317b9a26-26fc-4a9c-9f8b-2028dbe6a231	10498	10499	10463	10155	10199	Test Test	2017-03-10 17:08:51.774	2017-03-10 17:08:51.774	0	0	0	/0/	10497	1	<?xml version='1.0' encoding='UTF-8'?><root available-locales="en_US" default-locale="en_US"><Title language-id="en_US">Web Content Title</Title></root>	web-content-title		<?xml version="1.0"?>\n\n<root available-locales="en_US" default-locale="en_US">\n\t<static-content language-id="en_US"><![CDATA[Web Content Content]]></static-content>\n</root>	general				2017-03-10 17:08:00	\N	\N	t	f	10500		0	10199	Test Test	2017-03-10 17:08:51.999
\.


--
-- Data for Name: journalarticleimage; Type: TABLE DATA; Schema: public; Owner: root
--

COPY journalarticleimage (articleimageid, groupid, articleid, version, elinstanceid, elname, languageid, tempimage) FROM stdin;
\.


--
-- Data for Name: journalarticleresource; Type: TABLE DATA; Schema: public; Owner: root
--

COPY journalarticleresource (uuid_, resourceprimkey, groupid, articleid) FROM stdin;
7d19640a-5caf-4298-a32d-c15bec4d4aa3	10499	10463	10497
\.


--
-- Data for Name: journalcontentsearch; Type: TABLE DATA; Schema: public; Owner: root
--

COPY journalcontentsearch (contentsearchid, groupid, companyid, privatelayout, layoutid, portletid, articleid) FROM stdin;
10507	10463	10155	f	1	56_INSTANCE_3cRWP9EaUgFZ	10497
\.


--
-- Data for Name: journalfeed; Type: TABLE DATA; Schema: public; Owner: root
--

COPY journalfeed (uuid_, id_, groupid, companyid, userid, username, createdate, modifieddate, feedid, name, description, type_, structureid, templateid, renderertemplateid, delta, orderbycol, orderbytype, targetlayoutfriendlyurl, targetportletid, contentfield, feedformat, feedversion) FROM stdin;
\.


--
-- Data for Name: journalfolder; Type: TABLE DATA; Schema: public; Owner: root
--

COPY journalfolder (uuid_, folderid, groupid, companyid, userid, username, createdate, modifieddate, parentfolderid, treepath, name, description, status, statusbyuserid, statusbyusername, statusdate) FROM stdin;
\.


--
-- Data for Name: layout; Type: TABLE DATA; Schema: public; Owner: root
--

COPY layout (uuid_, plid, groupid, companyid, userid, username, createdate, modifieddate, privatelayout, layoutid, parentlayoutid, name, title, description, keywords, robots, type_, typesettings, hidden_, friendlyurl, iconimage, iconimageid, themeid, colorschemeid, wapthemeid, wapcolorschemeid, css, priority, layoutprototypeuuid, layoutprototypelinkenabled, sourceprototypelayoutuuid) FROM stdin;
b3944b46-6631-41b3-adca-8450d5c36d5b	10176	10173	10155	10159		2017-03-10 17:05:59.996	2017-03-10 17:05:59.996	t	1	0	<?xml version='1.0' encoding='UTF-8'?><root available-locales="en_US" default-locale="en_US"><Name language-id="en_US">Control Panel</Name></root>					control_panel	privateLayout=true\n	f	/manage	f	0						0		f	
f54f707e-219b-438a-b8ed-35e43efd4f63	10185	10182	10155	10159		2017-03-10 17:06:00.481	2017-03-10 17:06:00.651	f	1	0	<?xml version='1.0' encoding='UTF-8'?><root available-locales="en_US" default-locale="en_US"><Name language-id="en_US">Welcome</Name></root>					portlet	column-1=58,\ncolumn-2=47,\nlayout-template-id=2_columns_ii\n	f	/home	f	0						0		f	
af0630e5-e2b4-47b3-b2dd-cd5e48d20e06	10387	10376	10155	10159		2017-03-10 17:06:04.503	2017-03-10 17:06:04.627	t	1	0	<?xml version='1.0' encoding='UTF-8'?><root available-locales="en_US" default-locale="en_US"><Name language-id="en_US">Home</Name></root>					portlet	column-1=116,\ncolumn-2=3,82,101_INSTANCE_vFnyKp8y2c1s,\nlayout-template-id=2_columns_i\nprivateLayout=true\n	f	/home	f	0						0		f	
4fa604b5-0b0a-4840-a554-c328b0022227	10342	10339	10155	10159		2017-03-10 17:06:03.53	2017-03-10 17:06:03.619	t	1	0	<?xml version='1.0' encoding='UTF-8'?><root available-locales="en_US" default-locale="en_US"><Name language-id="en_US">Wiki</Name></root>					portlet	column-1=36,\ncolumn-2=122_INSTANCE_CxUYlFyV5tlM,141_INSTANCE_gcpHExQ03245,\nlayout-template-id=2_columns_iii\nprivateLayout=true\n	f	/layout	f	0						0		f	
715587b1-2ce5-43ee-a9ec-881b2d504d04	10320	10317	10155	10159		2017-03-10 17:06:03.208	2017-03-10 17:06:03.358	t	1	0	<?xml version='1.0' encoding='UTF-8'?><root available-locales="en_US" default-locale="en_US"><Name language-id="en_US">Blog</Name></root>					portlet	column-1=33,\ncolumn-2=148_INSTANCE_YN1AXKW93IjQ,114,\nlayout-template-id=2_columns_iii\nprivateLayout=true\n	f	/layout	f	0						0		f	
1bd38de4-538d-41e3-b0ca-f9871f397799	10369	10350	10155	10159		2017-03-10 17:06:04.252	2017-03-10 17:06:04.375	t	2	0	<?xml version='1.0' encoding='UTF-8'?><root available-locales="en_US" default-locale="en_US"><Name language-id="en_US">Wiki</Name></root>					portlet	column-1=36,\ncolumn-2=122_INSTANCE_YSgYD5s7AQ2H,148_INSTANCE_Vru4zWak80M1,\nlayout-template-id=2_columns_iii\nprivateLayout=true\n	f	/wiki	f	0						1		f	
8bb0732e-1c78-4649-a6f2-877ed4676846	10332	10329	10155	10159		2017-03-10 17:06:03.408	2017-03-10 17:06:03.51	t	1	0	<?xml version='1.0' encoding='UTF-8'?><root available-locales="en_US" default-locale="en_US"><Name language-id="en_US">Content Display Page</Name></root>					portlet	column-1=141_INSTANCE_LHWkhaysyiQZ,122_INSTANCE_ll52r9DzS2of,\ncolumn-2=3,101_INSTANCE_oJezYMau57VX,\ndefault-asset-publisher-portlet-id=101_INSTANCE_oJezYMau57VX\nlayout-template-id=2_columns_ii\nprivateLayout=true\n	f	/layout	f	0						0		f	
0ebc7a45-8053-46f6-a73e-137b46ba7610	10404	10376	10155	10159		2017-03-10 17:06:04.735	2017-03-10 17:06:04.821	t	3	0	<?xml version='1.0' encoding='UTF-8'?><root available-locales="en_US" default-locale="en_US"><Name language-id="en_US">News</Name></root>					portlet	column-1=39_INSTANCE_7BYN7TjEczmb,\ncolumn-2=39_INSTANCE_HtH4nWYKCyoo,\nlayout-template-id=2_columns_iii\nprivateLayout=true\n	f	/news	f	0						2		f	
dc9bf0c8-28f7-4777-b920-4f2a40392d23	10361	10350	10155	10159		2017-03-10 17:06:03.982	2017-03-10 17:06:04.237	t	1	0	<?xml version='1.0' encoding='UTF-8'?><root available-locales="en_US" default-locale="en_US"><Name language-id="en_US">Home</Name></root>					portlet	column-1=19,\ncolumn-2=3,59_INSTANCE_0WaGT5hPwAyy,180,101_INSTANCE_P3cvEkiij2gk,\nlayout-template-id=2_columns_iii\nprivateLayout=true\n	f	/home	f	0						0		f	
2e0827d1-f844-4d78-8df7-04d4050e6207	10396	10376	10155	10159		2017-03-10 17:06:04.638	2017-03-10 17:06:04.724	t	2	0	<?xml version='1.0' encoding='UTF-8'?><root available-locales="en_US" default-locale="en_US"><Name language-id="en_US">Documents and Media</Name></root>					portlet	column-1=20,\ncolumn-2=101_INSTANCE_dbhPcVMLCCcm,\nlayout-template-id=1_column\nprivateLayout=true\n	f	/documents	f	0						1		f	
4f161f0d-6294-4858-839b-31c990a3eccc	10441	10201	10155	10199	Test Test	2017-03-10 17:06:55.048	2017-03-10 17:06:55.113	t	1	0	<?xml version='1.0' encoding='UTF-8'?><root available-locales="en_US" default-locale="en_US"><Name language-id="en_US">Welcome</Name></root>					portlet	column-1=82,23,11,\ncolumn-2=29,\nlayout-template-id=2_columns_ii\nprivateLayout=true\n	f	/home	f	0						0		f	
9105ef9d-2fc3-4bfd-b618-3e991895e4b2	10447	10201	10155	10199	Test Test	2017-03-10 17:06:55.122	2017-03-10 17:06:55.156	f	1	0	<?xml version='1.0' encoding='UTF-8'?><root available-locales="en_US" default-locale="en_US"><Name language-id="en_US">Welcome</Name></root>					portlet	column-1=82,3,\ncolumn-2=33,\nlayout-template-id=2_columns_ii\n	f	/home	f	0						0		f	
94bcdfac-879b-4678-926a-ff1f3da0eb7a	10488	10463	10155	10199	Test Test	2017-03-10 17:08:17.13	2017-03-10 17:08:52.065	f	1	0	<?xml version='1.0' encoding='UTF-8'?><root available-locales="en_US" default-locale="en_US"><Name language-id="en_US">Staging Site Page</Name></root>					portlet	column-1=56_INSTANCE_3cRWP9EaUgFZ\nlayout-template-id=2_columns_ii\n	f	/staging-site-page	f	0						0		f	
\.


--
-- Data for Name: layoutbranch; Type: TABLE DATA; Schema: public; Owner: root
--

COPY layoutbranch (layoutbranchid, groupid, companyid, userid, username, layoutsetbranchid, plid, name, description, master) FROM stdin;
\.


--
-- Data for Name: layoutfriendlyurl; Type: TABLE DATA; Schema: public; Owner: root
--

COPY layoutfriendlyurl (uuid_, layoutfriendlyurlid, groupid, companyid, userid, username, createdate, modifieddate, plid, privatelayout, friendlyurl, languageid) FROM stdin;
7c5a8f4d-f906-4b6e-900d-2fa17dbb03cb	10177	10173	10155	10159		2017-03-10 17:06:00.065	2017-03-10 17:06:00.065	10176	t	/manage	en_US
632cd764-8f94-4aa0-985c-29eec2f4e28d	10186	10182	10155	10159		2017-03-10 17:06:00.526	2017-03-10 17:06:00.526	10185	f	/home	en_US
77d32277-68fc-4aac-a95c-b3075500ee03	10321	10317	10155	10159		2017-03-10 17:06:03.218	2017-03-10 17:06:03.218	10320	t	/layout	en_US
22e706cc-c811-49be-a75d-73064f78c85d	10333	10329	10155	10159		2017-03-10 17:06:03.419	2017-03-10 17:06:03.419	10332	t	/layout	en_US
1aad8048-2fab-488e-8e20-8148fffb27ab	10343	10339	10155	10159		2017-03-10 17:06:03.538	2017-03-10 17:06:03.538	10342	t	/layout	en_US
325ca799-abf8-4dd6-8c4b-f847ba952119	10362	10350	10155	10159		2017-03-10 17:06:03.995	2017-03-10 17:06:03.995	10361	t	/home	en_US
f2dc5677-4982-4124-87b9-fc7170e7f86a	10370	10350	10155	10159		2017-03-10 17:06:04.265	2017-03-10 17:06:04.265	10369	t	/wiki	en_US
7d0e6efc-fa9e-4564-a084-be0b1b7b6550	10388	10376	10155	10159		2017-03-10 17:06:04.512	2017-03-10 17:06:04.512	10387	t	/home	en_US
a16e64db-7cc2-4e93-bcf0-8707f0db188e	10397	10376	10155	10159		2017-03-10 17:06:04.647	2017-03-10 17:06:04.647	10396	t	/documents	en_US
6c16ef64-be56-491f-aa86-a72c11c1b0ca	10405	10376	10155	10159		2017-03-10 17:06:04.743	2017-03-10 17:06:04.743	10404	t	/news	en_US
f1332a2b-de27-46c2-b93b-37193f54a29c	10442	10201	10155	10199	Test Test	2017-03-10 17:06:55.053	2017-03-10 17:06:55.053	10441	t	/home	en_US
0d50a8b6-c19c-47d4-ba35-092b3194522d	10448	10201	10155	10199	Test Test	2017-03-10 17:06:55.128	2017-03-10 17:06:55.128	10447	f	/home	en_US
3bf3c1cb-4cbf-43e5-b566-b0350379262b	10489	10463	10155	10199	Test Test	2017-03-10 17:08:17.141	2017-03-10 17:08:17.141	10488	f	/staging-site-page	en_US
\.


--
-- Data for Name: layoutprototype; Type: TABLE DATA; Schema: public; Owner: root
--

COPY layoutprototype (uuid_, layoutprototypeid, companyid, userid, username, createdate, modifieddate, name, description, settings_, active_) FROM stdin;
0b331a23-a45e-4556-a481-5b0207e63c10	10316	10155	10159		2017-03-10 17:06:03.18	2017-03-10 17:06:03.18	<?xml version='1.0' encoding='UTF-8'?><root available-locales="en_US" default-locale="en_US"><Name language-id="en_US">Blog</Name></root>	Create, edit, and view blogs from this page. Explore topics using tags, and connect with other members that blog.		t
537a46f5-de8f-451f-89f5-1a89ba2bd895	10328	10155	10159		2017-03-10 17:06:03.392	2017-03-10 17:06:03.392	<?xml version='1.0' encoding='UTF-8'?><root available-locales="en_US" default-locale="en_US"><Name language-id="en_US">Content Display Page</Name></root>	Create, edit, and explore web content with this page. Search available content, explore related content with tags, and browse content categories.		t
c8ef8d85-f2c7-43c4-8643-fb55bd54f9cb	10338	10155	10159		2017-03-10 17:06:03.514	2017-03-10 17:06:03.514	<?xml version='1.0' encoding='UTF-8'?><root available-locales="en_US" default-locale="en_US"><Name language-id="en_US">Wiki</Name></root>	Collaborate with members through the wiki on this page. Discover related content through tags, and navigate quickly and easily with categories.		t
\.


--
-- Data for Name: layoutrevision; Type: TABLE DATA; Schema: public; Owner: root
--

COPY layoutrevision (layoutrevisionid, groupid, companyid, userid, username, createdate, modifieddate, layoutsetbranchid, layoutbranchid, parentlayoutrevisionid, head, major, plid, privatelayout, name, title, description, keywords, robots, typesettings, iconimage, iconimageid, themeid, colorschemeid, wapthemeid, wapcolorschemeid, css, status, statusbyuserid, statusbyusername, statusdate) FROM stdin;
\.


--
-- Data for Name: layoutset; Type: TABLE DATA; Schema: public; Owner: root
--

COPY layoutset (layoutsetid, groupid, companyid, createdate, modifieddate, privatelayout, logo, logoid, themeid, colorschemeid, wapthemeid, wapcolorschemeid, css, pagecount, settings_, layoutsetprototypeuuid, layoutsetprototypelinkenabled) FROM stdin;
10175	10173	10155	2017-03-10 17:05:59.951	2017-03-10 17:05:59.951	f	f	0	classic	01	mobile	01		0			f
10174	10173	10155	2017-03-10 17:05:59.935	2017-03-10 17:06:00.114	t	f	0	classic	01	mobile	01		1			f
10183	10182	10155	2017-03-10 17:06:00.434	2017-03-10 17:06:00.434	t	f	0	classic	01	mobile	01		0			f
10184	10182	10155	2017-03-10 17:06:00.436	2017-03-10 17:06:00.578	f	f	0	classic	01	mobile	01		1			f
10193	10192	10155	2017-03-10 17:06:00.664	2017-03-10 17:06:00.664	t	f	0	classic	01	mobile	01		0			f
10194	10192	10155	2017-03-10 17:06:00.665	2017-03-10 17:06:00.665	f	f	0	classic	01	mobile	01		0			f
10196	10195	10155	2017-03-10 17:06:00.737	2017-03-10 17:06:00.737	t	f	0	classic	01	mobile	01		0			f
10197	10195	10155	2017-03-10 17:06:00.739	2017-03-10 17:06:00.739	f	f	0	classic	01	mobile	01		0			f
10319	10317	10155	2017-03-10 17:06:03.201	2017-03-10 17:06:03.201	f	f	0	classic	01	mobile	01		0			f
10318	10317	10155	2017-03-10 17:06:03.2	2017-03-10 17:06:03.222	t	f	0	classic	01	mobile	01		1			f
10331	10329	10155	2017-03-10 17:06:03.399	2017-03-10 17:06:03.399	f	f	0	classic	01	mobile	01		0			f
10330	10329	10155	2017-03-10 17:06:03.398	2017-03-10 17:06:03.424	t	f	0	classic	01	mobile	01		1			f
10341	10339	10155	2017-03-10 17:06:03.522	2017-03-10 17:06:03.522	f	f	0	classic	01	mobile	01		0			f
10340	10339	10155	2017-03-10 17:06:03.52	2017-03-10 17:06:03.543	t	f	0	classic	01	mobile	01		1			f
10352	10350	10155	2017-03-10 17:06:03.651	2017-03-10 17:06:03.651	f	f	0	classic	01	mobile	01		0			f
10377	10376	10155	2017-03-10 17:06:04.397	2017-03-10 17:06:04.821	t	f	0	classic	01	mobile	01		3			f
10202	10201	10155	2017-03-10 17:06:01.098	2017-03-10 17:06:55.059	t	f	0	classic	01	mobile	01		1			f
10203	10201	10155	2017-03-10 17:06:01.1	2017-03-10 17:06:55.133	f	f	0	classic	01	mobile	01		1			f
10458	10457	10155	2017-03-10 17:07:18.088	2017-03-10 17:07:18.088	t	f	0	classic	01	mobile	01		0			f
10459	10457	10155	2017-03-10 17:07:18.089	2017-03-10 17:07:18.089	f	f	0	classic	01	mobile	01		0			f
10464	10463	10155	2017-03-10 17:07:39.354	2017-03-10 17:07:39.354	t	f	0	classic	01	mobile	01		0			f
10465	10463	10155	2017-03-10 17:07:39.356	2017-03-10 17:08:17.147	f	f	0	classic	01	mobile	01		1	last-publish-date=1489165660406\n		f
10351	10350	10155	2017-03-10 17:06:03.647	2017-03-10 17:06:04.375	t	f	0	classic	01	mobile	01		2			f
10378	10376	10155	2017-03-10 17:06:04.398	2017-03-10 17:06:04.398	f	f	0	classic	01	mobile	01		0			f
\.


--
-- Data for Name: layoutsetbranch; Type: TABLE DATA; Schema: public; Owner: root
--

COPY layoutsetbranch (layoutsetbranchid, groupid, companyid, userid, username, createdate, modifieddate, privatelayout, name, description, master, logo, logoid, themeid, colorschemeid, wapthemeid, wapcolorschemeid, css, settings_, layoutsetprototypeuuid, layoutsetprototypelinkenabled) FROM stdin;
\.


--
-- Data for Name: layoutsetprototype; Type: TABLE DATA; Schema: public; Owner: root
--

COPY layoutsetprototype (uuid_, layoutsetprototypeid, companyid, userid, username, createdate, modifieddate, name, description, settings_, active_) FROM stdin;
c3a275d3-f292-41cc-b2ef-953a0ce430ea	10375	10155	10159		2017-03-10 17:06:04.39	2017-03-10 17:06:04.821	<?xml version='1.0' encoding='UTF-8'?><root available-locales="en_US" default-locale="en_US"><Name language-id="en_US">Intranet Site</Name></root>	Site with Documents and News	layoutsUpdateable=true\n	t
2231ce90-ca37-4e85-87c4-33f9c357883b	10349	10155	10159		2017-03-10 17:06:03.634	2017-03-10 17:06:04.375	<?xml version='1.0' encoding='UTF-8'?><root available-locales="en_US" default-locale="en_US"><Name language-id="en_US">Community Site</Name></root>	Site with Forums and Wiki	layoutsUpdateable=true\n	t
\.


--
-- Data for Name: listtype; Type: TABLE DATA; Schema: public; Owner: root
--

COPY listtype (listtypeid, name, type_) FROM stdin;
10000	billing	com.liferay.portal.model.Account.address
10001	other	com.liferay.portal.model.Account.address
10002	p-o-box	com.liferay.portal.model.Account.address
10003	shipping	com.liferay.portal.model.Account.address
10004	email-address	com.liferay.portal.model.Account.emailAddress
10005	email-address-2	com.liferay.portal.model.Account.emailAddress
10006	email-address-3	com.liferay.portal.model.Account.emailAddress
10007	fax	com.liferay.portal.model.Account.phone
10008	local	com.liferay.portal.model.Account.phone
10009	other	com.liferay.portal.model.Account.phone
10010	toll-free	com.liferay.portal.model.Account.phone
10011	tty	com.liferay.portal.model.Account.phone
10012	intranet	com.liferay.portal.model.Account.website
10013	public	com.liferay.portal.model.Account.website
11000	business	com.liferay.portal.model.Contact.address
11001	other	com.liferay.portal.model.Contact.address
11002	personal	com.liferay.portal.model.Contact.address
11003	email-address	com.liferay.portal.model.Contact.emailAddress
11004	email-address-2	com.liferay.portal.model.Contact.emailAddress
11005	email-address-3	com.liferay.portal.model.Contact.emailAddress
11006	business	com.liferay.portal.model.Contact.phone
11007	business-fax	com.liferay.portal.model.Contact.phone
11008	mobile-phone	com.liferay.portal.model.Contact.phone
11009	other	com.liferay.portal.model.Contact.phone
11010	pager	com.liferay.portal.model.Contact.phone
11011	personal	com.liferay.portal.model.Contact.phone
11012	personal-fax	com.liferay.portal.model.Contact.phone
11013	tty	com.liferay.portal.model.Contact.phone
11014	dr	com.liferay.portal.model.Contact.prefix
11015	mr	com.liferay.portal.model.Contact.prefix
11016	mrs	com.liferay.portal.model.Contact.prefix
11017	ms	com.liferay.portal.model.Contact.prefix
11020	ii	com.liferay.portal.model.Contact.suffix
11021	iii	com.liferay.portal.model.Contact.suffix
11022	iv	com.liferay.portal.model.Contact.suffix
11023	jr	com.liferay.portal.model.Contact.suffix
11024	phd	com.liferay.portal.model.Contact.suffix
11025	sr	com.liferay.portal.model.Contact.suffix
11026	blog	com.liferay.portal.model.Contact.website
11027	business	com.liferay.portal.model.Contact.website
11028	other	com.liferay.portal.model.Contact.website
11029	personal	com.liferay.portal.model.Contact.website
12000	billing	com.liferay.portal.model.Organization.address
12001	other	com.liferay.portal.model.Organization.address
12002	p-o-box	com.liferay.portal.model.Organization.address
12003	shipping	com.liferay.portal.model.Organization.address
12004	email-address	com.liferay.portal.model.Organization.emailAddress
12005	email-address-2	com.liferay.portal.model.Organization.emailAddress
12006	email-address-3	com.liferay.portal.model.Organization.emailAddress
12007	fax	com.liferay.portal.model.Organization.phone
12008	local	com.liferay.portal.model.Organization.phone
12009	other	com.liferay.portal.model.Organization.phone
12010	toll-free	com.liferay.portal.model.Organization.phone
12011	tty	com.liferay.portal.model.Organization.phone
12012	administrative	com.liferay.portal.model.Organization.service
12013	contracts	com.liferay.portal.model.Organization.service
12014	donation	com.liferay.portal.model.Organization.service
12015	retail	com.liferay.portal.model.Organization.service
12016	training	com.liferay.portal.model.Organization.service
12017	full-member	com.liferay.portal.model.Organization.status
12018	provisional-member	com.liferay.portal.model.Organization.status
12019	intranet	com.liferay.portal.model.Organization.website
12020	public	com.liferay.portal.model.Organization.website
\.


--
-- Data for Name: lock_; Type: TABLE DATA; Schema: public; Owner: root
--

COPY lock_ (uuid_, lockid, companyid, userid, username, createdate, classname, key_, owner, inheritable, expirationdate) FROM stdin;
\.


--
-- Data for Name: marketplace_app; Type: TABLE DATA; Schema: public; Owner: root
--

COPY marketplace_app (uuid_, appid, companyid, userid, username, createdate, modifieddate, remoteappid, title, description, category, iconurl, version) FROM stdin;
\.


--
-- Data for Name: marketplace_module; Type: TABLE DATA; Schema: public; Owner: root
--

COPY marketplace_module (uuid_, moduleid, appid, bundlesymbolicname, bundleversion, contextname) FROM stdin;
\.


--
-- Data for Name: mbban; Type: TABLE DATA; Schema: public; Owner: root
--

COPY mbban (uuid_, banid, groupid, companyid, userid, username, createdate, modifieddate, banuserid) FROM stdin;
\.


--
-- Data for Name: mbcategory; Type: TABLE DATA; Schema: public; Owner: root
--

COPY mbcategory (uuid_, categoryid, groupid, companyid, userid, username, createdate, modifieddate, parentcategoryid, name, description, displaystyle, threadcount, messagecount, lastpostdate, status, statusbyuserid, statusbyusername, statusdate) FROM stdin;
\.


--
-- Data for Name: mbdiscussion; Type: TABLE DATA; Schema: public; Owner: root
--

COPY mbdiscussion (uuid_, discussionid, groupid, companyid, userid, username, createdate, modifieddate, classnameid, classpk, threadid) FROM stdin;
55ba421a-6e3c-4c33-a33c-f9f94078c978	10181	0	0	10159		2017-03-10 17:06:00.391	2017-03-10 17:06:00.391	10002	10176	10179
bbd31f78-cead-4a10-86de-79fb7b5913c9	10190	0	0	10159		2017-03-10 17:06:00.604	2017-03-10 17:06:00.604	10002	10185	10188
281030c0-98e8-4f09-905f-8c0b985c1d5b	10326	0	0	10159		2017-03-10 17:06:03.268	2017-03-10 17:06:03.268	10002	10320	10323
f624ac99-b86d-43cf-a386-3841bcd01aae	10337	0	0	10159		2017-03-10 17:06:03.441	2017-03-10 17:06:03.441	10002	10332	10335
0e4aebd0-256f-4841-bf01-7146fc5d6398	10347	0	0	10159		2017-03-10 17:06:03.553	2017-03-10 17:06:03.553	10002	10342	10345
ef2309a2-d688-4aba-a857-5d5a6a576941	10366	0	0	10159		2017-03-10 17:06:04.014	2017-03-10 17:06:04.014	10002	10361	10364
40771c91-99e7-4b52-aa1b-6d01c126615a	10374	0	0	10159		2017-03-10 17:06:04.288	2017-03-10 17:06:04.288	10002	10369	10372
0c4781e9-bf38-43ee-b295-7f2f3767479b	10392	0	0	10159		2017-03-10 17:06:04.527	2017-03-10 17:06:04.527	10002	10387	10390
d93dea83-2fee-48f0-8be4-160b1a8d1a5a	10401	0	0	10159		2017-03-10 17:06:04.661	2017-03-10 17:06:04.661	10002	10396	10399
737a2738-6a4c-476f-ae1b-3076d32d7e2b	10409	0	0	10159		2017-03-10 17:06:04.756	2017-03-10 17:06:04.756	10002	10404	10407
5d52c79a-db3e-496b-b717-4ab722a6221f	10446	0	0	10199	Test Test	2017-03-10 17:06:55.1	2017-03-10 17:06:55.1	10002	10441	10444
5c7961e1-5df4-4a86-8c31-f583e5e0bab4	10452	0	0	10199	Test Test	2017-03-10 17:06:55.143	2017-03-10 17:06:55.143	10002	10447	10450
3f179ede-974f-4cc0-a3d7-588293ba34df	10493	0	0	10199	Test Test	2017-03-10 17:08:17.17	2017-03-10 17:08:17.17	10002	10488	10491
deda5af3-1609-47ea-9d8b-fa32f585be51	10506	0	0	10199	Test Test	2017-03-10 17:08:51.997	2017-03-10 17:08:51.997	10109	10499	10504
\.


--
-- Data for Name: mbmailinglist; Type: TABLE DATA; Schema: public; Owner: root
--

COPY mbmailinglist (uuid_, mailinglistid, groupid, companyid, userid, username, createdate, modifieddate, categoryid, emailaddress, inprotocol, inservername, inserverport, inusessl, inusername, inpassword, inreadinterval, outemailaddress, outcustom, outservername, outserverport, outusessl, outusername, outpassword, allowanonymous, active_) FROM stdin;
\.


--
-- Data for Name: mbmessage; Type: TABLE DATA; Schema: public; Owner: root
--

COPY mbmessage (uuid_, messageid, groupid, companyid, userid, username, createdate, modifieddate, classnameid, classpk, categoryid, threadid, rootmessageid, parentmessageid, subject, body, format, anonymous, priority, allowpingbacks, answer, status, statusbyuserid, statusbyusername, statusdate) FROM stdin;
70ab8045-d203-46bc-aec9-80c25244c77e	10178	10173	10155	10159		2017-03-10 17:06:00.125	2017-03-10 17:06:00.125	10002	10176	-1	10179	10178	0	10176	10176	bbcode	t	0	f	f	0	10159		2017-03-10 17:06:00.256
3176cffe-8f06-493d-aa7a-3e49713e3fe6	10187	10182	10155	10159		2017-03-10 17:06:00.581	2017-03-10 17:06:00.581	10002	10185	-1	10188	10187	0	10185	10185	bbcode	t	0	f	f	0	10159		2017-03-10 17:06:00.589
903ca121-d7d2-4d38-b431-9f0bc5b56893	10322	10317	10155	10159		2017-03-10 17:06:03.223	2017-03-10 17:06:03.223	10002	10320	-1	10323	10322	0	10320	10320	bbcode	t	0	f	f	0	10159		2017-03-10 17:06:03.257
eaf52c89-f2a7-447e-ab30-8cc7fdabbebb	10334	10329	10155	10159		2017-03-10 17:06:03.425	2017-03-10 17:06:03.425	10002	10332	-1	10335	10334	0	10332	10332	bbcode	t	0	f	f	0	10159		2017-03-10 17:06:03.43
e39d9bd0-b8f7-4e06-87a9-a56db2114a04	10344	10339	10155	10159		2017-03-10 17:06:03.544	2017-03-10 17:06:03.544	10002	10342	-1	10345	10344	0	10342	10342	bbcode	t	0	f	f	0	10159		2017-03-10 17:06:03.546
8abd4560-2d9c-4702-9d01-efe9aaca2956	10363	10350	10155	10159		2017-03-10 17:06:04.004	2017-03-10 17:06:04.004	10002	10361	-1	10364	10363	0	10361	10361	bbcode	t	0	f	f	0	10159		2017-03-10 17:06:04.006
96bdea03-14c6-45d8-adda-572f68d47638	10371	10350	10155	10159		2017-03-10 17:06:04.274	2017-03-10 17:06:04.274	10002	10369	-1	10372	10371	0	10369	10369	bbcode	t	0	f	f	0	10159		2017-03-10 17:06:04.278
f105264c-e630-482a-aa5c-6e0e594e6436	10389	10376	10155	10159		2017-03-10 17:06:04.518	2017-03-10 17:06:04.518	10002	10387	-1	10390	10389	0	10387	10387	bbcode	t	0	f	f	0	10159		2017-03-10 17:06:04.52
a7870874-7e45-4e37-963a-9db59ce7aef3	10398	10376	10155	10159		2017-03-10 17:06:04.652	2017-03-10 17:06:04.652	10002	10396	-1	10399	10398	0	10396	10396	bbcode	t	0	f	f	0	10159		2017-03-10 17:06:04.655
2ed2f031-2968-4d08-a567-98b65c8c9dd1	10406	10376	10155	10159		2017-03-10 17:06:04.748	2017-03-10 17:06:04.748	10002	10404	-1	10407	10406	0	10404	10404	bbcode	t	0	f	f	0	10159		2017-03-10 17:06:04.75
d62caa73-a51b-43d7-b115-0b81d3b7890e	10443	10201	10155	10199	Test Test	2017-03-10 17:06:55.061	2017-03-10 17:06:55.061	10002	10441	-1	10444	10443	0	10441	10441	bbcode	f	0	f	f	0	10199	Test Test	2017-03-10 17:06:55.064
31048e36-1a71-498e-9662-c6b122d3fe88	10449	10201	10155	10199	Test Test	2017-03-10 17:06:55.135	2017-03-10 17:06:55.135	10002	10447	-1	10450	10449	0	10447	10447	bbcode	f	0	f	f	0	10199	Test Test	2017-03-10 17:06:55.137
23060d18-5dc8-4446-ac41-4e7057f4854f	10490	10463	10155	10199	Test Test	2017-03-10 17:08:17.149	2017-03-10 17:08:17.149	10002	10488	-1	10491	10490	0	10488	10488	bbcode	f	0	f	f	0	10199	Test Test	2017-03-10 17:08:17.155
d62b9dc2-7a28-4734-af0d-1e070161d0e0	10503	10463	10155	10199	Test Test	2017-03-10 17:08:51.986	2017-03-10 17:08:51.986	10109	10499	-1	10504	10503	0	10499	10499	bbcode	f	0	f	f	0	10199	Test Test	2017-03-10 17:08:51.991
\.


--
-- Data for Name: mbstatsuser; Type: TABLE DATA; Schema: public; Owner: root
--

COPY mbstatsuser (statsuserid, groupid, userid, messagecount, lastpostdate) FROM stdin;
\.


--
-- Data for Name: mbthread; Type: TABLE DATA; Schema: public; Owner: root
--

COPY mbthread (uuid_, threadid, groupid, companyid, userid, username, createdate, modifieddate, categoryid, rootmessageid, rootmessageuserid, messagecount, viewcount, lastpostbyuserid, lastpostdate, priority, question, status, statusbyuserid, statusbyusername, statusdate) FROM stdin;
2e053150-9530-493b-9621-032facd72e0c	10179	10173	10155	10159		2017-03-10 17:06:00.127	2017-03-10 17:06:00.256	-1	10178	10159	1	0	0	2017-03-10 17:06:00.256	0	f	0	10159		2017-03-10 17:06:00.256
6e74e28c-487b-4745-94ef-19210643c82e	10188	10182	10155	10159		2017-03-10 17:06:00.582	2017-03-10 17:06:00.589	-1	10187	10159	1	0	0	2017-03-10 17:06:00.589	0	f	0	10159		2017-03-10 17:06:00.589
73bac497-aedf-423b-b2b8-d355d370c674	10323	10317	10155	10159		2017-03-10 17:06:03.223	2017-03-10 17:06:03.257	-1	10322	10159	1	0	0	2017-03-10 17:06:03.257	0	f	0	10159		2017-03-10 17:06:03.257
ffd7e009-967b-4b51-b337-07956c192583	10335	10329	10155	10159		2017-03-10 17:06:03.425	2017-03-10 17:06:03.43	-1	10334	10159	1	0	0	2017-03-10 17:06:03.43	0	f	0	10159		2017-03-10 17:06:03.43
506187c8-ee17-400c-a8ef-eb3f28e6e915	10345	10339	10155	10159		2017-03-10 17:06:03.544	2017-03-10 17:06:03.546	-1	10344	10159	1	0	0	2017-03-10 17:06:03.546	0	f	0	10159		2017-03-10 17:06:03.546
186a3e90-9ce8-48d4-91e5-e4af21bde5a4	10407	10376	10155	10159		2017-03-10 17:06:04.748	2017-03-10 17:06:04.75	-1	10406	10159	1	0	0	2017-03-10 17:06:04.75	0	f	0	10159		2017-03-10 17:06:04.75
5f805f9c-a743-461d-8a30-7837710e3f38	10364	10350	10155	10159		2017-03-10 17:06:04.004	2017-03-10 17:06:04.006	-1	10363	10159	1	0	0	2017-03-10 17:06:04.006	0	f	0	10159		2017-03-10 17:06:04.006
a310fb6e-8d3a-4ea4-bc2f-5acd45a0b883	10372	10350	10155	10159		2017-03-10 17:06:04.274	2017-03-10 17:06:04.278	-1	10371	10159	1	0	0	2017-03-10 17:06:04.278	0	f	0	10159		2017-03-10 17:06:04.278
8c665fc5-5b6a-4a1c-aadd-0768963a27bb	10390	10376	10155	10159		2017-03-10 17:06:04.518	2017-03-10 17:06:04.52	-1	10389	10159	1	0	0	2017-03-10 17:06:04.52	0	f	0	10159		2017-03-10 17:06:04.52
58c0cc6f-84c9-4f5f-a624-3e6142acf266	10399	10376	10155	10159		2017-03-10 17:06:04.652	2017-03-10 17:06:04.655	-1	10398	10159	1	0	0	2017-03-10 17:06:04.655	0	f	0	10159		2017-03-10 17:06:04.655
a2df3982-1823-4a94-8d47-d679efc7e231	10444	10201	10155	10199	Test Test	2017-03-10 17:06:55.062	2017-03-10 17:06:55.064	-1	10443	10199	1	0	10199	2017-03-10 17:06:55.064	0	f	0	10199	Test Test	2017-03-10 17:06:55.064
c996b20b-a8eb-4635-9444-5cdc34d2ca0c	10450	10201	10155	10199	Test Test	2017-03-10 17:06:55.135	2017-03-10 17:06:55.137	-1	10449	10199	1	0	10199	2017-03-10 17:06:55.137	0	f	0	10199	Test Test	2017-03-10 17:06:55.137
ae8cf714-2571-4839-8a86-509408a15599	10491	10463	10155	10199	Test Test	2017-03-10 17:08:17.15	2017-03-10 17:08:17.155	-1	10490	10199	1	0	10199	2017-03-10 17:08:17.155	0	f	0	10199	Test Test	2017-03-10 17:08:17.155
35a541f0-8b94-492d-874f-418d405a0885	10504	10463	10155	10199	Test Test	2017-03-10 17:08:51.986	2017-03-10 17:08:51.991	-1	10503	10199	1	0	10199	2017-03-10 17:08:51.991	0	f	0	10199	Test Test	2017-03-10 17:08:51.991
\.


--
-- Data for Name: mbthreadflag; Type: TABLE DATA; Schema: public; Owner: root
--

COPY mbthreadflag (uuid_, threadflagid, groupid, companyid, userid, username, createdate, modifieddate, threadid) FROM stdin;
\.


--
-- Data for Name: mdraction; Type: TABLE DATA; Schema: public; Owner: root
--

COPY mdraction (uuid_, actionid, groupid, companyid, userid, username, createdate, modifieddate, classnameid, classpk, rulegroupinstanceid, name, description, type_, typesettings) FROM stdin;
\.


--
-- Data for Name: mdrrule; Type: TABLE DATA; Schema: public; Owner: root
--

COPY mdrrule (uuid_, ruleid, groupid, companyid, userid, username, createdate, modifieddate, rulegroupid, name, description, type_, typesettings) FROM stdin;
\.


--
-- Data for Name: mdrrulegroup; Type: TABLE DATA; Schema: public; Owner: root
--

COPY mdrrulegroup (uuid_, rulegroupid, groupid, companyid, userid, username, createdate, modifieddate, name, description) FROM stdin;
\.


--
-- Data for Name: mdrrulegroupinstance; Type: TABLE DATA; Schema: public; Owner: root
--

COPY mdrrulegroupinstance (uuid_, rulegroupinstanceid, groupid, companyid, userid, username, createdate, modifieddate, classnameid, classpk, rulegroupid, priority) FROM stdin;
\.


--
-- Data for Name: membershiprequest; Type: TABLE DATA; Schema: public; Owner: root
--

COPY membershiprequest (membershiprequestid, groupid, companyid, userid, createdate, comments, replycomments, replydate, replieruserid, statusid) FROM stdin;
\.


--
-- Data for Name: organization_; Type: TABLE DATA; Schema: public; Owner: root
--

COPY organization_ (uuid_, organizationid, companyid, userid, username, createdate, modifieddate, parentorganizationid, treepath, name, type_, recursable, regionid, countryid, statusid, comments) FROM stdin;
\.


--
-- Data for Name: orggrouprole; Type: TABLE DATA; Schema: public; Owner: root
--

COPY orggrouprole (organizationid, groupid, roleid) FROM stdin;
\.


--
-- Data for Name: orglabor; Type: TABLE DATA; Schema: public; Owner: root
--

COPY orglabor (orglaborid, organizationid, typeid, sunopen, sunclose, monopen, monclose, tueopen, tueclose, wedopen, wedclose, thuopen, thuclose, friopen, friclose, satopen, satclose) FROM stdin;
\.


--
-- Data for Name: passwordpolicy; Type: TABLE DATA; Schema: public; Owner: root
--

COPY passwordpolicy (uuid_, passwordpolicyid, companyid, userid, username, createdate, modifieddate, defaultpolicy, name, description, changeable, changerequired, minage, checksyntax, allowdictionarywords, minalphanumeric, minlength, minlowercase, minnumbers, minsymbols, minuppercase, regex, history, historycount, expireable, maxage, warningtime, gracelimit, lockout, maxfailure, lockoutduration, requireunlock, resetfailurecount, resetticketmaxage) FROM stdin;
73fd218a-f59a-4f0b-9d96-6017aeec43bc	10198	10155	10159		2017-03-10 17:06:00.752	2017-03-10 17:06:00.752	t	Default Password Policy	Default Password Policy	t	t	0	f	t	0	6	0	1	0	1	(?=.{4})(?:[a-zA-Z0-9]*)	f	6	f	8640000	86400	0	f	3	0	t	600	86400
\.


--
-- Data for Name: passwordpolicyrel; Type: TABLE DATA; Schema: public; Owner: root
--

COPY passwordpolicyrel (passwordpolicyrelid, passwordpolicyid, classnameid, classpk) FROM stdin;
\.


--
-- Data for Name: passwordtracker; Type: TABLE DATA; Schema: public; Owner: root
--

COPY passwordtracker (passwordtrackerid, userid, createdate, password_) FROM stdin;
\.


--
-- Data for Name: phone; Type: TABLE DATA; Schema: public; Owner: root
--

COPY phone (uuid_, phoneid, companyid, userid, username, createdate, modifieddate, classnameid, classpk, number_, extension, typeid, primary_) FROM stdin;
\.


--
-- Data for Name: pluginsetting; Type: TABLE DATA; Schema: public; Owner: root
--

COPY pluginsetting (pluginsettingid, companyid, pluginid, plugintype, roles, active_) FROM stdin;
\.


--
-- Data for Name: pollschoice; Type: TABLE DATA; Schema: public; Owner: root
--

COPY pollschoice (uuid_, choiceid, groupid, companyid, userid, username, createdate, modifieddate, questionid, name, description) FROM stdin;
\.


--
-- Data for Name: pollsquestion; Type: TABLE DATA; Schema: public; Owner: root
--

COPY pollsquestion (uuid_, questionid, groupid, companyid, userid, username, createdate, modifieddate, title, description, expirationdate, lastvotedate) FROM stdin;
\.


--
-- Data for Name: pollsvote; Type: TABLE DATA; Schema: public; Owner: root
--

COPY pollsvote (uuid_, voteid, groupid, companyid, userid, username, createdate, modifieddate, questionid, choiceid, votedate) FROM stdin;
\.


--
-- Data for Name: portalpreferences; Type: TABLE DATA; Schema: public; Owner: root
--

COPY portalpreferences (portalpreferencesid, ownerid, ownertype, preferences) FROM stdin;
10154	0	1	<portlet-preferences />
10161	10155	1	<portlet-preferences />
10439	10159	4	<portlet-preferences />
10453	10199	4	<portlet-preferences><preference><name>com.liferay.portal.util.SessionClicks#liferay_addpanel_tab</name><value>applications</value></preference><preference><name>com.liferay.portal.util.SessionClicks#p_auth</name><value>3VcbdERa</value></preference><preference><name>com.liferay.portal.util.SessionClicks#layoutsTreeRootNode</name><value>1</value></preference></portlet-preferences>
\.


--
-- Data for Name: portlet; Type: TABLE DATA; Schema: public; Owner: root
--

COPY portlet (id_, companyid, portletid, roles, active_) FROM stdin;
10205	10155	98		f
10206	10155	183		t
10207	10155	66		t
10208	10155	180		t
10209	10155	27		t
10210	10155	152		t
10211	10155	134		t
10212	10155	130		t
10213	10155	122		t
10214	10155	36		t
10215	10155	26		t
10216	10155	175		t
10217	10155	153		t
10218	10155	64		t
10219	10155	129		t
10220	10155	182		t
10221	10155	179		t
10222	10155	173		f
10223	10155	100		t
10224	10155	19		t
10225	10155	157		t
10226	10155	181		t
10227	10155	128		t
10228	10155	154		t
10229	10155	148		t
10230	10155	11		t
10231	10155	29		t
10232	10155	158		t
10233	10155	178		t
10234	10155	58		t
10235	10155	71		t
10236	10155	97		t
10237	10155	39		t
10238	10155	85		t
10239	10155	118		t
10240	10155	107		t
10241	10155	30		t
10242	10155	184		t
10243	10155	147		t
10244	10155	48		t
10245	10155	125		t
10246	10155	161		t
10247	10155	146		t
10248	10155	62		f
10249	10155	162		t
10250	10155	176		t
10251	10155	108		t
10252	10155	187		t
10253	10155	84		t
10254	10155	101		t
10255	10155	121		t
10256	10155	143		t
10257	10155	77		t
10258	10155	167		t
10259	10155	115		t
10260	10155	56		t
10261	10155	16		t
10262	10155	3		t
10263	10155	20		t
10264	10155	23		t
10265	10155	83		t
10266	10155	99		t
10267	10155	186		t
10268	10155	194		t
10269	10155	70		t
10270	10155	164		t
10271	10155	141		t
10272	10155	9		t
10273	10155	28		t
10274	10155	137		t
10275	10155	15		t
10276	10155	47		t
10277	10155	116		t
10278	10155	82		t
10279	10155	151		t
10280	10155	54		t
10281	10155	34		t
10282	10155	132		t
10283	10155	169		t
10284	10155	61		t
10285	10155	73		t
10286	10155	50		t
10287	10155	127		t
10288	10155	193		t
10289	10155	31		t
10290	10155	25		t
10291	10155	166		t
10292	10155	33		t
10293	10155	150		t
10294	10155	114		t
10295	10155	149		t
10296	10155	67		t
10297	10155	110		t
10298	10155	59		t
10299	10155	135		t
10300	10155	188		t
10301	10155	131		t
10302	10155	102		t
\.


--
-- Data for Name: portletitem; Type: TABLE DATA; Schema: public; Owner: root
--

COPY portletitem (portletitemid, groupid, companyid, userid, username, createdate, modifieddate, name, portletid, classnameid) FROM stdin;
\.


--
-- Data for Name: portletpreferences; Type: TABLE DATA; Schema: public; Owner: root
--

COPY portletpreferences (portletpreferencesid, ownerid, ownertype, plid, portletid, preferences) FROM stdin;
10327	0	3	10320	148_INSTANCE_YN1AXKW93IjQ	<portlet-preferences><preference><name>showAssetCount</name><value>true</value></preference><preference><name>showZeroAssetCount</name><value>false</value></preference><preference><name>classNameId</name><value>10007</value></preference><preference><name>displayStyle</name><value>cloud</value></preference><preference><name>maxAssetTags</name><value>10</value></preference></portlet-preferences>
10348	0	3	10342	141_INSTANCE_gcpHExQ03245	<portlet-preferences><preference><name>showAssetCount</name><value>true</value></preference><preference><name>classNameId</name><value>10016</value></preference></portlet-preferences>
10367	0	3	10361	3	<portlet-preferences><preference><name>portletSetupShowBorders</name><value>false</value></preference></portlet-preferences>
10368	0	3	10361	101_INSTANCE_P3cvEkiij2gk	<portlet-preferences><preference><name>portletSetupUseCustomTitle</name><value>true</value></preference><preference><name>anyAssetType</name><value>false</value></preference><preference><name>portletSetupTitle_en_US</name><value>Upcoming Events</value></preference></portlet-preferences>
10393	0	3	10387	3	<portlet-preferences><preference><name>portletSetupShowBorders</name><value>false</value></preference></portlet-preferences>
10394	0	3	10387	82	<portlet-preferences><preference><name>displayStyle</name><value>3</value></preference></portlet-preferences>
10395	0	3	10387	101_INSTANCE_vFnyKp8y2c1s	<portlet-preferences><preference><name>portletSetupUseCustomTitle</name><value>true</value></preference><preference><name>portletSetupTitle_en_US</name><value>Recent Content</value></preference></portlet-preferences>
10402	0	3	10396	20	<portlet-preferences><preference><name>portletSetupShowBorders</name><value>false</value></preference></portlet-preferences>
10403	0	3	10396	101_INSTANCE_dbhPcVMLCCcm	<portlet-preferences><preference><name>portletSetupUseCustomTitle</name><value>true</value></preference><preference><name>anyAssetType</name><value>false</value></preference><preference><name>portletSetupTitle_en_US</name><value>Upcoming Events</value></preference></portlet-preferences>
10410	0	3	10404	39_INSTANCE_7BYN7TjEczmb	<portlet-preferences><preference><name>portletSetupUseCustomTitle</name><value>true</value></preference><preference><name>expandedEntriesPerFeed</name><value>3</value></preference><preference><name>urls</name><value>http://partners.userland.com/nytRss/technology.xml</value></preference><preference><name>entriesPerFeed</name><value>4</value></preference><preference><name>portletSetupTitle_en_US</name><value>Technology news</value></preference></portlet-preferences>
10411	0	3	10404	39_INSTANCE_HtH4nWYKCyoo	<portlet-preferences><preference><name>portletSetupUseCustomTitle</name><value>true</value></preference><preference><name>expandedEntriesPerFeed</name><value>0</value></preference><preference><name>urls</name><value>http://www.liferay.com/en/about-us/news/-/blogs/rss</value></preference><preference><name>titles</name><value>Liferay Press Releases</value></preference><preference><name>entriesPerFeed</name><value>4</value></preference><preference><name>portletSetupTitle_en_US</name><value>Liferay news</value></preference></portlet-preferences>
10440	0	3	10185	145	<portlet-preferences />
10454	0	3	10176	190	<portlet-preferences />
10455	0	3	10176	145	<portlet-preferences />
10456	0	3	10176	134	<portlet-preferences />
10461	0	3	10176	160	<portlet-preferences />
10462	0	3	10176	165	<portlet-preferences />
10473	0	3	0	183	<portlet-preferences><preference><name>last-publish-date</name><value>1489165660374</value></preference></portlet-preferences>
10474	0	3	0	36	<portlet-preferences><preference><name>last-publish-date</name><value>1489165660377</value></preference></portlet-preferences>
10487	0	3	10176	156	<portlet-preferences />
10494	0	3	10488	145	<portlet-preferences />
10495	0	3	10488	170	<portlet-preferences />
10475	10463	2	0	19	<portlet-preferences><preference><name>priorities</name><value>Urgent,/message_boards/priority_urgent.png,3.0</value><value>Sticky,/message_boards/priority_sticky.png,2.0</value><value>Announcement,/message_boards/priority_announcement.png,1.0</value></preference><preference><name>last-publish-date</name><value>1489165660380</value></preference><preference><name>ranks</name><value>Youngling=0</value><value>Padawan=25</value><value>Jedi Knight=100</value><value>Jedi Master=250</value><value>Jedi Council Member=500</value><value>Yoda=1000</value><value>Moderator=organization:Message Boards Administrator</value><value>Moderator=organization-role:Message Boards Administrator</value><value>Moderator=regular-role:Message Boards Administrator</value><value>Moderator=site-role:Message Boards Administrator</value><value>Moderator=user-group:Message Boards Administrator</value></preference></portlet-preferences>
10476	10463	2	0	154	<portlet-preferences><preference><name>last-publish-date</name><value>1489165660383</value></preference></portlet-preferences>
10477	0	3	0	178	<portlet-preferences><preference><name>last-publish-date</name><value>1489165660385</value></preference></portlet-preferences>
10478	0	3	0	161	<portlet-preferences><preference><name>last-publish-date</name><value>1489165660388</value></preference></portlet-preferences>
10479	0	3	0	162	<portlet-preferences><preference><name>last-publish-date</name><value>1489165660390</value></preference></portlet-preferences>
10480	0	3	0	167	<portlet-preferences><preference><name>last-publish-date</name><value>1489165660392</value></preference></portlet-preferences>
10481	10463	2	0	20	<portlet-preferences><preference><name>last-publish-date</name><value>1489165660394</value></preference></portlet-preferences>
10482	0	3	0	28	<portlet-preferences><preference><name>last-publish-date</name><value>1489165660396</value></preference></portlet-preferences>
10483	10463	2	0	15	<portlet-preferences><preference><name>last-publish-date</name><value>1489165660399</value></preference></portlet-preferences>
10484	10463	2	0	25	<portlet-preferences><preference><name>last-publish-date</name><value>1489165660401</value></preference></portlet-preferences>
10485	10463	2	0	33	<portlet-preferences><preference><name>last-publish-date</name><value>1489165660404</value></preference></portlet-preferences>
10496	0	3	10488	56_INSTANCE_3cRWP9EaUgFZ	<portlet-preferences><preference><name>articleId</name><value>10497</value></preference><preference><name>groupId</name><value>10463</value></preference></portlet-preferences>
\.


--
-- Data for Name: quartz_blob_triggers; Type: TABLE DATA; Schema: public; Owner: root
--

COPY quartz_blob_triggers (sched_name, trigger_name, trigger_group, blob_data) FROM stdin;
\.


--
-- Data for Name: quartz_calendars; Type: TABLE DATA; Schema: public; Owner: root
--

COPY quartz_calendars (sched_name, calendar_name, calendar) FROM stdin;
\.


--
-- Data for Name: quartz_cron_triggers; Type: TABLE DATA; Schema: public; Owner: root
--

COPY quartz_cron_triggers (sched_name, trigger_name, trigger_group, cron_expression, time_zone_id) FROM stdin;
\.


--
-- Data for Name: quartz_fired_triggers; Type: TABLE DATA; Schema: public; Owner: root
--

COPY quartz_fired_triggers (sched_name, entry_id, trigger_name, trigger_group, instance_name, fired_time, priority, state, job_name, job_group, is_nonconcurrent, requests_recovery) FROM stdin;
\.


--
-- Data for Name: quartz_job_details; Type: TABLE DATA; Schema: public; Owner: root
--

COPY quartz_job_details (sched_name, job_name, job_group, description, job_class_name, is_durable, is_nonconcurrent, is_update_data, requests_recovery, job_data) FROM stdin;
\.


--
-- Data for Name: quartz_locks; Type: TABLE DATA; Schema: public; Owner: root
--

COPY quartz_locks (sched_name, lock_name) FROM stdin;
\.


--
-- Data for Name: quartz_paused_trigger_grps; Type: TABLE DATA; Schema: public; Owner: root
--

COPY quartz_paused_trigger_grps (sched_name, trigger_group) FROM stdin;
\.


--
-- Data for Name: quartz_scheduler_state; Type: TABLE DATA; Schema: public; Owner: root
--

COPY quartz_scheduler_state (sched_name, instance_name, last_checkin_time, checkin_interval) FROM stdin;
\.


--
-- Data for Name: quartz_simple_triggers; Type: TABLE DATA; Schema: public; Owner: root
--

COPY quartz_simple_triggers (sched_name, trigger_name, trigger_group, repeat_count, repeat_interval, times_triggered) FROM stdin;
\.


--
-- Data for Name: quartz_simprop_triggers; Type: TABLE DATA; Schema: public; Owner: root
--

COPY quartz_simprop_triggers (sched_name, trigger_name, trigger_group, str_prop_1, str_prop_2, str_prop_3, int_prop_1, int_prop_2, long_prop_1, long_prop_2, dec_prop_1, dec_prop_2, bool_prop_1, bool_prop_2) FROM stdin;
\.


--
-- Data for Name: quartz_triggers; Type: TABLE DATA; Schema: public; Owner: root
--

COPY quartz_triggers (sched_name, trigger_name, trigger_group, job_name, job_group, description, next_fire_time, prev_fire_time, priority, trigger_state, trigger_type, start_time, end_time, calendar_name, misfire_instr, job_data) FROM stdin;
\.


--
-- Data for Name: ratingsentry; Type: TABLE DATA; Schema: public; Owner: root
--

COPY ratingsentry (entryid, companyid, userid, username, createdate, modifieddate, classnameid, classpk, score) FROM stdin;
\.


--
-- Data for Name: ratingsstats; Type: TABLE DATA; Schema: public; Owner: root
--

COPY ratingsstats (statsid, classnameid, classpk, totalentries, totalscore, averagescore) FROM stdin;
10502	10109	10499	0	0	0
\.


--
-- Data for Name: region; Type: TABLE DATA; Schema: public; Owner: root
--

COPY region (regionid, countryid, regioncode, name, active_) FROM stdin;
1001	1	AB	Alberta	t
1002	1	BC	British Columbia	t
1003	1	MB	Manitoba	t
1004	1	NB	New Brunswick	t
1005	1	NL	Newfoundland and Labrador	t
1006	1	NT	Northwest Territories	t
1007	1	NS	Nova Scotia	t
1008	1	NU	Nunavut	t
1009	1	ON	Ontario	t
1010	1	PE	Prince Edward Island	t
1011	1	QC	Quebec	t
1012	1	SK	Saskatchewan	t
1013	1	YT	Yukon	t
2001	2	CN-34	Anhui	t
2002	2	CN-92	Aomen	t
2003	2	CN-11	Beijing	t
2004	2	CN-50	Chongqing	t
2005	2	CN-35	Fujian	t
2006	2	CN-62	Gansu	t
2007	2	CN-44	Guangdong	t
2008	2	CN-45	Guangxi	t
2009	2	CN-52	Guizhou	t
2010	2	CN-46	Hainan	t
2011	2	CN-13	Hebei	t
2012	2	CN-23	Heilongjiang	t
2013	2	CN-41	Henan	t
2014	2	CN-42	Hubei	t
2015	2	CN-43	Hunan	t
2016	2	CN-32	Jiangsu	t
2017	2	CN-36	Jiangxi	t
2018	2	CN-22	Jilin	t
2019	2	CN-21	Liaoning	t
2020	2	CN-15	Nei Mongol	t
2021	2	CN-64	Ningxia	t
2022	2	CN-63	Qinghai	t
2023	2	CN-61	Shaanxi	t
2024	2	CN-37	Shandong	t
2025	2	CN-31	Shanghai	t
2026	2	CN-14	Shanxi	t
2027	2	CN-51	Sichuan	t
2028	2	CN-71	Taiwan	t
2029	2	CN-12	Tianjin	t
2030	2	CN-91	Xianggang	t
2031	2	CN-65	Xinjiang	t
2032	2	CN-54	Xizang	t
2033	2	CN-53	Yunnan	t
2034	2	CN-33	Zhejiang	t
3001	3	A	Alsace	t
3002	3	B	Aquitaine	t
3003	3	C	Auvergne	t
3004	3	P	Basse-Normandie	t
3005	3	D	Bourgogne	t
3006	3	E	Bretagne	t
3007	3	F	Centre	t
3008	3	G	Champagne-Ardenne	t
3009	3	H	Corse	t
3010	3	GF	Guyane	t
3011	3	I	Franche Comté	t
3012	3	GP	Guadeloupe	t
3013	3	Q	Haute-Normandie	t
3014	3	J	Île-de-France	t
3015	3	K	Languedoc-Roussillon	t
3016	3	L	Limousin	t
3017	3	M	Lorraine	t
3018	3	MQ	Martinique	t
3019	3	N	Midi-Pyrénées	t
3020	3	O	Nord Pas de Calais	t
3021	3	R	Pays de la Loire	t
3022	3	S	Picardie	t
3023	3	T	Poitou-Charentes	t
3024	3	U	Provence-Alpes-Côte-d'Azur	t
3025	3	RE	Réunion	t
3026	3	V	Rhône-Alpes	t
4001	4	BW	Baden-Württemberg	t
4002	4	BY	Bayern	t
4003	4	BE	Berlin	t
4005	4	HB	Bremen	t
4006	4	HH	Hamburg	t
4007	4	HE	Hessen	t
4008	4	MV	Mecklenburg-Vorpommern	t
4009	4	NI	Niedersachsen	t
4010	4	NW	Nordrhein-Westfalen	t
4011	4	RP	Rheinland-Pfalz	t
4012	4	SL	Saarland	t
4013	4	SN	Sachsen	t
4014	4	ST	Sachsen-Anhalt	t
4015	4	SH	Schleswig-Holstein	t
4016	4	TH	Thüringen	t
8001	8	AG	Agrigento	t
8002	8	AL	Alessandria	t
8003	8	AN	Ancona	t
8004	8	AO	Aosta	t
8005	8	AR	Arezzo	t
8006	8	AP	Ascoli Piceno	t
8007	8	AT	Asti	t
8008	8	AV	Avellino	t
8009	8	BA	Bari	t
8010	8	BT	Barletta-Andria-Trani	t
8011	8	BL	Belluno	t
8012	8	BN	Benevento	t
8013	8	BG	Bergamo	t
8014	8	BI	Biella	t
8015	8	BO	Bologna	t
8016	8	BZ	Bolzano	t
8017	8	BS	Brescia	t
8018	8	BR	Brindisi	t
8019	8	CA	Cagliari	t
8020	8	CL	Caltanissetta	t
8021	8	CB	Campobasso	t
8022	8	CI	Carbonia-Iglesias	t
8023	8	CE	Caserta	t
8024	8	CT	Catania	t
8025	8	CZ	Catanzaro	t
8026	8	CH	Chieti	t
8027	8	CO	Como	t
8028	8	CS	Cosenza	t
8029	8	CR	Cremona	t
8030	8	KR	Crotone	t
8031	8	CN	Cuneo	t
8032	8	EN	Enna	t
8033	8	FM	Fermo	t
8034	8	FE	Ferrara	t
8035	8	FI	Firenze	t
8036	8	FG	Foggia	t
8037	8	FC	Forli-Cesena	t
8038	8	FR	Frosinone	t
8039	8	GE	Genova	t
8040	8	GO	Gorizia	t
8041	8	GR	Grosseto	t
8042	8	IM	Imperia	t
8043	8	IS	Isernia	t
8044	8	AQ	L'Aquila	t
8045	8	SP	La Spezia	t
8046	8	LT	Latina	t
8047	8	LE	Lecce	t
8048	8	LC	Lecco	t
8049	8	LI	Livorno	t
8050	8	LO	Lodi	t
8051	8	LU	Lucca	t
8052	8	MC	Macerata	t
8053	8	MN	Mantova	t
8054	8	MS	Massa-Carrara	t
8055	8	MT	Matera	t
8056	8	MA	Medio Campidano	t
8057	8	ME	Messina	t
8058	8	MI	Milano	t
8059	8	MO	Modena	t
8061	8	NA	Napoli	t
8062	8	NO	Novara	t
8063	8	NU	Nuoro	t
8064	8	OG	Ogliastra	t
8065	8	OT	Olbia-Tempio	t
8066	8	OR	Oristano	t
8067	8	PD	Padova	t
8068	8	PA	Palermo	t
8069	8	PR	Parma	t
8070	8	PV	Pavia	t
8071	8	PG	Perugia	t
8072	8	PU	Pesaro e Urbino	t
8073	8	PE	Pescara	t
8074	8	PC	Piacenza	t
8075	8	PI	Pisa	t
8076	8	PT	Pistoia	t
8077	8	PN	Pordenone	t
8078	8	PZ	Potenza	t
8079	8	PO	Prato	t
8080	8	RG	Ragusa	t
8081	8	RA	Ravenna	t
8082	8	RC	Reggio Calabria	t
8083	8	RE	Reggio Emilia	t
8084	8	RI	Rieti	t
8085	8	RN	Rimini	t
8086	8	RM	Roma	t
8087	8	RO	Rovigo	t
8088	8	SA	Salerno	t
8089	8	SS	Sassari	t
8090	8	SV	Savona	t
8091	8	SI	Siena	t
8092	8	SR	Siracusa	t
8093	8	SO	Sondrio	t
8094	8	TA	Taranto	t
8095	8	TE	Teramo	t
8096	8	TR	Terni	t
8097	8	TO	Torino	t
8098	8	TP	Trapani	t
8099	8	TN	Trento	t
8100	8	TV	Treviso	t
8101	8	TS	Trieste	t
8102	8	UD	Udine	t
8103	8	VA	Varese	t
8104	8	VE	Venezia	t
8105	8	VB	Verbano-Cusio-Ossola	t
8106	8	VC	Vercelli	t
8107	8	VR	Verona	t
8108	8	VV	Vibo Valentia	t
8109	8	VI	Vicenza	t
8110	8	VT	Viterbo	t
11001	11	DR	Drenthe	t
11002	11	FL	Flevoland	t
11003	11	FR	Friesland	t
11004	11	GE	Gelderland	t
11005	11	GR	Groningen	t
11006	11	LI	Limburg	t
11007	11	NB	Noord-Brabant	t
11008	11	NH	Noord-Holland	t
11009	11	OV	Overijssel	t
11010	11	UT	Utrecht	t
11011	11	ZE	Zeeland	t
11012	11	ZH	Zuid-Holland	t
15001	15	AN	Andalusia	t
15002	15	AR	Aragon	t
15003	15	AS	Asturias	t
15004	15	IB	Balearic Islands	t
15005	15	PV	Basque Country	t
15006	15	CN	Canary Islands	t
15007	15	CB	Cantabria	t
15008	15	CL	Castile and Leon	t
15009	15	CM	Castile-La Mancha	t
15010	15	CT	Catalonia	t
15011	15	CE	Ceuta	t
15012	15	EX	Extremadura	t
15013	15	GA	Galicia	t
15014	15	LO	La Rioja	t
15015	15	M	Madrid	t
15016	15	ML	Melilla	t
15017	15	MU	Murcia	t
15018	15	NA	Navarra	t
15019	15	VC	Valencia	t
19001	19	AL	Alabama	t
19002	19	AK	Alaska	t
19003	19	AZ	Arizona	t
19004	19	AR	Arkansas	t
19005	19	CA	California	t
19006	19	CO	Colorado	t
19007	19	CT	Connecticut	t
19008	19	DC	District of Columbia	t
19009	19	DE	Delaware	t
19010	19	FL	Florida	t
19011	19	GA	Georgia	t
19012	19	HI	Hawaii	t
19013	19	ID	Idaho	t
19014	19	IL	Illinois	t
19015	19	IN	Indiana	t
19016	19	IA	Iowa	t
19017	19	KS	Kansas	t
19018	19	KY	Kentucky 	t
19019	19	LA	Louisiana 	t
19020	19	ME	Maine	t
19021	19	MD	Maryland	t
19022	19	MA	Massachusetts	t
19023	19	MI	Michigan	t
19024	19	MN	Minnesota	t
19025	19	MS	Mississippi	t
19026	19	MO	Missouri	t
19027	19	MT	Montana	t
19028	19	NE	Nebraska	t
19029	19	NV	Nevada	t
19030	19	NH	New Hampshire	t
19031	19	NJ	New Jersey	t
19032	19	NM	New Mexico	t
19033	19	NY	New York	t
19034	19	NC	North Carolina	t
19035	19	ND	North Dakota	t
19036	19	OH	Ohio	t
19037	19	OK	Oklahoma 	t
19038	19	OR	Oregon	t
19039	19	PA	Pennsylvania	t
19040	19	PR	Puerto Rico	t
19041	19	RI	Rhode Island	t
19042	19	SC	South Carolina	t
19043	19	SD	South Dakota	t
19044	19	TN	Tennessee	t
19045	19	TX	Texas	t
19046	19	UT	Utah	t
19047	19	VT	Vermont	t
19048	19	VA	Virginia	t
19049	19	WA	Washington	t
19050	19	WV	West Virginia	t
19051	19	WI	Wisconsin	t
19052	19	WY	Wyoming	t
32001	32	ACT	Australian Capital Territory	t
32002	32	NSW	New South Wales	t
32003	32	NT	Northern Territory	t
32004	32	QLD	Queensland	t
32005	32	SA	South Australia	t
32006	32	TAS	Tasmania	t
32007	32	VIC	Victoria	t
32008	32	WA	Western Australia	t
144001	144	MX-AGS	Aguascalientes	t
144002	144	MX-BCN	Baja California	t
144003	144	MX-BCS	Baja California Sur	t
144004	144	MX-CAM	Campeche	t
144005	144	MX-CHP	Chiapas	t
144006	144	MX-CHI	Chihuahua	t
144007	144	MX-COA	Coahuila	t
144008	144	MX-COL	Colima	t
144009	144	MX-DUR	Durango	t
144010	144	MX-GTO	Guanajuato	t
144011	144	MX-GRO	Guerrero	t
144012	144	MX-HGO	Hidalgo	t
144013	144	MX-JAL	Jalisco	t
144014	144	MX-MEX	Mexico	t
144015	144	MX-MIC	Michoacan	t
144016	144	MX-MOR	Morelos	t
144017	144	MX-NAY	Nayarit	t
144018	144	MX-NLE	Nuevo Leon	t
144019	144	MX-OAX	Oaxaca	t
144020	144	MX-PUE	Puebla	t
144021	144	MX-QRO	Queretaro	t
144023	144	MX-ROO	Quintana Roo	t
144024	144	MX-SLP	San Luis Potosí	t
144025	144	MX-SIN	Sinaloa	t
144026	144	MX-SON	Sonora	t
144027	144	MX-TAB	Tabasco	t
144028	144	MX-TAM	Tamaulipas	t
144029	144	MX-TLX	Tlaxcala	t
144030	144	MX-VER	Veracruz	t
144031	144	MX-YUC	Yucatan	t
144032	144	MX-ZAC	Zacatecas	t
164001	164	01	Østfold	t
164002	164	02	Akershus	t
164003	164	03	Oslo	t
164004	164	04	Hedmark	t
164005	164	05	Oppland	t
164006	164	06	Buskerud	t
164007	164	07	Vestfold	t
164008	164	08	Telemark	t
164009	164	09	Aust-Agder	t
164010	164	10	Vest-Agder	t
164011	164	11	Rogaland	t
164012	164	12	Hordaland	t
164013	164	14	Sogn og Fjordane	t
164014	164	15	Møre of Romsdal	t
164015	164	16	Sør-Trøndelag	t
164016	164	17	Nord-Trøndelag	t
164017	164	18	Nordland	t
164018	164	19	Troms	t
164019	164	20	Finnmark	t
202001	202	AG	Aargau	t
202002	202	AR	Appenzell Ausserrhoden	t
202003	202	AI	Appenzell Innerrhoden	t
202004	202	BL	Basel-Landschaft	t
202005	202	BS	Basel-Stadt	t
202006	202	BE	Bern	t
202007	202	FR	Fribourg	t
202008	202	GE	Geneva	t
202009	202	GL	Glarus	t
202010	202	GR	Graubünden	t
202011	202	JU	Jura	t
202012	202	LU	Lucerne	t
202013	202	NE	Neuchâtel	t
202014	202	NW	Nidwalden	t
202015	202	OW	Obwalden	t
202016	202	SH	Schaffhausen	t
202017	202	SZ	Schwyz	t
202018	202	SO	Solothurn	t
202019	202	SG	St. Gallen	t
202020	202	TG	Thurgau	t
202021	202	TI	Ticino	t
202022	202	UR	Uri	t
202023	202	VS	Valais	t
202024	202	VD	Vaud	t
202025	202	ZG	Zug	t
202026	202	ZH	Zürich	t
4004	4	BB	Brandenburg	t
8060	8	MB	Monza e Brianza	t
\.


--
-- Data for Name: release_; Type: TABLE DATA; Schema: public; Owner: root
--

COPY release_ (releaseid, createdate, modifieddate, servletcontextname, buildnumber, builddate, verified, state_, teststring) FROM stdin;
1	2017-03-10 09:04:50.117226	2017-03-10 17:05:54.088	portal	6210	2013-11-01 00:00:00	t	0	You take the blue pill, the story ends, you wake up in your bed and believe whatever you want to believe. You take the red pill, you stay in Wonderland, and I show you how deep the rabbit hole goes.
10436	2017-03-10 17:06:08.395	2017-03-10 17:06:08.408	marketplace-portlet	100	\N	t	0	
\.


--
-- Data for Name: repository; Type: TABLE DATA; Schema: public; Owner: root
--

COPY repository (uuid_, repositoryid, groupid, companyid, userid, username, createdate, modifieddate, classnameid, name, description, portletid, typesettings, dlfolderid) FROM stdin;
\.


--
-- Data for Name: repositoryentry; Type: TABLE DATA; Schema: public; Owner: root
--

COPY repositoryentry (uuid_, repositoryentryid, groupid, companyid, userid, username, createdate, modifieddate, repositoryid, mappedid, manualcheckinrequired) FROM stdin;
\.


--
-- Data for Name: resourceaction; Type: TABLE DATA; Schema: public; Owner: root
--

COPY resourceaction (resourceactionid, name, actionid, bitwisevalue) FROM stdin;
1	com.liferay.portlet.softwarecatalog	ADD_FRAMEWORK_VERSION	2
2	com.liferay.portlet.softwarecatalog	ADD_PRODUCT_ENTRY	4
3	com.liferay.portlet.softwarecatalog	PERMISSIONS	8
4	com.liferay.portal.model.Team	ASSIGN_MEMBERS	2
5	com.liferay.portal.model.Team	DELETE	4
6	com.liferay.portal.model.Team	PERMISSIONS	8
7	com.liferay.portal.model.Team	UPDATE	16
8	com.liferay.portal.model.Team	VIEW	1
9	com.liferay.portal.model.PasswordPolicy	ASSIGN_MEMBERS	2
10	com.liferay.portal.model.PasswordPolicy	DELETE	4
11	com.liferay.portal.model.PasswordPolicy	PERMISSIONS	8
12	com.liferay.portal.model.PasswordPolicy	UPDATE	16
13	com.liferay.portal.model.PasswordPolicy	VIEW	1
14	com.liferay.portlet.blogs.model.BlogsEntry	ADD_DISCUSSION	2
15	com.liferay.portlet.blogs.model.BlogsEntry	DELETE	4
16	com.liferay.portlet.blogs.model.BlogsEntry	DELETE_DISCUSSION	8
17	com.liferay.portlet.blogs.model.BlogsEntry	PERMISSIONS	16
18	com.liferay.portlet.blogs.model.BlogsEntry	UPDATE	32
19	com.liferay.portlet.blogs.model.BlogsEntry	UPDATE_DISCUSSION	64
20	com.liferay.portlet.blogs.model.BlogsEntry	VIEW	1
21	com.liferay.portlet.dynamicdatamapping.model.DDMTemplate	DELETE	2
22	com.liferay.portlet.dynamicdatamapping.model.DDMTemplate	PERMISSIONS	4
23	com.liferay.portlet.dynamicdatamapping.model.DDMTemplate	UPDATE	8
24	com.liferay.portlet.dynamicdatamapping.model.DDMTemplate	VIEW	1
25	com.liferay.portlet.journal.model.JournalFeed	DELETE	2
26	com.liferay.portlet.journal.model.JournalFeed	PERMISSIONS	4
27	com.liferay.portlet.journal.model.JournalFeed	UPDATE	8
28	com.liferay.portlet.journal.model.JournalFeed	VIEW	1
29	com.liferay.portlet.wiki.model.WikiNode	ADD_ATTACHMENT	2
30	com.liferay.portlet.wiki.model.WikiNode	ADD_PAGE	4
31	com.liferay.portlet.wiki.model.WikiNode	DELETE	8
32	com.liferay.portlet.wiki.model.WikiNode	IMPORT	16
33	com.liferay.portlet.wiki.model.WikiNode	PERMISSIONS	32
34	com.liferay.portlet.wiki.model.WikiNode	SUBSCRIBE	64
35	com.liferay.portlet.wiki.model.WikiNode	UPDATE	128
36	com.liferay.portlet.wiki.model.WikiNode	VIEW	1
37	com.liferay.portlet.announcements.model.AnnouncementsEntry	DELETE	2
38	com.liferay.portlet.announcements.model.AnnouncementsEntry	UPDATE	4
39	com.liferay.portlet.announcements.model.AnnouncementsEntry	VIEW	1
40	com.liferay.portlet.announcements.model.AnnouncementsEntry	PERMISSIONS	8
41	com.liferay.portlet.bookmarks	ADD_ENTRY	2
42	com.liferay.portlet.bookmarks	ADD_FOLDER	4
43	com.liferay.portlet.bookmarks	PERMISSIONS	8
44	com.liferay.portlet.bookmarks	SUBSCRIBE	16
45	com.liferay.portlet.bookmarks	VIEW	1
46	com.liferay.portlet.mobiledevicerules.model.MDRRuleGroupInstance	DELETE	2
47	com.liferay.portlet.mobiledevicerules.model.MDRRuleGroupInstance	PERMISSIONS	4
48	com.liferay.portlet.mobiledevicerules.model.MDRRuleGroupInstance	UPDATE	8
49	com.liferay.portlet.mobiledevicerules.model.MDRRuleGroupInstance	VIEW	1
50	com.liferay.portlet.asset.model.AssetVocabulary	DELETE	2
51	com.liferay.portlet.asset.model.AssetVocabulary	PERMISSIONS	4
52	com.liferay.portlet.asset.model.AssetVocabulary	UPDATE	8
53	com.liferay.portlet.asset.model.AssetVocabulary	VIEW	1
54	com.liferay.portlet.documentlibrary.model.DLFolder	ACCESS	2
55	com.liferay.portlet.documentlibrary.model.DLFolder	ADD_DOCUMENT	4
56	com.liferay.portlet.documentlibrary.model.DLFolder	ADD_SHORTCUT	8
57	com.liferay.portlet.documentlibrary.model.DLFolder	ADD_SUBFOLDER	16
58	com.liferay.portlet.documentlibrary.model.DLFolder	DELETE	32
59	com.liferay.portlet.documentlibrary.model.DLFolder	PERMISSIONS	64
60	com.liferay.portlet.documentlibrary.model.DLFolder	UPDATE	128
61	com.liferay.portlet.documentlibrary.model.DLFolder	VIEW	1
62	com.liferay.portlet.expando.model.ExpandoColumn	DELETE	2
63	com.liferay.portlet.expando.model.ExpandoColumn	PERMISSIONS	4
64	com.liferay.portlet.expando.model.ExpandoColumn	UPDATE	8
65	com.liferay.portlet.expando.model.ExpandoColumn	VIEW	1
66	com.liferay.portlet.documentlibrary	ADD_DOCUMENT	2
67	com.liferay.portlet.documentlibrary	ADD_DOCUMENT_TYPE	4
68	com.liferay.portlet.documentlibrary	ADD_FOLDER	8
69	com.liferay.portlet.documentlibrary	ADD_REPOSITORY	16
70	com.liferay.portlet.documentlibrary	ADD_STRUCTURE	32
71	com.liferay.portlet.documentlibrary	ADD_SHORTCUT	64
72	com.liferay.portlet.documentlibrary	PERMISSIONS	128
73	com.liferay.portlet.documentlibrary	SUBSCRIBE	256
74	com.liferay.portlet.documentlibrary	UPDATE	512
75	com.liferay.portlet.documentlibrary	VIEW	1
76	com.liferay.portlet.calendar.model.CalEvent	ADD_DISCUSSION	2
77	com.liferay.portlet.calendar.model.CalEvent	DELETE	4
78	com.liferay.portlet.calendar.model.CalEvent	DELETE_DISCUSSION	8
79	com.liferay.portlet.calendar.model.CalEvent	PERMISSIONS	16
80	com.liferay.portlet.calendar.model.CalEvent	UPDATE	32
176	com.liferay.portal.model.Group	MANAGE_STAGING	16384
81	com.liferay.portlet.calendar.model.CalEvent	UPDATE_DISCUSSION	64
82	com.liferay.portlet.calendar.model.CalEvent	VIEW	1
83	com.liferay.portlet.shopping.model.ShoppingCategory	ADD_ITEM	2
84	com.liferay.portlet.shopping.model.ShoppingCategory	ADD_SUBCATEGORY	4
85	com.liferay.portlet.shopping.model.ShoppingCategory	DELETE	8
86	com.liferay.portlet.shopping.model.ShoppingCategory	PERMISSIONS	16
87	com.liferay.portlet.shopping.model.ShoppingCategory	UPDATE	32
88	com.liferay.portlet.shopping.model.ShoppingCategory	VIEW	1
89	com.liferay.portlet.documentlibrary.model.DLFileShortcut	DELETE	2
90	com.liferay.portlet.documentlibrary.model.DLFileShortcut	PERMISSIONS	4
91	com.liferay.portlet.documentlibrary.model.DLFileShortcut	UPDATE	8
92	com.liferay.portlet.documentlibrary.model.DLFileShortcut	VIEW	1
93	com.liferay.portlet.journal	ADD_ARTICLE	2
94	com.liferay.portlet.journal	ADD_FEED	4
95	com.liferay.portlet.journal	ADD_FOLDER	8
96	com.liferay.portlet.journal	ADD_STRUCTURE	16
97	com.liferay.portlet.journal	ADD_TEMPLATE	32
98	com.liferay.portlet.journal	SUBSCRIBE	64
99	com.liferay.portlet.journal	VIEW	1
100	com.liferay.portlet.journal	PERMISSIONS	128
101	com.liferay.portlet.calendar	ADD_EVENT	2
102	com.liferay.portlet.calendar	EXPORT_ALL_EVENTS	4
103	com.liferay.portlet.calendar	PERMISSIONS	8
104	com.liferay.portal.model.LayoutPrototype	DELETE	2
105	com.liferay.portal.model.LayoutPrototype	PERMISSIONS	4
106	com.liferay.portal.model.LayoutPrototype	UPDATE	8
107	com.liferay.portal.model.LayoutPrototype	VIEW	1
108	com.liferay.portlet.dynamicdatalists.model.DDLRecordSet	ADD_RECORD	2
109	com.liferay.portlet.dynamicdatalists.model.DDLRecordSet	DELETE	4
110	com.liferay.portlet.dynamicdatalists.model.DDLRecordSet	PERMISSIONS	8
111	com.liferay.portlet.dynamicdatalists.model.DDLRecordSet	UPDATE	16
112	com.liferay.portlet.dynamicdatalists.model.DDLRecordSet	VIEW	1
113	com.liferay.portal.model.Organization	ADD_ORGANIZATION	2
114	com.liferay.portal.model.Organization	ASSIGN_MEMBERS	4
115	com.liferay.portal.model.Organization	ASSIGN_USER_ROLES	8
116	com.liferay.portal.model.Organization	DELETE	16
117	com.liferay.portal.model.Organization	MANAGE_ANNOUNCEMENTS	32
118	com.liferay.portal.model.Organization	MANAGE_SUBORGANIZATIONS	64
119	com.liferay.portal.model.Organization	MANAGE_USERS	128
120	com.liferay.portal.model.Organization	PERMISSIONS	256
121	com.liferay.portal.model.Organization	UPDATE	512
122	com.liferay.portal.model.Organization	VIEW	1
123	com.liferay.portal.model.Organization	VIEW_MEMBERS	1024
124	com.liferay.portlet.softwarecatalog.model.SCLicense	DELETE	2
125	com.liferay.portlet.softwarecatalog.model.SCLicense	PERMISSIONS	4
126	com.liferay.portlet.softwarecatalog.model.SCLicense	UPDATE	8
127	com.liferay.portlet.softwarecatalog.model.SCLicense	VIEW	1
128	com.liferay.portlet.journal.model.JournalFolder	ACCESS	2
129	com.liferay.portlet.journal.model.JournalFolder	ADD_ARTICLE	4
130	com.liferay.portlet.journal.model.JournalFolder	ADD_SUBFOLDER	8
131	com.liferay.portlet.journal.model.JournalFolder	DELETE	16
132	com.liferay.portlet.journal.model.JournalFolder	PERMISSIONS	32
133	com.liferay.portlet.journal.model.JournalFolder	UPDATE	64
134	com.liferay.portlet.journal.model.JournalFolder	VIEW	1
135	com.liferay.portlet.documentlibrary.model.DLFileEntryType	DELETE	2
136	com.liferay.portlet.documentlibrary.model.DLFileEntryType	PERMISSIONS	4
137	com.liferay.portlet.documentlibrary.model.DLFileEntryType	UPDATE	8
138	com.liferay.portlet.documentlibrary.model.DLFileEntryType	VIEW	1
139	com.liferay.portlet.journal.model.JournalTemplate	DELETE	2
140	com.liferay.portlet.journal.model.JournalTemplate	PERMISSIONS	4
141	com.liferay.portlet.journal.model.JournalTemplate	UPDATE	8
142	com.liferay.portlet.journal.model.JournalTemplate	VIEW	1
143	com.liferay.portlet.journal.model.JournalArticle	ADD_DISCUSSION	2
144	com.liferay.portlet.journal.model.JournalArticle	DELETE	4
145	com.liferay.portlet.journal.model.JournalArticle	DELETE_DISCUSSION	8
146	com.liferay.portlet.journal.model.JournalArticle	EXPIRE	16
147	com.liferay.portlet.journal.model.JournalArticle	PERMISSIONS	32
148	com.liferay.portlet.journal.model.JournalArticle	UPDATE	64
149	com.liferay.portlet.journal.model.JournalArticle	UPDATE_DISCUSSION	128
150	com.liferay.portlet.journal.model.JournalArticle	VIEW	1
151	com.liferay.portlet.dynamicdatalists	ADD_RECORD_SET	2
152	com.liferay.portlet.dynamicdatalists	ADD_STRUCTURE	4
153	com.liferay.portlet.dynamicdatalists	ADD_TEMPLATE	8
154	com.liferay.portlet.dynamicdatalists	PERMISSIONS	16
155	com.liferay.portlet.bookmarks.model.BookmarksFolder	ACCESS	2
156	com.liferay.portlet.bookmarks.model.BookmarksFolder	ADD_ENTRY	4
157	com.liferay.portlet.bookmarks.model.BookmarksFolder	ADD_SUBFOLDER	8
158	com.liferay.portlet.bookmarks.model.BookmarksFolder	DELETE	16
159	com.liferay.portlet.bookmarks.model.BookmarksFolder	PERMISSIONS	32
160	com.liferay.portlet.bookmarks.model.BookmarksFolder	SUBSCRIBE	64
161	com.liferay.portlet.bookmarks.model.BookmarksFolder	UPDATE	128
162	com.liferay.portlet.bookmarks.model.BookmarksFolder	VIEW	1
163	com.liferay.portal.model.Group	ADD_COMMUNITY	2
164	com.liferay.portal.model.Group	ADD_LAYOUT	4
165	com.liferay.portal.model.Group	ADD_LAYOUT_BRANCH	8
166	com.liferay.portal.model.Group	ADD_LAYOUT_SET_BRANCH	16
167	com.liferay.portal.model.Group	ASSIGN_MEMBERS	32
168	com.liferay.portal.model.Group	ASSIGN_USER_ROLES	64
169	com.liferay.portal.model.Group	CONFIGURE_PORTLETS	128
170	com.liferay.portal.model.Group	DELETE	256
171	com.liferay.portal.model.Group	EXPORT_IMPORT_LAYOUTS	512
172	com.liferay.portal.model.Group	EXPORT_IMPORT_PORTLET_INFO	1024
173	com.liferay.portal.model.Group	MANAGE_ANNOUNCEMENTS	2048
174	com.liferay.portal.model.Group	MANAGE_ARCHIVED_SETUPS	4096
175	com.liferay.portal.model.Group	MANAGE_LAYOUTS	8192
310	com.liferay.portlet.wiki.model.WikiPage	ADD_DISCUSSION	2
419	174	PERMISSIONS	8
461	146	ACCESS_IN_CONTROL_PANEL	2
462	146	CONFIGURATION	4
463	146	VIEW	1
464	146	PERMISSIONS	8
465	146	PREFERENCES	16
466	147	ACCESS_IN_CONTROL_PANEL	2
177	com.liferay.portal.model.Group	MANAGE_SUBGROUPS	32768
178	com.liferay.portal.model.Group	MANAGE_TEAMS	65536
179	com.liferay.portal.model.Group	PERMISSIONS	131072
180	com.liferay.portal.model.Group	PREVIEW_IN_DEVICE	262144
181	com.liferay.portal.model.Group	PUBLISH_STAGING	524288
182	com.liferay.portal.model.Group	PUBLISH_TO_REMOTE	1048576
183	com.liferay.portal.model.Group	UPDATE	2097152
184	com.liferay.portal.model.Group	VIEW	1
185	com.liferay.portal.model.Group	VIEW_MEMBERS	4194304
186	com.liferay.portal.model.Group	VIEW_SITE_ADMINISTRATION	8388608
257	com.liferay.portlet.shopping	MANAGE_COUPONS	8
258	com.liferay.portlet.shopping	MANAGE_ORDERS	16
259	com.liferay.portlet.shopping	PERMISSIONS	32
260	com.liferay.portlet.shopping	VIEW	1
261	com.liferay.portlet.softwarecatalog.model.SCFrameworkVersion	DELETE	2
262	com.liferay.portlet.softwarecatalog.model.SCFrameworkVersion	PERMISSIONS	4
263	com.liferay.portlet.softwarecatalog.model.SCFrameworkVersion	UPDATE	8
264	com.liferay.portlet.wiki	ADD_NODE	2
265	com.liferay.portlet.wiki	PERMISSIONS	4
266	com.liferay.portlet.polls.model.PollsQuestion	ADD_VOTE	2
267	com.liferay.portlet.polls.model.PollsQuestion	DELETE	4
268	com.liferay.portlet.polls.model.PollsQuestion	PERMISSIONS	8
269	com.liferay.portlet.polls.model.PollsQuestion	UPDATE	16
270	com.liferay.portlet.polls.model.PollsQuestion	VIEW	1
271	com.liferay.portlet.shopping.model.ShoppingOrder	DELETE	2
272	com.liferay.portlet.shopping.model.ShoppingOrder	PERMISSIONS	4
273	com.liferay.portlet.shopping.model.ShoppingOrder	UPDATE	8
274	com.liferay.portlet.shopping.model.ShoppingOrder	VIEW	1
275	com.liferay.portal.model.UserGroup	ASSIGN_MEMBERS	2
276	com.liferay.portal.model.UserGroup	DELETE	4
277	com.liferay.portal.model.UserGroup	MANAGE_ANNOUNCEMENTS	8
278	com.liferay.portal.model.UserGroup	PERMISSIONS	16
279	com.liferay.portal.model.UserGroup	UPDATE	32
280	com.liferay.portal.model.UserGroup	VIEW	1
281	com.liferay.portal.model.UserGroup	VIEW_MEMBERS	64
282	com.liferay.portal.model.Role	ASSIGN_MEMBERS	2
283	com.liferay.portal.model.Role	DEFINE_PERMISSIONS	4
284	com.liferay.portal.model.Role	DELETE	8
285	com.liferay.portal.model.Role	MANAGE_ANNOUNCEMENTS	16
286	com.liferay.portal.model.Role	PERMISSIONS	32
287	com.liferay.portal.model.Role	UPDATE	64
288	com.liferay.portal.model.Role	VIEW	1
289	com.liferay.portlet.messageboards.model.MBCategory	ADD_FILE	2
290	com.liferay.portlet.messageboards.model.MBCategory	ADD_MESSAGE	4
291	com.liferay.portlet.messageboards.model.MBCategory	ADD_SUBCATEGORY	8
292	com.liferay.portlet.messageboards.model.MBCategory	DELETE	16
293	com.liferay.portlet.messageboards.model.MBCategory	LOCK_THREAD	32
294	com.liferay.portlet.messageboards.model.MBCategory	MOVE_THREAD	64
295	com.liferay.portlet.messageboards.model.MBCategory	PERMISSIONS	128
296	com.liferay.portlet.messageboards.model.MBCategory	REPLY_TO_MESSAGE	256
297	com.liferay.portlet.messageboards.model.MBCategory	SUBSCRIBE	512
298	com.liferay.portlet.messageboards.model.MBCategory	UPDATE	1024
299	com.liferay.portlet.messageboards.model.MBCategory	UPDATE_THREAD_PRIORITY	2048
300	com.liferay.portlet.messageboards.model.MBCategory	VIEW	1
301	com.liferay.portlet.mobiledevicerules	ADD_RULE_GROUP	2
303	com.liferay.portlet.mobiledevicerules	CONFIGURATION	8
307	com.liferay.portlet.dynamicdatamapping.model.DDMStructure	PERMISSIONS	4
422	83	ADD_ENTRY	2
423	83	ADD_TO_PAGE	4
424	83	CONFIGURATION	8
468	147	VIEW	1
187	com.liferay.portal.model.Group	VIEW_STAGING	16777216
188	com.liferay.portlet.journal.model.JournalStructure	DELETE	2
189	com.liferay.portlet.journal.model.JournalStructure	PERMISSIONS	4
190	com.liferay.portlet.journal.model.JournalStructure	UPDATE	8
191	com.liferay.portlet.journal.model.JournalStructure	VIEW	1
192	com.liferay.portlet.asset.model.AssetTag	DELETE	2
193	com.liferay.portlet.asset.model.AssetTag	PERMISSIONS	4
194	com.liferay.portlet.asset.model.AssetTag	UPDATE	8
195	com.liferay.portlet.asset.model.AssetTag	VIEW	1
196	com.liferay.portal.model.Layout	ADD_DISCUSSION	2
197	com.liferay.portal.model.Layout	ADD_LAYOUT	4
198	com.liferay.portal.model.Layout	CONFIGURE_PORTLETS	8
199	com.liferay.portal.model.Layout	CUSTOMIZE	16
200	com.liferay.portal.model.Layout	DELETE	32
201	com.liferay.portal.model.Layout	DELETE_DISCUSSION	64
202	com.liferay.portal.model.Layout	PERMISSIONS	128
203	com.liferay.portal.model.Layout	UPDATE	256
204	com.liferay.portal.model.Layout	UPDATE_DISCUSSION	512
205	com.liferay.portal.model.Layout	VIEW	1
206	com.liferay.portlet.asset	ADD_TAG	2
207	com.liferay.portlet.asset	PERMISSIONS	4
208	com.liferay.portlet.asset	ADD_CATEGORY	8
209	com.liferay.portlet.asset	ADD_VOCABULARY	16
210	com.liferay.portal.model.LayoutBranch	DELETE	2
211	com.liferay.portal.model.LayoutBranch	PERMISSIONS	4
212	com.liferay.portal.model.LayoutBranch	UPDATE	8
213	com.liferay.portal.model.LayoutSetBranch	DELETE	2
214	com.liferay.portal.model.LayoutSetBranch	MERGE	4
215	com.liferay.portal.model.LayoutSetBranch	PERMISSIONS	8
216	com.liferay.portal.model.LayoutSetBranch	UPDATE	16
217	com.liferay.portlet.messageboards	ADD_CATEGORY	2
218	com.liferay.portlet.messageboards	ADD_FILE	4
219	com.liferay.portlet.messageboards	ADD_MESSAGE	8
220	com.liferay.portlet.messageboards	BAN_USER	16
221	com.liferay.portlet.messageboards	MOVE_THREAD	32
222	com.liferay.portlet.messageboards	LOCK_THREAD	64
223	com.liferay.portlet.messageboards	PERMISSIONS	128
224	com.liferay.portlet.messageboards	REPLY_TO_MESSAGE	256
225	com.liferay.portlet.messageboards	SUBSCRIBE	512
226	com.liferay.portlet.messageboards	UPDATE_THREAD_PRIORITY	1024
227	com.liferay.portlet.messageboards	VIEW	1
228	com.liferay.portlet.polls	ADD_QUESTION	2
229	com.liferay.portlet.polls	PERMISSIONS	4
230	com.liferay.portlet.shopping.model.ShoppingItem	DELETE	2
231	com.liferay.portlet.shopping.model.ShoppingItem	PERMISSIONS	4
232	com.liferay.portlet.shopping.model.ShoppingItem	UPDATE	8
247	com.liferay.portal.model.User	IMPERSONATE	4
248	com.liferay.portal.model.User	PERMISSIONS	8
249	com.liferay.portal.model.User	UPDATE	16
250	com.liferay.portal.model.User	VIEW	1
251	com.liferay.portal.model.LayoutSetPrototype	DELETE	2
252	com.liferay.portal.model.LayoutSetPrototype	PERMISSIONS	4
253	com.liferay.portal.model.LayoutSetPrototype	UPDATE	8
254	com.liferay.portal.model.LayoutSetPrototype	VIEW	1
255	com.liferay.portlet.shopping	ADD_CATEGORY	2
304	com.liferay.portlet.mobiledevicerules	VIEW	1
308	com.liferay.portlet.dynamicdatamapping.model.DDMStructure	UPDATE	8
309	com.liferay.portlet.dynamicdatamapping.model.DDMStructure	VIEW	1
311	com.liferay.portlet.wiki.model.WikiPage	DELETE	4
363	19	CONFIGURATION	4
364	19	VIEW	1
365	19	PERMISSIONS	8
366	19	PREFERENCES	16
367	110	ADD_TO_PAGE	2
368	110	CONFIGURATION	4
369	110	PERMISSIONS	8
370	110	PREFERENCES	16
371	110	VIEW	1
372	36	ADD_PORTLET_DISPLAY_TEMPLATE	2
373	36	ADD_TO_PAGE	4
374	36	CONFIGURATION	8
375	36	VIEW	1
376	36	PERMISSIONS	16
377	36	PREFERENCES	32
378	178	CONFIGURATION	2
379	178	VIEW	1
380	178	ADD_TO_PAGE	4
381	178	PERMISSIONS	8
382	178	PREFERENCES	16
383	15	ACCESS_IN_CONTROL_PANEL	2
384	15	ADD_TO_PAGE	4
385	15	CONFIGURATION	8
386	15	VIEW	1
387	15	PERMISSIONS	16
388	15	PREFERENCES	32
389	33	ADD_PORTLET_DISPLAY_TEMPLATE	2
390	33	ADD_TO_PAGE	4
391	33	CONFIGURATION	8
392	33	VIEW	1
393	33	PERMISSIONS	16
394	33	PREFERENCES	32
395	34	ADD_TO_PAGE	2
396	34	CONFIGURATION	4
397	34	VIEW	1
398	34	PERMISSIONS	8
399	34	PREFERENCES	16
400	156	ADD_TO_PAGE	2
401	156	CONFIGURATION	4
402	156	PERMISSIONS	8
403	156	PREFERENCES	16
404	156	VIEW	1
233	com.liferay.portlet.shopping.model.ShoppingItem	VIEW	1
234	com.liferay.portlet.bookmarks.model.BookmarksEntry	DELETE	2
235	com.liferay.portlet.bookmarks.model.BookmarksEntry	PERMISSIONS	4
236	com.liferay.portlet.bookmarks.model.BookmarksEntry	SUBSCRIBE	8
237	com.liferay.portlet.bookmarks.model.BookmarksEntry	UPDATE	16
238	com.liferay.portlet.bookmarks.model.BookmarksEntry	VIEW	1
239	com.liferay.portlet.softwarecatalog.model.SCProductEntry	ADD_DISCUSSION	2
240	com.liferay.portlet.softwarecatalog.model.SCProductEntry	DELETE	4
241	com.liferay.portlet.softwarecatalog.model.SCProductEntry	DELETE_DISCUSSION	8
242	com.liferay.portlet.softwarecatalog.model.SCProductEntry	PERMISSIONS	16
243	com.liferay.portlet.softwarecatalog.model.SCProductEntry	UPDATE	32
244	com.liferay.portlet.softwarecatalog.model.SCProductEntry	UPDATE_DISCUSSION	64
245	com.liferay.portlet.softwarecatalog.model.SCProductEntry	VIEW	1
246	com.liferay.portal.model.User	DELETE	2
256	com.liferay.portlet.shopping	ADD_ITEM	4
302	com.liferay.portlet.mobiledevicerules	ADD_RULE_GROUP_INSTANCE	4
305	com.liferay.portlet.mobiledevicerules	PERMISSIONS	16
306	com.liferay.portlet.dynamicdatamapping.model.DDMStructure	DELETE	2
312	com.liferay.portlet.wiki.model.WikiPage	DELETE_DISCUSSION	8
313	com.liferay.portlet.wiki.model.WikiPage	PERMISSIONS	16
314	com.liferay.portlet.wiki.model.WikiPage	SUBSCRIBE	32
315	com.liferay.portlet.wiki.model.WikiPage	UPDATE	64
316	com.liferay.portlet.wiki.model.WikiPage	UPDATE_DISCUSSION	128
317	com.liferay.portlet.wiki.model.WikiPage	VIEW	1
318	com.liferay.portlet.asset.model.AssetCategory	ADD_CATEGORY	2
319	com.liferay.portlet.asset.model.AssetCategory	DELETE	4
320	com.liferay.portlet.asset.model.AssetCategory	PERMISSIONS	8
321	com.liferay.portlet.asset.model.AssetCategory	UPDATE	16
322	com.liferay.portlet.asset.model.AssetCategory	VIEW	1
323	com.liferay.portlet.mobiledevicerules.model.MDRRuleGroup	DELETE	2
324	com.liferay.portlet.mobiledevicerules.model.MDRRuleGroup	PERMISSIONS	4
325	com.liferay.portlet.mobiledevicerules.model.MDRRuleGroup	UPDATE	8
326	com.liferay.portlet.mobiledevicerules.model.MDRRuleGroup	VIEW	1
327	com.liferay.portlet.messageboards.model.MBMessage	DELETE	2
328	com.liferay.portlet.messageboards.model.MBMessage	PERMISSIONS	4
329	com.liferay.portlet.messageboards.model.MBMessage	SUBSCRIBE	8
330	com.liferay.portlet.messageboards.model.MBMessage	UPDATE	16
331	com.liferay.portlet.messageboards.model.MBMessage	VIEW	1
332	com.liferay.portlet.messageboards.model.MBThread	SUBSCRIBE	2
333	com.liferay.portlet.messageboards.model.MBThread	VIEW	1
334	com.liferay.portlet.messageboards.model.MBThread	PERMISSIONS	4
335	com.liferay.portlet.blogs	ADD_ENTRY	2
336	com.liferay.portlet.blogs	PERMISSIONS	4
337	com.liferay.portlet.blogs	SUBSCRIBE	8
338	com.liferay.portlet.documentlibrary.model.DLFileEntry	ADD_DISCUSSION	2
339	com.liferay.portlet.documentlibrary.model.DLFileEntry	DELETE	4
340	com.liferay.portlet.documentlibrary.model.DLFileEntry	DELETE_DISCUSSION	8
341	com.liferay.portlet.documentlibrary.model.DLFileEntry	OVERRIDE_CHECKOUT	16
342	com.liferay.portlet.documentlibrary.model.DLFileEntry	PERMISSIONS	32
343	com.liferay.portlet.documentlibrary.model.DLFileEntry	UPDATE	64
344	com.liferay.portlet.documentlibrary.model.DLFileEntry	UPDATE_DISCUSSION	128
345	com.liferay.portlet.documentlibrary.model.DLFileEntry	VIEW	1
346	134	ACCESS_IN_CONTROL_PANEL	2
347	134	CONFIGURATION	4
348	134	VIEW	1
349	134	PERMISSIONS	8
350	134	PREFERENCES	16
351	59	ADD_TO_PAGE	2
352	59	CONFIGURATION	4
353	59	PERMISSIONS	8
354	59	PREFERENCES	16
355	59	VIEW	1
356	139	ACCESS_IN_CONTROL_PANEL	2
357	139	ADD_EXPANDO	4
358	139	CONFIGURATION	8
359	139	VIEW	1
360	139	PERMISSIONS	16
361	139	PREFERENCES	32
362	19	ADD_TO_PAGE	2
410	20	ACCESS_IN_CONTROL_PANEL	2
411	20	ADD_PORTLET_DISPLAY_TEMPLATE	4
412	20	ADD_TO_PAGE	8
413	20	CONFIGURATION	16
414	20	VIEW	1
415	20	PERMISSIONS	32
416	20	PREFERENCES	64
417	174	ADD_TO_PAGE	2
426	83	PERMISSIONS	16
427	83	PREFERENCES	32
428	99	ACCESS_IN_CONTROL_PANEL	2
429	99	CONFIGURATION	4
430	99	VIEW	1
431	99	PERMISSIONS	8
432	99	PREFERENCES	16
433	84	ADD_ENTRY	2
434	84	ADD_TO_PAGE	4
435	84	CONFIGURATION	8
450	125	PREFERENCES	32
451	127	ADD_TO_PAGE	2
452	127	CONFIGURATION	4
453	127	PERMISSIONS	8
454	127	PREFERENCES	16
455	127	VIEW	1
456	128	ACCESS_IN_CONTROL_PANEL	2
405	154	ACCESS_IN_CONTROL_PANEL	2
406	154	CONFIGURATION	4
407	154	VIEW	1
408	154	PERMISSIONS	8
409	154	PREFERENCES	16
418	174	CONFIGURATION	4
470	147	PREFERENCES	16
420	174	PREFERENCES	16
421	174	VIEW	1
425	83	VIEW	1
436	84	VIEW	1
437	84	PERMISSIONS	16
438	84	PREFERENCES	32
439	98	ACCESS_IN_CONTROL_PANEL	2
440	98	ADD_TO_PAGE	4
441	98	CONFIGURATION	8
442	98	VIEW	1
443	98	PERMISSIONS	16
444	98	PREFERENCES	32
445	125	ACCESS_IN_CONTROL_PANEL	2
446	125	CONFIGURATION	4
447	125	EXPORT_USER	8
448	125	VIEW	1
449	125	PERMISSIONS	16
467	147	CONFIGURATION	4
457	128	CONFIGURATION	4
458	128	VIEW	1
459	128	PERMISSIONS	8
460	128	PREFERENCES	16
469	147	PERMISSIONS	8
471	149	ACCESS_IN_CONTROL_PANEL	2
472	149	CONFIGURATION	4
473	149	VIEW	1
474	149	PERMISSIONS	8
475	149	PREFERENCES	16
476	169	ADD_TO_PAGE	2
477	169	CONFIGURATION	4
478	169	PERMISSIONS	8
479	169	PREFERENCES	16
480	169	VIEW	1
481	25	ACCESS_IN_CONTROL_PANEL	2
482	25	CONFIGURATION	4
483	25	VIEW	1
484	25	PERMISSIONS	8
485	25	PREFERENCES	16
486	129	ACCESS_IN_CONTROL_PANEL	2
487	129	CONFIGURATION	4
488	129	VIEW	1
489	129	PERMISSIONS	8
490	129	PREFERENCES	16
491	166	ACCESS_IN_CONTROL_PANEL	2
492	166	ADD_TO_PAGE	4
493	166	CONFIGURATION	8
494	166	VIEW	1
495	166	PERMISSIONS	16
496	166	PREFERENCES	32
497	165	ADD_TO_PAGE	2
498	165	CONFIGURATION	4
499	165	PERMISSIONS	8
500	165	PREFERENCES	16
501	165	VIEW	1
502	28	ACCESS_IN_CONTROL_PANEL	2
503	28	ADD_TO_PAGE	4
504	28	CONFIGURATION	8
505	28	VIEW	1
506	28	PERMISSIONS	16
507	28	PREFERENCES	32
508	167	ACCESS_IN_CONTROL_PANEL	2
509	167	ADD_TO_PAGE	4
510	167	CONFIGURATION	8
511	167	VIEW	1
512	167	PERMISSIONS	16
513	167	PREFERENCES	32
514	161	ACCESS_IN_CONTROL_PANEL	2
515	161	CONFIGURATION	4
516	161	VIEW	1
517	161	PERMISSIONS	8
518	161	PREFERENCES	16
519	162	ACCESS_IN_CONTROL_PANEL	2
520	162	CONFIGURATION	4
521	162	VIEW	1
522	162	PERMISSIONS	8
523	162	PREFERENCES	16
524	31	ADD_TO_PAGE	2
525	31	CONFIGURATION	4
526	31	PERMISSIONS	8
527	31	PREFERENCES	16
528	31	VIEW	1
529	8	ACCESS_IN_CONTROL_PANEL	2
530	8	ADD_TO_PAGE	4
531	8	CONFIGURATION	8
532	8	VIEW	1
533	8	PERMISSIONS	16
534	8	PREFERENCES	32
535	183	VIEW	1
536	183	ADD_TO_PAGE	2
537	183	CONFIGURATION	4
538	183	PERMISSIONS	8
539	183	PREFERENCES	16
540	183	ACCESS_IN_CONTROL_PANEL	32
541	66	VIEW	1
542	66	ADD_TO_PAGE	2
543	66	CONFIGURATION	4
544	66	PERMISSIONS	8
545	66	PREFERENCES	16
546	66	ACCESS_IN_CONTROL_PANEL	32
547	156	ACCESS_IN_CONTROL_PANEL	32
548	180	VIEW	1
549	180	ADD_TO_PAGE	2
550	180	CONFIGURATION	4
551	180	PERMISSIONS	8
552	180	PREFERENCES	16
553	180	ACCESS_IN_CONTROL_PANEL	32
554	152	ACCESS_IN_CONTROL_PANEL	2
555	152	CONFIGURATION	4
556	152	VIEW	1
557	152	PERMISSIONS	8
558	152	PREFERENCES	16
559	27	VIEW	1
560	27	ADD_TO_PAGE	2
561	27	CONFIGURATION	4
562	27	PERMISSIONS	8
563	27	PREFERENCES	16
564	27	ACCESS_IN_CONTROL_PANEL	32
565	88	VIEW	1
566	88	ADD_TO_PAGE	2
567	88	CONFIGURATION	4
568	88	PERMISSIONS	8
569	88	PREFERENCES	16
570	88	ACCESS_IN_CONTROL_PANEL	32
571	130	ACCESS_IN_CONTROL_PANEL	2
572	130	CONFIGURATION	4
573	130	VIEW	1
574	130	PERMISSIONS	8
575	130	PREFERENCES	16
576	122	ADD_PORTLET_DISPLAY_TEMPLATE	2
577	122	CONFIGURATION	4
578	122	VIEW	1
579	122	ADD_TO_PAGE	8
580	122	PERMISSIONS	16
581	122	PREFERENCES	32
582	122	ACCESS_IN_CONTROL_PANEL	64
583	36	ACCESS_IN_CONTROL_PANEL	64
584	26	VIEW	1
585	26	ADD_TO_PAGE	2
586	26	CONFIGURATION	4
587	26	PERMISSIONS	8
588	26	PREFERENCES	16
589	26	ACCESS_IN_CONTROL_PANEL	32
590	190	VIEW	1
591	190	ADD_TO_PAGE	2
592	190	CONFIGURATION	4
593	190	PERMISSIONS	8
594	190	PREFERENCES	16
595	190	ACCESS_IN_CONTROL_PANEL	32
596	175	VIEW	1
597	175	ADD_TO_PAGE	2
598	175	CONFIGURATION	4
599	175	PERMISSIONS	8
600	175	PREFERENCES	16
601	175	ACCESS_IN_CONTROL_PANEL	32
602	64	VIEW	1
603	64	ADD_TO_PAGE	2
604	64	CONFIGURATION	4
605	64	PERMISSIONS	8
606	64	PREFERENCES	16
607	64	ACCESS_IN_CONTROL_PANEL	32
608	153	ACCESS_IN_CONTROL_PANEL	2
609	153	ADD_TO_PAGE	4
610	153	CONFIGURATION	8
611	153	VIEW	1
612	153	PERMISSIONS	16
613	153	PREFERENCES	32
614	182	VIEW	1
615	182	ADD_TO_PAGE	2
616	182	CONFIGURATION	4
617	182	PERMISSIONS	8
618	182	PREFERENCES	16
619	182	ACCESS_IN_CONTROL_PANEL	32
620	179	ACCESS_IN_CONTROL_PANEL	2
621	179	CONFIGURATION	4
622	179	VIEW	1
623	179	PERMISSIONS	8
624	179	PREFERENCES	16
625	173	VIEW	1
626	173	ADD_TO_PAGE	2
627	173	CONFIGURATION	4
628	173	PERMISSIONS	8
629	173	PREFERENCES	16
630	173	ACCESS_IN_CONTROL_PANEL	32
631	100	VIEW	1
632	100	ADD_TO_PAGE	2
633	100	CONFIGURATION	4
634	100	PERMISSIONS	8
635	100	PREFERENCES	16
636	100	ACCESS_IN_CONTROL_PANEL	32
637	157	ACCESS_IN_CONTROL_PANEL	2
638	157	CONFIGURATION	4
639	157	VIEW	1
640	157	PERMISSIONS	8
641	157	PREFERENCES	16
642	19	ACCESS_IN_CONTROL_PANEL	32
643	160	VIEW	1
644	160	ADD_TO_PAGE	2
645	160	CONFIGURATION	4
646	160	PERMISSIONS	8
647	160	PREFERENCES	16
648	160	ACCESS_IN_CONTROL_PANEL	32
649	181	VIEW	1
650	181	ADD_TO_PAGE	2
651	181	CONFIGURATION	4
652	181	PERMISSIONS	8
653	181	PREFERENCES	16
654	181	ACCESS_IN_CONTROL_PANEL	32
655	86	VIEW	1
656	86	ADD_TO_PAGE	2
657	86	CONFIGURATION	4
658	86	PERMISSIONS	8
659	86	PREFERENCES	16
660	86	ACCESS_IN_CONTROL_PANEL	32
661	148	VIEW	1
662	148	ADD_TO_PAGE	2
663	148	CONFIGURATION	4
664	148	PERMISSIONS	8
665	148	PREFERENCES	16
666	148	ACCESS_IN_CONTROL_PANEL	32
667	11	ADD_TO_PAGE	2
668	11	CONFIGURATION	4
669	11	VIEW	1
670	11	PERMISSIONS	8
671	11	PREFERENCES	16
672	11	ACCESS_IN_CONTROL_PANEL	32
673	29	ADD_TO_PAGE	2
674	29	CONFIGURATION	4
675	29	VIEW	1
676	29	PERMISSIONS	8
677	29	PREFERENCES	16
678	29	ACCESS_IN_CONTROL_PANEL	32
679	174	ACCESS_IN_CONTROL_PANEL	32
680	158	ACCESS_IN_CONTROL_PANEL	2
681	158	ADD_TO_PAGE	4
682	158	CONFIGURATION	8
683	158	VIEW	1
684	158	PERMISSIONS	16
685	158	PREFERENCES	32
686	178	ACCESS_IN_CONTROL_PANEL	32
687	124	VIEW	1
688	124	ADD_TO_PAGE	2
689	124	CONFIGURATION	4
690	124	PERMISSIONS	8
691	124	PREFERENCES	16
692	124	ACCESS_IN_CONTROL_PANEL	32
693	58	ADD_TO_PAGE	2
694	58	CONFIGURATION	4
695	58	VIEW	1
696	58	PERMISSIONS	8
697	58	PREFERENCES	16
698	58	ACCESS_IN_CONTROL_PANEL	32
699	97	VIEW	1
700	97	ADD_TO_PAGE	2
701	97	CONFIGURATION	4
702	97	PERMISSIONS	8
703	97	PREFERENCES	16
704	97	ACCESS_IN_CONTROL_PANEL	32
705	71	ADD_TO_PAGE	2
706	71	CONFIGURATION	4
707	71	VIEW	1
708	71	PERMISSIONS	8
709	71	PREFERENCES	16
710	71	ACCESS_IN_CONTROL_PANEL	32
711	39	VIEW	1
712	39	ADD_TO_PAGE	2
713	39	CONFIGURATION	4
714	39	PERMISSIONS	8
715	39	PREFERENCES	16
716	39	ACCESS_IN_CONTROL_PANEL	32
717	185	VIEW	1
718	185	ADD_TO_PAGE	2
719	185	CONFIGURATION	4
720	185	PERMISSIONS	8
721	185	PREFERENCES	16
722	185	ACCESS_IN_CONTROL_PANEL	32
723	170	VIEW	1
724	170	ADD_TO_PAGE	2
725	170	CONFIGURATION	4
726	170	PERMISSIONS	8
727	170	PREFERENCES	16
728	170	ACCESS_IN_CONTROL_PANEL	32
729	85	ADD_TO_PAGE	2
730	85	CONFIGURATION	4
731	85	VIEW	1
732	85	PERMISSIONS	8
733	85	PREFERENCES	16
734	85	ADD_PORTLET_DISPLAY_TEMPLATE	32
735	85	ACCESS_IN_CONTROL_PANEL	64
736	118	VIEW	1
737	118	ADD_TO_PAGE	2
738	118	CONFIGURATION	4
739	118	PERMISSIONS	8
740	118	PREFERENCES	16
741	118	ACCESS_IN_CONTROL_PANEL	32
742	107	VIEW	1
743	107	ADD_TO_PAGE	2
744	107	CONFIGURATION	4
745	107	PERMISSIONS	8
746	107	PREFERENCES	16
747	107	ACCESS_IN_CONTROL_PANEL	32
748	30	VIEW	1
749	30	ADD_TO_PAGE	2
750	30	CONFIGURATION	4
751	30	PERMISSIONS	8
752	30	PREFERENCES	16
753	30	ACCESS_IN_CONTROL_PANEL	32
754	184	ADD_TO_PAGE	2
755	184	CONFIGURATION	4
756	184	VIEW	1
757	184	PERMISSIONS	8
758	184	PREFERENCES	16
759	184	ACCESS_IN_CONTROL_PANEL	32
760	48	VIEW	1
761	48	ADD_TO_PAGE	2
762	48	CONFIGURATION	4
763	48	PERMISSIONS	8
764	48	PREFERENCES	16
765	48	ACCESS_IN_CONTROL_PANEL	32
766	62	VIEW	1
767	62	ADD_TO_PAGE	2
768	62	CONFIGURATION	4
769	62	PERMISSIONS	8
770	62	PREFERENCES	16
771	62	ACCESS_IN_CONTROL_PANEL	32
772	176	VIEW	1
773	176	ADD_TO_PAGE	2
774	176	CONFIGURATION	4
775	176	PERMISSIONS	8
776	176	PREFERENCES	16
777	176	ACCESS_IN_CONTROL_PANEL	32
778	172	VIEW	1
779	172	ADD_TO_PAGE	2
780	172	CONFIGURATION	4
781	172	PERMISSIONS	8
782	172	PREFERENCES	16
783	172	ACCESS_IN_CONTROL_PANEL	32
784	187	ADD_TO_PAGE	2
785	187	CONFIGURATION	4
786	187	VIEW	1
787	187	PERMISSIONS	8
788	187	PREFERENCES	16
789	187	ACCESS_IN_CONTROL_PANEL	32
790	108	VIEW	1
791	108	ADD_TO_PAGE	2
792	108	CONFIGURATION	4
793	108	PERMISSIONS	8
794	108	PREFERENCES	16
795	108	ACCESS_IN_CONTROL_PANEL	32
796	84	ACCESS_IN_CONTROL_PANEL	64
797	101	ADD_PORTLET_DISPLAY_TEMPLATE	2
798	101	ADD_TO_PAGE	4
799	101	CONFIGURATION	8
800	101	SUBSCRIBE	16
801	101	VIEW	1
802	101	PERMISSIONS	32
803	101	PREFERENCES	64
804	101	ACCESS_IN_CONTROL_PANEL	128
805	121	VIEW	1
806	121	ADD_TO_PAGE	2
807	121	CONFIGURATION	4
808	121	PERMISSIONS	8
809	121	PREFERENCES	16
810	121	ACCESS_IN_CONTROL_PANEL	32
811	49	VIEW	1
812	49	ADD_TO_PAGE	2
813	49	CONFIGURATION	4
814	49	PERMISSIONS	8
815	49	PREFERENCES	16
816	49	ACCESS_IN_CONTROL_PANEL	32
817	143	VIEW	1
818	143	ADD_TO_PAGE	2
819	143	CONFIGURATION	4
820	143	PERMISSIONS	8
821	143	PREFERENCES	16
822	143	ACCESS_IN_CONTROL_PANEL	32
823	77	VIEW	1
824	77	ADD_TO_PAGE	2
825	77	CONFIGURATION	4
826	77	PERMISSIONS	8
827	77	PREFERENCES	16
828	77	ACCESS_IN_CONTROL_PANEL	32
829	115	VIEW	1
830	115	ADD_TO_PAGE	2
831	115	CONFIGURATION	4
832	115	PERMISSIONS	8
833	115	PREFERENCES	16
834	115	ACCESS_IN_CONTROL_PANEL	32
835	56	ADD_TO_PAGE	2
836	56	CONFIGURATION	4
837	56	VIEW	1
838	56	PERMISSIONS	8
839	56	PREFERENCES	16
840	56	ACCESS_IN_CONTROL_PANEL	32
841	142	VIEW	1
842	142	ADD_TO_PAGE	2
843	142	CONFIGURATION	4
844	142	PERMISSIONS	8
845	142	PREFERENCES	16
846	142	ACCESS_IN_CONTROL_PANEL	32
847	16	PREFERENCES	2
848	16	GUEST_PREFERENCES	4
849	16	VIEW	1
850	16	ADD_TO_PAGE	8
851	16	CONFIGURATION	16
852	16	PERMISSIONS	32
853	16	ACCESS_IN_CONTROL_PANEL	64
854	3	VIEW	1
855	3	ADD_TO_PAGE	2
856	3	CONFIGURATION	4
857	3	PERMISSIONS	8
858	3	PREFERENCES	16
859	3	ACCESS_IN_CONTROL_PANEL	32
860	23	VIEW	1
861	23	ADD_TO_PAGE	2
862	23	CONFIGURATION	4
863	23	PERMISSIONS	8
864	23	PREFERENCES	16
865	23	ACCESS_IN_CONTROL_PANEL	32
866	145	VIEW	1
867	145	ADD_TO_PAGE	2
868	145	CONFIGURATION	4
869	145	PERMISSIONS	8
870	145	PREFERENCES	16
871	145	ACCESS_IN_CONTROL_PANEL	32
872	83	ACCESS_IN_CONTROL_PANEL	64
873	194	VIEW	1
874	194	ADD_TO_PAGE	2
875	194	CONFIGURATION	4
876	194	PERMISSIONS	8
877	194	PREFERENCES	16
878	194	ACCESS_IN_CONTROL_PANEL	32
879	186	ADD_TO_PAGE	2
880	186	CONFIGURATION	4
881	186	VIEW	1
882	186	PERMISSIONS	8
883	186	PREFERENCES	16
884	186	ACCESS_IN_CONTROL_PANEL	32
885	164	VIEW	1
886	164	ADD_TO_PAGE	2
887	164	CONFIGURATION	4
888	164	PERMISSIONS	8
889	164	PREFERENCES	16
890	164	ACCESS_IN_CONTROL_PANEL	32
891	70	VIEW	1
892	70	ADD_TO_PAGE	2
893	70	CONFIGURATION	4
894	70	PERMISSIONS	8
895	70	PREFERENCES	16
896	70	ACCESS_IN_CONTROL_PANEL	32
897	141	ADD_PORTLET_DISPLAY_TEMPLATE	2
898	141	CONFIGURATION	4
899	141	VIEW	1
900	141	ADD_TO_PAGE	8
901	141	PERMISSIONS	16
902	141	PREFERENCES	32
903	141	ACCESS_IN_CONTROL_PANEL	64
904	9	VIEW	1
905	9	ADD_TO_PAGE	2
906	9	CONFIGURATION	4
907	9	PERMISSIONS	8
908	9	PREFERENCES	16
909	9	ACCESS_IN_CONTROL_PANEL	32
910	137	ACCESS_IN_CONTROL_PANEL	2
911	137	CONFIGURATION	4
912	137	VIEW	1
913	137	PERMISSIONS	8
914	137	PREFERENCES	16
915	133	VIEW	1
916	133	ADD_TO_PAGE	2
917	133	CONFIGURATION	4
918	133	PERMISSIONS	8
919	133	PREFERENCES	16
920	133	ACCESS_IN_CONTROL_PANEL	32
921	116	VIEW	1
922	116	ADD_TO_PAGE	2
923	116	CONFIGURATION	4
924	116	PERMISSIONS	8
925	116	PREFERENCES	16
926	116	ACCESS_IN_CONTROL_PANEL	32
927	47	VIEW	1
928	47	ADD_TO_PAGE	2
929	47	CONFIGURATION	4
930	47	PERMISSIONS	8
931	47	PREFERENCES	16
932	47	ACCESS_IN_CONTROL_PANEL	32
933	82	VIEW	1
934	82	ADD_TO_PAGE	2
935	82	CONFIGURATION	4
936	82	PERMISSIONS	8
937	82	PREFERENCES	16
938	82	ACCESS_IN_CONTROL_PANEL	32
939	103	VIEW	1
940	103	ADD_TO_PAGE	2
941	103	CONFIGURATION	4
942	103	PERMISSIONS	8
943	103	PREFERENCES	16
944	103	ACCESS_IN_CONTROL_PANEL	32
945	151	ACCESS_IN_CONTROL_PANEL	2
946	151	CONFIGURATION	4
947	151	VIEW	1
948	151	PERMISSIONS	8
949	151	PREFERENCES	16
950	140	ACCESS_IN_CONTROL_PANEL	2
951	140	CONFIGURATION	4
952	140	VIEW	1
953	140	PERMISSIONS	8
954	140	PREFERENCES	16
955	54	VIEW	1
956	54	ADD_TO_PAGE	2
957	54	CONFIGURATION	4
958	54	PERMISSIONS	8
959	54	PREFERENCES	16
960	54	ACCESS_IN_CONTROL_PANEL	32
961	169	ACCESS_IN_CONTROL_PANEL	32
962	132	ACCESS_IN_CONTROL_PANEL	2
963	132	CONFIGURATION	4
964	132	VIEW	1
965	132	PERMISSIONS	8
966	132	PREFERENCES	16
967	34	ACCESS_IN_CONTROL_PANEL	32
968	61	VIEW	1
969	61	ADD_TO_PAGE	2
970	61	CONFIGURATION	4
971	61	PERMISSIONS	8
972	61	PREFERENCES	16
973	61	ACCESS_IN_CONTROL_PANEL	32
974	73	ADD_TO_PAGE	2
975	73	CONFIGURATION	4
976	73	VIEW	1
977	73	PERMISSIONS	8
978	73	PREFERENCES	16
979	73	ACCESS_IN_CONTROL_PANEL	32
980	193	VIEW	1
981	193	ADD_TO_PAGE	2
982	193	CONFIGURATION	4
983	193	PERMISSIONS	8
984	193	PREFERENCES	16
985	193	ACCESS_IN_CONTROL_PANEL	32
986	127	ACCESS_IN_CONTROL_PANEL	32
987	50	VIEW	1
988	50	ADD_TO_PAGE	2
989	50	CONFIGURATION	4
990	50	PERMISSIONS	8
991	50	PREFERENCES	16
992	50	ACCESS_IN_CONTROL_PANEL	32
993	31	ACCESS_IN_CONTROL_PANEL	32
994	165	ACCESS_IN_CONTROL_PANEL	32
995	192	VIEW	1
996	192	ADD_TO_PAGE	2
997	192	CONFIGURATION	4
998	192	PERMISSIONS	8
999	192	PREFERENCES	16
1000	192	ACCESS_IN_CONTROL_PANEL	32
1001	90	ADD_COMMUNITY	2
1002	90	ADD_GENERAL_ANNOUNCEMENTS	4
1003	90	ADD_LAYOUT_PROTOTYPE	8
1004	90	ADD_LAYOUT_SET_PROTOTYPE	16
1005	90	ADD_LICENSE	32
1006	90	ADD_ORGANIZATION	64
1007	90	ADD_PASSWORD_POLICY	128
1008	90	ADD_ROLE	256
1009	90	ADD_USER	512
1010	90	ADD_USER_GROUP	1024
1011	90	CONFIGURATION	2048
1012	90	EXPORT_USER	4096
1013	90	IMPERSONATE	8192
1014	90	UNLINK_LAYOUT_SET_PROTOTYPE	16384
1015	90	VIEW_CONTROL_PANEL	32768
1016	90	ADD_TO_PAGE	65536
1017	90	PERMISSIONS	131072
1018	90	PREFERENCES	262144
1019	90	VIEW	1
1020	90	ACCESS_IN_CONTROL_PANEL	524288
1021	150	ACCESS_IN_CONTROL_PANEL	2
1022	150	CONFIGURATION	4
1023	150	VIEW	1
1024	150	PERMISSIONS	8
1025	150	PREFERENCES	16
1026	113	VIEW	1
1027	113	ADD_TO_PAGE	2
1028	113	CONFIGURATION	4
1029	113	PERMISSIONS	8
1030	113	PREFERENCES	16
1031	113	ACCESS_IN_CONTROL_PANEL	32
1032	33	ACCESS_IN_CONTROL_PANEL	64
1033	2	ACCESS_IN_CONTROL_PANEL	2
1034	2	CONFIGURATION	4
1035	2	VIEW	1
1036	2	PERMISSIONS	8
1037	2	PREFERENCES	16
1038	191	VIEW	1
1039	191	ADD_TO_PAGE	2
1040	191	CONFIGURATION	4
1041	191	PERMISSIONS	8
1042	191	PREFERENCES	16
1043	191	ACCESS_IN_CONTROL_PANEL	32
1044	119	VIEW	1
1045	119	ADD_TO_PAGE	2
1046	119	CONFIGURATION	4
1047	119	PERMISSIONS	8
1048	119	PREFERENCES	16
1049	119	ACCESS_IN_CONTROL_PANEL	32
1050	114	VIEW	1
1051	114	ADD_TO_PAGE	2
1052	114	CONFIGURATION	4
1053	114	PERMISSIONS	8
1054	114	PREFERENCES	16
1055	114	ACCESS_IN_CONTROL_PANEL	32
1056	67	VIEW	1
1057	67	ADD_TO_PAGE	2
1058	67	CONFIGURATION	4
1059	67	PERMISSIONS	8
1060	67	PREFERENCES	16
1061	67	ACCESS_IN_CONTROL_PANEL	32
1062	110	ACCESS_IN_CONTROL_PANEL	32
1063	135	ACCESS_IN_CONTROL_PANEL	2
1064	135	CONFIGURATION	4
1065	135	VIEW	1
1066	135	PERMISSIONS	8
1067	135	PREFERENCES	16
1068	59	ACCESS_IN_CONTROL_PANEL	32
1069	188	ADD_TO_PAGE	2
1070	188	CONFIGURATION	4
1071	188	VIEW	1
1072	188	PERMISSIONS	8
1073	188	PREFERENCES	16
1074	188	ACCESS_IN_CONTROL_PANEL	32
1075	131	ACCESS_IN_CONTROL_PANEL	2
1076	131	CONFIGURATION	4
1077	131	VIEW	1
1078	131	PERMISSIONS	8
1079	131	PREFERENCES	16
1080	102	VIEW	1
1081	102	ADD_TO_PAGE	2
1082	102	CONFIGURATION	4
1083	102	PERMISSIONS	8
1084	102	PREFERENCES	16
1085	102	ACCESS_IN_CONTROL_PANEL	32
1086	1_WAR_marketplaceportlet	VIEW	1
1087	1_WAR_marketplaceportlet	ADD_TO_PAGE	2
1088	1_WAR_marketplaceportlet	CONFIGURATION	4
1089	1_WAR_marketplaceportlet	PERMISSIONS	8
1090	1_WAR_marketplaceportlet	PREFERENCES	16
1091	1_WAR_marketplaceportlet	ACCESS_IN_CONTROL_PANEL	32
1092	2_WAR_marketplaceportlet	VIEW	1
1093	2_WAR_marketplaceportlet	ADD_TO_PAGE	2
1094	2_WAR_marketplaceportlet	CONFIGURATION	4
1095	2_WAR_marketplaceportlet	PERMISSIONS	8
1096	2_WAR_marketplaceportlet	PREFERENCES	16
1097	2_WAR_marketplaceportlet	ACCESS_IN_CONTROL_PANEL	32
1098	3_WAR_marketplaceportlet	VIEW	1
1099	3_WAR_marketplaceportlet	ADD_TO_PAGE	2
1100	3_WAR_marketplaceportlet	CONFIGURATION	4
1101	3_WAR_marketplaceportlet	PERMISSIONS	8
1102	3_WAR_marketplaceportlet	PREFERENCES	16
1103	3_WAR_marketplaceportlet	ACCESS_IN_CONTROL_PANEL	32
\.


--
-- Data for Name: resourceblock; Type: TABLE DATA; Schema: public; Owner: root
--

COPY resourceblock (resourceblockid, companyid, groupid, name, permissionshash, referencecount) FROM stdin;
\.


--
-- Data for Name: resourceblockpermission; Type: TABLE DATA; Schema: public; Owner: root
--

COPY resourceblockpermission (resourceblockpermissionid, resourceblockid, roleid, actionids) FROM stdin;
\.


--
-- Data for Name: resourcepermission; Type: TABLE DATA; Schema: public; Owner: root
--

COPY resourcepermission (resourcepermissionid, companyid, name, scope, primkey, roleid, ownerid, actionids) FROM stdin;
1	10155	2	1	10155	10166	0	2
2	10155	140	1	10155	10166	0	2
5	10155	com.liferay.portal.model.Role	4	10162	10166	0	1
6	10155	com.liferay.portal.model.Role	4	10163	10166	0	1
7	10155	com.liferay.portal.model.Role	4	10164	10166	0	1
8	10155	com.liferay.portal.model.Role	4	10165	10166	0	1
9	10155	com.liferay.portal.model.Role	4	10166	10166	0	1
10	10155	com.liferay.portal.model.Role	4	10167	10166	0	1
11	10155	com.liferay.portal.model.Role	4	10168	10166	0	1
12	10155	com.liferay.portal.model.Role	4	10169	10166	0	1
13	10155	com.liferay.portal.model.Role	4	10170	10166	0	1
14	10155	com.liferay.portal.model.Role	4	10171	10166	0	1
15	10155	com.liferay.portal.model.Role	4	10172	10166	0	1
16	10155	com.liferay.portal.model.Layout	4	10176	10164	10159	1023
17	10155	com.liferay.portal.model.Layout	4	10176	10171	0	19
18	10155	com.liferay.portal.model.Layout	4	10176	10163	0	1
19	10155	com.liferay.portal.model.Layout	4	10185	10164	10159	1023
20	10155	com.liferay.portal.model.Layout	4	10185	10171	0	19
21	10155	com.liferay.portal.model.Layout	4	10185	10163	0	1
22	10155	com.liferay.portal.model.Layout	2	10192	10166	0	1
23	10155	com.liferay.portlet.blogs	2	10192	10166	0	14
24	10155	98	2	10192	10165	0	2
25	10155	183	2	10192	10165	0	32
26	10155	152	2	10192	10165	0	2
27	10155	182	2	10192	10165	0	32
28	10155	179	2	10192	10165	0	2
29	10155	173	2	10192	10165	0	32
30	10155	154	2	10192	10165	0	2
31	10155	178	2	10192	10165	0	32
32	10155	147	2	10192	10165	0	2
33	10155	161	2	10192	10165	0	2
34	10155	162	2	10192	10165	0	2
35	10155	167	2	10192	10165	0	2
36	10155	20	2	10192	10165	0	2
37	10155	99	2	10192	10165	0	2
38	10155	28	2	10192	10165	0	2
39	10155	15	2	10192	10165	0	2
40	10155	25	2	10192	10165	0	2
41	10155	com.liferay.portal.model.Group	2	10192	10165	0	8396800
42	10155	com.liferay.portlet.asset	2	10192	10165	0	30
43	10155	com.liferay.portlet.blogs	2	10192	10165	0	14
44	10155	com.liferay.portlet.bookmarks	2	10192	10165	0	31
45	10155	com.liferay.portlet.documentlibrary	2	10192	10165	0	1023
46	10155	com.liferay.portlet.journal	2	10192	10165	0	255
47	10155	com.liferay.portlet.messageboards	2	10192	10165	0	2047
48	10155	com.liferay.portlet.polls	2	10192	10165	0	6
49	10155	com.liferay.portlet.wiki	2	10192	10165	0	6
50	10155	com.liferay.portal.model.User	4	10199	10164	10199	31
51	10155	98	1	10155	10165	0	4
52	10155	98	1	10155	10166	0	4
53	10155	183	1	10155	10162	0	2
54	10155	66	1	10155	10165	0	2
55	10155	66	1	10155	10166	0	2
56	10155	180	1	10155	10163	0	2
57	10155	180	1	10155	10165	0	2
58	10155	180	1	10155	10166	0	2
59	10155	27	1	10155	10165	0	2
60	10155	27	1	10155	10166	0	2
61	10155	122	1	10155	10163	0	8
62	10155	122	1	10155	10165	0	8
63	10155	122	1	10155	10166	0	8
64	10155	36	1	10155	10165	0	4
65	10155	36	1	10155	10166	0	4
66	10155	26	1	10155	10165	0	2
67	10155	26	1	10155	10166	0	2
68	10155	175	1	10155	10163	0	2
69	10155	175	1	10155	10165	0	2
70	10155	175	1	10155	10166	0	2
71	10155	153	1	10155	10165	0	4
4	10155	153	1	10155	10166	0	6
72	10155	64	1	10155	10163	0	2
73	10155	64	1	10155	10165	0	2
74	10155	64	1	10155	10166	0	2
75	10155	182	1	10155	10165	0	2
76	10155	182	1	10155	10166	0	2
77	10155	173	1	10155	10163	0	2
78	10155	173	1	10155	10165	0	2
79	10155	173	1	10155	10166	0	2
80	10155	100	1	10155	10165	0	2
81	10155	100	1	10155	10166	0	2
82	10155	19	1	10155	10165	0	2
83	10155	19	1	10155	10166	0	2
84	10155	181	1	10155	10163	0	2
85	10155	181	1	10155	10165	0	2
86	10155	181	1	10155	10166	0	2
87	10155	148	1	10155	10163	0	2
88	10155	148	1	10155	10165	0	2
89	10155	148	1	10155	10166	0	2
90	10155	11	1	10155	10165	0	2
91	10155	11	1	10155	10166	0	2
92	10155	29	1	10155	10165	0	2
93	10155	29	1	10155	10166	0	2
94	10155	158	1	10155	10165	0	4
3	10155	158	1	10155	10166	0	6
95	10155	178	1	10155	10165	0	4
96	10155	178	1	10155	10166	0	4
97	10155	58	1	10155	10163	0	2
98	10155	58	1	10155	10165	0	2
99	10155	58	1	10155	10166	0	2
100	10155	71	1	10155	10163	0	2
101	10155	71	1	10155	10165	0	2
102	10155	71	1	10155	10166	0	2
103	10155	97	1	10155	10165	0	2
104	10155	97	1	10155	10166	0	2
105	10155	39	1	10155	10165	0	2
106	10155	39	1	10155	10166	0	2
107	10155	85	1	10155	10163	0	2
108	10155	85	1	10155	10165	0	2
109	10155	85	1	10155	10166	0	2
110	10155	118	1	10155	10163	0	2
111	10155	118	1	10155	10165	0	2
112	10155	118	1	10155	10166	0	2
113	10155	107	1	10155	10165	0	2
114	10155	107	1	10155	10166	0	2
115	10155	30	1	10155	10165	0	2
116	10155	30	1	10155	10166	0	2
117	10155	184	1	10155	10163	0	2
118	10155	184	1	10155	10165	0	2
119	10155	184	1	10155	10166	0	2
120	10155	48	1	10155	10165	0	2
121	10155	48	1	10155	10166	0	2
122	10155	62	1	10155	10165	0	2
123	10155	62	1	10155	10166	0	2
124	10155	176	1	10155	10162	0	2
125	10155	108	1	10155	10165	0	2
126	10155	108	1	10155	10166	0	2
127	10155	187	1	10155	10165	0	2
128	10155	187	1	10155	10166	0	2
129	10155	84	1	10155	10165	0	4
130	10155	84	1	10155	10166	0	4
131	10155	101	1	10155	10163	0	4
132	10155	101	1	10155	10165	0	4
133	10155	101	1	10155	10166	0	4
134	10155	121	1	10155	10163	0	2
135	10155	121	1	10155	10165	0	2
136	10155	121	1	10155	10166	0	2
137	10155	143	1	10155	10163	0	2
138	10155	143	1	10155	10165	0	2
139	10155	143	1	10155	10166	0	2
140	10155	77	1	10155	10163	0	2
141	10155	77	1	10155	10165	0	2
142	10155	77	1	10155	10166	0	2
143	10155	167	1	10155	10165	0	4
144	10155	167	1	10155	10166	0	4
145	10155	115	1	10155	10163	0	2
146	10155	115	1	10155	10165	0	2
147	10155	115	1	10155	10166	0	2
148	10155	56	1	10155	10163	0	2
149	10155	56	1	10155	10165	0	2
150	10155	56	1	10155	10166	0	2
151	10155	16	1	10155	10165	0	8
152	10155	16	1	10155	10166	0	8
153	10155	3	1	10155	10163	0	2
154	10155	3	1	10155	10165	0	2
155	10155	3	1	10155	10166	0	2
156	10155	20	1	10155	10163	0	8
157	10155	20	1	10155	10165	0	8
158	10155	20	1	10155	10166	0	8
159	10155	23	1	10155	10165	0	2
160	10155	23	1	10155	10166	0	2
161	10155	83	1	10155	10165	0	4
162	10155	83	1	10155	10166	0	4
163	10155	186	1	10155	10165	0	2
164	10155	186	1	10155	10166	0	2
165	10155	194	1	10155	10163	0	2
166	10155	194	1	10155	10165	0	2
167	10155	194	1	10155	10166	0	2
168	10155	70	1	10155	10165	0	2
169	10155	70	1	10155	10166	0	2
170	10155	164	1	10155	10163	0	2
171	10155	164	1	10155	10165	0	2
172	10155	164	1	10155	10166	0	2
173	10155	141	1	10155	10163	0	8
174	10155	141	1	10155	10165	0	8
175	10155	141	1	10155	10166	0	8
176	10155	9	1	10155	10162	0	2
177	10155	28	1	10155	10165	0	4
178	10155	28	1	10155	10166	0	4
179	10155	15	1	10155	10165	0	4
180	10155	15	1	10155	10166	0	4
181	10155	47	1	10155	10163	0	2
182	10155	47	1	10155	10165	0	2
183	10155	47	1	10155	10166	0	2
184	10155	116	1	10155	10163	0	2
185	10155	116	1	10155	10165	0	2
186	10155	116	1	10155	10166	0	2
187	10155	82	1	10155	10163	0	2
188	10155	82	1	10155	10165	0	2
189	10155	82	1	10155	10166	0	2
190	10155	54	1	10155	10165	0	2
191	10155	54	1	10155	10166	0	2
192	10155	34	1	10155	10165	0	2
193	10155	34	1	10155	10166	0	2
194	10155	169	1	10155	10165	0	2
195	10155	169	1	10155	10166	0	2
196	10155	61	1	10155	10165	0	2
197	10155	61	1	10155	10166	0	2
198	10155	73	1	10155	10163	0	2
199	10155	73	1	10155	10165	0	2
200	10155	73	1	10155	10166	0	2
201	10155	50	1	10155	10163	0	2
202	10155	50	1	10155	10165	0	2
203	10155	50	1	10155	10166	0	2
204	10155	127	1	10155	10162	0	2
205	10155	193	1	10155	10163	0	2
206	10155	193	1	10155	10165	0	2
207	10155	193	1	10155	10166	0	2
208	10155	31	1	10155	10163	0	2
209	10155	31	1	10155	10165	0	2
210	10155	31	1	10155	10166	0	2
211	10155	166	1	10155	10165	0	4
212	10155	166	1	10155	10166	0	4
213	10155	33	1	10155	10163	0	4
214	10155	33	1	10155	10165	0	4
215	10155	33	1	10155	10166	0	4
216	10155	114	1	10155	10163	0	2
217	10155	114	1	10155	10165	0	2
218	10155	114	1	10155	10166	0	2
219	10155	67	1	10155	10165	0	2
220	10155	67	1	10155	10166	0	2
221	10155	110	1	10155	10165	0	2
222	10155	110	1	10155	10166	0	2
223	10155	59	1	10155	10165	0	2
224	10155	59	1	10155	10166	0	2
225	10155	188	1	10155	10165	0	2
226	10155	188	1	10155	10166	0	2
227	10155	102	1	10155	10162	0	2
228	10155	com.liferay.portlet.dynamicdatamapping.model.DDMStructure	4	10303	10164	10159	15
229	10155	com.liferay.portlet.dynamicdatamapping.model.DDMStructure	4	10303	10166	0	1
230	10155	com.liferay.portlet.dynamicdatamapping.model.DDMStructure	4	10303	10163	0	1
231	10155	com.liferay.portlet.dynamicdatamapping.model.DDMStructure	4	10304	10164	10159	15
232	10155	com.liferay.portlet.dynamicdatamapping.model.DDMStructure	4	10304	10166	0	1
233	10155	com.liferay.portlet.dynamicdatamapping.model.DDMStructure	4	10304	10163	0	1
234	10155	com.liferay.portlet.dynamicdatamapping.model.DDMStructure	4	10305	10164	10159	15
235	10155	com.liferay.portlet.dynamicdatamapping.model.DDMStructure	4	10305	10166	0	1
236	10155	com.liferay.portlet.dynamicdatamapping.model.DDMStructure	4	10305	10163	0	1
237	10155	com.liferay.portlet.dynamicdatamapping.model.DDMStructure	4	10307	10164	10159	15
238	10155	com.liferay.portlet.dynamicdatamapping.model.DDMStructure	4	10307	10166	0	1
239	10155	com.liferay.portlet.dynamicdatamapping.model.DDMStructure	4	10307	10163	0	1
240	10155	com.liferay.portlet.documentlibrary.model.DLFileEntryType	4	10306	10164	10159	15
241	10155	com.liferay.portlet.documentlibrary.model.DLFileEntryType	4	10306	10166	0	1
242	10155	com.liferay.portlet.documentlibrary.model.DLFileEntryType	4	10306	10163	0	1
243	10155	com.liferay.portlet.dynamicdatamapping.model.DDMStructure	4	10309	10164	10159	15
244	10155	com.liferay.portlet.dynamicdatamapping.model.DDMStructure	4	10309	10166	0	1
245	10155	com.liferay.portlet.dynamicdatamapping.model.DDMStructure	4	10309	10163	0	1
246	10155	com.liferay.portlet.documentlibrary.model.DLFileEntryType	4	10308	10164	10159	15
247	10155	com.liferay.portlet.documentlibrary.model.DLFileEntryType	4	10308	10166	0	1
248	10155	com.liferay.portlet.documentlibrary.model.DLFileEntryType	4	10308	10163	0	1
249	10155	com.liferay.portlet.dynamicdatamapping.model.DDMStructure	4	10311	10164	10159	15
250	10155	com.liferay.portlet.dynamicdatamapping.model.DDMStructure	4	10311	10166	0	1
251	10155	com.liferay.portlet.dynamicdatamapping.model.DDMStructure	4	10311	10163	0	1
252	10155	com.liferay.portlet.documentlibrary.model.DLFileEntryType	4	10310	10164	10159	15
253	10155	com.liferay.portlet.documentlibrary.model.DLFileEntryType	4	10310	10166	0	1
254	10155	com.liferay.portlet.documentlibrary.model.DLFileEntryType	4	10310	10163	0	1
255	10155	com.liferay.portlet.dynamicdatamapping.model.DDMStructure	4	10313	10164	10159	15
256	10155	com.liferay.portlet.dynamicdatamapping.model.DDMStructure	4	10313	10166	0	1
257	10155	com.liferay.portlet.dynamicdatamapping.model.DDMStructure	4	10313	10163	0	1
403	10155	58	4	10185_LAYOUT_58	10171	0	1
258	10155	com.liferay.portlet.documentlibrary.model.DLFileEntryType	4	10312	10164	10159	15
259	10155	com.liferay.portlet.documentlibrary.model.DLFileEntryType	4	10312	10166	0	1
260	10155	com.liferay.portlet.documentlibrary.model.DLFileEntryType	4	10312	10163	0	1
261	10155	com.liferay.portlet.dynamicdatamapping.model.DDMStructure	4	10315	10164	10159	15
262	10155	com.liferay.portlet.dynamicdatamapping.model.DDMStructure	4	10315	10166	0	1
263	10155	com.liferay.portlet.dynamicdatamapping.model.DDMStructure	4	10315	10163	0	1
264	10155	com.liferay.portal.model.LayoutPrototype	4	10316	10164	10159	15
265	10155	com.liferay.portal.model.Layout	4	10320	10164	10159	1023
266	10155	com.liferay.portal.model.Layout	4	10320	10171	0	19
267	10155	com.liferay.portlet.asset.model.AssetVocabulary	4	10324	10164	10159	15
268	10155	33	4	10320_LAYOUT_33	10164	0	127
269	10155	33	4	10320_LAYOUT_33	10171	0	1
270	10155	33	4	10320_LAYOUT_33	10163	0	1
271	10155	com.liferay.portlet.blogs	4	10317	10164	0	14
272	10155	148	4	10320_LAYOUT_148_INSTANCE_YN1AXKW93IjQ	10164	0	63
273	10155	148	4	10320_LAYOUT_148_INSTANCE_YN1AXKW93IjQ	10171	0	1
274	10155	148	4	10320_LAYOUT_148_INSTANCE_YN1AXKW93IjQ	10163	0	1
275	10155	114	4	10320_LAYOUT_114	10164	0	63
276	10155	114	4	10320_LAYOUT_114	10171	0	1
277	10155	114	4	10320_LAYOUT_114	10163	0	1
278	10155	com.liferay.portal.model.LayoutPrototype	4	10328	10164	10159	15
279	10155	com.liferay.portal.model.Layout	4	10332	10164	10159	1023
280	10155	com.liferay.portal.model.Layout	4	10332	10171	0	19
281	10155	141	4	10332_LAYOUT_141_INSTANCE_LHWkhaysyiQZ	10164	0	127
282	10155	141	4	10332_LAYOUT_141_INSTANCE_LHWkhaysyiQZ	10171	0	1
283	10155	141	4	10332_LAYOUT_141_INSTANCE_LHWkhaysyiQZ	10163	0	1
284	10155	122	4	10332_LAYOUT_122_INSTANCE_ll52r9DzS2of	10164	0	127
285	10155	122	4	10332_LAYOUT_122_INSTANCE_ll52r9DzS2of	10171	0	1
286	10155	122	4	10332_LAYOUT_122_INSTANCE_ll52r9DzS2of	10163	0	1
287	10155	3	4	10332_LAYOUT_3	10164	0	63
288	10155	3	4	10332_LAYOUT_3	10171	0	1
289	10155	3	4	10332_LAYOUT_3	10163	0	1
290	10155	101	4	10332_LAYOUT_101_INSTANCE_oJezYMau57VX	10164	0	255
291	10155	101	4	10332_LAYOUT_101_INSTANCE_oJezYMau57VX	10171	0	17
292	10155	101	4	10332_LAYOUT_101_INSTANCE_oJezYMau57VX	10163	0	1
293	10155	com.liferay.portal.model.LayoutPrototype	4	10338	10164	10159	15
294	10155	com.liferay.portal.model.Layout	4	10342	10164	10159	1023
295	10155	com.liferay.portal.model.Layout	4	10342	10171	0	19
296	10155	36	4	10342_LAYOUT_36	10164	0	127
297	10155	36	4	10342_LAYOUT_36	10171	0	1
298	10155	36	4	10342_LAYOUT_36	10163	0	1
299	10155	com.liferay.portlet.wiki	4	10339	10164	0	6
300	10155	122	4	10342_LAYOUT_122_INSTANCE_CxUYlFyV5tlM	10164	0	127
301	10155	122	4	10342_LAYOUT_122_INSTANCE_CxUYlFyV5tlM	10171	0	1
302	10155	122	4	10342_LAYOUT_122_INSTANCE_CxUYlFyV5tlM	10163	0	1
303	10155	141	4	10342_LAYOUT_141_INSTANCE_gcpHExQ03245	10164	0	127
304	10155	141	4	10342_LAYOUT_141_INSTANCE_gcpHExQ03245	10171	0	1
305	10155	141	4	10342_LAYOUT_141_INSTANCE_gcpHExQ03245	10163	0	1
306	10155	com.liferay.portal.model.LayoutSetPrototype	4	10349	10164	10159	15
310	10155	com.liferay.portal.model.Layout	4	10361	10164	10159	1023
311	10155	com.liferay.portal.model.Layout	4	10361	10171	0	19
312	10155	com.liferay.portal.model.Layout	4	10361	10163	0	1
313	10155	19	4	10361_LAYOUT_19	10164	0	63
314	10155	19	4	10361_LAYOUT_19	10171	0	1
315	10155	19	4	10361_LAYOUT_19	10163	0	1
316	10155	com.liferay.portlet.messageboards	4	10350	10164	0	2047
317	10155	com.liferay.portlet.messageboards	4	10350	10171	0	781
318	10155	com.liferay.portlet.messageboards	4	10350	10163	0	1
319	10155	3	4	10361_LAYOUT_3	10164	0	63
320	10155	3	4	10361_LAYOUT_3	10171	0	1
321	10155	3	4	10361_LAYOUT_3	10163	0	1
322	10155	59	4	10361_LAYOUT_59_INSTANCE_0WaGT5hPwAyy	10164	0	63
323	10155	59	4	10361_LAYOUT_59_INSTANCE_0WaGT5hPwAyy	10171	0	1
324	10155	59	4	10361_LAYOUT_59_INSTANCE_0WaGT5hPwAyy	10163	0	1
325	10155	com.liferay.portlet.polls	4	10350	10164	0	6
326	10155	180	4	10361_LAYOUT_180	10164	0	63
327	10155	180	4	10361_LAYOUT_180	10171	0	1
328	10155	180	4	10361_LAYOUT_180	10163	0	1
329	10155	101	4	10361_LAYOUT_101_INSTANCE_P3cvEkiij2gk	10164	0	255
330	10155	101	4	10361_LAYOUT_101_INSTANCE_P3cvEkiij2gk	10171	0	17
331	10155	101	4	10361_LAYOUT_101_INSTANCE_P3cvEkiij2gk	10163	0	1
332	10155	com.liferay.portal.model.Layout	4	10369	10164	10159	1023
402	10155	58	4	10185_LAYOUT_58	10164	0	63
333	10155	com.liferay.portal.model.Layout	4	10369	10171	0	19
334	10155	com.liferay.portal.model.Layout	4	10369	10163	0	1
335	10155	36	4	10369_LAYOUT_36	10164	0	127
336	10155	36	4	10369_LAYOUT_36	10171	0	1
337	10155	36	4	10369_LAYOUT_36	10163	0	1
338	10155	com.liferay.portlet.wiki	4	10350	10164	0	6
339	10155	122	4	10369_LAYOUT_122_INSTANCE_YSgYD5s7AQ2H	10164	0	127
340	10155	122	4	10369_LAYOUT_122_INSTANCE_YSgYD5s7AQ2H	10171	0	1
341	10155	122	4	10369_LAYOUT_122_INSTANCE_YSgYD5s7AQ2H	10163	0	1
342	10155	148	4	10369_LAYOUT_148_INSTANCE_Vru4zWak80M1	10164	0	63
343	10155	148	4	10369_LAYOUT_148_INSTANCE_Vru4zWak80M1	10171	0	1
344	10155	148	4	10369_LAYOUT_148_INSTANCE_Vru4zWak80M1	10163	0	1
345	10155	com.liferay.portal.model.LayoutSetPrototype	4	10375	10164	10159	15
349	10155	com.liferay.portal.model.Layout	4	10387	10164	10159	1023
350	10155	com.liferay.portal.model.Layout	4	10387	10171	0	19
351	10155	com.liferay.portal.model.Layout	4	10387	10163	0	1
352	10155	116	4	10387_LAYOUT_116	10164	0	63
353	10155	116	4	10387_LAYOUT_116	10171	0	1
354	10155	116	4	10387_LAYOUT_116	10163	0	1
355	10155	3	4	10387_LAYOUT_3	10164	0	63
356	10155	3	4	10387_LAYOUT_3	10171	0	1
357	10155	3	4	10387_LAYOUT_3	10163	0	1
358	10155	82	4	10387_LAYOUT_82	10164	0	63
359	10155	82	4	10387_LAYOUT_82	10171	0	1
360	10155	82	4	10387_LAYOUT_82	10163	0	1
361	10155	101	4	10387_LAYOUT_101_INSTANCE_vFnyKp8y2c1s	10164	0	255
362	10155	101	4	10387_LAYOUT_101_INSTANCE_vFnyKp8y2c1s	10171	0	17
363	10155	101	4	10387_LAYOUT_101_INSTANCE_vFnyKp8y2c1s	10163	0	1
364	10155	com.liferay.portal.model.Layout	4	10396	10164	10159	1023
365	10155	com.liferay.portal.model.Layout	4	10396	10171	0	19
366	10155	com.liferay.portal.model.Layout	4	10396	10163	0	1
367	10155	20	4	10396_LAYOUT_20	10164	0	127
368	10155	20	4	10396_LAYOUT_20	10171	0	1
369	10155	20	4	10396_LAYOUT_20	10163	0	1
370	10155	com.liferay.portlet.documentlibrary	4	10376	10164	0	1023
371	10155	com.liferay.portlet.documentlibrary	4	10376	10171	0	331
372	10155	com.liferay.portlet.documentlibrary	4	10376	10163	0	1
373	10155	101	4	10396_LAYOUT_101_INSTANCE_dbhPcVMLCCcm	10164	0	255
374	10155	101	4	10396_LAYOUT_101_INSTANCE_dbhPcVMLCCcm	10171	0	17
375	10155	101	4	10396_LAYOUT_101_INSTANCE_dbhPcVMLCCcm	10163	0	1
376	10155	com.liferay.portal.model.Layout	4	10404	10164	10159	1023
377	10155	com.liferay.portal.model.Layout	4	10404	10171	0	19
378	10155	com.liferay.portal.model.Layout	4	10404	10163	0	1
379	10155	39	4	10404_LAYOUT_39_INSTANCE_7BYN7TjEczmb	10164	0	63
380	10155	39	4	10404_LAYOUT_39_INSTANCE_7BYN7TjEczmb	10171	0	1
381	10155	39	4	10404_LAYOUT_39_INSTANCE_7BYN7TjEczmb	10163	0	1
382	10155	39	4	10404_LAYOUT_39_INSTANCE_HtH4nWYKCyoo	10164	0	63
383	10155	39	4	10404_LAYOUT_39_INSTANCE_HtH4nWYKCyoo	10171	0	1
384	10155	39	4	10404_LAYOUT_39_INSTANCE_HtH4nWYKCyoo	10163	0	1
385	10155	com.liferay.portlet.dynamicdatamapping.model.DDMStructure	4	10412	10164	10159	15
386	10155	com.liferay.portlet.dynamicdatamapping.model.DDMStructure	4	10413	10164	10159	15
387	10155	com.liferay.portlet.dynamicdatamapping.model.DDMStructure	4	10414	10164	10159	15
388	10155	com.liferay.portlet.dynamicdatamapping.model.DDMStructure	4	10415	10164	10159	15
389	10155	com.liferay.portlet.dynamicdatamapping.model.DDMStructure	4	10416	10164	10159	15
390	10155	com.liferay.portlet.dynamicdatamapping.model.DDMStructure	4	10417	10164	10159	15
391	10155	com.liferay.portlet.dynamicdatamapping.model.DDMTemplate	4	10418	10164	10159	15
392	10155	com.liferay.portlet.dynamicdatamapping.model.DDMTemplate	4	10420	10164	10159	15
393	10155	com.liferay.portlet.dynamicdatamapping.model.DDMTemplate	4	10423	10164	10159	15
394	10155	com.liferay.portlet.dynamicdatamapping.model.DDMTemplate	4	10425	10164	10159	15
395	10155	com.liferay.portlet.dynamicdatamapping.model.DDMTemplate	4	10427	10164	10159	15
396	10155	com.liferay.portlet.dynamicdatamapping.model.DDMTemplate	4	10429	10164	10159	15
397	10155	com.liferay.portlet.dynamicdatamapping.model.DDMTemplate	4	10431	10164	10159	15
398	10155	com.liferay.portlet.expando.model.ExpandoColumn	4	10438	10164	0	15
399	10155	145	4	10185_LAYOUT_145	10164	0	63
400	10155	145	4	10185_LAYOUT_145	10171	0	1
401	10155	145	4	10185_LAYOUT_145	10163	0	1
404	10155	47	4	10185_LAYOUT_47	10164	0	63
406	10155	47	4	10185_LAYOUT_47	10171	0	1
407	10155	47	4	10185_LAYOUT_47	10163	0	1
405	10155	58	4	10185_LAYOUT_58	10163	0	1
408	10155	com.liferay.portal.model.Layout	4	10441	10164	10199	1023
409	10155	com.liferay.portal.model.Layout	4	10447	10164	10199	1023
410	10155	com.liferay.portal.model.Layout	4	10447	10166	0	19
411	10155	com.liferay.portal.model.Layout	4	10447	10163	0	1
412	10155	com.liferay.portal.model.Group	4	10457	10164	0	33554431
413	10155	com.liferay.portal.model.Group	4	10463	10164	0	33554431
414	10155	com.liferay.portlet.asset.model.AssetVocabulary	4	10470	10164	10159	15
415	10155	com.liferay.portlet.asset.model.AssetVocabulary	4	10471	10164	10159	15
416	10155	com.liferay.portlet.asset.model.AssetVocabulary	4	10471	10171	0	0
417	10155	com.liferay.portlet.asset.model.AssetVocabulary	4	10471	10163	0	0
418	10155	com.liferay.portal.model.Layout	4	10488	10164	10199	1023
419	10155	com.liferay.portal.model.Layout	4	10488	10171	0	19
420	10155	com.liferay.portal.model.Layout	4	10488	10163	0	1
421	10155	145	4	10488_LAYOUT_145	10164	0	63
422	10155	145	4	10488_LAYOUT_145	10171	0	1
423	10155	145	4	10488_LAYOUT_145	10163	0	1
424	10155	170	4	10488_LAYOUT_170	10164	0	63
425	10155	170	4	10488_LAYOUT_170	10171	0	1
426	10155	170	4	10488_LAYOUT_170	10163	0	1
427	10155	com.liferay.portlet.journal	4	10463	10164	0	255
428	10155	com.liferay.portlet.journal	4	10463	10171	0	1
429	10155	com.liferay.portlet.journal	4	10463	10163	0	1
430	10155	com.liferay.portlet.documentlibrary	4	10463	10164	0	1023
431	10155	com.liferay.portlet.documentlibrary	4	10463	10171	0	331
432	10155	com.liferay.portlet.documentlibrary	4	10463	10163	0	1
433	10155	56	4	10488_LAYOUT_56_INSTANCE_3cRWP9EaUgFZ	10164	0	63
434	10155	56	4	10488_LAYOUT_56_INSTANCE_3cRWP9EaUgFZ	10171	0	1
435	10155	56	4	10488_LAYOUT_56_INSTANCE_3cRWP9EaUgFZ	10163	0	1
436	10155	15	4	10488_LAYOUT_15	10164	0	63
437	10155	15	4	10488_LAYOUT_15	10171	0	1
438	10155	15	4	10488_LAYOUT_15	10163	0	1
439	10155	com.liferay.portlet.journal	4	10457	10164	0	255
440	10155	com.liferay.portlet.journal	4	10457	10171	0	1
441	10155	com.liferay.portlet.journal	4	10457	10163	0	1
442	10155	com.liferay.portlet.journal.model.JournalArticle	4	10499	10164	10199	255
443	10155	com.liferay.portlet.journal.model.JournalArticle	4	10499	10171	0	3
444	10155	com.liferay.portlet.journal.model.JournalArticle	4	10499	10163	0	3
\.


--
-- Data for Name: resourcetypepermission; Type: TABLE DATA; Schema: public; Owner: root
--

COPY resourcetypepermission (resourcetypepermissionid, companyid, groupid, name, roleid, actionids) FROM stdin;
\.


--
-- Data for Name: role_; Type: TABLE DATA; Schema: public; Owner: root
--

COPY role_ (uuid_, roleid, companyid, userid, username, createdate, modifieddate, classnameid, classpk, name, title, description, type_, subtype) FROM stdin;
4898f327-c024-42b4-9ded-fd4420272033	10162	10155	10159		2017-03-10 17:05:59.423	2017-03-10 17:05:59.423	10004	10162	Administrator		<?xml version='1.0' encoding='UTF-8'?><root available-locales="en_US" default-locale="en_US"><Description language-id="en_US">Administrators are super users who can do anything.</Description></root>	1	
7e9d149a-5d78-4f4c-9f11-69e911ae9ecb	10163	10155	10159		2017-03-10 17:05:59.45	2017-03-10 17:05:59.45	10004	10163	Guest		<?xml version='1.0' encoding='UTF-8'?><root available-locales="en_US" default-locale="en_US"><Description language-id="en_US">Unauthenticated users always have this role.</Description></root>	1	
04bf85d5-2a8b-48dc-a6db-57f2f286afd6	10164	10155	10159		2017-03-10 17:05:59.458	2017-03-10 17:05:59.458	10004	10164	Owner		<?xml version='1.0' encoding='UTF-8'?><root available-locales="en_US" default-locale="en_US"><Description language-id="en_US">This is an implied role with respect to the objects users create.</Description></root>	1	
8d4e15d6-f98e-4064-94aa-458fb1a32d26	10165	10155	10159		2017-03-10 17:05:59.467	2017-03-10 17:05:59.467	10004	10165	Power User		<?xml version='1.0' encoding='UTF-8'?><root available-locales="en_US" default-locale="en_US"><Description language-id="en_US">Power Users have their own personal site.</Description></root>	1	
ddce8349-271d-4158-9861-ba21178710a6	10166	10155	10159		2017-03-10 17:05:59.477	2017-03-10 17:05:59.477	10004	10166	User		<?xml version='1.0' encoding='UTF-8'?><root available-locales="en_US" default-locale="en_US"><Description language-id="en_US">Authenticated users should be assigned this role.</Description></root>	1	
1820d89b-f6c5-4945-bc3d-9e962a4451aa	10167	10155	10159		2017-03-10 17:05:59.54	2017-03-10 17:05:59.54	10004	10167	Organization Administrator		<?xml version='1.0' encoding='UTF-8'?><root available-locales="en_US" default-locale="en_US"><Description language-id="en_US">Organization Administrators are super users of their organization but cannot make other users into Organization Administrators.</Description></root>	3	
db280e5d-9300-425e-8d98-c623ae199d6b	10168	10155	10159		2017-03-10 17:05:59.546	2017-03-10 17:05:59.546	10004	10168	Organization Owner		<?xml version='1.0' encoding='UTF-8'?><root available-locales="en_US" default-locale="en_US"><Description language-id="en_US">Organization Owners are super users of their organization and can assign organization roles to users.</Description></root>	3	
dce094d5-924d-4960-b568-09281e0d9669	10169	10155	10159		2017-03-10 17:05:59.551	2017-03-10 17:05:59.551	10004	10169	Organization User		<?xml version='1.0' encoding='UTF-8'?><root available-locales="en_US" default-locale="en_US"><Description language-id="en_US">All users who belong to an organization have this role within that organization.</Description></root>	3	
38d53abf-2dfc-4538-be94-1e5c75971602	10170	10155	10159		2017-03-10 17:05:59.557	2017-03-10 17:05:59.557	10004	10170	Site Administrator		<?xml version='1.0' encoding='UTF-8'?><root available-locales="en_US" default-locale="en_US"><Description language-id="en_US">Site Administrators are super users of their site but cannot make other users into Site Administrators.</Description></root>	2	
5b8c20a4-6cff-4000-94dc-ef6ee7e3c19f	10171	10155	10159		2017-03-10 17:05:59.562	2017-03-10 17:05:59.562	10004	10171	Site Member		<?xml version='1.0' encoding='UTF-8'?><root available-locales="en_US" default-locale="en_US"><Description language-id="en_US">All users who belong to a site have this role within that site.</Description></root>	2	
a97dd499-961f-40d9-bf44-a35ddf14aa36	10172	10155	10159		2017-03-10 17:05:59.568	2017-03-10 17:05:59.568	10004	10172	Site Owner		<?xml version='1.0' encoding='UTF-8'?><root available-locales="en_US" default-locale="en_US"><Description language-id="en_US">Site Owners are super users of their site and can assign site roles to users.</Description></root>	2	
\.


--
-- Data for Name: scframeworkversi_scproductvers; Type: TABLE DATA; Schema: public; Owner: root
--

COPY scframeworkversi_scproductvers (frameworkversionid, productversionid) FROM stdin;
\.


--
-- Data for Name: scframeworkversion; Type: TABLE DATA; Schema: public; Owner: root
--

COPY scframeworkversion (frameworkversionid, groupid, companyid, userid, username, createdate, modifieddate, name, url, active_, priority) FROM stdin;
\.


--
-- Data for Name: sclicense; Type: TABLE DATA; Schema: public; Owner: root
--

COPY sclicense (licenseid, name, url, opensource, active_, recommended) FROM stdin;
\.


--
-- Data for Name: sclicenses_scproductentries; Type: TABLE DATA; Schema: public; Owner: root
--

COPY sclicenses_scproductentries (licenseid, productentryid) FROM stdin;
\.


--
-- Data for Name: scproductentry; Type: TABLE DATA; Schema: public; Owner: root
--

COPY scproductentry (productentryid, groupid, companyid, userid, username, createdate, modifieddate, name, type_, tags, shortdescription, longdescription, pageurl, author, repogroupid, repoartifactid) FROM stdin;
\.


--
-- Data for Name: scproductscreenshot; Type: TABLE DATA; Schema: public; Owner: root
--

COPY scproductscreenshot (productscreenshotid, companyid, groupid, productentryid, thumbnailid, fullimageid, priority) FROM stdin;
\.


--
-- Data for Name: scproductversion; Type: TABLE DATA; Schema: public; Owner: root
--

COPY scproductversion (productversionid, companyid, userid, username, createdate, modifieddate, productentryid, version, changelog, downloadpageurl, directdownloadurl, repostoreartifact) FROM stdin;
\.


--
-- Data for Name: servicecomponent; Type: TABLE DATA; Schema: public; Owner: root
--

COPY servicecomponent (servicecomponentid, buildnamespace, buildnumber, builddate, data_) FROM stdin;
10435	Marketplace	4	1410828214125	<?xml version="1.0"?>\n\n<data>\n\t<tables-sql><![CDATA[create table Marketplace_App (\n\tuuid_ VARCHAR(75) null,\n\tappId LONG not null primary key,\n\tcompanyId LONG,\n\tuserId LONG,\n\tuserName VARCHAR(75) null,\n\tcreateDate DATE null,\n\tmodifiedDate DATE null,\n\tremoteAppId LONG,\n\ttitle VARCHAR(75) null,\n\tdescription STRING null,\n\tcategory VARCHAR(75) null,\n\ticonURL STRING null,\n\tversion VARCHAR(75) null\n);\n\ncreate table Marketplace_Module (\n\tuuid_ VARCHAR(75) null,\n\tmoduleId LONG not null primary key,\n\tappId LONG,\n\tbundleSymbolicName VARCHAR(500) null,\n\tbundleVersion VARCHAR(75) null,\n\tcontextName VARCHAR(75) null\n);]]></tables-sql>\n\t<sequences-sql><![CDATA[]]></sequences-sql>\n\t<indexes-sql><![CDATA[create index IX_94A7EF25 on Marketplace_App (category);\ncreate index IX_865B7BD5 on Marketplace_App (companyId);\ncreate index IX_20F14D93 on Marketplace_App (remoteAppId);\ncreate index IX_3E667FE1 on Marketplace_App (uuid_);\ncreate index IX_A7807DA7 on Marketplace_App (uuid_, companyId);\n\ncreate index IX_7DC16D26 on Marketplace_Module (appId);\ncreate index IX_5848F52D on Marketplace_Module (appId, bundleSymbolicName, bundleVersion);\ncreate index IX_C6938724 on Marketplace_Module (appId, contextName);\ncreate index IX_DD03D499 on Marketplace_Module (bundleSymbolicName);\ncreate index IX_F2F1E964 on Marketplace_Module (contextName);\ncreate index IX_A7EFD80E on Marketplace_Module (uuid_);]]></indexes-sql>\n</data>
\.


--
-- Data for Name: shard; Type: TABLE DATA; Schema: public; Owner: root
--

COPY shard (shardid, classnameid, classpk, name) FROM stdin;
10156	10025	10155	default
\.


--
-- Data for Name: shoppingcart; Type: TABLE DATA; Schema: public; Owner: root
--

COPY shoppingcart (cartid, groupid, companyid, userid, username, createdate, modifieddate, itemids, couponcodes, altshipping, insure) FROM stdin;
\.


--
-- Data for Name: shoppingcategory; Type: TABLE DATA; Schema: public; Owner: root
--

COPY shoppingcategory (categoryid, groupid, companyid, userid, username, createdate, modifieddate, parentcategoryid, name, description) FROM stdin;
\.


--
-- Data for Name: shoppingcoupon; Type: TABLE DATA; Schema: public; Owner: root
--

COPY shoppingcoupon (couponid, groupid, companyid, userid, username, createdate, modifieddate, code_, name, description, startdate, enddate, active_, limitcategories, limitskus, minorder, discount, discounttype) FROM stdin;
\.


--
-- Data for Name: shoppingitem; Type: TABLE DATA; Schema: public; Owner: root
--

COPY shoppingitem (itemid, groupid, companyid, userid, username, createdate, modifieddate, categoryid, sku, name, description, properties, fields_, fieldsquantities, minquantity, maxquantity, price, discount, taxable, shipping, useshippingformula, requiresshipping, stockquantity, featured_, sale_, smallimage, smallimageid, smallimageurl, mediumimage, mediumimageid, mediumimageurl, largeimage, largeimageid, largeimageurl) FROM stdin;
\.


--
-- Data for Name: shoppingitemfield; Type: TABLE DATA; Schema: public; Owner: root
--

COPY shoppingitemfield (itemfieldid, itemid, name, values_, description) FROM stdin;
\.


--
-- Data for Name: shoppingitemprice; Type: TABLE DATA; Schema: public; Owner: root
--

COPY shoppingitemprice (itempriceid, itemid, minquantity, maxquantity, price, discount, taxable, shipping, useshippingformula, status) FROM stdin;
\.


--
-- Data for Name: shoppingorder; Type: TABLE DATA; Schema: public; Owner: root
--

COPY shoppingorder (orderid, groupid, companyid, userid, username, createdate, modifieddate, number_, tax, shipping, altshipping, requiresshipping, insure, insurance, couponcodes, coupondiscount, billingfirstname, billinglastname, billingemailaddress, billingcompany, billingstreet, billingcity, billingstate, billingzip, billingcountry, billingphone, shiptobilling, shippingfirstname, shippinglastname, shippingemailaddress, shippingcompany, shippingstreet, shippingcity, shippingstate, shippingzip, shippingcountry, shippingphone, ccname, cctype, ccnumber, ccexpmonth, ccexpyear, ccvernumber, comments, pptxnid, pppaymentstatus, pppaymentgross, ppreceiveremail, pppayeremail, sendorderemail, sendshippingemail) FROM stdin;
\.


--
-- Data for Name: shoppingorderitem; Type: TABLE DATA; Schema: public; Owner: root
--

COPY shoppingorderitem (orderitemid, orderid, itemid, sku, name, description, properties, price, quantity, shippeddate) FROM stdin;
\.


--
-- Data for Name: socialactivity; Type: TABLE DATA; Schema: public; Owner: root
--

COPY socialactivity (activityid, groupid, companyid, userid, createdate, activitysetid, mirroractivityid, classnameid, classpk, parentclassnameid, parentclasspk, type_, extradata, receiveruserid) FROM stdin;
1	10463	10155	10199	1489165732035	0	0	10109	10499	0	0	1	{"title":"<?xml version='1.0' encoding='UTF-8'?><root available-locales=\\"en_US\\" default-locale=\\"en_US\\"><Title language-id=\\"en_US\\">Web Content Title<\\/Title><\\/root>"}	0
\.


--
-- Data for Name: socialactivityachievement; Type: TABLE DATA; Schema: public; Owner: root
--

COPY socialactivityachievement (activityachievementid, groupid, companyid, userid, createdate, name, firstingroup) FROM stdin;
\.


--
-- Data for Name: socialactivitycounter; Type: TABLE DATA; Schema: public; Owner: root
--

COPY socialactivitycounter (activitycounterid, groupid, companyid, classnameid, classpk, name, ownertype, currentvalue, totalvalue, gracevalue, startperiod, endperiod, active_) FROM stdin;
\.


--
-- Data for Name: socialactivitylimit; Type: TABLE DATA; Schema: public; Owner: root
--

COPY socialactivitylimit (activitylimitid, groupid, companyid, userid, classnameid, classpk, activitytype, activitycountername, value) FROM stdin;
\.


--
-- Data for Name: socialactivityset; Type: TABLE DATA; Schema: public; Owner: root
--

COPY socialactivityset (activitysetid, groupid, companyid, userid, createdate, modifieddate, classnameid, classpk, type_, extradata, activitycount) FROM stdin;
\.


--
-- Data for Name: socialactivitysetting; Type: TABLE DATA; Schema: public; Owner: root
--

COPY socialactivitysetting (activitysettingid, groupid, companyid, classnameid, activitytype, name, value) FROM stdin;
\.


--
-- Data for Name: socialrelation; Type: TABLE DATA; Schema: public; Owner: root
--

COPY socialrelation (uuid_, relationid, companyid, createdate, userid1, userid2, type_) FROM stdin;
\.


--
-- Data for Name: socialrequest; Type: TABLE DATA; Schema: public; Owner: root
--

COPY socialrequest (uuid_, requestid, groupid, companyid, userid, createdate, modifieddate, classnameid, classpk, type_, extradata, receiveruserid, status) FROM stdin;
\.


--
-- Data for Name: subscription; Type: TABLE DATA; Schema: public; Owner: root
--

COPY subscription (subscriptionid, companyid, userid, username, createdate, modifieddate, classnameid, classpk, frequency) FROM stdin;
\.


--
-- Data for Name: systemevent; Type: TABLE DATA; Schema: public; Owner: root
--

COPY systemevent (systemeventid, groupid, companyid, userid, username, createdate, classnameid, classpk, classuuid, referrerclassnameid, parentsystemeventid, systemeventsetkey, type_, extradata) FROM stdin;
\.


--
-- Data for Name: team; Type: TABLE DATA; Schema: public; Owner: root
--

COPY team (teamid, companyid, userid, username, createdate, modifieddate, groupid, name, description) FROM stdin;
\.


--
-- Data for Name: ticket; Type: TABLE DATA; Schema: public; Owner: root
--

COPY ticket (ticketid, companyid, createdate, classnameid, classpk, key_, type_, extrainfo, expirationdate) FROM stdin;
\.


--
-- Data for Name: trashentry; Type: TABLE DATA; Schema: public; Owner: root
--

COPY trashentry (entryid, groupid, companyid, userid, username, createdate, classnameid, classpk, systemeventsetkey, typesettings, status) FROM stdin;
\.


--
-- Data for Name: trashversion; Type: TABLE DATA; Schema: public; Owner: root
--

COPY trashversion (versionid, entryid, classnameid, classpk, typesettings, status) FROM stdin;
\.


--
-- Data for Name: user_; Type: TABLE DATA; Schema: public; Owner: root
--

COPY user_ (uuid_, userid, companyid, createdate, modifieddate, defaultuser, contactid, password_, passwordencrypted, passwordreset, passwordmodifieddate, digest, reminderqueryquestion, reminderqueryanswer, gracelogincount, screenname, emailaddress, facebookid, ldapserverid, openid, portraitid, languageid, timezoneid, greeting, comments, firstname, middlename, lastname, jobtitle, logindate, loginip, lastlogindate, lastloginip, lastfailedlogindate, failedloginattempts, lockout, lockoutdate, agreedtotermsofuse, emailaddressverified, status) FROM stdin;
866290d7-1ca2-4cfc-8c64-c64cc5aa3729	10159	10155	2017-03-10 17:05:59.183	2017-03-10 17:05:59.183	t	10160	password	f	f	\N	5533ed38b5e33c076a804bb4bca644f9,3122172330a991cc1e9575c4f75428d4,3122172330a991cc1e9575c4f75428d4			0	10159	default@liferay.com	0	0		0	en_US	UTC	Welcome!						2017-03-10 17:05:59.183		\N		\N	0	f	\N	t	f	0
8c7993af-d36e-48a6-9f4e-e6b2ad708801	10199	10155	2017-03-10 17:06:00.789	2017-03-10 17:06:00.789	f	10200	AAAAoAAB9ADWlCsdNZbgbKVj/6NXYJA+KDIYQXK7mluwMypK	t	f	\N	e5d86c6f3672e52795891c3597f20de0,751da756639bc033b572ba2e7849b589,0d964023b6532e1cb17d96b98642eb31	what-is-your-father's-middle-name	test	0	test	test@liferay.com	0	-1		0	en_US	UTC	Welcome Test Test!		Test		Test		2017-03-10 17:06:55.027	127.0.0.1	2017-03-10 17:06:01.232	127.0.0.1	\N	0	f	\N	t	t	0
\.


--
-- Data for Name: usergroup; Type: TABLE DATA; Schema: public; Owner: root
--

COPY usergroup (uuid_, usergroupid, companyid, userid, username, createdate, modifieddate, parentusergroupid, name, description, addedbyldapimport) FROM stdin;
\.


--
-- Data for Name: usergroupgrouprole; Type: TABLE DATA; Schema: public; Owner: root
--

COPY usergroupgrouprole (usergroupid, groupid, roleid) FROM stdin;
\.


--
-- Data for Name: usergrouprole; Type: TABLE DATA; Schema: public; Owner: root
--

COPY usergrouprole (userid, groupid, roleid) FROM stdin;
10199	10457	10172
10199	10463	10172
\.


--
-- Data for Name: usergroups_teams; Type: TABLE DATA; Schema: public; Owner: root
--

COPY usergroups_teams (teamid, usergroupid) FROM stdin;
\.


--
-- Data for Name: useridmapper; Type: TABLE DATA; Schema: public; Owner: root
--

COPY useridmapper (useridmapperid, userid, type_, description, externaluserid) FROM stdin;
\.


--
-- Data for Name: usernotificationdelivery; Type: TABLE DATA; Schema: public; Owner: root
--

COPY usernotificationdelivery (usernotificationdeliveryid, companyid, userid, portletid, classnameid, notificationtype, deliverytype, deliver) FROM stdin;
\.


--
-- Data for Name: usernotificationevent; Type: TABLE DATA; Schema: public; Owner: root
--

COPY usernotificationevent (uuid_, usernotificationeventid, companyid, userid, type_, "timestamp", deliverby, delivered, payload, archived) FROM stdin;
\.


--
-- Data for Name: users_groups; Type: TABLE DATA; Schema: public; Owner: root
--

COPY users_groups (groupid, userid) FROM stdin;
10182	10199
10457	10199
10463	10199
\.


--
-- Data for Name: users_orgs; Type: TABLE DATA; Schema: public; Owner: root
--

COPY users_orgs (organizationid, userid) FROM stdin;
\.


--
-- Data for Name: users_roles; Type: TABLE DATA; Schema: public; Owner: root
--

COPY users_roles (roleid, userid) FROM stdin;
10163	10159
10166	10199
10162	10199
10165	10199
\.


--
-- Data for Name: users_teams; Type: TABLE DATA; Schema: public; Owner: root
--

COPY users_teams (teamid, userid) FROM stdin;
\.


--
-- Data for Name: users_usergroups; Type: TABLE DATA; Schema: public; Owner: root
--

COPY users_usergroups (userid, usergroupid) FROM stdin;
\.


--
-- Data for Name: usertracker; Type: TABLE DATA; Schema: public; Owner: root
--

COPY usertracker (usertrackerid, companyid, userid, modifieddate, sessionid, remoteaddr, remotehost, useragent) FROM stdin;
\.


--
-- Data for Name: usertrackerpath; Type: TABLE DATA; Schema: public; Owner: root
--

COPY usertrackerpath (usertrackerpathid, usertrackerid, path_, pathdate) FROM stdin;
\.


--
-- Data for Name: virtualhost; Type: TABLE DATA; Schema: public; Owner: root
--

COPY virtualhost (virtualhostid, companyid, layoutsetid, hostname) FROM stdin;
10158	10155	0	localhost
\.


--
-- Data for Name: webdavprops; Type: TABLE DATA; Schema: public; Owner: root
--

COPY webdavprops (webdavpropsid, companyid, createdate, modifieddate, classnameid, classpk, props) FROM stdin;
\.


--
-- Data for Name: website; Type: TABLE DATA; Schema: public; Owner: root
--

COPY website (uuid_, websiteid, companyid, userid, username, createdate, modifieddate, classnameid, classpk, url, typeid, primary_) FROM stdin;
\.


--
-- Data for Name: wikinode; Type: TABLE DATA; Schema: public; Owner: root
--

COPY wikinode (uuid_, nodeid, groupid, companyid, userid, username, createdate, modifieddate, name, description, lastpostdate, status, statusbyuserid, statusbyusername, statusdate) FROM stdin;
\.


--
-- Data for Name: wikipage; Type: TABLE DATA; Schema: public; Owner: root
--

COPY wikipage (uuid_, pageid, resourceprimkey, groupid, companyid, userid, username, createdate, modifieddate, nodeid, title, version, minoredit, content, summary, format, head, parenttitle, redirecttitle, status, statusbyuserid, statusbyusername, statusdate) FROM stdin;
\.


--
-- Data for Name: wikipageresource; Type: TABLE DATA; Schema: public; Owner: root
--

COPY wikipageresource (uuid_, resourceprimkey, nodeid, title) FROM stdin;
\.


--
-- Data for Name: workflowdefinitionlink; Type: TABLE DATA; Schema: public; Owner: root
--

COPY workflowdefinitionlink (workflowdefinitionlinkid, groupid, companyid, userid, username, createdate, modifieddate, classnameid, classpk, typepk, workflowdefinitionname, workflowdefinitionversion) FROM stdin;
\.


--
-- Data for Name: workflowinstancelink; Type: TABLE DATA; Schema: public; Owner: root
--

COPY workflowinstancelink (workflowinstancelinkid, groupid, companyid, userid, username, createdate, modifieddate, classnameid, classpk, workflowinstanceid) FROM stdin;
\.


--
-- Name: account__pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY account_
    ADD CONSTRAINT account__pkey PRIMARY KEY (accountid);


--
-- Name: address_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY address
    ADD CONSTRAINT address_pkey PRIMARY KEY (addressid);


--
-- Name: announcementsdelivery_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY announcementsdelivery
    ADD CONSTRAINT announcementsdelivery_pkey PRIMARY KEY (deliveryid);


--
-- Name: announcementsentry_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY announcementsentry
    ADD CONSTRAINT announcementsentry_pkey PRIMARY KEY (entryid);


--
-- Name: announcementsflag_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY announcementsflag
    ADD CONSTRAINT announcementsflag_pkey PRIMARY KEY (flagid);


--
-- Name: assetcategory_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY assetcategory
    ADD CONSTRAINT assetcategory_pkey PRIMARY KEY (categoryid);


--
-- Name: assetcategoryproperty_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY assetcategoryproperty
    ADD CONSTRAINT assetcategoryproperty_pkey PRIMARY KEY (categorypropertyid);


--
-- Name: assetentries_assetcategories_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY assetentries_assetcategories
    ADD CONSTRAINT assetentries_assetcategories_pkey PRIMARY KEY (categoryid, entryid);


--
-- Name: assetentries_assettags_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY assetentries_assettags
    ADD CONSTRAINT assetentries_assettags_pkey PRIMARY KEY (entryid, tagid);


--
-- Name: assetentry_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY assetentry
    ADD CONSTRAINT assetentry_pkey PRIMARY KEY (entryid);


--
-- Name: assetlink_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY assetlink
    ADD CONSTRAINT assetlink_pkey PRIMARY KEY (linkid);


--
-- Name: assettag_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY assettag
    ADD CONSTRAINT assettag_pkey PRIMARY KEY (tagid);


--
-- Name: assettagproperty_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY assettagproperty
    ADD CONSTRAINT assettagproperty_pkey PRIMARY KEY (tagpropertyid);


--
-- Name: assettagstats_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY assettagstats
    ADD CONSTRAINT assettagstats_pkey PRIMARY KEY (tagstatsid);


--
-- Name: assetvocabulary_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY assetvocabulary
    ADD CONSTRAINT assetvocabulary_pkey PRIMARY KEY (vocabularyid);


--
-- Name: backgroundtask_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY backgroundtask
    ADD CONSTRAINT backgroundtask_pkey PRIMARY KEY (backgroundtaskid);


--
-- Name: blogsentry_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY blogsentry
    ADD CONSTRAINT blogsentry_pkey PRIMARY KEY (entryid);


--
-- Name: blogsstatsuser_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY blogsstatsuser
    ADD CONSTRAINT blogsstatsuser_pkey PRIMARY KEY (statsuserid);


--
-- Name: bookmarksentry_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY bookmarksentry
    ADD CONSTRAINT bookmarksentry_pkey PRIMARY KEY (entryid);


--
-- Name: bookmarksfolder_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY bookmarksfolder
    ADD CONSTRAINT bookmarksfolder_pkey PRIMARY KEY (folderid);


--
-- Name: browsertracker_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY browsertracker
    ADD CONSTRAINT browsertracker_pkey PRIMARY KEY (browsertrackerid);


--
-- Name: calevent_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY calevent
    ADD CONSTRAINT calevent_pkey PRIMARY KEY (eventid);


--
-- Name: classname__pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY classname_
    ADD CONSTRAINT classname__pkey PRIMARY KEY (classnameid);


--
-- Name: clustergroup_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY clustergroup
    ADD CONSTRAINT clustergroup_pkey PRIMARY KEY (clustergroupid);


--
-- Name: company_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY company
    ADD CONSTRAINT company_pkey PRIMARY KEY (companyid);


--
-- Name: contact__pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY contact_
    ADD CONSTRAINT contact__pkey PRIMARY KEY (contactid);


--
-- Name: counter_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY counter
    ADD CONSTRAINT counter_pkey PRIMARY KEY (name);


--
-- Name: country_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY country
    ADD CONSTRAINT country_pkey PRIMARY KEY (countryid);


--
-- Name: cyrususer_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY cyrususer
    ADD CONSTRAINT cyrususer_pkey PRIMARY KEY (userid);


--
-- Name: cyrusvirtual_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY cyrusvirtual
    ADD CONSTRAINT cyrusvirtual_pkey PRIMARY KEY (emailaddress);


--
-- Name: ddlrecord_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY ddlrecord
    ADD CONSTRAINT ddlrecord_pkey PRIMARY KEY (recordid);


--
-- Name: ddlrecordset_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY ddlrecordset
    ADD CONSTRAINT ddlrecordset_pkey PRIMARY KEY (recordsetid);


--
-- Name: ddlrecordversion_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY ddlrecordversion
    ADD CONSTRAINT ddlrecordversion_pkey PRIMARY KEY (recordversionid);


--
-- Name: ddmcontent_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY ddmcontent
    ADD CONSTRAINT ddmcontent_pkey PRIMARY KEY (contentid);


--
-- Name: ddmstoragelink_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY ddmstoragelink
    ADD CONSTRAINT ddmstoragelink_pkey PRIMARY KEY (storagelinkid);


--
-- Name: ddmstructure_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY ddmstructure
    ADD CONSTRAINT ddmstructure_pkey PRIMARY KEY (structureid);


--
-- Name: ddmstructurelink_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY ddmstructurelink
    ADD CONSTRAINT ddmstructurelink_pkey PRIMARY KEY (structurelinkid);


--
-- Name: ddmtemplate_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY ddmtemplate
    ADD CONSTRAINT ddmtemplate_pkey PRIMARY KEY (templateid);


--
-- Name: dlcontent_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY dlcontent
    ADD CONSTRAINT dlcontent_pkey PRIMARY KEY (contentid);


--
-- Name: dlfileentry_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY dlfileentry
    ADD CONSTRAINT dlfileentry_pkey PRIMARY KEY (fileentryid);


--
-- Name: dlfileentrymetadata_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY dlfileentrymetadata
    ADD CONSTRAINT dlfileentrymetadata_pkey PRIMARY KEY (fileentrymetadataid);


--
-- Name: dlfileentrytype_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY dlfileentrytype
    ADD CONSTRAINT dlfileentrytype_pkey PRIMARY KEY (fileentrytypeid);


--
-- Name: dlfileentrytypes_ddmstructures_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY dlfileentrytypes_ddmstructures
    ADD CONSTRAINT dlfileentrytypes_ddmstructures_pkey PRIMARY KEY (structureid, fileentrytypeid);


--
-- Name: dlfileentrytypes_dlfolders_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY dlfileentrytypes_dlfolders
    ADD CONSTRAINT dlfileentrytypes_dlfolders_pkey PRIMARY KEY (fileentrytypeid, folderid);


--
-- Name: dlfilerank_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY dlfilerank
    ADD CONSTRAINT dlfilerank_pkey PRIMARY KEY (filerankid);


--
-- Name: dlfileshortcut_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY dlfileshortcut
    ADD CONSTRAINT dlfileshortcut_pkey PRIMARY KEY (fileshortcutid);


--
-- Name: dlfileversion_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY dlfileversion
    ADD CONSTRAINT dlfileversion_pkey PRIMARY KEY (fileversionid);


--
-- Name: dlfolder_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY dlfolder
    ADD CONSTRAINT dlfolder_pkey PRIMARY KEY (folderid);


--
-- Name: dlsyncevent_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY dlsyncevent
    ADD CONSTRAINT dlsyncevent_pkey PRIMARY KEY (synceventid);


--
-- Name: emailaddress_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY emailaddress
    ADD CONSTRAINT emailaddress_pkey PRIMARY KEY (emailaddressid);


--
-- Name: expandocolumn_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY expandocolumn
    ADD CONSTRAINT expandocolumn_pkey PRIMARY KEY (columnid);


--
-- Name: expandorow_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY expandorow
    ADD CONSTRAINT expandorow_pkey PRIMARY KEY (rowid_);


--
-- Name: expandotable_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY expandotable
    ADD CONSTRAINT expandotable_pkey PRIMARY KEY (tableid);


--
-- Name: expandovalue_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY expandovalue
    ADD CONSTRAINT expandovalue_pkey PRIMARY KEY (valueid);


--
-- Name: group__pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY group_
    ADD CONSTRAINT group__pkey PRIMARY KEY (groupid);


--
-- Name: groups_orgs_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY groups_orgs
    ADD CONSTRAINT groups_orgs_pkey PRIMARY KEY (groupid, organizationid);


--
-- Name: groups_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY groups_roles
    ADD CONSTRAINT groups_roles_pkey PRIMARY KEY (groupid, roleid);


--
-- Name: groups_usergroups_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY groups_usergroups
    ADD CONSTRAINT groups_usergroups_pkey PRIMARY KEY (groupid, usergroupid);


--
-- Name: image_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY image
    ADD CONSTRAINT image_pkey PRIMARY KEY (imageid);


--
-- Name: journalarticle_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY journalarticle
    ADD CONSTRAINT journalarticle_pkey PRIMARY KEY (id_);


--
-- Name: journalarticleimage_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY journalarticleimage
    ADD CONSTRAINT journalarticleimage_pkey PRIMARY KEY (articleimageid);


--
-- Name: journalarticleresource_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY journalarticleresource
    ADD CONSTRAINT journalarticleresource_pkey PRIMARY KEY (resourceprimkey);


--
-- Name: journalcontentsearch_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY journalcontentsearch
    ADD CONSTRAINT journalcontentsearch_pkey PRIMARY KEY (contentsearchid);


--
-- Name: journalfeed_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY journalfeed
    ADD CONSTRAINT journalfeed_pkey PRIMARY KEY (id_);


--
-- Name: journalfolder_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY journalfolder
    ADD CONSTRAINT journalfolder_pkey PRIMARY KEY (folderid);


--
-- Name: layout_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY layout
    ADD CONSTRAINT layout_pkey PRIMARY KEY (plid);


--
-- Name: layoutbranch_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY layoutbranch
    ADD CONSTRAINT layoutbranch_pkey PRIMARY KEY (layoutbranchid);


--
-- Name: layoutfriendlyurl_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY layoutfriendlyurl
    ADD CONSTRAINT layoutfriendlyurl_pkey PRIMARY KEY (layoutfriendlyurlid);


--
-- Name: layoutprototype_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY layoutprototype
    ADD CONSTRAINT layoutprototype_pkey PRIMARY KEY (layoutprototypeid);


--
-- Name: layoutrevision_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY layoutrevision
    ADD CONSTRAINT layoutrevision_pkey PRIMARY KEY (layoutrevisionid);


--
-- Name: layoutset_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY layoutset
    ADD CONSTRAINT layoutset_pkey PRIMARY KEY (layoutsetid);


--
-- Name: layoutsetbranch_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY layoutsetbranch
    ADD CONSTRAINT layoutsetbranch_pkey PRIMARY KEY (layoutsetbranchid);


--
-- Name: layoutsetprototype_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY layoutsetprototype
    ADD CONSTRAINT layoutsetprototype_pkey PRIMARY KEY (layoutsetprototypeid);


--
-- Name: listtype_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY listtype
    ADD CONSTRAINT listtype_pkey PRIMARY KEY (listtypeid);


--
-- Name: lock__pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY lock_
    ADD CONSTRAINT lock__pkey PRIMARY KEY (lockid);


--
-- Name: marketplace_app_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY marketplace_app
    ADD CONSTRAINT marketplace_app_pkey PRIMARY KEY (appid);


--
-- Name: marketplace_module_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY marketplace_module
    ADD CONSTRAINT marketplace_module_pkey PRIMARY KEY (moduleid);


--
-- Name: mbban_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY mbban
    ADD CONSTRAINT mbban_pkey PRIMARY KEY (banid);


--
-- Name: mbcategory_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY mbcategory
    ADD CONSTRAINT mbcategory_pkey PRIMARY KEY (categoryid);


--
-- Name: mbdiscussion_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY mbdiscussion
    ADD CONSTRAINT mbdiscussion_pkey PRIMARY KEY (discussionid);


--
-- Name: mbmailinglist_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY mbmailinglist
    ADD CONSTRAINT mbmailinglist_pkey PRIMARY KEY (mailinglistid);


--
-- Name: mbmessage_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY mbmessage
    ADD CONSTRAINT mbmessage_pkey PRIMARY KEY (messageid);


--
-- Name: mbstatsuser_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY mbstatsuser
    ADD CONSTRAINT mbstatsuser_pkey PRIMARY KEY (statsuserid);


--
-- Name: mbthread_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY mbthread
    ADD CONSTRAINT mbthread_pkey PRIMARY KEY (threadid);


--
-- Name: mbthreadflag_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY mbthreadflag
    ADD CONSTRAINT mbthreadflag_pkey PRIMARY KEY (threadflagid);


--
-- Name: mdraction_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY mdraction
    ADD CONSTRAINT mdraction_pkey PRIMARY KEY (actionid);


--
-- Name: mdrrule_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY mdrrule
    ADD CONSTRAINT mdrrule_pkey PRIMARY KEY (ruleid);


--
-- Name: mdrrulegroup_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY mdrrulegroup
    ADD CONSTRAINT mdrrulegroup_pkey PRIMARY KEY (rulegroupid);


--
-- Name: mdrrulegroupinstance_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY mdrrulegroupinstance
    ADD CONSTRAINT mdrrulegroupinstance_pkey PRIMARY KEY (rulegroupinstanceid);


--
-- Name: membershiprequest_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY membershiprequest
    ADD CONSTRAINT membershiprequest_pkey PRIMARY KEY (membershiprequestid);


--
-- Name: organization__pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY organization_
    ADD CONSTRAINT organization__pkey PRIMARY KEY (organizationid);


--
-- Name: orggrouprole_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY orggrouprole
    ADD CONSTRAINT orggrouprole_pkey PRIMARY KEY (organizationid, groupid, roleid);


--
-- Name: orglabor_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY orglabor
    ADD CONSTRAINT orglabor_pkey PRIMARY KEY (orglaborid);


--
-- Name: passwordpolicy_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY passwordpolicy
    ADD CONSTRAINT passwordpolicy_pkey PRIMARY KEY (passwordpolicyid);


--
-- Name: passwordpolicyrel_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY passwordpolicyrel
    ADD CONSTRAINT passwordpolicyrel_pkey PRIMARY KEY (passwordpolicyrelid);


--
-- Name: passwordtracker_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY passwordtracker
    ADD CONSTRAINT passwordtracker_pkey PRIMARY KEY (passwordtrackerid);


--
-- Name: phone_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY phone
    ADD CONSTRAINT phone_pkey PRIMARY KEY (phoneid);


--
-- Name: pluginsetting_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY pluginsetting
    ADD CONSTRAINT pluginsetting_pkey PRIMARY KEY (pluginsettingid);


--
-- Name: pollschoice_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY pollschoice
    ADD CONSTRAINT pollschoice_pkey PRIMARY KEY (choiceid);


--
-- Name: pollsquestion_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY pollsquestion
    ADD CONSTRAINT pollsquestion_pkey PRIMARY KEY (questionid);


--
-- Name: pollsvote_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY pollsvote
    ADD CONSTRAINT pollsvote_pkey PRIMARY KEY (voteid);


--
-- Name: portalpreferences_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY portalpreferences
    ADD CONSTRAINT portalpreferences_pkey PRIMARY KEY (portalpreferencesid);


--
-- Name: portlet_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY portlet
    ADD CONSTRAINT portlet_pkey PRIMARY KEY (id_);


--
-- Name: portletitem_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY portletitem
    ADD CONSTRAINT portletitem_pkey PRIMARY KEY (portletitemid);


--
-- Name: portletpreferences_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY portletpreferences
    ADD CONSTRAINT portletpreferences_pkey PRIMARY KEY (portletpreferencesid);


--
-- Name: quartz_blob_triggers_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY quartz_blob_triggers
    ADD CONSTRAINT quartz_blob_triggers_pkey PRIMARY KEY (sched_name, trigger_name, trigger_group);


--
-- Name: quartz_calendars_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY quartz_calendars
    ADD CONSTRAINT quartz_calendars_pkey PRIMARY KEY (sched_name, calendar_name);


--
-- Name: quartz_cron_triggers_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY quartz_cron_triggers
    ADD CONSTRAINT quartz_cron_triggers_pkey PRIMARY KEY (sched_name, trigger_name, trigger_group);


--
-- Name: quartz_fired_triggers_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY quartz_fired_triggers
    ADD CONSTRAINT quartz_fired_triggers_pkey PRIMARY KEY (sched_name, entry_id);


--
-- Name: quartz_job_details_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY quartz_job_details
    ADD CONSTRAINT quartz_job_details_pkey PRIMARY KEY (sched_name, job_name, job_group);


--
-- Name: quartz_locks_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY quartz_locks
    ADD CONSTRAINT quartz_locks_pkey PRIMARY KEY (sched_name, lock_name);


--
-- Name: quartz_paused_trigger_grps_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY quartz_paused_trigger_grps
    ADD CONSTRAINT quartz_paused_trigger_grps_pkey PRIMARY KEY (sched_name, trigger_group);


--
-- Name: quartz_scheduler_state_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY quartz_scheduler_state
    ADD CONSTRAINT quartz_scheduler_state_pkey PRIMARY KEY (sched_name, instance_name);


--
-- Name: quartz_simple_triggers_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY quartz_simple_triggers
    ADD CONSTRAINT quartz_simple_triggers_pkey PRIMARY KEY (sched_name, trigger_name, trigger_group);


--
-- Name: quartz_simprop_triggers_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY quartz_simprop_triggers
    ADD CONSTRAINT quartz_simprop_triggers_pkey PRIMARY KEY (sched_name, trigger_name, trigger_group);


--
-- Name: quartz_triggers_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY quartz_triggers
    ADD CONSTRAINT quartz_triggers_pkey PRIMARY KEY (sched_name, trigger_name, trigger_group);


--
-- Name: ratingsentry_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY ratingsentry
    ADD CONSTRAINT ratingsentry_pkey PRIMARY KEY (entryid);


--
-- Name: ratingsstats_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY ratingsstats
    ADD CONSTRAINT ratingsstats_pkey PRIMARY KEY (statsid);


--
-- Name: region_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY region
    ADD CONSTRAINT region_pkey PRIMARY KEY (regionid);


--
-- Name: release__pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY release_
    ADD CONSTRAINT release__pkey PRIMARY KEY (releaseid);


--
-- Name: repository_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY repository
    ADD CONSTRAINT repository_pkey PRIMARY KEY (repositoryid);


--
-- Name: repositoryentry_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY repositoryentry
    ADD CONSTRAINT repositoryentry_pkey PRIMARY KEY (repositoryentryid);


--
-- Name: resourceaction_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY resourceaction
    ADD CONSTRAINT resourceaction_pkey PRIMARY KEY (resourceactionid);


--
-- Name: resourceblock_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY resourceblock
    ADD CONSTRAINT resourceblock_pkey PRIMARY KEY (resourceblockid);


--
-- Name: resourceblockpermission_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY resourceblockpermission
    ADD CONSTRAINT resourceblockpermission_pkey PRIMARY KEY (resourceblockpermissionid);


--
-- Name: resourcepermission_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY resourcepermission
    ADD CONSTRAINT resourcepermission_pkey PRIMARY KEY (resourcepermissionid);


--
-- Name: resourcetypepermission_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY resourcetypepermission
    ADD CONSTRAINT resourcetypepermission_pkey PRIMARY KEY (resourcetypepermissionid);


--
-- Name: role__pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY role_
    ADD CONSTRAINT role__pkey PRIMARY KEY (roleid);


--
-- Name: scframeworkversi_scproductvers_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY scframeworkversi_scproductvers
    ADD CONSTRAINT scframeworkversi_scproductvers_pkey PRIMARY KEY (frameworkversionid, productversionid);


--
-- Name: scframeworkversion_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY scframeworkversion
    ADD CONSTRAINT scframeworkversion_pkey PRIMARY KEY (frameworkversionid);


--
-- Name: sclicense_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY sclicense
    ADD CONSTRAINT sclicense_pkey PRIMARY KEY (licenseid);


--
-- Name: sclicenses_scproductentries_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY sclicenses_scproductentries
    ADD CONSTRAINT sclicenses_scproductentries_pkey PRIMARY KEY (licenseid, productentryid);


--
-- Name: scproductentry_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY scproductentry
    ADD CONSTRAINT scproductentry_pkey PRIMARY KEY (productentryid);


--
-- Name: scproductscreenshot_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY scproductscreenshot
    ADD CONSTRAINT scproductscreenshot_pkey PRIMARY KEY (productscreenshotid);


--
-- Name: scproductversion_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY scproductversion
    ADD CONSTRAINT scproductversion_pkey PRIMARY KEY (productversionid);


--
-- Name: servicecomponent_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY servicecomponent
    ADD CONSTRAINT servicecomponent_pkey PRIMARY KEY (servicecomponentid);


--
-- Name: shard_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY shard
    ADD CONSTRAINT shard_pkey PRIMARY KEY (shardid);


--
-- Name: shoppingcart_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY shoppingcart
    ADD CONSTRAINT shoppingcart_pkey PRIMARY KEY (cartid);


--
-- Name: shoppingcategory_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY shoppingcategory
    ADD CONSTRAINT shoppingcategory_pkey PRIMARY KEY (categoryid);


--
-- Name: shoppingcoupon_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY shoppingcoupon
    ADD CONSTRAINT shoppingcoupon_pkey PRIMARY KEY (couponid);


--
-- Name: shoppingitem_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY shoppingitem
    ADD CONSTRAINT shoppingitem_pkey PRIMARY KEY (itemid);


--
-- Name: shoppingitemfield_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY shoppingitemfield
    ADD CONSTRAINT shoppingitemfield_pkey PRIMARY KEY (itemfieldid);


--
-- Name: shoppingitemprice_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY shoppingitemprice
    ADD CONSTRAINT shoppingitemprice_pkey PRIMARY KEY (itempriceid);


--
-- Name: shoppingorder_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY shoppingorder
    ADD CONSTRAINT shoppingorder_pkey PRIMARY KEY (orderid);


--
-- Name: shoppingorderitem_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY shoppingorderitem
    ADD CONSTRAINT shoppingorderitem_pkey PRIMARY KEY (orderitemid);


--
-- Name: socialactivity_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY socialactivity
    ADD CONSTRAINT socialactivity_pkey PRIMARY KEY (activityid);


--
-- Name: socialactivityachievement_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY socialactivityachievement
    ADD CONSTRAINT socialactivityachievement_pkey PRIMARY KEY (activityachievementid);


--
-- Name: socialactivitycounter_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY socialactivitycounter
    ADD CONSTRAINT socialactivitycounter_pkey PRIMARY KEY (activitycounterid);


--
-- Name: socialactivitylimit_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY socialactivitylimit
    ADD CONSTRAINT socialactivitylimit_pkey PRIMARY KEY (activitylimitid);


--
-- Name: socialactivityset_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY socialactivityset
    ADD CONSTRAINT socialactivityset_pkey PRIMARY KEY (activitysetid);


--
-- Name: socialactivitysetting_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY socialactivitysetting
    ADD CONSTRAINT socialactivitysetting_pkey PRIMARY KEY (activitysettingid);


--
-- Name: socialrelation_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY socialrelation
    ADD CONSTRAINT socialrelation_pkey PRIMARY KEY (relationid);


--
-- Name: socialrequest_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY socialrequest
    ADD CONSTRAINT socialrequest_pkey PRIMARY KEY (requestid);


--
-- Name: subscription_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY subscription
    ADD CONSTRAINT subscription_pkey PRIMARY KEY (subscriptionid);


--
-- Name: systemevent_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY systemevent
    ADD CONSTRAINT systemevent_pkey PRIMARY KEY (systemeventid);


--
-- Name: team_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY team
    ADD CONSTRAINT team_pkey PRIMARY KEY (teamid);


--
-- Name: ticket_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY ticket
    ADD CONSTRAINT ticket_pkey PRIMARY KEY (ticketid);


--
-- Name: trashentry_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY trashentry
    ADD CONSTRAINT trashentry_pkey PRIMARY KEY (entryid);


--
-- Name: trashversion_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY trashversion
    ADD CONSTRAINT trashversion_pkey PRIMARY KEY (versionid);


--
-- Name: user__pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY user_
    ADD CONSTRAINT user__pkey PRIMARY KEY (userid);


--
-- Name: usergroup_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY usergroup
    ADD CONSTRAINT usergroup_pkey PRIMARY KEY (usergroupid);


--
-- Name: usergroupgrouprole_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY usergroupgrouprole
    ADD CONSTRAINT usergroupgrouprole_pkey PRIMARY KEY (usergroupid, groupid, roleid);


--
-- Name: usergrouprole_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY usergrouprole
    ADD CONSTRAINT usergrouprole_pkey PRIMARY KEY (userid, groupid, roleid);


--
-- Name: usergroups_teams_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY usergroups_teams
    ADD CONSTRAINT usergroups_teams_pkey PRIMARY KEY (teamid, usergroupid);


--
-- Name: useridmapper_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY useridmapper
    ADD CONSTRAINT useridmapper_pkey PRIMARY KEY (useridmapperid);


--
-- Name: usernotificationdelivery_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY usernotificationdelivery
    ADD CONSTRAINT usernotificationdelivery_pkey PRIMARY KEY (usernotificationdeliveryid);


--
-- Name: usernotificationevent_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY usernotificationevent
    ADD CONSTRAINT usernotificationevent_pkey PRIMARY KEY (usernotificationeventid);


--
-- Name: users_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY users_groups
    ADD CONSTRAINT users_groups_pkey PRIMARY KEY (groupid, userid);


--
-- Name: users_orgs_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY users_orgs
    ADD CONSTRAINT users_orgs_pkey PRIMARY KEY (organizationid, userid);


--
-- Name: users_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY users_roles
    ADD CONSTRAINT users_roles_pkey PRIMARY KEY (roleid, userid);


--
-- Name: users_teams_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY users_teams
    ADD CONSTRAINT users_teams_pkey PRIMARY KEY (teamid, userid);


--
-- Name: users_usergroups_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY users_usergroups
    ADD CONSTRAINT users_usergroups_pkey PRIMARY KEY (userid, usergroupid);


--
-- Name: usertracker_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY usertracker
    ADD CONSTRAINT usertracker_pkey PRIMARY KEY (usertrackerid);


--
-- Name: usertrackerpath_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY usertrackerpath
    ADD CONSTRAINT usertrackerpath_pkey PRIMARY KEY (usertrackerpathid);


--
-- Name: virtualhost_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY virtualhost
    ADD CONSTRAINT virtualhost_pkey PRIMARY KEY (virtualhostid);


--
-- Name: webdavprops_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY webdavprops
    ADD CONSTRAINT webdavprops_pkey PRIMARY KEY (webdavpropsid);


--
-- Name: website_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY website
    ADD CONSTRAINT website_pkey PRIMARY KEY (websiteid);


--
-- Name: wikinode_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY wikinode
    ADD CONSTRAINT wikinode_pkey PRIMARY KEY (nodeid);


--
-- Name: wikipage_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY wikipage
    ADD CONSTRAINT wikipage_pkey PRIMARY KEY (pageid);


--
-- Name: wikipageresource_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY wikipageresource
    ADD CONSTRAINT wikipageresource_pkey PRIMARY KEY (resourceprimkey);


--
-- Name: workflowdefinitionlink_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY workflowdefinitionlink
    ADD CONSTRAINT workflowdefinitionlink_pkey PRIMARY KEY (workflowdefinitionlinkid);


--
-- Name: workflowinstancelink_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY workflowinstancelink
    ADD CONSTRAINT workflowinstancelink_pkey PRIMARY KEY (workflowinstancelinkid);


--
-- Name: ix_103d6207; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_103d6207 ON journalarticleimage USING btree (groupid, articleid, version, elinstanceid, elname, languageid);


--
-- Name: ix_1073ab9f; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_1073ab9f ON mbmessage USING btree (groupid, categoryid);


--
-- Name: ix_11641e26; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_11641e26 ON repository USING btree (uuid_, groupid);


--
-- Name: ix_119b5630; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_119b5630 ON shoppingorder USING btree (groupid, userid, pppaymentstatus);


--
-- Name: ix_11fb3e42; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_11fb3e42 ON region USING btree (countryid, active_);


--
-- Name: ix_12112599; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_12112599 ON pollsvote USING btree (questionid);


--
-- Name: ix_121ca3cb; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_121ca3cb ON socialactivity USING btree (receiveruserid);


--
-- Name: ix_12566ec2; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_12566ec2 ON company USING btree (mx);


--
-- Name: ix_1271f25f; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_1271f25f ON socialactivity USING btree (mirroractivityid);


--
-- Name: ix_127a35b0; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_127a35b0 ON ddmtemplate USING btree (smallimageid);


--
-- Name: ix_128516c8; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_128516c8 ON assetlink USING btree (entryid1);


--
-- Name: ix_12851a89; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_12851a89 ON assetlink USING btree (entryid2);


--
-- Name: ix_12a92145; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_12a92145 ON socialrelation USING btree (userid1, userid2, type_);


--
-- Name: ix_12b5e51d; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_12b5e51d ON portlet USING btree (companyid, portletid);


--
-- Name: ix_12ee4898; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_12ee4898 ON calevent USING btree (groupid);


--
-- Name: ix_13805bf7; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_13805bf7 ON assettagproperty USING btree (companyid, key_);


--
-- Name: ix_13984800; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_13984800 ON layoutrevision USING btree (layoutsetbranchid, layoutbranchid, plid);


--
-- Name: ix_1399d844; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_1399d844 ON dlfileentrytype USING btree (uuid_, groupid);


--
-- Name: ix_13c5cd3a; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_13c5cd3a ON lock_ USING btree (uuid_);


--
-- Name: ix_13df4e6d; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_13df4e6d ON mbcategory USING btree (uuid_, companyid);


--
-- Name: ix_143dc786; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_143dc786 ON team USING btree (groupid, name);


--
-- Name: ix_146382f2; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_146382f2 ON bookmarksentry USING btree (groupid, folderid, status);


--
-- Name: ix_14d5a20d; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_14d5a20d ON assetlink USING btree (entryid1, type_);


--
-- Name: ix_14d8bcc0; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_14d8bcc0 ON usertrackerpath USING btree (usertrackerid);


--
-- Name: ix_14f06a6b; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_14f06a6b ON announcementsentry USING btree (classnameid, classpk, alert);


--
-- Name: ix_158b526f; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_158b526f ON journalarticleimage USING btree (groupid, articleid, version);


--
-- Name: ix_16184d57; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_16184d57 ON ratingsentry USING btree (classnameid, classpk);


--
-- Name: ix_16218a38; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_16218a38 ON group_ USING btree (livegroupid);


--
-- Name: ix_16d87ca7; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_16d87ca7 ON region USING btree (countryid);


--
-- Name: ix_16e99b0a; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_16e99b0a ON wikipage USING btree (groupid, nodeid, head);


--
-- Name: ix_1725355c; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_1725355c ON wikipage USING btree (resourceprimkey, status);


--
-- Name: ix_17692b58; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_17692b58 ON ddmstructurelink USING btree (structureid);


--
-- Name: ix_17ee3098; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_17ee3098 ON dlfileshortcut USING btree (groupid, folderid, active_, status);


--
-- Name: ix_186442a4; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_186442a4 ON quartz_triggers USING btree (sched_name, trigger_name, trigger_group, trigger_state);


--
-- Name: ix_18d4bae5; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_18d4bae5 ON socialactivitylimit USING btree (groupid);


--
-- Name: ix_190483c6; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_190483c6 ON journalfolder USING btree (groupid, parentfolderid);


--
-- Name: ix_19da007b; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_19da007b ON country USING btree (name);


--
-- Name: ix_1a1b61d2; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_1a1b61d2 ON layout USING btree (groupid, privatelayout, type_);


--
-- Name: ix_1aa07a6d; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_1aa07a6d ON website USING btree (companyid, classnameid, classpk, primary_);


--
-- Name: ix_1aa75ce3; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_1aa75ce3 ON ddmtemplate USING btree (uuid_, groupid);


--
-- Name: ix_1ad93c16; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_1ad93c16 ON mbmessage USING btree (companyid, status);


--
-- Name: ix_1afbde08; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_1afbde08 ON announcementsentry USING btree (uuid_);


--
-- Name: ix_1b1040fd; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_1b1040fd ON blogsentry USING btree (uuid_, groupid);


--
-- Name: ix_1b2b8792; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_1b2b8792 ON assetvocabulary USING btree (uuid_, groupid);


--
-- Name: ix_1b7e3b67; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_1b7e3b67 ON socialactivitycounter USING btree (groupid, classnameid, classpk, name, ownertype, endperiod);


--
-- Name: ix_1b988d7a; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_1b988d7a ON usergrouprole USING btree (groupid);


--
-- Name: ix_1ba1f9dc; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_1ba1f9dc ON quartz_triggers USING btree (sched_name, trigger_group);


--
-- Name: ix_1bb072ca; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_1bb072ca ON emailaddress USING btree (companyid);


--
-- Name: ix_1bbfd4d3; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_1bbfd4d3 ON pollsvote USING btree (questionid, userid);


--
-- Name: ix_1bd3f4c; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_1bd3f4c ON expandovalue USING btree (tableid, classpk);


--
-- Name: ix_1c717ca6; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_1c717ca6 ON shoppingitem USING btree (companyid, sku);


--
-- Name: ix_1c841592; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_1c841592 ON sclicense USING btree (active_);


--
-- Name: ix_1cdf88c; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_1cdf88c ON usergroupgrouprole USING btree (roleid);


--
-- Name: ix_1d15553e; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_1d15553e ON shoppingorder USING btree (groupid);


--
-- Name: ix_1d731f03; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_1d731f03 ON user_ USING btree (companyid, facebookid);


--
-- Name: ix_1e5b9905; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_1e5b9905 ON workflowdefinitionlink USING btree (groupid, companyid, classnameid, classpk);


--
-- Name: ix_1e6464f5; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_1e6464f5 ON shoppingcategory USING btree (groupid, parentcategoryid);


--
-- Name: ix_1e9cf33b; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_1e9cf33b ON socialactivitysetting USING btree (groupid, classnameid, activitytype);


--
-- Name: ix_1e9d371d; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_1e9d371d ON assetentry USING btree (classnameid, classpk);


--
-- Name: ix_1eba6821; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_1eba6821 ON assetentry USING btree (groupid, classuuid);


--
-- Name: ix_1ecc7656; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_1ecc7656 ON wikipage USING btree (nodeid, redirecttitle);


--
-- Name: ix_1efd8ee9; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_1efd8ee9 ON blogsentry USING btree (groupid, status);


--
-- Name: ix_1f00c374; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_1f00c374 ON socialactivity USING btree (mirroractivityid, classnameid, classpk);


--
-- Name: ix_1f90ca2d; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_1f90ca2d ON bookmarksentry USING btree (companyid);


--
-- Name: ix_1f92813c; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_1f92813c ON quartz_triggers USING btree (sched_name, next_fire_time, misfire_instr);


--
-- Name: ix_1fe9c04; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_1fe9c04 ON dlfileentrymetadata USING btree (fileversionid);


--
-- Name: ix_2008facb; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_2008facb ON assetcategory USING btree (groupid, vocabularyid);


--
-- Name: ix_204d31e8; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_204d31e8 ON quartz_fired_triggers USING btree (sched_name, instance_name);


--
-- Name: ix_20962903; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_20962903 ON journalcontentsearch USING btree (groupid, privatelayout);


--
-- Name: ix_20a2e3d9; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_20a2e3d9 ON resourceblockpermission USING btree (roleid);


--
-- Name: ix_20f14d93; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_20f14d93 ON marketplace_app USING btree (remoteappid);


--
-- Name: ix_20fde04c; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_20fde04c ON ddmstructure USING btree (structurekey);


--
-- Name: ix_21277664; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_21277664 ON wikipageresource USING btree (nodeid, title);


--
-- Name: ix_2200aa69; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_2200aa69 ON resourcepermission USING btree (companyid, name, scope, primkey);


--
-- Name: ix_228562ad; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_228562ad ON lock_ USING btree (classname, key_);


--
-- Name: ix_22882d02; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_22882d02 ON journalarticle USING btree (groupid, urltitle);


--
-- Name: ix_22dab85c; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_22dab85c ON mdrrulegroupinstance USING btree (groupid, classnameid, classpk);


--
-- Name: ix_23325358; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_23325358 ON wikinode USING btree (groupid, status);


--
-- Name: ix_23922f7d; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_23922f7d ON layout USING btree (iconimageid);


--
-- Name: ix_23ead0d; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_23ead0d ON usergroup USING btree (companyid, name);


--
-- Name: ix_24f1bf0; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_24f1bf0 ON usernotificationevent USING btree (userid, delivered);


--
-- Name: ix_25c9d1f7; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_25c9d1f7 ON mdrrulegroupinstance USING btree (uuid_, companyid);


--
-- Name: ix_25d734cd; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_25d734cd ON country USING btree (active_);


--
-- Name: ix_26284944; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_26284944 ON resourcepermission USING btree (companyid, primkey);


--
-- Name: ix_2672f77f; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_2672f77f ON blogsentry USING btree (displaydate, status);


--
-- Name: ix_2674f2a8; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_2674f2a8 ON trashentry USING btree (companyid);


--
-- Name: ix_26cc761a; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_26cc761a ON group_ USING btree (uuid_, companyid);


--
-- Name: ix_26db26c5; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_26db26c5 ON role_ USING btree (uuid_);


--
-- Name: ix_27006638; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_27006638 ON sclicenses_scproductentries USING btree (licenseid);


--
-- Name: ix_270ba5e1; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_270ba5e1 ON ddlrecordset USING btree (uuid_, groupid);


--
-- Name: ix_272991fa; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_272991fa ON scframeworkversion USING btree (groupid);


--
-- Name: ix_276c8c13; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_276c8c13 ON bookmarksentry USING btree (companyid, status);


--
-- Name: ix_287b1f89; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_287b1f89 ON assetcategory USING btree (vocabularyid);


--
-- Name: ix_28a49bb9; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_28a49bb9 ON bookmarksfolder USING btree (resourceblockid);


--
-- Name: ix_28c78d5c; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_28c78d5c ON blogsstatsuser USING btree (groupid, entrycount);


--
-- Name: ix_2932dd37; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_2932dd37 ON listtype USING btree (type_);


--
-- Name: ix_299639c6; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_299639c6 ON calevent USING btree (uuid_, companyid);


--
-- Name: ix_29ae81c4; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_29ae81c4 ON dlfileshortcut USING btree (uuid_, companyid);


--
-- Name: ix_29ba1cf5; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_29ba1cf5 ON usertracker USING btree (companyid);


--
-- Name: ix_29d0af28; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_29d0af28 ON dlfileentry USING btree (groupid, folderid, fileentrytypeid);


--
-- Name: ix_2a2468; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_2a2468 ON socialactivity USING btree (groupid);


--
-- Name: ix_2a2cb130; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_2a2cb130 ON emailaddress USING btree (companyid, classnameid, classpk, primary_);


--
-- Name: ix_2a3b68f6; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_2a3b68f6 ON mbban USING btree (uuid_, groupid);


--
-- Name: ix_2aba25d7; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_2aba25d7 ON bookmarksfolder USING btree (companyid);


--
-- Name: ix_2c1142e; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_2c1142e ON passwordpolicy USING btree (companyid, defaultpolicy);


--
-- Name: ix_2c418eae; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_2c418eae ON lock_ USING btree (uuid_, companyid);


--
-- Name: ix_2c42603e; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_2c42603e ON layoutbranch USING btree (layoutsetbranchid, plid);


--
-- Name: ix_2c61314e; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_2c61314e ON portletitem USING btree (groupid, portletid);


--
-- Name: ix_2c944354; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_2c944354 ON assettagproperty USING btree (tagid, key_);


--
-- Name: ix_2cd67c81; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_2cd67c81 ON wikipage USING btree (resourceprimkey, nodeid, version);


--
-- Name: ix_2ce4be84; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_2ce4be84 ON layout USING btree (uuid_, companyid);


--
-- Name: ix_2d4cc782; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_2d4cc782 ON resourceblock USING btree (companyid, name);


--
-- Name: ix_2d9a426f; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_2d9a426f ON region USING btree (active_);


--
-- Name: ix_2e1a92d4; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_2e1a92d4 ON subscription USING btree (companyid, userid, classnameid, classpk);


--
-- Name: ix_2e207659; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_2e207659 ON journalarticle USING btree (groupid, structureid);


--
-- Name: ix_2e4e3885; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_2e4e3885 ON assetentry USING btree (publishdate);


--
-- Name: ix_2ed82cad; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_2ed82cad ON assetentries_assettags USING btree (entryid);


--
-- Name: ix_2f4ddfe1; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_2f4ddfe1 ON ddlrecordversion USING btree (recordid);


--
-- Name: ix_2fcfe748; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_2fcfe748 ON backgroundtask USING btree (taskexecutorclassname, status);


--
-- Name: ix_301d024b; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_301d024b ON journalarticle USING btree (groupid, status);


--
-- Name: ix_30616aaa; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_30616aaa ON layoutprototype USING btree (companyid);


--
-- Name: ix_3103ef3d; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_3103ef3d ON groups_roles USING btree (roleid);


--
-- Name: ix_31079de8; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_31079de8 ON dlfileentry USING btree (uuid_, companyid);


--
-- Name: ix_314b621a; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_314b621a ON layoutrevision USING btree (layoutsetbranchid);


--
-- Name: ix_31817a62; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_31817a62 ON ddmstructure USING btree (classnameid);


--
-- Name: ix_31fb0b08; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_31fb0b08 ON usergroups_teams USING btree (teamid);


--
-- Name: ix_31fb749a; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_31fb749a ON groups_usergroups USING btree (groupid);


--
-- Name: ix_32292ed1; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_32292ed1 ON socialrequest USING btree (receiveruserid);


--
-- Name: ix_323df109; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_323df109 ON journalarticle USING btree (companyid, status);


--
-- Name: ix_3251af16; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_3251af16 ON shoppingcoupon USING btree (groupid);


--
-- Name: ix_326525d6; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_326525d6 ON layoutfriendlyurl USING btree (uuid_, groupid);


--
-- Name: ix_3269e180; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_3269e180 ON assettagproperty USING btree (tagid);


--
-- Name: ix_326f75bd; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_326f75bd ON passwordtracker USING btree (userid);


--
-- Name: ix_32a18526; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_32a18526 ON ddmstoragelink USING btree (uuid_);


--
-- Name: ix_32f83d16; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_32f83d16 ON ddmtemplate USING btree (classpk);


--
-- Name: ix_3321f142; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_3321f142 ON mbmessage USING btree (userid, classnameid, status);


--
-- Name: ix_33781904; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_33781904 ON mbthreadflag USING btree (userid, threadid);


--
-- Name: ix_339e078m; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_339e078m ON quartz_fired_triggers USING btree (sched_name, instance_name, requests_recovery);


--
-- Name: ix_33a4de38; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_33a4de38 ON mbdiscussion USING btree (classnameid, classpk);


--
-- Name: ix_33b8ce8d; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_33b8ce8d ON portletitem USING btree (groupid, portletid, name);


--
-- Name: ix_33bef579; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_33bef579 ON ddmtemplate USING btree (language);


--
-- Name: ix_33f49d16; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_33f49d16 ON journalarticle USING btree (resourceprimkey);


--
-- Name: ix_3463d95b; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_3463d95b ON journalarticle USING btree (uuid_, groupid);


--
-- Name: ix_348dc3b2; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_348dc3b2 ON dlfileshortcut USING btree (groupid, folderid, active_);


--
-- Name: ix_3504b8bc; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_3504b8bc ON socialactivity USING btree (userid);


--
-- Name: ix_354aa664; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_354aa664 ON repositoryentry USING btree (uuid_, groupid);


--
-- Name: ix_35a2db2f; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_35a2db2f ON journalfeed USING btree (groupid);


--
-- Name: ix_35aa8fa6; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_35aa8fa6 ON membershiprequest USING btree (groupid, userid, statusid);


--
-- Name: ix_35e3e7c6; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_35e3e7c6 ON company USING btree (system);


--
-- Name: ix_36a90ca7; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_36a90ca7 ON socialrequest USING btree (userid, classnameid, classpk, type_, receiveruserid);


--
-- Name: ix_374b35ae; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_374b35ae ON socialactivitycounter USING btree (groupid, classnameid, classpk, name, ownertype, startperiod);


--
-- Name: ix_37562284; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_37562284 ON expandotable USING btree (companyid, classnameid, name);


--
-- Name: ix_377858d2; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_377858d2 ON mbmessage USING btree (groupid, userid, status);


--
-- Name: ix_381e55da; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_381e55da ON address USING btree (uuid_);


--
-- Name: ix_384788cd; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_384788cd ON socialactivitysetting USING btree (groupid, activitytype);


--
-- Name: ix_384ab6f7; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_384ab6f7 ON ddlrecord USING btree (uuid_, companyid);


--
-- Name: ix_385e123e; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_385e123e ON mbmessage USING btree (groupid, categoryid, threadid, status);


--
-- Name: ix_38efe3fd; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_38efe3fd ON company USING btree (logoid);


--
-- Name: ix_38f0315; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_38f0315 ON dlfilerank USING btree (companyid, userid, fileentryid);


--
-- Name: ix_39031f51; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_39031f51 ON journalfeed USING btree (uuid_, groupid);


--
-- Name: ix_396d6b42; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_396d6b42 ON organization_ USING btree (uuid_);


--
-- Name: ix_39a18ecc; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_39a18ecc ON layout USING btree (sourceprototypelayoutuuid);


--
-- Name: ix_3a1e834e; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_3a1e834e ON user_ USING btree (companyid);


--
-- Name: ix_3a200b7b; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_3a200b7b ON mbthread USING btree (uuid_, groupid);


--
-- Name: ix_3a9c0626; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_3a9c0626 ON ddmcontent USING btree (uuid_, companyid);


--
-- Name: ix_3b51bb68; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_3b51bb68 ON journalarticleimage USING btree (groupid);


--
-- Name: ix_3b69160f; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_3b69160f ON groups_usergroups USING btree (usergroupid);


--
-- Name: ix_3bb93eca; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_3bb93eca ON scframeworkversi_scproductvers USING btree (frameworkversionid);


--
-- Name: ix_3c028c1e; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_3c028c1e ON journalarticle USING btree (groupid, layoutuuid);


--
-- Name: ix_3cc1ded2; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_3cc1ded2 ON dlfolder USING btree (uuid_, groupid);


--
-- Name: ix_3d070845; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_3d070845 ON journalarticle USING btree (companyid, version);


--
-- Name: ix_3d4af476; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_3d4af476 ON wikipage USING btree (nodeid, title, version);


--
-- Name: ix_3d8e1607; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_3d8e1607 ON dlsyncevent USING btree (modifiedtime);


--
-- Name: ix_3dbb361a; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_3dbb361a ON usernotificationevent USING btree (userid, archived);


--
-- Name: ix_3e2765fc; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_3e2765fc ON journalarticle USING btree (resourceprimkey, status);


--
-- Name: ix_3e5d78c4; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_3e5d78c4 ON usernotificationevent USING btree (userid);


--
-- Name: ix_3e667fe1; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_3e667fe1 ON marketplace_app USING btree (uuid_);


--
-- Name: ix_3f1ea19e; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_3f1ea19e ON journalarticle USING btree (layoutuuid);


--
-- Name: ix_3f9c2fa8; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_3f9c2fa8 ON socialrelation USING btree (userid2, type_);


--
-- Name: ix_3fbfa9f4; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_3fbfa9f4 ON passwordpolicy USING btree (companyid, name);


--
-- Name: ix_405cc0e; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_405cc0e ON user_ USING btree (uuid_, companyid);


--
-- Name: ix_40f94f68; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_40f94f68 ON wikipage USING btree (nodeid, head, redirecttitle, status);


--
-- Name: ix_4115ec7a; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_4115ec7a ON mbmailinglist USING btree (uuid_);


--
-- Name: ix_415a7007; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_415a7007 ON workflowinstancelink USING btree (groupid, companyid, classnameid, classpk);


--
-- Name: ix_416ad7d5; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_416ad7d5 ON bookmarksentry USING btree (groupid, status);


--
-- Name: ix_418e4522; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_418e4522 ON organization_ USING btree (companyid, parentorganizationid);


--
-- Name: ix_41a32e0d; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_41a32e0d ON useridmapper USING btree (type_, externaluserid);


--
-- Name: ix_41f6dc8a; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_41f6dc8a ON mbthread USING btree (categoryid, priority);


--
-- Name: ix_4257db85; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_4257db85 ON mbmessage USING btree (groupid, categoryid, status);


--
-- Name: ix_430d791f; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_430d791f ON blogsentry USING btree (companyid, displaydate);


--
-- Name: ix_431a3960; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_431a3960 ON virtualhost USING btree (hostname);


--
-- Name: ix_43261870; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_43261870 ON dlfileentry USING btree (groupid, userid);


--
-- Name: ix_432f0ab0; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_432f0ab0 ON wikipage USING btree (nodeid, head, status);


--
-- Name: ix_43395316; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_43395316 ON ddmstructure USING btree (groupid, parentstructureid);


--
-- Name: ix_43840eeb; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_43840eeb ON blogsstatsuser USING btree (groupid);


--
-- Name: ix_43a0f80f; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_43a0f80f ON journalarticle USING btree (groupid, userid, classnameid);


--
-- Name: ix_43e8286a; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_43e8286a ON layoutrevision USING btree (head, plid);


--
-- Name: ix_4460fa14; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_4460fa14 ON socialactivityset USING btree (classnameid, classpk, type_);


--
-- Name: ix_449a10b9; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_449a10b9 ON role_ USING btree (companyid);


--
-- Name: ix_4501fd9c; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_4501fd9c ON dlfileentrytype USING btree (groupid);


--
-- Name: ix_451d63ec; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_451d63ec ON journalarticle USING btree (resourceprimkey, indexable, status);


--
-- Name: ix_451e7ae3; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_451e7ae3 ON bookmarksfolder USING btree (uuid_);


--
-- Name: ix_4539a99c; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_4539a99c ON announcementsflag USING btree (userid, entryid, value);


--
-- Name: ix_46665cc4; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_46665cc4 ON mdrrulegroup USING btree (uuid_, groupid);


--
-- Name: ix_467956fd; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_467956fd ON scproductscreenshot USING btree (productentryid);


--
-- Name: ix_46b0ae8e; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_46b0ae8e ON usertracker USING btree (sessionid);


--
-- Name: ix_46eef3c8; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_46eef3c8 ON wikipage USING btree (nodeid, parenttitle);


--
-- Name: ix_4831ebe4; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_4831ebe4 ON dlfileshortcut USING btree (uuid_);


--
-- Name: ix_48550691; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_48550691 ON layoutset USING btree (groupid, privatelayout);


--
-- Name: ix_485f7e98; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_485f7e98 ON mbthread USING btree (groupid, categoryid, status);


--
-- Name: ix_48814bba; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_48814bba ON mbban USING btree (userid);


--
-- Name: ix_49c37475; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_49c37475 ON dlfolder USING btree (groupid, parentfolderid);


--
-- Name: ix_49d2dec4; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_49d2dec4 ON emailaddress USING btree (companyid, classnameid);


--
-- Name: ix_49d5872c; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_49d5872c ON socialrequest USING btree (uuid_);


--
-- Name: ix_49e15a23; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_49e15a23 ON blogsentry USING btree (groupid, userid, status);


--
-- Name: ix_49eb3118; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_49eb3118 ON expandorow USING btree (classpk);


--
-- Name: ix_4a4bb4ed; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_4a4bb4ed ON mbmessage USING btree (userid, classnameid, classpk, status);


--
-- Name: ix_4a527dd3; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_4a527dd3 ON orggrouprole USING btree (groupid);


--
-- Name: ix_4a84af43; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_4a84af43 ON layoutrevision USING btree (layoutsetbranchid, parentlayoutrevisionid, plid);


--
-- Name: ix_4ab3756; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_4ab3756 ON resourceblockpermission USING btree (resourceblockid);


--
-- Name: ix_4b52be89; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_4b52be89 ON socialrelation USING btree (userid1, type_);


--
-- Name: ix_4b7247f6; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_4b7247f6 ON dlfileshortcut USING btree (tofileentryid);


--
-- Name: ix_4bd722bm; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_4bd722bm ON quartz_fired_triggers USING btree (sched_name, trigger_group);


--
-- Name: ix_4bfabb9a; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_4bfabb9a ON dlfileversion USING btree (uuid_);


--
-- Name: ix_4cb1b2b4; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_4cb1b2b4 ON dlfileentry USING btree (companyid);


--
-- Name: ix_4d040680; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_4d040680 ON usergrouprole USING btree (userid, groupid);


--
-- Name: ix_4d06ad51; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_4d06ad51 ON users_teams USING btree (teamid);


--
-- Name: ix_4d37bb00; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_4d37bb00 ON assetcategory USING btree (uuid_);


--
-- Name: ix_4d5cd982; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_4d5cd982 ON journalarticle USING btree (groupid, articleid, status);


--
-- Name: ix_4e96195b; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_4e96195b ON dlfilerank USING btree (groupid, userid, active_);


--
-- Name: ix_4f0315b8; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_4f0315b8 ON servicecomponent USING btree (buildnamespace, buildnumber);


--
-- Name: ix_4f0f0ca7; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_4f0f0ca7 ON website USING btree (companyid, classnameid);


--
-- Name: ix_4f40fe5e; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_4f40fe5e ON dlfileentrymetadata USING btree (fileentryid);


--
-- Name: ix_4f4293f1; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_4f4293f1 ON mdrrule USING btree (rulegroupid);


--
-- Name: ix_4f841574; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_4f841574 ON mbban USING btree (uuid_, companyid);


--
-- Name: ix_4f973efe; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_4f973efe ON socialrequest USING btree (uuid_, groupid);


--
-- Name: ix_4fa5969f; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_4fa5969f ON ddlrecordset USING btree (groupid);


--
-- Name: ix_4fbac092; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_4fbac092 ON ddmstructure USING btree (companyid, classnameid);


--
-- Name: ix_4fddd2bf; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_4fddd2bf ON calevent USING btree (groupid, repeating);


--
-- Name: ix_5005e3af; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_5005e3af ON quartz_fired_triggers USING btree (sched_name, job_name, job_group);


--
-- Name: ix_50702693; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_50702693 ON assettagstats USING btree (classnameid);


--
-- Name: ix_507ba031; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_507ba031 ON blogsstatsuser USING btree (userid, lastpostdate);


--
-- Name: ix_50bf1038; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_50bf1038 ON ddmcontent USING btree (groupid);


--
-- Name: ix_50c36d79; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_50c36d79 ON journalfeed USING btree (uuid_);


--
-- Name: ix_50f1904a; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_50f1904a ON mbthread USING btree (groupid, categoryid, lastpostdate);


--
-- Name: ix_51437a01; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_51437a01 ON passwordpolicy USING btree (uuid_);


--
-- Name: ix_51556082; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_51556082 ON dlfolder USING btree (parentfolderid, name);


--
-- Name: ix_51a8d44d; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_51a8d44d ON mbmessage USING btree (classnameid, classpk);


--
-- Name: ix_51f087f4; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_51f087f4 ON pollsquestion USING btree (uuid_);


--
-- Name: ix_5200100c; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_5200100c ON bookmarksentry USING btree (groupid, folderid);


--
-- Name: ix_52340033; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_52340033 ON assetcategoryproperty USING btree (companyid, key_);


--
-- Name: ix_524fefce; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_524fefce ON usergroup USING btree (companyid);


--
-- Name: ix_5253b1fa; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_5253b1fa ON repository USING btree (groupid);


--
-- Name: ix_526a032a; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_526a032a ON trashentry USING btree (groupid);


--
-- Name: ix_5327bb79; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_5327bb79 ON sclicense USING btree (active_, recommended);


--
-- Name: ix_5391712; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_5391712 ON dlfileentry USING btree (groupid, folderid, name);


--
-- Name: ix_54101cc8; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_54101cc8 ON shoppingcart USING btree (userid);


--
-- Name: ix_54243afd; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_54243afd ON subscription USING btree (userid);


--
-- Name: ix_546f2d5c; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_546f2d5c ON wikipage USING btree (nodeid, status);


--
-- Name: ix_5477d431; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_5477d431 ON mbdiscussion USING btree (uuid_);


--
-- Name: ix_54f0ed65; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_54f0ed65 ON bookmarksfolder USING btree (uuid_, companyid);


--
-- Name: ix_54f89e1f; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_54f89e1f ON journalfolder USING btree (uuid_, companyid);


--
-- Name: ix_551a519f; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_551a519f ON emailaddress USING btree (companyid, classnameid, classpk);


--
-- Name: ix_557a639f; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_557a639f ON layoutprototype USING btree (companyid, active_);


--
-- Name: ix_55d44577; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_55d44577 ON trashversion USING btree (entryid);


--
-- Name: ix_55f58818; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_55f58818 ON assetvocabulary USING btree (uuid_);


--
-- Name: ix_55f63d98; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_55f63d98 ON layoutsetprototype USING btree (companyid);


--
-- Name: ix_561e44e9; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_561e44e9 ON ddlrecordset USING btree (uuid_);


--
-- Name: ix_56682cc4; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_56682cc4 ON assettagstats USING btree (tagid, classnameid);


--
-- Name: ix_56dab121; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_56dab121 ON ddlrecordset USING btree (groupid, recordsetkey);


--
-- Name: ix_56e0ab21; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_56e0ab21 ON assetlink USING btree (entryid1, entryid2);


--
-- Name: ix_579c63b0; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_579c63b0 ON backgroundtask USING btree (groupid, name, taskexecutorclassname, completed);


--
-- Name: ix_57ca9fec; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_57ca9fec ON mbmessage USING btree (uuid_, companyid);


--
-- Name: ix_57d82b06; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_57d82b06 ON dlsyncevent USING btree (typepk);


--
-- Name: ix_5848f52d; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_5848f52d ON marketplace_module USING btree (appid, bundlesymbolicname, bundleversion);


--
-- Name: ix_5849891c; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_5849891c ON mdrrulegroup USING btree (groupid);


--
-- Name: ix_59051329; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_59051329 ON layoutfriendlyurl USING btree (plid, friendlyurl);


--
-- Name: ix_5938c39f; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_5938c39f ON ddlrecordset USING btree (uuid_, companyid);


--
-- Name: ix_59f9ce5c; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_59f9ce5c ON mbmessage USING btree (userid, classnameid);


--
-- Name: ix_5a09e5d1; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_5a09e5d1 ON backgroundtask USING btree (groupid);


--
-- Name: ix_5a40cdcc; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_5a40cdcc ON socialrelation USING btree (userid1);


--
-- Name: ix_5a40d18d; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_5a40d18d ON socialrelation USING btree (userid2);


--
-- Name: ix_5aa68501; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_5aa68501 ON group_ USING btree (companyid, name);


--
-- Name: ix_5adbe171; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_5adbe171 ON user_ USING btree (contactid);


--
-- Name: ix_5b03e942; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_5b03e942 ON dlfileentrytype USING btree (uuid_, companyid);


--
-- Name: ix_5b153fb2; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_5b153fb2 ON mbmessage USING btree (groupid);


--
-- Name: ix_5b30f663; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_5b30f663 ON socialrelation USING btree (uuid_, companyid);


--
-- Name: ix_5b6bef5f; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_5b6bef5f ON dlfileentrytype USING btree (groupid, fileentrytypekey);


--
-- Name: ix_5bb6ad6c; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_5bb6ad6c ON dlfileentrytypes_dlfolders USING btree (fileentrytypeid);


--
-- Name: ix_5bc8b0d4; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_5bc8b0d4 ON address USING btree (userid);


--
-- Name: ix_5bddb872; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_5bddb872 ON group_ USING btree (companyid, friendlyurl);


--
-- Name: ix_5c3ff12a; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_5c3ff12a ON mbban USING btree (groupid);


--
-- Name: ix_5cce79c8; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_5cce79c8 ON calevent USING btree (uuid_, groupid);


--
-- Name: ix_5cd17502; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_5cd17502 ON journalarticle USING btree (groupid, folderid);


--
-- Name: ix_5d25244f; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_5d25244f ON scproductentry USING btree (companyid);


--
-- Name: ix_5d6fe3f0; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_5d6fe3f0 ON wikinode USING btree (companyid);


--
-- Name: ix_5d75499e; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_5d75499e ON group_ USING btree (companyid, parentgroupid);


--
-- Name: ix_5dc4bd39; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_5dc4bd39 ON wikipage USING btree (uuid_, companyid);


--
-- Name: ix_5de0be11; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_5de0be11 ON group_ USING btree (companyid, classnameid, livegroupid, name);


--
-- Name: ix_5e8307bb; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_5e8307bb ON blogsentry USING btree (uuid_, companyid);


--
-- Name: ix_5eb4e2fb; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_5eb4e2fb ON role_ USING btree (subtype);


--
-- Name: ix_5f1dd85a; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_5f1dd85a ON usergroup USING btree (uuid_);


--
-- Name: ix_5f615d3e; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_5f615d3e ON shoppingcategory USING btree (groupid);


--
-- Name: ix_5ff18552; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_5ff18552 ON layoutsetbranch USING btree (groupid, privatelayout, name);


--
-- Name: ix_5ff21ce6; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_5ff21ce6 ON wikipage USING btree (groupid, nodeid, title, head);


--
-- Name: ix_60b99860; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_60b99860 ON resourcepermission USING btree (companyid, name, scope);


--
-- Name: ix_60c8634c; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_60c8634c ON repository USING btree (groupid, name, portletid);


--
-- Name: ix_61171e99; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_61171e99 ON socialrelation USING btree (companyid);


--
-- Name: ix_615e9f7a; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_615e9f7a ON user_ USING btree (companyid, emailaddress);


--
-- Name: ix_621e19d; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_621e19d ON blogsentry USING btree (groupid, displaydate);


--
-- Name: ix_62ac101a; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_62ac101a ON socialactivityset USING btree (userid, classnameid, classpk, type_);


--
-- Name: ix_630a643b; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_630a643b ON trashversion USING btree (classnameid, classpk);


--
-- Name: ix_63a2aabd; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_63a2aabd ON group_ USING btree (companyid, site);


--
-- Name: ix_63bdfa69; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_63bdfa69 ON journalfolder USING btree (uuid_);


--
-- Name: ix_63ed2532; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_63ed2532 ON layoutprototype USING btree (uuid_, companyid);


--
-- Name: ix_64b1bc66; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_64b1bc66 ON socialactivity USING btree (companyid);


--
-- Name: ix_64f0fe40; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_64f0fe40 ON dlfileentry USING btree (uuid_);


--
-- Name: ix_65026705; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_65026705 ON journalfolder USING btree (groupid, parentfolderid, name);


--
-- Name: ix_65576cbc; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_65576cbc ON journalfeed USING btree (groupid, feedid);


--
-- Name: ix_657899a8; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_657899a8 ON ddmstructure USING btree (parentstructureid);


--
-- Name: ix_65e84af4; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_65e84af4 ON wikipage USING btree (nodeid, head, parenttitle);


--
-- Name: ix_6660b399; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_6660b399 ON pollschoice USING btree (uuid_);


--
-- Name: ix_66d496a3; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_66d496a3 ON contact_ USING btree (companyid);


--
-- Name: ix_66d70879; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_66d70879 ON membershiprequest USING btree (userid);


--
-- Name: ix_66ff2503; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_66ff2503 ON users_usergroups USING btree (usergroupid);


--
-- Name: ix_6838e427; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_6838e427 ON journalcontentsearch USING btree (groupid, articleid);


--
-- Name: ix_68c0f69c; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_68c0f69c ON journalarticle USING btree (groupid, articleid);


--
-- Name: ix_69157a4d; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_69157a4d ON blogsentry USING btree (uuid_);


--
-- Name: ix_69771487; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_69771487 ON usergroup USING btree (companyid, parentusergroupid);


--
-- Name: ix_69951a25; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_69951a25 ON mbban USING btree (banuserid);


--
-- Name: ix_6a6c1c85; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_6a6c1c85 ON ddlrecord USING btree (companyid);


--
-- Name: ix_6a83a66a; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_6a83a66a ON dlcontent USING btree (companyid, repositoryid);


--
-- Name: ix_6a925a4d; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_6a925a4d ON image USING btree (size_);


--
-- Name: ix_6af0d434; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_6af0d434 ON orglabor USING btree (organizationid);


--
-- Name: ix_6bbb7682; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_6bbb7682 ON groups_orgs USING btree (organizationid);


--
-- Name: ix_6c112d7c; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_6c112d7c ON wikinode USING btree (uuid_);


--
-- Name: ix_6c226433; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_6c226433 ON layoutbranch USING btree (layoutsetbranchid);


--
-- Name: ix_6c499099; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_6c499099 ON group_ USING btree (companyid, parentgroupid, site);


--
-- Name: ix_6c572dac; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_6c572dac ON scproductscreenshot USING btree (thumbnailid);


--
-- Name: ix_6caae2e8; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_6caae2e8 ON trashentry USING btree (groupid, createdate);


--
-- Name: ix_6d5f9b87; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_6d5f9b87 ON shoppingitemfield USING btree (itemid);


--
-- Name: ix_6de88b06; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_6de88b06 ON layout USING btree (groupid, privatelayout, parentlayoutid);


--
-- Name: ix_6e00a2ec; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_6e00a2ec ON dlfileentrytypes_dlfolders USING btree (folderid);


--
-- Name: ix_6e1764f; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_6e1764f ON scframeworkversion USING btree (groupid, active_);


--
-- Name: ix_6edb9600; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_6edb9600 ON announcementsdelivery USING btree (userid);


--
-- Name: ix_6ef03e4e; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_6ef03e4e ON user_ USING btree (companyid, defaultuser);


--
-- Name: ix_6f9ede9f; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_6f9ede9f ON socialactivitylimit USING btree (userid);


--
-- Name: ix_7020130f; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_7020130f ON scproductversion USING btree (directdownloadurl);


--
-- Name: ix_702d1ad5; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_702d1ad5 ON ddmstoragelink USING btree (classpk);


--
-- Name: ix_705b40ee; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_705b40ee ON workflowdefinitionlink USING btree (groupid, companyid, classnameid, classpk, typepk);


--
-- Name: ix_705f5aa3; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_705f5aa3 ON layout USING btree (groupid, privatelayout);


--
-- Name: ix_70da9ecb; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_70da9ecb ON layoutrevision USING btree (layoutsetbranchid, plid, status);


--
-- Name: ix_712bcd35; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_712bcd35 ON website USING btree (uuid_, companyid);


--
-- Name: ix_71520099; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_71520099 ON journalarticle USING btree (uuid_, companyid);


--
-- Name: ix_7162c27c; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_7162c27c ON layout USING btree (groupid, privatelayout, layoutid);


--
-- Name: ix_7171b2e8; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_7171b2e8 ON pluginsetting USING btree (companyid, pluginid, plugintype);


--
-- Name: ix_717b97e1; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_717b97e1 ON country USING btree (a2);


--
-- Name: ix_717b9ba2; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_717b9ba2 ON country USING btree (a3);


--
-- Name: ix_71cb1123; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_71cb1123 ON address USING btree (companyid, classnameid, classpk);


--
-- Name: ix_72394f8e; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_72394f8e ON usergroup USING btree (uuid_, companyid);


--
-- Name: ix_72bba8b7; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_72bba8b7 ON layoutset USING btree (layoutsetprototypeuuid);


--
-- Name: ix_72d58d37; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_72d58d37 ON trashversion USING btree (entryid, classnameid);


--
-- Name: ix_72d73d39; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_72d73d39 ON systemevent USING btree (groupid);


--
-- Name: ix_72ef6041; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_72ef6041 ON blogsentry USING btree (companyid);


--
-- Name: ix_72f87291; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_72f87291 ON scproductentry USING btree (groupid);


--
-- Name: ix_7306c60; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_7306c60 ON assetentry USING btree (companyid);


--
-- Name: ix_7311e812; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_7311e812 ON scproductentry USING btree (repogroupid, repoartifactid);


--
-- Name: ix_7332b44f; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_7332b44f ON dlfileentrymetadata USING btree (ddmstructureid, fileversionid);


--
-- Name: ix_7338606f; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_7338606f ON servicecomponent USING btree (buildnamespace);


--
-- Name: ix_73c52252; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_73c52252 ON usergroupgrouprole USING btree (usergroupid, groupid);


--
-- Name: ix_740c4d0c; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_740c4d0c ON user_ USING btree (companyid, createdate);


--
-- Name: ix_742dec1f; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_742dec1f ON journalfolder USING btree (groupid);


--
-- Name: ix_742ef04a; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_742ef04a ON layoutfriendlyurl USING btree (groupid);


--
-- Name: ix_74c17b04; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_74c17b04 ON repository USING btree (uuid_);


--
-- Name: ix_75267dca; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_75267dca ON groups_orgs USING btree (groupid);


--
-- Name: ix_754fbb1c; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_754fbb1c ON group_ USING btree (uuid_, groupid);


--
-- Name: ix_75638cdf; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_75638cdf ON backgroundtask USING btree (status);


--
-- Name: ix_75b95071; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_75b95071 ON mbmessage USING btree (threadid);


--
-- Name: ix_75be36ad; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_75be36ad ON mdraction USING btree (uuid_, groupid);


--
-- Name: ix_75d42ff9; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_75d42ff9 ON assetentry USING btree (expirationdate);


--
-- Name: ix_7609b2ae; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_7609b2ae ON wikinode USING btree (uuid_, groupid);


--
-- Name: ix_762adc7; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_762adc7 ON ddlrecordversion USING btree (recordid, status);


--
-- Name: ix_762f63c6; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_762f63c6 ON user_ USING btree (emailaddress);


--
-- Name: ix_76ce9cdd; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_76ce9cdd ON mbmailinglist USING btree (groupid, categoryid);


--
-- Name: ix_76f15d13; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_76f15d13 ON website USING btree (uuid_);


--
-- Name: ix_772ecde7; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_772ecde7 ON dlfileentry USING btree (fileentrytypeid);


--
-- Name: ix_779bca37; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_779bca37 ON quartz_job_details USING btree (sched_name, requests_recovery);


--
-- Name: ix_77bb5e9d; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_77bb5e9d ON mdraction USING btree (uuid_);


--
-- Name: ix_786d171a; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_786d171a ON subscription USING btree (companyid, classnameid, classpk);


--
-- Name: ix_791914fa; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_791914fa ON contact_ USING btree (classnameid, classpk);


--
-- Name: ix_79d0120b; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_79d0120b ON mbdiscussion USING btree (classnameid);


--
-- Name: ix_7a040c32; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_7a040c32 ON mbmessage USING btree (userid);


--
-- Name: ix_7a2f0ece; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_7a2f0ece ON systemevent USING btree (groupid, classnameid, classpk);


--
-- Name: ix_7a9ff471; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_7a9ff471 ON backgroundtask USING btree (groupid, taskexecutorclassname, completed);


--
-- Name: ix_7acc74c9; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_7acc74c9 ON journalcontentsearch USING btree (groupid, privatelayout, layoutid, portletid);


--
-- Name: ix_7b43cd8; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_7b43cd8 ON emailaddress USING btree (userid);


--
-- Name: ix_7b590a7a; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_7b590a7a ON group_ USING btree (type_, active_);


--
-- Name: ix_7bb1826b; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_7bb1826b ON assetcategory USING btree (parentcategoryid);


--
-- Name: ix_7c9e46ba; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_7c9e46ba ON assettag USING btree (groupid);


--
-- Name: ix_7cc7d73e; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_7cc7d73e ON journalcontentsearch USING btree (groupid, privatelayout, articleid);


--
-- Name: ix_7d81f66f; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_7d81f66f ON resourcetypepermission USING btree (companyid, name, roleid);


--
-- Name: ix_7d8e92b8; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_7d8e92b8 ON pollsvote USING btree (uuid_, companyid);


--
-- Name: ix_7dc16d26; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_7dc16d26 ON marketplace_module USING btree (appid);


--
-- Name: ix_7dea8df1; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_7dea8df1 ON mdrrule USING btree (uuid_, companyid);


--
-- Name: ix_7e264a0f; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_7e264a0f ON mbthread USING btree (uuid_);


--
-- Name: ix_7e757d70; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_7e757d70 ON backgroundtask USING btree (groupid, taskexecutorclassname, status);


--
-- Name: ix_7e965757; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_7e965757 ON mbdiscussion USING btree (uuid_, companyid);


--
-- Name: ix_7ef4ec0e; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_7ef4ec0e ON users_orgs USING btree (organizationid);


--
-- Name: ix_7f187e63; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_7f187e63 ON usergroups_teams USING btree (usergroupid);


--
-- Name: ix_7f26b2a6; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_7f26b2a6 ON mdrrulegroup USING btree (uuid_);


--
-- Name: ix_7f703619; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_7f703619 ON bookmarksfolder USING btree (groupid);


--
-- Name: ix_7ffae700; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_7ffae700 ON layoutrevision USING btree (layoutsetbranchid, status);


--
-- Name: ix_808a0036; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_808a0036 ON mdrrulegroupinstance USING btree (classnameid, classpk, rulegroupid);


--
-- Name: ix_80cc9508; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_80cc9508 ON portlet USING btree (companyid);


--
-- Name: ix_80f7a9c2; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_80f7a9c2 ON socialrequest USING btree (userid);


--
-- Name: ix_812ce07a; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_812ce07a ON phone USING btree (companyid, classnameid, classpk, primary_);


--
-- Name: ix_81776090; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_81776090 ON ddmstoragelink USING btree (structureid);


--
-- Name: ix_81a50303; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_81a50303 ON blogsentry USING btree (groupid);


--
-- Name: ix_81efbff5; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_81efbff5 ON expandorow USING btree (tableid, classpk);


--
-- Name: ix_81f2db09; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_81f2db09 ON resourceaction USING btree (name);


--
-- Name: ix_82254c25; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_82254c25 ON blogsstatsuser USING btree (groupid, userid);


--
-- Name: ix_824adc72; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_824adc72 ON ddmtemplate USING btree (groupid, classnameid, classpk);


--
-- Name: ix_82e39a0c; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_82e39a0c ON socialactivity USING btree (classnameid);


--
-- Name: ix_834bceb6; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_834bceb6 ON organization_ USING btree (companyid);


--
-- Name: ix_8373ec7c; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_8373ec7c ON dlfileentrytypes_ddmstructures USING btree (fileentrytypeid);


--
-- Name: ix_8377a211; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_8377a211 ON scproductversion USING btree (productentryid);


--
-- Name: ix_83ae56ab; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_83ae56ab ON layoutfriendlyurl USING btree (plid);


--
-- Name: ix_83e16f2f; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_83e16f2f ON socialactivityachievement USING btree (groupid, firstingroup);


--
-- Name: ix_84471fd2; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_84471fd2 ON groups_roles USING btree (groupid);


--
-- Name: ix_847f92b5; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_847f92b5 ON mbstatsuser USING btree (userid);


--
-- Name: ix_84ab0309; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_84ab0309 ON journalarticleresource USING btree (uuid_, groupid);


--
-- Name: ix_852ea801; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_852ea801 ON assetcategory USING btree (groupid, parentcategoryid, name, vocabularyid);


--
-- Name: ix_8571953e; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_8571953e ON dlfileshortcut USING btree (companyid, status);


--
-- Name: ix_85c52eec; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_85c52eec ON journalarticle USING btree (groupid, articleid, version);


--
-- Name: ix_85c7ebe2; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_85c7ebe2 ON ddmstructure USING btree (uuid_, groupid);


--
-- Name: ix_85e7cc76; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_85e7cc76 ON wikipage USING btree (resourceprimkey);


--
-- Name: ix_8654719f; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_8654719f ON assetcategoryproperty USING btree (companyid);


--
-- Name: ix_865b7bd5; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_865b7bd5 ON marketplace_app USING btree (companyid);


--
-- Name: ix_871412df; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_871412df ON usergrouprole USING btree (groupid, roleid);


--
-- Name: ix_87603842; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_87603842 ON assetcategory USING btree (groupid, parentcategoryid, vocabularyid);


--
-- Name: ix_87a6b599; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_87a6b599 ON ddlrecord USING btree (recordsetid);


--
-- Name: ix_88328984; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_88328984 ON quartz_job_details USING btree (sched_name, job_group);


--
-- Name: ix_887a2c95; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_887a2c95 ON usergrouprole USING btree (roleid);


--
-- Name: ix_887be56a; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_887be56a ON usergrouprole USING btree (userid);


--
-- Name: ix_88df994a; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_88df994a ON journalarticleresource USING btree (groupid, articleid);


--
-- Name: ix_89509087; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_89509087 ON user_ USING btree (companyid, openid);


--
-- Name: ix_899d3dfb; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_899d3dfb ON wikipage USING btree (uuid_, groupid);


--
-- Name: ix_89bedc4f; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_89bedc4f ON bookmarksentry USING btree (uuid_, companyid);


--
-- Name: ix_89ff8b06; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_89ff8b06 ON journalarticle USING btree (resourceprimkey, indexable);


--
-- Name: ix_8a13c634; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_8a13c634 ON mbban USING btree (uuid_);


--
-- Name: ix_8a1cc4b; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_8a1cc4b ON membershiprequest USING btree (groupid);


--
-- Name: ix_8aa50be1; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_8aa50be1 ON quartz_triggers USING btree (sched_name, job_group);


--
-- Name: ix_8abc4e3b; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_8abc4e3b ON mbban USING btree (groupid, banuserid);


--
-- Name: ix_8ae746ef; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_8ae746ef ON pollschoice USING btree (uuid_, companyid);


--
-- Name: ix_8b6e3ace; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_8b6e3ace ON usernotificationdelivery USING btree (userid, portletid, classnameid, notificationtype, deliverytype);


--
-- Name: ix_8bc2f891; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_8bc2f891 ON ddlrecord USING btree (uuid_);


--
-- Name: ix_8bd6bca7; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_8bd6bca7 ON release_ USING btree (servletcontextname);


--
-- Name: ix_8be5f230; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_8be5f230 ON socialactivitysetting USING btree (groupid);


--
-- Name: ix_8cace77b; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_8cace77b ON blogsentry USING btree (companyid, userid);


--
-- Name: ix_8cb0a24a; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_8cb0a24a ON mbthreadflag USING btree (threadid);


--
-- Name: ix_8ce8c0d9; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_8ce8c0d9 ON layout USING btree (groupid, privatelayout, sourceprototypelayoutuuid);


--
-- Name: ix_8d12316e; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_8d12316e ON mbmessage USING btree (uuid_, groupid);


--
-- Name: ix_8d42897c; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_8d42897c ON socialrequest USING btree (uuid_, companyid);


--
-- Name: ix_8d83d0ce; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_8d83d0ce ON resourcepermission USING btree (companyid, name, scope, primkey, roleid);


--
-- Name: ix_8daf8a35; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_8daf8a35 ON journalcontentsearch USING btree (portletid);


--
-- Name: ix_8deae14e; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_8deae14e ON journalarticle USING btree (groupid, templateid);


--
-- Name: ix_8e6da3a1; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_8e6da3a1 ON portletpreferences USING btree (portletid);


--
-- Name: ix_8e71167f; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_8e71167f ON portletitem USING btree (groupid, portletid, classnameid, name);


--
-- Name: ix_8e8710d9; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_8e8710d9 ON journalarticle USING btree (structureid);


--
-- Name: ix_8eb8c5ec; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_8eb8c5ec ON mbmessage USING btree (groupid, userid);


--
-- Name: ix_8ec3d2bc; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_8ec3d2bc ON layoutrevision USING btree (plid, status);


--
-- Name: ix_8f32dec9; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_8f32dec9 ON socialactivity USING btree (groupid, userid, createdate, classnameid, classpk, type_, receiveruserid);


--
-- Name: ix_8f542794; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_8f542794 ON assetlink USING btree (entryid1, entryid2, type_);


--
-- Name: ix_8f6408f0; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_8f6408f0 ON socialactivityachievement USING btree (groupid, name);


--
-- Name: ix_8f6c75d0; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_8f6c75d0 ON dlfileentry USING btree (folderid, name);


--
-- Name: ix_8fcb620e; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_8fcb620e ON address USING btree (uuid_, companyid);


--
-- Name: ix_8fee65f5; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_8fee65f5 ON passwordpolicy USING btree (companyid);


--
-- Name: ix_8ff5d6ea; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_8ff5d6ea ON layoutsetbranch USING btree (groupid);


--
-- Name: ix_9029e15a; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_9029e15a ON assetentry USING btree (visible);


--
-- Name: ix_902fd874; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_902fd874 ON dlfolder USING btree (groupid, parentfolderid, name);


--
-- Name: ix_903dc750; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_903dc750 ON shoppingitem USING btree (largeimageid);


--
-- Name: ix_90724726; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_90724726 ON dlfileentrytype USING btree (uuid_);


--
-- Name: ix_90800923; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_90800923 ON ddmtemplate USING btree (groupid, classnameid, classpk, type_);


--
-- Name: ix_90cda39a; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_90cda39a ON blogsstatsuser USING btree (companyid, entrycount);


--
-- Name: ix_9106f6ce; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_9106f6ce ON journalarticle USING btree (templateid);


--
-- Name: ix_9112a7a0; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_9112a7a0 ON expandovalue USING btree (rowid_);


--
-- Name: ix_9168e2c9; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_9168e2c9 ON mbstatsuser USING btree (groupid, userid);


--
-- Name: ix_9178fc71; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_9178fc71 ON layoutsetprototype USING btree (companyid, active_);


--
-- Name: ix_91ca7cce; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_91ca7cce ON quartz_triggers USING btree (sched_name, trigger_group, next_fire_time, trigger_state, misfire_instr);


--
-- Name: ix_91e78c35; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_91e78c35 ON journalarticle USING btree (groupid, classnameid, structureid);


--
-- Name: ix_91f132c; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_91f132c ON assetlink USING btree (entryid2, type_);


--
-- Name: ix_9207cb31; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_9207cb31 ON journalcontentsearch USING btree (articleid);


--
-- Name: ix_920cd8b1; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_920cd8b1 ON wikinode USING btree (groupid, name);


--
-- Name: ix_9226dbb4; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_9226dbb4 ON address USING btree (companyid, classnameid, classpk, primary_);


--
-- Name: ix_923bd178; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_923bd178 ON address USING btree (companyid, classnameid, classpk, mailing);


--
-- Name: ix_926cdd04; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_926cdd04 ON socialactivitycounter USING btree (groupid, classnameid, classpk, ownertype);


--
-- Name: ix_9329c9d6; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_9329c9d6 ON layoutrevision USING btree (plid);


--
-- Name: ix_9356f865; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_9356f865 ON journalarticle USING btree (groupid);


--
-- Name: ix_93cf8193; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_93cf8193 ON dlfileentry USING btree (groupid, folderid);


--
-- Name: ix_93d5ad4e; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_93d5ad4e ON address USING btree (companyid);


--
-- Name: ix_941ba8c3; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_941ba8c3 ON shard USING btree (name);


--
-- Name: ix_941e429c; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_941e429c ON wikipage USING btree (groupid, nodeid, status);


--
-- Name: ix_9464ca; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_9464ca ON assettagstats USING btree (tagid);


--
-- Name: ix_94a7ef25; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_94a7ef25 ON marketplace_app USING btree (category);


--
-- Name: ix_94d1054d; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_94d1054d ON wikipage USING btree (resourceprimkey, nodeid, status);


--
-- Name: ix_95135d1c; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_95135d1c ON socialrelation USING btree (companyid, type_);


--
-- Name: ix_95c0ea45; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_95c0ea45 ON mbthread USING btree (groupid);


--
-- Name: ix_95e9e44e; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_95e9e44e ON dlfileversion USING btree (uuid_, companyid);


--
-- Name: ix_967799c0; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_967799c0 ON bookmarksfolder USING btree (groupid, parentfolderid);


--
-- Name: ix_96bdd537; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_96bdd537 ON portletitem USING btree (groupid, classnameid);


--
-- Name: ix_96f07007; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_96f07007 ON website USING btree (companyid);


--
-- Name: ix_9782ad88; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_9782ad88 ON user_ USING btree (companyid, userid);


--
-- Name: ix_97dfa146; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_97dfa146 ON webdavprops USING btree (classnameid, classpk);


--
-- Name: ix_98cc0aab; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_98cc0aab ON backgroundtask USING btree (groupid, name, taskexecutorclassname);


--
-- Name: ix_98e6a9cb; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_98e6a9cb ON scproductentry USING btree (groupid, userid);


--
-- Name: ix_99108b6e; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_99108b6e ON quartz_triggers USING btree (sched_name, trigger_state);


--
-- Name: ix_997eedd2; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_997eedd2 ON wikipage USING btree (nodeid, title);


--
-- Name: ix_99da856; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_99da856 ON assetcategoryproperty USING btree (categoryid);


--
-- Name: ix_9a2d11b2; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_9a2d11b2 ON mbthread USING btree (groupid, categoryid);


--
-- Name: ix_9a53569; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_9a53569 ON phone USING btree (companyid, classnameid, classpk);


--
-- Name: ix_9bdcf489; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_9bdcf489 ON repositoryentry USING btree (repositoryid, mappedid);


--
-- Name: ix_9be30ddf; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_9be30ddf ON socialactivityset USING btree (groupid, userid, classnameid, type_);


--
-- Name: ix_9be769ed; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_9be769ed ON dlfileversion USING btree (groupid, folderid, title, version);


--
-- Name: ix_9c0e478f; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_9c0e478f ON wikipage USING btree (uuid_);


--
-- Name: ix_9c7eb9f; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_9c7eb9f ON announcementsflag USING btree (entryid);


--
-- Name: ix_9cbc6a39; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_9cbc6a39 ON mdrrulegroupinstance USING btree (uuid_, groupid);


--
-- Name: ix_9ce6e0fa; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_9ce6e0fa ON journalarticle USING btree (groupid, classnameid, classpk);


--
-- Name: ix_9d22151e; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_9d22151e ON socialactivitysetting USING btree (groupid, classnameid);


--
-- Name: ix_9d7c3b23; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_9d7c3b23 ON mbmessage USING btree (threadid, answer);


--
-- Name: ix_9d9cf70f; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_9d9cf70f ON bookmarksentry USING btree (groupid, userid, status);


--
-- Name: ix_9dc8e57; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_9dc8e57 ON mbmessage USING btree (threadid, status);


--
-- Name: ix_9ddd15ea; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_9ddd15ea ON assetcategory USING btree (parentcategoryid, name);


--
-- Name: ix_9ddd21e5; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_9ddd21e5 ON expandovalue USING btree (columnid, rowid_);


--
-- Name: ix_9e13f2de; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_9e13f2de ON socialactivityset USING btree (groupid);


--
-- Name: ix_9f704a14; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_9f704a14 ON phone USING btree (companyid);


--
-- Name: ix_9f7655da; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_9f7655da ON wikipage USING btree (nodeid, head, parenttitle, status);


--
-- Name: ix_9f80d54; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_9f80d54 ON layoutfriendlyurl USING btree (uuid_);


--
-- Name: ix_9ff342ea; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_9ff342ea ON pollsquestion USING btree (groupid);


--
-- Name: ix_a00a898f; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_a00a898f ON mbstatsuser USING btree (groupid);


--
-- Name: ix_a083d394; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_a083d394 ON virtualhost USING btree (companyid, layoutsetid);


--
-- Name: ix_a098efbf; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_a098efbf ON users_teams USING btree (userid);


--
-- Name: ix_a0a283f4; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_a0a283f4 ON dlfileversion USING btree (companyid, status);


--
-- Name: ix_a18034a4; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_a18034a4 ON user_ USING btree (portraitid);


--
-- Name: ix_a188f560; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_a188f560 ON assetentries_assetcategories USING btree (categoryid);


--
-- Name: ix_a19c89ff; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_a19c89ff ON systemevent USING btree (groupid, systemeventsetkey);


--
-- Name: ix_a1a8cb8b; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_a1a8cb8b ON ratingsentry USING btree (classnameid, classpk, score);


--
-- Name: ix_a2001730; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_a2001730 ON wikipage USING btree (format);


--
-- Name: ix_a2534ac2; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_a2534ac2 ON journalarticle USING btree (groupid, classnameid, layoutuuid);


--
-- Name: ix_a2635f5c; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_a2635f5c ON region USING btree (countryid, regioncode);


--
-- Name: ix_a28004b; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_a28004b ON mbthreadflag USING btree (userid);


--
-- Name: ix_a2e4afba; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_a2e4afba ON phone USING btree (companyid, classnameid);


--
-- Name: ix_a37a0588; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_a37a0588 ON resourcepermission USING btree (roleid);


--
-- Name: ix_a3b2a80c; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_a3b2a80c ON portletpreferences USING btree (ownertype, portletid);


--
-- Name: ix_a40b8bec; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_a40b8bec ON layoutset USING btree (groupid);


--
-- Name: ix_a44636c9; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_a44636c9 ON dlfileentrymetadata USING btree (fileentryid, fileversionid);


--
-- Name: ix_a4b9a23b; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_a4b9a23b ON socialactivitycounter USING btree (classnameid, classpk);


--
-- Name: ix_a4bb2e58; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_a4bb2e58 ON dlfileshortcut USING btree (companyid);


--
-- Name: ix_a4db1f0f; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_a4db1f0f ON workflowdefinitionlink USING btree (companyid, workflowdefinitionname, workflowdefinitionversion);


--
-- Name: ix_a5f57b61; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_a5f57b61 ON blogsentry USING btree (companyid, userid, status);


--
-- Name: ix_a65a1f8b; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_a65a1f8b ON dlfilerank USING btree (fileentryid);


--
-- Name: ix_a6bafdfe; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_a6bafdfe ON usernotificationevent USING btree (uuid_, companyid);


--
-- Name: ix_a6e99284; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_a6e99284 ON ratingsstats USING btree (classnameid, classpk);


--
-- Name: ix_a6ef0b81; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_a6ef0b81 ON announcementsentry USING btree (classnameid, classpk);


--
-- Name: ix_a6fc2b28; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_a6fc2b28 ON layoutfriendlyurl USING btree (groupid, privatelayout, friendlyurl, languageid);


--
-- Name: ix_a7038cd7; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_a7038cd7 ON mbmessage USING btree (threadid, parentmessageid);


--
-- Name: ix_a705ff94; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_a705ff94 ON layoutbranch USING btree (layoutsetbranchid, plid, master);


--
-- Name: ix_a73b688a; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_a73b688a ON backgroundtask USING btree (groupid, taskexecutorclassname);


--
-- Name: ix_a74db14c; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_a74db14c ON dlfolder USING btree (companyid);


--
-- Name: ix_a7807da7; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_a7807da7 ON marketplace_app USING btree (uuid_, companyid);


--
-- Name: ix_a7efd80e; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_a7efd80e ON marketplace_module USING btree (uuid_);


--
-- Name: ix_a82690e2; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_a82690e2 ON resourcetypepermission USING btree (roleid);


--
-- Name: ix_a853c757; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_a853c757 ON socialactivity USING btree (classnameid, classpk);


--
-- Name: ix_a85822a0; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_a85822a0 ON quartz_triggers USING btree (sched_name, job_name, job_group);


--
-- Name: ix_a88c673a; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_a88c673a ON pollsvote USING btree (uuid_, groupid);


--
-- Name: ix_a88e424e; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_a88e424e ON role_ USING btree (companyid, classnameid, classpk);


--
-- Name: ix_a8b0d276; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_a8b0d276 ON workflowdefinitionlink USING btree (companyid);


--
-- Name: ix_a8c0cbe8; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_a8c0cbe8 ON expandocolumn USING btree (tableid);


--
-- Name: ix_a90fe5a0; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_a90fe5a0 ON socialrequest USING btree (companyid);


--
-- Name: ix_a9ac086e; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_a9ac086e ON layoutrevision USING btree (layoutsetbranchid, head);


--
-- Name: ix_a9d85ba6; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_a9d85ba6 ON organization_ USING btree (uuid_, companyid);


--
-- Name: ix_aabc18e9; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_aabc18e9 ON socialactivityachievement USING btree (groupid, userid, firstingroup);


--
-- Name: ix_aac564d3; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_aac564d3 ON ddlrecord USING btree (recordsetid, userid);


--
-- Name: ix_ab044d1c; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_ab044d1c ON orggrouprole USING btree (roleid);


--
-- Name: ix_ab5906a8; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_ab5906a8 ON socialrequest USING btree (userid, status);


--
-- Name: ix_aba5cec2; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_aba5cec2 ON group_ USING btree (companyid);


--
-- Name: ix_abd7dac0; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_abd7dac0 ON address USING btree (companyid, classnameid);


--
-- Name: ix_abe2d54; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_abe2d54 ON group_ USING btree (companyid, classnameid, parentgroupid);


--
-- Name: ix_abeb6d07; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_abeb6d07 ON mbmessage USING btree (userid, classnameid, classpk);


--
-- Name: ix_ae4b50c2; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_ae4b50c2 ON ddmcontent USING btree (uuid_);


--
-- Name: ix_ae6e9907; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_ae6e9907 ON team USING btree (groupid);


--
-- Name: ix_ae8224cc; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_ae8224cc ON scproductscreenshot USING btree (fullimageid);


--
-- Name: ix_aedd9cb5; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_aedd9cb5 ON mbthread USING btree (lastpostdate, priority);


--
-- Name: ix_aeea209c; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_aeea209c ON resourceblock USING btree (companyid, groupid, name, permissionshash);


--
-- Name: ix_aff28547; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_aff28547 ON mdrrulegroupinstance USING btree (groupid);


--
-- Name: ix_b0051937; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_b0051937 ON dlfileshortcut USING btree (groupid, folderid);


--
-- Name: ix_b1432d30; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_b1432d30 ON mbmessage USING btree (companyid);


--
-- Name: ix_b15863fa; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_b15863fa ON socialactivitylimit USING btree (classnameid, classpk);


--
-- Name: ix_b185e980; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_b185e980 ON assetcategory USING btree (parentcategoryid, vocabularyid);


--
-- Name: ix_b1c33ea6; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_b1c33ea6 ON ddmtemplate USING btree (groupid, classpk);


--
-- Name: ix_b22d908c; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_b22d908c ON assetvocabulary USING btree (companyid);


--
-- Name: ix_b2468446; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_b2468446 ON ticket USING btree (key_);


--
-- Name: ix_b271fa88; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_b271fa88 ON phone USING btree (uuid_, companyid);


--
-- Name: ix_b27a301f; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_b27a301f ON classname_ USING btree (value);


--
-- Name: ix_b29fef17; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_b29fef17 ON expandovalue USING btree (classnameid, classpk);


--
-- Name: ix_b2a61b55; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_b2a61b55 ON assetentries_assettags USING btree (tagid);


--
-- Name: ix_b35f73d5; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_b35f73d5 ON trashentry USING btree (classnameid, classpk);


--
-- Name: ix_b3b318dc; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_b3b318dc ON journalcontentsearch USING btree (groupid, privatelayout, layoutid);


--
-- Name: ix_b4328f39; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_b4328f39 ON ddlrecord USING btree (uuid_, groupid);


--
-- Name: ix_b47e3c11; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_b47e3c11 ON ratingsentry USING btree (userid, classnameid, classpk);


--
-- Name: ix_b480a672; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_b480a672 ON wikinode USING btree (groupid);


--
-- Name: ix_b529bfd3; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_b529bfd3 ON layout USING btree (layoutprototypeuuid);


--
-- Name: ix_b54332d6; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_b54332d6 ON wikinode USING btree (companyid, status);


--
-- Name: ix_b584b5cc; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_b584b5cc ON group_ USING btree (companyid, classnameid);


--
-- Name: ix_b5ae8a85; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_b5ae8a85 ON expandotable USING btree (companyid, classnameid);


--
-- Name: ix_b5c9c690; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_b5c9c690 ON socialrelation USING btree (userid1, userid2);


--
-- Name: ix_b5ca2dc; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_b5ca2dc ON mbdiscussion USING btree (threadid);


--
-- Name: ix_b5f82c7a; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_b5f82c7a ON shoppingorderitem USING btree (orderid);


--
-- Name: ix_b6356f93; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_b6356f93 ON ddmtemplate USING btree (classnameid, classpk, type_);


--
-- Name: ix_b670ba39; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_b670ba39 ON bookmarksentry USING btree (uuid_);


--
-- Name: ix_b674ab58; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_b674ab58 ON mbmessage USING btree (groupid, categoryid, threadid);


--
-- Name: ix_b6a6bd91; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_b6a6bd91 ON mdrrulegroupinstance USING btree (uuid_);


--
-- Name: ix_b6b8ca0e; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_b6b8ca0e ON assetvocabulary USING btree (groupid);


--
-- Name: ix_b6ed5e50; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_b6ed5e50 ON ddmstructure USING btree (groupid, classnameid);


--
-- Name: ix_b6ee8c9e; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_b6ee8c9e ON workflowdefinitionlink USING btree (groupid, companyid, classnameid);


--
-- Name: ix_b7034b27; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_b7034b27 ON repositoryentry USING btree (repositoryid);


--
-- Name: ix_b71e92d5; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_b71e92d5 ON expandovalue USING btree (tableid, rowid_);


--
-- Name: ix_b771d67; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_b771d67 ON wikipage USING btree (resourceprimkey, nodeid);


--
-- Name: ix_b7b914e5; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_b7b914e5 ON layoutrevision USING btree (layoutsetbranchid, plid);


--
-- Name: ix_b8c28c53; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_b8c28c53 ON contact_ USING btree (accountid);


--
-- Name: ix_b9746445; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_b9746445 ON pluginsetting USING btree (companyid);


--
-- Name: ix_b9b1506; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_b9b1506 ON repositoryentry USING btree (uuid_);


--
-- Name: ix_b9ff6043; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_b9ff6043 ON role_ USING btree (uuid_, companyid);


--
-- Name: ix_ba4413d5; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_ba4413d5 ON announcementsdelivery USING btree (userid, type_);


--
-- Name: ix_ba497163; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_ba497163 ON resourcetypepermission USING btree (companyid, groupid, name, roleid);


--
-- Name: ix_ba72b89a; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_ba72b89a ON wikipage USING btree (groupid, nodeid, head, parenttitle, status);


--
-- Name: ix_bafb116e; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_bafb116e ON dlfilerank USING btree (groupid, userid);


--
-- Name: ix_bb0c2905; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_bb0c2905 ON blogsentry USING btree (companyid, displaydate, status);


--
-- Name: ix_bb51f1d9; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_bb51f1d9 ON blogsstatsuser USING btree (userid);


--
-- Name: ix_bb870c11; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_bb870c11 ON mbcategory USING btree (groupid);


--
-- Name: ix_bbaf6928; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_bbaf6928 ON assetcategory USING btree (uuid_, companyid);


--
-- Name: ix_bbca55b; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_bbca55b ON group_ USING btree (companyid, livegroupid, name);


--
-- Name: ix_bc2c4231; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_bc2c4231 ON layout USING btree (groupid, privatelayout, friendlyurl);


--
-- Name: ix_bc2e7e6a; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_bc2e7e6a ON dlfileentry USING btree (uuid_, groupid);


--
-- Name: ix_bc2f03b0; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_bc2f03b0 ON quartz_fired_triggers USING btree (sched_name, job_group);


--
-- Name: ix_bc735dcf; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_bc735dcf ON mbcategory USING btree (companyid);


--
-- Name: ix_bcfda257; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_bcfda257 ON user_ USING btree (companyid, createdate, modifieddate);


--
-- Name: ix_bd9a4a91; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_bd9a4a91 ON ddmtemplate USING btree (groupid, classnameid);


--
-- Name: ix_be3835e5; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_be3835e5 ON quartz_fired_triggers USING btree (sched_name, trigger_name, trigger_group);


--
-- Name: ix_be4df2bf; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_be4df2bf ON assetcategory USING btree (parentcategoryid, name, vocabularyid);


--
-- Name: ix_be8102d6; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_be8102d6 ON users_usergroups USING btree (userid);


--
-- Name: ix_be898221; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_be898221 ON wikipageresource USING btree (uuid_);


--
-- Name: ix_bea33ab8; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_bea33ab8 ON wikipage USING btree (nodeid, title, status);


--
-- Name: ix_bf3e642b; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_bf3e642b ON mdrrulegroupinstance USING btree (rulegroupid);


--
-- Name: ix_bfeb984f; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_bfeb984f ON mbmailinglist USING btree (active_);


--
-- Name: ix_c07cc7f8; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_c07cc7f8 ON backgroundtask USING btree (name);


--
-- Name: ix_c099d61a; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_c099d61a ON layout USING btree (groupid);


--
-- Name: ix_c0aad74d; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_c0aad74d ON assetvocabulary USING btree (groupid, name);


--
-- Name: ix_c19e5f31; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_c19e5f31 ON users_roles USING btree (roleid);


--
-- Name: ix_c1a01806; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_c1a01806 ON users_roles USING btree (userid);


--
-- Name: ix_c1ad2122; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_c1ad2122 ON calevent USING btree (uuid_);


--
-- Name: ix_c222bd31; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_c222bd31 ON pollschoice USING btree (uuid_, groupid);


--
-- Name: ix_c2626edb; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_c2626edb ON mbcategory USING btree (uuid_);


--
-- Name: ix_c27c9dbd; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_c27c9dbd ON bookmarksfolder USING btree (companyid, status);


--
-- Name: ix_c28b41dc; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_c28b41dc ON shoppingcart USING btree (groupid);


--
-- Name: ix_c28c72ec; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_c28c72ec ON membershiprequest USING btree (groupid, statusid);


--
-- Name: ix_c295dbee; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_c295dbee ON mbcategory USING btree (groupid, parentcategoryid, status);


--
-- Name: ix_c31a64c6; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_c31a64c6 ON socialrelation USING btree (type_);


--
-- Name: ix_c36b0443; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_c36b0443 ON journalfolder USING btree (companyid, status);


--
-- Name: ix_c3a17327; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_c3a17327 ON passwordpolicyrel USING btree (classnameid, classpk);


--
-- Name: ix_c3aa93b8; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_c3aa93b8 ON journalcontentsearch USING btree (groupid, privatelayout, layoutid, portletid, articleid);


--
-- Name: ix_c4079fd3; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_c4079fd3 ON layoutsetbranch USING btree (groupid, privatelayout);


--
-- Name: ix_c4e6fd10; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_c4e6fd10 ON assetvocabulary USING btree (uuid_, companyid);


--
-- Name: ix_c4f283c8; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_c4f283c8 ON ddmtemplate USING btree (type_);


--
-- Name: ix_c4f9e699; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_c4f9e699 ON users_groups USING btree (groupid);


--
-- Name: ix_c5762e72; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_c5762e72 ON layoutfriendlyurl USING btree (plid, languageid);


--
-- Name: ix_c57b16bc; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_c57b16bc ON mbmessage USING btree (uuid_);


--
-- Name: ix_c5806019; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_c5806019 ON user_ USING btree (companyid, screenname);


--
-- Name: ix_c58a516b; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_c58a516b ON mdraction USING btree (uuid_, companyid);


--
-- Name: ix_c5a6c78f; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_c5a6c78f ON backgroundtask USING btree (companyid);


--
-- Name: ix_c5d69b24; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_c5d69b24 ON layoutsetprototype USING btree (uuid_);


--
-- Name: ix_c648700a; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_c648700a ON usernotificationdelivery USING btree (userid);


--
-- Name: ix_c68dc967; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_c68dc967 ON dlfileversion USING btree (fileentryid);


--
-- Name: ix_c6938724; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_c6938724 ON marketplace_module USING btree (appid, contextname);


--
-- Name: ix_c7057ff7; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_c7057ff7 ON portletpreferences USING btree (ownerid, ownertype, plid, portletid);


--
-- Name: ix_c71c3b7; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_c71c3b7 ON backgroundtask USING btree (groupid, status);


--
-- Name: ix_c78b61ac; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_c78b61ac ON bookmarksentry USING btree (groupid, userid, folderid, status);


--
-- Name: ix_c79e347; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_c79e347 ON ddlrecordversion USING btree (recordid, version);


--
-- Name: ix_c7f39fca; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_c7f39fca ON assetcategory USING btree (groupid, name, vocabularyid);


--
-- Name: ix_c7fbc998; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_c7fbc998 ON layout USING btree (companyid);


--
-- Name: ix_c803899d; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_c803899d ON ddmstructurelink USING btree (classpk);


--
-- Name: ix_c8419fbe; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_c8419fbe ON ddmstructure USING btree (groupid);


--
-- Name: ix_c8785130; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_c8785130 ON ddmstructure USING btree (groupid, classnameid, structurekey);


--
-- Name: ix_c88430ab; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_c88430ab ON dlfolder USING btree (groupid, mountpoint, parentfolderid, hidden_, status);


--
-- Name: ix_c8a9c476; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_c8a9c476 ON wikipage USING btree (nodeid);


--
-- Name: ix_c8fd892b; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_c8fd892b ON socialactivityachievement USING btree (groupid, userid);


--
-- Name: ix_c95a08d8; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_c95a08d8 ON mdrrulegroupinstance USING btree (classnameid, classpk);


--
-- Name: ix_c98c0d78; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_c98c0d78 ON scframeworkversion USING btree (companyid);


--
-- Name: ix_c99b2650; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_c99b2650 ON dlfileversion USING btree (uuid_, groupid);


--
-- Name: ix_c9a3fce2; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_c9a3fce2 ON portletpreferences USING btree (ownerid, ownertype, portletid);


--
-- Name: ix_ca713461; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_ca713461 ON layoutfriendlyurl USING btree (groupid, privatelayout, friendlyurl);


--
-- Name: ix_ca9afb7c; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_ca9afb7c ON expandovalue USING btree (tableid, columnid);


--
-- Name: ix_caa451d6; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_caa451d6 ON wikipage USING btree (groupid, userid, nodeid, status);


--
-- Name: ix_cab0ccc8; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_cab0ccc8 ON usergroupgrouprole USING btree (groupid, roleid);


--
-- Name: ix_cae41a28; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_cae41a28 ON ddmtemplate USING btree (templatekey);


--
-- Name: ix_cb37a10f; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_cb37a10f ON journalfeed USING btree (uuid_, companyid);


--
-- Name: ix_cbc408d8; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_cbc408d8 ON dlfolder USING btree (uuid_);


--
-- Name: ix_cbe204; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_cbe204 ON role_ USING btree (type_, subtype);


--
-- Name: ix_cbfdbf0a; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_cbfdbf0a ON mbmessage USING btree (groupid, categoryid, threadid, answer);


--
-- Name: ix_cc14dc2; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_cc14dc2 ON mdrrulegroup USING btree (uuid_, companyid);


--
-- Name: ix_cc86a444; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_cc86a444 ON socialrequest USING btree (userid, classnameid, classpk, type_, status);


--
-- Name: ix_cc993ecb; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_cc993ecb ON mbthread USING btree (rootmessageid);


--
-- Name: ix_ccbe4063; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_ccbe4063 ON usergroupgrouprole USING btree (groupid);


--
-- Name: ix_ccf0da29; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_ccf0da29 ON layoutsetbranch USING btree (groupid, privatelayout, master);


--
-- Name: ix_cd25266e; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_cd25266e ON passwordpolicyrel USING btree (passwordpolicyid);


--
-- Name: ix_cd7132d0; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_cd7132d0 ON quartz_triggers USING btree (sched_name, calendar_name);


--
-- Name: ix_ce360bf6; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_ce360bf6 ON dlfolder USING btree (groupid, parentfolderid, hidden_, status);


--
-- Name: ix_cef72136; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_cef72136 ON layoutprototype USING btree (uuid_);


--
-- Name: ix_d0822724; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_d0822724 ON layout USING btree (uuid_);


--
-- Name: ix_d0d5e397; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_d0d5e397 ON group_ USING btree (companyid, classnameid, classpk);


--
-- Name: ix_d0e9029e; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_d0e9029e ON socialactivity USING btree (classnameid, classpk, type_);


--
-- Name: ix_d16018a6; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_d16018a6 ON bookmarksfolder USING btree (groupid, parentfolderid, status);


--
-- Name: ix_d19c1b9f; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_d19c1b9f ON journalarticle USING btree (groupid, userid);


--
-- Name: ix_d1c44a6e; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_d1c44a6e ON useridmapper USING btree (userid, type_);


--
-- Name: ix_d1f795f1; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_d1f795f1 ON portalpreferences USING btree (ownerid, ownertype);


--
-- Name: ix_d20c434d; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_d20c434d ON dlfileentry USING btree (groupid, userid, folderid);


--
-- Name: ix_d217ab30; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_d217ab30 ON shoppingitem USING btree (mediumimageid);


--
-- Name: ix_d219afde; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_d219afde ON quartz_triggers USING btree (sched_name, trigger_group, trigger_state);


--
-- Name: ix_d24f3956; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_d24f3956 ON emailaddress USING btree (uuid_);


--
-- Name: ix_d27b03e7; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_d27b03e7 ON expandovalue USING btree (tableid, columnid, classpk);


--
-- Name: ix_d2d249e8; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_d2d249e8 ON journalarticle USING btree (groupid, urltitle, status);


--
-- Name: ix_d33a5445; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_d33a5445 ON mbstatsuser USING btree (groupid, userid, messagecount);


--
-- Name: ix_d340db76; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_d340db76 ON portletpreferences USING btree (plid, portletid);


--
-- Name: ix_d3425487; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_d3425487 ON socialrequest USING btree (classnameid, classpk, type_, receiveruserid, status);


--
-- Name: ix_d3b9af62; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_d3b9af62 ON repositoryentry USING btree (uuid_, companyid);


--
-- Name: ix_d3f5d7ae; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_d3f5d7ae ON expandorow USING btree (tableid);


--
-- Name: ix_d4121315; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_d4121315 ON journalarticleimage USING btree (tempimage);


--
-- Name: ix_d4390caa; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_d4390caa ON socialactivityachievement USING btree (groupid, userid, name);


--
-- Name: ix_d43e4208; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_d43e4208 ON ddmstructurelink USING btree (classnameid);


--
-- Name: ix_d47bb14d; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_d47bb14d ON dlfileversion USING btree (fileentryid, status);


--
-- Name: ix_d49ab5d1; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_d49ab5d1 ON dlfileentrymetadata USING btree (uuid_);


--
-- Name: ix_d49c2e66; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_d49c2e66 ON announcementsentry USING btree (userid);


--
-- Name: ix_d4c2c221; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_d4c2c221 ON ddmtemplate USING btree (uuid_, companyid);


--
-- Name: ix_d5df7b54; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_d5df7b54 ON pollsvote USING btree (choiceid);


--
-- Name: ix_d5eda3a1; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_d5eda3a1 ON portletpreferences USING btree (ownertype, plid, portletid);


--
-- Name: ix_d61abe08; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_d61abe08 ON assetcategory USING btree (name, vocabularyid);


--
-- Name: ix_d63322f9; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_d63322f9 ON assettag USING btree (groupid, name);


--
-- Name: ix_d639348c; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_d639348c ON trashversion USING btree (entryid, classnameid, classpk);


--
-- Name: ix_d63d20bb; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_d63d20bb ON resourceblockpermission USING btree (resourceblockid, roleid);


--
-- Name: ix_d6666704; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_d6666704 ON socialactivitycounter USING btree (groupid);


--
-- Name: ix_d699243f; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_d699243f ON portletitem USING btree (groupid, name, portletid, classnameid);


--
-- Name: ix_d6fd9496; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_d6fd9496 ON calevent USING btree (companyid);


--
-- Name: ix_d76dd2cf; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_d76dd2cf ON pollschoice USING btree (questionid, name);


--
-- Name: ix_d7710a66; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_d7710a66 ON sclicenses_scproductentries USING btree (productentryid);


--
-- Name: ix_d7d6e87a; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_d7d6e87a ON shoppingorder USING btree (number_);


--
-- Name: ix_d9380cb7; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_d9380cb7 ON socialrequest USING btree (receiveruserid, status);


--
-- Name: ix_d9492cf6; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_d9492cf6 ON dlfileentry USING btree (mimetype);


--
-- Name: ix_d984aaba; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_d984aaba ON socialactivitysetting USING btree (groupid, classnameid, activitytype, name);


--
-- Name: ix_d9ffca84; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_d9ffca84 ON layoutsetprototype USING btree (uuid_, companyid);


--
-- Name: ix_da04f689; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_da04f689 ON blogsentry USING btree (groupid, userid, displaydate, status);


--
-- Name: ix_da30b086; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_da30b086 ON resourceblock USING btree (companyid, groupid, name);


--
-- Name: ix_da448450; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_da448450 ON dlfolder USING btree (uuid_, companyid);


--
-- Name: ix_da5f4359; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_da5f4359 ON shard USING btree (classnameid, classpk);


--
-- Name: ix_da84a9f7; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_da84a9f7 ON mbcategory USING btree (groupid, status);


--
-- Name: ix_da913a55; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_da913a55 ON scproductscreenshot USING btree (productentryid, priority);


--
-- Name: ix_db24dddd; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_db24dddd ON ddmtemplate USING btree (groupid);


--
-- Name: ix_db780a20; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_db780a20 ON blogsentry USING btree (groupid, urltitle);


--
-- Name: ix_dbd111aa; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_dbd111aa ON assetcategoryproperty USING btree (categoryid, key_);


--
-- Name: ix_dc2f8927; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_dc2f8927 ON bookmarksfolder USING btree (uuid_, groupid);


--
-- Name: ix_dc60cfae; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_dc60cfae ON shoppingcoupon USING btree (code_);


--
-- Name: ix_dcd1fac1; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_dcd1fac1 ON journalarticleresource USING btree (uuid_);


--
-- Name: ix_dcded558; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_dcded558 ON usergroupgrouprole USING btree (usergroupid);


--
-- Name: ix_dce308c5; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_dce308c5 ON mbthreadflag USING btree (uuid_, companyid);


--
-- Name: ix_dd03d499; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_dd03d499 ON marketplace_module USING btree (bundlesymbolicname);


--
-- Name: ix_dfd809d3; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_dfd809d3 ON dlfileversion USING btree (groupid, folderid, status);


--
-- Name: ix_dff1f063; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_dff1f063 ON assettagproperty USING btree (companyid);


--
-- Name: ix_dff98523; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_dff98523 ON journalarticle USING btree (companyid);


--
-- Name: ix_e002061; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_e002061 ON journalfolder USING btree (uuid_, groupid);


--
-- Name: ix_e0092ff0; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_e0092ff0 ON wikipage USING btree (groupid, nodeid, head, status);


--
-- Name: ix_e0422bda; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_e0422bda ON user_ USING btree (uuid_);


--
-- Name: ix_e0e6d12c; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_e0e6d12c ON wikinode USING btree (uuid_, companyid);


--
-- Name: ix_e10ac39; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_e10ac39 ON layoutrevision USING btree (layoutsetbranchid, head, plid);


--
-- Name: ix_e118c537; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_e118c537 ON layout USING btree (uuid_, groupid, privatelayout);


--
-- Name: ix_e119938a; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_e119938a ON assetentries_assetcategories USING btree (entryid);


--
-- Name: ix_e14b1f1; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_e14b1f1 ON socialactivityachievement USING btree (groupid);


--
-- Name: ix_e15a5db5; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_e15a5db5 ON mbcategory USING btree (companyid, status);


--
-- Name: ix_e1e7142b; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_e1e7142b ON mbthread USING btree (groupid, status);


--
-- Name: ix_e1f55fb; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_e1f55fb ON wikipage USING btree (resourceprimkey, nodeid, head);


--
-- Name: ix_e2815081; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_e2815081 ON dlfileversion USING btree (fileentryid, version);


--
-- Name: ix_e301bdf5; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_e301bdf5 ON organization_ USING btree (companyid, name);


--
-- Name: ix_e3baf436; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_e3baf436 ON ddmcontent USING btree (companyid);


--
-- Name: ix_e3f1286b; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_e3f1286b ON lock_ USING btree (expirationdate);


--
-- Name: ix_e4d7ef87; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_e4d7ef87 ON passwordpolicy USING btree (uuid_, companyid);


--
-- Name: ix_e4efba8d; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_e4efba8d ON usertracker USING btree (userid);


--
-- Name: ix_e4f13e6e; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_e4f13e6e ON portletpreferences USING btree (ownerid, ownertype, plid);


--
-- Name: ix_e60ea987; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_e60ea987 ON useridmapper USING btree (userid);


--
-- Name: ix_e61809c8; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_e61809c8 ON ddmstructure USING btree (uuid_);


--
-- Name: ix_e639e2f6; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_e639e2f6 ON assetcategory USING btree (groupid);


--
-- Name: ix_e6dfab84; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_e6dfab84 ON ddmtemplate USING btree (groupid, classnameid, templatekey);


--
-- Name: ix_e6e2725d; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_e6e2725d ON journalfolder USING btree (companyid);


--
-- Name: ix_e745ea26; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_e745ea26 ON wikipage USING btree (nodeid, title, head);


--
-- Name: ix_e79be432; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_e79be432 ON dlfolder USING btree (companyid, status);


--
-- Name: ix_e7b95510; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_e7b95510 ON browsertracker USING btree (userid);


--
-- Name: ix_e7f635ca; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_e7f635ca ON wikipage USING btree (nodeid, head);


--
-- Name: ix_e82f322b; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_e82f322b ON journalarticle USING btree (companyid, version, status);


--
-- Name: ix_e848278f; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_e848278f ON bookmarksentry USING btree (resourceblockid);


--
-- Name: ix_e858f170; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_e858f170 ON mbmailinglist USING btree (uuid_, groupid);


--
-- Name: ix_e8d019aa; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_e8d019aa ON assetcategory USING btree (uuid_, groupid);


--
-- Name: ix_e8d33ff9; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_e8d33ff9 ON scframeworkversi_scproductvers USING btree (productversionid);


--
-- Name: ix_e8f34171; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_e8f34171 ON subscription USING btree (userid, classnameid);


--
-- Name: ix_e922d6c0; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_e922d6c0 ON portletitem USING btree (groupid, portletid, classnameid);


--
-- Name: ix_e988689e; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_e988689e ON journalfolder USING btree (groupid, name);


--
-- Name: ix_ea05e9e1; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_ea05e9e1 ON journalarticle USING btree (displaydate, status);


--
-- Name: ix_ea6245a0; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_ea6245a0 ON phone USING btree (uuid_);


--
-- Name: ix_ea63b9d7; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_ea63b9d7 ON mdrrule USING btree (uuid_);


--
-- Name: ix_ea6fd516; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_ea6fd516 ON shoppingitemprice USING btree (itemid);


--
-- Name: ix_eaa02a91; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_eaa02a91 ON bookmarksentry USING btree (uuid_, groupid);


--
-- Name: ix_eab317c8; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_eab317c8 ON layoutfriendlyurl USING btree (companyid);


--
-- Name: ix_eb2dce27; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_eb2dce27 ON blogsentry USING btree (companyid, status);


--
-- Name: ix_eb531760; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_eb531760 ON dlcontent USING btree (companyid, repositoryid, path_);


--
-- Name: ix_eb9bde28; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_eb9bde28 ON ddmcontent USING btree (uuid_, groupid);


--
-- Name: ix_ebc931b8; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_ebc931b8 ON role_ USING btree (companyid, name);


--
-- Name: ix_ec00543c; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_ec00543c ON company USING btree (webid);


--
-- Name: ix_ec370f10; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_ec370f10 ON pollschoice USING btree (questionid);


--
-- Name: ix_ecd8cfea; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_ecd8cfea ON usernotificationevent USING btree (uuid_);


--
-- Name: ix_ed292508; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_ed292508 ON mbcategory USING btree (groupid, parentcategoryid);


--
-- Name: ix_ed39ac98; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_ed39ac98 ON mbmessage USING btree (groupid, status);


--
-- Name: ix_ed5ca615; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_ed5ca615 ON dlfileentry USING btree (groupid, folderid, title);


--
-- Name: ix_edb9986e; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_edb9986e ON resourceaction USING btree (name, actionid);


--
-- Name: ix_ee29c715; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_ee29c715 ON dlfolder USING btree (repositoryid);


--
-- Name: ix_ee8abd19; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_ee8abd19 ON user_ USING btree (companyid, modifieddate);


--
-- Name: ix_eed06670; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_eed06670 ON dlfilerank USING btree (userid);


--
-- Name: ix_eefe382a; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_eefe382a ON quartz_triggers USING btree (sched_name, next_fire_time);


--
-- Name: ix_ef9b7028; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_ef9b7028 ON journalarticle USING btree (smallimageid);


--
-- Name: ix_efd9cac; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_efd9cac ON journalfolder USING btree (groupid, parentfolderid, status);


--
-- Name: ix_f026cf4c; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_f026cf4c ON quartz_triggers USING btree (sched_name, next_fire_time, trigger_state);


--
-- Name: ix_f029602f; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_f029602f ON journalarticle USING btree (uuid_);


--
-- Name: ix_f0566a77; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_f0566a77 ON expandovalue USING btree (tableid);


--
-- Name: ix_f0c3449; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_f0c3449 ON ddmtemplate USING btree (groupid, classnameid, classpk, type_, mode_);


--
-- Name: ix_f0ca24a5; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_f0ca24a5 ON socialrelation USING btree (uuid_);


--
-- Name: ix_f0e73383; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_f0e73383 ON blogsentry USING btree (groupid, displaydate, status);


--
-- Name: ix_f10b6c6b; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_f10b6c6b ON users_groups USING btree (userid);


--
-- Name: ix_f147cf3f; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_f147cf3f ON dlfileentrytypes_ddmstructures USING btree (structureid);


--
-- Name: ix_f15c1c4f; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_f15c1c4f ON portletpreferences USING btree (plid);


--
-- Name: ix_f1c1a617; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_f1c1a617 ON socialactivitylimit USING btree (groupid, userid, classnameid, classpk, activitytype, activitycountername);


--
-- Name: ix_f202b9ce; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_f202b9ce ON phone USING btree (userid);


--
-- Name: ix_f2949120; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_f2949120 ON announcementsentry USING btree (uuid_, companyid);


--
-- Name: ix_f2a243a7; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_f2a243a7 ON ddmtemplate USING btree (uuid_);


--
-- Name: ix_f2dd7c7e; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_f2dd7c7e ON quartz_triggers USING btree (sched_name, next_fire_time, trigger_state, misfire_instr);


--
-- Name: ix_f2ea1ace; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_f2ea1ace ON dlfolder USING btree (groupid);


--
-- Name: ix_f2f1e964; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_f2f1e964 ON marketplace_module USING btree (contextname);


--
-- Name: ix_f35391e8; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_f35391e8 ON journalarticle USING btree (groupid, folderid, status);


--
-- Name: ix_f36bbb83; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_f36bbb83 ON mbthreadflag USING btree (uuid_);


--
-- Name: ix_f389330e; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_f389330e ON dlfileversion USING btree (companyid);


--
-- Name: ix_f3c9f36; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_f3c9f36 ON pollsquestion USING btree (uuid_, groupid);


--
-- Name: ix_f3e1c6fc; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_f3e1c6fc ON role_ USING btree (companyid, type_);


--
-- Name: ix_f3efdcb3; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_f3efdcb3 ON mdrrule USING btree (uuid_, groupid);


--
-- Name: ix_f4321a54; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_f4321a54 ON layoutfriendlyurl USING btree (uuid_, companyid);


--
-- Name: ix_f436ec8e; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_f436ec8e ON role_ USING btree (name);


--
-- Name: ix_f43b9ff2; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_f43b9ff2 ON journalarticle USING btree (groupid, classnameid, templateid);


--
-- Name: ix_f4555981; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_f4555981 ON resourcepermission USING btree (scope);


--
-- Name: ix_f474fd89; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_f474fd89 ON shoppingorder USING btree (pptxnid);


--
-- Name: ix_f4af5636; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_f4af5636 ON dlfileentry USING btree (groupid);


--
-- Name: ix_f542e9bc; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_f542e9bc ON socialactivity USING btree (activitysetid);


--
-- Name: ix_f543ea4; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_f543ea4 ON repository USING btree (uuid_, companyid);


--
-- Name: ix_f6006202; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_f6006202 ON calevent USING btree (remindby);


--
-- Name: ix_f6039434; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_f6039434 ON user_ USING btree (companyid, status);


--
-- Name: ix_f6687633; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_f6687633 ON mbmessage USING btree (classnameid, classpk, status);


--
-- Name: ix_f71071bd; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_f71071bd ON socialactivityset USING btree (groupid, userid, type_);


--
-- Name: ix_f74ab912; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_f74ab912 ON emailaddress USING btree (uuid_, companyid);


--
-- Name: ix_f75690bb; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_f75690bb ON website USING btree (userid);


--
-- Name: ix_f78286c5; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_f78286c5 ON dlfolder USING btree (groupid, mountpoint, parentfolderid, hidden_);


--
-- Name: ix_f7aac799; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_f7aac799 ON mbdiscussion USING btree (uuid_, groupid);


--
-- Name: ix_f7d28c2f; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_f7d28c2f ON mbcategory USING btree (uuid_, groupid);


--
-- Name: ix_f7dd0987; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_f7dd0987 ON expandovalue USING btree (columnid);


--
-- Name: ix_f80c4386; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_f80c4386 ON socialactivityset USING btree (userid);


--
-- Name: ix_f8433677; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_f8433677 ON journalarticleresource USING btree (groupid);


--
-- Name: ix_f8ca2ab9; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_f8ca2ab9 ON mbthread USING btree (uuid_, companyid);


--
-- Name: ix_f8e90438; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_f8e90438 ON dlfileentrymetadata USING btree (fileentrytypeid);


--
-- Name: ix_f910bbb4; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_f910bbb4 ON pollsquestion USING btree (uuid_, companyid);


--
-- Name: ix_f92b66e6; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_f92b66e6 ON role_ USING btree (type_);


--
-- Name: ix_f960131c; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_f960131c ON website USING btree (companyid, classnameid, classpk);


--
-- Name: ix_f981514e; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_f981514e ON group_ USING btree (uuid_);


--
-- Name: ix_f9fb8d60; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_f9fb8d60 ON ddmstructure USING btree (uuid_, companyid);


--
-- Name: ix_fb604dc7; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_fb604dc7 ON socialactivity USING btree (groupid, userid, classnameid, classpk, type_, receiveruserid);


--
-- Name: ix_fb646ca6; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_fb646ca6 ON users_orgs USING btree (userid);


--
-- Name: ix_fbbe7c96; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_fbbe7c96 ON wikipage USING btree (userid, nodeid, status);


--
-- Name: ix_fbde0aa3; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_fbde0aa3 ON blogsentry USING btree (groupid, userid, displaydate);


--
-- Name: ix_fc1f9c7b; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_fc1f9c7b ON assetentry USING btree (classuuid);


--
-- Name: ix_fc46fe16; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_fc46fe16 ON shoppingcart USING btree (groupid, userid);


--
-- Name: ix_fc4eea64; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_fc4eea64 ON trashentry USING btree (groupid, classnameid);


--
-- Name: ix_fc61676e; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_fc61676e ON mbmailinglist USING btree (uuid_, companyid);


--
-- Name: ix_fcd7c63d; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_fcd7c63d ON calevent USING btree (groupid, type_);


--
-- Name: ix_fd32eb70; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_fd32eb70 ON pollsvote USING btree (uuid_);


--
-- Name: ix_fd57097d; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_fd57097d ON layoutbranch USING btree (layoutsetbranchid, plid, name);


--
-- Name: ix_fd90786c; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_fd90786c ON mdraction USING btree (rulegroupinstanceid);


--
-- Name: ix_fd93cbfa; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_fd93cbfa ON calevent USING btree (groupid, type_, repeating);


--
-- Name: ix_fdb4a946; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_fdb4a946 ON dlfileshortcut USING btree (uuid_, groupid);


--
-- Name: ix_fdd1aaa8; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_fdd1aaa8 ON dlcontent USING btree (companyid, repositoryid, path_, version);


--
-- Name: ix_feb0fc87; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_feb0fc87 ON mbthreadflag USING btree (uuid_, groupid);


--
-- Name: ix_fec4a201; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_fec4a201 ON assetentry USING btree (layoutuuid);


--
-- Name: ix_fefc8da7; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE UNIQUE INDEX ix_fefc8da7 ON expandocolumn USING btree (tableid, name);


--
-- Name: ix_fefe7d76; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_fefe7d76 ON shoppingitem USING btree (groupid, categoryid);


--
-- Name: ix_ff203304; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_ff203304 ON shoppingitem USING btree (smallimageid);


--
-- Name: ix_ffb3395c; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_ffb3395c ON dlfileversion USING btree (mimetype);


--
-- Name: ix_ffcbb747; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX ix_ffcbb747 ON systemevent USING btree (groupid, classnameid, classpk, type_);


--
-- Name: public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

