-- MySQL dump 10.13  Distrib 5.5.21, for Win64 (x86)
--
-- Host: localhost    Database: lportal
-- ------------------------------------------------------
-- Server version	5.5.21

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `Account_`
--

DROP TABLE IF EXISTS `Account_`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Account_` (
  `accountId` bigint(20) NOT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `userId` bigint(20) DEFAULT NULL,
  `userName` varchar(75) DEFAULT NULL,
  `createDate` datetime DEFAULT NULL,
  `modifiedDate` datetime DEFAULT NULL,
  `parentAccountId` bigint(20) DEFAULT NULL,
  `name` varchar(75) DEFAULT NULL,
  `legalName` varchar(75) DEFAULT NULL,
  `legalId` varchar(75) DEFAULT NULL,
  `legalType` varchar(75) DEFAULT NULL,
  `sicCode` varchar(75) DEFAULT NULL,
  `tickerSymbol` varchar(75) DEFAULT NULL,
  `industry` varchar(75) DEFAULT NULL,
  `type_` varchar(75) DEFAULT NULL,
  `size_` varchar(75) DEFAULT NULL,
  PRIMARY KEY (`accountId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Account_`
--

LOCK TABLES `Account_` WRITE;
/*!40000 ALTER TABLE `Account_` DISABLE KEYS */;
INSERT INTO `Account_` VALUES (10134,10132,0,'','2014-04-03 16:33:40','2014-04-03 16:33:40',0,'liferay.com','','','','','','','','');
/*!40000 ALTER TABLE `Account_` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Address`
--

DROP TABLE IF EXISTS `Address`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Address` (
  `addressId` bigint(20) NOT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `userId` bigint(20) DEFAULT NULL,
  `userName` varchar(75) DEFAULT NULL,
  `createDate` datetime DEFAULT NULL,
  `modifiedDate` datetime DEFAULT NULL,
  `classNameId` bigint(20) DEFAULT NULL,
  `classPK` bigint(20) DEFAULT NULL,
  `street1` varchar(75) DEFAULT NULL,
  `street2` varchar(75) DEFAULT NULL,
  `street3` varchar(75) DEFAULT NULL,
  `city` varchar(75) DEFAULT NULL,
  `zip` varchar(75) DEFAULT NULL,
  `regionId` bigint(20) DEFAULT NULL,
  `countryId` bigint(20) DEFAULT NULL,
  `typeId` int(11) DEFAULT NULL,
  `mailing` tinyint(4) DEFAULT NULL,
  `primary_` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`addressId`),
  KEY `IX_93D5AD4E` (`companyId`),
  KEY `IX_ABD7DAC0` (`companyId`,`classNameId`),
  KEY `IX_71CB1123` (`companyId`,`classNameId`,`classPK`),
  KEY `IX_923BD178` (`companyId`,`classNameId`,`classPK`,`mailing`),
  KEY `IX_9226DBB4` (`companyId`,`classNameId`,`classPK`,`primary_`),
  KEY `IX_5BC8B0D4` (`userId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Address`
--

LOCK TABLES `Address` WRITE;
/*!40000 ALTER TABLE `Address` DISABLE KEYS */;
INSERT INTO `Address` VALUES (10769,10132,10169,'Test Test','2014-04-03 17:07:06','2014-04-03 17:07:24',10009,10170,'1220 Brea Canyon Rd','','','Walnut','91789',19005,19,11000,1,1);
/*!40000 ALTER TABLE `Address` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `AnnouncementsDelivery`
--

DROP TABLE IF EXISTS `AnnouncementsDelivery`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `AnnouncementsDelivery` (
  `deliveryId` bigint(20) NOT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `userId` bigint(20) DEFAULT NULL,
  `type_` varchar(75) DEFAULT NULL,
  `email` tinyint(4) DEFAULT NULL,
  `sms` tinyint(4) DEFAULT NULL,
  `website` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`deliveryId`),
  UNIQUE KEY `IX_BA4413D5` (`userId`,`type_`),
  KEY `IX_6EDB9600` (`userId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `AnnouncementsDelivery`
--

LOCK TABLES `AnnouncementsDelivery` WRITE;
/*!40000 ALTER TABLE `AnnouncementsDelivery` DISABLE KEYS */;
INSERT INTO `AnnouncementsDelivery` VALUES (10371,10132,10365,'general',0,0,0),(10372,10132,10365,'news',0,0,0),(10373,10132,10365,'test',0,0,0),(10549,10132,10543,'general',0,0,0),(10550,10132,10543,'news',0,0,0),(10551,10132,10543,'test',0,0,0),(10595,10132,10589,'general',0,0,0),(10596,10132,10589,'news',0,0,0),(10597,10132,10589,'test',0,0,0),(10735,10132,10169,'general',1,1,1),(10736,10132,10169,'news',0,0,1),(10737,10132,10169,'test',0,0,1),(10749,10132,10743,'general',0,0,0),(10750,10132,10743,'news',0,0,0),(10751,10132,10743,'test',0,0,0);
/*!40000 ALTER TABLE `AnnouncementsDelivery` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `AnnouncementsEntry`
--

DROP TABLE IF EXISTS `AnnouncementsEntry`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `AnnouncementsEntry` (
  `uuid_` varchar(75) DEFAULT NULL,
  `entryId` bigint(20) NOT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `userId` bigint(20) DEFAULT NULL,
  `userName` varchar(75) DEFAULT NULL,
  `createDate` datetime DEFAULT NULL,
  `modifiedDate` datetime DEFAULT NULL,
  `classNameId` bigint(20) DEFAULT NULL,
  `classPK` bigint(20) DEFAULT NULL,
  `title` varchar(75) DEFAULT NULL,
  `content` longtext,
  `url` longtext,
  `type_` varchar(75) DEFAULT NULL,
  `displayDate` datetime DEFAULT NULL,
  `expirationDate` datetime DEFAULT NULL,
  `priority` int(11) DEFAULT NULL,
  `alert` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`entryId`),
  KEY `IX_A6EF0B81` (`classNameId`,`classPK`),
  KEY `IX_14F06A6B` (`classNameId`,`classPK`,`alert`),
  KEY `IX_D49C2E66` (`userId`),
  KEY `IX_1AFBDE08` (`uuid_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `AnnouncementsEntry`
--

LOCK TABLES `AnnouncementsEntry` WRITE;
/*!40000 ALTER TABLE `AnnouncementsEntry` DISABLE KEYS */;
INSERT INTO `AnnouncementsEntry` VALUES ('7faa0ba3-99bd-4b0b-93a2-28e650b72230',10738,10132,10169,'Test Test','2014-04-03 17:04:54','2014-04-03 17:04:54',0,0,'Announcements Entry Title','Announcements Entry Content','http://www.liferay.com','general','2014-04-03 17:04:00','2014-05-03 17:04:00',0,0);
/*!40000 ALTER TABLE `AnnouncementsEntry` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `AnnouncementsFlag`
--

DROP TABLE IF EXISTS `AnnouncementsFlag`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `AnnouncementsFlag` (
  `flagId` bigint(20) NOT NULL,
  `userId` bigint(20) DEFAULT NULL,
  `createDate` datetime DEFAULT NULL,
  `entryId` bigint(20) DEFAULT NULL,
  `value` int(11) DEFAULT NULL,
  PRIMARY KEY (`flagId`),
  UNIQUE KEY `IX_4539A99C` (`userId`,`entryId`,`value`),
  KEY `IX_9C7EB9F` (`entryId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `AnnouncementsFlag`
--

LOCK TABLES `AnnouncementsFlag` WRITE;
/*!40000 ALTER TABLE `AnnouncementsFlag` DISABLE KEYS */;
INSERT INTO `AnnouncementsFlag` VALUES (10739,10169,'2014-04-03 17:04:59',10738,2);
/*!40000 ALTER TABLE `AnnouncementsFlag` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `AssetCategory`
--

DROP TABLE IF EXISTS `AssetCategory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `AssetCategory` (
  `uuid_` varchar(75) DEFAULT NULL,
  `categoryId` bigint(20) NOT NULL,
  `groupId` bigint(20) DEFAULT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `userId` bigint(20) DEFAULT NULL,
  `userName` varchar(75) DEFAULT NULL,
  `createDate` datetime DEFAULT NULL,
  `modifiedDate` datetime DEFAULT NULL,
  `parentCategoryId` bigint(20) DEFAULT NULL,
  `leftCategoryId` bigint(20) DEFAULT NULL,
  `rightCategoryId` bigint(20) DEFAULT NULL,
  `name` varchar(75) DEFAULT NULL,
  `title` longtext,
  `vocabularyId` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`categoryId`),
  UNIQUE KEY `IX_BE4DF2BF` (`parentCategoryId`,`name`,`vocabularyId`),
  UNIQUE KEY `IX_E8D019AA` (`uuid_`,`groupId`),
  KEY `IX_E639E2F6` (`groupId`),
  KEY `IX_D61ABE08` (`name`,`vocabularyId`),
  KEY `IX_7BB1826B` (`parentCategoryId`),
  KEY `IX_9DDD15EA` (`parentCategoryId`,`name`),
  KEY `IX_B185E980` (`parentCategoryId`,`vocabularyId`),
  KEY `IX_4D37BB00` (`uuid_`),
  KEY `IX_287B1F89` (`vocabularyId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `AssetCategory`
--

LOCK TABLES `AssetCategory` WRITE;
/*!40000 ALTER TABLE `AssetCategory` DISABLE KEYS */;
INSERT INTO `AssetCategory` VALUES ('6ecd313d-9eb8-4ce8-bd01-3eca0d8455c4',10470,10435,10132,10169,'Test Test','2014-04-03 16:49:04','2014-04-03 16:49:06',0,2,3,'Category Name','<?xml version=\'1.0\' encoding=\'UTF-8\'?><root available-locales=\"en_US\" default-locale=\"en_US\"><Title language-id=\"en_US\">Category Name</Title></root>',10469);
/*!40000 ALTER TABLE `AssetCategory` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `AssetCategoryProperty`
--

DROP TABLE IF EXISTS `AssetCategoryProperty`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `AssetCategoryProperty` (
  `categoryPropertyId` bigint(20) NOT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `userId` bigint(20) DEFAULT NULL,
  `userName` varchar(75) DEFAULT NULL,
  `createDate` datetime DEFAULT NULL,
  `modifiedDate` datetime DEFAULT NULL,
  `categoryId` bigint(20) DEFAULT NULL,
  `key_` varchar(75) DEFAULT NULL,
  `value` varchar(75) DEFAULT NULL,
  PRIMARY KEY (`categoryPropertyId`),
  UNIQUE KEY `IX_DBD111AA` (`categoryId`,`key_`),
  KEY `IX_99DA856` (`categoryId`),
  KEY `IX_8654719F` (`companyId`),
  KEY `IX_52340033` (`companyId`,`key_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `AssetCategoryProperty`
--

LOCK TABLES `AssetCategoryProperty` WRITE;
/*!40000 ALTER TABLE `AssetCategoryProperty` DISABLE KEYS */;
INSERT INTO `AssetCategoryProperty` VALUES (10471,10132,10169,'Test Test','2014-04-03 16:49:06','2014-04-03 16:49:06',10470,'Category Property Key','Category Property Value');
/*!40000 ALTER TABLE `AssetCategoryProperty` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `AssetEntries_AssetCategories`
--

DROP TABLE IF EXISTS `AssetEntries_AssetCategories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `AssetEntries_AssetCategories` (
  `entryId` bigint(20) NOT NULL,
  `categoryId` bigint(20) NOT NULL,
  PRIMARY KEY (`entryId`,`categoryId`),
  KEY `IX_A188F560` (`categoryId`),
  KEY `IX_E119938A` (`entryId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `AssetEntries_AssetCategories`
--

LOCK TABLES `AssetEntries_AssetCategories` WRITE;
/*!40000 ALTER TABLE `AssetEntries_AssetCategories` DISABLE KEYS */;
INSERT INTO `AssetEntries_AssetCategories` VALUES (10462,10470);
/*!40000 ALTER TABLE `AssetEntries_AssetCategories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `AssetEntries_AssetTags`
--

DROP TABLE IF EXISTS `AssetEntries_AssetTags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `AssetEntries_AssetTags` (
  `entryId` bigint(20) NOT NULL,
  `tagId` bigint(20) NOT NULL,
  PRIMARY KEY (`entryId`,`tagId`),
  KEY `IX_2ED82CAD` (`entryId`),
  KEY `IX_B2A61B55` (`tagId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `AssetEntries_AssetTags`
--

LOCK TABLES `AssetEntries_AssetTags` WRITE;
/*!40000 ALTER TABLE `AssetEntries_AssetTags` DISABLE KEYS */;
/*!40000 ALTER TABLE `AssetEntries_AssetTags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `AssetEntry`
--

DROP TABLE IF EXISTS `AssetEntry`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `AssetEntry` (
  `entryId` bigint(20) NOT NULL,
  `groupId` bigint(20) DEFAULT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `userId` bigint(20) DEFAULT NULL,
  `userName` varchar(75) DEFAULT NULL,
  `createDate` datetime DEFAULT NULL,
  `modifiedDate` datetime DEFAULT NULL,
  `classNameId` bigint(20) DEFAULT NULL,
  `classPK` bigint(20) DEFAULT NULL,
  `classUuid` varchar(75) DEFAULT NULL,
  `visible` tinyint(4) DEFAULT NULL,
  `startDate` datetime DEFAULT NULL,
  `endDate` datetime DEFAULT NULL,
  `publishDate` datetime DEFAULT NULL,
  `expirationDate` datetime DEFAULT NULL,
  `mimeType` varchar(75) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `description` longtext,
  `summary` longtext,
  `url` longtext,
  `height` int(11) DEFAULT NULL,
  `width` int(11) DEFAULT NULL,
  `priority` double DEFAULT NULL,
  `viewCount` int(11) DEFAULT NULL,
  PRIMARY KEY (`entryId`),
  UNIQUE KEY `IX_1E9D371D` (`classNameId`,`classPK`),
  KEY `IX_FC1F9C7B` (`classUuid`),
  KEY `IX_7306C60` (`companyId`),
  KEY `IX_1EBA6821` (`groupId`,`classUuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `AssetEntry`
--

LOCK TABLES `AssetEntry` WRITE;
/*!40000 ALTER TABLE `AssetEntry` DISABLE KEYS */;
INSERT INTO `AssetEntry` VALUES (10155,10149,10132,10135,' ','2014-04-03 16:33:40','2014-04-03 16:33:40',10093,10153,'6bcd8aa9-5fc5-4365-bb0f-3d9212e0f861',0,NULL,NULL,NULL,NULL,'text/html','10152','','','',0,0,0,0),(10163,10157,10132,10135,' ','2014-04-03 16:33:40','2014-04-03 16:33:40',10093,10161,'31d7906e-70ad-45c3-999d-f01a2b193cc1',0,NULL,NULL,NULL,NULL,'text/html','10160','','','',0,0,0,0),(10174,10165,10132,10169,'Test Test','2014-04-03 16:33:41','2014-04-03 17:07:24',10046,10169,'9a883172-faf9-4a8f-bae3-eb6030ff4a65',0,NULL,NULL,NULL,NULL,'','Test Test','','','',0,0,0,0),(10323,10171,10132,10169,'Test Test','2014-04-03 16:38:59','2014-04-03 16:38:59',10093,10321,'b1a9c4b1-4ccb-4721-8075-cb548129355c',0,NULL,NULL,NULL,NULL,'text/html','10320','','','',0,0,0,0),(10328,10171,10132,10169,'Test Test','2014-04-03 16:38:59','2014-04-03 16:38:59',10093,10326,'359a0f30-aef6-4b34-bbe9-3fdfd4800277',0,NULL,NULL,NULL,NULL,'text/html','10325','','','',0,0,0,0),(10336,10157,10132,10169,'Test Test','2014-04-03 16:39:07','2014-04-03 16:39:07',10093,10334,'159f9a97-d6c2-470b-8b25-3963b05fc0ab',0,NULL,NULL,NULL,NULL,'text/html','10333','','','',0,0,0,0),(10350,10157,10132,10169,'Test Test','2014-04-03 16:39:31','2014-04-03 16:39:31',10093,10348,'6097adb6-06f0-4515-ab33-da95f599006c',0,NULL,NULL,NULL,NULL,'text/html','10344','','','',0,0,0,0),(10360,10165,10132,10169,'Test Test','2014-04-03 16:40:01','2014-04-03 16:40:01',10012,10357,'',0,NULL,NULL,NULL,NULL,'','Member Site','','','',0,0,0,0),(10370,10165,10132,10169,'Test Test','2014-04-03 16:40:50','2014-04-03 16:40:50',10046,10365,'17ee6c75-62e6-45a2-80f9-1d627765dacc',0,NULL,NULL,NULL,NULL,'','userfn userln','','','',0,0,0,0),(10379,10165,10132,10169,'Test Test','2014-04-03 16:41:34','2014-04-03 16:41:34',10024,10375,'',0,NULL,NULL,NULL,NULL,'','Organization Name','','','',0,0,0,0),(10391,10165,10132,10169,'Test Test','2014-04-03 16:44:38','2014-04-03 16:44:38',10012,10388,'',0,NULL,NULL,NULL,NULL,'','Wiki Site','','','',0,0,0,0),(10395,10388,10132,10169,'Test Test','2014-04-03 16:44:49','2014-04-03 16:44:49',10093,10393,'431deb30-6b52-4c89-b919-ef698f7541b7',0,NULL,NULL,NULL,NULL,'text/html','10392','','','',0,0,0,0),(10404,10388,10132,10169,'Test Test','2014-04-03 16:44:56','2014-04-03 16:45:12',10129,10403,'5f0d6038-7068-4f28-b284-53387f1e9bf1',1,NULL,NULL,NULL,NULL,'text/html','FrontPage','','','',0,0,0,4),(10407,10388,10132,10169,'Test Test','2014-04-03 16:44:56','2014-04-03 16:44:56',10093,10405,'e8f39f31-a179-4078-90f6-c7a328fefbd8',0,NULL,NULL,NULL,NULL,'text/html','10403','','','',0,0,0,0),(10415,10388,10132,10169,'Test Test','2014-04-03 16:45:12','2014-04-03 16:45:12',10129,10414,'354c8731-b4c7-4d4d-9913-7798bdffde28',0,NULL,NULL,NULL,NULL,'text/html','FrontPage','','','',0,0,0,0),(10427,10157,10132,10169,'Test Test','2014-04-03 16:46:47','2014-04-03 16:46:47',10093,10425,'c06516ec-ad86-4c12-9e60-2b41ede2c8d8',0,NULL,NULL,NULL,NULL,'text/html','10424','','','',0,0,0,0),(10438,10165,10132,10169,'Test Test','2014-04-03 16:47:29','2014-04-03 16:47:29',10012,10435,'',0,NULL,NULL,NULL,NULL,'','WebContent Site','','','',0,0,0,0),(10442,10435,10132,10169,'Test Test','2014-04-03 16:47:40','2014-04-03 16:47:40',10093,10440,'03f4a894-af2c-42e6-a91c-f0f487f3c052',0,NULL,NULL,NULL,NULL,'text/html','10439','','','',0,0,0,0),(10462,10435,10132,10169,'Test Test','2014-04-03 16:48:49','2014-04-03 16:49:24',10084,10459,'f337b4bb-2085-4569-8191-4e980bb71f36',1,NULL,NULL,'2014-04-03 16:48:00',NULL,'text/html','WC WebContent Title','','','',0,0,0,4),(10465,10435,10132,10169,'Test Test','2014-04-03 16:48:49','2014-04-03 16:48:49',10093,10463,'b59c76b7-d1f2-42f7-ba3f-be68a56ea6f4',0,NULL,NULL,NULL,NULL,'text/html','10459','','','',0,0,0,0),(10484,10165,10132,10169,'Test Test','2014-04-03 16:49:46','2014-04-03 16:49:46',10012,10481,'',0,NULL,NULL,NULL,NULL,'','Social Equity Site','','','',0,0,0,0),(10488,10481,10132,10169,'Test Test','2014-04-03 16:49:56','2014-04-03 16:49:56',10093,10486,'88a16cf5-9f9c-4f89-acea-ccd2e6c9e4c0',0,NULL,NULL,NULL,NULL,'text/html','10485','','','',0,0,0,0),(10529,10523,10132,10169,'Test Test','2014-04-03 16:50:44','2014-04-03 16:50:44',10093,10527,'780cb8a7-9853-4bf3-8ef4-706f542859dd',0,NULL,NULL,NULL,NULL,'text/html','10526','','','',0,0,0,0),(10539,10533,10132,10169,'Test Test','2014-04-03 16:51:07','2014-04-03 16:51:07',10093,10537,'599681f6-32d1-47c0-bd2f-7cde956ea45a',0,NULL,NULL,NULL,NULL,'text/html','10536','','','',0,0,0,0),(10548,10165,10132,10169,'Test Test','2014-04-03 16:51:43','2014-04-03 16:52:34',10046,10543,'3be7aa05-cbba-487a-ae1f-6a3b4448536d',0,NULL,NULL,NULL,NULL,'','userPPfn userPPln','','','',0,0,0,0),(10555,10545,10132,10543,'userPPfn userPPln','2014-04-03 16:52:04','2014-04-03 16:52:04',10093,10553,'53f5f756-07dd-4cb2-89ec-d3c58446947e',0,NULL,NULL,NULL,NULL,'text/html','10552','','','',0,0,0,0),(10560,10545,10132,10543,'userPPfn userPPln','2014-04-03 16:52:04','2014-04-03 16:52:04',10093,10558,'30113060-ef28-47df-8139-a2f85561b503',0,NULL,NULL,NULL,NULL,'text/html','10557','','','',0,0,0,0),(10569,10157,10132,10169,'Test Test','2014-04-03 16:53:42','2014-04-03 16:53:42',10093,10567,'902129c5-fbd9-4360-9d0b-1d5a39720bcb',0,NULL,NULL,NULL,NULL,'text/html','10566','','','',0,0,0,0),(10588,10165,10132,10169,'Test Test','2014-04-03 16:55:55','2014-04-03 16:55:55',10012,10585,'',0,NULL,NULL,NULL,NULL,'','Site Name','','','',0,0,0,0),(10594,10165,10132,10169,'Test Test','2014-04-03 16:56:03','2014-04-03 16:56:13',10046,10589,'e0be1517-78c7-4d0b-8a67-79ccb46b480e',0,NULL,NULL,NULL,NULL,'','userSMfn userSMln','','','',0,0,0,0),(10601,10591,10132,10589,'userSMfn userSMln','2014-04-03 16:56:22','2014-04-03 16:56:22',10093,10599,'aa5289f9-69f0-48ad-aad5-096e5c4753c7',0,NULL,NULL,NULL,NULL,'text/html','10598','','','',0,0,0,0),(10606,10591,10132,10589,'userSMfn userSMln','2014-04-03 16:56:22','2014-04-03 16:56:22',10093,10604,'f8df72bf-f267-44f9-a984-ceff66022870',0,NULL,NULL,NULL,NULL,'text/html','10603','','','',0,0,0,0),(10620,10165,10132,10169,'Test Test','2014-04-03 16:57:18','2014-04-03 16:57:18',10012,10617,'',0,NULL,NULL,NULL,NULL,'','Staging Site','','','',0,0,0,0),(10624,10617,10132,10169,'Test Test','2014-04-03 16:57:29','2014-04-03 16:57:29',10093,10622,'c46c4e47-2509-4218-a185-0141130415d9',0,NULL,NULL,NULL,NULL,'text/html','10621','','','',0,0,0,0),(10629,10165,10132,10169,'Test Test','2014-04-03 16:57:46','2014-04-03 16:57:46',10012,10626,'',0,NULL,NULL,NULL,NULL,'','Staging Site (Staging)','','','',0,0,0,0),(10649,10626,10132,10169,'Test Test','2014-04-03 16:58:12','2014-04-03 16:58:12',10095,10647,'3cda30fd-b1cd-4758-bcb9-cb19585bc16e',1,NULL,NULL,NULL,NULL,'text/html','MB Thread Message Subject','','','',0,0,0,0),(10654,10157,10132,10169,'Test Test','2014-04-03 16:58:33','2014-04-03 16:58:33',10093,10652,'43144695-c22d-4306-8b5b-b553f2358ffb',0,NULL,NULL,NULL,NULL,'text/html','10651','','','',0,0,0,0),(10661,10157,10132,10169,'Test Test','2014-04-03 16:58:47','2014-04-03 16:58:47',10070,10660,'faec244e-7594-40eb-90a7-a06b6b4c47fa',1,NULL,NULL,NULL,NULL,'text/plain','Test Bookmark Name','Test Bookmark Description','','http://www.liferay.com',0,0,0,0),(10666,10165,10132,10169,'Test Test','2014-04-03 16:59:18','2014-04-03 16:59:18',10012,10663,'',0,NULL,NULL,NULL,NULL,'','AP Site','','','',0,0,0,0),(10670,10663,10132,10169,'Test Test','2014-04-03 16:59:29','2014-04-03 16:59:29',10093,10668,'92b1fb10-a551-4470-8247-71eb825feb41',0,NULL,NULL,NULL,NULL,'text/html','10667','','','',0,0,0,0),(10681,10165,10132,10169,'Test Test','2014-04-03 17:00:19','2014-04-03 17:00:19',10012,10678,'',0,NULL,NULL,NULL,NULL,'','Document Library Site','','','',0,0,0,0),(10685,10678,10132,10169,'Test Test','2014-04-03 17:00:30','2014-04-03 17:00:30',10093,10683,'aebf3eb5-d0fe-49e2-8856-2f97db090e65',0,NULL,NULL,NULL,NULL,'text/html','10682','','','',0,0,0,0),(10696,10678,10132,10169,'Test Test','2014-04-03 17:00:43','2014-04-03 17:00:43',10093,10694,'f444d5a8-ff0c-4569-a17c-6343a08172e4',0,NULL,NULL,NULL,NULL,'text/html','10691','','','',0,0,0,0),(10699,10678,10132,10169,'Test Test','2014-04-03 17:01:09','2014-04-03 17:01:09',10075,10698,'de8b238e-b930-465e-a393-6c7a7ac052a3',0,NULL,NULL,NULL,NULL,'text/plain','DM Document Title.txt','DM Document Description','','',0,0,0,0),(10716,10157,10132,10169,'Test Test','2014-04-03 17:03:52','2014-04-03 17:03:52',10093,10714,'395a0c14-b579-4aca-91a0-a32431675a8c',0,NULL,NULL,NULL,NULL,'text/html','10713','','','',0,0,0,0),(10724,10157,10132,10169,'Test Test','2014-04-03 17:04:07','2014-04-03 17:04:07',10072,10723,'bf2157d4-a10a-4dfa-80bc-8bc4fb74f045',1,NULL,NULL,NULL,NULL,'text/html','Calendar Event Title','','','',0,0,0,0),(10728,10157,10132,10169,'Test Test','2014-04-03 17:04:30','2014-04-03 17:04:30',10093,10726,'159fd4aa-87d1-4bdd-8967-12133751c8ef',0,NULL,NULL,NULL,NULL,'text/html','10725','','','',0,0,0,0),(10748,10165,10132,10169,'Test Test','2014-04-03 17:05:30','2014-04-03 17:05:30',10046,10743,'84585a58-8a50-4615-bb90-e70c5ea5d79e',0,NULL,NULL,NULL,NULL,'','userCFfn userCFln','','','',0,0,0,0),(10755,10165,10132,10169,'Test Test','2014-04-03 17:06:06','2014-04-03 17:06:06',10012,10752,'',0,NULL,NULL,NULL,NULL,'','Blogs Site','','','',0,0,0,0),(10759,10752,10132,10169,'Test Test','2014-04-03 17:06:16','2014-04-03 17:06:16',10093,10757,'72e7d8e1-0c8c-4003-ab67-7c685bbefc5b',0,NULL,NULL,NULL,NULL,'text/html','10756','','','',0,0,0,0);
/*!40000 ALTER TABLE `AssetEntry` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `AssetLink`
--

DROP TABLE IF EXISTS `AssetLink`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `AssetLink` (
  `linkId` bigint(20) NOT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `userId` bigint(20) DEFAULT NULL,
  `userName` varchar(75) DEFAULT NULL,
  `createDate` datetime DEFAULT NULL,
  `entryId1` bigint(20) DEFAULT NULL,
  `entryId2` bigint(20) DEFAULT NULL,
  `type_` int(11) DEFAULT NULL,
  `weight` int(11) DEFAULT NULL,
  PRIMARY KEY (`linkId`),
  KEY `IX_128516C8` (`entryId1`),
  KEY `IX_56E0AB21` (`entryId1`,`entryId2`),
  KEY `IX_8F542794` (`entryId1`,`entryId2`,`type_`),
  KEY `IX_14D5A20D` (`entryId1`,`type_`),
  KEY `IX_12851A89` (`entryId2`),
  KEY `IX_91F132C` (`entryId2`,`type_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `AssetLink`
--

LOCK TABLES `AssetLink` WRITE;
/*!40000 ALTER TABLE `AssetLink` DISABLE KEYS */;
/*!40000 ALTER TABLE `AssetLink` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `AssetTag`
--

DROP TABLE IF EXISTS `AssetTag`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `AssetTag` (
  `tagId` bigint(20) NOT NULL,
  `groupId` bigint(20) DEFAULT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `userId` bigint(20) DEFAULT NULL,
  `userName` varchar(75) DEFAULT NULL,
  `createDate` datetime DEFAULT NULL,
  `modifiedDate` datetime DEFAULT NULL,
  `name` varchar(75) DEFAULT NULL,
  `assetCount` int(11) DEFAULT NULL,
  PRIMARY KEY (`tagId`),
  KEY `IX_7C9E46BA` (`groupId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `AssetTag`
--

LOCK TABLES `AssetTag` WRITE;
/*!40000 ALTER TABLE `AssetTag` DISABLE KEYS */;
INSERT INTO `AssetTag` VALUES (10762,10752,10132,10169,'Test Test','2014-04-03 17:06:25','2014-04-03 17:06:25','blue',0);
/*!40000 ALTER TABLE `AssetTag` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `AssetTagProperty`
--

DROP TABLE IF EXISTS `AssetTagProperty`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `AssetTagProperty` (
  `tagPropertyId` bigint(20) NOT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `userId` bigint(20) DEFAULT NULL,
  `userName` varchar(75) DEFAULT NULL,
  `createDate` datetime DEFAULT NULL,
  `modifiedDate` datetime DEFAULT NULL,
  `tagId` bigint(20) DEFAULT NULL,
  `key_` varchar(75) DEFAULT NULL,
  `value` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`tagPropertyId`),
  UNIQUE KEY `IX_2C944354` (`tagId`,`key_`),
  KEY `IX_DFF1F063` (`companyId`),
  KEY `IX_13805BF7` (`companyId`,`key_`),
  KEY `IX_3269E180` (`tagId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `AssetTagProperty`
--

LOCK TABLES `AssetTagProperty` WRITE;
/*!40000 ALTER TABLE `AssetTagProperty` DISABLE KEYS */;
/*!40000 ALTER TABLE `AssetTagProperty` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `AssetTagStats`
--

DROP TABLE IF EXISTS `AssetTagStats`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `AssetTagStats` (
  `tagStatsId` bigint(20) NOT NULL,
  `tagId` bigint(20) DEFAULT NULL,
  `classNameId` bigint(20) DEFAULT NULL,
  `assetCount` int(11) DEFAULT NULL,
  PRIMARY KEY (`tagStatsId`),
  UNIQUE KEY `IX_56682CC4` (`tagId`,`classNameId`),
  KEY `IX_50702693` (`classNameId`),
  KEY `IX_9464CA` (`tagId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `AssetTagStats`
--

LOCK TABLES `AssetTagStats` WRITE;
/*!40000 ALTER TABLE `AssetTagStats` DISABLE KEYS */;
/*!40000 ALTER TABLE `AssetTagStats` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `AssetVocabulary`
--

DROP TABLE IF EXISTS `AssetVocabulary`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `AssetVocabulary` (
  `uuid_` varchar(75) DEFAULT NULL,
  `vocabularyId` bigint(20) NOT NULL,
  `groupId` bigint(20) DEFAULT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `userId` bigint(20) DEFAULT NULL,
  `userName` varchar(75) DEFAULT NULL,
  `createDate` datetime DEFAULT NULL,
  `modifiedDate` datetime DEFAULT NULL,
  `name` varchar(75) DEFAULT NULL,
  `title` longtext,
  `description` longtext,
  `settings_` longtext,
  PRIMARY KEY (`vocabularyId`),
  UNIQUE KEY `IX_C0AAD74D` (`groupId`,`name`),
  UNIQUE KEY `IX_1B2B8792` (`uuid_`,`groupId`),
  KEY `IX_B22D908C` (`companyId`),
  KEY `IX_B6B8CA0E` (`groupId`),
  KEY `IX_55F58818` (`uuid_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `AssetVocabulary`
--

LOCK TABLES `AssetVocabulary` WRITE;
/*!40000 ALTER TABLE `AssetVocabulary` DISABLE KEYS */;
INSERT INTO `AssetVocabulary` VALUES ('caafe4d6-2267-436e-9a3f-a74ea6a63736',10409,10388,10132,10135,' ','2014-04-03 16:44:56','2014-04-03 16:44:56','Topic','<?xml version=\'1.0\' encoding=\'UTF-8\'?><root available-locales=\"en_US\" default-locale=\"en_US\"><Title language-id=\"en_US\">Topic</Title></root>','',''),('1e5a9318-e896-4c5f-bca8-13a1cbccfa0a',10410,10165,10132,10135,' ','2014-04-03 16:44:56','2014-04-03 16:44:56','Topic','<?xml version=\'1.0\' encoding=\'UTF-8\'?><root available-locales=\"en_US\" default-locale=\"en_US\"><Title language-id=\"en_US\">Topic</Title></root>','',''),('231ced18-5836-4ab7-ac40-4d67a82ccfe4',10468,10435,10132,10135,' ','2014-04-03 16:48:56','2014-04-03 16:48:56','Topic','<?xml version=\'1.0\' encoding=\'UTF-8\'?><root available-locales=\"en_US\" default-locale=\"en_US\"><Title language-id=\"en_US\">Topic</Title></root>','',''),('03fee74f-1c01-4646-b18c-54e67ac99746',10469,10435,10132,10169,'Test Test','2014-04-03 16:49:01','2014-04-03 16:49:01','Vocabulary Name','<?xml version=\'1.0\' encoding=\'UTF-8\'?><root available-locales=\"en_US\" default-locale=\"en_US\"><Title language-id=\"en_US\">Vocabulary Name</Title></root>','',''),('ee7254ac-141c-4fa2-91d8-7df9c4a039e1',10634,10617,10132,10135,' ','2014-04-03 16:57:47','2014-04-03 16:57:47','Topic','<?xml version=\'1.0\' encoding=\'UTF-8\'?><root available-locales=\"en_US\" default-locale=\"en_US\"><Title language-id=\"en_US\">Topic</Title></root>','',''),('ee7254ac-141c-4fa2-91d8-7df9c4a039e1',10635,10626,10132,10135,' ','2014-04-03 16:57:47','2014-04-03 16:57:47','Topic','<?xml version=\'1.0\' encoding=\'UTF-8\'?><root available-locales=\"en_US\" default-locale=\"en_US\"><Title language-id=\"en_US\">Topic</Title></root>','','');
/*!40000 ALTER TABLE `AssetVocabulary` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `BlogsEntry`
--

DROP TABLE IF EXISTS `BlogsEntry`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `BlogsEntry` (
  `uuid_` varchar(75) DEFAULT NULL,
  `entryId` bigint(20) NOT NULL,
  `groupId` bigint(20) DEFAULT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `userId` bigint(20) DEFAULT NULL,
  `userName` varchar(75) DEFAULT NULL,
  `createDate` datetime DEFAULT NULL,
  `modifiedDate` datetime DEFAULT NULL,
  `title` varchar(150) DEFAULT NULL,
  `urlTitle` varchar(150) DEFAULT NULL,
  `content` longtext,
  `displayDate` datetime DEFAULT NULL,
  `allowPingbacks` tinyint(4) DEFAULT NULL,
  `allowTrackbacks` tinyint(4) DEFAULT NULL,
  `trackbacks` longtext,
  `status` int(11) DEFAULT NULL,
  `statusByUserId` bigint(20) DEFAULT NULL,
  `statusByUserName` varchar(75) DEFAULT NULL,
  `statusDate` datetime DEFAULT NULL,
  PRIMARY KEY (`entryId`),
  UNIQUE KEY `IX_DB780A20` (`groupId`,`urlTitle`),
  UNIQUE KEY `IX_1B1040FD` (`uuid_`,`groupId`),
  KEY `IX_72EF6041` (`companyId`),
  KEY `IX_430D791F` (`companyId`,`displayDate`),
  KEY `IX_BB0C2905` (`companyId`,`displayDate`,`status`),
  KEY `IX_EB2DCE27` (`companyId`,`status`),
  KEY `IX_8CACE77B` (`companyId`,`userId`),
  KEY `IX_A5F57B61` (`companyId`,`userId`,`status`),
  KEY `IX_81A50303` (`groupId`),
  KEY `IX_621E19D` (`groupId`,`displayDate`),
  KEY `IX_F0E73383` (`groupId`,`displayDate`,`status`),
  KEY `IX_1EFD8EE9` (`groupId`,`status`),
  KEY `IX_FBDE0AA3` (`groupId`,`userId`,`displayDate`),
  KEY `IX_DA04F689` (`groupId`,`userId`,`displayDate`,`status`),
  KEY `IX_49E15A23` (`groupId`,`userId`,`status`),
  KEY `IX_69157A4D` (`uuid_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `BlogsEntry`
--

LOCK TABLES `BlogsEntry` WRITE;
/*!40000 ALTER TABLE `BlogsEntry` DISABLE KEYS */;
/*!40000 ALTER TABLE `BlogsEntry` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `BlogsStatsUser`
--

DROP TABLE IF EXISTS `BlogsStatsUser`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `BlogsStatsUser` (
  `statsUserId` bigint(20) NOT NULL,
  `groupId` bigint(20) DEFAULT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `userId` bigint(20) DEFAULT NULL,
  `entryCount` int(11) DEFAULT NULL,
  `lastPostDate` datetime DEFAULT NULL,
  `ratingsTotalEntries` int(11) DEFAULT NULL,
  `ratingsTotalScore` double DEFAULT NULL,
  `ratingsAverageScore` double DEFAULT NULL,
  PRIMARY KEY (`statsUserId`),
  UNIQUE KEY `IX_82254C25` (`groupId`,`userId`),
  KEY `IX_90CDA39A` (`companyId`,`entryCount`),
  KEY `IX_43840EEB` (`groupId`),
  KEY `IX_28C78D5C` (`groupId`,`entryCount`),
  KEY `IX_BB51F1D9` (`userId`),
  KEY `IX_507BA031` (`userId`,`lastPostDate`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `BlogsStatsUser`
--

LOCK TABLES `BlogsStatsUser` WRITE;
/*!40000 ALTER TABLE `BlogsStatsUser` DISABLE KEYS */;
/*!40000 ALTER TABLE `BlogsStatsUser` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `BookmarksEntry`
--

DROP TABLE IF EXISTS `BookmarksEntry`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `BookmarksEntry` (
  `uuid_` varchar(75) DEFAULT NULL,
  `entryId` bigint(20) NOT NULL,
  `groupId` bigint(20) DEFAULT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `userId` bigint(20) DEFAULT NULL,
  `createDate` datetime DEFAULT NULL,
  `modifiedDate` datetime DEFAULT NULL,
  `folderId` bigint(20) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `url` longtext,
  `comments` longtext,
  `visits` int(11) DEFAULT NULL,
  `priority` int(11) DEFAULT NULL,
  PRIMARY KEY (`entryId`),
  UNIQUE KEY `IX_EAA02A91` (`uuid_`,`groupId`),
  KEY `IX_E52FF7EF` (`groupId`),
  KEY `IX_5200100C` (`groupId`,`folderId`),
  KEY `IX_E2E9F129` (`groupId`,`userId`),
  KEY `IX_B670BA39` (`uuid_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `BookmarksEntry`
--

LOCK TABLES `BookmarksEntry` WRITE;
/*!40000 ALTER TABLE `BookmarksEntry` DISABLE KEYS */;
INSERT INTO `BookmarksEntry` VALUES ('faec244e-7594-40eb-90a7-a06b6b4c47fa',10660,10157,10132,10169,'2014-04-03 16:58:47','2014-04-03 16:58:47',0,'Test Bookmark Name','http://www.liferay.com','Test Bookmark Description',0,0);
/*!40000 ALTER TABLE `BookmarksEntry` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `BookmarksFolder`
--

DROP TABLE IF EXISTS `BookmarksFolder`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `BookmarksFolder` (
  `uuid_` varchar(75) DEFAULT NULL,
  `folderId` bigint(20) NOT NULL,
  `groupId` bigint(20) DEFAULT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `userId` bigint(20) DEFAULT NULL,
  `createDate` datetime DEFAULT NULL,
  `modifiedDate` datetime DEFAULT NULL,
  `parentFolderId` bigint(20) DEFAULT NULL,
  `name` varchar(75) DEFAULT NULL,
  `description` longtext,
  PRIMARY KEY (`folderId`),
  UNIQUE KEY `IX_DC2F8927` (`uuid_`,`groupId`),
  KEY `IX_2ABA25D7` (`companyId`),
  KEY `IX_7F703619` (`groupId`),
  KEY `IX_967799C0` (`groupId`,`parentFolderId`),
  KEY `IX_451E7AE3` (`uuid_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `BookmarksFolder`
--

LOCK TABLES `BookmarksFolder` WRITE;
/*!40000 ALTER TABLE `BookmarksFolder` DISABLE KEYS */;
INSERT INTO `BookmarksFolder` VALUES ('4ff5675e-b809-45b6-b5c2-b623302c65c3',10662,10157,10132,10169,'2014-04-03 16:58:55','2014-04-03 16:58:55',0,'Test Folder Name','Test Folder Description');
/*!40000 ALTER TABLE `BookmarksFolder` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `BrowserTracker`
--

DROP TABLE IF EXISTS `BrowserTracker`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `BrowserTracker` (
  `browserTrackerId` bigint(20) NOT NULL,
  `userId` bigint(20) DEFAULT NULL,
  `browserKey` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`browserTrackerId`),
  UNIQUE KEY `IX_E7B95510` (`userId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `BrowserTracker`
--

LOCK TABLES `BrowserTracker` WRITE;
/*!40000 ALTER TABLE `BrowserTracker` DISABLE KEYS */;
/*!40000 ALTER TABLE `BrowserTracker` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CalEvent`
--

DROP TABLE IF EXISTS `CalEvent`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `CalEvent` (
  `uuid_` varchar(75) DEFAULT NULL,
  `eventId` bigint(20) NOT NULL,
  `groupId` bigint(20) DEFAULT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `userId` bigint(20) DEFAULT NULL,
  `userName` varchar(75) DEFAULT NULL,
  `createDate` datetime DEFAULT NULL,
  `modifiedDate` datetime DEFAULT NULL,
  `title` varchar(75) DEFAULT NULL,
  `description` longtext,
  `startDate` datetime DEFAULT NULL,
  `endDate` datetime DEFAULT NULL,
  `durationHour` int(11) DEFAULT NULL,
  `durationMinute` int(11) DEFAULT NULL,
  `allDay` tinyint(4) DEFAULT NULL,
  `timeZoneSensitive` tinyint(4) DEFAULT NULL,
  `type_` varchar(75) DEFAULT NULL,
  `repeating` tinyint(4) DEFAULT NULL,
  `recurrence` longtext,
  `remindBy` int(11) DEFAULT NULL,
  `firstReminder` int(11) DEFAULT NULL,
  `secondReminder` int(11) DEFAULT NULL,
  PRIMARY KEY (`eventId`),
  UNIQUE KEY `IX_5CCE79C8` (`uuid_`,`groupId`),
  KEY `IX_D6FD9496` (`companyId`),
  KEY `IX_12EE4898` (`groupId`),
  KEY `IX_4FDDD2BF` (`groupId`,`repeating`),
  KEY `IX_FCD7C63D` (`groupId`,`type_`),
  KEY `IX_F6006202` (`remindBy`),
  KEY `IX_C1AD2122` (`uuid_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CalEvent`
--

LOCK TABLES `CalEvent` WRITE;
/*!40000 ALTER TABLE `CalEvent` DISABLE KEYS */;
INSERT INTO `CalEvent` VALUES ('bf2157d4-a10a-4dfa-80bc-8bc4fb74f045',10723,10157,10132,10169,'Test Test','2014-04-03 17:04:07','2014-04-03 17:04:07','Calendar Event Title','','2014-04-03 17:15:00','2015-04-03 23:59:59',1,0,0,1,'anniversary',0,'null',1,900000,300000);
/*!40000 ALTER TABLE `CalEvent` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ClassName_`
--

DROP TABLE IF EXISTS `ClassName_`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ClassName_` (
  `classNameId` bigint(20) NOT NULL,
  `value` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`classNameId`),
  UNIQUE KEY `IX_B27A301F` (`value`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ClassName_`
--

LOCK TABLES `ClassName_` WRITE;
/*!40000 ALTER TABLE `ClassName_` DISABLE KEYS */;
INSERT INTO `ClassName_` VALUES (10001,'com.liferay.counter.model.Counter'),(10002,'com.liferay.portal.kernel.workflow.WorkflowTask'),(10003,'com.liferay.portal.model.Account'),(10004,'com.liferay.portal.model.Address'),(10005,'com.liferay.portal.model.BrowserTracker'),(10006,'com.liferay.portal.model.ClassName'),(10007,'com.liferay.portal.model.ClusterGroup'),(10008,'com.liferay.portal.model.Company'),(10009,'com.liferay.portal.model.Contact'),(10010,'com.liferay.portal.model.Country'),(10011,'com.liferay.portal.model.EmailAddress'),(10012,'com.liferay.portal.model.Group'),(10013,'com.liferay.portal.model.Image'),(10014,'com.liferay.portal.model.Layout'),(10015,'com.liferay.portal.model.LayoutPrototype'),(10016,'com.liferay.portal.model.LayoutSet'),(10017,'com.liferay.portal.model.LayoutSetPrototype'),(10018,'com.liferay.portal.model.ListType'),(10019,'com.liferay.portal.model.Lock'),(10020,'com.liferay.portal.model.MembershipRequest'),(10024,'com.liferay.portal.model.Organization'),(10021,'com.liferay.portal.model.OrgGroupPermission'),(10022,'com.liferay.portal.model.OrgGroupRole'),(10023,'com.liferay.portal.model.OrgLabor'),(10025,'com.liferay.portal.model.PasswordPolicy'),(10026,'com.liferay.portal.model.PasswordPolicyRel'),(10027,'com.liferay.portal.model.PasswordTracker'),(10028,'com.liferay.portal.model.Permission'),(10029,'com.liferay.portal.model.Phone'),(10030,'com.liferay.portal.model.PluginSetting'),(10031,'com.liferay.portal.model.Portlet'),(10032,'com.liferay.portal.model.PortletItem'),(10033,'com.liferay.portal.model.PortletPreferences'),(10034,'com.liferay.portal.model.Region'),(10035,'com.liferay.portal.model.Release'),(10036,'com.liferay.portal.model.Resource'),(10037,'com.liferay.portal.model.ResourceAction'),(10038,'com.liferay.portal.model.ResourceCode'),(10039,'com.liferay.portal.model.ResourcePermission'),(10040,'com.liferay.portal.model.Role'),(10041,'com.liferay.portal.model.ServiceComponent'),(10042,'com.liferay.portal.model.Shard'),(10043,'com.liferay.portal.model.Subscription'),(10044,'com.liferay.portal.model.Team'),(10045,'com.liferay.portal.model.Ticket'),(10046,'com.liferay.portal.model.User'),(10047,'com.liferay.portal.model.UserGroup'),(10048,'com.liferay.portal.model.UserGroupGroupRole'),(10049,'com.liferay.portal.model.UserGroupRole'),(10050,'com.liferay.portal.model.UserIdMapper'),(10051,'com.liferay.portal.model.UserTracker'),(10052,'com.liferay.portal.model.UserTrackerPath'),(10053,'com.liferay.portal.model.WebDAVProps'),(10054,'com.liferay.portal.model.Website'),(10055,'com.liferay.portal.model.WorkflowDefinitionLink'),(10056,'com.liferay.portal.model.WorkflowInstanceLink'),(10261,'com.liferay.portal.workflow.kaleo.model.KaleoAction'),(10262,'com.liferay.portal.workflow.kaleo.model.KaleoDefinition'),(10263,'com.liferay.portal.workflow.kaleo.model.KaleoInstance'),(10264,'com.liferay.portal.workflow.kaleo.model.KaleoInstanceToken'),(10265,'com.liferay.portal.workflow.kaleo.model.KaleoLog'),(10266,'com.liferay.portal.workflow.kaleo.model.KaleoNode'),(10267,'com.liferay.portal.workflow.kaleo.model.KaleoNotification'),(10268,'com.liferay.portal.workflow.kaleo.model.KaleoNotificationRecipient'),(10269,'com.liferay.portal.workflow.kaleo.model.KaleoTask'),(10270,'com.liferay.portal.workflow.kaleo.model.KaleoTaskAssignment'),(10271,'com.liferay.portal.workflow.kaleo.model.KaleoTaskAssignmentInstance'),(10272,'com.liferay.portal.workflow.kaleo.model.KaleoTaskInstanceToken'),(10273,'com.liferay.portal.workflow.kaleo.model.KaleoTransition'),(10057,'com.liferay.portlet.announcements.model.AnnouncementsDelivery'),(10058,'com.liferay.portlet.announcements.model.AnnouncementsEntry'),(10059,'com.liferay.portlet.announcements.model.AnnouncementsFlag'),(10060,'com.liferay.portlet.asset.model.AssetCategory'),(10061,'com.liferay.portlet.asset.model.AssetCategoryProperty'),(10062,'com.liferay.portlet.asset.model.AssetEntry'),(10063,'com.liferay.portlet.asset.model.AssetLink'),(10064,'com.liferay.portlet.asset.model.AssetTag'),(10065,'com.liferay.portlet.asset.model.AssetTagProperty'),(10066,'com.liferay.portlet.asset.model.AssetTagStats'),(10067,'com.liferay.portlet.asset.model.AssetVocabulary'),(10068,'com.liferay.portlet.blogs.model.BlogsEntry'),(10069,'com.liferay.portlet.blogs.model.BlogsStatsUser'),(10070,'com.liferay.portlet.bookmarks.model.BookmarksEntry'),(10071,'com.liferay.portlet.bookmarks.model.BookmarksFolder'),(10072,'com.liferay.portlet.calendar.model.CalEvent'),(10073,'com.liferay.portlet.documentlibrary.model.DLFileEntry'),(10074,'com.liferay.portlet.documentlibrary.model.DLFileRank'),(10075,'com.liferay.portlet.documentlibrary.model.DLFileShortcut'),(10076,'com.liferay.portlet.documentlibrary.model.DLFileVersion'),(10077,'com.liferay.portlet.documentlibrary.model.DLFolder'),(10078,'com.liferay.portlet.expando.model.ExpandoColumn'),(10079,'com.liferay.portlet.expando.model.ExpandoRow'),(10080,'com.liferay.portlet.expando.model.ExpandoTable'),(10081,'com.liferay.portlet.expando.model.ExpandoValue'),(10082,'com.liferay.portlet.imagegallery.model.IGFolder'),(10083,'com.liferay.portlet.imagegallery.model.IGImage'),(10084,'com.liferay.portlet.journal.model.JournalArticle'),(10085,'com.liferay.portlet.journal.model.JournalArticleImage'),(10086,'com.liferay.portlet.journal.model.JournalArticleResource'),(10087,'com.liferay.portlet.journal.model.JournalContentSearch'),(10088,'com.liferay.portlet.journal.model.JournalFeed'),(10089,'com.liferay.portlet.journal.model.JournalStructure'),(10090,'com.liferay.portlet.journal.model.JournalTemplate'),(10091,'com.liferay.portlet.messageboards.model.MBBan'),(10092,'com.liferay.portlet.messageboards.model.MBCategory'),(10093,'com.liferay.portlet.messageboards.model.MBDiscussion'),(10094,'com.liferay.portlet.messageboards.model.MBMailingList'),(10095,'com.liferay.portlet.messageboards.model.MBMessage'),(10096,'com.liferay.portlet.messageboards.model.MBMessageFlag'),(10097,'com.liferay.portlet.messageboards.model.MBStatsUser'),(10098,'com.liferay.portlet.messageboards.model.MBThread'),(10099,'com.liferay.portlet.polls.model.PollsChoice'),(10100,'com.liferay.portlet.polls.model.PollsQuestion'),(10101,'com.liferay.portlet.polls.model.PollsVote'),(10102,'com.liferay.portlet.ratings.model.RatingsEntry'),(10103,'com.liferay.portlet.ratings.model.RatingsStats'),(10104,'com.liferay.portlet.shopping.model.ShoppingCart'),(10105,'com.liferay.portlet.shopping.model.ShoppingCategory'),(10106,'com.liferay.portlet.shopping.model.ShoppingCoupon'),(10107,'com.liferay.portlet.shopping.model.ShoppingItem'),(10108,'com.liferay.portlet.shopping.model.ShoppingItemField'),(10109,'com.liferay.portlet.shopping.model.ShoppingItemPrice'),(10110,'com.liferay.portlet.shopping.model.ShoppingOrder'),(10111,'com.liferay.portlet.shopping.model.ShoppingOrderItem'),(10112,'com.liferay.portlet.social.model.SocialActivity'),(10113,'com.liferay.portlet.social.model.SocialEquityAssetEntry'),(10114,'com.liferay.portlet.social.model.SocialEquityGroupSetting'),(10115,'com.liferay.portlet.social.model.SocialEquityHistory'),(10116,'com.liferay.portlet.social.model.SocialEquityLog'),(10117,'com.liferay.portlet.social.model.SocialEquitySetting'),(10118,'com.liferay.portlet.social.model.SocialEquityUser'),(10119,'com.liferay.portlet.social.model.SocialRelation'),(10120,'com.liferay.portlet.social.model.SocialRequest'),(10121,'com.liferay.portlet.softwarecatalog.model.SCFrameworkVersion'),(10122,'com.liferay.portlet.softwarecatalog.model.SCLicense'),(10123,'com.liferay.portlet.softwarecatalog.model.SCProductEntry'),(10124,'com.liferay.portlet.softwarecatalog.model.SCProductScreenshot'),(10125,'com.liferay.portlet.softwarecatalog.model.SCProductVersion'),(10126,'com.liferay.portlet.tasks.model.TasksProposal'),(10127,'com.liferay.portlet.tasks.model.TasksReview'),(10128,'com.liferay.portlet.wiki.model.WikiNode'),(10129,'com.liferay.portlet.wiki.model.WikiPage'),(10130,'com.liferay.portlet.wiki.model.WikiPageResource'),(10301,'com.liferay.socialnetworking.model.MeetupsEntry'),(10302,'com.liferay.socialnetworking.model.MeetupsRegistration'),(10303,'com.liferay.socialnetworking.model.WallEntry');
/*!40000 ALTER TABLE `ClassName_` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ClusterGroup`
--

DROP TABLE IF EXISTS `ClusterGroup`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ClusterGroup` (
  `clusterGroupId` bigint(20) NOT NULL,
  `name` varchar(75) DEFAULT NULL,
  `clusterNodeIds` varchar(75) DEFAULT NULL,
  `wholeCluster` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`clusterGroupId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ClusterGroup`
--

LOCK TABLES `ClusterGroup` WRITE;
/*!40000 ALTER TABLE `ClusterGroup` DISABLE KEYS */;
/*!40000 ALTER TABLE `ClusterGroup` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Company`
--

DROP TABLE IF EXISTS `Company`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Company` (
  `companyId` bigint(20) NOT NULL,
  `accountId` bigint(20) DEFAULT NULL,
  `webId` varchar(75) DEFAULT NULL,
  `key_` longtext,
  `virtualHost` varchar(75) DEFAULT NULL,
  `mx` varchar(75) DEFAULT NULL,
  `homeURL` longtext,
  `logoId` bigint(20) DEFAULT NULL,
  `system` tinyint(4) DEFAULT NULL,
  `maxUsers` int(11) DEFAULT NULL,
  PRIMARY KEY (`companyId`),
  UNIQUE KEY `IX_975996C0` (`virtualHost`),
  UNIQUE KEY `IX_EC00543C` (`webId`),
  KEY `IX_38EFE3FD` (`logoId`),
  KEY `IX_12566EC2` (`mx`),
  KEY `IX_35E3E7C6` (`system`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Company`
--

LOCK TABLES `Company` WRITE;
/*!40000 ALTER TABLE `Company` DISABLE KEYS */;
INSERT INTO `Company` VALUES (10132,10134,'liferay.com','rO0ABXNyABRqYXZhLnNlY3VyaXR5LktleVJlcL35T7OImqVDAgAETAAJYWxnb3JpdGhtdAASTGphdmEvbGFuZy9TdHJpbmc7WwAHZW5jb2RlZHQAAltCTAAGZm9ybWF0cQB+AAFMAAR0eXBldAAbTGphdmEvc2VjdXJpdHkvS2V5UmVwJFR5cGU7eHB0AANERVN1cgACW0Ks8xf4BghU4AIAAHhwAAAACBB/hnPpKoU3dAADUkFXfnIAGWphdmEuc2VjdXJpdHkuS2V5UmVwJFR5cGUAAAAAAAAAABIAAHhyAA5qYXZhLmxhbmcuRW51bQAAAAAAAAAAEgAAeHB0AAZTRUNSRVQ=','localhost','liferay.com','',0,0,0);
/*!40000 ALTER TABLE `Company` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Contact_`
--

DROP TABLE IF EXISTS `Contact_`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Contact_` (
  `contactId` bigint(20) NOT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `userId` bigint(20) DEFAULT NULL,
  `userName` varchar(75) DEFAULT NULL,
  `createDate` datetime DEFAULT NULL,
  `modifiedDate` datetime DEFAULT NULL,
  `accountId` bigint(20) DEFAULT NULL,
  `parentContactId` bigint(20) DEFAULT NULL,
  `firstName` varchar(75) DEFAULT NULL,
  `middleName` varchar(75) DEFAULT NULL,
  `lastName` varchar(75) DEFAULT NULL,
  `prefixId` int(11) DEFAULT NULL,
  `suffixId` int(11) DEFAULT NULL,
  `male` tinyint(4) DEFAULT NULL,
  `birthday` datetime DEFAULT NULL,
  `smsSn` varchar(75) DEFAULT NULL,
  `aimSn` varchar(75) DEFAULT NULL,
  `facebookSn` varchar(75) DEFAULT NULL,
  `icqSn` varchar(75) DEFAULT NULL,
  `jabberSn` varchar(75) DEFAULT NULL,
  `msnSn` varchar(75) DEFAULT NULL,
  `mySpaceSn` varchar(75) DEFAULT NULL,
  `skypeSn` varchar(75) DEFAULT NULL,
  `twitterSn` varchar(75) DEFAULT NULL,
  `ymSn` varchar(75) DEFAULT NULL,
  `employeeStatusId` varchar(75) DEFAULT NULL,
  `employeeNumber` varchar(75) DEFAULT NULL,
  `jobTitle` varchar(100) DEFAULT NULL,
  `jobClass` varchar(75) DEFAULT NULL,
  `hoursOfOperation` varchar(75) DEFAULT NULL,
  PRIMARY KEY (`contactId`),
  KEY `IX_66D496A3` (`companyId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Contact_`
--

LOCK TABLES `Contact_` WRITE;
/*!40000 ALTER TABLE `Contact_` DISABLE KEYS */;
INSERT INTO `Contact_` VALUES (10136,10132,10135,'','2014-04-03 16:33:40','2014-04-03 16:33:40',10134,0,'','','',0,0,1,'2014-04-03 16:33:40','','','','','','','','','','','','','','',''),(10170,10132,10169,'','2014-04-03 16:33:40','2014-04-03 17:07:24',10134,0,'Test','','Test',0,0,1,'1970-01-01 00:00:00','','','','','','','','','','','','','','',''),(10366,10132,10169,'Test Test','2014-04-03 16:40:50','2014-04-03 16:40:50',10134,0,'userfn','','userln',0,0,1,'1970-01-01 00:00:00','','','','','','','','','','','','','','',''),(10544,10132,10169,'Test Test','2014-04-03 16:51:43','2014-04-03 16:52:34',10134,0,'userPPfn','','userPPln',0,0,1,'1970-01-01 00:00:00','','','','','','','','','','','','','','',''),(10590,10132,10169,'Test Test','2014-04-03 16:56:03','2014-04-03 16:56:13',10134,0,'userSMfn','','userSMln',0,0,1,'1970-01-01 00:00:00','','','','','','','','','','','','','','',''),(10744,10132,10169,'Test Test','2014-04-03 17:05:30','2014-04-03 17:05:30',10134,0,'userCFfn','','userCFln',0,0,1,'1970-01-01 00:00:00','','','','','','','','','','','','','','','');
/*!40000 ALTER TABLE `Contact_` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Counter`
--

DROP TABLE IF EXISTS `Counter`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Counter` (
  `name` varchar(75) NOT NULL,
  `currentId` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Counter`
--

LOCK TABLES `Counter` WRITE;
/*!40000 ALTER TABLE `Counter` DISABLE KEYS */;
INSERT INTO `Counter` VALUES ('com.liferay.counter.model.Counter',10800),('com.liferay.portal.model.Layout#10149#true',1),('com.liferay.portal.model.Layout#10157#false',7),('com.liferay.portal.model.Layout#10171#false',1),('com.liferay.portal.model.Layout#10171#true',1),('com.liferay.portal.model.Layout#10388#false',1),('com.liferay.portal.model.Layout#10435#false',1),('com.liferay.portal.model.Layout#10481#false',1),('com.liferay.portal.model.Layout#10523#true',1),('com.liferay.portal.model.Layout#10533#true',1),('com.liferay.portal.model.Layout#10545#false',1),('com.liferay.portal.model.Layout#10545#true',1),('com.liferay.portal.model.Layout#10591#false',1),('com.liferay.portal.model.Layout#10591#true',1),('com.liferay.portal.model.Layout#10617#false',1),('com.liferay.portal.model.Layout#10626#false',1),('com.liferay.portal.model.Layout#10663#false',1),('com.liferay.portal.model.Layout#10678#false',1),('com.liferay.portal.model.Layout#10752#false',1),('com.liferay.portal.model.Permission',100),('com.liferay.portal.model.Resource',100),('com.liferay.portal.model.ResourceAction',700),('com.liferay.portal.model.ResourcePermission',700),('com.liferay.portal.model.UserTracker',100),('com.liferay.portal.model.UserTrackerPath',900),('com.liferay.portlet.documentlibrary.model.DLFileEntry',100),('com.liferay.portlet.social.model.SocialActivity',100);
/*!40000 ALTER TABLE `Counter` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Country`
--

DROP TABLE IF EXISTS `Country`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Country` (
  `countryId` bigint(20) NOT NULL,
  `name` varchar(75) DEFAULT NULL,
  `a2` varchar(75) DEFAULT NULL,
  `a3` varchar(75) DEFAULT NULL,
  `number_` varchar(75) DEFAULT NULL,
  `idd_` varchar(75) DEFAULT NULL,
  `active_` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`countryId`),
  UNIQUE KEY `IX_717B97E1` (`a2`),
  UNIQUE KEY `IX_717B9BA2` (`a3`),
  UNIQUE KEY `IX_19DA007B` (`name`),
  KEY `IX_25D734CD` (`active_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Country`
--

LOCK TABLES `Country` WRITE;
/*!40000 ALTER TABLE `Country` DISABLE KEYS */;
INSERT INTO `Country` VALUES (1,'Canada','CA','CAN','124','001',1),(2,'China','CN','CHN','156','086',1),(3,'France','FR','FRA','250','033',1),(4,'Germany','DE','DEU','276','049',1),(5,'Hong Kong','HK','HKG','344','852',1),(6,'Hungary','HU','HUN','348','036',1),(7,'Israel','IL','ISR','376','972',1),(8,'Italy','IT','ITA','380','039',1),(9,'Japan','JP','JPN','392','081',1),(10,'South Korea','KR','KOR','410','082',1),(11,'Netherlands','NL','NLD','528','031',1),(12,'Portugal','PT','PRT','620','351',1),(13,'Russia','RU','RUS','643','007',1),(14,'Singapore','SG','SGP','702','065',1),(15,'Spain','ES','ESP','724','034',1),(16,'Turkey','TR','TUR','792','090',1),(17,'Vietnam','VN','VNM','704','084',1),(18,'United Kingdom','GB','GBR','826','044',1),(19,'United States','US','USA','840','001',1),(20,'Afghanistan','AF','AFG','4','093',1),(21,'Albania','AL','ALB','8','355',1),(22,'Algeria','DZ','DZA','12','213',1),(23,'American Samoa','AS','ASM','16','684',1),(24,'Andorra','AD','AND','20','376',1),(25,'Angola','AO','AGO','24','244',1),(26,'Anguilla','AI','AIA','660','264',1),(27,'Antarctica','AQ','ATA','10','672',1),(28,'Antigua','AG','ATG','28','268',1),(29,'Argentina','AR','ARG','32','054',1),(30,'Armenia','AM','ARM','51','374',1),(31,'Aruba','AW','ABW','533','297',1),(32,'Australia','AU','AUS','36','061',1),(33,'Austria','AT','AUT','40','043',1),(34,'Azerbaijan','AZ','AZE','31','994',1),(35,'Bahamas','BS','BHS','44','242',1),(36,'Bahrain','BH','BHR','48','973',1),(37,'Bangladesh','BD','BGD','50','880',1),(38,'Barbados','BB','BRB','52','246',1),(39,'Belarus','BY','BLR','112','375',1),(40,'Belgium','BE','BEL','56','032',1),(41,'Belize','BZ','BLZ','84','501',1),(42,'Benin','BJ','BEN','204','229',1),(43,'Bermuda','BM','BMU','60','441',1),(44,'Bhutan','BT','BTN','64','975',1),(45,'Bolivia','BO','BOL','68','591',1),(46,'Bosnia-Herzegovina','BA','BIH','70','387',1),(47,'Botswana','BW','BWA','72','267',1),(48,'Brazil','BR','BRA','76','055',1),(49,'British Virgin Islands','VG','VGB','92','284',1),(50,'Brunei','BN','BRN','96','673',1),(51,'Bulgaria','BG','BGR','100','359',1),(52,'Burkina Faso','BF','BFA','854','226',1),(53,'Burma (Myanmar)','MM','MMR','104','095',1),(54,'Burundi','BI','BDI','108','257',1),(55,'Cambodia','KH','KHM','116','855',1),(56,'Cameroon','CM','CMR','120','237',1),(57,'Cape Verde Island','CV','CPV','132','238',1),(58,'Cayman Islands','KY','CYM','136','345',1),(59,'Central African Republic','CF','CAF','140','236',1),(60,'Chad','TD','TCD','148','235',1),(61,'Chile','CL','CHL','152','056',1),(62,'Christmas Island','CX','CXR','162','061',1),(63,'Cocos Islands','CC','CCK','166','061',1),(64,'Colombia','CO','COL','170','057',1),(65,'Comoros','KM','COM','174','269',1),(66,'Republic of Congo','CD','COD','180','242',1),(67,'Democratic Republic of Congo','CG','COG','178','243',1),(68,'Cook Islands','CK','COK','184','682',1),(69,'Costa Rica','CR','CRI','188','506',1),(70,'Croatia','HR','HRV','191','385',1),(71,'Cuba','CU','CUB','192','053',1),(72,'Cyprus','CY','CYP','196','357',1),(73,'Czech Republic','CZ','CZE','203','420',1),(74,'Denmark','DK','DNK','208','045',1),(75,'Djibouti','DJ','DJI','262','253',1),(76,'Dominica','DM','DMA','212','767',1),(77,'Dominican Republic','DO','DOM','214','809',1),(78,'Ecuador','EC','ECU','218','593',1),(79,'Egypt','EG','EGY','818','020',1),(80,'El Salvador','SV','SLV','222','503',1),(81,'Equatorial Guinea','GQ','GNQ','226','240',1),(82,'Eritrea','ER','ERI','232','291',1),(83,'Estonia','EE','EST','233','372',1),(84,'Ethiopia','ET','ETH','231','251',1),(85,'Faeroe Islands','FO','FRO','234','298',1),(86,'Falkland Islands','FK','FLK','238','500',1),(87,'Fiji Islands','FJ','FJI','242','679',1),(88,'Finland','FI','FIN','246','358',1),(89,'French Guiana','GF','GUF','254','594',1),(90,'French Polynesia','PF','PYF','258','689',1),(91,'Gabon','GA','GAB','266','241',1),(92,'Gambia','GM','GMB','270','220',1),(93,'Georgia','GE','GEO','268','995',1),(94,'Ghana','GH','GHA','288','233',1),(95,'Gibraltar','GI','GIB','292','350',1),(96,'Greece','GR','GRC','300','030',1),(97,'Greenland','GL','GRL','304','299',1),(98,'Grenada','GD','GRD','308','473',1),(99,'Guadeloupe','GP','GLP','312','590',1),(100,'Guam','GU','GUM','316','671',1),(101,'Guatemala','GT','GTM','320','502',1),(102,'Guinea','GN','GIN','324','224',1),(103,'Guinea-Bissau','GW','GNB','624','245',1),(104,'Guyana','GY','GUY','328','592',1),(105,'Haiti','HT','HTI','332','509',1),(106,'Honduras','HN','HND','340','504',1),(107,'Iceland','IS','ISL','352','354',1),(108,'India','IN','IND','356','091',1),(109,'Indonesia','ID','IDN','360','062',1),(110,'Iran','IR','IRN','364','098',1),(111,'Iraq','IQ','IRQ','368','964',1),(112,'Ireland','IE','IRL','372','353',1),(113,'Ivory Coast','CI','CIV','384','225',1),(114,'Jamaica','JM','JAM','388','876',1),(115,'Jordan','JO','JOR','400','962',1),(116,'Kazakhstan','KZ','KAZ','398','007',1),(117,'Kenya','KE','KEN','404','254',1),(118,'Kiribati','KI','KIR','408','686',1),(119,'Kuwait','KW','KWT','414','965',1),(120,'North Korea','KP','PRK','408','850',1),(121,'Kyrgyzstan','KG','KGZ','471','996',1),(122,'Laos','LA','LAO','418','856',1),(123,'Latvia','LV','LVA','428','371',1),(124,'Lebanon','LB','LBN','422','961',1),(125,'Lesotho','LS','LSO','426','266',1),(126,'Liberia','LR','LBR','430','231',1),(127,'Libya','LY','LBY','434','218',1),(128,'Liechtenstein','LI','LIE','438','423',1),(129,'Lithuania','LT','LTU','440','370',1),(130,'Luxembourg','LU','LUX','442','352',1),(131,'Macau','MO','MAC','446','853',1),(132,'Macedonia','MK','MKD','807','389',1),(133,'Madagascar','MG','MDG','450','261',1),(134,'Malawi','MW','MWI','454','265',1),(135,'Malaysia','MY','MYS','458','060',1),(136,'Maldives','MV','MDV','462','960',1),(137,'Mali','ML','MLI','466','223',1),(138,'Malta','MT','MLT','470','356',1),(139,'Marshall Islands','MH','MHL','584','692',1),(140,'Martinique','MQ','MTQ','474','596',1),(141,'Mauritania','MR','MRT','478','222',1),(142,'Mauritius','MU','MUS','480','230',1),(143,'Mayotte Island','YT','MYT','175','269',1),(144,'Mexico','MX','MEX','484','052',1),(145,'Micronesia','FM','FSM','583','691',1),(146,'Moldova','MD','MDA','498','373',1),(147,'Monaco','MC','MCO','492','377',1),(148,'Mongolia','MN','MNG','496','976',1),(149,'Montenegro','ME','MNE','499','382',1),(150,'Montserrat','MS','MSR','500','664',1),(151,'Morocco','MA','MAR','504','212',1),(152,'Mozambique','MZ','MOZ','508','258',1),(153,'Namibia','NA','NAM','516','264',1),(154,'Nauru','NR','NRU','520','674',1),(155,'Nepal','NP','NPL','524','977',1),(156,'Netherlands Antilles','AN','ANT','530','599',1),(157,'New Caledonia','NC','NCL','540','687',1),(158,'New Zealand','NZ','NZL','554','064',1),(159,'Nicaragua','NI','NIC','558','505',1),(160,'Niger','NE','NER','562','227',1),(161,'Nigeria','NG','NGA','566','234',1),(162,'Niue','NU','NIU','570','683',1),(163,'Norfolk Island','NF','NFK','574','672',1),(164,'Norway','NO','NOR','578','047',1),(165,'Oman','OM','OMN','512','968',1),(166,'Pakistan','PK','PAK','586','092',1),(167,'Palau','PW','PLW','585','680',1),(168,'Palestine','PS','PSE','275','970',1),(169,'Panama','PA','PAN','591','507',1),(170,'Papua New Guinea','PG','PNG','598','675',1),(171,'Paraguay','PY','PRY','600','595',1),(172,'Peru','PE','PER','604','051',1),(173,'Philippines','PH','PHL','608','063',1),(174,'Poland','PL','POL','616','048',1),(175,'Puerto Rico','PR','PRI','630','787',1),(176,'Qatar','QA','QAT','634','974',1),(177,'Reunion Island','RE','REU','638','262',1),(178,'Romania','RO','ROU','642','040',1),(179,'Rwanda','RW','RWA','646','250',1),(180,'St. Helena','SH','SHN','654','290',1),(181,'St. Kitts','KN','KNA','659','869',1),(182,'St. Lucia','LC','LCA','662','758',1),(183,'St. Pierre & Miquelon','PM','SPM','666','508',1),(184,'St. Vincent','VC','VCT','670','784',1),(185,'San Marino','SM','SMR','674','378',1),(186,'Sao Tome & Principe','ST','STP','678','239',1),(187,'Saudi Arabia','SA','SAU','682','966',1),(188,'Senegal','SN','SEN','686','221',1),(189,'Serbia','RS','SRB','688','381',1),(190,'Seychelles','SC','SYC','690','248',1),(191,'Sierra Leone','SL','SLE','694','249',1),(192,'Slovakia','SK','SVK','703','421',1),(193,'Slovenia','SI','SVN','705','386',1),(194,'Solomon Islands','SB','SLB','90','677',1),(195,'Somalia','SO','SOM','706','252',1),(196,'South Africa','ZA','ZAF','710','027',1),(197,'Sri Lanka','LK','LKA','144','094',1),(198,'Sudan','SD','SDN','736','095',1),(199,'Suriname','SR','SUR','740','597',1),(200,'Swaziland','SZ','SWZ','748','268',1),(201,'Sweden','SE','SWE','752','046',1),(202,'Switzerland','CH','CHE','756','041',1),(203,'Syria','SY','SYR','760','963',1),(204,'Taiwan','TW','TWN','158','886',1),(205,'Tajikistan','TJ','TJK','762','992',1),(206,'Tanzania','TZ','TZA','834','255',1),(207,'Thailand','TH','THA','764','066',1),(208,'Togo','TG','TGO','768','228',1),(209,'Tonga','TO','TON','776','676',1),(210,'Trinidad & Tobago','TT','TTO','780','868',1),(211,'Tunisia','TN','TUN','788','216',1),(212,'Turkmenistan','TM','TKM','795','993',1),(213,'Turks & Caicos','TC','TCA','796','649',1),(214,'Tuvalu','TV','TUV','798','688',1),(215,'Uganda','UG','UGA','800','256',1),(216,'Ukraine','UA','UKR','804','380',1),(217,'United Arab Emirates','AE','ARE','784','971',1),(218,'Uruguay','UY','URY','858','598',1),(219,'Uzbekistan','UZ','UZB','860','998',1),(220,'Vanuatu','VU','VUT','548','678',1),(221,'Vatican City','VA','VAT','336','039',1),(222,'Venezuela','VE','VEN','862','058',1),(223,'Wallis & Futuna','WF','WLF','876','681',1),(224,'Western Samoa','EH','ESH','732','685',1),(225,'Yemen','YE','YEM','887','967',1),(226,'Zambia','ZM','ZMB','894','260',1),(227,'Zimbabwe','ZW','ZWE','716','263',1);
/*!40000 ALTER TABLE `Country` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CyrusUser`
--

DROP TABLE IF EXISTS `CyrusUser`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `CyrusUser` (
  `userId` varchar(75) NOT NULL,
  `password_` varchar(75) NOT NULL,
  PRIMARY KEY (`userId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CyrusUser`
--

LOCK TABLES `CyrusUser` WRITE;
/*!40000 ALTER TABLE `CyrusUser` DISABLE KEYS */;
/*!40000 ALTER TABLE `CyrusUser` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CyrusVirtual`
--

DROP TABLE IF EXISTS `CyrusVirtual`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `CyrusVirtual` (
  `emailAddress` varchar(75) NOT NULL,
  `userId` varchar(75) NOT NULL,
  PRIMARY KEY (`emailAddress`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CyrusVirtual`
--

LOCK TABLES `CyrusVirtual` WRITE;
/*!40000 ALTER TABLE `CyrusVirtual` DISABLE KEYS */;
/*!40000 ALTER TABLE `CyrusVirtual` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `DLFileEntry`
--

DROP TABLE IF EXISTS `DLFileEntry`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `DLFileEntry` (
  `uuid_` varchar(75) DEFAULT NULL,
  `fileEntryId` bigint(20) NOT NULL,
  `groupId` bigint(20) DEFAULT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `userId` bigint(20) DEFAULT NULL,
  `userName` varchar(75) DEFAULT NULL,
  `versionUserId` bigint(20) DEFAULT NULL,
  `versionUserName` varchar(75) DEFAULT NULL,
  `createDate` datetime DEFAULT NULL,
  `modifiedDate` datetime DEFAULT NULL,
  `folderId` bigint(20) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `extension` varchar(75) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `description` longtext,
  `extraSettings` longtext,
  `version` varchar(75) DEFAULT NULL,
  `size_` bigint(20) DEFAULT NULL,
  `readCount` int(11) DEFAULT NULL,
  PRIMARY KEY (`fileEntryId`),
  UNIQUE KEY `IX_5391712` (`groupId`,`folderId`,`name`),
  UNIQUE KEY `IX_ED5CA615` (`groupId`,`folderId`,`title`),
  UNIQUE KEY `IX_BC2E7E6A` (`uuid_`,`groupId`),
  KEY `IX_4CB1B2B4` (`companyId`),
  KEY `IX_F4AF5636` (`groupId`),
  KEY `IX_93CF8193` (`groupId`,`folderId`),
  KEY `IX_43261870` (`groupId`,`userId`),
  KEY `IX_D20C434D` (`groupId`,`userId`,`folderId`),
  KEY `IX_64F0FE40` (`uuid_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `DLFileEntry`
--

LOCK TABLES `DLFileEntry` WRITE;
/*!40000 ALTER TABLE `DLFileEntry` DISABLE KEYS */;
INSERT INTO `DLFileEntry` VALUES ('9a92a349-3c5f-42d2-b0ad-ad5c9b53c5f6',10707,10678,10132,10169,'Test Test',10169,'Test Test','2014-04-03 17:00:43','2014-04-03 17:01:19',10705,'1','txt','DM Document Title Edit','DM Document Description Edit','','1.1',259,0);
/*!40000 ALTER TABLE `DLFileEntry` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `DLFileRank`
--

DROP TABLE IF EXISTS `DLFileRank`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `DLFileRank` (
  `fileRankId` bigint(20) NOT NULL,
  `groupId` bigint(20) DEFAULT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `userId` bigint(20) DEFAULT NULL,
  `createDate` datetime DEFAULT NULL,
  `fileEntryId` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`fileRankId`),
  UNIQUE KEY `IX_38F0315` (`companyId`,`userId`,`fileEntryId`),
  KEY `IX_A65A1F8B` (`fileEntryId`),
  KEY `IX_BAFB116E` (`groupId`,`userId`),
  KEY `IX_EED06670` (`userId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `DLFileRank`
--

LOCK TABLES `DLFileRank` WRITE;
/*!40000 ALTER TABLE `DLFileRank` DISABLE KEYS */;
/*!40000 ALTER TABLE `DLFileRank` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `DLFileShortcut`
--

DROP TABLE IF EXISTS `DLFileShortcut`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `DLFileShortcut` (
  `uuid_` varchar(75) DEFAULT NULL,
  `fileShortcutId` bigint(20) NOT NULL,
  `groupId` bigint(20) DEFAULT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `userId` bigint(20) DEFAULT NULL,
  `userName` varchar(75) DEFAULT NULL,
  `createDate` datetime DEFAULT NULL,
  `modifiedDate` datetime DEFAULT NULL,
  `folderId` bigint(20) DEFAULT NULL,
  `toFileEntryId` bigint(20) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `statusByUserId` bigint(20) DEFAULT NULL,
  `statusByUserName` varchar(75) DEFAULT NULL,
  `statusDate` datetime DEFAULT NULL,
  PRIMARY KEY (`fileShortcutId`),
  UNIQUE KEY `IX_FDB4A946` (`uuid_`,`groupId`),
  KEY `IX_B0051937` (`groupId`,`folderId`),
  KEY `IX_ECCE311D` (`groupId`,`folderId`,`status`),
  KEY `IX_4B7247F6` (`toFileEntryId`),
  KEY `IX_4831EBE4` (`uuid_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `DLFileShortcut`
--

LOCK TABLES `DLFileShortcut` WRITE;
/*!40000 ALTER TABLE `DLFileShortcut` DISABLE KEYS */;
INSERT INTO `DLFileShortcut` VALUES ('de8b238e-b930-465e-a393-6c7a7ac052a3',10698,10678,10132,10169,'Test Test','2014-04-03 17:01:09','2014-04-03 17:01:09',0,10707,0,10169,'Test Test','2014-04-03 17:01:09');
/*!40000 ALTER TABLE `DLFileShortcut` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `DLFileVersion`
--

DROP TABLE IF EXISTS `DLFileVersion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `DLFileVersion` (
  `fileVersionId` bigint(20) NOT NULL,
  `groupId` bigint(20) DEFAULT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `userId` bigint(20) DEFAULT NULL,
  `userName` varchar(75) DEFAULT NULL,
  `createDate` datetime DEFAULT NULL,
  `fileEntryId` bigint(20) DEFAULT NULL,
  `extension` varchar(75) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `description` longtext,
  `changeLog` varchar(75) DEFAULT NULL,
  `extraSettings` longtext,
  `version` varchar(75) DEFAULT NULL,
  `size_` bigint(20) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `statusByUserId` bigint(20) DEFAULT NULL,
  `statusByUserName` varchar(75) DEFAULT NULL,
  `statusDate` datetime DEFAULT NULL,
  PRIMARY KEY (`fileVersionId`),
  UNIQUE KEY `IX_E2815081` (`fileEntryId`,`version`),
  KEY `IX_C68DC967` (`fileEntryId`),
  KEY `IX_D47BB14D` (`fileEntryId`,`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `DLFileVersion`
--

LOCK TABLES `DLFileVersion` WRITE;
/*!40000 ALTER TABLE `DLFileVersion` DISABLE KEYS */;
INSERT INTO `DLFileVersion` VALUES (10708,10678,10132,10169,'Test Test','2014-04-03 17:01:19',10707,'','DM Document Title Edit','DM Document Description Edit','','','1.1',259,0,10169,'Test Test','2014-04-03 17:01:39'),(10709,10678,10132,10169,'Test Test','2014-04-03 17:00:43',10707,'txt','DM Document Title.txt','DM Document Description','','','1.0',259,0,10169,'Test Test','2014-04-03 17:01:39');
/*!40000 ALTER TABLE `DLFileVersion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `DLFolder`
--

DROP TABLE IF EXISTS `DLFolder`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `DLFolder` (
  `uuid_` varchar(75) DEFAULT NULL,
  `folderId` bigint(20) NOT NULL,
  `groupId` bigint(20) DEFAULT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `userId` bigint(20) DEFAULT NULL,
  `userName` varchar(75) DEFAULT NULL,
  `createDate` datetime DEFAULT NULL,
  `modifiedDate` datetime DEFAULT NULL,
  `parentFolderId` bigint(20) DEFAULT NULL,
  `name` varchar(100) DEFAULT NULL,
  `description` longtext,
  `lastPostDate` datetime DEFAULT NULL,
  PRIMARY KEY (`folderId`),
  UNIQUE KEY `IX_902FD874` (`groupId`,`parentFolderId`,`name`),
  UNIQUE KEY `IX_3CC1DED2` (`uuid_`,`groupId`),
  KEY `IX_A74DB14C` (`companyId`),
  KEY `IX_F2EA1ACE` (`groupId`),
  KEY `IX_49C37475` (`groupId`,`parentFolderId`),
  KEY `IX_51556082` (`parentFolderId`,`name`),
  KEY `IX_CBC408D8` (`uuid_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `DLFolder`
--

LOCK TABLES `DLFolder` WRITE;
/*!40000 ALTER TABLE `DLFolder` DISABLE KEYS */;
INSERT INTO `DLFolder` VALUES ('51ed7cce-6f32-4266-b391-f0bcac691b10',10705,10678,10132,10169,'','2014-04-03 17:01:23','2014-04-03 17:01:23',0,'DM Folder Name','DM Folder Description',NULL);
/*!40000 ALTER TABLE `DLFolder` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `EmailAddress`
--

DROP TABLE IF EXISTS `EmailAddress`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `EmailAddress` (
  `emailAddressId` bigint(20) NOT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `userId` bigint(20) DEFAULT NULL,
  `userName` varchar(75) DEFAULT NULL,
  `createDate` datetime DEFAULT NULL,
  `modifiedDate` datetime DEFAULT NULL,
  `classNameId` bigint(20) DEFAULT NULL,
  `classPK` bigint(20) DEFAULT NULL,
  `address` varchar(75) DEFAULT NULL,
  `typeId` int(11) DEFAULT NULL,
  `primary_` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`emailAddressId`),
  KEY `IX_1BB072CA` (`companyId`),
  KEY `IX_49D2DEC4` (`companyId`,`classNameId`),
  KEY `IX_551A519F` (`companyId`,`classNameId`,`classPK`),
  KEY `IX_2A2CB130` (`companyId`,`classNameId`,`classPK`,`primary_`),
  KEY `IX_7B43CD8` (`userId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `EmailAddress`
--

LOCK TABLES `EmailAddress` WRITE;
/*!40000 ALTER TABLE `EmailAddress` DISABLE KEYS */;
INSERT INTO `EmailAddress` VALUES (10770,10132,10169,'Test Test','2014-04-03 17:07:12','2014-04-03 17:07:24',10009,10170,'liferayportal01@liferay.com',11003,1);
/*!40000 ALTER TABLE `EmailAddress` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ExpandoColumn`
--

DROP TABLE IF EXISTS `ExpandoColumn`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ExpandoColumn` (
  `columnId` bigint(20) NOT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `tableId` bigint(20) DEFAULT NULL,
  `name` varchar(75) DEFAULT NULL,
  `type_` int(11) DEFAULT NULL,
  `defaultData` longtext,
  `typeSettings` longtext,
  PRIMARY KEY (`columnId`),
  UNIQUE KEY `IX_FEFC8DA7` (`tableId`,`name`),
  KEY `IX_A8C0CBE8` (`tableId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ExpandoColumn`
--

LOCK TABLES `ExpandoColumn` WRITE;
/*!40000 ALTER TABLE `ExpandoColumn` DISABLE KEYS */;
INSERT INTO `ExpandoColumn` VALUES (10307,10132,10306,'aboutMe',15,'',''),(10742,10132,10741,'boolean',1,'','');
/*!40000 ALTER TABLE `ExpandoColumn` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ExpandoRow`
--

DROP TABLE IF EXISTS `ExpandoRow`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ExpandoRow` (
  `rowId_` bigint(20) NOT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `tableId` bigint(20) DEFAULT NULL,
  `classPK` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`rowId_`),
  UNIQUE KEY `IX_81EFBFF5` (`tableId`,`classPK`),
  KEY `IX_D3F5D7AE` (`tableId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ExpandoRow`
--

LOCK TABLES `ExpandoRow` WRITE;
/*!40000 ALTER TABLE `ExpandoRow` DISABLE KEYS */;
INSERT INTO `ExpandoRow` VALUES (10767,10132,10741,10169);
/*!40000 ALTER TABLE `ExpandoRow` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ExpandoTable`
--

DROP TABLE IF EXISTS `ExpandoTable`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ExpandoTable` (
  `tableId` bigint(20) NOT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `classNameId` bigint(20) DEFAULT NULL,
  `name` varchar(75) DEFAULT NULL,
  PRIMARY KEY (`tableId`),
  UNIQUE KEY `IX_37562284` (`companyId`,`classNameId`,`name`),
  KEY `IX_B5AE8A85` (`companyId`,`classNameId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ExpandoTable`
--

LOCK TABLES `ExpandoTable` WRITE;
/*!40000 ALTER TABLE `ExpandoTable` DISABLE KEYS */;
INSERT INTO `ExpandoTable` VALUES (10741,10132,10046,'CUSTOM_FIELDS'),(10306,10132,10046,'SN');
/*!40000 ALTER TABLE `ExpandoTable` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ExpandoValue`
--

DROP TABLE IF EXISTS `ExpandoValue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ExpandoValue` (
  `valueId` bigint(20) NOT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `tableId` bigint(20) DEFAULT NULL,
  `columnId` bigint(20) DEFAULT NULL,
  `rowId_` bigint(20) DEFAULT NULL,
  `classNameId` bigint(20) DEFAULT NULL,
  `classPK` bigint(20) DEFAULT NULL,
  `data_` longtext,
  PRIMARY KEY (`valueId`),
  UNIQUE KEY `IX_9DDD21E5` (`columnId`,`rowId_`),
  UNIQUE KEY `IX_D27B03E7` (`tableId`,`columnId`,`classPK`),
  KEY `IX_B29FEF17` (`classNameId`,`classPK`),
  KEY `IX_F7DD0987` (`columnId`),
  KEY `IX_9112A7A0` (`rowId_`),
  KEY `IX_F0566A77` (`tableId`),
  KEY `IX_1BD3F4C` (`tableId`,`classPK`),
  KEY `IX_CA9AFB7C` (`tableId`,`columnId`),
  KEY `IX_B71E92D5` (`tableId`,`rowId_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ExpandoValue`
--

LOCK TABLES `ExpandoValue` WRITE;
/*!40000 ALTER TABLE `ExpandoValue` DISABLE KEYS */;
INSERT INTO `ExpandoValue` VALUES (10768,10132,10741,10742,10767,10046,10169,'false');
/*!40000 ALTER TABLE `ExpandoValue` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Group_`
--

DROP TABLE IF EXISTS `Group_`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Group_` (
  `groupId` bigint(20) NOT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `creatorUserId` bigint(20) DEFAULT NULL,
  `classNameId` bigint(20) DEFAULT NULL,
  `classPK` bigint(20) DEFAULT NULL,
  `parentGroupId` bigint(20) DEFAULT NULL,
  `liveGroupId` bigint(20) DEFAULT NULL,
  `name` varchar(75) DEFAULT NULL,
  `description` longtext,
  `type_` int(11) DEFAULT NULL,
  `typeSettings` longtext,
  `friendlyURL` varchar(100) DEFAULT NULL,
  `active_` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`groupId`),
  UNIQUE KEY `IX_D0D5E397` (`companyId`,`classNameId`,`classPK`),
  UNIQUE KEY `IX_5DE0BE11` (`companyId`,`classNameId`,`liveGroupId`,`name`),
  UNIQUE KEY `IX_5BDDB872` (`companyId`,`friendlyURL`),
  UNIQUE KEY `IX_BBCA55B` (`companyId`,`liveGroupId`,`name`),
  UNIQUE KEY `IX_5AA68501` (`companyId`,`name`),
  KEY `IX_ABA5CEC2` (`companyId`),
  KEY `IX_16218A38` (`liveGroupId`),
  KEY `IX_7B590A7A` (`type_`,`active_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Group_`
--

LOCK TABLES `Group_` WRITE;
/*!40000 ALTER TABLE `Group_` DISABLE KEYS */;
INSERT INTO `Group_` VALUES (10149,10132,10135,10012,10149,0,0,'Control Panel','',3,'','/control_panel',1),(10157,10132,10135,10012,10157,0,0,'Guest','',1,'','/guest',1),(10165,10132,10135,10008,10132,0,0,'10132','',0,'','/null',1),(10171,10132,10169,10046,10169,0,0,'10169','',0,'','/test',1),(10357,10132,10169,10012,10357,0,0,'Member Site','',1,'','/member-site',1),(10367,10132,10365,10046,10365,0,0,'10365','',0,'','/usersn',1),(10376,10132,10169,10024,10375,0,0,'10375','',0,'','/organization-name',1),(10385,10132,10169,10047,10384,0,0,'10384','',0,'','/10384',1),(10388,10132,10169,10012,10388,0,0,'Wiki Site','',1,'','/wiki-site',1),(10435,10132,10169,10012,10435,0,0,'WebContent Site','',1,'','/webcontent-site',1),(10481,10132,10169,10012,10481,0,0,'Social Equity Site','',1,'','/social-equity-site',1),(10523,10132,10169,10015,10522,0,0,'10522','',0,'','/template-10522',1),(10533,10132,10169,10017,10532,0,0,'10532','',0,'','/template-10532',1),(10545,10132,10543,10046,10543,0,0,'10543','',0,'','/userpp',1),(10585,10132,10169,10012,10585,0,0,'Site Name','',2,'','/site-name',1),(10591,10132,10589,10046,10589,0,0,'10589','',0,'','/usersmsn',1),(10617,10132,10169,10012,10617,0,0,'Staging Site','',1,'staged-portlet_8=true\nworkflowEnabled=false\nstaged-portlet_108=true\nstagedRemotely=false\nstaged-portlet_107=true\nstaged-portlet_56=true\nstaged-portlet_15=true\nstaged-portlet_28=true\nstaged-portlet_39=true\nstaged-portlet_54=true\nstaged-portlet_19=true\nstaged-portlet_110=true\nstaged-portlet_36=true\nstaged-portlet_33=true\nstaged-portlet_20=true\nstaged-portlet_31=true\nstaged-portlet_59=true\nstaged-portlet_25=true\nstaged=true\n','/staging-site',1),(10626,10132,10169,10012,10626,0,10617,'Staging Site (Staging)','',1,'','/staging-site-staging',1),(10663,10132,10169,10012,10663,0,0,'AP Site','',1,'','/ap-site',1),(10678,10132,10169,10012,10678,0,0,'Document Library Site','',1,'','/document-library-site',1),(10745,10132,10743,10046,10743,0,0,'10743','',0,'','/usercf',1),(10752,10132,10169,10012,10752,0,0,'Blogs Site','',1,'','/blogs-site',1);
/*!40000 ALTER TABLE `Group_` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Groups_Orgs`
--

DROP TABLE IF EXISTS `Groups_Orgs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Groups_Orgs` (
  `groupId` bigint(20) NOT NULL,
  `organizationId` bigint(20) NOT NULL,
  PRIMARY KEY (`groupId`,`organizationId`),
  KEY `IX_75267DCA` (`groupId`),
  KEY `IX_6BBB7682` (`organizationId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Groups_Orgs`
--

LOCK TABLES `Groups_Orgs` WRITE;
/*!40000 ALTER TABLE `Groups_Orgs` DISABLE KEYS */;
INSERT INTO `Groups_Orgs` VALUES (10357,10375);
/*!40000 ALTER TABLE `Groups_Orgs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Groups_Permissions`
--

DROP TABLE IF EXISTS `Groups_Permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Groups_Permissions` (
  `groupId` bigint(20) NOT NULL,
  `permissionId` bigint(20) NOT NULL,
  PRIMARY KEY (`groupId`,`permissionId`),
  KEY `IX_C48736B` (`groupId`),
  KEY `IX_EC97689D` (`permissionId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Groups_Permissions`
--

LOCK TABLES `Groups_Permissions` WRITE;
/*!40000 ALTER TABLE `Groups_Permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `Groups_Permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Groups_Roles`
--

DROP TABLE IF EXISTS `Groups_Roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Groups_Roles` (
  `groupId` bigint(20) NOT NULL,
  `roleId` bigint(20) NOT NULL,
  PRIMARY KEY (`groupId`,`roleId`),
  KEY `IX_84471FD2` (`groupId`),
  KEY `IX_3103EF3D` (`roleId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Groups_Roles`
--

LOCK TABLES `Groups_Roles` WRITE;
/*!40000 ALTER TABLE `Groups_Roles` DISABLE KEYS */;
INSERT INTO `Groups_Roles` VALUES (10357,10362);
/*!40000 ALTER TABLE `Groups_Roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Groups_UserGroups`
--

DROP TABLE IF EXISTS `Groups_UserGroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Groups_UserGroups` (
  `groupId` bigint(20) NOT NULL,
  `userGroupId` bigint(20) NOT NULL,
  PRIMARY KEY (`groupId`,`userGroupId`),
  KEY `IX_31FB749A` (`groupId`),
  KEY `IX_3B69160F` (`userGroupId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Groups_UserGroups`
--

LOCK TABLES `Groups_UserGroups` WRITE;
/*!40000 ALTER TABLE `Groups_UserGroups` DISABLE KEYS */;
INSERT INTO `Groups_UserGroups` VALUES (10357,10384);
/*!40000 ALTER TABLE `Groups_UserGroups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `IGFolder`
--

DROP TABLE IF EXISTS `IGFolder`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `IGFolder` (
  `uuid_` varchar(75) DEFAULT NULL,
  `folderId` bigint(20) NOT NULL,
  `groupId` bigint(20) DEFAULT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `userId` bigint(20) DEFAULT NULL,
  `createDate` datetime DEFAULT NULL,
  `modifiedDate` datetime DEFAULT NULL,
  `parentFolderId` bigint(20) DEFAULT NULL,
  `name` varchar(75) DEFAULT NULL,
  `description` longtext,
  PRIMARY KEY (`folderId`),
  UNIQUE KEY `IX_9BBAFB1E` (`groupId`,`parentFolderId`,`name`),
  UNIQUE KEY `IX_B10EFD68` (`uuid_`,`groupId`),
  KEY `IX_60214CF6` (`companyId`),
  KEY `IX_206498F8` (`groupId`),
  KEY `IX_1A605E9F` (`groupId`,`parentFolderId`),
  KEY `IX_F73C0982` (`uuid_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `IGFolder`
--

LOCK TABLES `IGFolder` WRITE;
/*!40000 ALTER TABLE `IGFolder` DISABLE KEYS */;
/*!40000 ALTER TABLE `IGFolder` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `IGImage`
--

DROP TABLE IF EXISTS `IGImage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `IGImage` (
  `uuid_` varchar(75) DEFAULT NULL,
  `imageId` bigint(20) NOT NULL,
  `groupId` bigint(20) DEFAULT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `userId` bigint(20) DEFAULT NULL,
  `createDate` datetime DEFAULT NULL,
  `modifiedDate` datetime DEFAULT NULL,
  `folderId` bigint(20) DEFAULT NULL,
  `name` varchar(75) DEFAULT NULL,
  `description` longtext,
  `smallImageId` bigint(20) DEFAULT NULL,
  `largeImageId` bigint(20) DEFAULT NULL,
  `custom1ImageId` bigint(20) DEFAULT NULL,
  `custom2ImageId` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`imageId`),
  UNIQUE KEY `IX_E97342D9` (`uuid_`,`groupId`),
  KEY `IX_E597322D` (`custom1ImageId`),
  KEY `IX_D9E0A34C` (`custom2ImageId`),
  KEY `IX_63820A7` (`groupId`),
  KEY `IX_8956B2C4` (`groupId`,`folderId`),
  KEY `IX_AAE8DF83` (`groupId`,`folderId`,`name`),
  KEY `IX_BE79E1E1` (`groupId`,`userId`),
  KEY `IX_64F0B572` (`largeImageId`),
  KEY `IX_D3D32126` (`smallImageId`),
  KEY `IX_265BB0F1` (`uuid_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `IGImage`
--

LOCK TABLES `IGImage` WRITE;
/*!40000 ALTER TABLE `IGImage` DISABLE KEYS */;
/*!40000 ALTER TABLE `IGImage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Image`
--

DROP TABLE IF EXISTS `Image`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Image` (
  `imageId` bigint(20) NOT NULL,
  `modifiedDate` datetime DEFAULT NULL,
  `text_` longtext,
  `type_` varchar(75) DEFAULT NULL,
  `height` int(11) DEFAULT NULL,
  `width` int(11) DEFAULT NULL,
  `size_` int(11) DEFAULT NULL,
  PRIMARY KEY (`imageId`),
  KEY `IX_6A925A4D` (`size_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Image`
--

LOCK TABLES `Image` WRITE;
/*!40000 ALTER TABLE `Image` DISABLE KEYS */;
INSERT INTO `Image` VALUES (10346,'2014-04-03 16:39:31','','png',108,80,5176),(10347,'2014-04-03 16:39:31','','png',160,160,5695),(10460,'2014-04-03 16:48:49','','png',160,160,5695),(10479,'2014-04-03 16:49:24','','png',160,160,5695);
/*!40000 ALTER TABLE `Image` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `JournalArticle`
--

DROP TABLE IF EXISTS `JournalArticle`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `JournalArticle` (
  `uuid_` varchar(75) DEFAULT NULL,
  `id_` bigint(20) NOT NULL,
  `resourcePrimKey` bigint(20) DEFAULT NULL,
  `groupId` bigint(20) DEFAULT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `userId` bigint(20) DEFAULT NULL,
  `userName` varchar(75) DEFAULT NULL,
  `createDate` datetime DEFAULT NULL,
  `modifiedDate` datetime DEFAULT NULL,
  `articleId` varchar(75) DEFAULT NULL,
  `version` double DEFAULT NULL,
  `title` varchar(300) DEFAULT NULL,
  `urlTitle` varchar(150) DEFAULT NULL,
  `description` longtext,
  `content` longtext,
  `type_` varchar(75) DEFAULT NULL,
  `structureId` varchar(75) DEFAULT NULL,
  `templateId` varchar(75) DEFAULT NULL,
  `displayDate` datetime DEFAULT NULL,
  `expirationDate` datetime DEFAULT NULL,
  `reviewDate` datetime DEFAULT NULL,
  `indexable` tinyint(4) DEFAULT NULL,
  `smallImage` tinyint(4) DEFAULT NULL,
  `smallImageId` bigint(20) DEFAULT NULL,
  `smallImageURL` longtext,
  `status` int(11) DEFAULT NULL,
  `statusByUserId` bigint(20) DEFAULT NULL,
  `statusByUserName` varchar(75) DEFAULT NULL,
  `statusDate` datetime DEFAULT NULL,
  PRIMARY KEY (`id_`),
  UNIQUE KEY `IX_85C52EEC` (`groupId`,`articleId`,`version`),
  UNIQUE KEY `IX_3463D95B` (`uuid_`,`groupId`),
  KEY `IX_DFF98523` (`companyId`),
  KEY `IX_323DF109` (`companyId`,`status`),
  KEY `IX_9356F865` (`groupId`),
  KEY `IX_68C0F69C` (`groupId`,`articleId`),
  KEY `IX_4D5CD982` (`groupId`,`articleId`,`status`),
  KEY `IX_301D024B` (`groupId`,`status`),
  KEY `IX_2E207659` (`groupId`,`structureId`),
  KEY `IX_8DEAE14E` (`groupId`,`templateId`),
  KEY `IX_22882D02` (`groupId`,`urlTitle`),
  KEY `IX_D2D249E8` (`groupId`,`urlTitle`,`status`),
  KEY `IX_33F49D16` (`resourcePrimKey`),
  KEY `IX_3E2765FC` (`resourcePrimKey`,`status`),
  KEY `IX_EF9B7028` (`smallImageId`),
  KEY `IX_F029602F` (`uuid_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `JournalArticle`
--

LOCK TABLES `JournalArticle` WRITE;
/*!40000 ALTER TABLE `JournalArticle` DISABLE KEYS */;
INSERT INTO `JournalArticle` VALUES ('f337b4bb-2085-4569-8191-4e980bb71f36',10458,10459,10435,10132,10169,'Test Test','2014-04-03 16:48:49','2014-04-03 16:48:49','10457',1,'WC WebContent Title','wc-webcontent-title','','<?xml version=\"1.0\"?>\n\n<root>\n	<dynamic-element instance-id=\"9SyQcOPq\" name=\"Subject\" type=\"text\" index-type=\"\">\n		<dynamic-content><![CDATA[Subject]]></dynamic-content>\n	</dynamic-element>\n	<dynamic-element instance-id=\"CPsDB9Oy\" name=\"picture\" type=\"image\" index-type=\"\">\n		<dynamic-content id=\"10460\">/image/journal/article?img_id=10460&amp;t=1396543729404</dynamic-content>\n	</dynamic-element>\n	<dynamic-element instance-id=\"4ba0u6H8\" name=\"Content\" type=\"text_box\" index-type=\"\">\n		<dynamic-element instance-id=\"tN8gpQpc\" name=\"caption\" type=\"text\" index-type=\"\">\n			<dynamic-content><![CDATA[caption]]></dynamic-content>\n		</dynamic-element>\n		<dynamic-content><![CDATA[WC Content]]></dynamic-content>\n	</dynamic-element>\n</root>','general','10452','10454','2014-04-03 16:48:00',NULL,NULL,1,0,10461,'',0,10169,'Test Test','2014-04-03 16:48:49'),('e2445253-da9b-4dd7-911f-dfe7b6c83af3',10478,10459,10435,10132,10169,'Test Test','2014-04-03 16:49:24','2014-04-03 16:49:24','10457',1.1,'WC WebContent Title','wc-webcontent-title','','<?xml version=\"1.0\"?>\n\n<root>\n	<dynamic-element instance-id=\"9SyQcOPq\" name=\"Subject\" type=\"text\" index-type=\"\">\n		<dynamic-content><![CDATA[Subject]]></dynamic-content>\n	</dynamic-element>\n	<dynamic-element instance-id=\"CPsDB9Oy\" name=\"picture\" type=\"image\" index-type=\"\">\n		<dynamic-content id=\"10479\">/image/journal/article?img_id=10479&amp;t=1396543764294</dynamic-content>\n	</dynamic-element>\n	<dynamic-element instance-id=\"4ba0u6H8\" name=\"Content\" type=\"text_box\" index-type=\"\">\n		<dynamic-element instance-id=\"tN8gpQpc\" name=\"caption\" type=\"text\" index-type=\"\">\n			<dynamic-content><![CDATA[caption]]></dynamic-content>\n		</dynamic-element>\n		<dynamic-content><![CDATA[WC Content]]></dynamic-content>\n	</dynamic-element>\n</root>','general','10452','10454','2014-04-03 16:48:00',NULL,NULL,1,0,10461,'',0,10169,'Test Test','2014-04-03 16:49:24');
/*!40000 ALTER TABLE `JournalArticle` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `JournalArticleImage`
--

DROP TABLE IF EXISTS `JournalArticleImage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `JournalArticleImage` (
  `articleImageId` bigint(20) NOT NULL,
  `groupId` bigint(20) DEFAULT NULL,
  `articleId` varchar(75) DEFAULT NULL,
  `version` double DEFAULT NULL,
  `elInstanceId` varchar(75) DEFAULT NULL,
  `elName` varchar(75) DEFAULT NULL,
  `languageId` varchar(75) DEFAULT NULL,
  `tempImage` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`articleImageId`),
  UNIQUE KEY `IX_103D6207` (`groupId`,`articleId`,`version`,`elInstanceId`,`elName`,`languageId`),
  KEY `IX_3B51BB68` (`groupId`),
  KEY `IX_158B526F` (`groupId`,`articleId`,`version`),
  KEY `IX_D4121315` (`tempImage`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `JournalArticleImage`
--

LOCK TABLES `JournalArticleImage` WRITE;
/*!40000 ALTER TABLE `JournalArticleImage` DISABLE KEYS */;
INSERT INTO `JournalArticleImage` VALUES (10460,10435,'10457',1,'CPsDB9Oy','picture','',0),(10479,10435,'10457',1.1,'CPsDB9Oy','picture','',0);
/*!40000 ALTER TABLE `JournalArticleImage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `JournalArticleResource`
--

DROP TABLE IF EXISTS `JournalArticleResource`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `JournalArticleResource` (
  `uuid_` varchar(75) DEFAULT NULL,
  `resourcePrimKey` bigint(20) NOT NULL,
  `groupId` bigint(20) DEFAULT NULL,
  `articleId` varchar(75) DEFAULT NULL,
  PRIMARY KEY (`resourcePrimKey`),
  UNIQUE KEY `IX_88DF994A` (`groupId`,`articleId`),
  UNIQUE KEY `IX_84AB0309` (`uuid_`,`groupId`),
  KEY `IX_F8433677` (`groupId`),
  KEY `IX_DCD1FAC1` (`uuid_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `JournalArticleResource`
--

LOCK TABLES `JournalArticleResource` WRITE;
/*!40000 ALTER TABLE `JournalArticleResource` DISABLE KEYS */;
INSERT INTO `JournalArticleResource` VALUES ('28eb7885-cde2-4608-b265-df1d08809da6',10459,10435,'10457');
/*!40000 ALTER TABLE `JournalArticleResource` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `JournalContentSearch`
--

DROP TABLE IF EXISTS `JournalContentSearch`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `JournalContentSearch` (
  `contentSearchId` bigint(20) NOT NULL,
  `groupId` bigint(20) DEFAULT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `privateLayout` tinyint(4) DEFAULT NULL,
  `layoutId` bigint(20) DEFAULT NULL,
  `portletId` varchar(200) DEFAULT NULL,
  `articleId` varchar(75) DEFAULT NULL,
  PRIMARY KEY (`contentSearchId`),
  UNIQUE KEY `IX_C3AA93B8` (`groupId`,`privateLayout`,`layoutId`,`portletId`,`articleId`),
  KEY `IX_9207CB31` (`articleId`),
  KEY `IX_6838E427` (`groupId`,`articleId`),
  KEY `IX_20962903` (`groupId`,`privateLayout`),
  KEY `IX_7CC7D73E` (`groupId`,`privateLayout`,`articleId`),
  KEY `IX_B3B318DC` (`groupId`,`privateLayout`,`layoutId`),
  KEY `IX_7ACC74C9` (`groupId`,`privateLayout`,`layoutId`,`portletId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `JournalContentSearch`
--

LOCK TABLES `JournalContentSearch` WRITE;
/*!40000 ALTER TABLE `JournalContentSearch` DISABLE KEYS */;
INSERT INTO `JournalContentSearch` VALUES (10473,10435,10132,0,1,'56_INSTANCE_hUa2','10457');
/*!40000 ALTER TABLE `JournalContentSearch` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `JournalFeed`
--

DROP TABLE IF EXISTS `JournalFeed`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `JournalFeed` (
  `uuid_` varchar(75) DEFAULT NULL,
  `id_` bigint(20) NOT NULL,
  `groupId` bigint(20) DEFAULT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `userId` bigint(20) DEFAULT NULL,
  `userName` varchar(75) DEFAULT NULL,
  `createDate` datetime DEFAULT NULL,
  `modifiedDate` datetime DEFAULT NULL,
  `feedId` varchar(75) DEFAULT NULL,
  `name` varchar(75) DEFAULT NULL,
  `description` longtext,
  `type_` varchar(75) DEFAULT NULL,
  `structureId` varchar(75) DEFAULT NULL,
  `templateId` varchar(75) DEFAULT NULL,
  `rendererTemplateId` varchar(75) DEFAULT NULL,
  `delta` int(11) DEFAULT NULL,
  `orderByCol` varchar(75) DEFAULT NULL,
  `orderByType` varchar(75) DEFAULT NULL,
  `targetLayoutFriendlyUrl` varchar(255) DEFAULT NULL,
  `targetPortletId` varchar(75) DEFAULT NULL,
  `contentField` varchar(75) DEFAULT NULL,
  `feedType` varchar(75) DEFAULT NULL,
  `feedVersion` double DEFAULT NULL,
  PRIMARY KEY (`id_`),
  UNIQUE KEY `IX_65576CBC` (`groupId`,`feedId`),
  UNIQUE KEY `IX_39031F51` (`uuid_`,`groupId`),
  KEY `IX_35A2DB2F` (`groupId`),
  KEY `IX_50C36D79` (`uuid_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `JournalFeed`
--

LOCK TABLES `JournalFeed` WRITE;
/*!40000 ALTER TABLE `JournalFeed` DISABLE KEYS */;
INSERT INTO `JournalFeed` VALUES ('72f5199c-dcaf-4f17-998b-0f56d0172149',10447,10435,10132,10169,'Test Test','2014-04-03 16:47:50','2014-04-03 16:47:50','10446','Feed Name','Feed Description','','','','',10,'modified-date','asc','/web/guest/home','','rendered-web-content','atom',1);
/*!40000 ALTER TABLE `JournalFeed` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `JournalStructure`
--

DROP TABLE IF EXISTS `JournalStructure`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `JournalStructure` (
  `uuid_` varchar(75) DEFAULT NULL,
  `id_` bigint(20) NOT NULL,
  `groupId` bigint(20) DEFAULT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `userId` bigint(20) DEFAULT NULL,
  `userName` varchar(75) DEFAULT NULL,
  `createDate` datetime DEFAULT NULL,
  `modifiedDate` datetime DEFAULT NULL,
  `structureId` varchar(75) DEFAULT NULL,
  `parentStructureId` varchar(75) DEFAULT NULL,
  `name` varchar(75) DEFAULT NULL,
  `description` longtext,
  `xsd` longtext,
  PRIMARY KEY (`id_`),
  UNIQUE KEY `IX_AB6E9996` (`groupId`,`structureId`),
  UNIQUE KEY `IX_42E86E58` (`uuid_`,`groupId`),
  KEY `IX_B97F5608` (`groupId`),
  KEY `IX_CA0BD48C` (`groupId`,`parentStructureId`),
  KEY `IX_8831E4FC` (`structureId`),
  KEY `IX_6702CA92` (`uuid_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `JournalStructure`
--

LOCK TABLES `JournalStructure` WRITE;
/*!40000 ALTER TABLE `JournalStructure` DISABLE KEYS */;
INSERT INTO `JournalStructure` VALUES ('e00d67ef-b3ff-4665-af81-ad7015ac916d',10453,10435,10132,10169,'Test Test','2014-04-03 16:48:10','2014-04-03 16:48:10','10452','','WC Structure Name','WC Structure Description','<?xml version=\"1.0\"?>\n\n<root>\n	<dynamic-element name=\"Subject\" type=\"text\" index-type=\"\" repeatable=\"false\"/>\n	<dynamic-element name=\"picture\" type=\"image\" index-type=\"\" repeatable=\"false\"/>\n	<dynamic-element name=\"Content\" type=\"text_box\" index-type=\"\" repeatable=\"false\">\n		<dynamic-element name=\"caption\" type=\"text\" index-type=\"\" repeatable=\"false\"/>\n	</dynamic-element>\n</root>');
/*!40000 ALTER TABLE `JournalStructure` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `JournalTemplate`
--

DROP TABLE IF EXISTS `JournalTemplate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `JournalTemplate` (
  `uuid_` varchar(75) DEFAULT NULL,
  `id_` bigint(20) NOT NULL,
  `groupId` bigint(20) DEFAULT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `userId` bigint(20) DEFAULT NULL,
  `userName` varchar(75) DEFAULT NULL,
  `createDate` datetime DEFAULT NULL,
  `modifiedDate` datetime DEFAULT NULL,
  `templateId` varchar(75) DEFAULT NULL,
  `structureId` varchar(75) DEFAULT NULL,
  `name` varchar(75) DEFAULT NULL,
  `description` longtext,
  `xsl` longtext,
  `langType` varchar(75) DEFAULT NULL,
  `cacheable` tinyint(4) DEFAULT NULL,
  `smallImage` tinyint(4) DEFAULT NULL,
  `smallImageId` bigint(20) DEFAULT NULL,
  `smallImageURL` longtext,
  PRIMARY KEY (`id_`),
  UNIQUE KEY `IX_E802AA3C` (`groupId`,`templateId`),
  UNIQUE KEY `IX_62D1B3AD` (`uuid_`,`groupId`),
  KEY `IX_77923653` (`groupId`),
  KEY `IX_1701CB2B` (`groupId`,`structureId`),
  KEY `IX_25FFB6FA` (`smallImageId`),
  KEY `IX_1B12CA20` (`templateId`),
  KEY `IX_2857419D` (`uuid_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `JournalTemplate`
--

LOCK TABLES `JournalTemplate` WRITE;
/*!40000 ALTER TABLE `JournalTemplate` DISABLE KEYS */;
INSERT INTO `JournalTemplate` VALUES ('19d9414b-9155-496e-ba9c-9971d2438032',10455,10435,10132,10169,'Test Test','2014-04-03 16:48:30','2014-04-03 16:48:30','10454','10452','WC Template Name','WC Template Description',' $Subject.getData()<br/>\n <br/> <img alt=\"Image\" src=\"$picture.getData()\" /><br/>\n $Content.getData()<br/>\n $Content.getChild(\"caption\").getData()\n','vm',1,0,10456,'');
/*!40000 ALTER TABLE `JournalTemplate` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `KaleoAction`
--

DROP TABLE IF EXISTS `KaleoAction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `KaleoAction` (
  `kaleoActionId` bigint(20) NOT NULL,
  `groupId` bigint(20) DEFAULT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `userId` bigint(20) DEFAULT NULL,
  `userName` varchar(200) DEFAULT NULL,
  `createDate` datetime DEFAULT NULL,
  `modifiedDate` datetime DEFAULT NULL,
  `kaleoDefinitionId` bigint(20) DEFAULT NULL,
  `kaleoNodeId` bigint(20) DEFAULT NULL,
  `kaleoNodeName` varchar(200) DEFAULT NULL,
  `name` varchar(200) DEFAULT NULL,
  `description` longtext,
  `executionType` varchar(20) DEFAULT NULL,
  `script` longtext,
  `scriptLanguage` varchar(75) DEFAULT NULL,
  `priority` int(11) DEFAULT NULL,
  PRIMARY KEY (`kaleoActionId`),
  KEY `IX_50E9112C` (`companyId`),
  KEY `IX_F95A622` (`kaleoDefinitionId`),
  KEY `IX_B88DF9B1` (`kaleoNodeId`,`executionType`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `KaleoAction`
--

LOCK TABLES `KaleoAction` WRITE;
/*!40000 ALTER TABLE `KaleoAction` DISABLE KEYS */;
INSERT INTO `KaleoAction` VALUES (10281,0,10132,10135,' ','2014-04-03 16:34:04','2014-04-03 16:34:04',10275,10280,'approved','approve','','onEntry','\n					\n						Packages.com.liferay.portal.kernel.workflow.WorkflowStatusManagerUtil.updateStatus(Packages.com.liferay.portal.kernel.workflow.WorkflowConstants.toStatus(\"approved\"), workflowContext);\n					\n				','javascript',0);
/*!40000 ALTER TABLE `KaleoAction` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `KaleoDefinition`
--

DROP TABLE IF EXISTS `KaleoDefinition`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `KaleoDefinition` (
  `kaleoDefinitionId` bigint(20) NOT NULL,
  `groupId` bigint(20) DEFAULT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `userId` bigint(20) DEFAULT NULL,
  `userName` varchar(200) DEFAULT NULL,
  `createDate` datetime DEFAULT NULL,
  `modifiedDate` datetime DEFAULT NULL,
  `name` varchar(200) DEFAULT NULL,
  `title` longtext,
  `description` longtext,
  `version` int(11) DEFAULT NULL,
  `active_` tinyint(4) DEFAULT NULL,
  `startKaleoNodeId` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`kaleoDefinitionId`),
  KEY `IX_40B9112F` (`companyId`),
  KEY `IX_408542BA` (`companyId`,`active_`),
  KEY `IX_76C781AE` (`companyId`,`name`),
  KEY `IX_4C23F11B` (`companyId`,`name`,`active_`),
  KEY `IX_EC14F81A` (`companyId`,`name`,`version`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `KaleoDefinition`
--

LOCK TABLES `KaleoDefinition` WRITE;
/*!40000 ALTER TABLE `KaleoDefinition` DISABLE KEYS */;
INSERT INTO `KaleoDefinition` VALUES (10275,0,10132,10135,' ','2014-04-03 16:34:04','2014-04-03 16:34:04','Single Approver','Single Approver','A single approver can approve a workflow content.',1,1,10282);
/*!40000 ALTER TABLE `KaleoDefinition` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `KaleoInstance`
--

DROP TABLE IF EXISTS `KaleoInstance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `KaleoInstance` (
  `kaleoInstanceId` bigint(20) NOT NULL,
  `groupId` bigint(20) DEFAULT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `userId` bigint(20) DEFAULT NULL,
  `userName` varchar(200) DEFAULT NULL,
  `createDate` datetime DEFAULT NULL,
  `modifiedDate` datetime DEFAULT NULL,
  `kaleoDefinitionId` bigint(20) DEFAULT NULL,
  `kaleoDefinitionName` varchar(200) DEFAULT NULL,
  `kaleoDefinitionVersion` int(11) DEFAULT NULL,
  `rootKaleoInstanceTokenId` bigint(20) DEFAULT NULL,
  `className` varchar(200) DEFAULT NULL,
  `classPK` bigint(20) DEFAULT NULL,
  `completed` tinyint(4) DEFAULT NULL,
  `completionDate` datetime DEFAULT NULL,
  `workflowContext` longtext,
  PRIMARY KEY (`kaleoInstanceId`),
  KEY `IX_5F2FCD2D` (`companyId`),
  KEY `IX_BF5839F8` (`companyId`,`kaleoDefinitionName`,`kaleoDefinitionVersion`,`completionDate`),
  KEY `IX_4DA4D123` (`kaleoDefinitionId`),
  KEY `IX_ACF16238` (`kaleoDefinitionId`,`completed`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `KaleoInstance`
--

LOCK TABLES `KaleoInstance` WRITE;
/*!40000 ALTER TABLE `KaleoInstance` DISABLE KEYS */;
/*!40000 ALTER TABLE `KaleoInstance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `KaleoInstanceToken`
--

DROP TABLE IF EXISTS `KaleoInstanceToken`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `KaleoInstanceToken` (
  `kaleoInstanceTokenId` bigint(20) NOT NULL,
  `groupId` bigint(20) DEFAULT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `userId` bigint(20) DEFAULT NULL,
  `userName` varchar(200) DEFAULT NULL,
  `createDate` datetime DEFAULT NULL,
  `modifiedDate` datetime DEFAULT NULL,
  `kaleoDefinitionId` bigint(20) DEFAULT NULL,
  `kaleoInstanceId` bigint(20) DEFAULT NULL,
  `parentKaleoInstanceTokenId` bigint(20) DEFAULT NULL,
  `currentKaleoNodeId` bigint(20) DEFAULT NULL,
  `currentKaleoNodeName` varchar(200) DEFAULT NULL,
  `className` varchar(75) DEFAULT NULL,
  `classPK` bigint(20) DEFAULT NULL,
  `completed` tinyint(4) DEFAULT NULL,
  `completionDate` datetime DEFAULT NULL,
  PRIMARY KEY (`kaleoInstanceTokenId`),
  KEY `IX_153721BE` (`companyId`),
  KEY `IX_4A86923B` (`companyId`,`parentKaleoInstanceTokenId`),
  KEY `IX_360D34D9` (`companyId`,`parentKaleoInstanceTokenId`,`completionDate`),
  KEY `IX_7BDB04B4` (`kaleoDefinitionId`),
  KEY `IX_F42AAFF6` (`kaleoInstanceId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `KaleoInstanceToken`
--

LOCK TABLES `KaleoInstanceToken` WRITE;
/*!40000 ALTER TABLE `KaleoInstanceToken` DISABLE KEYS */;
/*!40000 ALTER TABLE `KaleoInstanceToken` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `KaleoLog`
--

DROP TABLE IF EXISTS `KaleoLog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `KaleoLog` (
  `kaleoLogId` bigint(20) NOT NULL,
  `groupId` bigint(20) DEFAULT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `userId` bigint(20) DEFAULT NULL,
  `userName` varchar(200) DEFAULT NULL,
  `createDate` datetime DEFAULT NULL,
  `modifiedDate` datetime DEFAULT NULL,
  `kaleoDefinitionId` bigint(20) DEFAULT NULL,
  `kaleoInstanceId` bigint(20) DEFAULT NULL,
  `kaleoInstanceTokenId` bigint(20) DEFAULT NULL,
  `kaleoTaskInstanceTokenId` bigint(20) DEFAULT NULL,
  `kaleoNodeId` bigint(20) DEFAULT NULL,
  `kaleoNodeName` varchar(200) DEFAULT NULL,
  `terminalKaleoNode` tinyint(4) DEFAULT NULL,
  `kaleoActionId` bigint(20) DEFAULT NULL,
  `kaleoActionName` varchar(200) DEFAULT NULL,
  `kaleoActionDescription` longtext,
  `previousKaleoNodeId` bigint(20) DEFAULT NULL,
  `previousKaleoNodeName` varchar(200) DEFAULT NULL,
  `previousAssigneeClassName` varchar(200) DEFAULT NULL,
  `previousAssigneeClassPK` bigint(20) DEFAULT NULL,
  `currentAssigneeClassName` varchar(200) DEFAULT NULL,
  `currentAssigneeClassPK` bigint(20) DEFAULT NULL,
  `type_` varchar(50) DEFAULT NULL,
  `comment_` longtext,
  `startDate` datetime DEFAULT NULL,
  `endDate` datetime DEFAULT NULL,
  `duration` bigint(20) DEFAULT NULL,
  `workflowContext` longtext,
  PRIMARY KEY (`kaleoLogId`),
  KEY `IX_73B5F4DE` (`companyId`),
  KEY `IX_6C64B7D4` (`kaleoDefinitionId`),
  KEY `IX_5BC6AB16` (`kaleoInstanceId`),
  KEY `IX_25157F25` (`kaleoInstanceTokenId`,`kaleoNodeId`,`type_`),
  KEY `IX_470B9FF8` (`kaleoInstanceTokenId`,`type_`),
  KEY `IX_B0CDCA38` (`kaleoTaskInstanceTokenId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `KaleoLog`
--

LOCK TABLES `KaleoLog` WRITE;
/*!40000 ALTER TABLE `KaleoLog` DISABLE KEYS */;
/*!40000 ALTER TABLE `KaleoLog` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `KaleoNode`
--

DROP TABLE IF EXISTS `KaleoNode`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `KaleoNode` (
  `kaleoNodeId` bigint(20) NOT NULL,
  `groupId` bigint(20) DEFAULT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `userId` bigint(20) DEFAULT NULL,
  `userName` varchar(200) DEFAULT NULL,
  `createDate` datetime DEFAULT NULL,
  `modifiedDate` datetime DEFAULT NULL,
  `kaleoDefinitionId` bigint(20) DEFAULT NULL,
  `name` varchar(200) DEFAULT NULL,
  `description` longtext,
  `type_` varchar(20) DEFAULT NULL,
  `initial_` tinyint(4) DEFAULT NULL,
  `terminal` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`kaleoNodeId`),
  KEY `IX_C4E9ACE0` (`companyId`),
  KEY `IX_F28C443E` (`companyId`,`kaleoDefinitionId`),
  KEY `IX_32E94DD6` (`kaleoDefinitionId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `KaleoNode`
--

LOCK TABLES `KaleoNode` WRITE;
/*!40000 ALTER TABLE `KaleoNode` DISABLE KEYS */;
INSERT INTO `KaleoNode` VALUES (10276,0,10132,10135,' ','2014-04-03 16:34:04','2014-04-03 16:34:04',10275,'update','','TASK',0,0),(10280,0,10132,10135,' ','2014-04-03 16:34:04','2014-04-03 16:34:04',10275,'approved','','STATE',0,1),(10282,0,10132,10135,' ','2014-04-03 16:34:04','2014-04-03 16:34:04',10275,'created','','STATE',1,0),(10283,0,10132,10135,' ','2014-04-03 16:34:04','2014-04-03 16:34:04',10275,'review','','TASK',0,0);
/*!40000 ALTER TABLE `KaleoNode` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `KaleoNotification`
--

DROP TABLE IF EXISTS `KaleoNotification`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `KaleoNotification` (
  `kaleoNotificationId` bigint(20) NOT NULL,
  `groupId` bigint(20) DEFAULT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `userId` bigint(20) DEFAULT NULL,
  `userName` varchar(200) DEFAULT NULL,
  `createDate` datetime DEFAULT NULL,
  `modifiedDate` datetime DEFAULT NULL,
  `kaleoDefinitionId` bigint(20) DEFAULT NULL,
  `kaleoNodeId` bigint(20) DEFAULT NULL,
  `kaleoNodeName` varchar(200) DEFAULT NULL,
  `name` varchar(200) DEFAULT NULL,
  `description` longtext,
  `executionType` varchar(20) DEFAULT NULL,
  `template` longtext,
  `templateLanguage` varchar(75) DEFAULT NULL,
  `notificationTypes` varchar(25) DEFAULT NULL,
  PRIMARY KEY (`kaleoNotificationId`),
  KEY `IX_38829497` (`companyId`),
  KEY `IX_4B968E8D` (`kaleoDefinitionId`),
  KEY `IX_A5C459A6` (`kaleoNodeId`,`executionType`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `KaleoNotification`
--

LOCK TABLES `KaleoNotification` WRITE;
/*!40000 ALTER TABLE `KaleoNotification` DISABLE KEYS */;
INSERT INTO `KaleoNotification` VALUES (10277,0,10132,10135,' ','2014-04-03 16:34:04','2014-04-03 16:34:04',10275,10276,'update','Creator Modification Notification','','onAssignment','Your submission was rejected by a reviewer, please modify and resubmit.','text','email'),(10284,0,10132,10135,' ','2014-04-03 16:34:04','2014-04-03 16:34:04',10275,10283,'review','Review Notification','','onAssignment','You have a new submission waiting for your review in the workflow.','text','email');
/*!40000 ALTER TABLE `KaleoNotification` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `KaleoNotificationRecipient`
--

DROP TABLE IF EXISTS `KaleoNotificationRecipient`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `KaleoNotificationRecipient` (
  `kaleoNotificationRecipientId` bigint(20) NOT NULL,
  `groupId` bigint(20) DEFAULT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `userId` bigint(20) DEFAULT NULL,
  `userName` varchar(75) DEFAULT NULL,
  `createDate` datetime DEFAULT NULL,
  `modifiedDate` datetime DEFAULT NULL,
  `kaleoDefinitionId` bigint(20) DEFAULT NULL,
  `kaleoNotificationId` bigint(20) DEFAULT NULL,
  `recipientClassName` varchar(75) DEFAULT NULL,
  `recipientClassPK` bigint(20) DEFAULT NULL,
  `recipientRoleType` int(11) DEFAULT NULL,
  `address` varchar(75) DEFAULT NULL,
  PRIMARY KEY (`kaleoNotificationRecipientId`),
  KEY `IX_2C8C4AF4` (`companyId`),
  KEY `IX_AA6697EA` (`kaleoDefinitionId`),
  KEY `IX_7F4FED02` (`kaleoNotificationId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `KaleoNotificationRecipient`
--

LOCK TABLES `KaleoNotificationRecipient` WRITE;
/*!40000 ALTER TABLE `KaleoNotificationRecipient` DISABLE KEYS */;
/*!40000 ALTER TABLE `KaleoNotificationRecipient` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `KaleoTask`
--

DROP TABLE IF EXISTS `KaleoTask`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `KaleoTask` (
  `kaleoTaskId` bigint(20) NOT NULL,
  `groupId` bigint(20) DEFAULT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `userId` bigint(20) DEFAULT NULL,
  `userName` varchar(200) DEFAULT NULL,
  `createDate` datetime DEFAULT NULL,
  `modifiedDate` datetime DEFAULT NULL,
  `kaleoDefinitionId` bigint(20) DEFAULT NULL,
  `kaleoNodeId` bigint(20) DEFAULT NULL,
  `name` varchar(75) DEFAULT NULL,
  `description` varchar(75) DEFAULT NULL,
  `dueDateDuration` double DEFAULT NULL,
  `dueDateScale` varchar(75) DEFAULT NULL,
  PRIMARY KEY (`kaleoTaskId`),
  KEY `IX_E1F8B23D` (`companyId`),
  KEY `IX_3FFA633` (`kaleoDefinitionId`),
  KEY `IX_77B3F1A2` (`kaleoNodeId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `KaleoTask`
--

LOCK TABLES `KaleoTask` WRITE;
/*!40000 ALTER TABLE `KaleoTask` DISABLE KEYS */;
INSERT INTO `KaleoTask` VALUES (10278,0,10132,10135,' ','2014-04-03 16:34:04','2014-04-03 16:34:04',10275,10276,'update','',0,''),(10285,0,10132,10135,' ','2014-04-03 16:34:04','2014-04-03 16:34:04',10275,10283,'review','',0,'');
/*!40000 ALTER TABLE `KaleoTask` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `KaleoTaskAssignment`
--

DROP TABLE IF EXISTS `KaleoTaskAssignment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `KaleoTaskAssignment` (
  `kaleoTaskAssignmentId` bigint(20) NOT NULL,
  `groupId` bigint(20) DEFAULT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `userId` bigint(20) DEFAULT NULL,
  `userName` varchar(200) DEFAULT NULL,
  `createDate` datetime DEFAULT NULL,
  `modifiedDate` datetime DEFAULT NULL,
  `kaleoDefinitionId` bigint(20) DEFAULT NULL,
  `kaleoNodeId` bigint(20) DEFAULT NULL,
  `kaleoTaskId` bigint(20) DEFAULT NULL,
  `assigneeClassName` varchar(200) DEFAULT NULL,
  `assigneeClassPK` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`kaleoTaskAssignmentId`),
  KEY `IX_81225C04` (`assigneeClassName`,`kaleoTaskId`),
  KEY `IX_611732B0` (`companyId`),
  KEY `IX_575C03A6` (`kaleoDefinitionId`),
  KEY `IX_4DD12F58` (`kaleoTaskId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `KaleoTaskAssignment`
--

LOCK TABLES `KaleoTaskAssignment` WRITE;
/*!40000 ALTER TABLE `KaleoTaskAssignment` DISABLE KEYS */;
INSERT INTO `KaleoTaskAssignment` VALUES (10279,0,10132,10135,' ','2014-04-03 16:34:04','2014-04-03 16:34:04',10275,10276,10278,'com.liferay.portal.model.User',0),(10286,0,10132,10135,' ','2014-04-03 16:34:04','2014-04-03 16:34:04',10275,10283,10285,'com.liferay.portal.model.Role',10287),(10288,0,10132,10135,' ','2014-04-03 16:34:04','2014-04-03 16:34:04',10275,10283,10285,'com.liferay.portal.model.Role',10146),(10289,0,10132,10135,' ','2014-04-03 16:34:04','2014-04-03 16:34:04',10275,10283,10285,'com.liferay.portal.model.Role',10145),(10290,0,10132,10135,' ','2014-04-03 16:34:04','2014-04-03 16:34:04',10275,10283,10285,'com.liferay.portal.model.Role',10138),(10291,0,10132,10135,' ','2014-04-03 16:34:04','2014-04-03 16:34:04',10275,10283,10285,'com.liferay.portal.model.Role',10148),(10292,0,10132,10135,' ','2014-04-03 16:34:04','2014-04-03 16:34:04',10275,10283,10285,'com.liferay.portal.model.Role',10293),(10294,0,10132,10135,' ','2014-04-03 16:34:04','2014-04-03 16:34:04',10275,10283,10285,'com.liferay.portal.model.Role',10143),(10295,0,10132,10135,' ','2014-04-03 16:34:04','2014-04-03 16:34:04',10275,10283,10285,'com.liferay.portal.model.Role',10296);
/*!40000 ALTER TABLE `KaleoTaskAssignment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `KaleoTaskAssignmentInstance`
--

DROP TABLE IF EXISTS `KaleoTaskAssignmentInstance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `KaleoTaskAssignmentInstance` (
  `kaleoTaskAssignmentInstanceId` bigint(20) NOT NULL,
  `groupId` bigint(20) DEFAULT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `userId` bigint(20) DEFAULT NULL,
  `userName` varchar(75) DEFAULT NULL,
  `createDate` datetime DEFAULT NULL,
  `modifiedDate` datetime DEFAULT NULL,
  `kaleoDefinitionId` bigint(20) DEFAULT NULL,
  `kaleoInstanceId` bigint(20) DEFAULT NULL,
  `kaleoInstanceTokenId` bigint(20) DEFAULT NULL,
  `kaleoTaskInstanceTokenId` bigint(20) DEFAULT NULL,
  `kaleoTaskId` bigint(20) DEFAULT NULL,
  `kaleoTaskName` varchar(75) DEFAULT NULL,
  `assigneeClassName` varchar(75) DEFAULT NULL,
  `assigneeClassPK` bigint(20) DEFAULT NULL,
  `completed` tinyint(4) DEFAULT NULL,
  `completionDate` datetime DEFAULT NULL,
  PRIMARY KEY (`kaleoTaskAssignmentInstanceId`),
  KEY `IX_6E3CDA1B` (`companyId`),
  KEY `IX_C851011` (`kaleoDefinitionId`),
  KEY `IX_67A9EE93` (`kaleoInstanceId`),
  KEY `IX_D4C2235B` (`kaleoTaskInstanceTokenId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `KaleoTaskAssignmentInstance`
--

LOCK TABLES `KaleoTaskAssignmentInstance` WRITE;
/*!40000 ALTER TABLE `KaleoTaskAssignmentInstance` DISABLE KEYS */;
/*!40000 ALTER TABLE `KaleoTaskAssignmentInstance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `KaleoTaskInstanceToken`
--

DROP TABLE IF EXISTS `KaleoTaskInstanceToken`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `KaleoTaskInstanceToken` (
  `kaleoTaskInstanceTokenId` bigint(20) NOT NULL,
  `groupId` bigint(20) DEFAULT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `userId` bigint(20) DEFAULT NULL,
  `userName` varchar(200) DEFAULT NULL,
  `createDate` datetime DEFAULT NULL,
  `modifiedDate` datetime DEFAULT NULL,
  `kaleoDefinitionId` bigint(20) DEFAULT NULL,
  `kaleoInstanceId` bigint(20) DEFAULT NULL,
  `kaleoInstanceTokenId` bigint(20) DEFAULT NULL,
  `kaleoTaskId` bigint(20) DEFAULT NULL,
  `kaleoTaskName` varchar(200) DEFAULT NULL,
  `className` varchar(75) DEFAULT NULL,
  `classPK` bigint(20) DEFAULT NULL,
  `completionUserId` bigint(20) DEFAULT NULL,
  `completed` tinyint(4) DEFAULT NULL,
  `completionDate` datetime DEFAULT NULL,
  `dueDate` datetime DEFAULT NULL,
  `workflowContext` longtext,
  PRIMARY KEY (`kaleoTaskInstanceTokenId`),
  KEY `IX_997FE723` (`companyId`),
  KEY `IX_608E9519` (`kaleoDefinitionId`),
  KEY `IX_2CE1159B` (`kaleoInstanceId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `KaleoTaskInstanceToken`
--

LOCK TABLES `KaleoTaskInstanceToken` WRITE;
/*!40000 ALTER TABLE `KaleoTaskInstanceToken` DISABLE KEYS */;
/*!40000 ALTER TABLE `KaleoTaskInstanceToken` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `KaleoTransition`
--

DROP TABLE IF EXISTS `KaleoTransition`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `KaleoTransition` (
  `kaleoTransitionId` bigint(20) NOT NULL,
  `groupId` bigint(20) DEFAULT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `userId` bigint(20) DEFAULT NULL,
  `userName` varchar(200) DEFAULT NULL,
  `createDate` datetime DEFAULT NULL,
  `modifiedDate` datetime DEFAULT NULL,
  `kaleoDefinitionId` bigint(20) DEFAULT NULL,
  `kaleoNodeId` bigint(20) DEFAULT NULL,
  `name` varchar(200) DEFAULT NULL,
  `description` longtext,
  `sourceKaleoNodeId` bigint(20) DEFAULT NULL,
  `sourceKaleoNodeName` varchar(200) DEFAULT NULL,
  `targetKaleoNodeId` bigint(20) DEFAULT NULL,
  `targetKaleoNodeName` varchar(200) DEFAULT NULL,
  `defaultTransition` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`kaleoTransitionId`),
  KEY `IX_41D6C6D` (`companyId`),
  KEY `IX_479F3063` (`kaleoDefinitionId`),
  KEY `IX_A392DFD2` (`kaleoNodeId`),
  KEY `IX_A38E2194` (`kaleoNodeId`,`defaultTransition`),
  KEY `IX_85268A11` (`kaleoNodeId`,`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `KaleoTransition`
--

LOCK TABLES `KaleoTransition` WRITE;
/*!40000 ALTER TABLE `KaleoTransition` DISABLE KEYS */;
INSERT INTO `KaleoTransition` VALUES (10297,0,10132,10135,' ','2014-04-03 16:34:04','2014-04-03 16:34:04',10275,10276,'resubmit','',10276,'update',10283,'review',1),(10298,0,10132,10135,' ','2014-04-03 16:34:04','2014-04-03 16:34:04',10275,10282,'review','',10282,'created',10283,'review',1),(10299,0,10132,10135,' ','2014-04-03 16:34:04','2014-04-03 16:34:04',10275,10283,'approve','',10283,'review',10280,'approved',1),(10300,0,10132,10135,' ','2014-04-03 16:34:04','2014-04-03 16:34:04',10275,10283,'reject','',10283,'review',10276,'update',0);
/*!40000 ALTER TABLE `KaleoTransition` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Layout`
--

DROP TABLE IF EXISTS `Layout`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Layout` (
  `uuid_` varchar(75) DEFAULT NULL,
  `plid` bigint(20) NOT NULL,
  `groupId` bigint(20) DEFAULT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `privateLayout` tinyint(4) DEFAULT NULL,
  `layoutId` bigint(20) DEFAULT NULL,
  `parentLayoutId` bigint(20) DEFAULT NULL,
  `name` longtext,
  `title` longtext,
  `description` longtext,
  `type_` varchar(75) DEFAULT NULL,
  `typeSettings` longtext,
  `hidden_` tinyint(4) DEFAULT NULL,
  `friendlyURL` varchar(255) DEFAULT NULL,
  `iconImage` tinyint(4) DEFAULT NULL,
  `iconImageId` bigint(20) DEFAULT NULL,
  `themeId` varchar(75) DEFAULT NULL,
  `colorSchemeId` varchar(75) DEFAULT NULL,
  `wapThemeId` varchar(75) DEFAULT NULL,
  `wapColorSchemeId` varchar(75) DEFAULT NULL,
  `css` longtext,
  `priority` int(11) DEFAULT NULL,
  `layoutPrototypeId` bigint(20) DEFAULT NULL,
  `dlFolderId` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`plid`),
  UNIQUE KEY `IX_BC2C4231` (`groupId`,`privateLayout`,`friendlyURL`),
  UNIQUE KEY `IX_7162C27C` (`groupId`,`privateLayout`,`layoutId`),
  UNIQUE KEY `IX_CED31606` (`uuid_`,`groupId`),
  KEY `IX_C7FBC998` (`companyId`),
  KEY `IX_FAD05595` (`dlFolderId`),
  KEY `IX_C099D61A` (`groupId`),
  KEY `IX_705F5AA3` (`groupId`,`privateLayout`),
  KEY `IX_6DE88B06` (`groupId`,`privateLayout`,`parentLayoutId`),
  KEY `IX_1A1B61D2` (`groupId`,`privateLayout`,`type_`),
  KEY `IX_23922F7D` (`iconImageId`),
  KEY `IX_D0822724` (`uuid_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Layout`
--

LOCK TABLES `Layout` WRITE;
/*!40000 ALTER TABLE `Layout` DISABLE KEYS */;
INSERT INTO `Layout` VALUES ('d475d9d9-7849-42db-9c29-ead695e06252',10152,10149,10132,1,1,0,'<?xml version=\'1.0\' encoding=\'UTF-8\'?><root available-locales=\"en_US\" default-locale=\"en_US\"><name language-id=\"en_US\">Control Panel</name></root>','','','control_panel','',0,'/manage',0,0,'','','','','',0,0,0),('1b292b48-af21-4f7d-8180-2ccbc180eeb0',10160,10157,10132,0,1,0,'<?xml version=\'1.0\' encoding=\'UTF-8\'?><root available-locales=\"en_US\" default-locale=\"en_US\"><name language-id=\"en_US\">Welcome</name></root>','','','portlet','layout-template-id=2_columns_ii\ncolumn-2=47,\ncolumn-1=58,\n',0,'/home',0,0,'','','','','',0,0,0),('7463da52-88ea-44b6-9131-b11895b8b36f',10320,10171,10132,1,1,0,'<?xml version=\'1.0\' encoding=\'UTF-8\'?><root available-locales=\"en_US\" default-locale=\"en_US\"><name language-id=\"en_US\">Welcome</name></root>','','','portlet','layout-template-id=2_columns_ii\ncolumn-2=29,8,\ncolumn-1=82,23,11,\n',0,'/home',0,0,'','','','','',0,0,0),('7ef0558c-015e-4e52-a315-e7ee64a0ffcb',10325,10171,10132,0,1,0,'<?xml version=\'1.0\' encoding=\'UTF-8\'?><root available-locales=\"en_US\" default-locale=\"en_US\"><name language-id=\"en_US\">Welcome</name></root>','','','portlet','layout-template-id=2_columns_ii\ncolumn-2=33,\ncolumn-1=82,3,\n',0,'/home',0,0,'','','','','',0,0,0),('b5fe4463-b04e-4707-8e61-2b4c8a232fe2',10333,10157,10132,0,2,0,'<?xml version=\'1.0\' encoding=\'UTF-8\'?><root available-locales=\"en_US\" default-locale=\"en_US\"><name language-id=\"en_US\">Software Catalog Page</name></root>','','','portlet','layout-template-id=2_columns_ii\ncolumn-1=98\n',0,'/software-catalog-page',0,0,'','','','','',1,0,0),('f1ecbade-24c8-4961-aa8c-bbe4c98bd097',10392,10388,10132,0,1,0,'<?xml version=\'1.0\' encoding=\'UTF-8\'?><root available-locales=\"en_US\" default-locale=\"en_US\"><name language-id=\"en_US\">Wiki Test Page</name></root>','','','portlet','layout-template-id=2_columns_ii\ncolumn-1=36\n',0,'/wiki-test-page',0,0,'','','','','',0,0,0),('89b34cb6-a9c5-46ed-8e0d-64be93a530df',10424,10157,10132,0,3,0,'<?xml version=\'1.0\' encoding=\'UTF-8\'?><root available-locales=\"en_US\" default-locale=\"en_US\"><name language-id=\"en_US\">Polls Display Page</name></root>','','','portlet','layout-template-id=2_columns_ii\ncolumn-1=59_INSTANCE_l7zO\n',0,'/polls-display-page',0,0,'','','','','',2,0,0),('54ab654e-1fa2-4a7d-849c-3b6373d8e90a',10439,10435,10132,0,1,0,'<?xml version=\'1.0\' encoding=\'UTF-8\'?><root available-locales=\"en_US\" default-locale=\"en_US\"><name language-id=\"en_US\">Web Content Display Page</name></root>','','','portlet','layout-template-id=2_columns_ii\ncolumn-1=56_INSTANCE_hUa2\n',0,'/web-content-display-page',0,0,'','','','','',0,0,0),('334331b7-4114-485a-b302-b9b839448a7d',10485,10481,10132,0,1,0,'<?xml version=\'1.0\' encoding=\'UTF-8\'?><root available-locales=\"en_US\" default-locale=\"en_US\"><name language-id=\"en_US\">Social Equity Page</name></root>','','','portlet','layout-template-id=2_columns_ii\ncolumn-1=84\n',0,'/social-equity-page',0,0,'','','','','',0,0,0),('bf81fec7-583f-465c-8bbc-429cb4620b43',10526,10523,10132,1,1,0,'<?xml version=\'1.0\' encoding=\'UTF-8\'?><root available-locales=\"en_US\" default-locale=\"en_US\"><name language-id=\"en_US\">10522</name></root>','','','portlet','layout-template-id=2_columns_ii\n',0,'/layout',0,0,'','','','','',0,0,0),('37535e38-8622-4aca-b622-00485ca72c3e',10536,10533,10132,1,1,0,'<?xml version=\'1.0\' encoding=\'UTF-8\'?><root available-locales=\"en_US\" default-locale=\"en_US\"><name language-id=\"en_US\">home</name></root>','','','portlet','layout-template-id=2_columns_ii\n',0,'/home',0,0,'','','','','',0,0,0),('03e0642d-0ee8-4798-8e69-f2463f1765f0',10552,10545,10132,1,1,0,'<?xml version=\'1.0\' encoding=\'UTF-8\'?><root available-locales=\"en_US\" default-locale=\"en_US\"><name language-id=\"en_US\">Welcome</name></root>','','','portlet','layout-template-id=2_columns_ii\ncolumn-2=29,8,\ncolumn-1=82,23,11,\n',0,'/home',0,0,'','','','','',0,0,0),('fd222efb-83e9-47c8-839a-624187f22db7',10557,10545,10132,0,1,0,'<?xml version=\'1.0\' encoding=\'UTF-8\'?><root available-locales=\"en_US\" default-locale=\"en_US\"><name language-id=\"en_US\">Welcome</name></root>','','','portlet','layout-template-id=2_columns_ii\ncolumn-2=33,\ncolumn-1=82,3,\n',0,'/home',0,0,'','','','','',0,0,0),('1aeb80db-8f9a-4b00-b469-6c4ade570502',10566,10157,10132,0,4,0,'<?xml version=\'1.0\' encoding=\'UTF-8\'?><root available-locales=\"en_US\" default-locale=\"en_US\"><name language-id=\"en_US\">Shopping Page</name></root>','','','portlet','layout-template-id=2_columns_ii\ncolumn-1=34\n',0,'/shopping-page',0,0,'','','','','',3,0,0),('3a1170ab-5a77-4331-9a0b-9a1351024b79',10598,10591,10132,1,1,0,'<?xml version=\'1.0\' encoding=\'UTF-8\'?><root available-locales=\"en_US\" default-locale=\"en_US\"><name language-id=\"en_US\">Welcome</name></root>','','','portlet','layout-template-id=2_columns_ii\ncolumn-2=29,8,\ncolumn-1=82,23,11,\n',0,'/home',0,0,'','','','','',0,0,0),('7b3fd702-f16b-4f7c-8212-29862e67d934',10603,10591,10132,0,1,0,'<?xml version=\'1.0\' encoding=\'UTF-8\'?><root available-locales=\"en_US\" default-locale=\"en_US\"><name language-id=\"en_US\">Welcome</name></root>','','','portlet','layout-template-id=2_columns_ii\ncolumn-2=33,\ncolumn-1=82,3,\n',0,'/home',0,0,'','','','','',0,0,0),('bbe13cf5-c125-4b18-81e6-9cfc2dbec996',10621,10617,10132,0,1,0,'<?xml version=\'1.0\' encoding=\'UTF-8\'?><root available-locales=\"en_US\" default-locale=\"en_US\"><name language-id=\"en_US\">Message Boards Page</name></root>','','','portlet','layout-template-id=2_columns_ii\n',0,'/message-boards-page',0,0,'','','','','',0,0,0),('bbe13cf5-c125-4b18-81e6-9cfc2dbec996',10636,10626,10132,0,1,0,'<?xml version=\'1.0\' encoding=\'UTF-8\'?><root available-locales=\"en_US\" default-locale=\"en_US\"><name language-id=\"en_US\">Message Boards Page</name></root>','','','portlet','layout-template-id=2_columns_ii\ncolumn-1=19\n',0,'/message-boards-page',0,0,'','','','','',0,0,0),('20367a67-8be6-4840-8d59-4eb871823e47',10651,10157,10132,0,5,0,'<?xml version=\'1.0\' encoding=\'UTF-8\'?><root available-locales=\"en_US\" default-locale=\"en_US\"><name language-id=\"en_US\">Bookmarks Page</name></root>','','','portlet','layout-template-id=2_columns_ii\ncolumn-1=28\n',0,'/bookmarks-page',0,0,'','','','','',4,0,0),('27136143-5b80-47a5-86f7-ee6df58091f0',10667,10663,10132,0,1,0,'<?xml version=\'1.0\' encoding=\'UTF-8\'?><root available-locales=\"en_US\" default-locale=\"en_US\"><name language-id=\"en_US\">Asset Publisher Page</name></root>','','','portlet','layout-template-id=2_columns_ii\ncolumn-1=33,19,101_INSTANCE_dCR9\n',0,'/asset-publisher-page',0,0,'','','','','',0,0,0),('0202ead6-76df-4d9e-ba5a-548946e6961a',10682,10678,10132,0,1,0,'<?xml version=\'1.0\' encoding=\'UTF-8\'?><root available-locales=\"en_US\" default-locale=\"en_US\"><name language-id=\"en_US\">Document Library Page</name></root>','','','portlet','layout-template-id=2_columns_ii\ncolumn-1=20\n',0,'/document-library-page',0,0,'','','','','',0,0,0),('ae64ed45-59f3-4a64-92cb-df10dade53a7',10713,10157,10132,0,6,0,'<?xml version=\'1.0\' encoding=\'UTF-8\'?><root available-locales=\"en_US\" default-locale=\"en_US\"><name language-id=\"en_US\">Calendar Page</name></root>','','','portlet','layout-template-id=2_columns_ii\ncolumn-1=8\n',0,'/calendar-page',0,0,'','','','','',5,0,0),('40549cea-4eca-493f-829b-0561543d9561',10725,10157,10132,0,7,0,'<?xml version=\'1.0\' encoding=\'UTF-8\'?><root available-locales=\"en_US\" default-locale=\"en_US\"><name language-id=\"en_US\">Announcements Page</name></root>','','','portlet','layout-template-id=2_columns_ii\ncolumn-1=84\n',0,'/announcements-page',0,0,'','','','','',6,0,0),('8737e54e-9ca4-4315-bfbb-0e224bc0939e',10756,10752,10132,0,1,0,'<?xml version=\'1.0\' encoding=\'UTF-8\'?><root available-locales=\"en_US\" default-locale=\"en_US\"><name language-id=\"en_US\">Blogs Page</name></root>','','','portlet','layout-template-id=2_columns_ii\ncolumn-1=33\n',0,'/blogs-page',0,0,'','','','','',0,0,0);
/*!40000 ALTER TABLE `Layout` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `LayoutPrototype`
--

DROP TABLE IF EXISTS `LayoutPrototype`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `LayoutPrototype` (
  `layoutPrototypeId` bigint(20) NOT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `name` longtext,
  `description` longtext,
  `settings_` longtext,
  `active_` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`layoutPrototypeId`),
  KEY `IX_30616AAA` (`companyId`),
  KEY `IX_557A639F` (`companyId`,`active_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `LayoutPrototype`
--

LOCK TABLES `LayoutPrototype` WRITE;
/*!40000 ALTER TABLE `LayoutPrototype` DISABLE KEYS */;
INSERT INTO `LayoutPrototype` VALUES (10522,10132,'<?xml version=\'1.0\' encoding=\'UTF-8\'?><root available-locales=\"en_US\" default-locale=\"en_US\"><Name language-id=\"en_US\">Page Template Name</Name></root>','','',1);
/*!40000 ALTER TABLE `LayoutPrototype` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `LayoutSet`
--

DROP TABLE IF EXISTS `LayoutSet`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `LayoutSet` (
  `layoutSetId` bigint(20) NOT NULL,
  `groupId` bigint(20) DEFAULT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `privateLayout` tinyint(4) DEFAULT NULL,
  `logo` tinyint(4) DEFAULT NULL,
  `logoId` bigint(20) DEFAULT NULL,
  `themeId` varchar(75) DEFAULT NULL,
  `colorSchemeId` varchar(75) DEFAULT NULL,
  `wapThemeId` varchar(75) DEFAULT NULL,
  `wapColorSchemeId` varchar(75) DEFAULT NULL,
  `css` longtext,
  `pageCount` int(11) DEFAULT NULL,
  `virtualHost` varchar(75) DEFAULT NULL,
  `settings_` longtext,
  `layoutSetPrototypeId` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`layoutSetId`),
  UNIQUE KEY `IX_48550691` (`groupId`,`privateLayout`),
  KEY `IX_A40B8BEC` (`groupId`),
  KEY `IX_5ABC2905` (`virtualHost`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `LayoutSet`
--

LOCK TABLES `LayoutSet` WRITE;
/*!40000 ALTER TABLE `LayoutSet` DISABLE KEYS */;
INSERT INTO `LayoutSet` VALUES (10150,10149,10132,1,0,0,'classic','01','mobile','01','',1,'','',0),(10151,10149,10132,0,0,0,'classic','01','mobile','01','',0,'','',0),(10158,10157,10132,1,0,0,'classic','01','mobile','01','',0,'','',0),(10159,10157,10132,0,0,0,'classic','01','mobile','01','',7,'','',0),(10166,10165,10132,1,0,0,'classic','01','mobile','01','',0,'','',0),(10167,10165,10132,0,0,0,'classic','01','mobile','01','',0,'','',0),(10172,10171,10132,1,0,0,'classic','01','mobile','01','',1,'','',0),(10173,10171,10132,0,0,0,'classic','01','mobile','01','',1,'','',0),(10358,10357,10132,1,0,0,'classic','01','mobile','01','',0,'','',0),(10359,10357,10132,0,0,0,'classic','01','mobile','01','',0,'','',0),(10368,10367,10132,1,0,0,'classic','01','mobile','01','',0,'','',0),(10369,10367,10132,0,0,0,'classic','01','mobile','01','',0,'','',0),(10377,10376,10132,1,0,0,'classic','01','mobile','01','',0,'','',0),(10378,10376,10132,0,0,0,'classic','01','mobile','01','',0,'','',0),(10386,10385,10132,1,0,0,'classic','01','mobile','01','',0,'','',0),(10387,10385,10132,0,0,0,'classic','01','mobile','01','',0,'','',0),(10389,10388,10132,1,0,0,'classic','01','mobile','01','',0,'','',0),(10390,10388,10132,0,0,0,'classic','01','mobile','01','',1,'','',0),(10436,10435,10132,1,0,0,'classic','01','mobile','01','',0,'','',0),(10437,10435,10132,0,0,0,'classic','01','mobile','01','',1,'','',0),(10482,10481,10132,1,0,0,'classic','01','mobile','01','',0,'','',0),(10483,10481,10132,0,0,0,'classic','01','mobile','01','',1,'','',0),(10524,10523,10132,1,0,0,'classic','01','mobile','01','',1,'','',0),(10525,10523,10132,0,0,0,'classic','01','mobile','01','',0,'','',0),(10534,10533,10132,1,0,0,'classic','01','mobile','01','',1,'','',0),(10535,10533,10132,0,0,0,'classic','01','mobile','01','',0,'','',0),(10546,10545,10132,1,0,0,'classic','01','mobile','01','',1,'','',0),(10547,10545,10132,0,0,0,'classic','01','mobile','01','',1,'','',0),(10586,10585,10132,1,0,0,'classic','01','mobile','01','',0,'','',0),(10587,10585,10132,0,0,0,'classic','01','mobile','01','',0,'','',0),(10592,10591,10132,1,0,0,'classic','01','mobile','01','',1,'','',0),(10593,10591,10132,0,0,0,'classic','01','mobile','01','',1,'','',0),(10618,10617,10132,1,0,0,'classic','01','mobile','01','',0,'','',0),(10619,10617,10132,0,0,0,'classic','01','mobile','01','',1,'','last-publish-date=1396544266496\n',0),(10627,10626,10132,1,0,0,'classic','01','mobile','01','',0,'','',0),(10628,10626,10132,0,0,0,'classic','01','mobile','01','',1,'','',0),(10664,10663,10132,1,0,0,'classic','01','mobile','01','',0,'','',0),(10665,10663,10132,0,0,0,'classic','01','mobile','01','',1,'','',0),(10679,10678,10132,1,0,0,'classic','01','mobile','01','',0,'','',0),(10680,10678,10132,0,0,0,'classic','01','mobile','01','',1,'','',0),(10746,10745,10132,1,0,0,'classic','01','mobile','01','',0,'','',0),(10747,10745,10132,0,0,0,'classic','01','mobile','01','',0,'','',0),(10753,10752,10132,1,0,0,'classic','01','mobile','01','',0,'','',0),(10754,10752,10132,0,0,0,'classic','01','mobile','01','',1,'','',0);
/*!40000 ALTER TABLE `LayoutSet` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `LayoutSetPrototype`
--

DROP TABLE IF EXISTS `LayoutSetPrototype`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `LayoutSetPrototype` (
  `layoutSetPrototypeId` bigint(20) NOT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `name` longtext,
  `description` longtext,
  `settings_` longtext,
  `active_` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`layoutSetPrototypeId`),
  KEY `IX_55F63D98` (`companyId`),
  KEY `IX_9178FC71` (`companyId`,`active_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `LayoutSetPrototype`
--

LOCK TABLES `LayoutSetPrototype` WRITE;
/*!40000 ALTER TABLE `LayoutSetPrototype` DISABLE KEYS */;
INSERT INTO `LayoutSetPrototype` VALUES (10532,10132,'<?xml version=\'1.0\' encoding=\'UTF-8\'?><root available-locales=\"en_US\" default-locale=\"en_US\"><Name language-id=\"en_US\">Site Template Name</Name></root>','','',1);
/*!40000 ALTER TABLE `LayoutSetPrototype` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ListType`
--

DROP TABLE IF EXISTS `ListType`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ListType` (
  `listTypeId` int(11) NOT NULL,
  `name` varchar(75) DEFAULT NULL,
  `type_` varchar(75) DEFAULT NULL,
  PRIMARY KEY (`listTypeId`),
  KEY `IX_2932DD37` (`type_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ListType`
--

LOCK TABLES `ListType` WRITE;
/*!40000 ALTER TABLE `ListType` DISABLE KEYS */;
INSERT INTO `ListType` VALUES (10000,'Billing','com.liferay.portal.model.Account.address'),(10001,'Other','com.liferay.portal.model.Account.address'),(10002,'P.O. Box','com.liferay.portal.model.Account.address'),(10003,'Shipping','com.liferay.portal.model.Account.address'),(10004,'E-mail','com.liferay.portal.model.Account.emailAddress'),(10005,'E-mail 2','com.liferay.portal.model.Account.emailAddress'),(10006,'E-mail 3','com.liferay.portal.model.Account.emailAddress'),(10007,'Fax','com.liferay.portal.model.Account.phone'),(10008,'Local','com.liferay.portal.model.Account.phone'),(10009,'Other','com.liferay.portal.model.Account.phone'),(10010,'Toll-Free','com.liferay.portal.model.Account.phone'),(10011,'TTY','com.liferay.portal.model.Account.phone'),(10012,'Intranet','com.liferay.portal.model.Account.website'),(10013,'Public','com.liferay.portal.model.Account.website'),(11000,'Business','com.liferay.portal.model.Contact.address'),(11001,'Other','com.liferay.portal.model.Contact.address'),(11002,'Personal','com.liferay.portal.model.Contact.address'),(11003,'E-mail','com.liferay.portal.model.Contact.emailAddress'),(11004,'E-mail 2','com.liferay.portal.model.Contact.emailAddress'),(11005,'E-mail 3','com.liferay.portal.model.Contact.emailAddress'),(11006,'Business','com.liferay.portal.model.Contact.phone'),(11007,'Business Fax','com.liferay.portal.model.Contact.phone'),(11008,'Mobile','com.liferay.portal.model.Contact.phone'),(11009,'Other','com.liferay.portal.model.Contact.phone'),(11010,'Pager','com.liferay.portal.model.Contact.phone'),(11011,'Personal','com.liferay.portal.model.Contact.phone'),(11012,'Personal Fax','com.liferay.portal.model.Contact.phone'),(11013,'TTY','com.liferay.portal.model.Contact.phone'),(11014,'Dr.','com.liferay.portal.model.Contact.prefix'),(11015,'Mr.','com.liferay.portal.model.Contact.prefix'),(11016,'Mrs.','com.liferay.portal.model.Contact.prefix'),(11017,'Ms.','com.liferay.portal.model.Contact.prefix'),(11020,'II','com.liferay.portal.model.Contact.suffix'),(11021,'III','com.liferay.portal.model.Contact.suffix'),(11022,'IV','com.liferay.portal.model.Contact.suffix'),(11023,'Jr.','com.liferay.portal.model.Contact.suffix'),(11024,'PhD.','com.liferay.portal.model.Contact.suffix'),(11025,'Sr.','com.liferay.portal.model.Contact.suffix'),(11026,'Blog','com.liferay.portal.model.Contact.website'),(11027,'Business','com.liferay.portal.model.Contact.website'),(11028,'Other','com.liferay.portal.model.Contact.website'),(11029,'Personal','com.liferay.portal.model.Contact.website'),(12000,'Billing','com.liferay.portal.model.Organization.address'),(12001,'Other','com.liferay.portal.model.Organization.address'),(12002,'P.O. Box','com.liferay.portal.model.Organization.address'),(12003,'Shipping','com.liferay.portal.model.Organization.address'),(12004,'E-mail','com.liferay.portal.model.Organization.emailAddress'),(12005,'E-mail 2','com.liferay.portal.model.Organization.emailAddress'),(12006,'E-mail 3','com.liferay.portal.model.Organization.emailAddress'),(12007,'Fax','com.liferay.portal.model.Organization.phone'),(12008,'Local','com.liferay.portal.model.Organization.phone'),(12009,'Other','com.liferay.portal.model.Organization.phone'),(12010,'Toll-Free','com.liferay.portal.model.Organization.phone'),(12011,'TTY','com.liferay.portal.model.Organization.phone'),(12012,'Administrative','com.liferay.portal.model.Organization.service'),(12013,'Contracts','com.liferay.portal.model.Organization.service'),(12014,'Donation','com.liferay.portal.model.Organization.service'),(12015,'Retail','com.liferay.portal.model.Organization.service'),(12016,'Training','com.liferay.portal.model.Organization.service'),(12017,'Full Member','com.liferay.portal.model.Organization.status'),(12018,'Provisional Member','com.liferay.portal.model.Organization.status'),(12019,'Intranet','com.liferay.portal.model.Organization.website'),(12020,'Public','com.liferay.portal.model.Organization.website');
/*!40000 ALTER TABLE `ListType` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Lock_`
--

DROP TABLE IF EXISTS `Lock_`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Lock_` (
  `uuid_` varchar(75) DEFAULT NULL,
  `lockId` bigint(20) NOT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `userId` bigint(20) DEFAULT NULL,
  `userName` varchar(75) DEFAULT NULL,
  `createDate` datetime DEFAULT NULL,
  `className` varchar(75) DEFAULT NULL,
  `key_` varchar(200) DEFAULT NULL,
  `owner` varchar(75) DEFAULT NULL,
  `inheritable` tinyint(4) DEFAULT NULL,
  `expirationDate` datetime DEFAULT NULL,
  PRIMARY KEY (`lockId`),
  KEY `IX_228562AD` (`className`,`key_`),
  KEY `IX_E3F1286B` (`expirationDate`),
  KEY `IX_13C5CD3A` (`uuid_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Lock_`
--

LOCK TABLES `Lock_` WRITE;
/*!40000 ALTER TABLE `Lock_` DISABLE KEYS */;
/*!40000 ALTER TABLE `Lock_` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MBBan`
--

DROP TABLE IF EXISTS `MBBan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `MBBan` (
  `banId` bigint(20) NOT NULL,
  `groupId` bigint(20) DEFAULT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `userId` bigint(20) DEFAULT NULL,
  `userName` varchar(75) DEFAULT NULL,
  `createDate` datetime DEFAULT NULL,
  `modifiedDate` datetime DEFAULT NULL,
  `banUserId` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`banId`),
  UNIQUE KEY `IX_8ABC4E3B` (`groupId`,`banUserId`),
  KEY `IX_69951A25` (`banUserId`),
  KEY `IX_5C3FF12A` (`groupId`),
  KEY `IX_48814BBA` (`userId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MBBan`
--

LOCK TABLES `MBBan` WRITE;
/*!40000 ALTER TABLE `MBBan` DISABLE KEYS */;
/*!40000 ALTER TABLE `MBBan` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MBCategory`
--

DROP TABLE IF EXISTS `MBCategory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `MBCategory` (
  `uuid_` varchar(75) DEFAULT NULL,
  `categoryId` bigint(20) NOT NULL,
  `groupId` bigint(20) DEFAULT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `userId` bigint(20) DEFAULT NULL,
  `userName` varchar(75) DEFAULT NULL,
  `createDate` datetime DEFAULT NULL,
  `modifiedDate` datetime DEFAULT NULL,
  `parentCategoryId` bigint(20) DEFAULT NULL,
  `name` varchar(75) DEFAULT NULL,
  `description` longtext,
  `threadCount` int(11) DEFAULT NULL,
  `messageCount` int(11) DEFAULT NULL,
  `lastPostDate` datetime DEFAULT NULL,
  PRIMARY KEY (`categoryId`),
  UNIQUE KEY `IX_F7D28C2F` (`uuid_`,`groupId`),
  KEY `IX_BC735DCF` (`companyId`),
  KEY `IX_BB870C11` (`groupId`),
  KEY `IX_ED292508` (`groupId`,`parentCategoryId`),
  KEY `IX_C2626EDB` (`uuid_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MBCategory`
--

LOCK TABLES `MBCategory` WRITE;
/*!40000 ALTER TABLE `MBCategory` DISABLE KEYS */;
INSERT INTO `MBCategory` VALUES ('703fb82e-5d69-468e-9c2d-e7e3c549ac94',10645,10626,10132,10169,'Test Test','2014-04-03 16:58:00','2014-04-03 16:58:00',0,'MB Category Name','',0,0,NULL);
/*!40000 ALTER TABLE `MBCategory` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MBDiscussion`
--

DROP TABLE IF EXISTS `MBDiscussion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `MBDiscussion` (
  `discussionId` bigint(20) NOT NULL,
  `classNameId` bigint(20) DEFAULT NULL,
  `classPK` bigint(20) DEFAULT NULL,
  `threadId` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`discussionId`),
  UNIQUE KEY `IX_33A4DE38` (`classNameId`,`classPK`),
  UNIQUE KEY `IX_B5CA2DC` (`threadId`),
  KEY `IX_79D0120B` (`classNameId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MBDiscussion`
--

LOCK TABLES `MBDiscussion` WRITE;
/*!40000 ALTER TABLE `MBDiscussion` DISABLE KEYS */;
INSERT INTO `MBDiscussion` VALUES (10156,10014,10152,10154),(10164,10014,10160,10162),(10324,10014,10320,10322),(10329,10014,10325,10327),(10337,10014,10333,10335),(10351,10123,10344,10349),(10396,10014,10392,10394),(10408,10129,10403,10406),(10428,10014,10424,10426),(10443,10014,10439,10441),(10466,10084,10459,10464),(10489,10014,10485,10487),(10530,10014,10526,10528),(10540,10014,10536,10538),(10556,10014,10552,10554),(10561,10014,10557,10559),(10570,10014,10566,10568),(10602,10014,10598,10600),(10607,10014,10603,10605),(10625,10014,10621,10623),(10655,10014,10651,10653),(10671,10014,10667,10669),(10686,10014,10682,10684),(10697,10073,10707,10695),(10717,10014,10713,10715),(10729,10014,10725,10727),(10760,10014,10756,10758);
/*!40000 ALTER TABLE `MBDiscussion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MBMailingList`
--

DROP TABLE IF EXISTS `MBMailingList`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `MBMailingList` (
  `uuid_` varchar(75) DEFAULT NULL,
  `mailingListId` bigint(20) NOT NULL,
  `groupId` bigint(20) DEFAULT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `userId` bigint(20) DEFAULT NULL,
  `userName` varchar(75) DEFAULT NULL,
  `createDate` datetime DEFAULT NULL,
  `modifiedDate` datetime DEFAULT NULL,
  `categoryId` bigint(20) DEFAULT NULL,
  `emailAddress` varchar(75) DEFAULT NULL,
  `inProtocol` varchar(75) DEFAULT NULL,
  `inServerName` varchar(75) DEFAULT NULL,
  `inServerPort` int(11) DEFAULT NULL,
  `inUseSSL` tinyint(4) DEFAULT NULL,
  `inUserName` varchar(75) DEFAULT NULL,
  `inPassword` varchar(75) DEFAULT NULL,
  `inReadInterval` int(11) DEFAULT NULL,
  `outEmailAddress` varchar(75) DEFAULT NULL,
  `outCustom` tinyint(4) DEFAULT NULL,
  `outServerName` varchar(75) DEFAULT NULL,
  `outServerPort` int(11) DEFAULT NULL,
  `outUseSSL` tinyint(4) DEFAULT NULL,
  `outUserName` varchar(75) DEFAULT NULL,
  `outPassword` varchar(75) DEFAULT NULL,
  `active_` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`mailingListId`),
  UNIQUE KEY `IX_76CE9CDD` (`groupId`,`categoryId`),
  UNIQUE KEY `IX_E858F170` (`uuid_`,`groupId`),
  KEY `IX_BFEB984F` (`active_`),
  KEY `IX_4115EC7A` (`uuid_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MBMailingList`
--

LOCK TABLES `MBMailingList` WRITE;
/*!40000 ALTER TABLE `MBMailingList` DISABLE KEYS */;
INSERT INTO `MBMailingList` VALUES ('8dac69e0-6ecc-40ac-bf61-20df0211af4f',10646,10626,10132,10169,'Test Test','2014-04-03 16:58:00','2014-04-03 16:58:00',10645,'','pop3','',110,0,'','',5,'',0,'',25,0,'','',0);
/*!40000 ALTER TABLE `MBMailingList` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MBMessage`
--

DROP TABLE IF EXISTS `MBMessage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `MBMessage` (
  `uuid_` varchar(75) DEFAULT NULL,
  `messageId` bigint(20) NOT NULL,
  `groupId` bigint(20) DEFAULT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `userId` bigint(20) DEFAULT NULL,
  `userName` varchar(75) DEFAULT NULL,
  `createDate` datetime DEFAULT NULL,
  `modifiedDate` datetime DEFAULT NULL,
  `classNameId` bigint(20) DEFAULT NULL,
  `classPK` bigint(20) DEFAULT NULL,
  `categoryId` bigint(20) DEFAULT NULL,
  `threadId` bigint(20) DEFAULT NULL,
  `rootMessageId` bigint(20) DEFAULT NULL,
  `parentMessageId` bigint(20) DEFAULT NULL,
  `subject` varchar(75) DEFAULT NULL,
  `body` longtext,
  `attachments` tinyint(4) DEFAULT NULL,
  `anonymous` tinyint(4) DEFAULT NULL,
  `priority` double DEFAULT NULL,
  `allowPingbacks` tinyint(4) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `statusByUserId` bigint(20) DEFAULT NULL,
  `statusByUserName` varchar(75) DEFAULT NULL,
  `statusDate` datetime DEFAULT NULL,
  PRIMARY KEY (`messageId`),
  UNIQUE KEY `IX_8D12316E` (`uuid_`,`groupId`),
  KEY `IX_51A8D44D` (`classNameId`,`classPK`),
  KEY `IX_F6687633` (`classNameId`,`classPK`,`status`),
  KEY `IX_B1432D30` (`companyId`),
  KEY `IX_1AD93C16` (`companyId`,`status`),
  KEY `IX_5B153FB2` (`groupId`),
  KEY `IX_1073AB9F` (`groupId`,`categoryId`),
  KEY `IX_4257DB85` (`groupId`,`categoryId`,`status`),
  KEY `IX_B674AB58` (`groupId`,`categoryId`,`threadId`),
  KEY `IX_385E123E` (`groupId`,`categoryId`,`threadId`,`status`),
  KEY `IX_ED39AC98` (`groupId`,`status`),
  KEY `IX_8EB8C5EC` (`groupId`,`userId`),
  KEY `IX_377858D2` (`groupId`,`userId`,`status`),
  KEY `IX_75B95071` (`threadId`),
  KEY `IX_A7038CD7` (`threadId`,`parentMessageId`),
  KEY `IX_9DC8E57` (`threadId`,`status`),
  KEY `IX_7A040C32` (`userId`),
  KEY `IX_C57B16BC` (`uuid_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MBMessage`
--

LOCK TABLES `MBMessage` WRITE;
/*!40000 ALTER TABLE `MBMessage` DISABLE KEYS */;
INSERT INTO `MBMessage` VALUES ('6bcd8aa9-5fc5-4365-bb0f-3d9212e0f861',10153,10149,10132,10135,' ','2014-04-03 16:33:40','2014-04-03 16:33:40',10014,10152,-1,10154,10153,0,'10152','10152',0,1,0,0,0,10135,' ','2014-04-03 16:33:40'),('31d7906e-70ad-45c3-999d-f01a2b193cc1',10161,10157,10132,10135,' ','2014-04-03 16:33:40','2014-04-03 16:33:40',10014,10160,-1,10162,10161,0,'10160','10160',0,1,0,0,0,10135,' ','2014-04-03 16:33:40'),('b1a9c4b1-4ccb-4721-8075-cb548129355c',10321,10171,10132,10169,'Test Test','2014-04-03 16:38:59','2014-04-03 16:38:59',10014,10320,-1,10322,10321,0,'10320','10320',0,0,0,0,0,10169,'Test Test','2014-04-03 16:38:59'),('359a0f30-aef6-4b34-bbe9-3fdfd4800277',10326,10171,10132,10169,'Test Test','2014-04-03 16:38:59','2014-04-03 16:38:59',10014,10325,-1,10327,10326,0,'10325','10325',0,0,0,0,0,10169,'Test Test','2014-04-03 16:38:59'),('159f9a97-d6c2-470b-8b25-3963b05fc0ab',10334,10157,10132,10169,'Test Test','2014-04-03 16:39:07','2014-04-03 16:39:07',10014,10333,-1,10335,10334,0,'10333','10333',0,0,0,0,0,10169,'Test Test','2014-04-03 16:39:07'),('6097adb6-06f0-4515-ab33-da95f599006c',10348,10157,10132,10169,'Test Test','2014-04-03 16:39:31','2014-04-03 16:39:31',10123,10344,-1,10349,10348,0,'10344','10344',0,0,0,0,0,10169,'Test Test','2014-04-03 16:39:31'),('431deb30-6b52-4c89-b919-ef698f7541b7',10393,10388,10132,10169,'Test Test','2014-04-03 16:44:49','2014-04-03 16:44:49',10014,10392,-1,10394,10393,0,'10392','10392',0,0,0,0,0,10169,'Test Test','2014-04-03 16:44:49'),('e8f39f31-a179-4078-90f6-c7a328fefbd8',10405,10388,10132,10169,'Test Test','2014-04-03 16:44:56','2014-04-03 16:44:56',10129,10403,-1,10406,10405,0,'10403','10403',0,0,0,0,0,10169,'Test Test','2014-04-03 16:44:56'),('c06516ec-ad86-4c12-9e60-2b41ede2c8d8',10425,10157,10132,10169,'Test Test','2014-04-03 16:46:47','2014-04-03 16:46:47',10014,10424,-1,10426,10425,0,'10424','10424',0,0,0,0,0,10169,'Test Test','2014-04-03 16:46:47'),('03f4a894-af2c-42e6-a91c-f0f487f3c052',10440,10435,10132,10169,'Test Test','2014-04-03 16:47:40','2014-04-03 16:47:40',10014,10439,-1,10441,10440,0,'10439','10439',0,0,0,0,0,10169,'Test Test','2014-04-03 16:47:40'),('b59c76b7-d1f2-42f7-ba3f-be68a56ea6f4',10463,10435,10132,10169,'Test Test','2014-04-03 16:48:49','2014-04-03 16:48:49',10084,10459,-1,10464,10463,0,'10459','10459',0,0,0,0,0,10169,'Test Test','2014-04-03 16:48:49'),('88a16cf5-9f9c-4f89-acea-ccd2e6c9e4c0',10486,10481,10132,10169,'Test Test','2014-04-03 16:49:56','2014-04-03 16:49:56',10014,10485,-1,10487,10486,0,'10485','10485',0,0,0,0,0,10169,'Test Test','2014-04-03 16:49:56'),('780cb8a7-9853-4bf3-8ef4-706f542859dd',10527,10523,10132,10169,'Test Test','2014-04-03 16:50:44','2014-04-03 16:50:44',10014,10526,-1,10528,10527,0,'10526','10526',0,0,0,0,0,10169,'Test Test','2014-04-03 16:50:44'),('599681f6-32d1-47c0-bd2f-7cde956ea45a',10537,10533,10132,10169,'Test Test','2014-04-03 16:51:07','2014-04-03 16:51:07',10014,10536,-1,10538,10537,0,'10536','10536',0,0,0,0,0,10169,'Test Test','2014-04-03 16:51:07'),('53f5f756-07dd-4cb2-89ec-d3c58446947e',10553,10545,10132,10543,'userPPfn userPPln','2014-04-03 16:52:04','2014-04-03 16:52:04',10014,10552,-1,10554,10553,0,'10552','10552',0,0,0,0,0,10543,'userPPfn userPPln','2014-04-03 16:52:04'),('30113060-ef28-47df-8139-a2f85561b503',10558,10545,10132,10543,'userPPfn userPPln','2014-04-03 16:52:04','2014-04-03 16:52:04',10014,10557,-1,10559,10558,0,'10557','10557',0,0,0,0,0,10543,'userPPfn userPPln','2014-04-03 16:52:04'),('902129c5-fbd9-4360-9d0b-1d5a39720bcb',10567,10157,10132,10169,'Test Test','2014-04-03 16:53:42','2014-04-03 16:53:42',10014,10566,-1,10568,10567,0,'10566','10566',0,0,0,0,0,10169,'Test Test','2014-04-03 16:53:42'),('aa5289f9-69f0-48ad-aad5-096e5c4753c7',10599,10591,10132,10589,'userSMfn userSMln','2014-04-03 16:56:22','2014-04-03 16:56:22',10014,10598,-1,10600,10599,0,'10598','10598',0,0,0,0,0,10589,'userSMfn userSMln','2014-04-03 16:56:22'),('f8df72bf-f267-44f9-a984-ceff66022870',10604,10591,10132,10589,'userSMfn userSMln','2014-04-03 16:56:22','2014-04-03 16:56:22',10014,10603,-1,10605,10604,0,'10603','10603',0,0,0,0,0,10589,'userSMfn userSMln','2014-04-03 16:56:22'),('c46c4e47-2509-4218-a185-0141130415d9',10622,10617,10132,10169,'Test Test','2014-04-03 16:57:29','2014-04-03 16:57:29',10014,10621,-1,10623,10622,0,'10621','10621',0,0,0,0,0,10169,'Test Test','2014-04-03 16:57:29'),('3cda30fd-b1cd-4758-bcb9-cb19585bc16e',10647,10626,10132,10169,'Test Test','2014-04-03 16:58:12','2014-04-03 16:58:12',0,0,0,10648,10647,0,'MB Thread Message Subject','MB Thread Message Body',0,0,0,1,0,10169,'Test Test','2014-04-03 16:58:13'),('43144695-c22d-4306-8b5b-b553f2358ffb',10652,10157,10132,10169,'Test Test','2014-04-03 16:58:33','2014-04-03 16:58:33',10014,10651,-1,10653,10652,0,'10651','10651',0,0,0,0,0,10169,'Test Test','2014-04-03 16:58:33'),('92b1fb10-a551-4470-8247-71eb825feb41',10668,10663,10132,10169,'Test Test','2014-04-03 16:59:29','2014-04-03 16:59:29',10014,10667,-1,10669,10668,0,'10667','10667',0,0,0,0,0,10169,'Test Test','2014-04-03 16:59:29'),('aebf3eb5-d0fe-49e2-8856-2f97db090e65',10683,10678,10132,10169,'Test Test','2014-04-03 17:00:30','2014-04-03 17:00:30',10014,10682,-1,10684,10683,0,'10682','10682',0,0,0,0,0,10169,'Test Test','2014-04-03 17:00:30'),('f444d5a8-ff0c-4569-a17c-6343a08172e4',10694,10678,10132,10169,'Test Test','2014-04-03 17:00:43','2014-04-03 17:00:43',10073,10691,-1,10695,10694,0,'10691','10691',0,0,0,0,0,10169,'Test Test','2014-04-03 17:00:43'),('395a0c14-b579-4aca-91a0-a32431675a8c',10714,10157,10132,10169,'Test Test','2014-04-03 17:03:52','2014-04-03 17:03:52',10014,10713,-1,10715,10714,0,'10713','10713',0,0,0,0,0,10169,'Test Test','2014-04-03 17:03:52'),('159fd4aa-87d1-4bdd-8967-12133751c8ef',10726,10157,10132,10169,'Test Test','2014-04-03 17:04:30','2014-04-03 17:04:30',10014,10725,-1,10727,10726,0,'10725','10725',0,0,0,0,0,10169,'Test Test','2014-04-03 17:04:30'),('72e7d8e1-0c8c-4003-ab67-7c685bbefc5b',10757,10752,10132,10169,'Test Test','2014-04-03 17:06:16','2014-04-03 17:06:16',10014,10756,-1,10758,10757,0,'10756','10756',0,0,0,0,0,10169,'Test Test','2014-04-03 17:06:16');
/*!40000 ALTER TABLE `MBMessage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MBMessageFlag`
--

DROP TABLE IF EXISTS `MBMessageFlag`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `MBMessageFlag` (
  `messageFlagId` bigint(20) NOT NULL,
  `userId` bigint(20) DEFAULT NULL,
  `modifiedDate` datetime DEFAULT NULL,
  `threadId` bigint(20) DEFAULT NULL,
  `messageId` bigint(20) DEFAULT NULL,
  `flag` int(11) DEFAULT NULL,
  PRIMARY KEY (`messageFlagId`),
  UNIQUE KEY `IX_E9EB6194` (`userId`,`messageId`,`flag`),
  KEY `IX_D180D4AE` (`messageId`),
  KEY `IX_A6973A8E` (`messageId`,`flag`),
  KEY `IX_C1C9A8FD` (`threadId`),
  KEY `IX_3CFD579D` (`threadId`,`flag`),
  KEY `IX_7B2917BE` (`userId`),
  KEY `IX_2EA537D7` (`userId`,`threadId`,`flag`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MBMessageFlag`
--

LOCK TABLES `MBMessageFlag` WRITE;
/*!40000 ALTER TABLE `MBMessageFlag` DISABLE KEYS */;
/*!40000 ALTER TABLE `MBMessageFlag` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MBStatsUser`
--

DROP TABLE IF EXISTS `MBStatsUser`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `MBStatsUser` (
  `statsUserId` bigint(20) NOT NULL,
  `groupId` bigint(20) DEFAULT NULL,
  `userId` bigint(20) DEFAULT NULL,
  `messageCount` int(11) DEFAULT NULL,
  `lastPostDate` datetime DEFAULT NULL,
  PRIMARY KEY (`statsUserId`),
  UNIQUE KEY `IX_9168E2C9` (`groupId`,`userId`),
  KEY `IX_A00A898F` (`groupId`),
  KEY `IX_FAB5A88B` (`groupId`,`messageCount`),
  KEY `IX_847F92B5` (`userId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MBStatsUser`
--

LOCK TABLES `MBStatsUser` WRITE;
/*!40000 ALTER TABLE `MBStatsUser` DISABLE KEYS */;
INSERT INTO `MBStatsUser` VALUES (10650,10626,10169,1,'2014-04-03 16:58:13');
/*!40000 ALTER TABLE `MBStatsUser` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MBThread`
--

DROP TABLE IF EXISTS `MBThread`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `MBThread` (
  `threadId` bigint(20) NOT NULL,
  `groupId` bigint(20) DEFAULT NULL,
  `categoryId` bigint(20) DEFAULT NULL,
  `rootMessageId` bigint(20) DEFAULT NULL,
  `messageCount` int(11) DEFAULT NULL,
  `viewCount` int(11) DEFAULT NULL,
  `lastPostByUserId` bigint(20) DEFAULT NULL,
  `lastPostDate` datetime DEFAULT NULL,
  `priority` double DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `statusByUserId` bigint(20) DEFAULT NULL,
  `statusByUserName` varchar(75) DEFAULT NULL,
  `statusDate` datetime DEFAULT NULL,
  PRIMARY KEY (`threadId`),
  KEY `IX_41F6DC8A` (`categoryId`,`priority`),
  KEY `IX_95C0EA45` (`groupId`),
  KEY `IX_9A2D11B2` (`groupId`,`categoryId`),
  KEY `IX_50F1904A` (`groupId`,`categoryId`,`lastPostDate`),
  KEY `IX_485F7E98` (`groupId`,`categoryId`,`status`),
  KEY `IX_E1E7142B` (`groupId`,`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MBThread`
--

LOCK TABLES `MBThread` WRITE;
/*!40000 ALTER TABLE `MBThread` DISABLE KEYS */;
INSERT INTO `MBThread` VALUES (10154,10149,-1,10153,1,0,0,'2014-04-03 16:33:40',0,0,10135,' ','2014-04-03 16:33:40'),(10162,10157,-1,10161,1,0,0,'2014-04-03 16:33:40',0,0,10135,' ','2014-04-03 16:33:40'),(10322,10171,-1,10321,1,0,10169,'2014-04-03 16:38:59',0,0,10169,'Test Test','2014-04-03 16:38:59'),(10327,10171,-1,10326,1,0,10169,'2014-04-03 16:38:59',0,0,10169,'Test Test','2014-04-03 16:38:59'),(10335,10157,-1,10334,1,0,10169,'2014-04-03 16:39:07',0,0,10169,'Test Test','2014-04-03 16:39:07'),(10349,10157,-1,10348,1,0,10169,'2014-04-03 16:39:31',0,0,10169,'Test Test','2014-04-03 16:39:31'),(10394,10388,-1,10393,1,0,10169,'2014-04-03 16:44:49',0,0,10169,'Test Test','2014-04-03 16:44:49'),(10406,10388,-1,10405,1,0,10169,'2014-04-03 16:44:56',0,0,10169,'Test Test','2014-04-03 16:44:56'),(10426,10157,-1,10425,1,0,10169,'2014-04-03 16:46:47',0,0,10169,'Test Test','2014-04-03 16:46:47'),(10441,10435,-1,10440,1,0,10169,'2014-04-03 16:47:40',0,0,10169,'Test Test','2014-04-03 16:47:40'),(10464,10435,-1,10463,1,0,10169,'2014-04-03 16:48:49',0,0,10169,'Test Test','2014-04-03 16:48:49'),(10487,10481,-1,10486,1,0,10169,'2014-04-03 16:49:56',0,0,10169,'Test Test','2014-04-03 16:49:56'),(10528,10523,-1,10527,1,0,10169,'2014-04-03 16:50:44',0,0,10169,'Test Test','2014-04-03 16:50:44'),(10538,10533,-1,10537,1,0,10169,'2014-04-03 16:51:07',0,0,10169,'Test Test','2014-04-03 16:51:07'),(10554,10545,-1,10553,1,0,10543,'2014-04-03 16:52:04',0,0,10543,'userPPfn userPPln','2014-04-03 16:52:04'),(10559,10545,-1,10558,1,0,10543,'2014-04-03 16:52:04',0,0,10543,'userPPfn userPPln','2014-04-03 16:52:04'),(10568,10157,-1,10567,1,0,10169,'2014-04-03 16:53:42',0,0,10169,'Test Test','2014-04-03 16:53:42'),(10600,10591,-1,10599,1,0,10589,'2014-04-03 16:56:22',0,0,10589,'userSMfn userSMln','2014-04-03 16:56:22'),(10605,10591,-1,10604,1,0,10589,'2014-04-03 16:56:22',0,0,10589,'userSMfn userSMln','2014-04-03 16:56:22'),(10623,10617,-1,10622,1,0,10169,'2014-04-03 16:57:29',0,0,10169,'Test Test','2014-04-03 16:57:29'),(10648,10626,0,10647,1,0,10169,'2014-04-03 16:58:13',0,0,10169,'Test Test','2014-04-03 16:58:13'),(10653,10157,-1,10652,1,0,10169,'2014-04-03 16:58:33',0,0,10169,'Test Test','2014-04-03 16:58:33'),(10669,10663,-1,10668,1,0,10169,'2014-04-03 16:59:29',0,0,10169,'Test Test','2014-04-03 16:59:29'),(10684,10678,-1,10683,1,0,10169,'2014-04-03 17:00:30',0,0,10169,'Test Test','2014-04-03 17:00:30'),(10695,10678,-1,10694,1,0,10169,'2014-04-03 17:00:43',0,0,10169,'Test Test','2014-04-03 17:00:43'),(10715,10157,-1,10714,1,0,10169,'2014-04-03 17:03:52',0,0,10169,'Test Test','2014-04-03 17:03:52'),(10727,10157,-1,10726,1,0,10169,'2014-04-03 17:04:30',0,0,10169,'Test Test','2014-04-03 17:04:30'),(10758,10752,-1,10757,1,0,10169,'2014-04-03 17:06:16',0,0,10169,'Test Test','2014-04-03 17:06:16');
/*!40000 ALTER TABLE `MBThread` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MembershipRequest`
--

DROP TABLE IF EXISTS `MembershipRequest`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `MembershipRequest` (
  `membershipRequestId` bigint(20) NOT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `userId` bigint(20) DEFAULT NULL,
  `createDate` datetime DEFAULT NULL,
  `groupId` bigint(20) DEFAULT NULL,
  `comments` longtext,
  `replyComments` longtext,
  `replyDate` datetime DEFAULT NULL,
  `replierUserId` bigint(20) DEFAULT NULL,
  `statusId` int(11) DEFAULT NULL,
  PRIMARY KEY (`membershipRequestId`),
  KEY `IX_8A1CC4B` (`groupId`),
  KEY `IX_C28C72EC` (`groupId`,`statusId`),
  KEY `IX_66D70879` (`userId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MembershipRequest`
--

LOCK TABLES `MembershipRequest` WRITE;
/*!40000 ALTER TABLE `MembershipRequest` DISABLE KEYS */;
INSERT INTO `MembershipRequest` VALUES (10616,10132,10589,'2014-04-03 16:56:50',10585,'Request Membership Comment','',NULL,0,0);
/*!40000 ALTER TABLE `MembershipRequest` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `OrgGroupPermission`
--

DROP TABLE IF EXISTS `OrgGroupPermission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `OrgGroupPermission` (
  `organizationId` bigint(20) NOT NULL,
  `groupId` bigint(20) NOT NULL,
  `permissionId` bigint(20) NOT NULL,
  PRIMARY KEY (`organizationId`,`groupId`,`permissionId`),
  KEY `IX_A425F71A` (`groupId`),
  KEY `IX_6C53DA4E` (`permissionId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `OrgGroupPermission`
--

LOCK TABLES `OrgGroupPermission` WRITE;
/*!40000 ALTER TABLE `OrgGroupPermission` DISABLE KEYS */;
/*!40000 ALTER TABLE `OrgGroupPermission` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `OrgGroupRole`
--

DROP TABLE IF EXISTS `OrgGroupRole`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `OrgGroupRole` (
  `organizationId` bigint(20) NOT NULL,
  `groupId` bigint(20) NOT NULL,
  `roleId` bigint(20) NOT NULL,
  PRIMARY KEY (`organizationId`,`groupId`,`roleId`),
  KEY `IX_4A527DD3` (`groupId`),
  KEY `IX_AB044D1C` (`roleId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `OrgGroupRole`
--

LOCK TABLES `OrgGroupRole` WRITE;
/*!40000 ALTER TABLE `OrgGroupRole` DISABLE KEYS */;
/*!40000 ALTER TABLE `OrgGroupRole` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `OrgLabor`
--

DROP TABLE IF EXISTS `OrgLabor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `OrgLabor` (
  `orgLaborId` bigint(20) NOT NULL,
  `organizationId` bigint(20) DEFAULT NULL,
  `typeId` int(11) DEFAULT NULL,
  `sunOpen` int(11) DEFAULT NULL,
  `sunClose` int(11) DEFAULT NULL,
  `monOpen` int(11) DEFAULT NULL,
  `monClose` int(11) DEFAULT NULL,
  `tueOpen` int(11) DEFAULT NULL,
  `tueClose` int(11) DEFAULT NULL,
  `wedOpen` int(11) DEFAULT NULL,
  `wedClose` int(11) DEFAULT NULL,
  `thuOpen` int(11) DEFAULT NULL,
  `thuClose` int(11) DEFAULT NULL,
  `friOpen` int(11) DEFAULT NULL,
  `friClose` int(11) DEFAULT NULL,
  `satOpen` int(11) DEFAULT NULL,
  `satClose` int(11) DEFAULT NULL,
  PRIMARY KEY (`orgLaborId`),
  KEY `IX_6AF0D434` (`organizationId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `OrgLabor`
--

LOCK TABLES `OrgLabor` WRITE;
/*!40000 ALTER TABLE `OrgLabor` DISABLE KEYS */;
/*!40000 ALTER TABLE `OrgLabor` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Organization_`
--

DROP TABLE IF EXISTS `Organization_`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Organization_` (
  `organizationId` bigint(20) NOT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `parentOrganizationId` bigint(20) DEFAULT NULL,
  `leftOrganizationId` bigint(20) DEFAULT NULL,
  `rightOrganizationId` bigint(20) DEFAULT NULL,
  `name` varchar(100) DEFAULT NULL,
  `type_` varchar(75) DEFAULT NULL,
  `recursable` tinyint(4) DEFAULT NULL,
  `regionId` bigint(20) DEFAULT NULL,
  `countryId` bigint(20) DEFAULT NULL,
  `statusId` int(11) DEFAULT NULL,
  `comments` longtext,
  PRIMARY KEY (`organizationId`),
  UNIQUE KEY `IX_E301BDF5` (`companyId`,`name`),
  KEY `IX_834BCEB6` (`companyId`),
  KEY `IX_418E4522` (`companyId`,`parentOrganizationId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Organization_`
--

LOCK TABLES `Organization_` WRITE;
/*!40000 ALTER TABLE `Organization_` DISABLE KEYS */;
INSERT INTO `Organization_` VALUES (10375,10132,0,2,3,'Organization Name','regular-organization',1,0,0,12017,'');
/*!40000 ALTER TABLE `Organization_` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PasswordPolicy`
--

DROP TABLE IF EXISTS `PasswordPolicy`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `PasswordPolicy` (
  `passwordPolicyId` bigint(20) NOT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `userId` bigint(20) DEFAULT NULL,
  `userName` varchar(75) DEFAULT NULL,
  `createDate` datetime DEFAULT NULL,
  `modifiedDate` datetime DEFAULT NULL,
  `defaultPolicy` tinyint(4) DEFAULT NULL,
  `name` varchar(75) DEFAULT NULL,
  `description` longtext,
  `changeable` tinyint(4) DEFAULT NULL,
  `changeRequired` tinyint(4) DEFAULT NULL,
  `minAge` bigint(20) DEFAULT NULL,
  `checkSyntax` tinyint(4) DEFAULT NULL,
  `allowDictionaryWords` tinyint(4) DEFAULT NULL,
  `minAlphanumeric` int(11) DEFAULT NULL,
  `minLength` int(11) DEFAULT NULL,
  `minLowerCase` int(11) DEFAULT NULL,
  `minNumbers` int(11) DEFAULT NULL,
  `minSymbols` int(11) DEFAULT NULL,
  `minUpperCase` int(11) DEFAULT NULL,
  `history` tinyint(4) DEFAULT NULL,
  `historyCount` int(11) DEFAULT NULL,
  `expireable` tinyint(4) DEFAULT NULL,
  `maxAge` bigint(20) DEFAULT NULL,
  `warningTime` bigint(20) DEFAULT NULL,
  `graceLimit` int(11) DEFAULT NULL,
  `lockout` tinyint(4) DEFAULT NULL,
  `maxFailure` int(11) DEFAULT NULL,
  `lockoutDuration` bigint(20) DEFAULT NULL,
  `requireUnlock` tinyint(4) DEFAULT NULL,
  `resetFailureCount` bigint(20) DEFAULT NULL,
  `resetTicketMaxAge` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`passwordPolicyId`),
  UNIQUE KEY `IX_3FBFA9F4` (`companyId`,`name`),
  KEY `IX_2C1142E` (`companyId`,`defaultPolicy`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PasswordPolicy`
--

LOCK TABLES `PasswordPolicy` WRITE;
/*!40000 ALTER TABLE `PasswordPolicy` DISABLE KEYS */;
INSERT INTO `PasswordPolicy` VALUES (10168,10132,10135,' ','2014-04-03 16:33:40','2014-04-03 16:33:40',1,'Default Password Policy','Default Password Policy',1,0,0,0,1,0,6,0,1,0,1,0,6,0,8640000,86400,0,0,3,0,1,600,86400),(10542,10132,10169,'Test Test','2014-04-03 16:51:31','2014-04-03 16:51:35',0,'Password Policy Name','Password Policy Description',1,0,0,0,0,0,0,0,0,0,0,1,2,0,1209600,43200,0,0,0,0,1,300,0);
/*!40000 ALTER TABLE `PasswordPolicy` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PasswordPolicyRel`
--

DROP TABLE IF EXISTS `PasswordPolicyRel`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `PasswordPolicyRel` (
  `passwordPolicyRelId` bigint(20) NOT NULL,
  `passwordPolicyId` bigint(20) DEFAULT NULL,
  `classNameId` bigint(20) DEFAULT NULL,
  `classPK` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`passwordPolicyRelId`),
  KEY `IX_C3A17327` (`classNameId`,`classPK`),
  KEY `IX_CD25266E` (`passwordPolicyId`),
  KEY `IX_ED7CF243` (`passwordPolicyId`,`classNameId`,`classPK`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PasswordPolicyRel`
--

LOCK TABLES `PasswordPolicyRel` WRITE;
/*!40000 ALTER TABLE `PasswordPolicyRel` DISABLE KEYS */;
INSERT INTO `PasswordPolicyRel` VALUES (10563,10542,10046,10543);
/*!40000 ALTER TABLE `PasswordPolicyRel` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PasswordTracker`
--

DROP TABLE IF EXISTS `PasswordTracker`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `PasswordTracker` (
  `passwordTrackerId` bigint(20) NOT NULL,
  `userId` bigint(20) DEFAULT NULL,
  `createDate` datetime DEFAULT NULL,
  `password_` varchar(75) DEFAULT NULL,
  PRIMARY KEY (`passwordTrackerId`),
  KEY `IX_326F75BD` (`userId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PasswordTracker`
--

LOCK TABLES `PasswordTracker` WRITE;
/*!40000 ALTER TABLE `PasswordTracker` DISABLE KEYS */;
INSERT INTO `PasswordTracker` VALUES (10564,10543,'2014-04-03 16:52:34','W6ph5Mm5Pz8GgiULbPgzG37mj9g=');
/*!40000 ALTER TABLE `PasswordTracker` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Permission_`
--

DROP TABLE IF EXISTS `Permission_`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Permission_` (
  `permissionId` bigint(20) NOT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `actionId` varchar(75) DEFAULT NULL,
  `resourceId` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`permissionId`),
  UNIQUE KEY `IX_4D19C2B8` (`actionId`,`resourceId`),
  KEY `IX_F090C113` (`resourceId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Permission_`
--

LOCK TABLES `Permission_` WRITE;
/*!40000 ALTER TABLE `Permission_` DISABLE KEYS */;
/*!40000 ALTER TABLE `Permission_` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Phone`
--

DROP TABLE IF EXISTS `Phone`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Phone` (
  `phoneId` bigint(20) NOT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `userId` bigint(20) DEFAULT NULL,
  `userName` varchar(75) DEFAULT NULL,
  `createDate` datetime DEFAULT NULL,
  `modifiedDate` datetime DEFAULT NULL,
  `classNameId` bigint(20) DEFAULT NULL,
  `classPK` bigint(20) DEFAULT NULL,
  `number_` varchar(75) DEFAULT NULL,
  `extension` varchar(75) DEFAULT NULL,
  `typeId` int(11) DEFAULT NULL,
  `primary_` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`phoneId`),
  KEY `IX_9F704A14` (`companyId`),
  KEY `IX_A2E4AFBA` (`companyId`,`classNameId`),
  KEY `IX_9A53569` (`companyId`,`classNameId`,`classPK`),
  KEY `IX_812CE07A` (`companyId`,`classNameId`,`classPK`,`primary_`),
  KEY `IX_F202B9CE` (`userId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Phone`
--

LOCK TABLES `Phone` WRITE;
/*!40000 ALTER TABLE `Phone` DISABLE KEYS */;
INSERT INTO `Phone` VALUES (10771,10132,10169,'Test Test','2014-04-03 17:07:18','2014-04-03 17:07:24',10009,10170,'1231231234','123',11006,1);
/*!40000 ALTER TABLE `Phone` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PluginSetting`
--

DROP TABLE IF EXISTS `PluginSetting`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `PluginSetting` (
  `pluginSettingId` bigint(20) NOT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `pluginId` varchar(75) DEFAULT NULL,
  `pluginType` varchar(75) DEFAULT NULL,
  `roles` longtext,
  `active_` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`pluginSettingId`),
  UNIQUE KEY `IX_7171B2E8` (`companyId`,`pluginId`,`pluginType`),
  KEY `IX_B9746445` (`companyId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PluginSetting`
--

LOCK TABLES `PluginSetting` WRITE;
/*!40000 ALTER TABLE `PluginSetting` DISABLE KEYS */;
INSERT INTO `PluginSetting` VALUES (10712,10132,'classic','theme','User',1);
/*!40000 ALTER TABLE `PluginSetting` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PollsChoice`
--

DROP TABLE IF EXISTS `PollsChoice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `PollsChoice` (
  `uuid_` varchar(75) DEFAULT NULL,
  `choiceId` bigint(20) NOT NULL,
  `questionId` bigint(20) DEFAULT NULL,
  `name` varchar(75) DEFAULT NULL,
  `description` longtext,
  PRIMARY KEY (`choiceId`),
  UNIQUE KEY `IX_D76DD2CF` (`questionId`,`name`),
  KEY `IX_EC370F10` (`questionId`),
  KEY `IX_6660B399` (`uuid_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PollsChoice`
--

LOCK TABLES `PollsChoice` WRITE;
/*!40000 ALTER TABLE `PollsChoice` DISABLE KEYS */;
INSERT INTO `PollsChoice` VALUES ('0fd1cd29-16b7-4cc7-b867-5764bdf45c74',10422,10421,'a','<?xml version=\'1.0\' encoding=\'UTF-8\'?><root available-locales=\"en_US\" default-locale=\"en_US\"><Description language-id=\"en_US\">Choice A</Description></root>'),('06a8f54a-3e94-433f-875d-cabd7845444e',10423,10421,'b','<?xml version=\'1.0\' encoding=\'UTF-8\'?><root available-locales=\"en_US\" default-locale=\"en_US\"><Description language-id=\"en_US\">Choice B</Description></root>');
/*!40000 ALTER TABLE `PollsChoice` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PollsQuestion`
--

DROP TABLE IF EXISTS `PollsQuestion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `PollsQuestion` (
  `uuid_` varchar(75) DEFAULT NULL,
  `questionId` bigint(20) NOT NULL,
  `groupId` bigint(20) DEFAULT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `userId` bigint(20) DEFAULT NULL,
  `userName` varchar(75) DEFAULT NULL,
  `createDate` datetime DEFAULT NULL,
  `modifiedDate` datetime DEFAULT NULL,
  `title` longtext,
  `description` longtext,
  `expirationDate` datetime DEFAULT NULL,
  `lastVoteDate` datetime DEFAULT NULL,
  PRIMARY KEY (`questionId`),
  UNIQUE KEY `IX_F3C9F36` (`uuid_`,`groupId`),
  KEY `IX_9FF342EA` (`groupId`),
  KEY `IX_51F087F4` (`uuid_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PollsQuestion`
--

LOCK TABLES `PollsQuestion` WRITE;
/*!40000 ALTER TABLE `PollsQuestion` DISABLE KEYS */;
INSERT INTO `PollsQuestion` VALUES ('9f043034-1a56-4299-a1af-e13a503f86f7',10421,10157,10132,10169,'Test Test','2014-04-03 16:46:41','2014-04-03 16:46:41','<?xml version=\'1.0\' encoding=\'UTF-8\'?><root available-locales=\"en_US\" default-locale=\"en_US\"><Title language-id=\"en_US\">Polls Title</Title></root>','<?xml version=\'1.0\' encoding=\'UTF-8\'?><root available-locales=\"en_US\" default-locale=\"en_US\"><Description language-id=\"en_US\">Polls Question</Description></root>',NULL,'2014-04-03 16:47:07');
/*!40000 ALTER TABLE `PollsQuestion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PollsVote`
--

DROP TABLE IF EXISTS `PollsVote`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `PollsVote` (
  `voteId` bigint(20) NOT NULL,
  `userId` bigint(20) DEFAULT NULL,
  `questionId` bigint(20) DEFAULT NULL,
  `choiceId` bigint(20) DEFAULT NULL,
  `voteDate` datetime DEFAULT NULL,
  PRIMARY KEY (`voteId`),
  UNIQUE KEY `IX_1BBFD4D3` (`questionId`,`userId`),
  KEY `IX_D5DF7B54` (`choiceId`),
  KEY `IX_12112599` (`questionId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PollsVote`
--

LOCK TABLES `PollsVote` WRITE;
/*!40000 ALTER TABLE `PollsVote` DISABLE KEYS */;
INSERT INTO `PollsVote` VALUES (10434,10169,10421,10422,'2014-04-03 16:47:07');
/*!40000 ALTER TABLE `PollsVote` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Portlet`
--

DROP TABLE IF EXISTS `Portlet`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Portlet` (
  `id_` bigint(20) NOT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `portletId` varchar(200) DEFAULT NULL,
  `roles` longtext,
  `active_` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`id_`),
  UNIQUE KEY `IX_12B5E51D` (`companyId`,`portletId`),
  KEY `IX_80CC9508` (`companyId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Portlet`
--

LOCK TABLES `Portlet` WRITE;
/*!40000 ALTER TABLE `Portlet` DISABLE KEYS */;
INSERT INTO `Portlet` VALUES (10175,10132,'98','',1),(10176,10132,'66','',1),(10177,10132,'27','',1),(10178,10132,'152','',1),(10179,10132,'134','',1),(10180,10132,'130','',1),(10181,10132,'122','',1),(10182,10132,'36','',1),(10183,10132,'26','',1),(10184,10132,'104','',1),(10185,10132,'153','',1),(10186,10132,'64','',1),(10187,10132,'129','',1),(10188,10132,'100','',1),(10189,10132,'19','',1),(10190,10132,'157','',1),(10191,10132,'128','',1),(10192,10132,'154','',1),(10193,10132,'148','',1),(10194,10132,'11','',1),(10195,10132,'29','',1),(10196,10132,'158','',1),(10197,10132,'8','',1),(10198,10132,'58','',1),(10199,10132,'155','',1),(10200,10132,'71','',1),(10201,10132,'97','',1),(10202,10132,'39','',1),(10203,10132,'85','',1),(10204,10132,'118','',1),(10205,10132,'79','',1),(10206,10132,'107','',1),(10207,10132,'30','',1),(10208,10132,'147','',1),(10209,10132,'48','',1),(10210,10132,'125','',1),(10211,10132,'146','',1),(10212,10132,'62','',1),(10213,10132,'159','',1),(10214,10132,'108','',1),(10215,10132,'84','',1),(10216,10132,'101','',1),(10217,10132,'121','',1),(10218,10132,'37','',1),(10219,10132,'143','',1),(10220,10132,'77','',1),(10221,10132,'115','',1),(10222,10132,'56','',1),(10223,10132,'16','',1),(10224,10132,'111','',1),(10225,10132,'3','',1),(10226,10132,'23','',1),(10227,10132,'20','',1),(10228,10132,'83','',1),(10229,10132,'99','',1),(10230,10132,'70','',1),(10231,10132,'141','',1),(10232,10132,'9','',1),(10233,10132,'28','',1),(10234,10132,'137','',1),(10235,10132,'47','',1),(10236,10132,'15','',1),(10237,10132,'116','',1),(10238,10132,'82','',1),(10239,10132,'151','',1),(10240,10132,'54','',1),(10241,10132,'132','',1),(10242,10132,'34','',1),(10243,10132,'61','',1),(10244,10132,'73','',1),(10245,10132,'31','',1),(10246,10132,'136','',1),(10247,10132,'50','',1),(10248,10132,'127','',1),(10249,10132,'25','',1),(10250,10132,'33','',1),(10251,10132,'150','',1),(10252,10132,'126','',1),(10253,10132,'114','',1),(10254,10132,'149','',1),(10255,10132,'67','',1),(10256,10132,'110','',1),(10257,10132,'59','',1),(10258,10132,'135','',1),(10259,10132,'131','',1),(10260,10132,'102','',1),(10308,10132,'6_WAR_socialnetworkingportlet','',1),(10309,10132,'1_WAR_socialnetworkingportlet','',1),(10310,10132,'3_WAR_socialnetworkingportlet','',1),(10311,10132,'7_WAR_socialnetworkingportlet','',1),(10312,10132,'8_WAR_socialnetworkingportlet','',1),(10313,10132,'4_WAR_socialnetworkingportlet','',1),(10314,10132,'2_WAR_socialnetworkingportlet','',1),(10315,10132,'5_WAR_socialnetworkingportlet','',1);
/*!40000 ALTER TABLE `Portlet` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PortletItem`
--

DROP TABLE IF EXISTS `PortletItem`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `PortletItem` (
  `portletItemId` bigint(20) NOT NULL,
  `groupId` bigint(20) DEFAULT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `userId` bigint(20) DEFAULT NULL,
  `userName` varchar(75) DEFAULT NULL,
  `createDate` datetime DEFAULT NULL,
  `modifiedDate` datetime DEFAULT NULL,
  `name` varchar(75) DEFAULT NULL,
  `portletId` varchar(75) DEFAULT NULL,
  `classNameId` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`portletItemId`),
  KEY `IX_96BDD537` (`groupId`,`classNameId`),
  KEY `IX_D699243F` (`groupId`,`name`,`portletId`,`classNameId`),
  KEY `IX_2C61314E` (`groupId`,`portletId`),
  KEY `IX_E922D6C0` (`groupId`,`portletId`,`classNameId`),
  KEY `IX_8E71167F` (`groupId`,`portletId`,`classNameId`,`name`),
  KEY `IX_33B8CE8D` (`groupId`,`portletId`,`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PortletItem`
--

LOCK TABLES `PortletItem` WRITE;
/*!40000 ALTER TABLE `PortletItem` DISABLE KEYS */;
/*!40000 ALTER TABLE `PortletItem` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PortletPreferences`
--

DROP TABLE IF EXISTS `PortletPreferences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `PortletPreferences` (
  `portletPreferencesId` bigint(20) NOT NULL,
  `ownerId` bigint(20) DEFAULT NULL,
  `ownerType` int(11) DEFAULT NULL,
  `plid` bigint(20) DEFAULT NULL,
  `portletId` varchar(200) DEFAULT NULL,
  `preferences` longtext,
  PRIMARY KEY (`portletPreferencesId`),
  UNIQUE KEY `IX_C7057FF7` (`ownerId`,`ownerType`,`plid`,`portletId`),
  KEY `IX_E4F13E6E` (`ownerId`,`ownerType`,`plid`),
  KEY `IX_F15C1C4F` (`plid`),
  KEY `IX_D340DB76` (`plid`,`portletId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PortletPreferences`
--

LOCK TABLES `PortletPreferences` WRITE;
/*!40000 ALTER TABLE `PortletPreferences` DISABLE KEYS */;
INSERT INTO `PortletPreferences` VALUES (10131,0,1,0,'LIFERAY_PORTAL','<portlet-preferences />'),(10137,10132,1,0,'LIFERAY_PORTAL','<portlet-preferences />'),(10316,0,3,10160,'103','<portlet-preferences />'),(10317,0,3,10160,'47','<portlet-preferences />'),(10318,0,3,10160,'58','<portlet-preferences />'),(10319,10135,4,0,'LIFERAY_PORTAL','<portlet-preferences />'),(10330,10169,4,0,'LIFERAY_PORTAL','<portlet-preferences><preference><name>com.liferay.portal.util.SessionClicks#journalCategorizationPanel</name><value>open</value></preference><preference><name>79#user-groups-order-by-col</name><value>name</value></preference><preference><name>com.liferay.portal.util.SessionClicks#show-portlet-description-33</name><value>false</value></preference><preference><name>79#user-groups-order-by-type</name><value>asc</value></preference><preference><name>79#users-order-by-type</name><value>asc</value></preference><preference><name>com.liferay.portal.util.SessionClicks#show-portlet-description-15</name><value>false</value></preference><preference><name>com.liferay.portal.util.SessionClicks#show-portlet-description-8</name><value>false</value></preference><preference><name>com.liferay.portal.util.SessionClicks#show-portlet-description-134</name><value>false</value></preference><preference><name>com.liferay.portal.util.SessionClicks#show-portlet-description-154</name><value>false</value></preference><preference><name>79#users-order-by-col</name><value>last-name</value></preference><preference><name>com.liferay.portal.util.SessionClicks#show-portlet-description-132</name><value>false</value></preference><preference><name>com.liferay.portal.util.SessionClicks#show-portlet-description-156</name><value>false</value></preference><preference><name>com.liferay.portal.util.SessionClicks#show-portlet-description-155</name><value>false</value></preference><preference><name>com.liferay.portal.util.SessionClicks#show-portlet-description-2</name><value>false</value></preference><preference><name>79#groups-order-by-col</name><value>name</value></preference><preference><name>com.liferay.portal.util.SessionClicks#show-portlet-description-20</name><value>false</value></preference><preference><name>79#organizations-order-by-type</name><value>asc</value></preference><preference><name>79#organizations-order-by-col</name><value>name</value></preference><preference><name>79#password-policies-order-by-col</name><value>name</value></preference><preference><name>79#groups-order-by-type</name><value>asc</value></preference><preference><name>15#articles-order-by-type</name><value>asc</value></preference><preference><name>com.liferay.portal.util.SessionClicks#show-portlet-description-25</name><value>false</value></preference><preference><name>79#password-policies-order-by-type</name><value>asc</value></preference><preference><name>com.liferay.portal.util.SessionClicks#show-portlet-description-147</name><value>false</value></preference><preference><name>15#articles-order-by-col</name><value>id</value></preference><preference><name>com.liferay.portal.util.SessionClicks#show-portlet-description-129</name><value>false</value></preference><preference><name>com.liferay.portal.util.SessionClicks#show-portlet-description-128</name><value>false</value></preference><preference><name>com.liferay.portal.util.SessionClicks#show-portlet-description-146</name><value>false</value></preference><preference><name>com.liferay.portal.util.SessionClicks#show-portlet-description-149</name><value>false</value></preference><preference><name>com.liferay.portal.util.SessionClicks#show-portlet-description-125</name><value>false</value></preference><preference><name>com.liferay.portal.util.SessionClicks#show-portlet-description-127</name><value>false</value></preference><preference><name>com.liferay.portal.util.SessionClicks#show-portlet-description-126</name><value>false</value></preference></portlet-preferences>'),(10331,0,3,10160,'145','<portlet-preferences />'),(10332,0,3,10160,'88','<portlet-preferences />'),(10338,0,3,10333,'103','<portlet-preferences />'),(10339,0,3,10333,'145','<portlet-preferences />'),(10340,0,3,10333,'87','<portlet-preferences />'),(10341,0,3,10333,'98','<portlet-preferences />'),(10354,0,3,10152,'160','<portlet-preferences />'),(10355,0,3,10152,'145','<portlet-preferences />'),(10356,0,3,10152,'134','<portlet-preferences />'),(10361,0,3,10152,'128','<portlet-preferences />'),(10364,0,3,10152,'125','<portlet-preferences />'),(10374,0,3,10152,'126','<portlet-preferences />'),(10380,10375,6,0,'LIFERAY_PORTAL','<portlet-preferences><preference><name>reminderQueries_tr_TR</name><value></value></preference><preference><name>reminderQueries_de_DE</name><value></value></preference><preference><name>reminderQueries_vi_VN</name><value></value></preference><preference><name>reminderQueries_it_IT</name><value></value></preference><preference><name>reminderQueries_el_GR</name><value></value></preference><preference><name>reminderQueries_cs_CZ</name><value></value></preference><preference><name>reminderQueries_ca_AD</name><value></value></preference><preference><name>reminderQueries_in_ID</name><value></value></preference><preference><name>reminderQueries_es_ES</name><value></value></preference><preference><name>reminderQueries_fr_FR</name><value></value></preference><preference><name>reminderQueries_ar_SA</name><value></value></preference><preference><name>reminderQueries_ru_RU</name><value></value></preference><preference><name>reminderQueries_iw_IL</name><value></value></preference><preference><name>reminderQueries_nb_NO</name><value></value></preference><preference><name>reminderQueries_eu_ES</name><value></value></preference><preference><name>reminderQueries</name><value></value></preference><preference><name>reminderQueries_pt_PT</name><value></value></preference><preference><name>reminderQueries_ca_ES</name><value></value></preference><preference><name>reminderQueries_ko_KR</name><value></value></preference><preference><name>reminderQueries_et_EE</name><value></value></preference><preference><name>reminderQueries_hu_HU</name><value></value></preference><preference><name>reminderQueries_uk_UA</name><value></value></preference><preference><name>reminderQueries_zh_TW</name><value></value></preference><preference><name>reminderQueries_pt_BR</name><value></value></preference><preference><name>reminderQueries_sk_SK</name><value></value></preference><preference><name>reminderQueries_sv_SE</name><value></value></preference><preference><name>reminderQueries_nl_NL</name><value></value></preference><preference><name>reminderQueries_fi_FI</name><value></value></preference><preference><name>reminderQueries_gl_ES</name><value></value></preference><preference><name>reminderQueries_pl_PL</name><value></value></preference><preference><name>reminderQueries_fa_IR</name><value></value></preference><preference><name>reminderQueries_bg_BG</name><value></value></preference><preference><name>reminderQueries_ja_JP</name><value></value></preference><preference><name>reminderQueries_zh_CN</name><value></value></preference><preference><name>reminderQueries_hi_IN</name><value></value></preference><preference><name>reminderQueries_en_GB</name><value></value></preference></portlet-preferences>'),(10383,0,3,10152,'127','<portlet-preferences />'),(10397,0,3,10392,'103','<portlet-preferences />'),(10398,0,3,10392,'145','<portlet-preferences />'),(10399,0,3,10392,'87','<portlet-preferences />'),(10400,0,3,10392,'36','<portlet-preferences />'),(10411,10388,2,0,'154','<portlet-preferences />'),(10412,0,3,10152,'154','<portlet-preferences />'),(10417,0,3,10392,'144','<portlet-preferences />'),(10419,10157,2,0,'25','<portlet-preferences />'),(10420,0,3,10152,'25','<portlet-preferences />'),(10429,0,3,10424,'103','<portlet-preferences />'),(10430,0,3,10424,'145','<portlet-preferences />'),(10431,0,3,10424,'87','<portlet-preferences />'),(10432,0,3,10424,'59_INSTANCE_l7zO','<portlet-preferences><preference><name>question-id</name><value>10421</value></preference></portlet-preferences>'),(10433,0,3,10424,'86','<portlet-preferences />'),(10444,10435,2,0,'15','<portlet-preferences />'),(10445,0,3,10152,'15','<portlet-preferences />'),(10448,0,3,10439,'103','<portlet-preferences />'),(10449,0,3,10439,'145','<portlet-preferences />'),(10450,0,3,10439,'87','<portlet-preferences />'),(10451,0,3,10439,'56_INSTANCE_hUa2','<portlet-preferences><preference><name>enable-print</name><value>false</value></preference><preference><name>group-id</name><value>10435</value></preference><preference><name>enable-comments</name><value>false</value></preference><preference><name>article-id</name><value>10457</value></preference><preference><name>enable-comment-ratings</name><value>false</value></preference><preference><name>show-available-locales</name><value>false</value></preference><preference><name>enable-ratings</name><value>false</value></preference><preference><name>template-id</name><value></value></preference><preference><name>extensions</name><value>NULL_VALUE</value></preference></portlet-preferences>'),(10467,0,3,10152,'147','<portlet-preferences />'),(10472,0,3,10439,'86','<portlet-preferences />'),(10474,0,3,10439,'15','<portlet-preferences />'),(10475,0,3,10160,'119','<portlet-preferences />'),(10490,0,3,10485,'103','<portlet-preferences />'),(10491,0,3,10485,'145','<portlet-preferences />'),(10492,0,3,10485,'87','<portlet-preferences />'),(10493,0,3,10485,'84','<portlet-preferences />'),(10494,10132,1,0,'84','<portlet-preferences />'),(10495,0,3,10152,'155','<portlet-preferences />'),(10520,0,3,10152,'33','<portlet-preferences />'),(10521,0,3,10152,'146','<portlet-preferences />'),(10531,0,3,10152,'149','<portlet-preferences />'),(10541,0,3,10152,'129','<portlet-preferences />'),(10562,10543,4,0,'LIFERAY_PORTAL','<portlet-preferences />'),(10565,0,3,10152,'156','<portlet-preferences />'),(10571,0,3,10566,'103','<portlet-preferences />'),(10572,0,3,10566,'145','<portlet-preferences />'),(10573,0,3,10566,'87','<portlet-preferences />'),(10574,0,3,10566,'34','<portlet-preferences />'),(10575,10157,2,0,'34','<portlet-preferences />'),(10608,10589,4,0,'LIFERAY_PORTAL','<portlet-preferences />'),(10609,0,3,10598,'103','<portlet-preferences />'),(10610,0,3,10598,'11','<portlet-preferences />'),(10611,0,3,10598,'23','<portlet-preferences />'),(10612,0,3,10598,'29','<portlet-preferences />'),(10613,0,3,10598,'8','<portlet-preferences />'),(10614,0,3,10598,'82','<portlet-preferences />'),(10615,0,3,10598,'145','<portlet-preferences />'),(10630,0,3,10621,'20','<portlet-preferences />'),(10631,10617,2,0,'15','<portlet-preferences />'),(10632,0,3,10621,'31','<portlet-preferences />'),(10633,10617,2,0,'25','<portlet-preferences />'),(10637,0,3,10636,'20','<portlet-preferences></portlet-preferences>'),(10638,10626,2,0,'15','<?xml version=\"1.0\"?>\n\n<portlet-preferences owner-id=\"10617\" owner-type=\"2\" default-user=\"false\" plid=\"0\" portlet-id=\"15\"/>'),(10639,0,3,10636,'15','<portlet-preferences></portlet-preferences>'),(10640,10626,2,0,'25','<?xml version=\"1.0\"?>\n\n<portlet-preferences owner-id=\"10617\" owner-type=\"2\" default-user=\"false\" plid=\"0\" portlet-id=\"25\"/>'),(10641,0,3,10636,'103','<portlet-preferences />'),(10642,0,3,10636,'145','<portlet-preferences />'),(10643,0,3,10636,'87','<portlet-preferences />'),(10644,0,3,10636,'19','<portlet-preferences xmlns=\"http://java.sun.com/xml/ns/portlet/portlet-app_2_0.xsd\">\n			<preference>\n				<name>priorities</name>\n				<value>Urgent,/message_boards/priority_urgent.png,3.0</value>\n				<value>Sticky,/message_boards/priority_sticky.png,2.0</value>\n				<value>Announcement,/message_boards/priority_announcement.png,1.0</value>\n			</preference>\n			<preference>\n				<name>ranks</name>\n				<value>Youngling=0</value>\n				<value>Padawan=25</value>\n				<value>Jedi Knight=100</value>\n				<value>Jedi Master=250</value>\n				<value>Jedi Council Member=500</value>\n				<value>Yoda=1000</value>\n				<value>Moderator=community-role:Message Boards Administrator</value>\n				<value>Moderator=organization:Message Boards Administrator</value>\n				<value>Moderator=organization-role:Message Boards Administrator</value>\n				<value>Moderator=regular-role:Message Boards Administrator</value>\n				<value>Moderator=user-group:Message Boards Administrator</value>\n			</preference>\n		</portlet-preferences>'),(10656,0,3,10651,'103','<portlet-preferences />'),(10657,0,3,10651,'145','<portlet-preferences />'),(10658,0,3,10651,'87','<portlet-preferences />'),(10659,0,3,10651,'28','<portlet-preferences />'),(10672,0,3,10667,'103','<portlet-preferences />'),(10673,0,3,10667,'145','<portlet-preferences />'),(10674,0,3,10667,'87','<portlet-preferences />'),(10675,0,3,10667,'101_INSTANCE_dCR9','<portlet-preferences />'),(10676,0,3,10667,'19','<portlet-preferences xmlns=\"http://java.sun.com/xml/ns/portlet/portlet-app_2_0.xsd\">\n			<preference>\n				<name>priorities</name>\n				<value>Urgent,/message_boards/priority_urgent.png,3.0</value>\n				<value>Sticky,/message_boards/priority_sticky.png,2.0</value>\n				<value>Announcement,/message_boards/priority_announcement.png,1.0</value>\n			</preference>\n			<preference>\n				<name>ranks</name>\n				<value>Youngling=0</value>\n				<value>Padawan=25</value>\n				<value>Jedi Knight=100</value>\n				<value>Jedi Master=250</value>\n				<value>Jedi Council Member=500</value>\n				<value>Yoda=1000</value>\n				<value>Moderator=community-role:Message Boards Administrator</value>\n				<value>Moderator=organization:Message Boards Administrator</value>\n				<value>Moderator=organization-role:Message Boards Administrator</value>\n				<value>Moderator=regular-role:Message Boards Administrator</value>\n				<value>Moderator=user-group:Message Boards Administrator</value>\n			</preference>\n		</portlet-preferences>'),(10677,0,3,10667,'33','<portlet-preferences />'),(10687,0,3,10682,'103','<portlet-preferences />'),(10688,0,3,10682,'145','<portlet-preferences />'),(10689,0,3,10682,'87','<portlet-preferences />'),(10690,0,3,10682,'20','<portlet-preferences />'),(10700,0,3,10152,'20','<portlet-preferences />'),(10701,10678,2,0,'20','<portlet-preferences />'),(10711,0,3,10152,'132','<portlet-preferences />'),(10718,0,3,10713,'103','<portlet-preferences />'),(10719,0,3,10713,'145','<portlet-preferences />'),(10720,0,3,10713,'87','<portlet-preferences />'),(10721,0,3,10713,'8','<portlet-preferences />'),(10722,0,3,10152,'8','<portlet-preferences />'),(10730,0,3,10725,'103','<portlet-preferences />'),(10731,0,3,10725,'145','<portlet-preferences />'),(10732,0,3,10725,'87','<portlet-preferences />'),(10733,0,3,10725,'84','<portlet-preferences />'),(10734,0,3,10152,'2','<portlet-preferences />'),(10740,0,3,10152,'139','<portlet-preferences />'),(10761,0,3,10152,'99','<portlet-preferences />'),(10763,0,3,10756,'103','<portlet-preferences />'),(10764,0,3,10756,'145','<portlet-preferences />'),(10765,0,3,10756,'87','<portlet-preferences />'),(10766,0,3,10756,'33','<portlet-preferences />');
/*!40000 ALTER TABLE `PortletPreferences` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `QUARTZ_BLOB_TRIGGERS`
--

DROP TABLE IF EXISTS `QUARTZ_BLOB_TRIGGERS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `QUARTZ_BLOB_TRIGGERS` (
  `TRIGGER_NAME` varchar(80) NOT NULL,
  `TRIGGER_GROUP` varchar(80) NOT NULL,
  `BLOB_DATA` blob,
  PRIMARY KEY (`TRIGGER_NAME`,`TRIGGER_GROUP`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `QUARTZ_BLOB_TRIGGERS`
--

LOCK TABLES `QUARTZ_BLOB_TRIGGERS` WRITE;
/*!40000 ALTER TABLE `QUARTZ_BLOB_TRIGGERS` DISABLE KEYS */;
/*!40000 ALTER TABLE `QUARTZ_BLOB_TRIGGERS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `QUARTZ_CALENDARS`
--

DROP TABLE IF EXISTS `QUARTZ_CALENDARS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `QUARTZ_CALENDARS` (
  `CALENDAR_NAME` varchar(80) NOT NULL,
  `CALENDAR` blob NOT NULL,
  PRIMARY KEY (`CALENDAR_NAME`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `QUARTZ_CALENDARS`
--

LOCK TABLES `QUARTZ_CALENDARS` WRITE;
/*!40000 ALTER TABLE `QUARTZ_CALENDARS` DISABLE KEYS */;
/*!40000 ALTER TABLE `QUARTZ_CALENDARS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `QUARTZ_CRON_TRIGGERS`
--

DROP TABLE IF EXISTS `QUARTZ_CRON_TRIGGERS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `QUARTZ_CRON_TRIGGERS` (
  `TRIGGER_NAME` varchar(80) NOT NULL,
  `TRIGGER_GROUP` varchar(80) NOT NULL,
  `CRON_EXPRESSION` varchar(80) NOT NULL,
  `TIME_ZONE_ID` varchar(80) DEFAULT NULL,
  PRIMARY KEY (`TRIGGER_NAME`,`TRIGGER_GROUP`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `QUARTZ_CRON_TRIGGERS`
--

LOCK TABLES `QUARTZ_CRON_TRIGGERS` WRITE;
/*!40000 ALTER TABLE `QUARTZ_CRON_TRIGGERS` DISABLE KEYS */;
/*!40000 ALTER TABLE `QUARTZ_CRON_TRIGGERS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `QUARTZ_FIRED_TRIGGERS`
--

DROP TABLE IF EXISTS `QUARTZ_FIRED_TRIGGERS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `QUARTZ_FIRED_TRIGGERS` (
  `ENTRY_ID` varchar(95) NOT NULL,
  `TRIGGER_NAME` varchar(80) NOT NULL,
  `TRIGGER_GROUP` varchar(80) NOT NULL,
  `IS_VOLATILE` tinyint(4) NOT NULL,
  `INSTANCE_NAME` varchar(80) NOT NULL,
  `FIRED_TIME` bigint(20) NOT NULL,
  `PRIORITY` int(11) NOT NULL,
  `STATE` varchar(16) NOT NULL,
  `JOB_NAME` varchar(80) DEFAULT NULL,
  `JOB_GROUP` varchar(80) DEFAULT NULL,
  `IS_STATEFUL` tinyint(4) DEFAULT NULL,
  `REQUESTS_RECOVERY` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`ENTRY_ID`),
  KEY `IX_804154AF` (`INSTANCE_NAME`),
  KEY `IX_BAB9A1F7` (`JOB_GROUP`),
  KEY `IX_ADEE6A17` (`JOB_NAME`),
  KEY `IX_64B194F2` (`TRIGGER_GROUP`),
  KEY `IX_5FEABBC` (`TRIGGER_NAME`),
  KEY `IX_20D8706C` (`TRIGGER_NAME`,`TRIGGER_GROUP`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `QUARTZ_FIRED_TRIGGERS`
--

LOCK TABLES `QUARTZ_FIRED_TRIGGERS` WRITE;
/*!40000 ALTER TABLE `QUARTZ_FIRED_TRIGGERS` DISABLE KEYS */;
/*!40000 ALTER TABLE `QUARTZ_FIRED_TRIGGERS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `QUARTZ_JOB_DETAILS`
--

DROP TABLE IF EXISTS `QUARTZ_JOB_DETAILS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `QUARTZ_JOB_DETAILS` (
  `JOB_NAME` varchar(80) NOT NULL,
  `JOB_GROUP` varchar(80) NOT NULL,
  `DESCRIPTION` varchar(120) DEFAULT NULL,
  `JOB_CLASS_NAME` varchar(128) NOT NULL,
  `IS_DURABLE` tinyint(4) NOT NULL,
  `IS_VOLATILE` tinyint(4) NOT NULL,
  `IS_STATEFUL` tinyint(4) NOT NULL,
  `REQUESTS_RECOVERY` tinyint(4) NOT NULL,
  `JOB_DATA` blob,
  PRIMARY KEY (`JOB_NAME`,`JOB_GROUP`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `QUARTZ_JOB_DETAILS`
--

LOCK TABLES `QUARTZ_JOB_DETAILS` WRITE;
/*!40000 ALTER TABLE `QUARTZ_JOB_DETAILS` DISABLE KEYS */;
INSERT INTO `QUARTZ_JOB_DETAILS` VALUES ('com.liferay.portlet.admin.messaging.LDAPImportMessageListener','com.liferay.portlet.admin.messaging.LDAPImportMessageListener',NULL,'com.liferay.portal.scheduler.job.MessageSenderJob',1,0,0,0,'��\0sr\0org.quartz.JobDataMap���迩��\0\0xr\0&org.quartz.utils.StringKeyDirtyFlagMap�����](\0Z\0allowsTransientDataxr\0org.quartz.utils.DirtyFlagMap�.�(v\n�\0Z\0dirtyL\0mapt\0Ljava/util/Map;xpsr\0java.util.HashMap���`�\0F\0\nloadFactorI\0	thresholdxp?@\0\0\0\0\0w\0\0\0\0\0\0t\0MESSAGEt�{\"response\":null,\"responseId\":null,\"values\":{\"map\":{\"EXCEPTIONS_MAX_SIZE\":0,\"RECEIVER_KEY\":\"com.liferay.portlet.admin.messaging.LDAPImportMessageListener.com.liferay.portlet.admin.messaging.LDAPImportMessageListener\",\"MESSAGE_LISTENER_UUID\":\"dceda73e-e887-48fb-a725-b5619fa52714\"},\"javaClass\":\"java.util.HashMap\"},\"responseDestinationName\":null,\"javaClass\":\"com.liferay.portal.kernel.messaging.Message\",\"payload\":null,\"destinationName\":null}t\0DESCRIPTIONt\0\0t\0DESTINATION_NAMEt\0\Zliferay/scheduler_dispatchx\0'),('com.liferay.portlet.admin.messaging.PluginRepositoriesMessageListener','com.liferay.portlet.admin.messaging.PluginRepositoriesMessageListener',NULL,'com.liferay.portal.scheduler.job.MessageSenderJob',1,0,0,0,'��\0sr\0org.quartz.JobDataMap���迩��\0\0xr\0&org.quartz.utils.StringKeyDirtyFlagMap�����](\0Z\0allowsTransientDataxr\0org.quartz.utils.DirtyFlagMap�.�(v\n�\0Z\0dirtyL\0mapt\0Ljava/util/Map;xpsr\0java.util.HashMap���`�\0F\0\nloadFactorI\0	thresholdxp?@\0\0\0\0\0w\0\0\0\0\0\0t\0MESSAGEt�{\"response\":null,\"responseId\":null,\"values\":{\"map\":{\"EXCEPTIONS_MAX_SIZE\":0,\"RECEIVER_KEY\":\"com.liferay.portlet.admin.messaging.PluginRepositoriesMessageListener.com.liferay.portlet.admin.messaging.PluginRepositoriesMessageListener\",\"MESSAGE_LISTENER_UUID\":\"b0fc3eea-4a47-420c-ab3b-7867c6cc548a\"},\"javaClass\":\"java.util.HashMap\"},\"responseDestinationName\":null,\"javaClass\":\"com.liferay.portal.kernel.messaging.Message\",\"payload\":null,\"destinationName\":null}t\0DESCRIPTIONt\0\0t\0DESTINATION_NAMEt\0\Zliferay/scheduler_dispatchx\0'),('com.liferay.portlet.announcements.messaging.CheckEntryMessageListener','com.liferay.portlet.announcements.messaging.CheckEntryMessageListener',NULL,'com.liferay.portal.scheduler.job.MessageSenderJob',1,0,0,0,'��\0sr\0org.quartz.JobDataMap���迩��\0\0xr\0&org.quartz.utils.StringKeyDirtyFlagMap�����](\0Z\0allowsTransientDataxr\0org.quartz.utils.DirtyFlagMap�.�(v\n�\0Z\0dirtyL\0mapt\0Ljava/util/Map;xpsr\0java.util.HashMap���`�\0F\0\nloadFactorI\0	thresholdxp?@\0\0\0\0\0w\0\0\0\0\0\0t\0MESSAGEt�{\"response\":null,\"responseId\":null,\"values\":{\"map\":{\"EXCEPTIONS_MAX_SIZE\":0,\"RECEIVER_KEY\":\"com.liferay.portlet.announcements.messaging.CheckEntryMessageListener.com.liferay.portlet.announcements.messaging.CheckEntryMessageListener\",\"MESSAGE_LISTENER_UUID\":\"140ff8f3-2b51-4d18-80ad-6584338a90b8\"},\"javaClass\":\"java.util.HashMap\"},\"responseDestinationName\":null,\"javaClass\":\"com.liferay.portal.kernel.messaging.Message\",\"payload\":null,\"destinationName\":null}t\0DESCRIPTIONt\0\0t\0DESTINATION_NAMEt\0\Zliferay/scheduler_dispatchx\0'),('com.liferay.portlet.blogs.messaging.LinkbackMessageListener','com.liferay.portlet.blogs.messaging.LinkbackMessageListener',NULL,'com.liferay.portal.scheduler.job.MessageSenderJob',1,0,0,0,'��\0sr\0org.quartz.JobDataMap���迩��\0\0xr\0&org.quartz.utils.StringKeyDirtyFlagMap�����](\0Z\0allowsTransientDataxr\0org.quartz.utils.DirtyFlagMap�.�(v\n�\0Z\0dirtyL\0mapt\0Ljava/util/Map;xpsr\0java.util.HashMap���`�\0F\0\nloadFactorI\0	thresholdxp?@\0\0\0\0\0w\0\0\0\0\0\0t\0MESSAGEt�{\"response\":null,\"responseId\":null,\"values\":{\"map\":{\"EXCEPTIONS_MAX_SIZE\":0,\"RECEIVER_KEY\":\"com.liferay.portlet.blogs.messaging.LinkbackMessageListener.com.liferay.portlet.blogs.messaging.LinkbackMessageListener\",\"MESSAGE_LISTENER_UUID\":\"0e881c1e-fe42-4fac-beea-9666889a8084\"},\"javaClass\":\"java.util.HashMap\"},\"responseDestinationName\":null,\"javaClass\":\"com.liferay.portal.kernel.messaging.Message\",\"payload\":null,\"destinationName\":null}t\0DESCRIPTIONt\0\0t\0DESTINATION_NAMEt\0\Zliferay/scheduler_dispatchx\0'),('com.liferay.portlet.calendar.messaging.CheckEventMessageListener','com.liferay.portlet.calendar.messaging.CheckEventMessageListener',NULL,'com.liferay.portal.scheduler.job.MessageSenderJob',1,0,0,0,'��\0sr\0org.quartz.JobDataMap���迩��\0\0xr\0&org.quartz.utils.StringKeyDirtyFlagMap�����](\0Z\0allowsTransientDataxr\0org.quartz.utils.DirtyFlagMap�.�(v\n�\0Z\0dirtyL\0mapt\0Ljava/util/Map;xpsr\0java.util.HashMap���`�\0F\0\nloadFactorI\0	thresholdxp?@\0\0\0\0\0w\0\0\0\0\0\0t\0MESSAGEt�{\"response\":null,\"responseId\":null,\"values\":{\"map\":{\"EXCEPTIONS_MAX_SIZE\":0,\"RECEIVER_KEY\":\"com.liferay.portlet.calendar.messaging.CheckEventMessageListener.com.liferay.portlet.calendar.messaging.CheckEventMessageListener\",\"MESSAGE_LISTENER_UUID\":\"175ae7ab-ff66-4f38-9abc-9428c49483ef\"},\"javaClass\":\"java.util.HashMap\"},\"responseDestinationName\":null,\"javaClass\":\"com.liferay.portal.kernel.messaging.Message\",\"payload\":null,\"destinationName\":null}t\0DESCRIPTIONt\0\0t\0DESTINATION_NAMEt\0\Zliferay/scheduler_dispatchx\0'),('com.liferay.portlet.journal.messaging.CheckArticleMessageListener','com.liferay.portlet.journal.messaging.CheckArticleMessageListener',NULL,'com.liferay.portal.scheduler.job.MessageSenderJob',1,0,0,0,'��\0sr\0org.quartz.JobDataMap���迩��\0\0xr\0&org.quartz.utils.StringKeyDirtyFlagMap�����](\0Z\0allowsTransientDataxr\0org.quartz.utils.DirtyFlagMap�.�(v\n�\0Z\0dirtyL\0mapt\0Ljava/util/Map;xpsr\0java.util.HashMap���`�\0F\0\nloadFactorI\0	thresholdxp?@\0\0\0\0\0w\0\0\0\0\0\0t\0MESSAGEt�{\"response\":null,\"responseId\":null,\"values\":{\"map\":{\"EXCEPTIONS_MAX_SIZE\":0,\"RECEIVER_KEY\":\"com.liferay.portlet.journal.messaging.CheckArticleMessageListener.com.liferay.portlet.journal.messaging.CheckArticleMessageListener\",\"MESSAGE_LISTENER_UUID\":\"63ef8bec-c815-4186-b593-3b0c994be7d4\"},\"javaClass\":\"java.util.HashMap\"},\"responseDestinationName\":null,\"javaClass\":\"com.liferay.portal.kernel.messaging.Message\",\"payload\":null,\"destinationName\":null}t\0DESCRIPTIONt\0\0t\0DESTINATION_NAMEt\0\Zliferay/scheduler_dispatchx\0'),('com.liferay.portlet.messageboards.messaging.ExpireBanMessageListener','com.liferay.portlet.messageboards.messaging.ExpireBanMessageListener',NULL,'com.liferay.portal.scheduler.job.MessageSenderJob',1,0,0,0,'��\0sr\0org.quartz.JobDataMap���迩��\0\0xr\0&org.quartz.utils.StringKeyDirtyFlagMap�����](\0Z\0allowsTransientDataxr\0org.quartz.utils.DirtyFlagMap�.�(v\n�\0Z\0dirtyL\0mapt\0Ljava/util/Map;xpsr\0java.util.HashMap���`�\0F\0\nloadFactorI\0	thresholdxp?@\0\0\0\0\0w\0\0\0\0\0\0t\0MESSAGEt�{\"response\":null,\"responseId\":null,\"values\":{\"map\":{\"EXCEPTIONS_MAX_SIZE\":0,\"RECEIVER_KEY\":\"com.liferay.portlet.messageboards.messaging.ExpireBanMessageListener.com.liferay.portlet.messageboards.messaging.ExpireBanMessageListener\",\"MESSAGE_LISTENER_UUID\":\"dbcc0974-7cc0-487a-973f-ff3240e726aa\"},\"javaClass\":\"java.util.HashMap\"},\"responseDestinationName\":null,\"javaClass\":\"com.liferay.portal.kernel.messaging.Message\",\"payload\":null,\"destinationName\":null}t\0DESCRIPTIONt\0\0t\0DESTINATION_NAMEt\0\Zliferay/scheduler_dispatchx\0'),('com.liferay.portlet.social.messaging.CheckEquityLogMessageListener','com.liferay.portlet.social.messaging.CheckEquityLogMessageListener',NULL,'com.liferay.portal.scheduler.job.MessageSenderJob',1,0,0,0,'��\0sr\0org.quartz.JobDataMap���迩��\0\0xr\0&org.quartz.utils.StringKeyDirtyFlagMap�����](\0Z\0allowsTransientDataxr\0org.quartz.utils.DirtyFlagMap�.�(v\n�\0Z\0dirtyL\0mapt\0Ljava/util/Map;xpsr\0java.util.HashMap���`�\0F\0\nloadFactorI\0	thresholdxp?@\0\0\0\0\0w\0\0\0\0\0\0t\0MESSAGEt�{\"response\":null,\"responseId\":null,\"values\":{\"map\":{\"EXCEPTIONS_MAX_SIZE\":0,\"RECEIVER_KEY\":\"com.liferay.portlet.social.messaging.CheckEquityLogMessageListener.com.liferay.portlet.social.messaging.CheckEquityLogMessageListener\",\"MESSAGE_LISTENER_UUID\":\"4c99e872-538d-4f39-bfc1-f2a32dc5ae20\"},\"javaClass\":\"java.util.HashMap\"},\"responseDestinationName\":null,\"javaClass\":\"com.liferay.portal.kernel.messaging.Message\",\"payload\":null,\"destinationName\":null}t\0DESCRIPTIONpt\0DESTINATION_NAMEt\0\Zliferay/scheduler_dispatchx\0');
/*!40000 ALTER TABLE `QUARTZ_JOB_DETAILS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `QUARTZ_JOB_LISTENERS`
--

DROP TABLE IF EXISTS `QUARTZ_JOB_LISTENERS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `QUARTZ_JOB_LISTENERS` (
  `JOB_NAME` varchar(80) NOT NULL,
  `JOB_GROUP` varchar(80) NOT NULL,
  `JOB_LISTENER` varchar(80) NOT NULL,
  PRIMARY KEY (`JOB_NAME`,`JOB_GROUP`,`JOB_LISTENER`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `QUARTZ_JOB_LISTENERS`
--

LOCK TABLES `QUARTZ_JOB_LISTENERS` WRITE;
/*!40000 ALTER TABLE `QUARTZ_JOB_LISTENERS` DISABLE KEYS */;
/*!40000 ALTER TABLE `QUARTZ_JOB_LISTENERS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `QUARTZ_LOCKS`
--

DROP TABLE IF EXISTS `QUARTZ_LOCKS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `QUARTZ_LOCKS` (
  `LOCK_NAME` varchar(40) NOT NULL,
  PRIMARY KEY (`LOCK_NAME`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `QUARTZ_LOCKS`
--

LOCK TABLES `QUARTZ_LOCKS` WRITE;
/*!40000 ALTER TABLE `QUARTZ_LOCKS` DISABLE KEYS */;
INSERT INTO `QUARTZ_LOCKS` VALUES ('CALENDAR_ACCESS'),('JOB_ACCESS'),('MISFIRE_ACCESS'),('STATE_ACCESS'),('TRIGGER_ACCESS');
/*!40000 ALTER TABLE `QUARTZ_LOCKS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `QUARTZ_PAUSED_TRIGGER_GRPS`
--

DROP TABLE IF EXISTS `QUARTZ_PAUSED_TRIGGER_GRPS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `QUARTZ_PAUSED_TRIGGER_GRPS` (
  `TRIGGER_GROUP` varchar(80) NOT NULL,
  PRIMARY KEY (`TRIGGER_GROUP`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `QUARTZ_PAUSED_TRIGGER_GRPS`
--

LOCK TABLES `QUARTZ_PAUSED_TRIGGER_GRPS` WRITE;
/*!40000 ALTER TABLE `QUARTZ_PAUSED_TRIGGER_GRPS` DISABLE KEYS */;
/*!40000 ALTER TABLE `QUARTZ_PAUSED_TRIGGER_GRPS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `QUARTZ_SCHEDULER_STATE`
--

DROP TABLE IF EXISTS `QUARTZ_SCHEDULER_STATE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `QUARTZ_SCHEDULER_STATE` (
  `INSTANCE_NAME` varchar(80) NOT NULL,
  `LAST_CHECKIN_TIME` bigint(20) NOT NULL,
  `CHECKIN_INTERVAL` bigint(20) NOT NULL,
  PRIMARY KEY (`INSTANCE_NAME`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `QUARTZ_SCHEDULER_STATE`
--

LOCK TABLES `QUARTZ_SCHEDULER_STATE` WRITE;
/*!40000 ALTER TABLE `QUARTZ_SCHEDULER_STATE` DISABLE KEYS */;
/*!40000 ALTER TABLE `QUARTZ_SCHEDULER_STATE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `QUARTZ_SIMPLE_TRIGGERS`
--

DROP TABLE IF EXISTS `QUARTZ_SIMPLE_TRIGGERS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `QUARTZ_SIMPLE_TRIGGERS` (
  `TRIGGER_NAME` varchar(80) NOT NULL,
  `TRIGGER_GROUP` varchar(80) NOT NULL,
  `REPEAT_COUNT` bigint(20) NOT NULL,
  `REPEAT_INTERVAL` bigint(20) NOT NULL,
  `TIMES_TRIGGERED` bigint(20) NOT NULL,
  PRIMARY KEY (`TRIGGER_NAME`,`TRIGGER_GROUP`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `QUARTZ_SIMPLE_TRIGGERS`
--

LOCK TABLES `QUARTZ_SIMPLE_TRIGGERS` WRITE;
/*!40000 ALTER TABLE `QUARTZ_SIMPLE_TRIGGERS` DISABLE KEYS */;
/*!40000 ALTER TABLE `QUARTZ_SIMPLE_TRIGGERS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `QUARTZ_TRIGGERS`
--

DROP TABLE IF EXISTS `QUARTZ_TRIGGERS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `QUARTZ_TRIGGERS` (
  `TRIGGER_NAME` varchar(80) NOT NULL,
  `TRIGGER_GROUP` varchar(80) NOT NULL,
  `JOB_NAME` varchar(80) NOT NULL,
  `JOB_GROUP` varchar(80) NOT NULL,
  `IS_VOLATILE` tinyint(4) NOT NULL,
  `DESCRIPTION` varchar(120) DEFAULT NULL,
  `NEXT_FIRE_TIME` bigint(20) DEFAULT NULL,
  `PREV_FIRE_TIME` bigint(20) DEFAULT NULL,
  `PRIORITY` int(11) DEFAULT NULL,
  `TRIGGER_STATE` varchar(16) NOT NULL,
  `TRIGGER_TYPE` varchar(8) NOT NULL,
  `START_TIME` bigint(20) NOT NULL,
  `END_TIME` bigint(20) DEFAULT NULL,
  `CALENDAR_NAME` varchar(80) DEFAULT NULL,
  `MISFIRE_INSTR` int(11) DEFAULT NULL,
  `JOB_DATA` blob,
  PRIMARY KEY (`TRIGGER_NAME`,`TRIGGER_GROUP`),
  KEY `IX_F7655CC3` (`NEXT_FIRE_TIME`),
  KEY `IX_9955EFB5` (`TRIGGER_STATE`),
  KEY `IX_8040C593` (`TRIGGER_STATE`,`NEXT_FIRE_TIME`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `QUARTZ_TRIGGERS`
--

LOCK TABLES `QUARTZ_TRIGGERS` WRITE;
/*!40000 ALTER TABLE `QUARTZ_TRIGGERS` DISABLE KEYS */;
/*!40000 ALTER TABLE `QUARTZ_TRIGGERS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `QUARTZ_TRIGGER_LISTENERS`
--

DROP TABLE IF EXISTS `QUARTZ_TRIGGER_LISTENERS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `QUARTZ_TRIGGER_LISTENERS` (
  `TRIGGER_NAME` varchar(80) NOT NULL,
  `TRIGGER_GROUP` varchar(80) NOT NULL,
  `TRIGGER_LISTENER` varchar(80) NOT NULL,
  PRIMARY KEY (`TRIGGER_NAME`,`TRIGGER_GROUP`,`TRIGGER_LISTENER`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `QUARTZ_TRIGGER_LISTENERS`
--

LOCK TABLES `QUARTZ_TRIGGER_LISTENERS` WRITE;
/*!40000 ALTER TABLE `QUARTZ_TRIGGER_LISTENERS` DISABLE KEYS */;
/*!40000 ALTER TABLE `QUARTZ_TRIGGER_LISTENERS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `RatingsEntry`
--

DROP TABLE IF EXISTS `RatingsEntry`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `RatingsEntry` (
  `entryId` bigint(20) NOT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `userId` bigint(20) DEFAULT NULL,
  `userName` varchar(75) DEFAULT NULL,
  `createDate` datetime DEFAULT NULL,
  `modifiedDate` datetime DEFAULT NULL,
  `classNameId` bigint(20) DEFAULT NULL,
  `classPK` bigint(20) DEFAULT NULL,
  `score` double DEFAULT NULL,
  PRIMARY KEY (`entryId`),
  UNIQUE KEY `IX_B47E3C11` (`userId`,`classNameId`,`classPK`),
  KEY `IX_16184D57` (`classNameId`,`classPK`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `RatingsEntry`
--

LOCK TABLES `RatingsEntry` WRITE;
/*!40000 ALTER TABLE `RatingsEntry` DISABLE KEYS */;
INSERT INTO `RatingsEntry` VALUES (10418,10132,10169,'Test Test','2014-04-03 16:45:14','2014-04-03 16:45:14',10129,10403,1);
/*!40000 ALTER TABLE `RatingsEntry` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `RatingsStats`
--

DROP TABLE IF EXISTS `RatingsStats`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `RatingsStats` (
  `statsId` bigint(20) NOT NULL,
  `classNameId` bigint(20) DEFAULT NULL,
  `classPK` bigint(20) DEFAULT NULL,
  `totalEntries` int(11) DEFAULT NULL,
  `totalScore` double DEFAULT NULL,
  `averageScore` double DEFAULT NULL,
  PRIMARY KEY (`statsId`),
  UNIQUE KEY `IX_A6E99284` (`classNameId`,`classPK`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `RatingsStats`
--

LOCK TABLES `RatingsStats` WRITE;
/*!40000 ALTER TABLE `RatingsStats` DISABLE KEYS */;
INSERT INTO `RatingsStats` VALUES (10352,10123,10344,0,0,0),(10416,10129,10403,1,1,1),(10710,10073,10707,0,0,0);
/*!40000 ALTER TABLE `RatingsStats` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Region`
--

DROP TABLE IF EXISTS `Region`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Region` (
  `regionId` bigint(20) NOT NULL,
  `countryId` bigint(20) DEFAULT NULL,
  `regionCode` varchar(75) DEFAULT NULL,
  `name` varchar(75) DEFAULT NULL,
  `active_` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`regionId`),
  KEY `IX_2D9A426F` (`active_`),
  KEY `IX_16D87CA7` (`countryId`),
  KEY `IX_11FB3E42` (`countryId`,`active_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Region`
--

LOCK TABLES `Region` WRITE;
/*!40000 ALTER TABLE `Region` DISABLE KEYS */;
INSERT INTO `Region` VALUES (1001,1,'AB','Alberta',1),(1002,1,'BC','British Columbia',1),(1003,1,'MB','Manitoba',1),(1004,1,'NB','New Brunswick',1),(1005,1,'NL','Newfoundland and Labrador',1),(1006,1,'NT','Northwest Territories',1),(1007,1,'NS','Nova Scotia',1),(1008,1,'NU','Nunavut',1),(1009,1,'ON','Ontario',1),(1010,1,'PE','Prince Edward Island',1),(1011,1,'QC','Quebec',1),(1012,1,'SK','Saskatchewan',1),(1013,1,'YT','Yukon',1),(2001,2,'CN-34','Anhui',1),(2002,2,'CN-92','Aomen',1),(2003,2,'CN-11','Beijing',1),(2004,2,'CN-50','Chongqing',1),(2005,2,'CN-35','Fujian',1),(2006,2,'CN-62','Gansu',1),(2007,2,'CN-44','Guangdong',1),(2008,2,'CN-45','Guangxi',1),(2009,2,'CN-52','Guizhou',1),(2010,2,'CN-46','Hainan',1),(2011,2,'CN-13','Hebei',1),(2012,2,'CN-23','Heilongjiang',1),(2013,2,'CN-41','Henan',1),(2014,2,'CN-42','Hubei',1),(2015,2,'CN-43','Hunan',1),(2016,2,'CN-32','Jiangsu',1),(2017,2,'CN-36','Jiangxi',1),(2018,2,'CN-22','Jilin',1),(2019,2,'CN-21','Liaoning',1),(2020,2,'CN-15','Nei Mongol',1),(2021,2,'CN-64','Ningxia',1),(2022,2,'CN-63','Qinghai',1),(2023,2,'CN-61','Shaanxi',1),(2024,2,'CN-37','Shandong',1),(2025,2,'CN-31','Shanghai',1),(2026,2,'CN-14','Shanxi',1),(2027,2,'CN-51','Sichuan',1),(2028,2,'CN-71','Taiwan',1),(2029,2,'CN-12','Tianjin',1),(2030,2,'CN-91','Xianggang',1),(2031,2,'CN-65','Xinjiang',1),(2032,2,'CN-54','Xizang',1),(2033,2,'CN-53','Yunnan',1),(2034,2,'CN-33','Zhejiang',1),(3001,3,'A','Alsace',1),(3002,3,'B','Aquitaine',1),(3003,3,'C','Auvergne',1),(3004,3,'P','Basse-Normandie',1),(3005,3,'D','Bourgogne',1),(3006,3,'E','Bretagne',1),(3007,3,'F','Centre',1),(3008,3,'G','Champagne-Ardenne',1),(3009,3,'H','Corse',1),(3010,3,'GF','Guyane',1),(3011,3,'I','Franche Comté',1),(3012,3,'GP','Guadeloupe',1),(3013,3,'Q','Haute-Normandie',1),(3014,3,'J','Île-de-France',1),(3015,3,'K','Languedoc-Roussillon',1),(3016,3,'L','Limousin',1),(3017,3,'M','Lorraine',1),(3018,3,'MQ','Martinique',1),(3019,3,'N','Midi-Pyrénées',1),(3020,3,'O','Nord Pas de Calais',1),(3021,3,'R','Pays de la Loire',1),(3022,3,'S','Picardie',1),(3023,3,'T','Poitou-Charentes',1),(3024,3,'U','Provence-Alpes-Côte-d\'Azur',1),(3025,3,'RE','Réunion',1),(3026,3,'V','Rhône-Alpes',1),(4001,4,'BW','Baden-Württemberg',1),(4002,4,'BY','Bayern',1),(4003,4,'BE','Berlin',1),(4004,4,'BR','Brandenburg',1),(4005,4,'HB','Bremen',1),(4006,4,'HH','Hamburg',1),(4007,4,'HE','Hessen',1),(4008,4,'MV','Mecklenburg-Vorpommern',1),(4009,4,'NI','Niedersachsen',1),(4010,4,'NW','Nordrhein-Westfalen',1),(4011,4,'RP','Rheinland-Pfalz',1),(4012,4,'SL','Saarland',1),(4013,4,'SN','Sachsen',1),(4014,4,'ST','Sachsen-Anhalt',1),(4015,4,'SH','Schleswig-Holstein',1),(4016,4,'TH','Thüringen',1),(8001,8,'AG','Agrigento',1),(8002,8,'AL','Alessandria',1),(8003,8,'AN','Ancona',1),(8004,8,'AO','Aosta',1),(8005,8,'AR','Arezzo',1),(8006,8,'AP','Ascoli Piceno',1),(8007,8,'AT','Asti',1),(8008,8,'AV','Avellino',1),(8009,8,'BA','Bari',1),(8010,8,'BT','Barletta-Andria-Trani',1),(8011,8,'BL','Belluno',1),(8012,8,'BN','Benevento',1),(8013,8,'BG','Bergamo',1),(8014,8,'BI','Biella',1),(8015,8,'BO','Bologna',1),(8016,8,'BZ','Bolzano',1),(8017,8,'BS','Brescia',1),(8018,8,'BR','Brindisi',1),(8019,8,'CA','Cagliari',1),(8020,8,'CL','Caltanissetta',1),(8021,8,'CB','Campobasso',1),(8022,8,'CI','Carbonia-Iglesias',1),(8023,8,'CE','Caserta',1),(8024,8,'CT','Catania',1),(8025,8,'CZ','Catanzaro',1),(8026,8,'CH','Chieti',1),(8027,8,'CO','Como',1),(8028,8,'CS','Cosenza',1),(8029,8,'CR','Cremona',1),(8030,8,'KR','Crotone',1),(8031,8,'CN','Cuneo',1),(8032,8,'EN','Enna',1),(8033,8,'FM','Fermo',1),(8034,8,'FE','Ferrara',1),(8035,8,'FI','Firenze',1),(8036,8,'FG','Foggia',1),(8037,8,'FC','Forli-Cesena',1),(8038,8,'FR','Frosinone',1),(8039,8,'GE','Genova',1),(8040,8,'GO','Gorizia',1),(8041,8,'GR','Grosseto',1),(8042,8,'IM','Imperia',1),(8043,8,'IS','Isernia',1),(8044,8,'AQ','L\'Aquila',1),(8045,8,'SP','La Spezia',1),(8046,8,'LT','Latina',1),(8047,8,'LE','Lecce',1),(8048,8,'LC','Lecco',1),(8049,8,'LI','Livorno',1),(8050,8,'LO','Lodi',1),(8051,8,'LU','Lucca',1),(8052,8,'MC','Macerata',1),(8053,8,'MN','Mantova',1),(8054,8,'MS','Massa-Carrara',1),(8055,8,'MT','Matera',1),(8056,8,'MA','Medio Campidano',1),(8057,8,'ME','Messina',1),(8058,8,'MI','Milano',1),(8059,8,'MO','Modena',1),(8060,8,'MZ','Monza',1),(8061,8,'NA','Napoli',1),(8062,8,'NO','Novara',1),(8063,8,'NU','Nuoro',1),(8064,8,'OG','Ogliastra',1),(8065,8,'OT','Olbia-Tempio',1),(8066,8,'OR','Oristano',1),(8067,8,'PD','Padova',1),(8068,8,'PA','Palermo',1),(8069,8,'PR','Parma',1),(8070,8,'PV','Pavia',1),(8071,8,'PG','Perugia',1),(8072,8,'PU','Pesaro e Urbino',1),(8073,8,'PE','Pescara',1),(8074,8,'PC','Piacenza',1),(8075,8,'PI','Pisa',1),(8076,8,'PT','Pistoia',1),(8077,8,'PN','Pordenone',1),(8078,8,'PZ','Potenza',1),(8079,8,'PO','Prato',1),(8080,8,'RG','Ragusa',1),(8081,8,'RA','Ravenna',1),(8082,8,'RC','Reggio Calabria',1),(8083,8,'RE','Reggio Emilia',1),(8084,8,'RI','Rieti',1),(8085,8,'RN','Rimini',1),(8086,8,'RM','Roma',1),(8087,8,'RO','Rovigo',1),(8088,8,'SA','Salerno',1),(8089,8,'SS','Sassari',1),(8090,8,'SV','Savona',1),(8091,8,'SI','Siena',1),(8092,8,'SR','Siracusa',1),(8093,8,'SO','Sondrio',1),(8094,8,'TA','Taranto',1),(8095,8,'TE','Teramo',1),(8096,8,'TR','Terni',1),(8097,8,'TO','Torino',1),(8098,8,'TP','Trapani',1),(8099,8,'TN','Trento',1),(8100,8,'TV','Treviso',1),(8101,8,'TS','Trieste',1),(8102,8,'UD','Udine',1),(8103,8,'VA','Varese',1),(8104,8,'VE','Venezia',1),(8105,8,'VB','Verbano-Cusio-Ossola',1),(8106,8,'VC','Vercelli',1),(8107,8,'VR','Verona',1),(8108,8,'VV','Vibo Valentia',1),(8109,8,'VI','Vicenza',1),(8110,8,'VT','Viterbo',1),(11001,11,'DR','Drenthe',1),(11002,11,'FL','Flevoland',1),(11003,11,'FR','Friesland',1),(11004,11,'GE','Gelderland',1),(11005,11,'GR','Groningen',1),(11006,11,'LI','Limburg',1),(11007,11,'NB','Noord-Brabant',1),(11008,11,'NH','Noord-Holland',1),(11009,11,'OV','Overijssel',1),(11010,11,'UT','Utrecht',1),(11011,11,'ZE','Zeeland',1),(11012,11,'ZH','Zuid-Holland',1),(15001,15,'AN','Andalusia',1),(15002,15,'AR','Aragon',1),(15003,15,'AS','Asturias',1),(15004,15,'IB','Balearic Islands',1),(15005,15,'PV','Basque Country',1),(15006,15,'CN','Canary Islands',1),(15007,15,'CB','Cantabria',1),(15008,15,'CL','Castile and Leon',1),(15009,15,'CM','Castile-La Mancha',1),(15010,15,'CT','Catalonia',1),(15011,15,'CE','Ceuta',1),(15012,15,'EX','Extremadura',1),(15013,15,'GA','Galicia',1),(15014,15,'LO','La Rioja',1),(15015,15,'M','Madrid',1),(15016,15,'ML','Melilla',1),(15017,15,'MU','Murcia',1),(15018,15,'NA','Navarra',1),(15019,15,'VC','Valencia',1),(19001,19,'AL','Alabama',1),(19002,19,'AK','Alaska',1),(19003,19,'AZ','Arizona',1),(19004,19,'AR','Arkansas',1),(19005,19,'CA','California',1),(19006,19,'CO','Colorado',1),(19007,19,'CT','Connecticut',1),(19008,19,'DC','District of Columbia',1),(19009,19,'DE','Delaware',1),(19010,19,'FL','Florida',1),(19011,19,'GA','Georgia',1),(19012,19,'HI','Hawaii',1),(19013,19,'ID','Idaho',1),(19014,19,'IL','Illinois',1),(19015,19,'IN','Indiana',1),(19016,19,'IA','Iowa',1),(19017,19,'KS','Kansas',1),(19018,19,'KY','Kentucky ',1),(19019,19,'LA','Louisiana ',1),(19020,19,'ME','Maine',1),(19021,19,'MD','Maryland',1),(19022,19,'MA','Massachusetts',1),(19023,19,'MI','Michigan',1),(19024,19,'MN','Minnesota',1),(19025,19,'MS','Mississippi',1),(19026,19,'MO','Missouri',1),(19027,19,'MT','Montana',1),(19028,19,'NE','Nebraska',1),(19029,19,'NV','Nevada',1),(19030,19,'NH','New Hampshire',1),(19031,19,'NJ','New Jersey',1),(19032,19,'NM','New Mexico',1),(19033,19,'NY','New York',1),(19034,19,'NC','North Carolina',1),(19035,19,'ND','North Dakota',1),(19036,19,'OH','Ohio',1),(19037,19,'OK','Oklahoma ',1),(19038,19,'OR','Oregon',1),(19039,19,'PA','Pennsylvania',1),(19040,19,'PR','Puerto Rico',1),(19041,19,'RI','Rhode Island',1),(19042,19,'SC','South Carolina',1),(19043,19,'SD','South Dakota',1),(19044,19,'TN','Tennessee',1),(19045,19,'TX','Texas',1),(19046,19,'UT','Utah',1),(19047,19,'VT','Vermont',1),(19048,19,'VA','Virginia',1),(19049,19,'WA','Washington',1),(19050,19,'WV','West Virginia',1),(19051,19,'WI','Wisconsin',1),(19052,19,'WY','Wyoming',1),(32001,32,'ACT','Australian Capital Territory',1),(32002,32,'NSW','New South Wales',1),(32003,32,'NT','Northern Territory',1),(32004,32,'QLD','Queensland',1),(32005,32,'SA','South Australia',1),(32006,32,'TAS','Tasmania',1),(32007,32,'VIC','Victoria',1),(32008,32,'WA','Western Australia',1),(202001,202,'AG','Aargau',1),(202002,202,'AR','Appenzell Ausserrhoden',1),(202003,202,'AI','Appenzell Innerrhoden',1),(202004,202,'BL','Basel-Landschaft',1),(202005,202,'BS','Basel-Stadt',1),(202006,202,'BE','Bern',1),(202007,202,'FR','Fribourg',1),(202008,202,'GE','Geneva',1),(202009,202,'GL','Glarus',1),(202010,202,'GR','Graubünden',1),(202011,202,'JU','Jura',1),(202012,202,'LU','Lucerne',1),(202013,202,'NE','Neuchâtel',1),(202014,202,'NW','Nidwalden',1),(202015,202,'OW','Obwalden',1),(202016,202,'SH','Schaffhausen',1),(202017,202,'SZ','Schwyz',1),(202018,202,'SO','Solothurn',1),(202019,202,'SG','St. Gallen',1),(202020,202,'TG','Thurgau',1),(202021,202,'TI','Ticino',1),(202022,202,'UR','Uri',1),(202023,202,'VS','Valais',1),(202024,202,'VD','Vaud',1),(202025,202,'ZG','Zug',1),(202026,202,'ZH','Zürich',1);
/*!40000 ALTER TABLE `Region` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Release_`
--

DROP TABLE IF EXISTS `Release_`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Release_` (
  `releaseId` bigint(20) NOT NULL,
  `createDate` datetime DEFAULT NULL,
  `modifiedDate` datetime DEFAULT NULL,
  `servletContextName` varchar(75) DEFAULT NULL,
  `buildNumber` int(11) DEFAULT NULL,
  `buildDate` datetime DEFAULT NULL,
  `verified` tinyint(4) DEFAULT NULL,
  `testString` varchar(1024) DEFAULT NULL,
  PRIMARY KEY (`releaseId`),
  KEY `IX_8BD6BCA7` (`servletContextName`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Release_`
--

LOCK TABLES `Release_` WRITE;
/*!40000 ALTER TABLE `Release_` DISABLE KEYS */;
INSERT INTO `Release_` VALUES (1,'2014-04-03 09:33:29','2014-04-03 16:33:34','portal',6011,'2011-01-13 00:00:00',1,'You take the blue pill, the story ends, you wake up in your bed and believe whatever you want to believe. You take the red pill, you stay in Wonderland, and I show you how deep the rabbit hole goes.'),(10305,'2014-04-03 16:34:05','2014-04-03 16:34:05','social-networking-portlet',100,NULL,1,'');
/*!40000 ALTER TABLE `Release_` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ResourceAction`
--

DROP TABLE IF EXISTS `ResourceAction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ResourceAction` (
  `resourceActionId` bigint(20) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `actionId` varchar(75) DEFAULT NULL,
  `bitwiseValue` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`resourceActionId`),
  UNIQUE KEY `IX_EDB9986E` (`name`,`actionId`),
  KEY `IX_81F2DB09` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ResourceAction`
--

LOCK TABLES `ResourceAction` WRITE;
/*!40000 ALTER TABLE `ResourceAction` DISABLE KEYS */;
INSERT INTO `ResourceAction` VALUES (1,'com.liferay.portlet.softwarecatalog','ADD_FRAMEWORK_VERSION',2),(2,'com.liferay.portlet.softwarecatalog','ADD_PRODUCT_ENTRY',4),(3,'com.liferay.portlet.softwarecatalog','PERMISSIONS',8),(4,'com.liferay.portal.model.Team','ASSIGN_MEMBERS',2),(5,'com.liferay.portal.model.Team','DELETE',4),(6,'com.liferay.portal.model.Team','PERMISSIONS',8),(7,'com.liferay.portal.model.Team','UPDATE',16),(8,'com.liferay.portal.model.Team','VIEW',1),(9,'com.liferay.portal.model.PasswordPolicy','ASSIGN_MEMBERS',2),(10,'com.liferay.portal.model.PasswordPolicy','DELETE',4),(11,'com.liferay.portal.model.PasswordPolicy','PERMISSIONS',8),(12,'com.liferay.portal.model.PasswordPolicy','UPDATE',16),(13,'com.liferay.portal.model.PasswordPolicy','VIEW',1),(14,'com.liferay.portlet.blogs.model.BlogsEntry','ADD_DISCUSSION',2),(15,'com.liferay.portlet.blogs.model.BlogsEntry','DELETE',4),(16,'com.liferay.portlet.blogs.model.BlogsEntry','DELETE_DISCUSSION',8),(17,'com.liferay.portlet.blogs.model.BlogsEntry','PERMISSIONS',16),(18,'com.liferay.portlet.blogs.model.BlogsEntry','UPDATE',32),(19,'com.liferay.portlet.blogs.model.BlogsEntry','UPDATE_DISCUSSION',64),(20,'com.liferay.portlet.blogs.model.BlogsEntry','VIEW',1),(21,'com.liferay.portlet.journal.model.JournalFeed','DELETE',2),(22,'com.liferay.portlet.journal.model.JournalFeed','PERMISSIONS',4),(23,'com.liferay.portlet.journal.model.JournalFeed','UPDATE',8),(24,'com.liferay.portlet.journal.model.JournalFeed','VIEW',1),(25,'com.liferay.portlet.wiki.model.WikiNode','ADD_ATTACHMENT',2),(26,'com.liferay.portlet.wiki.model.WikiNode','ADD_PAGE',4),(27,'com.liferay.portlet.wiki.model.WikiNode','DELETE',8),(28,'com.liferay.portlet.wiki.model.WikiNode','IMPORT',16),(29,'com.liferay.portlet.wiki.model.WikiNode','PERMISSIONS',32),(30,'com.liferay.portlet.wiki.model.WikiNode','SUBSCRIBE',64),(31,'com.liferay.portlet.wiki.model.WikiNode','UPDATE',128),(32,'com.liferay.portlet.wiki.model.WikiNode','VIEW',1),(33,'com.liferay.portlet.announcements.model.AnnouncementsEntry','DELETE',2),(34,'com.liferay.portlet.announcements.model.AnnouncementsEntry','UPDATE',4),(35,'com.liferay.portlet.announcements.model.AnnouncementsEntry','VIEW',1),(36,'com.liferay.portlet.announcements.model.AnnouncementsEntry','PERMISSIONS',8),(37,'com.liferay.portlet.bookmarks','ADD_ENTRY',2),(38,'com.liferay.portlet.bookmarks','ADD_FOLDER',4),(39,'com.liferay.portlet.bookmarks','PERMISSIONS',8),(40,'com.liferay.portlet.asset.model.AssetVocabulary','DELETE',2),(41,'com.liferay.portlet.asset.model.AssetVocabulary','PERMISSIONS',4),(42,'com.liferay.portlet.asset.model.AssetVocabulary','UPDATE',8),(43,'com.liferay.portlet.asset.model.AssetVocabulary','VIEW',1),(44,'com.liferay.portlet.documentlibrary.model.DLFolder','ACCESS',2),(45,'com.liferay.portlet.documentlibrary.model.DLFolder','ADD_DOCUMENT',4),(46,'com.liferay.portlet.documentlibrary.model.DLFolder','ADD_SHORTCUT',8),(47,'com.liferay.portlet.documentlibrary.model.DLFolder','ADD_SUBFOLDER',16),(48,'com.liferay.portlet.documentlibrary.model.DLFolder','DELETE',32),(49,'com.liferay.portlet.documentlibrary.model.DLFolder','PERMISSIONS',64),(50,'com.liferay.portlet.documentlibrary.model.DLFolder','UPDATE',128),(51,'com.liferay.portlet.documentlibrary.model.DLFolder','VIEW',1),(52,'com.liferay.portlet.expando.model.ExpandoColumn','DELETE',2),(53,'com.liferay.portlet.expando.model.ExpandoColumn','PERMISSIONS',4),(54,'com.liferay.portlet.expando.model.ExpandoColumn','UPDATE',8),(55,'com.liferay.portlet.expando.model.ExpandoColumn','VIEW',1),(56,'com.liferay.portlet.documentlibrary','ADD_DOCUMENT',2),(57,'com.liferay.portlet.documentlibrary','ADD_FOLDER',4),(58,'com.liferay.portlet.documentlibrary','ADD_SHORTCUT',8),(59,'com.liferay.portlet.documentlibrary','PERMISSIONS',16),(60,'com.liferay.portlet.documentlibrary','VIEW',1),(61,'com.liferay.portlet.calendar.model.CalEvent','ADD_DISCUSSION',2),(62,'com.liferay.portlet.calendar.model.CalEvent','DELETE',4),(63,'com.liferay.portlet.calendar.model.CalEvent','DELETE_DISCUSSION',8),(64,'com.liferay.portlet.calendar.model.CalEvent','PERMISSIONS',16),(65,'com.liferay.portlet.calendar.model.CalEvent','UPDATE',32),(66,'com.liferay.portlet.calendar.model.CalEvent','UPDATE_DISCUSSION',64),(67,'com.liferay.portlet.calendar.model.CalEvent','VIEW',1),(68,'com.liferay.portlet.shopping.model.ShoppingCategory','ADD_ITEM',2),(69,'com.liferay.portlet.shopping.model.ShoppingCategory','ADD_SUBCATEGORY',4),(70,'com.liferay.portlet.shopping.model.ShoppingCategory','DELETE',8),(71,'com.liferay.portlet.shopping.model.ShoppingCategory','PERMISSIONS',16),(72,'com.liferay.portlet.shopping.model.ShoppingCategory','UPDATE',32),(73,'com.liferay.portlet.shopping.model.ShoppingCategory','VIEW',1),(74,'com.liferay.portlet.documentlibrary.model.DLFileShortcut','ADD_DISCUSSION',2),(75,'com.liferay.portlet.documentlibrary.model.DLFileShortcut','DELETE',4),(76,'com.liferay.portlet.documentlibrary.model.DLFileShortcut','DELETE_DISCUSSION',8),(77,'com.liferay.portlet.documentlibrary.model.DLFileShortcut','PERMISSIONS',16),(78,'com.liferay.portlet.documentlibrary.model.DLFileShortcut','UPDATE',32),(79,'com.liferay.portlet.documentlibrary.model.DLFileShortcut','UPDATE_DISCUSSION',64),(80,'com.liferay.portlet.documentlibrary.model.DLFileShortcut','VIEW',1),(81,'com.liferay.portlet.journal','ADD_ARTICLE',2),(82,'com.liferay.portlet.journal','ADD_FEED',4),(83,'com.liferay.portlet.journal','ADD_STRUCTURE',8),(84,'com.liferay.portlet.journal','ADD_TEMPLATE',16),(85,'com.liferay.portlet.journal','SUBSCRIBE',32),(86,'com.liferay.portlet.journal','PERMISSIONS',64),(87,'com.liferay.portlet.calendar','ADD_EVENT',2),(88,'com.liferay.portlet.calendar','EXPORT_ALL_EVENTS',4),(89,'com.liferay.portlet.calendar','PERMISSIONS',8),(90,'com.liferay.portal.model.LayoutPrototype','DELETE',2),(91,'com.liferay.portal.model.LayoutPrototype','PERMISSIONS',4),(92,'com.liferay.portal.model.LayoutPrototype','UPDATE',8),(93,'com.liferay.portal.model.LayoutPrototype','VIEW',1),(94,'com.liferay.portlet.tasks.model.TasksProposal','ADD_DISCUSSION',2),(95,'com.liferay.portlet.tasks.model.TasksProposal','DELETE',4),(96,'com.liferay.portlet.tasks.model.TasksProposal','DELETE_DISCUSSION',8),(97,'com.liferay.portlet.tasks.model.TasksProposal','UPDATE',16),(98,'com.liferay.portlet.tasks.model.TasksProposal','UPDATE_DISCUSSION',32),(99,'com.liferay.portlet.tasks.model.TasksProposal','VIEW',1),(100,'com.liferay.portlet.tasks.model.TasksProposal','PERMISSIONS',64),(101,'com.liferay.portal.model.Organization','APPROVE_PROPOSAL',2),(102,'com.liferay.portal.model.Organization','ASSIGN_MEMBERS',4),(103,'com.liferay.portal.model.Organization','ASSIGN_REVIEWER',8),(104,'com.liferay.portal.model.Organization','ASSIGN_USER_ROLES',16),(105,'com.liferay.portal.model.Organization','DELETE',32),(106,'com.liferay.portal.model.Organization','MANAGE_ANNOUNCEMENTS',64),(107,'com.liferay.portal.model.Organization','MANAGE_ARCHIVED_SETUPS',128),(108,'com.liferay.portal.model.Organization','MANAGE_LAYOUTS',256),(109,'com.liferay.portal.model.Organization','MANAGE_STAGING',512),(110,'com.liferay.portal.model.Organization','MANAGE_SUBORGANIZATIONS',1024),(111,'com.liferay.portal.model.Organization','MANAGE_TEAMS',2048),(112,'com.liferay.portal.model.Organization','MANAGE_USERS',4096),(113,'com.liferay.portal.model.Organization','PERMISSIONS',8192),(114,'com.liferay.portal.model.Organization','PUBLISH_STAGING',16384),(115,'com.liferay.portal.model.Organization','UPDATE',32768),(116,'com.liferay.portal.model.Organization','VIEW',1),(117,'com.liferay.portlet.imagegallery','ADD_FOLDER',2),(118,'com.liferay.portlet.imagegallery','ADD_IMAGE',4),(119,'com.liferay.portlet.imagegallery','PERMISSIONS',8),(120,'com.liferay.portlet.imagegallery','VIEW',1),(121,'com.liferay.portlet.softwarecatalog.model.SCLicense','DELETE',2),(122,'com.liferay.portlet.softwarecatalog.model.SCLicense','PERMISSIONS',4),(123,'com.liferay.portlet.softwarecatalog.model.SCLicense','UPDATE',8),(124,'com.liferay.portlet.softwarecatalog.model.SCLicense','VIEW',1),(125,'com.liferay.portlet.journal.model.JournalTemplate','DELETE',2),(126,'com.liferay.portlet.journal.model.JournalTemplate','PERMISSIONS',4),(127,'com.liferay.portlet.journal.model.JournalTemplate','UPDATE',8),(128,'com.liferay.portlet.journal.model.JournalTemplate','VIEW',1),(129,'com.liferay.portlet.journal.model.JournalArticle','ADD_DISCUSSION',2),(130,'com.liferay.portlet.journal.model.JournalArticle','DELETE',4),(131,'com.liferay.portlet.journal.model.JournalArticle','DELETE_DISCUSSION',8),(132,'com.liferay.portlet.journal.model.JournalArticle','EXPIRE',16),(133,'com.liferay.portlet.journal.model.JournalArticle','PERMISSIONS',32),(134,'com.liferay.portlet.journal.model.JournalArticle','UPDATE',64),(135,'com.liferay.portlet.journal.model.JournalArticle','UPDATE_DISCUSSION',128),(136,'com.liferay.portlet.journal.model.JournalArticle','VIEW',1),(137,'com.liferay.portlet.bookmarks.model.BookmarksFolder','ACCESS',2),(138,'com.liferay.portlet.bookmarks.model.BookmarksFolder','ADD_ENTRY',4),(139,'com.liferay.portlet.bookmarks.model.BookmarksFolder','ADD_SUBFOLDER',8),(140,'com.liferay.portlet.bookmarks.model.BookmarksFolder','DELETE',16),(141,'com.liferay.portlet.bookmarks.model.BookmarksFolder','PERMISSIONS',32),(142,'com.liferay.portlet.bookmarks.model.BookmarksFolder','UPDATE',64),(143,'com.liferay.portlet.bookmarks.model.BookmarksFolder','VIEW',1),(144,'com.liferay.portal.model.Group','APPROVE_PROPOSAL',2),(145,'com.liferay.portal.model.Group','ASSIGN_MEMBERS',4),(146,'com.liferay.portal.model.Group','ASSIGN_REVIEWER',8),(147,'com.liferay.portal.model.Group','ASSIGN_USER_ROLES',16),(148,'com.liferay.portal.model.Group','DELETE',32),(149,'com.liferay.portal.model.Group','MANAGE_ANNOUNCEMENTS',64),(150,'com.liferay.portal.model.Group','MANAGE_ARCHIVED_SETUPS',128),(151,'com.liferay.portal.model.Group','MANAGE_LAYOUTS',256),(152,'com.liferay.portal.model.Group','MANAGE_STAGING',512),(153,'com.liferay.portal.model.Group','MANAGE_TEAMS',1024),(154,'com.liferay.portal.model.Group','PERMISSIONS',2048),(155,'com.liferay.portal.model.Group','PUBLISH_STAGING',4096),(156,'com.liferay.portal.model.Group','PUBLISH_TO_REMOTE',8192),(157,'com.liferay.portal.model.Group','UPDATE',16384),(158,'com.liferay.portlet.journal.model.JournalStructure','DELETE',2),(159,'com.liferay.portlet.journal.model.JournalStructure','PERMISSIONS',4),(160,'com.liferay.portlet.journal.model.JournalStructure','UPDATE',8),(161,'com.liferay.portlet.journal.model.JournalStructure','VIEW',1),(162,'com.liferay.portlet.asset.model.AssetTag','DELETE',2),(163,'com.liferay.portlet.asset.model.AssetTag','PERMISSIONS',4),(164,'com.liferay.portlet.asset.model.AssetTag','UPDATE',8),(165,'com.liferay.portlet.asset.model.AssetTag','VIEW',1),(166,'com.liferay.portal.model.Layout','ADD_DISCUSSION',2),(167,'com.liferay.portal.model.Layout','DELETE',4),(168,'com.liferay.portal.model.Layout','DELETE_DISCUSSION',8),(169,'com.liferay.portal.model.Layout','UPDATE',16),(170,'com.liferay.portal.model.Layout','UPDATE_DISCUSSION',32),(171,'com.liferay.portal.model.Layout','VIEW',1),(172,'com.liferay.portal.model.Layout','PERMISSIONS',64),(173,'com.liferay.portlet.imagegallery.model.IGImage','DELETE',2),(174,'com.liferay.portlet.imagegallery.model.IGImage','PERMISSIONS',4),(175,'com.liferay.portlet.imagegallery.model.IGImage','UPDATE',8),(176,'com.liferay.portlet.imagegallery.model.IGImage','VIEW',1),(177,'com.liferay.portlet.asset','ADD_CATEGORY',2),(178,'com.liferay.portlet.asset','ADD_VOCABULARY',4),(179,'com.liferay.portlet.asset','ADD_TAG',8),(180,'com.liferay.portlet.asset','PERMISSIONS',16),(181,'com.liferay.portlet.messageboards','ADD_CATEGORY',2),(182,'com.liferay.portlet.messageboards','ADD_FILE',4),(183,'com.liferay.portlet.messageboards','ADD_MESSAGE',8),(184,'com.liferay.portlet.messageboards','BAN_USER',16),(185,'com.liferay.portlet.messageboards','MOVE_THREAD',32),(186,'com.liferay.portlet.messageboards','LOCK_THREAD',64),(187,'com.liferay.portlet.messageboards','PERMISSIONS',128),(188,'com.liferay.portlet.messageboards','REPLY_TO_MESSAGE',256),(189,'com.liferay.portlet.messageboards','SUBSCRIBE',512),(190,'com.liferay.portlet.messageboards','UPDATE_THREAD_PRIORITY',1024),(191,'com.liferay.portlet.polls','ADD_QUESTION',2),(192,'com.liferay.portlet.polls','PERMISSIONS',4),(193,'com.liferay.portlet.shopping.model.ShoppingItem','DELETE',2),(194,'com.liferay.portlet.shopping.model.ShoppingItem','PERMISSIONS',4),(195,'com.liferay.portlet.shopping.model.ShoppingItem','UPDATE',8),(196,'com.liferay.portlet.shopping.model.ShoppingItem','VIEW',1),(197,'com.liferay.portlet.bookmarks.model.BookmarksEntry','DELETE',2),(198,'com.liferay.portlet.bookmarks.model.BookmarksEntry','PERMISSIONS',4),(199,'com.liferay.portlet.bookmarks.model.BookmarksEntry','UPDATE',8),(200,'com.liferay.portlet.bookmarks.model.BookmarksEntry','VIEW',1),(201,'com.liferay.portlet.softwarecatalog.model.SCProductEntry','ADD_DISCUSSION',2),(202,'com.liferay.portlet.softwarecatalog.model.SCProductEntry','DELETE',4),(203,'com.liferay.portlet.softwarecatalog.model.SCProductEntry','DELETE_DISCUSSION',8),(204,'com.liferay.portlet.softwarecatalog.model.SCProductEntry','PERMISSIONS',16),(205,'com.liferay.portlet.softwarecatalog.model.SCProductEntry','UPDATE',32),(206,'com.liferay.portlet.softwarecatalog.model.SCProductEntry','UPDATE_DISCUSSION',64),(207,'com.liferay.portlet.softwarecatalog.model.SCProductEntry','VIEW',1),(208,'com.liferay.portal.model.User','DELETE',2),(209,'com.liferay.portal.model.User','IMPERSONATE',4),(210,'com.liferay.portal.model.User','PERMISSIONS',8),(211,'com.liferay.portal.model.User','UPDATE',16),(212,'com.liferay.portal.model.User','VIEW',1),(213,'com.liferay.portal.model.LayoutSetPrototype','DELETE',2),(214,'com.liferay.portal.model.LayoutSetPrototype','PERMISSIONS',4),(215,'com.liferay.portal.model.LayoutSetPrototype','UPDATE',8),(216,'com.liferay.portal.model.LayoutSetPrototype','VIEW',1),(217,'com.liferay.portlet.shopping','ADD_CATEGORY',2),(218,'com.liferay.portlet.shopping','ADD_ITEM',4),(219,'com.liferay.portlet.shopping','MANAGE_COUPONS',8),(220,'com.liferay.portlet.shopping','MANAGE_ORDERS',16),(221,'com.liferay.portlet.shopping','PERMISSIONS',32),(222,'com.liferay.portlet.softwarecatalog.model.SCFrameworkVersion','DELETE',2),(223,'com.liferay.portlet.softwarecatalog.model.SCFrameworkVersion','PERMISSIONS',4),(224,'com.liferay.portlet.softwarecatalog.model.SCFrameworkVersion','UPDATE',8),(225,'com.liferay.portlet.wiki','ADD_NODE',2),(226,'com.liferay.portlet.wiki','PERMISSIONS',4),(227,'com.liferay.portlet.polls.model.PollsQuestion','ADD_VOTE',2),(228,'com.liferay.portlet.polls.model.PollsQuestion','DELETE',4),(229,'com.liferay.portlet.polls.model.PollsQuestion','PERMISSIONS',8),(230,'com.liferay.portlet.polls.model.PollsQuestion','UPDATE',16),(231,'com.liferay.portlet.polls.model.PollsQuestion','VIEW',1),(232,'com.liferay.portal.model.UserGroup','ASSIGN_MEMBERS',2),(233,'com.liferay.portal.model.UserGroup','DELETE',4),(234,'com.liferay.portal.model.UserGroup','MANAGE_ANNOUNCEMENTS',8),(235,'com.liferay.portal.model.UserGroup','PERMISSIONS',16),(236,'com.liferay.portal.model.UserGroup','MANAGE_LAYOUTS',32),(237,'com.liferay.portal.model.UserGroup','UPDATE',64),(238,'com.liferay.portal.model.UserGroup','VIEW',1),(239,'com.liferay.portlet.shopping.model.ShoppingOrder','DELETE',2),(240,'com.liferay.portlet.shopping.model.ShoppingOrder','PERMISSIONS',4),(241,'com.liferay.portlet.shopping.model.ShoppingOrder','UPDATE',8),(242,'com.liferay.portlet.shopping.model.ShoppingOrder','VIEW',1),(243,'com.liferay.portlet.imagegallery.model.IGFolder','ACCESS',2),(244,'com.liferay.portlet.imagegallery.model.IGFolder','ADD_IMAGE',4),(245,'com.liferay.portlet.imagegallery.model.IGFolder','ADD_SUBFOLDER',8),(246,'com.liferay.portlet.imagegallery.model.IGFolder','DELETE',16),(247,'com.liferay.portlet.imagegallery.model.IGFolder','PERMISSIONS',32),(248,'com.liferay.portlet.imagegallery.model.IGFolder','UPDATE',64),(249,'com.liferay.portlet.imagegallery.model.IGFolder','VIEW',1),(250,'com.liferay.portal.model.Role','ASSIGN_MEMBERS',2),(251,'com.liferay.portal.model.Role','DEFINE_PERMISSIONS',4),(252,'com.liferay.portal.model.Role','DELETE',8),(253,'com.liferay.portal.model.Role','MANAGE_ANNOUNCEMENTS',16),(254,'com.liferay.portal.model.Role','PERMISSIONS',32),(255,'com.liferay.portal.model.Role','UPDATE',64),(256,'com.liferay.portal.model.Role','VIEW',1),(257,'com.liferay.portlet.messageboards.model.MBCategory','ADD_FILE',2),(258,'com.liferay.portlet.messageboards.model.MBCategory','ADD_MESSAGE',4),(259,'com.liferay.portlet.messageboards.model.MBCategory','ADD_SUBCATEGORY',8),(260,'com.liferay.portlet.messageboards.model.MBCategory','DELETE',16),(261,'com.liferay.portlet.messageboards.model.MBCategory','LOCK_THREAD',32),(262,'com.liferay.portlet.messageboards.model.MBCategory','MOVE_THREAD',64),(263,'com.liferay.portlet.messageboards.model.MBCategory','PERMISSIONS',128),(264,'com.liferay.portlet.messageboards.model.MBCategory','REPLY_TO_MESSAGE',256),(265,'com.liferay.portlet.messageboards.model.MBCategory','SUBSCRIBE',512),(266,'com.liferay.portlet.messageboards.model.MBCategory','UPDATE',1024),(267,'com.liferay.portlet.messageboards.model.MBCategory','UPDATE_THREAD_PRIORITY',2048),(268,'com.liferay.portlet.messageboards.model.MBCategory','VIEW',1),(269,'com.liferay.portlet.wiki.model.WikiPage','ADD_DISCUSSION',2),(270,'com.liferay.portlet.wiki.model.WikiPage','DELETE',4),(271,'com.liferay.portlet.wiki.model.WikiPage','DELETE_DISCUSSION',8),(272,'com.liferay.portlet.wiki.model.WikiPage','PERMISSIONS',16),(273,'com.liferay.portlet.wiki.model.WikiPage','SUBSCRIBE',32),(274,'com.liferay.portlet.wiki.model.WikiPage','UPDATE',64),(275,'com.liferay.portlet.wiki.model.WikiPage','UPDATE_DISCUSSION',128),(276,'com.liferay.portlet.wiki.model.WikiPage','VIEW',1),(277,'com.liferay.portlet.asset.model.AssetCategory','ADD_CATEGORY',2),(278,'com.liferay.portlet.asset.model.AssetCategory','DELETE',4),(279,'com.liferay.portlet.asset.model.AssetCategory','PERMISSIONS',8),(280,'com.liferay.portlet.asset.model.AssetCategory','UPDATE',16),(281,'com.liferay.portlet.asset.model.AssetCategory','VIEW',1),(282,'com.liferay.portlet.messageboards.model.MBMessage','DELETE',2),(283,'com.liferay.portlet.messageboards.model.MBMessage','PERMISSIONS',4),(284,'com.liferay.portlet.messageboards.model.MBMessage','SUBSCRIBE',8),(285,'com.liferay.portlet.messageboards.model.MBMessage','UPDATE',16),(286,'com.liferay.portlet.messageboards.model.MBMessage','VIEW',1),(287,'com.liferay.portlet.blogs','ADD_ENTRY',2),(288,'com.liferay.portlet.blogs','PERMISSIONS',4),(289,'com.liferay.portlet.blogs','SUBSCRIBE',8),(290,'com.liferay.portlet.documentlibrary.model.DLFileEntry','ADD_DISCUSSION',2),(291,'com.liferay.portlet.documentlibrary.model.DLFileEntry','DELETE',4),(292,'com.liferay.portlet.documentlibrary.model.DLFileEntry','DELETE_DISCUSSION',8),(293,'com.liferay.portlet.documentlibrary.model.DLFileEntry','PERMISSIONS',16),(294,'com.liferay.portlet.documentlibrary.model.DLFileEntry','UPDATE',32),(295,'com.liferay.portlet.documentlibrary.model.DLFileEntry','UPDATE_DISCUSSION',64),(296,'com.liferay.portlet.documentlibrary.model.DLFileEntry','VIEW',1),(297,'98','ACCESS_IN_CONTROL_PANEL',2),(298,'98','ADD_TO_PAGE',4),(299,'98','CONFIGURATION',8),(300,'98','VIEW',1),(301,'66','VIEW',1),(302,'66','ADD_TO_PAGE',2),(303,'66','CONFIGURATION',4),(304,'156','VIEW',1),(305,'156','ADD_TO_PAGE',2),(306,'156','CONFIGURATION',4),(307,'152','ACCESS_IN_CONTROL_PANEL',2),(308,'152','CONFIGURATION',4),(309,'152','VIEW',1),(310,'27','VIEW',1),(311,'27','ADD_TO_PAGE',2),(312,'27','CONFIGURATION',4),(313,'88','VIEW',1),(314,'88','ADD_TO_PAGE',2),(315,'88','CONFIGURATION',4),(316,'87','VIEW',1),(317,'87','ADD_TO_PAGE',2),(318,'87','CONFIGURATION',4),(319,'134','ACCESS_IN_CONTROL_PANEL',2),(320,'134','CONFIGURATION',4),(321,'134','VIEW',1),(322,'130','ACCESS_IN_CONTROL_PANEL',2),(323,'130','CONFIGURATION',4),(324,'130','VIEW',1),(325,'122','VIEW',1),(326,'122','ADD_TO_PAGE',2),(327,'122','CONFIGURATION',4),(328,'36','ADD_TO_PAGE',2),(329,'36','CONFIGURATION',4),(330,'36','VIEW',1),(331,'26','VIEW',1),(332,'26','ADD_TO_PAGE',2),(333,'26','CONFIGURATION',4),(334,'104','VIEW',1),(335,'104','ADD_TO_PAGE',2),(336,'104','CONFIGURATION',4),(337,'64','VIEW',1),(338,'64','ADD_TO_PAGE',2),(339,'64','CONFIGURATION',4),(340,'153','ACCESS_IN_CONTROL_PANEL',2),(341,'153','CONFIGURATION',4),(342,'153','VIEW',1),(343,'129','ACCESS_IN_CONTROL_PANEL',2),(344,'129','CONFIGURATION',4),(345,'129','VIEW',1),(346,'100','VIEW',1),(347,'100','ADD_TO_PAGE',2),(348,'100','CONFIGURATION',4),(349,'157','ACCESS_IN_CONTROL_PANEL',2),(350,'157','CONFIGURATION',4),(351,'157','VIEW',1),(352,'19','ACCESS_IN_CONTROL_PANEL',2),(353,'19','ADD_TO_PAGE',4),(354,'19','CONFIGURATION',8),(355,'19','VIEW',1),(356,'160','VIEW',1),(357,'160','ADD_TO_PAGE',2),(358,'160','CONFIGURATION',4),(359,'128','ACCESS_IN_CONTROL_PANEL',2),(360,'128','CONFIGURATION',4),(361,'128','VIEW',1),(362,'86','VIEW',1),(363,'86','ADD_TO_PAGE',2),(364,'86','CONFIGURATION',4),(365,'154','ACCESS_IN_CONTROL_PANEL',2),(366,'154','CONFIGURATION',4),(367,'154','VIEW',1),(368,'148','VIEW',1),(369,'148','ADD_TO_PAGE',2),(370,'148','CONFIGURATION',4),(371,'11','ADD_TO_PAGE',2),(372,'11','CONFIGURATION',4),(373,'11','VIEW',1),(374,'120','VIEW',1),(375,'120','ADD_TO_PAGE',2),(376,'120','CONFIGURATION',4),(377,'29','ADD_TO_PAGE',2),(378,'29','CONFIGURATION',4),(379,'29','VIEW',1),(380,'158','ACCESS_IN_CONTROL_PANEL',2),(381,'158','CONFIGURATION',4),(382,'158','VIEW',1),(383,'124','VIEW',1),(384,'124','ADD_TO_PAGE',2),(385,'124','CONFIGURATION',4),(386,'8','ACCESS_IN_CONTROL_PANEL',2),(387,'8','ADD_TO_PAGE',4),(388,'8','CONFIGURATION',8),(389,'8','VIEW',1),(390,'58','ADD_TO_PAGE',2),(391,'58','CONFIGURATION',4),(392,'58','VIEW',1),(393,'155','ACCESS_IN_CONTROL_PANEL',2),(394,'155','VIEW',1),(395,'155','CONFIGURATION',4),(396,'97','VIEW',1),(397,'97','ADD_TO_PAGE',2),(398,'97','CONFIGURATION',4),(399,'71','ADD_TO_PAGE',2),(400,'71','CONFIGURATION',4),(401,'71','VIEW',1),(402,'39','VIEW',1),(403,'39','ADD_TO_PAGE',2),(404,'39','CONFIGURATION',4),(405,'85','ADD_TO_PAGE',2),(406,'85','CONFIGURATION',4),(407,'85','VIEW',1),(408,'118','VIEW',1),(409,'118','ADD_TO_PAGE',2),(410,'118','CONFIGURATION',4),(411,'107','VIEW',1),(412,'107','ADD_TO_PAGE',2),(413,'107','CONFIGURATION',4),(414,'79','CONFIGURATION',2),(415,'79','VIEW',1),(416,'79','ADD_TO_PAGE',4),(417,'30','VIEW',1),(418,'30','ADD_TO_PAGE',2),(419,'30','CONFIGURATION',4),(420,'147','ACCESS_IN_CONTROL_PANEL',2),(421,'147','CONFIGURATION',4),(422,'147','VIEW',1),(423,'48','VIEW',1),(424,'48','ADD_TO_PAGE',2),(425,'48','CONFIGURATION',4),(426,'125','ACCESS_IN_CONTROL_PANEL',2),(427,'125','CONFIGURATION',4),(428,'125','EXPORT_USER',8),(429,'125','VIEW',1),(430,'144','VIEW',1),(431,'144','ADD_TO_PAGE',2),(432,'144','CONFIGURATION',4),(433,'146','ACCESS_IN_CONTROL_PANEL',2),(434,'146','CONFIGURATION',4),(435,'146','VIEW',1),(436,'62','VIEW',1),(437,'62','ADD_TO_PAGE',2),(438,'62','CONFIGURATION',4),(439,'159','VIEW',1),(440,'159','ADD_TO_PAGE',2),(441,'159','CONFIGURATION',4),(442,'108','VIEW',1),(443,'108','ADD_TO_PAGE',2),(444,'108','CONFIGURATION',4),(445,'139','ACCESS_IN_CONTROL_PANEL',2),(446,'139','ADD_EXPANDO',4),(447,'139','CONFIGURATION',8),(448,'139','VIEW',1),(449,'84','ADD_ENTRY',2),(450,'84','ADD_TO_PAGE',4),(451,'84','CONFIGURATION',8),(452,'84','VIEW',1),(453,'101','VIEW',1),(454,'101','ADD_TO_PAGE',2),(455,'101','CONFIGURATION',4),(456,'121','VIEW',1),(457,'121','ADD_TO_PAGE',2),(458,'121','CONFIGURATION',4),(459,'49','VIEW',1),(460,'49','ADD_TO_PAGE',2),(461,'49','CONFIGURATION',4),(462,'143','VIEW',1),(463,'143','ADD_TO_PAGE',2),(464,'143','CONFIGURATION',4),(465,'37','VIEW',1),(466,'37','ADD_TO_PAGE',2),(467,'37','CONFIGURATION',4),(468,'77','VIEW',1),(469,'77','ADD_TO_PAGE',2),(470,'77','CONFIGURATION',4),(471,'115','VIEW',1),(472,'115','ADD_TO_PAGE',2),(473,'115','CONFIGURATION',4),(474,'56','ADD_TO_PAGE',2),(475,'56','CONFIGURATION',4),(476,'56','VIEW',1),(477,'142','VIEW',1),(478,'142','ADD_TO_PAGE',2),(479,'142','CONFIGURATION',4),(480,'111','VIEW',1),(481,'111','ADD_TO_PAGE',2),(482,'111','CONFIGURATION',4),(483,'16','PREFERENCES',2),(484,'16','GUEST_PREFERENCES',4),(485,'16','VIEW',1),(486,'16','ADD_TO_PAGE',8),(487,'16','CONFIGURATION',16),(488,'3','VIEW',1),(489,'3','ADD_TO_PAGE',2),(490,'3','CONFIGURATION',4),(491,'20','ACCESS_IN_CONTROL_PANEL',2),(492,'20','ADD_TO_PAGE',4),(493,'20','CONFIGURATION',8),(494,'20','VIEW',1),(495,'23','VIEW',1),(496,'23','ADD_TO_PAGE',2),(497,'23','CONFIGURATION',4),(498,'145','VIEW',1),(499,'145','ADD_TO_PAGE',2),(500,'145','CONFIGURATION',4),(501,'83','ADD_ENTRY',2),(502,'83','ADD_TO_PAGE',4),(503,'83','CONFIGURATION',8),(504,'83','VIEW',1),(505,'99','ACCESS_IN_CONTROL_PANEL',2),(506,'99','CONFIGURATION',4),(507,'99','VIEW',1),(508,'70','VIEW',1),(509,'70','ADD_TO_PAGE',2),(510,'70','CONFIGURATION',4),(511,'141','VIEW',1),(512,'141','ADD_TO_PAGE',2),(513,'141','CONFIGURATION',4),(514,'9','VIEW',1),(515,'9','ADD_TO_PAGE',2),(516,'9','CONFIGURATION',4),(517,'137','ACCESS_IN_CONTROL_PANEL',2),(518,'137','CONFIGURATION',4),(519,'137','VIEW',1),(520,'28','ACCESS_IN_CONTROL_PANEL',2),(521,'28','ADD_TO_PAGE',4),(522,'28','CONFIGURATION',8),(523,'28','VIEW',1),(524,'133','VIEW',1),(525,'133','ADD_TO_PAGE',2),(526,'133','CONFIGURATION',4),(527,'116','VIEW',1),(528,'116','ADD_TO_PAGE',2),(529,'116','CONFIGURATION',4),(530,'15','ACCESS_IN_CONTROL_PANEL',2),(531,'15','ADD_TO_PAGE',4),(532,'15','CONFIGURATION',8),(533,'15','VIEW',1),(534,'47','VIEW',1),(535,'47','ADD_TO_PAGE',2),(536,'47','CONFIGURATION',4),(537,'82','VIEW',1),(538,'82','ADD_TO_PAGE',2),(539,'82','CONFIGURATION',4),(540,'103','VIEW',1),(541,'103','ADD_TO_PAGE',2),(542,'103','CONFIGURATION',4),(543,'151','ACCESS_IN_CONTROL_PANEL',2),(544,'151','CONFIGURATION',4),(545,'151','VIEW',1),(546,'140','VIEW',1),(547,'140','ADD_TO_PAGE',2),(548,'140','CONFIGURATION',4),(549,'54','VIEW',1),(550,'54','ADD_TO_PAGE',2),(551,'54','CONFIGURATION',4),(552,'132','ACCESS_IN_CONTROL_PANEL',2),(553,'132','CONFIGURATION',4),(554,'132','VIEW',1),(555,'34','ADD_TO_PAGE',2),(556,'34','CONFIGURATION',4),(557,'34','VIEW',1),(558,'61','VIEW',1),(559,'61','ADD_TO_PAGE',2),(560,'61','CONFIGURATION',4),(561,'73','ADD_TO_PAGE',2),(562,'73','CONFIGURATION',4),(563,'73','VIEW',1),(564,'31','ACCESS_IN_CONTROL_PANEL',2),(565,'31','ADD_TO_PAGE',4),(566,'31','CONFIGURATION',8),(567,'31','VIEW',1),(568,'136','ACCESS_IN_CONTROL_PANEL',2),(569,'136','CONFIGURATION',4),(570,'136','VIEW',1),(571,'127','ACCESS_IN_CONTROL_PANEL',2),(572,'127','CONFIGURATION',4),(573,'127','VIEW',1),(574,'50','VIEW',1),(575,'50','ADD_TO_PAGE',2),(576,'50','CONFIGURATION',4),(577,'25','ACCESS_IN_CONTROL_PANEL',2),(578,'25','CONFIGURATION',4),(579,'25','VIEW',1),(580,'90','ADD_COMMUNITY',2),(581,'90','ADD_LAYOUT_PROTOTYPE',4),(582,'90','ADD_LAYOUT_SET_PROTOTYPE',8),(583,'90','ADD_LICENSE',16),(584,'90','ADD_ORGANIZATION',32),(585,'90','ADD_PASSWORD_POLICY',64),(586,'90','ADD_ROLE',128),(587,'90','ADD_USER',256),(588,'90','ADD_USER_GROUP',512),(589,'90','CONFIGURATION',1024),(590,'90','EXPORT_USER',2048),(591,'150','ACCESS_IN_CONTROL_PANEL',2),(592,'150','CONFIGURATION',4),(593,'150','VIEW',1),(594,'113','VIEW',1),(595,'113','ADD_TO_PAGE',2),(596,'113','CONFIGURATION',4),(597,'33','ACCESS_IN_CONTROL_PANEL',2),(598,'33','ADD_TO_PAGE',4),(599,'33','CONFIGURATION',8),(600,'33','VIEW',1),(601,'2','VIEW',1),(602,'2','ADD_TO_PAGE',2),(603,'2','CONFIGURATION',4),(604,'119','VIEW',1),(605,'119','ADD_TO_PAGE',2),(606,'119','CONFIGURATION',4),(607,'126','ACCESS_IN_CONTROL_PANEL',2),(608,'126','CONFIGURATION',4),(609,'126','VIEW',1),(610,'114','VIEW',1),(611,'114','ADD_TO_PAGE',2),(612,'114','CONFIGURATION',4),(613,'149','ACCESS_IN_CONTROL_PANEL',2),(614,'149','CONFIGURATION',4),(615,'149','VIEW',1),(616,'67','VIEW',1),(617,'67','ADD_TO_PAGE',2),(618,'67','CONFIGURATION',4),(619,'110','VIEW',1),(620,'110','ADD_TO_PAGE',2),(621,'110','CONFIGURATION',4),(622,'135','ACCESS_IN_CONTROL_PANEL',2),(623,'135','CONFIGURATION',4),(624,'135','VIEW',1),(625,'59','VIEW',1),(626,'59','ADD_TO_PAGE',2),(627,'59','CONFIGURATION',4),(628,'131','ACCESS_IN_CONTROL_PANEL',2),(629,'131','CONFIGURATION',4),(630,'131','VIEW',1),(631,'102','VIEW',1),(632,'102','ADD_TO_PAGE',2),(633,'102','CONFIGURATION',4),(634,'6_WAR_socialnetworkingportlet','VIEW',1),(635,'6_WAR_socialnetworkingportlet','ADD_TO_PAGE',2),(636,'6_WAR_socialnetworkingportlet','CONFIGURATION',4),(637,'1_WAR_socialnetworkingportlet','VIEW',1),(638,'1_WAR_socialnetworkingportlet','ADD_TO_PAGE',2),(639,'1_WAR_socialnetworkingportlet','CONFIGURATION',4),(640,'3_WAR_socialnetworkingportlet','VIEW',1),(641,'3_WAR_socialnetworkingportlet','ADD_TO_PAGE',2),(642,'3_WAR_socialnetworkingportlet','CONFIGURATION',4),(643,'7_WAR_socialnetworkingportlet','VIEW',1),(644,'7_WAR_socialnetworkingportlet','ADD_TO_PAGE',2),(645,'7_WAR_socialnetworkingportlet','CONFIGURATION',4),(646,'8_WAR_socialnetworkingportlet','VIEW',1),(647,'8_WAR_socialnetworkingportlet','ADD_TO_PAGE',2),(648,'8_WAR_socialnetworkingportlet','CONFIGURATION',4),(649,'4_WAR_socialnetworkingportlet','VIEW',1),(650,'4_WAR_socialnetworkingportlet','ADD_TO_PAGE',2),(651,'4_WAR_socialnetworkingportlet','CONFIGURATION',4),(652,'2_WAR_socialnetworkingportlet','VIEW',1),(653,'2_WAR_socialnetworkingportlet','ADD_TO_PAGE',2),(654,'2_WAR_socialnetworkingportlet','CONFIGURATION',4),(655,'5_WAR_socialnetworkingportlet','VIEW',1),(656,'5_WAR_socialnetworkingportlet','ADD_TO_PAGE',2),(657,'5_WAR_socialnetworkingportlet','CONFIGURATION',4);
/*!40000 ALTER TABLE `ResourceAction` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ResourceCode`
--

DROP TABLE IF EXISTS `ResourceCode`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ResourceCode` (
  `codeId` bigint(20) NOT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `scope` int(11) DEFAULT NULL,
  PRIMARY KEY (`codeId`),
  UNIQUE KEY `IX_A32C097E` (`companyId`,`name`,`scope`),
  KEY `IX_717FDD47` (`companyId`),
  KEY `IX_AACAFF40` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ResourceCode`
--

LOCK TABLES `ResourceCode` WRITE;
/*!40000 ALTER TABLE `ResourceCode` DISABLE KEYS */;
/*!40000 ALTER TABLE `ResourceCode` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ResourcePermission`
--

DROP TABLE IF EXISTS `ResourcePermission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ResourcePermission` (
  `resourcePermissionId` bigint(20) NOT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `scope` int(11) DEFAULT NULL,
  `primKey` varchar(255) DEFAULT NULL,
  `roleId` bigint(20) DEFAULT NULL,
  `actionIds` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`resourcePermissionId`),
  UNIQUE KEY `IX_8D83D0CE` (`companyId`,`name`,`scope`,`primKey`,`roleId`),
  KEY `IX_60B99860` (`companyId`,`name`,`scope`),
  KEY `IX_2200AA69` (`companyId`,`name`,`scope`,`primKey`),
  KEY `IX_A37A0588` (`roleId`),
  KEY `IX_2F80C17C` (`roleId`,`scope`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ResourcePermission`
--

LOCK TABLES `ResourcePermission` WRITE;
/*!40000 ALTER TABLE `ResourcePermission` DISABLE KEYS */;
INSERT INTO `ResourcePermission` VALUES (1,10132,'com.liferay.portal.model.Layout',4,'10152',10140,127),(2,10132,'com.liferay.portal.model.Layout',4,'10152',10144,3),(3,10132,'com.liferay.portal.model.Layout',4,'10152',10139,1),(4,10132,'com.liferay.portal.model.Layout',4,'10160',10140,127),(5,10132,'com.liferay.portal.model.Layout',4,'10160',10144,3),(6,10132,'com.liferay.portal.model.Layout',4,'10160',10139,1),(7,10132,'com.liferay.portal.model.User',4,'10169',10140,31),(8,10132,'98',1,'10132',10141,4),(9,10132,'98',1,'10132',10142,4),(10,10132,'66',1,'10132',10141,2),(11,10132,'66',1,'10132',10142,2),(12,10132,'27',1,'10132',10141,2),(13,10132,'27',1,'10132',10142,2),(14,10132,'122',1,'10132',10139,2),(15,10132,'122',1,'10132',10141,2),(16,10132,'122',1,'10132',10142,2),(17,10132,'36',1,'10132',10141,2),(18,10132,'36',1,'10132',10142,2),(19,10132,'26',1,'10132',10141,2),(20,10132,'26',1,'10132',10142,2),(21,10132,'104',1,'10132',10138,2),(22,10132,'64',1,'10132',10139,2),(23,10132,'64',1,'10132',10141,2),(24,10132,'64',1,'10132',10142,2),(25,10132,'100',1,'10132',10141,2),(26,10132,'100',1,'10132',10142,2),(27,10132,'19',1,'10132',10141,4),(28,10132,'19',1,'10132',10142,4),(29,10132,'148',1,'10132',10139,2),(30,10132,'148',1,'10132',10141,2),(31,10132,'148',1,'10132',10142,2),(32,10132,'11',1,'10132',10141,2),(33,10132,'11',1,'10132',10142,2),(34,10132,'29',1,'10132',10141,2),(35,10132,'29',1,'10132',10142,2),(36,10132,'8',1,'10132',10141,4),(37,10132,'8',1,'10132',10142,4),(38,10132,'58',1,'10132',10139,2),(39,10132,'58',1,'10132',10141,2),(40,10132,'58',1,'10132',10142,2),(41,10132,'71',1,'10132',10139,2),(42,10132,'71',1,'10132',10141,2),(43,10132,'71',1,'10132',10142,2),(44,10132,'97',1,'10132',10141,2),(45,10132,'97',1,'10132',10142,2),(46,10132,'39',1,'10132',10141,2),(47,10132,'39',1,'10132',10142,2),(48,10132,'85',1,'10132',10139,2),(49,10132,'85',1,'10132',10141,2),(50,10132,'85',1,'10132',10142,2),(51,10132,'118',1,'10132',10139,2),(52,10132,'118',1,'10132',10141,2),(53,10132,'118',1,'10132',10142,2),(54,10132,'79',1,'10132',10138,4),(55,10132,'107',1,'10132',10141,2),(56,10132,'107',1,'10132',10142,2),(57,10132,'30',1,'10132',10141,2),(58,10132,'30',1,'10132',10142,2),(59,10132,'48',1,'10132',10141,2),(60,10132,'48',1,'10132',10142,2),(61,10132,'62',1,'10132',10141,2),(62,10132,'62',1,'10132',10142,2),(63,10132,'159',1,'10132',10139,2),(64,10132,'159',1,'10132',10141,2),(65,10132,'159',1,'10132',10142,2),(66,10132,'108',1,'10132',10141,2),(67,10132,'108',1,'10132',10142,2),(68,10132,'84',1,'10132',10141,4),(69,10132,'84',1,'10132',10142,4),(70,10132,'101',1,'10132',10139,2),(71,10132,'101',1,'10132',10141,2),(72,10132,'101',1,'10132',10142,2),(73,10132,'121',1,'10132',10139,2),(74,10132,'121',1,'10132',10141,2),(75,10132,'121',1,'10132',10142,2),(76,10132,'37',1,'10132',10141,2),(77,10132,'37',1,'10132',10142,2),(78,10132,'143',1,'10132',10139,2),(79,10132,'143',1,'10132',10141,2),(80,10132,'143',1,'10132',10142,2),(81,10132,'77',1,'10132',10139,2),(82,10132,'77',1,'10132',10141,2),(83,10132,'77',1,'10132',10142,2),(84,10132,'115',1,'10132',10139,2),(85,10132,'115',1,'10132',10141,2),(86,10132,'115',1,'10132',10142,2),(87,10132,'56',1,'10132',10139,2),(88,10132,'56',1,'10132',10141,2),(89,10132,'56',1,'10132',10142,2),(90,10132,'16',1,'10132',10141,8),(91,10132,'16',1,'10132',10142,8),(92,10132,'111',1,'10132',10138,2),(93,10132,'3',1,'10132',10139,2),(94,10132,'3',1,'10132',10141,2),(95,10132,'3',1,'10132',10142,2),(96,10132,'23',1,'10132',10141,2),(97,10132,'23',1,'10132',10142,2),(98,10132,'20',1,'10132',10139,4),(99,10132,'20',1,'10132',10141,4),(100,10132,'20',1,'10132',10142,4),(101,10132,'83',1,'10132',10141,4),(102,10132,'83',1,'10132',10142,4),(103,10132,'70',1,'10132',10141,2),(104,10132,'70',1,'10132',10142,2),(105,10132,'141',1,'10132',10139,2),(106,10132,'141',1,'10132',10141,2),(107,10132,'141',1,'10132',10142,2),(108,10132,'9',1,'10132',10138,2),(109,10132,'28',1,'10132',10141,4),(110,10132,'28',1,'10132',10142,4),(111,10132,'47',1,'10132',10139,2),(112,10132,'47',1,'10132',10141,2),(113,10132,'47',1,'10132',10142,2),(114,10132,'15',1,'10132',10141,4),(115,10132,'15',1,'10132',10142,4),(116,10132,'116',1,'10132',10139,2),(117,10132,'116',1,'10132',10141,2),(118,10132,'116',1,'10132',10142,2),(119,10132,'82',1,'10132',10139,2),(120,10132,'82',1,'10132',10141,2),(121,10132,'82',1,'10132',10142,2),(122,10132,'54',1,'10132',10141,2),(123,10132,'54',1,'10132',10142,2),(124,10132,'34',1,'10132',10141,2),(125,10132,'34',1,'10132',10142,2),(126,10132,'61',1,'10132',10141,2),(127,10132,'61',1,'10132',10142,2),(128,10132,'73',1,'10132',10139,2),(129,10132,'73',1,'10132',10141,2),(130,10132,'73',1,'10132',10142,2),(131,10132,'31',1,'10132',10139,4),(132,10132,'31',1,'10132',10141,4),(133,10132,'31',1,'10132',10142,4),(134,10132,'50',1,'10132',10139,2),(135,10132,'50',1,'10132',10141,2),(136,10132,'50',1,'10132',10142,2),(137,10132,'33',1,'10132',10139,4),(138,10132,'33',1,'10132',10141,4),(139,10132,'33',1,'10132',10142,4),(140,10132,'114',1,'10132',10139,2),(141,10132,'114',1,'10132',10141,2),(142,10132,'114',1,'10132',10142,2),(143,10132,'67',1,'10132',10141,2),(144,10132,'67',1,'10132',10142,2),(145,10132,'110',1,'10132',10141,2),(146,10132,'110',1,'10132',10142,2),(147,10132,'59',1,'10132',10141,2),(148,10132,'59',1,'10132',10142,2),(149,10132,'102',1,'10132',10139,2),(150,10132,'102',1,'10132',10141,2),(151,10132,'102',1,'10132',10142,2),(152,10132,'com.liferay.portal.model.Role',4,'10287',10140,127),(153,10132,'com.liferay.portal.model.Role',4,'10293',10140,127),(154,10132,'com.liferay.portal.model.Role',4,'10296',10140,127),(155,10132,'com.liferay.portlet.expando.model.ExpandoColumn',4,'10307',10140,15),(156,10132,'6_WAR_socialnetworkingportlet',1,'10132',10138,2),(157,10132,'6_WAR_socialnetworkingportlet',1,'10132',10139,2),(158,10132,'6_WAR_socialnetworkingportlet',1,'10132',10141,2),(159,10132,'6_WAR_socialnetworkingportlet',1,'10132',10142,2),(160,10132,'1_WAR_socialnetworkingportlet',1,'10132',10138,2),(161,10132,'1_WAR_socialnetworkingportlet',1,'10132',10139,2),(162,10132,'1_WAR_socialnetworkingportlet',1,'10132',10141,2),(163,10132,'1_WAR_socialnetworkingportlet',1,'10132',10142,2),(164,10132,'3_WAR_socialnetworkingportlet',1,'10132',10138,2),(165,10132,'3_WAR_socialnetworkingportlet',1,'10132',10139,2),(166,10132,'3_WAR_socialnetworkingportlet',1,'10132',10141,2),(167,10132,'3_WAR_socialnetworkingportlet',1,'10132',10142,2),(168,10132,'7_WAR_socialnetworkingportlet',1,'10132',10138,2),(169,10132,'7_WAR_socialnetworkingportlet',1,'10132',10139,2),(170,10132,'7_WAR_socialnetworkingportlet',1,'10132',10141,2),(171,10132,'7_WAR_socialnetworkingportlet',1,'10132',10142,2),(172,10132,'8_WAR_socialnetworkingportlet',1,'10132',10138,2),(173,10132,'8_WAR_socialnetworkingportlet',1,'10132',10139,2),(174,10132,'8_WAR_socialnetworkingportlet',1,'10132',10141,2),(175,10132,'8_WAR_socialnetworkingportlet',1,'10132',10142,2),(176,10132,'4_WAR_socialnetworkingportlet',1,'10132',10138,2),(177,10132,'4_WAR_socialnetworkingportlet',1,'10132',10139,2),(178,10132,'4_WAR_socialnetworkingportlet',1,'10132',10141,2),(179,10132,'4_WAR_socialnetworkingportlet',1,'10132',10142,2),(180,10132,'2_WAR_socialnetworkingportlet',1,'10132',10138,2),(181,10132,'2_WAR_socialnetworkingportlet',1,'10132',10139,2),(182,10132,'2_WAR_socialnetworkingportlet',1,'10132',10141,2),(183,10132,'2_WAR_socialnetworkingportlet',1,'10132',10142,2),(184,10132,'5_WAR_socialnetworkingportlet',1,'10132',10138,2),(185,10132,'5_WAR_socialnetworkingportlet',1,'10132',10139,2),(186,10132,'5_WAR_socialnetworkingportlet',1,'10132',10141,2),(187,10132,'5_WAR_socialnetworkingportlet',1,'10132',10142,2),(188,10132,'103',4,'10160_LAYOUT_103',10140,7),(189,10132,'103',4,'10160_LAYOUT_103',10144,1),(190,10132,'103',4,'10160_LAYOUT_103',10139,1),(191,10132,'47',4,'10160_LAYOUT_47',10140,7),(192,10132,'47',4,'10160_LAYOUT_47',10144,1),(193,10132,'47',4,'10160_LAYOUT_47',10139,1),(194,10132,'58',4,'10160_LAYOUT_58',10140,7),(195,10132,'58',4,'10160_LAYOUT_58',10144,1),(196,10132,'58',4,'10160_LAYOUT_58',10139,1),(197,10132,'com.liferay.portal.model.Layout',4,'10320',10140,127),(198,10132,'com.liferay.portal.model.Layout',4,'10320',10141,3),(199,10132,'com.liferay.portal.model.Layout',4,'10320',10139,1),(200,10132,'com.liferay.portal.model.Layout',4,'10325',10140,127),(201,10132,'com.liferay.portal.model.Layout',4,'10325',10141,3),(202,10132,'com.liferay.portal.model.Layout',4,'10325',10139,1),(203,10132,'145',4,'10160_LAYOUT_145',10140,7),(204,10132,'145',4,'10160_LAYOUT_145',10144,1),(205,10132,'145',4,'10160_LAYOUT_145',10139,1),(206,10132,'com.liferay.portlet.asset',4,'10157',10140,30),(207,10132,'com.liferay.portal.model.Layout',4,'10333',10140,127),(208,10132,'com.liferay.portal.model.Layout',4,'10333',10144,3),(209,10132,'com.liferay.portal.model.Layout',4,'10333',10139,1),(210,10132,'103',4,'10333_LAYOUT_103',10140,7),(211,10132,'103',4,'10333_LAYOUT_103',10144,1),(212,10132,'103',4,'10333_LAYOUT_103',10139,1),(213,10132,'145',4,'10333_LAYOUT_145',10140,7),(214,10132,'145',4,'10333_LAYOUT_145',10144,1),(215,10132,'145',4,'10333_LAYOUT_145',10139,1),(216,10132,'87',4,'10333_LAYOUT_87',10140,7),(217,10132,'87',4,'10333_LAYOUT_87',10144,1),(218,10132,'87',4,'10333_LAYOUT_87',10139,1),(219,10132,'98',4,'10333_LAYOUT_98',10140,15),(220,10132,'98',4,'10333_LAYOUT_98',10144,1),(221,10132,'98',4,'10333_LAYOUT_98',10139,1),(222,10132,'com.liferay.portlet.softwarecatalog',4,'10157',10140,14),(223,10132,'com.liferay.portlet.softwarecatalog.model.SCFrameworkVersion',4,'10342',10140,14),(224,10132,'com.liferay.portlet.softwarecatalog.model.SCProductEntry',4,'10344',10140,127),(225,10132,'com.liferay.portlet.softwarecatalog.model.SCProductEntry',4,'10344',10144,3),(226,10132,'com.liferay.portlet.softwarecatalog.model.SCProductEntry',4,'10344',10139,1),(227,10132,'160',4,'10152_LAYOUT_160',10140,7),(228,10132,'160',4,'10152_LAYOUT_160',10144,1),(229,10132,'160',4,'10152_LAYOUT_160',10139,1),(230,10132,'145',4,'10152_LAYOUT_145',10140,7),(231,10132,'145',4,'10152_LAYOUT_145',10144,1),(232,10132,'145',4,'10152_LAYOUT_145',10139,1),(233,10132,'com.liferay.portlet.asset',4,'10149',10140,30),(234,10132,'134',4,'10152_LAYOUT_134',10140,7),(235,10132,'134',4,'10152_LAYOUT_134',10144,1),(236,10132,'134',4,'10152_LAYOUT_134',10139,1),(237,10132,'com.liferay.portal.model.Group',4,'10357',10140,32766),(238,10132,'128',4,'10152_LAYOUT_128',10140,7),(239,10132,'128',4,'10152_LAYOUT_128',10144,1),(240,10132,'128',4,'10152_LAYOUT_128',10139,1),(241,10132,'com.liferay.portal.model.Role',4,'10362',10140,127),(242,10132,'com.liferay.portal.model.Role',4,'10363',10140,127),(243,10132,'125',4,'10152_LAYOUT_125',10140,15),(244,10132,'125',4,'10152_LAYOUT_125',10144,1),(245,10132,'125',4,'10152_LAYOUT_125',10139,1),(246,10132,'com.liferay.portal.model.User',4,'10365',10140,31),(247,10132,'126',4,'10152_LAYOUT_126',10140,7),(248,10132,'126',4,'10152_LAYOUT_126',10144,1),(249,10132,'126',4,'10152_LAYOUT_126',10139,1),(250,10132,'com.liferay.portal.model.Group',4,'10376',10140,32766),(251,10132,'com.liferay.portal.model.Organization',4,'10375',10140,65535),(252,10132,'com.liferay.portal.model.Team',4,'10381',10140,31),(253,10132,'com.liferay.portal.model.Role',4,'10382',10140,127),(254,10132,'127',4,'10152_LAYOUT_127',10140,7),(255,10132,'127',4,'10152_LAYOUT_127',10144,1),(256,10132,'127',4,'10152_LAYOUT_127',10139,1),(257,10132,'com.liferay.portal.model.UserGroup',4,'10384',10140,127),(258,10132,'com.liferay.portal.model.Group',4,'10388',10140,32766),(259,10132,'com.liferay.portal.model.Layout',4,'10392',10140,127),(260,10132,'com.liferay.portal.model.Layout',4,'10392',10144,3),(261,10132,'com.liferay.portal.model.Layout',4,'10392',10139,1),(262,10132,'103',4,'10392_LAYOUT_103',10140,7),(263,10132,'103',4,'10392_LAYOUT_103',10144,1),(264,10132,'103',4,'10392_LAYOUT_103',10139,1),(265,10132,'145',4,'10392_LAYOUT_145',10140,7),(266,10132,'145',4,'10392_LAYOUT_145',10144,1),(267,10132,'145',4,'10392_LAYOUT_145',10139,1),(268,10132,'com.liferay.portlet.asset',4,'10388',10140,30),(269,10132,'87',4,'10392_LAYOUT_87',10140,7),(270,10132,'87',4,'10392_LAYOUT_87',10144,1),(271,10132,'87',4,'10392_LAYOUT_87',10139,1),(272,10132,'36',4,'10392_LAYOUT_36',10140,7),(273,10132,'36',4,'10392_LAYOUT_36',10144,1),(274,10132,'36',4,'10392_LAYOUT_36',10139,1),(275,10132,'com.liferay.portlet.wiki',4,'10388',10140,6),(276,10132,'com.liferay.portlet.wiki.model.WikiNode',4,'10401',10140,255),(277,10132,'com.liferay.portlet.wiki.model.WikiNode',4,'10401',10144,71),(278,10132,'com.liferay.portlet.wiki.model.WikiNode',4,'10401',10139,1),(279,10132,'com.liferay.portlet.wiki.model.WikiPage',4,'10403',10140,255),(280,10132,'com.liferay.portlet.wiki.model.WikiPage',4,'10403',10144,99),(281,10132,'com.liferay.portlet.wiki.model.WikiPage',4,'10403',10139,1),(282,10132,'com.liferay.portlet.asset.model.AssetVocabulary',4,'10409',10140,15),(283,10132,'com.liferay.portlet.asset.model.AssetVocabulary',4,'10410',10140,15),(284,10132,'154',4,'10152_LAYOUT_154',10140,7),(285,10132,'com.liferay.portlet.wiki.model.WikiNode',4,'10413',10140,255),(286,10132,'com.liferay.portlet.wiki.model.WikiNode',4,'10413',10144,71),(287,10132,'com.liferay.portlet.wiki.model.WikiNode',4,'10413',10139,1),(288,10132,'25',4,'10152_LAYOUT_25',10140,7),(289,10132,'25',4,'10152_LAYOUT_25',10144,1),(290,10132,'25',4,'10152_LAYOUT_25',10139,1),(291,10132,'com.liferay.portlet.polls',4,'10149',10140,6),(292,10132,'com.liferay.portlet.polls.model.PollsQuestion',4,'10421',10140,31),(293,10132,'com.liferay.portlet.polls.model.PollsQuestion',4,'10421',10144,3),(294,10132,'com.liferay.portlet.polls.model.PollsQuestion',4,'10421',10139,1),(295,10132,'com.liferay.portal.model.Layout',4,'10424',10140,127),(296,10132,'com.liferay.portal.model.Layout',4,'10424',10144,3),(297,10132,'com.liferay.portal.model.Layout',4,'10424',10139,1),(298,10132,'103',4,'10424_LAYOUT_103',10140,7),(299,10132,'103',4,'10424_LAYOUT_103',10144,1),(300,10132,'103',4,'10424_LAYOUT_103',10139,1),(301,10132,'145',4,'10424_LAYOUT_145',10140,7),(302,10132,'145',4,'10424_LAYOUT_145',10144,1),(303,10132,'145',4,'10424_LAYOUT_145',10139,1),(304,10132,'87',4,'10424_LAYOUT_87',10140,7),(305,10132,'87',4,'10424_LAYOUT_87',10144,1),(306,10132,'87',4,'10424_LAYOUT_87',10139,1),(307,10132,'59',4,'10424_LAYOUT_59_INSTANCE_l7zO',10140,7),(308,10132,'59',4,'10424_LAYOUT_59_INSTANCE_l7zO',10144,1),(309,10132,'59',4,'10424_LAYOUT_59_INSTANCE_l7zO',10139,1),(310,10132,'86',4,'10424_LAYOUT_86',10140,7),(311,10132,'86',4,'10424_LAYOUT_86',10144,1),(312,10132,'86',4,'10424_LAYOUT_86',10139,1),(313,10132,'com.liferay.portal.model.Group',4,'10435',10140,32766),(314,10132,'com.liferay.portal.model.Layout',4,'10439',10140,127),(315,10132,'com.liferay.portal.model.Layout',4,'10439',10144,3),(316,10132,'com.liferay.portal.model.Layout',4,'10439',10139,1),(317,10132,'15',4,'10152_LAYOUT_15',10140,15),(318,10132,'15',4,'10152_LAYOUT_15',10144,1),(319,10132,'15',4,'10152_LAYOUT_15',10139,1),(320,10132,'com.liferay.portlet.journal',4,'10149',10140,126),(321,10132,'com.liferay.portlet.journal.model.JournalFeed',4,'10447',10140,15),(322,10132,'com.liferay.portlet.journal.model.JournalFeed',4,'10447',10144,1),(323,10132,'com.liferay.portlet.journal.model.JournalFeed',4,'10447',10139,1),(324,10132,'103',4,'10439_LAYOUT_103',10140,7),(325,10132,'103',4,'10439_LAYOUT_103',10144,1),(326,10132,'103',4,'10439_LAYOUT_103',10139,1),(327,10132,'145',4,'10439_LAYOUT_145',10140,7),(328,10132,'145',4,'10439_LAYOUT_145',10144,1),(329,10132,'145',4,'10439_LAYOUT_145',10139,1),(330,10132,'com.liferay.portlet.asset',4,'10435',10140,30),(331,10132,'87',4,'10439_LAYOUT_87',10140,7),(332,10132,'87',4,'10439_LAYOUT_87',10144,1),(333,10132,'87',4,'10439_LAYOUT_87',10139,1),(334,10132,'56',4,'10439_LAYOUT_56_INSTANCE_hUa2',10140,7),(335,10132,'56',4,'10439_LAYOUT_56_INSTANCE_hUa2',10144,1),(336,10132,'56',4,'10439_LAYOUT_56_INSTANCE_hUa2',10139,1),(337,10132,'com.liferay.portlet.journal.model.JournalStructure',4,'10453',10140,15),(338,10132,'com.liferay.portlet.journal.model.JournalStructure',4,'10453',10144,1),(339,10132,'com.liferay.portlet.journal.model.JournalStructure',4,'10453',10139,1),(340,10132,'com.liferay.portlet.journal.model.JournalTemplate',4,'10455',10140,15),(341,10132,'com.liferay.portlet.journal.model.JournalTemplate',4,'10455',10144,1),(342,10132,'com.liferay.portlet.journal.model.JournalTemplate',4,'10455',10139,1),(343,10132,'com.liferay.portlet.journal.model.JournalArticle',4,'10459',10140,255),(344,10132,'com.liferay.portlet.journal.model.JournalArticle',4,'10459',10144,3),(345,10132,'com.liferay.portlet.journal.model.JournalArticle',4,'10459',10139,1),(346,10132,'147',4,'10152_LAYOUT_147',10140,7),(347,10132,'147',4,'10152_LAYOUT_147',10144,1),(348,10132,'147',4,'10152_LAYOUT_147',10139,1),(349,10132,'com.liferay.portlet.asset.model.AssetVocabulary',4,'10468',10140,15),(350,10132,'com.liferay.portlet.asset.model.AssetVocabulary',4,'10469',10140,15),(351,10132,'com.liferay.portlet.asset.model.AssetVocabulary',4,'10469',10144,1),(352,10132,'com.liferay.portlet.asset.model.AssetVocabulary',4,'10469',10139,1),(353,10132,'com.liferay.portlet.asset.model.AssetCategory',4,'10470',10140,31),(354,10132,'com.liferay.portlet.asset.model.AssetCategory',4,'10470',10144,3),(355,10132,'com.liferay.portlet.asset.model.AssetCategory',4,'10470',10139,1),(356,10132,'86',4,'10439_LAYOUT_86',10140,7),(357,10132,'86',4,'10439_LAYOUT_86',10144,1),(358,10132,'86',4,'10439_LAYOUT_86',10139,1),(359,10132,'15',4,'10439_LAYOUT_15',10140,15),(360,10132,'15',4,'10439_LAYOUT_15',10144,1),(361,10132,'15',4,'10439_LAYOUT_15',10139,1),(362,10132,'com.liferay.portlet.journal',4,'10435',10140,126),(363,10132,'com.liferay.portal.model.Group',4,'10481',10140,32766),(364,10132,'com.liferay.portal.model.Layout',4,'10485',10140,127),(365,10132,'com.liferay.portal.model.Layout',4,'10485',10144,3),(366,10132,'com.liferay.portal.model.Layout',4,'10485',10139,1),(367,10132,'103',4,'10485_LAYOUT_103',10140,7),(368,10132,'103',4,'10485_LAYOUT_103',10144,1),(369,10132,'103',4,'10485_LAYOUT_103',10139,1),(370,10132,'145',4,'10485_LAYOUT_145',10140,7),(371,10132,'145',4,'10485_LAYOUT_145',10144,1),(372,10132,'145',4,'10485_LAYOUT_145',10139,1),(373,10132,'com.liferay.portlet.asset',4,'10481',10140,30),(374,10132,'87',4,'10485_LAYOUT_87',10140,7),(375,10132,'87',4,'10485_LAYOUT_87',10144,1),(376,10132,'87',4,'10485_LAYOUT_87',10139,1),(377,10132,'84',4,'10485_LAYOUT_84',10140,15),(378,10132,'84',4,'10485_LAYOUT_84',10144,1),(379,10132,'84',4,'10485_LAYOUT_84',10139,1),(380,10132,'155',4,'10152_LAYOUT_155',10140,7),(381,10132,'33',4,'10152_LAYOUT_33',10140,15),(382,10132,'33',4,'10152_LAYOUT_33',10144,1),(383,10132,'33',4,'10152_LAYOUT_33',10139,1),(384,10132,'com.liferay.portlet.blogs',4,'10149',10140,14),(385,10132,'146',4,'10152_LAYOUT_146',10140,7),(386,10132,'146',4,'10152_LAYOUT_146',10144,1),(387,10132,'146',4,'10152_LAYOUT_146',10139,1),(388,10132,'com.liferay.portal.model.LayoutPrototype',4,'10522',10140,15),(389,10132,'com.liferay.portal.model.Layout',4,'10526',10140,127),(390,10132,'com.liferay.portal.model.Layout',4,'10526',10144,3),(391,10132,'com.liferay.portal.model.Layout',4,'10526',10139,1),(392,10132,'149',4,'10152_LAYOUT_149',10140,7),(393,10132,'149',4,'10152_LAYOUT_149',10144,1),(394,10132,'149',4,'10152_LAYOUT_149',10139,1),(395,10132,'com.liferay.portal.model.LayoutSetPrototype',4,'10532',10140,15),(396,10132,'com.liferay.portal.model.Layout',4,'10536',10140,127),(397,10132,'com.liferay.portal.model.Layout',4,'10536',10144,3),(398,10132,'com.liferay.portal.model.Layout',4,'10536',10139,1),(399,10132,'129',4,'10152_LAYOUT_129',10140,7),(400,10132,'129',4,'10152_LAYOUT_129',10144,1),(401,10132,'129',4,'10152_LAYOUT_129',10139,1),(402,10132,'com.liferay.portal.model.PasswordPolicy',4,'10542',10140,31),(403,10132,'com.liferay.portal.model.User',4,'10543',10140,31),(404,10132,'com.liferay.portal.model.Layout',4,'10552',10140,127),(405,10132,'com.liferay.portal.model.Layout',4,'10552',10141,3),(406,10132,'com.liferay.portal.model.Layout',4,'10552',10139,1),(407,10132,'com.liferay.portal.model.Layout',4,'10557',10140,127),(408,10132,'com.liferay.portal.model.Layout',4,'10557',10141,3),(409,10132,'com.liferay.portal.model.Layout',4,'10557',10139,1),(410,10132,'156',4,'10152_LAYOUT_156',10140,7),(411,10132,'156',4,'10152_LAYOUT_156',10144,1),(412,10132,'156',4,'10152_LAYOUT_156',10139,1),(413,10132,'com.liferay.portal.model.Layout',4,'10566',10140,127),(414,10132,'com.liferay.portal.model.Layout',4,'10566',10144,3),(415,10132,'com.liferay.portal.model.Layout',4,'10566',10139,1),(416,10132,'103',4,'10566_LAYOUT_103',10140,7),(417,10132,'103',4,'10566_LAYOUT_103',10144,1),(418,10132,'103',4,'10566_LAYOUT_103',10139,1),(419,10132,'145',4,'10566_LAYOUT_145',10140,7),(420,10132,'145',4,'10566_LAYOUT_145',10144,1),(421,10132,'145',4,'10566_LAYOUT_145',10139,1),(422,10132,'87',4,'10566_LAYOUT_87',10140,7),(423,10132,'87',4,'10566_LAYOUT_87',10144,1),(424,10132,'87',4,'10566_LAYOUT_87',10139,1),(425,10132,'34',4,'10566_LAYOUT_34',10140,7),(426,10132,'34',4,'10566_LAYOUT_34',10144,1),(427,10132,'34',4,'10566_LAYOUT_34',10139,1),(428,10132,'com.liferay.portlet.shopping',4,'10157',10140,62),(429,10132,'com.liferay.portlet.shopping.model.ShoppingCategory',4,'10576',10140,63),(430,10132,'com.liferay.portlet.shopping.model.ShoppingCategory',4,'10576',10144,1),(431,10132,'com.liferay.portlet.shopping.model.ShoppingCategory',4,'10576',10139,1),(432,10132,'com.liferay.portlet.shopping.model.ShoppingItem',4,'10577',10140,15),(433,10132,'com.liferay.portlet.shopping.model.ShoppingItem',4,'10577',10144,1),(434,10132,'com.liferay.portlet.shopping.model.ShoppingItem',4,'10577',10139,1),(435,10132,'com.liferay.portal.model.Group',4,'10585',10140,32766),(436,10132,'com.liferay.portal.model.User',4,'10589',10140,31),(437,10132,'com.liferay.portal.model.Layout',4,'10598',10140,127),(438,10132,'com.liferay.portal.model.Layout',4,'10598',10141,3),(439,10132,'com.liferay.portal.model.Layout',4,'10598',10139,1),(440,10132,'com.liferay.portal.model.Layout',4,'10603',10140,127),(441,10132,'com.liferay.portal.model.Layout',4,'10603',10141,3),(442,10132,'com.liferay.portal.model.Layout',4,'10603',10139,1),(443,10132,'103',4,'10598_LAYOUT_103',10140,7),(444,10132,'103',4,'10598_LAYOUT_103',10141,1),(445,10132,'103',4,'10598_LAYOUT_103',10139,1),(446,10132,'11',4,'10598_LAYOUT_11',10140,7),(447,10132,'23',4,'10598_LAYOUT_23',10140,7),(448,10132,'23',4,'10598_LAYOUT_23',10141,1),(449,10132,'23',4,'10598_LAYOUT_23',10139,1),(450,10132,'29',4,'10598_LAYOUT_29',10140,7),(451,10132,'29',4,'10598_LAYOUT_29',10141,1),(452,10132,'29',4,'10598_LAYOUT_29',10139,1),(453,10132,'8',4,'10598_LAYOUT_8',10140,15),(454,10132,'8',4,'10598_LAYOUT_8',10141,1),(455,10132,'8',4,'10598_LAYOUT_8',10139,1),(456,10132,'com.liferay.portlet.calendar',4,'10591',10140,14),(457,10132,'82',4,'10598_LAYOUT_82',10140,7),(458,10132,'82',4,'10598_LAYOUT_82',10141,1),(459,10132,'82',4,'10598_LAYOUT_82',10139,1),(460,10132,'145',4,'10598_LAYOUT_145',10140,7),(461,10132,'145',4,'10598_LAYOUT_145',10141,1),(462,10132,'145',4,'10598_LAYOUT_145',10139,1),(463,10132,'com.liferay.portlet.asset',4,'10591',10140,30),(464,10132,'com.liferay.portal.model.Group',4,'10617',10140,32766),(465,10132,'com.liferay.portal.model.Layout',4,'10621',10140,127),(466,10132,'com.liferay.portal.model.Layout',4,'10621',10144,3),(467,10132,'com.liferay.portal.model.Layout',4,'10621',10139,1),(468,10132,'com.liferay.portal.model.Group',4,'10626',10140,32766),(469,10132,'com.liferay.portlet.asset.model.AssetVocabulary',4,'10634',10140,15),(470,10132,'com.liferay.portlet.asset.model.AssetVocabulary',4,'10635',10140,15),(473,10132,'com.liferay.portal.model.Layout',4,'10636',10139,1),(474,10132,'com.liferay.portal.model.Layout',4,'10636',10140,127),(475,10132,'com.liferay.portal.model.Layout',4,'10636',10144,3),(476,10132,'103',4,'10636_LAYOUT_103',10140,7),(477,10132,'103',4,'10636_LAYOUT_103',10144,1),(478,10132,'103',4,'10636_LAYOUT_103',10139,1),(479,10132,'145',4,'10636_LAYOUT_145',10140,7),(480,10132,'145',4,'10636_LAYOUT_145',10144,1),(481,10132,'145',4,'10636_LAYOUT_145',10139,1),(482,10132,'com.liferay.portlet.asset',4,'10626',10140,30),(483,10132,'87',4,'10636_LAYOUT_87',10140,7),(484,10132,'87',4,'10636_LAYOUT_87',10144,1),(485,10132,'87',4,'10636_LAYOUT_87',10139,1),(486,10132,'19',4,'10636_LAYOUT_19',10140,15),(487,10132,'19',4,'10636_LAYOUT_19',10144,1),(488,10132,'19',4,'10636_LAYOUT_19',10139,1),(489,10132,'com.liferay.portlet.messageboards',4,'10626',10140,2046),(490,10132,'com.liferay.portlet.messageboards.model.MBCategory',4,'10645',10140,4095),(491,10132,'com.liferay.portlet.messageboards.model.MBCategory',4,'10645',10144,775),(492,10132,'com.liferay.portlet.messageboards.model.MBCategory',4,'10645',10139,1),(493,10132,'com.liferay.portlet.messageboards.model.MBMessage',4,'10647',10140,31),(494,10132,'com.liferay.portlet.messageboards.model.MBMessage',4,'10647',10144,9),(495,10132,'com.liferay.portlet.messageboards.model.MBMessage',4,'10647',10139,1),(496,10132,'com.liferay.portal.model.Layout',4,'10651',10140,127),(497,10132,'com.liferay.portal.model.Layout',4,'10651',10144,3),(498,10132,'com.liferay.portal.model.Layout',4,'10651',10139,1),(499,10132,'103',4,'10651_LAYOUT_103',10140,7),(500,10132,'103',4,'10651_LAYOUT_103',10144,1),(501,10132,'103',4,'10651_LAYOUT_103',10139,1),(502,10132,'145',4,'10651_LAYOUT_145',10140,7),(503,10132,'145',4,'10651_LAYOUT_145',10144,1),(504,10132,'145',4,'10651_LAYOUT_145',10139,1),(505,10132,'87',4,'10651_LAYOUT_87',10140,7),(506,10132,'87',4,'10651_LAYOUT_87',10144,1),(507,10132,'87',4,'10651_LAYOUT_87',10139,1),(508,10132,'28',4,'10651_LAYOUT_28',10140,15),(509,10132,'28',4,'10651_LAYOUT_28',10144,1),(510,10132,'28',4,'10651_LAYOUT_28',10139,1),(511,10132,'com.liferay.portlet.bookmarks',4,'10157',10140,14),(512,10132,'com.liferay.portlet.bookmarks.model.BookmarksEntry',4,'10660',10140,15),(513,10132,'com.liferay.portlet.bookmarks.model.BookmarksEntry',4,'10660',10144,1),(514,10132,'com.liferay.portlet.bookmarks.model.BookmarksEntry',4,'10660',10139,1),(515,10132,'com.liferay.portlet.bookmarks.model.BookmarksFolder',4,'10662',10140,127),(516,10132,'com.liferay.portlet.bookmarks.model.BookmarksFolder',4,'10662',10144,5),(517,10132,'com.liferay.portlet.bookmarks.model.BookmarksFolder',4,'10662',10139,1),(518,10132,'com.liferay.portal.model.Group',4,'10663',10140,32766),(519,10132,'com.liferay.portal.model.Layout',4,'10667',10140,127),(520,10132,'com.liferay.portal.model.Layout',4,'10667',10144,3),(521,10132,'com.liferay.portal.model.Layout',4,'10667',10139,1),(522,10132,'103',4,'10667_LAYOUT_103',10140,7),(523,10132,'103',4,'10667_LAYOUT_103',10144,1),(524,10132,'103',4,'10667_LAYOUT_103',10139,1),(525,10132,'145',4,'10667_LAYOUT_145',10140,7),(526,10132,'145',4,'10667_LAYOUT_145',10144,1),(527,10132,'145',4,'10667_LAYOUT_145',10139,1),(528,10132,'com.liferay.portlet.asset',4,'10663',10140,30),(529,10132,'87',4,'10667_LAYOUT_87',10140,7),(530,10132,'87',4,'10667_LAYOUT_87',10144,1),(531,10132,'87',4,'10667_LAYOUT_87',10139,1),(532,10132,'101',4,'10667_LAYOUT_101_INSTANCE_dCR9',10140,7),(533,10132,'101',4,'10667_LAYOUT_101_INSTANCE_dCR9',10144,1),(534,10132,'101',4,'10667_LAYOUT_101_INSTANCE_dCR9',10139,1),(535,10132,'19',4,'10667_LAYOUT_19',10140,15),(536,10132,'19',4,'10667_LAYOUT_19',10144,1),(537,10132,'19',4,'10667_LAYOUT_19',10139,1),(538,10132,'com.liferay.portlet.messageboards',4,'10663',10140,2046),(539,10132,'33',4,'10667_LAYOUT_33',10140,15),(540,10132,'33',4,'10667_LAYOUT_33',10144,1),(541,10132,'33',4,'10667_LAYOUT_33',10139,1),(542,10132,'com.liferay.portlet.blogs',4,'10663',10140,14),(543,10132,'com.liferay.portal.model.Group',4,'10678',10140,32766),(544,10132,'com.liferay.portal.model.Layout',4,'10682',10140,127),(545,10132,'com.liferay.portal.model.Layout',4,'10682',10144,3),(546,10132,'com.liferay.portal.model.Layout',4,'10682',10139,1),(547,10132,'103',4,'10682_LAYOUT_103',10140,7),(548,10132,'103',4,'10682_LAYOUT_103',10144,1),(549,10132,'103',4,'10682_LAYOUT_103',10139,1),(550,10132,'145',4,'10682_LAYOUT_145',10140,7),(551,10132,'145',4,'10682_LAYOUT_145',10144,1),(552,10132,'145',4,'10682_LAYOUT_145',10139,1),(553,10132,'com.liferay.portlet.asset',4,'10678',10140,30),(554,10132,'87',4,'10682_LAYOUT_87',10140,7),(555,10132,'87',4,'10682_LAYOUT_87',10144,1),(556,10132,'87',4,'10682_LAYOUT_87',10139,1),(557,10132,'20',4,'10682_LAYOUT_20',10140,15),(558,10132,'20',4,'10682_LAYOUT_20',10144,1),(559,10132,'20',4,'10682_LAYOUT_20',10139,1),(560,10132,'com.liferay.portlet.documentlibrary',4,'10678',10140,31),(561,10132,'com.liferay.portlet.documentlibrary',4,'10678',10144,1),(562,10132,'com.liferay.portlet.documentlibrary.model.DLFileEntry',4,'10707',10140,127),(563,10132,'com.liferay.portlet.documentlibrary.model.DLFileEntry',4,'10707',10144,3),(564,10132,'com.liferay.portlet.documentlibrary.model.DLFileEntry',4,'10707',10139,1),(565,10132,'com.liferay.portlet.documentlibrary.model.DLFileShortcut',4,'10698',10140,127),(566,10132,'com.liferay.portlet.documentlibrary.model.DLFileShortcut',4,'10698',10144,3),(567,10132,'com.liferay.portlet.documentlibrary.model.DLFileShortcut',4,'10698',10139,1),(568,10132,'20',4,'10152_LAYOUT_20',10140,15),(569,10132,'20',4,'10152_LAYOUT_20',10144,1),(570,10132,'20',4,'10152_LAYOUT_20',10139,1),(571,10132,'com.liferay.portlet.documentlibrary',4,'10149',10140,31),(572,10132,'com.liferay.portlet.documentlibrary',4,'10149',10144,1),(573,10132,'com.liferay.portlet.documentlibrary.model.DLFolder',4,'10705',10140,255),(574,10132,'com.liferay.portlet.documentlibrary.model.DLFolder',4,'10705',10144,29),(575,10132,'com.liferay.portlet.documentlibrary.model.DLFolder',4,'10705',10139,1),(576,10132,'132',4,'10152_LAYOUT_132',10140,7),(577,10132,'132',4,'10152_LAYOUT_132',10144,1),(578,10132,'132',4,'10152_LAYOUT_132',10139,1),(579,10132,'com.liferay.portal.model.Layout',4,'10713',10140,127),(580,10132,'com.liferay.portal.model.Layout',4,'10713',10144,3),(581,10132,'com.liferay.portal.model.Layout',4,'10713',10139,1),(582,10132,'103',4,'10713_LAYOUT_103',10140,7),(583,10132,'103',4,'10713_LAYOUT_103',10144,1),(584,10132,'103',4,'10713_LAYOUT_103',10139,1),(585,10132,'145',4,'10713_LAYOUT_145',10140,7),(586,10132,'145',4,'10713_LAYOUT_145',10144,1),(587,10132,'145',4,'10713_LAYOUT_145',10139,1),(588,10132,'87',4,'10713_LAYOUT_87',10140,7),(589,10132,'87',4,'10713_LAYOUT_87',10144,1),(590,10132,'87',4,'10713_LAYOUT_87',10139,1),(591,10132,'8',4,'10713_LAYOUT_8',10140,15),(592,10132,'8',4,'10713_LAYOUT_8',10144,1),(593,10132,'8',4,'10713_LAYOUT_8',10139,1),(594,10132,'com.liferay.portlet.calendar',4,'10157',10140,14),(595,10132,'8',4,'10152_LAYOUT_8',10140,15),(596,10132,'8',4,'10152_LAYOUT_8',10144,1),(597,10132,'8',4,'10152_LAYOUT_8',10139,1),(598,10132,'com.liferay.portlet.calendar',4,'10149',10140,14),(599,10132,'com.liferay.portlet.calendar.model.CalEvent',4,'10723',10140,127),(600,10132,'com.liferay.portlet.calendar.model.CalEvent',4,'10723',10144,3),(601,10132,'com.liferay.portlet.calendar.model.CalEvent',4,'10723',10139,1),(602,10132,'com.liferay.portal.model.Layout',4,'10725',10140,127),(603,10132,'com.liferay.portal.model.Layout',4,'10725',10144,3),(604,10132,'com.liferay.portal.model.Layout',4,'10725',10139,1),(605,10132,'103',4,'10725_LAYOUT_103',10140,7),(606,10132,'103',4,'10725_LAYOUT_103',10144,1),(607,10132,'103',4,'10725_LAYOUT_103',10139,1),(608,10132,'145',4,'10725_LAYOUT_145',10140,7),(609,10132,'145',4,'10725_LAYOUT_145',10144,1),(610,10132,'145',4,'10725_LAYOUT_145',10139,1),(611,10132,'87',4,'10725_LAYOUT_87',10140,7),(612,10132,'87',4,'10725_LAYOUT_87',10144,1),(613,10132,'87',4,'10725_LAYOUT_87',10139,1),(614,10132,'84',4,'10725_LAYOUT_84',10140,15),(615,10132,'84',4,'10725_LAYOUT_84',10144,1),(616,10132,'84',4,'10725_LAYOUT_84',10139,1),(617,10132,'2',4,'10152_LAYOUT_2',10140,7),(618,10132,'2',4,'10152_LAYOUT_2',10144,1),(619,10132,'2',4,'10152_LAYOUT_2',10139,1),(620,10132,'com.liferay.portlet.announcements.model.AnnouncementsEntry',4,'10738',10140,15),(621,10132,'139',4,'10152_LAYOUT_139',10140,15),(622,10132,'com.liferay.portlet.expando.model.ExpandoColumn',4,'10742',10140,15),(623,10132,'com.liferay.portal.model.User',4,'10743',10140,31),(624,10132,'com.liferay.portal.model.Group',4,'10752',10140,32766),(625,10132,'com.liferay.portal.model.Layout',4,'10756',10140,127),(626,10132,'com.liferay.portal.model.Layout',4,'10756',10144,3),(627,10132,'com.liferay.portal.model.Layout',4,'10756',10139,1),(628,10132,'99',4,'10152_LAYOUT_99',10140,7),(629,10132,'99',4,'10152_LAYOUT_99',10144,1),(630,10132,'99',4,'10152_LAYOUT_99',10139,1),(631,10132,'com.liferay.portlet.asset.model.AssetTag',4,'10762',10140,15),(632,10132,'com.liferay.portlet.asset.model.AssetTag',4,'10762',10144,1),(633,10132,'com.liferay.portlet.asset.model.AssetTag',4,'10762',10139,1),(634,10132,'103',4,'10756_LAYOUT_103',10140,7),(635,10132,'103',4,'10756_LAYOUT_103',10144,1),(636,10132,'103',4,'10756_LAYOUT_103',10139,1),(637,10132,'145',4,'10756_LAYOUT_145',10140,7),(638,10132,'145',4,'10756_LAYOUT_145',10144,1),(639,10132,'145',4,'10756_LAYOUT_145',10139,1),(640,10132,'com.liferay.portlet.asset',4,'10752',10140,30),(641,10132,'87',4,'10756_LAYOUT_87',10140,7),(642,10132,'87',4,'10756_LAYOUT_87',10144,1),(643,10132,'87',4,'10756_LAYOUT_87',10139,1),(644,10132,'33',4,'10756_LAYOUT_33',10140,15),(645,10132,'33',4,'10756_LAYOUT_33',10144,1),(646,10132,'33',4,'10756_LAYOUT_33',10139,1),(647,10132,'com.liferay.portlet.blogs',4,'10752',10140,14);
/*!40000 ALTER TABLE `ResourcePermission` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Resource_`
--

DROP TABLE IF EXISTS `Resource_`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Resource_` (
  `resourceId` bigint(20) NOT NULL,
  `codeId` bigint(20) DEFAULT NULL,
  `primKey` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`resourceId`),
  UNIQUE KEY `IX_67DE7856` (`codeId`,`primKey`),
  KEY `IX_2578FBD3` (`codeId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Resource_`
--

LOCK TABLES `Resource_` WRITE;
/*!40000 ALTER TABLE `Resource_` DISABLE KEYS */;
/*!40000 ALTER TABLE `Resource_` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Role_`
--

DROP TABLE IF EXISTS `Role_`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Role_` (
  `roleId` bigint(20) NOT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `classNameId` bigint(20) DEFAULT NULL,
  `classPK` bigint(20) DEFAULT NULL,
  `name` varchar(75) DEFAULT NULL,
  `title` longtext,
  `description` longtext,
  `type_` int(11) DEFAULT NULL,
  `subtype` varchar(75) DEFAULT NULL,
  PRIMARY KEY (`roleId`),
  UNIQUE KEY `IX_A88E424E` (`companyId`,`classNameId`,`classPK`),
  UNIQUE KEY `IX_EBC931B8` (`companyId`,`name`),
  KEY `IX_449A10B9` (`companyId`),
  KEY `IX_5EB4E2FB` (`subtype`),
  KEY `IX_CBE204` (`type_`,`subtype`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Role_`
--

LOCK TABLES `Role_` WRITE;
/*!40000 ALTER TABLE `Role_` DISABLE KEYS */;
INSERT INTO `Role_` VALUES (10138,10132,10040,10138,'Administrator','','Administrators are super users who can do anything.',1,''),(10139,10132,10040,10139,'Guest','','Unauthenticated users always have this role.',1,''),(10140,10132,10040,10140,'Owner','','This is an implied role with respect to the objects users create.',1,''),(10141,10132,10040,10141,'Power User','','Power Users have their own public and private pages.',1,''),(10142,10132,10040,10142,'User','','Authenticated users should be assigned this role.',1,''),(10143,10132,10040,10143,'Community Administrator','','Community Administrators are super users of their community but cannot make other users into Community Administrators.',2,''),(10144,10132,10040,10144,'Community Member','','All users who belong to a community have this role within that community.',2,''),(10145,10132,10040,10145,'Community Owner','','Community Owners are super users of their community and can assign community roles to users.',2,''),(10146,10132,10040,10146,'Organization Administrator','','Organization Administrators are super users of their organization but cannot make other users into Organization Administrators.',3,''),(10147,10132,10040,10147,'Organization Member','','All users who belong to an organization have this role within that organization.',3,''),(10148,10132,10040,10148,'Organization Owner','','Organization Owners are super users of their organization and can assign organization roles to users.',3,''),(10287,10132,10040,10287,'Portal Content Reviewer','','Autogenerated role from workflow definition',1,''),(10293,10132,10040,10293,'Community Content Reviewer','','Autogenerated role from workflow definition',2,''),(10296,10132,10040,10296,'Organization Content Reviewer','','Autogenerated role from workflow definition',3,''),(10362,10132,10040,10362,'Roles Regrole Name','','',1,''),(10363,10132,10040,10363,'Roles Orgrole Name','','',2,''),(10382,10132,10044,10381,'10381','','',4,'');
/*!40000 ALTER TABLE `Role_` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Roles_Permissions`
--

DROP TABLE IF EXISTS `Roles_Permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Roles_Permissions` (
  `roleId` bigint(20) NOT NULL,
  `permissionId` bigint(20) NOT NULL,
  PRIMARY KEY (`roleId`,`permissionId`),
  KEY `IX_7A3619C6` (`permissionId`),
  KEY `IX_E04E486D` (`roleId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Roles_Permissions`
--

LOCK TABLES `Roles_Permissions` WRITE;
/*!40000 ALTER TABLE `Roles_Permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `Roles_Permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SCFrameworkVersi_SCProductVers`
--

DROP TABLE IF EXISTS `SCFrameworkVersi_SCProductVers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `SCFrameworkVersi_SCProductVers` (
  `frameworkVersionId` bigint(20) NOT NULL,
  `productVersionId` bigint(20) NOT NULL,
  PRIMARY KEY (`frameworkVersionId`,`productVersionId`),
  KEY `IX_3BB93ECA` (`frameworkVersionId`),
  KEY `IX_E8D33FF9` (`productVersionId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SCFrameworkVersi_SCProductVers`
--

LOCK TABLES `SCFrameworkVersi_SCProductVers` WRITE;
/*!40000 ALTER TABLE `SCFrameworkVersi_SCProductVers` DISABLE KEYS */;
INSERT INTO `SCFrameworkVersi_SCProductVers` VALUES (10342,10353);
/*!40000 ALTER TABLE `SCFrameworkVersi_SCProductVers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SCFrameworkVersion`
--

DROP TABLE IF EXISTS `SCFrameworkVersion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `SCFrameworkVersion` (
  `frameworkVersionId` bigint(20) NOT NULL,
  `groupId` bigint(20) DEFAULT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `userId` bigint(20) DEFAULT NULL,
  `userName` varchar(75) DEFAULT NULL,
  `createDate` datetime DEFAULT NULL,
  `modifiedDate` datetime DEFAULT NULL,
  `name` varchar(75) DEFAULT NULL,
  `url` longtext,
  `active_` tinyint(4) DEFAULT NULL,
  `priority` int(11) DEFAULT NULL,
  PRIMARY KEY (`frameworkVersionId`),
  KEY `IX_C98C0D78` (`companyId`),
  KEY `IX_272991FA` (`groupId`),
  KEY `IX_6E1764F` (`groupId`,`active_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SCFrameworkVersion`
--

LOCK TABLES `SCFrameworkVersion` WRITE;
/*!40000 ALTER TABLE `SCFrameworkVersion` DISABLE KEYS */;
INSERT INTO `SCFrameworkVersion` VALUES (10342,10157,10132,10169,'Test Test','2014-04-03 16:39:19','2014-04-03 16:39:19','SC Framework Version Name','www.FrameworkVersion.com',1,0);
/*!40000 ALTER TABLE `SCFrameworkVersion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SCLicense`
--

DROP TABLE IF EXISTS `SCLicense`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `SCLicense` (
  `licenseId` bigint(20) NOT NULL,
  `name` varchar(75) DEFAULT NULL,
  `url` longtext,
  `openSource` tinyint(4) DEFAULT NULL,
  `active_` tinyint(4) DEFAULT NULL,
  `recommended` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`licenseId`),
  KEY `IX_1C841592` (`active_`),
  KEY `IX_5327BB79` (`active_`,`recommended`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SCLicense`
--

LOCK TABLES `SCLicense` WRITE;
/*!40000 ALTER TABLE `SCLicense` DISABLE KEYS */;
INSERT INTO `SCLicense` VALUES (10343,'SC License Name','www.SCLicense.com',1,1,1);
/*!40000 ALTER TABLE `SCLicense` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SCLicenses_SCProductEntries`
--

DROP TABLE IF EXISTS `SCLicenses_SCProductEntries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `SCLicenses_SCProductEntries` (
  `licenseId` bigint(20) NOT NULL,
  `productEntryId` bigint(20) NOT NULL,
  PRIMARY KEY (`licenseId`,`productEntryId`),
  KEY `IX_27006638` (`licenseId`),
  KEY `IX_D7710A66` (`productEntryId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SCLicenses_SCProductEntries`
--

LOCK TABLES `SCLicenses_SCProductEntries` WRITE;
/*!40000 ALTER TABLE `SCLicenses_SCProductEntries` DISABLE KEYS */;
INSERT INTO `SCLicenses_SCProductEntries` VALUES (10343,10344);
/*!40000 ALTER TABLE `SCLicenses_SCProductEntries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SCProductEntry`
--

DROP TABLE IF EXISTS `SCProductEntry`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `SCProductEntry` (
  `productEntryId` bigint(20) NOT NULL,
  `groupId` bigint(20) DEFAULT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `userId` bigint(20) DEFAULT NULL,
  `userName` varchar(75) DEFAULT NULL,
  `createDate` datetime DEFAULT NULL,
  `modifiedDate` datetime DEFAULT NULL,
  `name` varchar(75) DEFAULT NULL,
  `type_` varchar(75) DEFAULT NULL,
  `tags` varchar(255) DEFAULT NULL,
  `shortDescription` longtext,
  `longDescription` longtext,
  `pageURL` longtext,
  `author` varchar(75) DEFAULT NULL,
  `repoGroupId` varchar(75) DEFAULT NULL,
  `repoArtifactId` varchar(75) DEFAULT NULL,
  PRIMARY KEY (`productEntryId`),
  KEY `IX_5D25244F` (`companyId`),
  KEY `IX_72F87291` (`groupId`),
  KEY `IX_98E6A9CB` (`groupId`,`userId`),
  KEY `IX_7311E812` (`repoGroupId`,`repoArtifactId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SCProductEntry`
--

LOCK TABLES `SCProductEntry` WRITE;
/*!40000 ALTER TABLE `SCProductEntry` DISABLE KEYS */;
INSERT INTO `SCProductEntry` VALUES (10344,10157,10132,10169,'Test Test','2014-04-03 16:39:31','2014-04-03 16:39:37','SC Product Test Name','portlet','','SC Short Product Description','','http://www.ProductTest.com','Test Test','1','1');
/*!40000 ALTER TABLE `SCProductEntry` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SCProductScreenshot`
--

DROP TABLE IF EXISTS `SCProductScreenshot`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `SCProductScreenshot` (
  `productScreenshotId` bigint(20) NOT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `groupId` bigint(20) DEFAULT NULL,
  `productEntryId` bigint(20) DEFAULT NULL,
  `thumbnailId` bigint(20) DEFAULT NULL,
  `fullImageId` bigint(20) DEFAULT NULL,
  `priority` int(11) DEFAULT NULL,
  PRIMARY KEY (`productScreenshotId`),
  KEY `IX_AE8224CC` (`fullImageId`),
  KEY `IX_467956FD` (`productEntryId`),
  KEY `IX_DA913A55` (`productEntryId`,`priority`),
  KEY `IX_6C572DAC` (`thumbnailId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SCProductScreenshot`
--

LOCK TABLES `SCProductScreenshot` WRITE;
/*!40000 ALTER TABLE `SCProductScreenshot` DISABLE KEYS */;
INSERT INTO `SCProductScreenshot` VALUES (10345,10132,10157,10344,10346,10347,0);
/*!40000 ALTER TABLE `SCProductScreenshot` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SCProductVersion`
--

DROP TABLE IF EXISTS `SCProductVersion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `SCProductVersion` (
  `productVersionId` bigint(20) NOT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `userId` bigint(20) DEFAULT NULL,
  `userName` varchar(75) DEFAULT NULL,
  `createDate` datetime DEFAULT NULL,
  `modifiedDate` datetime DEFAULT NULL,
  `productEntryId` bigint(20) DEFAULT NULL,
  `version` varchar(75) DEFAULT NULL,
  `changeLog` longtext,
  `downloadPageURL` longtext,
  `directDownloadURL` varchar(2000) DEFAULT NULL,
  `repoStoreArtifact` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`productVersionId`),
  KEY `IX_7020130F` (`directDownloadURL`(255)),
  KEY `IX_8377A211` (`productEntryId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SCProductVersion`
--

LOCK TABLES `SCProductVersion` WRITE;
/*!40000 ALTER TABLE `SCProductVersion` DISABLE KEYS */;
INSERT INTO `SCProductVersion` VALUES (10353,10132,10169,'Test Test','2014-04-03 16:39:37','2014-04-03 16:39:37',10344,'Product Version Name','This is a log for product version','http://www.liferay.com','',0);
/*!40000 ALTER TABLE `SCProductVersion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SN_MeetupsEntry`
--

DROP TABLE IF EXISTS `SN_MeetupsEntry`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `SN_MeetupsEntry` (
  `meetupsEntryId` bigint(20) NOT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `userId` bigint(20) DEFAULT NULL,
  `userName` varchar(75) DEFAULT NULL,
  `createDate` datetime DEFAULT NULL,
  `modifiedDate` datetime DEFAULT NULL,
  `title` varchar(75) DEFAULT NULL,
  `description` longtext,
  `startDate` datetime DEFAULT NULL,
  `endDate` datetime DEFAULT NULL,
  `totalAttendees` int(11) DEFAULT NULL,
  `maxAttendees` int(11) DEFAULT NULL,
  `price` double DEFAULT NULL,
  `thumbnailId` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`meetupsEntryId`),
  KEY `IX_A56E51DD` (`companyId`),
  KEY `IX_6EA9EEA5` (`userId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SN_MeetupsEntry`
--

LOCK TABLES `SN_MeetupsEntry` WRITE;
/*!40000 ALTER TABLE `SN_MeetupsEntry` DISABLE KEYS */;
/*!40000 ALTER TABLE `SN_MeetupsEntry` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SN_MeetupsRegistration`
--

DROP TABLE IF EXISTS `SN_MeetupsRegistration`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `SN_MeetupsRegistration` (
  `meetupsRegistrationId` bigint(20) NOT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `userId` bigint(20) DEFAULT NULL,
  `userName` varchar(75) DEFAULT NULL,
  `createDate` datetime DEFAULT NULL,
  `modifiedDate` datetime DEFAULT NULL,
  `meetupsEntryId` bigint(20) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `comments` longtext,
  PRIMARY KEY (`meetupsRegistrationId`),
  KEY `IX_A79293FC` (`meetupsEntryId`),
  KEY `IX_BCEB16E2` (`meetupsEntryId`,`status`),
  KEY `IX_3CBE4C36` (`userId`,`meetupsEntryId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SN_MeetupsRegistration`
--

LOCK TABLES `SN_MeetupsRegistration` WRITE;
/*!40000 ALTER TABLE `SN_MeetupsRegistration` DISABLE KEYS */;
/*!40000 ALTER TABLE `SN_MeetupsRegistration` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SN_WallEntry`
--

DROP TABLE IF EXISTS `SN_WallEntry`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `SN_WallEntry` (
  `wallEntryId` bigint(20) NOT NULL,
  `groupId` bigint(20) DEFAULT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `userId` bigint(20) DEFAULT NULL,
  `userName` varchar(75) DEFAULT NULL,
  `createDate` datetime DEFAULT NULL,
  `modifiedDate` datetime DEFAULT NULL,
  `comments` longtext,
  PRIMARY KEY (`wallEntryId`),
  KEY `IX_5C68C960` (`groupId`),
  KEY `IX_F2F6C19A` (`groupId`,`userId`),
  KEY `IX_C46194C4` (`userId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SN_WallEntry`
--

LOCK TABLES `SN_WallEntry` WRITE;
/*!40000 ALTER TABLE `SN_WallEntry` DISABLE KEYS */;
/*!40000 ALTER TABLE `SN_WallEntry` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ServiceComponent`
--

DROP TABLE IF EXISTS `ServiceComponent`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ServiceComponent` (
  `serviceComponentId` bigint(20) NOT NULL,
  `buildNamespace` varchar(75) DEFAULT NULL,
  `buildNumber` bigint(20) DEFAULT NULL,
  `buildDate` bigint(20) DEFAULT NULL,
  `data_` longtext,
  PRIMARY KEY (`serviceComponentId`),
  UNIQUE KEY `IX_4F0315B8` (`buildNamespace`,`buildNumber`),
  KEY `IX_7338606F` (`buildNamespace`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ServiceComponent`
--

LOCK TABLES `ServiceComponent` WRITE;
/*!40000 ALTER TABLE `ServiceComponent` DISABLE KEYS */;
INSERT INTO `ServiceComponent` VALUES (10274,'Kaleo',3,1282611222123,'<?xml version=\"1.0\"?>\n\n<data>\n	<tables-sql><![CDATA[create table KaleoAction (\n	kaleoActionId LONG not null primary key,\n	groupId LONG,\n	companyId LONG,\n	userId LONG,\n	userName VARCHAR(200) null,\n	createDate DATE null,\n	modifiedDate DATE null,\n	kaleoDefinitionId LONG,\n	kaleoNodeId LONG,\n	kaleoNodeName VARCHAR(200) null,\n	name VARCHAR(200) null,\n	description STRING null,\n	executionType VARCHAR(20) null,\n	script TEXT null,\n	scriptLanguage VARCHAR(75) null,\n	priority INTEGER\n);\n\ncreate table KaleoDefinition (\n	kaleoDefinitionId LONG not null primary key,\n	groupId LONG,\n	companyId LONG,\n	userId LONG,\n	userName VARCHAR(200) null,\n	createDate DATE null,\n	modifiedDate DATE null,\n	name VARCHAR(200) null,\n	title STRING null,\n	description STRING null,\n	version INTEGER,\n	active_ BOOLEAN,\n	startKaleoNodeId LONG\n);\n\ncreate table KaleoInstance (\n	kaleoInstanceId LONG not null primary key,\n	groupId LONG,\n	companyId LONG,\n	userId LONG,\n	userName VARCHAR(200) null,\n	createDate DATE null,\n	modifiedDate DATE null,\n	kaleoDefinitionId LONG,\n	kaleoDefinitionName VARCHAR(200) null,\n	kaleoDefinitionVersion INTEGER,\n	rootKaleoInstanceTokenId LONG,\n	className VARCHAR(200) null,\n	classPK LONG,\n	completed BOOLEAN,\n	completionDate DATE null,\n	workflowContext TEXT null\n);\n\ncreate table KaleoInstanceToken (\n	kaleoInstanceTokenId LONG not null primary key,\n	groupId LONG,\n	companyId LONG,\n	userId LONG,\n	userName VARCHAR(200) null,\n	createDate DATE null,\n	modifiedDate DATE null,\n	kaleoDefinitionId LONG,\n	kaleoInstanceId LONG,\n	parentKaleoInstanceTokenId LONG,\n	currentKaleoNodeId LONG,\n	currentKaleoNodeName VARCHAR(200) null,\n	className VARCHAR(75) null,\n	classPK LONG,\n	completed BOOLEAN,\n	completionDate DATE null\n);\n\ncreate table KaleoLog (\n	kaleoLogId LONG not null primary key,\n	groupId LONG,\n	companyId LONG,\n	userId LONG,\n	userName VARCHAR(200) null,\n	createDate DATE null,\n	modifiedDate DATE null,\n	kaleoDefinitionId LONG,\n	kaleoInstanceId LONG,\n	kaleoInstanceTokenId LONG,\n	kaleoTaskInstanceTokenId LONG,\n	kaleoNodeId LONG,\n	kaleoNodeName VARCHAR(200) null,\n	terminalKaleoNode BOOLEAN,\n	kaleoActionId LONG,\n	kaleoActionName VARCHAR(200) null,\n	kaleoActionDescription STRING null,\n	previousKaleoNodeId LONG,\n	previousKaleoNodeName VARCHAR(200) null,\n	previousAssigneeClassName VARCHAR(200) null,\n	previousAssigneeClassPK LONG,\n	currentAssigneeClassName VARCHAR(200) null,\n	currentAssigneeClassPK LONG,\n	type_ VARCHAR(50) null,\n	comment_ STRING null,\n	startDate DATE null,\n	endDate DATE null,\n	duration LONG,\n	workflowContext TEXT null\n);\n\ncreate table KaleoNode (\n	kaleoNodeId LONG not null primary key,\n	groupId LONG,\n	companyId LONG,\n	userId LONG,\n	userName VARCHAR(200) null,\n	createDate DATE null,\n	modifiedDate DATE null,\n	kaleoDefinitionId LONG,\n	name VARCHAR(200) null,\n	description STRING null,\n	type_ VARCHAR(20) null,\n	initial_ BOOLEAN,\n	terminal BOOLEAN\n);\n\ncreate table KaleoNotification (\n	kaleoNotificationId LONG not null primary key,\n	groupId LONG,\n	companyId LONG,\n	userId LONG,\n	userName VARCHAR(200) null,\n	createDate DATE null,\n	modifiedDate DATE null,\n	kaleoDefinitionId LONG,\n	kaleoNodeId LONG,\n	kaleoNodeName VARCHAR(200) null,\n	name VARCHAR(200) null,\n	description STRING null,\n	executionType VARCHAR(20) null,\n	template TEXT null,\n	templateLanguage VARCHAR(75) null,\n	notificationTypes VARCHAR(25) null\n);\n\ncreate table KaleoNotificationRecipient (\n	kaleoNotificationRecipientId LONG not null primary key,\n	groupId LONG,\n	companyId LONG,\n	userId LONG,\n	userName VARCHAR(75) null,\n	createDate DATE null,\n	modifiedDate DATE null,\n	kaleoDefinitionId LONG,\n	kaleoNotificationId LONG,\n	recipientClassName VARCHAR(75) null,\n	recipientClassPK LONG,\n	recipientRoleType INTEGER,\n	address VARCHAR(75) null\n);\n\ncreate table KaleoTask (\n	kaleoTaskId LONG not null primary key,\n	groupId LONG,\n	companyId LONG,\n	userId LONG,\n	userName VARCHAR(200) null,\n	createDate DATE null,\n	modifiedDate DATE null,\n	kaleoDefinitionId LONG,\n	kaleoNodeId LONG,\n	name VARCHAR(75) null,\n	description VARCHAR(75) null,\n	dueDateDuration DOUBLE,\n	dueDateScale VARCHAR(75) null\n);\n\ncreate table KaleoTaskAssignment (\n	kaleoTaskAssignmentId LONG not null primary key,\n	groupId LONG,\n	companyId LONG,\n	userId LONG,\n	userName VARCHAR(200) null,\n	createDate DATE null,\n	modifiedDate DATE null,\n	kaleoDefinitionId LONG,\n	kaleoNodeId LONG,\n	kaleoTaskId LONG,\n	assigneeClassName VARCHAR(200) null,\n	assigneeClassPK LONG\n);\n\ncreate table KaleoTaskAssignmentInstance (\n	kaleoTaskAssignmentInstanceId LONG not null primary key,\n	groupId LONG,\n	companyId LONG,\n	userId LONG,\n	userName VARCHAR(75) null,\n	createDate DATE null,\n	modifiedDate DATE null,\n	kaleoDefinitionId LONG,\n	kaleoInstanceId LONG,\n	kaleoInstanceTokenId LONG,\n	kaleoTaskInstanceTokenId LONG,\n	kaleoTaskId LONG,\n	kaleoTaskName VARCHAR(75) null,\n	assigneeClassName VARCHAR(75) null,\n	assigneeClassPK LONG,\n	completed BOOLEAN,\n	completionDate DATE null\n);\n\ncreate table KaleoTaskInstanceToken (\n	kaleoTaskInstanceTokenId LONG not null primary key,\n	groupId LONG,\n	companyId LONG,\n	userId LONG,\n	userName VARCHAR(200) null,\n	createDate DATE null,\n	modifiedDate DATE null,\n	kaleoDefinitionId LONG,\n	kaleoInstanceId LONG,\n	kaleoInstanceTokenId LONG,\n	kaleoTaskId LONG,\n	kaleoTaskName VARCHAR(200) null,\n	className VARCHAR(75) null,\n	classPK LONG,\n	completionUserId LONG,\n	completed BOOLEAN,\n	completionDate DATE null,\n	dueDate DATE null,\n	workflowContext TEXT null\n);\n\ncreate table KaleoTransition (\n	kaleoTransitionId LONG not null primary key,\n	groupId LONG,\n	companyId LONG,\n	userId LONG,\n	userName VARCHAR(200) null,\n	createDate DATE null,\n	modifiedDate DATE null,\n	kaleoDefinitionId LONG,\n	kaleoNodeId LONG,\n	name VARCHAR(200) null,\n	description STRING null,\n	sourceKaleoNodeId LONG,\n	sourceKaleoNodeName VARCHAR(200) null,\n	targetKaleoNodeId LONG,\n	targetKaleoNodeName VARCHAR(200) null,\n	defaultTransition BOOLEAN\n);]]></tables-sql>\n	<sequences-sql><![CDATA[]]></sequences-sql>\n	<indexes-sql><![CDATA[create index IX_50E9112C on KaleoAction (companyId);\ncreate index IX_F95A622 on KaleoAction (kaleoDefinitionId);\ncreate index IX_B88DF9B1 on KaleoAction (kaleoNodeId, executionType);\n\ncreate index IX_40B9112F on KaleoDefinition (companyId);\ncreate index IX_408542BA on KaleoDefinition (companyId, active_);\ncreate index IX_76C781AE on KaleoDefinition (companyId, name);\ncreate index IX_4C23F11B on KaleoDefinition (companyId, name, active_);\ncreate index IX_EC14F81A on KaleoDefinition (companyId, name, version);\n\ncreate index IX_5F2FCD2D on KaleoInstance (companyId);\ncreate index IX_BF5839F8 on KaleoInstance (companyId, kaleoDefinitionName, kaleoDefinitionVersion, completionDate);\ncreate index IX_4DA4D123 on KaleoInstance (kaleoDefinitionId);\ncreate index IX_ACF16238 on KaleoInstance (kaleoDefinitionId, completed);\n\ncreate index IX_153721BE on KaleoInstanceToken (companyId);\ncreate index IX_4A86923B on KaleoInstanceToken (companyId, parentKaleoInstanceTokenId);\ncreate index IX_360D34D9 on KaleoInstanceToken (companyId, parentKaleoInstanceTokenId, completionDate);\ncreate index IX_7BDB04B4 on KaleoInstanceToken (kaleoDefinitionId);\ncreate index IX_F42AAFF6 on KaleoInstanceToken (kaleoInstanceId);\n\ncreate index IX_73B5F4DE on KaleoLog (companyId);\ncreate index IX_6C64B7D4 on KaleoLog (kaleoDefinitionId);\ncreate index IX_5BC6AB16 on KaleoLog (kaleoInstanceId);\ncreate index IX_25157F25 on KaleoLog (kaleoInstanceTokenId, kaleoNodeId, type_);\ncreate index IX_470B9FF8 on KaleoLog (kaleoInstanceTokenId, type_);\ncreate index IX_B0CDCA38 on KaleoLog (kaleoTaskInstanceTokenId);\n\ncreate index IX_C4E9ACE0 on KaleoNode (companyId);\ncreate index IX_F28C443E on KaleoNode (companyId, kaleoDefinitionId);\ncreate index IX_32E94DD6 on KaleoNode (kaleoDefinitionId);\n\ncreate index IX_38829497 on KaleoNotification (companyId);\ncreate index IX_4B968E8D on KaleoNotification (kaleoDefinitionId);\ncreate index IX_A5C459A6 on KaleoNotification (kaleoNodeId, executionType);\n\ncreate index IX_2C8C4AF4 on KaleoNotificationRecipient (companyId);\ncreate index IX_AA6697EA on KaleoNotificationRecipient (kaleoDefinitionId);\ncreate index IX_7F4FED02 on KaleoNotificationRecipient (kaleoNotificationId);\n\ncreate index IX_E1F8B23D on KaleoTask (companyId);\ncreate index IX_3FFA633 on KaleoTask (kaleoDefinitionId);\ncreate index IX_77B3F1A2 on KaleoTask (kaleoNodeId);\n\ncreate index IX_81225C04 on KaleoTaskAssignment (assigneeClassName, kaleoTaskId);\ncreate index IX_611732B0 on KaleoTaskAssignment (companyId);\ncreate index IX_575C03A6 on KaleoTaskAssignment (kaleoDefinitionId);\ncreate index IX_4DD12F58 on KaleoTaskAssignment (kaleoTaskId);\n\ncreate index IX_6E3CDA1B on KaleoTaskAssignmentInstance (companyId);\ncreate index IX_C851011 on KaleoTaskAssignmentInstance (kaleoDefinitionId);\ncreate index IX_67A9EE93 on KaleoTaskAssignmentInstance (kaleoInstanceId);\ncreate index IX_D4C2235B on KaleoTaskAssignmentInstance (kaleoTaskInstanceTokenId);\n\ncreate index IX_997FE723 on KaleoTaskInstanceToken (companyId);\ncreate index IX_608E9519 on KaleoTaskInstanceToken (kaleoDefinitionId);\ncreate index IX_2CE1159B on KaleoTaskInstanceToken (kaleoInstanceId);\n\ncreate index IX_41D6C6D on KaleoTransition (companyId);\ncreate index IX_479F3063 on KaleoTransition (kaleoDefinitionId);\ncreate index IX_A392DFD2 on KaleoTransition (kaleoNodeId);\ncreate index IX_A38E2194 on KaleoTransition (kaleoNodeId, defaultTransition);\ncreate index IX_85268A11 on KaleoTransition (kaleoNodeId, name);]]></indexes-sql>\n</data>'),(10304,'SN',1,1250629154126,'<?xml version=\"1.0\"?>\n\n<data>\n	<tables-sql><![CDATA[create table SN_MeetupsEntry (\r\n	meetupsEntryId LONG not null primary key,\r\n	companyId LONG,\r\n	userId LONG,\r\n	userName VARCHAR(75) null,\r\n	createDate DATE null,\r\n	modifiedDate DATE null,\r\n	title VARCHAR(75) null,\r\n	description STRING null,\r\n	startDate DATE null,\r\n	endDate DATE null,\r\n	totalAttendees INTEGER,\r\n	maxAttendees INTEGER,\r\n	price DOUBLE,\r\n	thumbnailId LONG\r\n);\r\n\r\ncreate table SN_MeetupsRegistration (\r\n	meetupsRegistrationId LONG not null primary key,\r\n	companyId LONG,\r\n	userId LONG,\r\n	userName VARCHAR(75) null,\r\n	createDate DATE null,\r\n	modifiedDate DATE null,\r\n	meetupsEntryId LONG,\r\n	status INTEGER,\r\n	comments STRING null\r\n);\r\n\r\ncreate table SN_WallEntry (\r\n	wallEntryId LONG not null primary key,\r\n	groupId LONG,\r\n	companyId LONG,\r\n	userId LONG,\r\n	userName VARCHAR(75) null,\r\n	createDate DATE null,\r\n	modifiedDate DATE null,\r\n	comments STRING null\r\n);]]></tables-sql>\n	<sequences-sql><![CDATA[]]></sequences-sql>\n	<indexes-sql><![CDATA[create index IX_A56E51DD on SN_MeetupsEntry (companyId);\r\ncreate index IX_6EA9EEA5 on SN_MeetupsEntry (userId);\r\n\r\ncreate index IX_A79293FC on SN_MeetupsRegistration (meetupsEntryId);\r\ncreate index IX_BCEB16E2 on SN_MeetupsRegistration (meetupsEntryId, status);\r\ncreate index IX_3CBE4C36 on SN_MeetupsRegistration (userId, meetupsEntryId);\r\n\r\ncreate index IX_5C68C960 on SN_WallEntry (groupId);\r\ncreate index IX_F2F6C19A on SN_WallEntry (groupId, userId);\r\ncreate index IX_C46194C4 on SN_WallEntry (userId);]]></indexes-sql>\n</data>');
/*!40000 ALTER TABLE `ServiceComponent` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Shard`
--

DROP TABLE IF EXISTS `Shard`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Shard` (
  `shardId` bigint(20) NOT NULL,
  `classNameId` bigint(20) DEFAULT NULL,
  `classPK` bigint(20) DEFAULT NULL,
  `name` varchar(75) DEFAULT NULL,
  PRIMARY KEY (`shardId`),
  KEY `IX_DA5F4359` (`classNameId`,`classPK`),
  KEY `IX_941BA8C3` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Shard`
--

LOCK TABLES `Shard` WRITE;
/*!40000 ALTER TABLE `Shard` DISABLE KEYS */;
INSERT INTO `Shard` VALUES (10133,10008,10132,'default');
/*!40000 ALTER TABLE `Shard` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ShoppingCart`
--

DROP TABLE IF EXISTS `ShoppingCart`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ShoppingCart` (
  `cartId` bigint(20) NOT NULL,
  `groupId` bigint(20) DEFAULT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `userId` bigint(20) DEFAULT NULL,
  `userName` varchar(75) DEFAULT NULL,
  `createDate` datetime DEFAULT NULL,
  `modifiedDate` datetime DEFAULT NULL,
  `itemIds` longtext,
  `couponCodes` varchar(75) DEFAULT NULL,
  `altShipping` int(11) DEFAULT NULL,
  `insure` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`cartId`),
  UNIQUE KEY `IX_FC46FE16` (`groupId`,`userId`),
  KEY `IX_C28B41DC` (`groupId`),
  KEY `IX_54101CC8` (`userId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ShoppingCart`
--

LOCK TABLES `ShoppingCart` WRITE;
/*!40000 ALTER TABLE `ShoppingCart` DISABLE KEYS */;
/*!40000 ALTER TABLE `ShoppingCart` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ShoppingCategory`
--

DROP TABLE IF EXISTS `ShoppingCategory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ShoppingCategory` (
  `categoryId` bigint(20) NOT NULL,
  `groupId` bigint(20) DEFAULT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `userId` bigint(20) DEFAULT NULL,
  `userName` varchar(75) DEFAULT NULL,
  `createDate` datetime DEFAULT NULL,
  `modifiedDate` datetime DEFAULT NULL,
  `parentCategoryId` bigint(20) DEFAULT NULL,
  `name` varchar(75) DEFAULT NULL,
  `description` longtext,
  PRIMARY KEY (`categoryId`),
  KEY `IX_5F615D3E` (`groupId`),
  KEY `IX_1E6464F5` (`groupId`,`parentCategoryId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ShoppingCategory`
--

LOCK TABLES `ShoppingCategory` WRITE;
/*!40000 ALTER TABLE `ShoppingCategory` DISABLE KEYS */;
INSERT INTO `ShoppingCategory` VALUES (10576,10157,10132,10169,'Test Test','2014-04-03 16:53:57','2014-04-03 16:53:57',0,'Category Name','Category Description');
/*!40000 ALTER TABLE `ShoppingCategory` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ShoppingCoupon`
--

DROP TABLE IF EXISTS `ShoppingCoupon`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ShoppingCoupon` (
  `couponId` bigint(20) NOT NULL,
  `groupId` bigint(20) DEFAULT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `userId` bigint(20) DEFAULT NULL,
  `userName` varchar(75) DEFAULT NULL,
  `createDate` datetime DEFAULT NULL,
  `modifiedDate` datetime DEFAULT NULL,
  `code_` varchar(75) DEFAULT NULL,
  `name` varchar(75) DEFAULT NULL,
  `description` longtext,
  `startDate` datetime DEFAULT NULL,
  `endDate` datetime DEFAULT NULL,
  `active_` tinyint(4) DEFAULT NULL,
  `limitCategories` longtext,
  `limitSkus` longtext,
  `minOrder` double DEFAULT NULL,
  `discount` double DEFAULT NULL,
  `discountType` varchar(75) DEFAULT NULL,
  PRIMARY KEY (`couponId`),
  UNIQUE KEY `IX_DC60CFAE` (`code_`),
  KEY `IX_3251AF16` (`groupId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ShoppingCoupon`
--

LOCK TABLES `ShoppingCoupon` WRITE;
/*!40000 ALTER TABLE `ShoppingCoupon` DISABLE KEYS */;
/*!40000 ALTER TABLE `ShoppingCoupon` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ShoppingItem`
--

DROP TABLE IF EXISTS `ShoppingItem`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ShoppingItem` (
  `itemId` bigint(20) NOT NULL,
  `groupId` bigint(20) DEFAULT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `userId` bigint(20) DEFAULT NULL,
  `userName` varchar(75) DEFAULT NULL,
  `createDate` datetime DEFAULT NULL,
  `modifiedDate` datetime DEFAULT NULL,
  `categoryId` bigint(20) DEFAULT NULL,
  `sku` varchar(75) DEFAULT NULL,
  `name` varchar(200) DEFAULT NULL,
  `description` longtext,
  `properties` longtext,
  `fields_` tinyint(4) DEFAULT NULL,
  `fieldsQuantities` longtext,
  `minQuantity` int(11) DEFAULT NULL,
  `maxQuantity` int(11) DEFAULT NULL,
  `price` double DEFAULT NULL,
  `discount` double DEFAULT NULL,
  `taxable` tinyint(4) DEFAULT NULL,
  `shipping` double DEFAULT NULL,
  `useShippingFormula` tinyint(4) DEFAULT NULL,
  `requiresShipping` tinyint(4) DEFAULT NULL,
  `stockQuantity` int(11) DEFAULT NULL,
  `featured_` tinyint(4) DEFAULT NULL,
  `sale_` tinyint(4) DEFAULT NULL,
  `smallImage` tinyint(4) DEFAULT NULL,
  `smallImageId` bigint(20) DEFAULT NULL,
  `smallImageURL` longtext,
  `mediumImage` tinyint(4) DEFAULT NULL,
  `mediumImageId` bigint(20) DEFAULT NULL,
  `mediumImageURL` longtext,
  `largeImage` tinyint(4) DEFAULT NULL,
  `largeImageId` bigint(20) DEFAULT NULL,
  `largeImageURL` longtext,
  PRIMARY KEY (`itemId`),
  UNIQUE KEY `IX_1C717CA6` (`companyId`,`sku`),
  KEY `IX_FEFE7D76` (`groupId`,`categoryId`),
  KEY `IX_903DC750` (`largeImageId`),
  KEY `IX_D217AB30` (`mediumImageId`),
  KEY `IX_FF203304` (`smallImageId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ShoppingItem`
--

LOCK TABLES `ShoppingItem` WRITE;
/*!40000 ALTER TABLE `ShoppingItem` DISABLE KEYS */;
INSERT INTO `ShoppingItem` VALUES (10577,10157,10132,10169,'Test Test','2014-04-03 16:54:02','2014-04-03 16:54:26',0,'ITEM SKU','Item Name','Item Description','Item Properties',1,'1,',1,10,10,0.1,1,1,1,0,0,0,1,0,10578,'',0,10579,'',0,10580,'');
/*!40000 ALTER TABLE `ShoppingItem` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ShoppingItemField`
--

DROP TABLE IF EXISTS `ShoppingItemField`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ShoppingItemField` (
  `itemFieldId` bigint(20) NOT NULL,
  `itemId` bigint(20) DEFAULT NULL,
  `name` varchar(75) DEFAULT NULL,
  `values_` longtext,
  `description` longtext,
  PRIMARY KEY (`itemFieldId`),
  KEY `IX_6D5F9B87` (`itemId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ShoppingItemField`
--

LOCK TABLES `ShoppingItemField` WRITE;
/*!40000 ALTER TABLE `ShoppingItemField` DISABLE KEYS */;
INSERT INTO `ShoppingItemField` VALUES (10582,10577,'Field Name','Field Values','Field Description');
/*!40000 ALTER TABLE `ShoppingItemField` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ShoppingItemPrice`
--

DROP TABLE IF EXISTS `ShoppingItemPrice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ShoppingItemPrice` (
  `itemPriceId` bigint(20) NOT NULL,
  `itemId` bigint(20) DEFAULT NULL,
  `minQuantity` int(11) DEFAULT NULL,
  `maxQuantity` int(11) DEFAULT NULL,
  `price` double DEFAULT NULL,
  `discount` double DEFAULT NULL,
  `taxable` tinyint(4) DEFAULT NULL,
  `shipping` double DEFAULT NULL,
  `useShippingFormula` tinyint(4) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  PRIMARY KEY (`itemPriceId`),
  KEY `IX_EA6FD516` (`itemId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ShoppingItemPrice`
--

LOCK TABLES `ShoppingItemPrice` WRITE;
/*!40000 ALTER TABLE `ShoppingItemPrice` DISABLE KEYS */;
INSERT INTO `ShoppingItemPrice` VALUES (10583,10577,1,10,10,0.1,1,1,1,1),(10584,10577,0,0,0,0,1,0,1,2);
/*!40000 ALTER TABLE `ShoppingItemPrice` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ShoppingOrder`
--

DROP TABLE IF EXISTS `ShoppingOrder`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ShoppingOrder` (
  `orderId` bigint(20) NOT NULL,
  `groupId` bigint(20) DEFAULT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `userId` bigint(20) DEFAULT NULL,
  `userName` varchar(75) DEFAULT NULL,
  `createDate` datetime DEFAULT NULL,
  `modifiedDate` datetime DEFAULT NULL,
  `number_` varchar(75) DEFAULT NULL,
  `tax` double DEFAULT NULL,
  `shipping` double DEFAULT NULL,
  `altShipping` varchar(75) DEFAULT NULL,
  `requiresShipping` tinyint(4) DEFAULT NULL,
  `insure` tinyint(4) DEFAULT NULL,
  `insurance` double DEFAULT NULL,
  `couponCodes` varchar(75) DEFAULT NULL,
  `couponDiscount` double DEFAULT NULL,
  `billingFirstName` varchar(75) DEFAULT NULL,
  `billingLastName` varchar(75) DEFAULT NULL,
  `billingEmailAddress` varchar(75) DEFAULT NULL,
  `billingCompany` varchar(75) DEFAULT NULL,
  `billingStreet` varchar(75) DEFAULT NULL,
  `billingCity` varchar(75) DEFAULT NULL,
  `billingState` varchar(75) DEFAULT NULL,
  `billingZip` varchar(75) DEFAULT NULL,
  `billingCountry` varchar(75) DEFAULT NULL,
  `billingPhone` varchar(75) DEFAULT NULL,
  `shipToBilling` tinyint(4) DEFAULT NULL,
  `shippingFirstName` varchar(75) DEFAULT NULL,
  `shippingLastName` varchar(75) DEFAULT NULL,
  `shippingEmailAddress` varchar(75) DEFAULT NULL,
  `shippingCompany` varchar(75) DEFAULT NULL,
  `shippingStreet` varchar(75) DEFAULT NULL,
  `shippingCity` varchar(75) DEFAULT NULL,
  `shippingState` varchar(75) DEFAULT NULL,
  `shippingZip` varchar(75) DEFAULT NULL,
  `shippingCountry` varchar(75) DEFAULT NULL,
  `shippingPhone` varchar(75) DEFAULT NULL,
  `ccName` varchar(75) DEFAULT NULL,
  `ccType` varchar(75) DEFAULT NULL,
  `ccNumber` varchar(75) DEFAULT NULL,
  `ccExpMonth` int(11) DEFAULT NULL,
  `ccExpYear` int(11) DEFAULT NULL,
  `ccVerNumber` varchar(75) DEFAULT NULL,
  `comments` longtext,
  `ppTxnId` varchar(75) DEFAULT NULL,
  `ppPaymentStatus` varchar(75) DEFAULT NULL,
  `ppPaymentGross` double DEFAULT NULL,
  `ppReceiverEmail` varchar(75) DEFAULT NULL,
  `ppPayerEmail` varchar(75) DEFAULT NULL,
  `sendOrderEmail` tinyint(4) DEFAULT NULL,
  `sendShippingEmail` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`orderId`),
  UNIQUE KEY `IX_D7D6E87A` (`number_`),
  KEY `IX_1D15553E` (`groupId`),
  KEY `IX_119B5630` (`groupId`,`userId`,`ppPaymentStatus`),
  KEY `IX_F474FD89` (`ppTxnId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ShoppingOrder`
--

LOCK TABLES `ShoppingOrder` WRITE;
/*!40000 ALTER TABLE `ShoppingOrder` DISABLE KEYS */;
/*!40000 ALTER TABLE `ShoppingOrder` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ShoppingOrderItem`
--

DROP TABLE IF EXISTS `ShoppingOrderItem`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ShoppingOrderItem` (
  `orderItemId` bigint(20) NOT NULL,
  `orderId` bigint(20) DEFAULT NULL,
  `itemId` varchar(75) DEFAULT NULL,
  `sku` varchar(75) DEFAULT NULL,
  `name` varchar(200) DEFAULT NULL,
  `description` longtext,
  `properties` longtext,
  `price` double DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  `shippedDate` datetime DEFAULT NULL,
  PRIMARY KEY (`orderItemId`),
  KEY `IX_B5F82C7A` (`orderId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ShoppingOrderItem`
--

LOCK TABLES `ShoppingOrderItem` WRITE;
/*!40000 ALTER TABLE `ShoppingOrderItem` DISABLE KEYS */;
/*!40000 ALTER TABLE `ShoppingOrderItem` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SocialActivity`
--

DROP TABLE IF EXISTS `SocialActivity`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `SocialActivity` (
  `activityId` bigint(20) NOT NULL,
  `groupId` bigint(20) DEFAULT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `userId` bigint(20) DEFAULT NULL,
  `createDate` bigint(20) DEFAULT NULL,
  `mirrorActivityId` bigint(20) DEFAULT NULL,
  `classNameId` bigint(20) DEFAULT NULL,
  `classPK` bigint(20) DEFAULT NULL,
  `type_` int(11) DEFAULT NULL,
  `extraData` longtext,
  `receiverUserId` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`activityId`),
  UNIQUE KEY `IX_8F32DEC9` (`groupId`,`userId`,`createDate`,`classNameId`,`classPK`,`type_`,`receiverUserId`),
  KEY `IX_82E39A0C` (`classNameId`),
  KEY `IX_A853C757` (`classNameId`,`classPK`),
  KEY `IX_64B1BC66` (`companyId`),
  KEY `IX_2A2468` (`groupId`),
  KEY `IX_1271F25F` (`mirrorActivityId`),
  KEY `IX_1F00C374` (`mirrorActivityId`,`classNameId`,`classPK`),
  KEY `IX_121CA3CB` (`receiverUserId`),
  KEY `IX_3504B8BC` (`userId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SocialActivity`
--

LOCK TABLES `SocialActivity` WRITE;
/*!40000 ALTER TABLE `SocialActivity` DISABLE KEYS */;
INSERT INTO `SocialActivity` VALUES (1,10388,10132,10169,1396543496812,0,10129,10403,1,'',0),(2,10388,10132,10169,1396543512774,0,10129,10403,1,'',0),(3,10626,10132,10169,1396544293008,0,10095,10647,1,'',0),(6,10157,10132,10169,1396544647484,0,10072,10723,1,'',0);
/*!40000 ALTER TABLE `SocialActivity` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SocialEquityAssetEntry`
--

DROP TABLE IF EXISTS `SocialEquityAssetEntry`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `SocialEquityAssetEntry` (
  `equityAssetEntryId` bigint(20) NOT NULL,
  `groupId` bigint(20) DEFAULT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `userId` bigint(20) DEFAULT NULL,
  `assetEntryId` bigint(20) DEFAULT NULL,
  `informationK` double DEFAULT NULL,
  `informationB` double DEFAULT NULL,
  PRIMARY KEY (`equityAssetEntryId`),
  UNIQUE KEY `IX_22F6B5CB` (`assetEntryId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SocialEquityAssetEntry`
--

LOCK TABLES `SocialEquityAssetEntry` WRITE;
/*!40000 ALTER TABLE `SocialEquityAssetEntry` DISABLE KEYS */;
/*!40000 ALTER TABLE `SocialEquityAssetEntry` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SocialEquityGroupSetting`
--

DROP TABLE IF EXISTS `SocialEquityGroupSetting`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `SocialEquityGroupSetting` (
  `equityGroupSettingId` bigint(20) NOT NULL,
  `groupId` bigint(20) DEFAULT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `classNameId` bigint(20) DEFAULT NULL,
  `type_` int(11) DEFAULT NULL,
  `enabled` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`equityGroupSettingId`),
  UNIQUE KEY `IX_E4F84168` (`groupId`,`classNameId`,`type_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SocialEquityGroupSetting`
--

LOCK TABLES `SocialEquityGroupSetting` WRITE;
/*!40000 ALTER TABLE `SocialEquityGroupSetting` DISABLE KEYS */;
INSERT INTO `SocialEquityGroupSetting` VALUES (10496,10481,10132,10012,1,1),(10497,10481,10132,10012,2,1),(10504,10481,10132,10129,1,1),(10505,10481,10132,10129,2,1),(10510,10481,10132,10095,1,1),(10511,10481,10132,10095,2,1),(10518,10481,10132,10068,1,1),(10519,10481,10132,10068,2,1);
/*!40000 ALTER TABLE `SocialEquityGroupSetting` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SocialEquityHistory`
--

DROP TABLE IF EXISTS `SocialEquityHistory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `SocialEquityHistory` (
  `equityHistoryId` bigint(20) NOT NULL,
  `groupId` bigint(20) DEFAULT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `userId` bigint(20) DEFAULT NULL,
  `createDate` datetime DEFAULT NULL,
  `personalEquity` int(11) DEFAULT NULL,
  PRIMARY KEY (`equityHistoryId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SocialEquityHistory`
--

LOCK TABLES `SocialEquityHistory` WRITE;
/*!40000 ALTER TABLE `SocialEquityHistory` DISABLE KEYS */;
/*!40000 ALTER TABLE `SocialEquityHistory` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SocialEquityLog`
--

DROP TABLE IF EXISTS `SocialEquityLog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `SocialEquityLog` (
  `equityLogId` bigint(20) NOT NULL,
  `groupId` bigint(20) DEFAULT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `userId` bigint(20) DEFAULT NULL,
  `assetEntryId` bigint(20) DEFAULT NULL,
  `actionId` varchar(75) DEFAULT NULL,
  `actionDate` int(11) DEFAULT NULL,
  `active_` tinyint(4) DEFAULT NULL,
  `expiration` int(11) DEFAULT NULL,
  `type_` int(11) DEFAULT NULL,
  `value` int(11) DEFAULT NULL,
  PRIMARY KEY (`equityLogId`),
  UNIQUE KEY `IX_55B2F00C` (`userId`,`assetEntryId`,`actionId`,`actionDate`,`active_`,`type_`),
  KEY `IX_DB6958D2` (`assetEntryId`,`actionId`,`actionDate`,`active_`,`type_`),
  KEY `IX_FEB4055A` (`assetEntryId`,`actionId`,`active_`,`type_`),
  KEY `IX_E8DA181D` (`assetEntryId`,`type_`,`active_`),
  KEY `IX_15A017B` (`userId`,`actionId`,`actionDate`,`active_`,`type_`),
  KEY `IX_3525A383` (`userId`,`actionId`,`active_`,`type_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SocialEquityLog`
--

LOCK TABLES `SocialEquityLog` WRITE;
/*!40000 ALTER TABLE `SocialEquityLog` DISABLE KEYS */;
/*!40000 ALTER TABLE `SocialEquityLog` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SocialEquitySetting`
--

DROP TABLE IF EXISTS `SocialEquitySetting`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `SocialEquitySetting` (
  `equitySettingId` bigint(20) NOT NULL,
  `groupId` bigint(20) DEFAULT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `classNameId` bigint(20) DEFAULT NULL,
  `actionId` varchar(75) DEFAULT NULL,
  `dailyLimit` int(11) DEFAULT NULL,
  `lifespan` int(11) DEFAULT NULL,
  `type_` int(11) DEFAULT NULL,
  `uniqueEntry` tinyint(4) DEFAULT NULL,
  `value` int(11) DEFAULT NULL,
  PRIMARY KEY (`equitySettingId`),
  UNIQUE KEY `IX_903C1B28` (`groupId`,`classNameId`,`actionId`,`type_`),
  KEY `IX_F3AAD60D` (`groupId`,`classNameId`,`actionId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SocialEquitySetting`
--

LOCK TABLES `SocialEquitySetting` WRITE;
/*!40000 ALTER TABLE `SocialEquitySetting` DISABLE KEYS */;
INSERT INTO `SocialEquitySetting` VALUES (10498,10481,10132,10129,'VIEW',0,365,1,0,1),(10499,10481,10132,10129,'VIEW',0,365,2,0,1),(10500,10481,10132,10129,'ADD_PAGE',0,365,1,0,10),(10501,10481,10132,10129,'ADD_PAGE',0,365,2,0,5),(10502,10481,10132,10129,'ADD_DISCUSSION',0,365,1,0,2),(10503,10481,10132,10129,'ADD_DISCUSSION',0,365,2,0,2),(10506,10481,10132,10095,'REPLY_TO_MESSAGE',0,30,2,0,10),(10507,10481,10132,10095,'ADD_MESSAGE',0,30,2,0,20),(10508,10481,10132,10095,'VIEW',0,30,2,0,1),(10509,10481,10132,10095,'ADD_VOTE',0,365,1,0,10),(10512,10481,10132,10068,'VIEW',0,365,1,0,1),(10513,10481,10132,10068,'VIEW',0,365,2,0,1),(10514,10481,10132,10068,'ADD_ENTRY',0,365,1,0,10),(10515,10481,10132,10068,'ADD_ENTRY',0,365,2,0,5),(10516,10481,10132,10068,'ADD_DISCUSSION',0,365,1,0,2),(10517,10481,10132,10068,'ADD_DISCUSSION',0,365,2,0,2);
/*!40000 ALTER TABLE `SocialEquitySetting` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SocialEquityUser`
--

DROP TABLE IF EXISTS `SocialEquityUser`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `SocialEquityUser` (
  `equityUserId` bigint(20) NOT NULL,
  `groupId` bigint(20) DEFAULT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `userId` bigint(20) DEFAULT NULL,
  `contributionK` double DEFAULT NULL,
  `contributionB` double DEFAULT NULL,
  `participationK` double DEFAULT NULL,
  `participationB` double DEFAULT NULL,
  `rank` int(11) DEFAULT NULL,
  PRIMARY KEY (`equityUserId`),
  UNIQUE KEY `IX_D65D3521` (`groupId`,`userId`),
  KEY `IX_6B42B3E7` (`groupId`),
  KEY `IX_945E27C7` (`groupId`,`rank`),
  KEY `IX_166A8F03` (`rank`),
  KEY `IX_6ECBD5D` (`userId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SocialEquityUser`
--

LOCK TABLES `SocialEquityUser` WRITE;
/*!40000 ALTER TABLE `SocialEquityUser` DISABLE KEYS */;
/*!40000 ALTER TABLE `SocialEquityUser` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SocialRelation`
--

DROP TABLE IF EXISTS `SocialRelation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `SocialRelation` (
  `uuid_` varchar(75) DEFAULT NULL,
  `relationId` bigint(20) NOT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `createDate` bigint(20) DEFAULT NULL,
  `userId1` bigint(20) DEFAULT NULL,
  `userId2` bigint(20) DEFAULT NULL,
  `type_` int(11) DEFAULT NULL,
  PRIMARY KEY (`relationId`),
  UNIQUE KEY `IX_12A92145` (`userId1`,`userId2`,`type_`),
  KEY `IX_61171E99` (`companyId`),
  KEY `IX_95135D1C` (`companyId`,`type_`),
  KEY `IX_C31A64C6` (`type_`),
  KEY `IX_5A40CDCC` (`userId1`),
  KEY `IX_4B52BE89` (`userId1`,`type_`),
  KEY `IX_5A40D18D` (`userId2`),
  KEY `IX_3F9C2FA8` (`userId2`,`type_`),
  KEY `IX_F0CA24A5` (`uuid_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SocialRelation`
--

LOCK TABLES `SocialRelation` WRITE;
/*!40000 ALTER TABLE `SocialRelation` DISABLE KEYS */;
/*!40000 ALTER TABLE `SocialRelation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SocialRequest`
--

DROP TABLE IF EXISTS `SocialRequest`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `SocialRequest` (
  `uuid_` varchar(75) DEFAULT NULL,
  `requestId` bigint(20) NOT NULL,
  `groupId` bigint(20) DEFAULT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `userId` bigint(20) DEFAULT NULL,
  `createDate` bigint(20) DEFAULT NULL,
  `modifiedDate` bigint(20) DEFAULT NULL,
  `classNameId` bigint(20) DEFAULT NULL,
  `classPK` bigint(20) DEFAULT NULL,
  `type_` int(11) DEFAULT NULL,
  `extraData` longtext,
  `receiverUserId` bigint(20) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  PRIMARY KEY (`requestId`),
  UNIQUE KEY `IX_36A90CA7` (`userId`,`classNameId`,`classPK`,`type_`,`receiverUserId`),
  UNIQUE KEY `IX_4F973EFE` (`uuid_`,`groupId`),
  KEY `IX_D3425487` (`classNameId`,`classPK`,`type_`,`receiverUserId`,`status`),
  KEY `IX_A90FE5A0` (`companyId`),
  KEY `IX_32292ED1` (`receiverUserId`),
  KEY `IX_D9380CB7` (`receiverUserId`,`status`),
  KEY `IX_80F7A9C2` (`userId`),
  KEY `IX_CC86A444` (`userId`,`classNameId`,`classPK`,`type_`,`status`),
  KEY `IX_AB5906A8` (`userId`,`status`),
  KEY `IX_49D5872C` (`uuid_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SocialRequest`
--

LOCK TABLES `SocialRequest` WRITE;
/*!40000 ALTER TABLE `SocialRequest` DISABLE KEYS */;
/*!40000 ALTER TABLE `SocialRequest` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Subscription`
--

DROP TABLE IF EXISTS `Subscription`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Subscription` (
  `subscriptionId` bigint(20) NOT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `userId` bigint(20) DEFAULT NULL,
  `userName` varchar(75) DEFAULT NULL,
  `createDate` datetime DEFAULT NULL,
  `modifiedDate` datetime DEFAULT NULL,
  `classNameId` bigint(20) DEFAULT NULL,
  `classPK` bigint(20) DEFAULT NULL,
  `frequency` varchar(75) DEFAULT NULL,
  PRIMARY KEY (`subscriptionId`),
  UNIQUE KEY `IX_2E1A92D4` (`companyId`,`userId`,`classNameId`,`classPK`),
  KEY `IX_786D171A` (`companyId`,`classNameId`,`classPK`),
  KEY `IX_54243AFD` (`userId`),
  KEY `IX_E8F34171` (`userId`,`classNameId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Subscription`
--

LOCK TABLES `Subscription` WRITE;
/*!40000 ALTER TABLE `Subscription` DISABLE KEYS */;
/*!40000 ALTER TABLE `Subscription` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `TasksProposal`
--

DROP TABLE IF EXISTS `TasksProposal`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `TasksProposal` (
  `proposalId` bigint(20) NOT NULL,
  `groupId` bigint(20) DEFAULT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `userId` bigint(20) DEFAULT NULL,
  `userName` varchar(75) DEFAULT NULL,
  `createDate` datetime DEFAULT NULL,
  `modifiedDate` datetime DEFAULT NULL,
  `classNameId` bigint(20) DEFAULT NULL,
  `classPK` varchar(75) DEFAULT NULL,
  `name` varchar(75) DEFAULT NULL,
  `description` longtext,
  `publishDate` datetime DEFAULT NULL,
  `dueDate` datetime DEFAULT NULL,
  PRIMARY KEY (`proposalId`),
  UNIQUE KEY `IX_181A4A1B` (`classNameId`,`classPK`),
  KEY `IX_7FB27324` (`groupId`),
  KEY `IX_6EEC675E` (`groupId`,`userId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `TasksProposal`
--

LOCK TABLES `TasksProposal` WRITE;
/*!40000 ALTER TABLE `TasksProposal` DISABLE KEYS */;
/*!40000 ALTER TABLE `TasksProposal` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `TasksReview`
--

DROP TABLE IF EXISTS `TasksReview`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `TasksReview` (
  `reviewId` bigint(20) NOT NULL,
  `groupId` bigint(20) DEFAULT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `userId` bigint(20) DEFAULT NULL,
  `userName` varchar(75) DEFAULT NULL,
  `createDate` datetime DEFAULT NULL,
  `modifiedDate` datetime DEFAULT NULL,
  `proposalId` bigint(20) DEFAULT NULL,
  `assignedByUserId` bigint(20) DEFAULT NULL,
  `assignedByUserName` varchar(75) DEFAULT NULL,
  `stage` int(11) DEFAULT NULL,
  `completed` tinyint(4) DEFAULT NULL,
  `rejected` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`reviewId`),
  UNIQUE KEY `IX_5C6BE4C7` (`userId`,`proposalId`),
  KEY `IX_4D0C7F8D` (`proposalId`),
  KEY `IX_70AFEA01` (`proposalId`,`stage`),
  KEY `IX_1894B29A` (`proposalId`,`stage`,`completed`),
  KEY `IX_41AFC20C` (`proposalId`,`stage`,`completed`,`rejected`),
  KEY `IX_36F512E6` (`userId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `TasksReview`
--

LOCK TABLES `TasksReview` WRITE;
/*!40000 ALTER TABLE `TasksReview` DISABLE KEYS */;
/*!40000 ALTER TABLE `TasksReview` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Team`
--

DROP TABLE IF EXISTS `Team`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Team` (
  `teamId` bigint(20) NOT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `userId` bigint(20) DEFAULT NULL,
  `userName` varchar(75) DEFAULT NULL,
  `createDate` datetime DEFAULT NULL,
  `modifiedDate` datetime DEFAULT NULL,
  `groupId` bigint(20) DEFAULT NULL,
  `name` varchar(75) DEFAULT NULL,
  `description` longtext,
  PRIMARY KEY (`teamId`),
  UNIQUE KEY `IX_143DC786` (`groupId`,`name`),
  KEY `IX_AE6E9907` (`groupId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Team`
--

LOCK TABLES `Team` WRITE;
/*!40000 ALTER TABLE `Team` DISABLE KEYS */;
INSERT INTO `Team` VALUES (10381,10132,10169,'Test Test','2014-04-03 16:42:17','2014-04-03 16:42:17',10357,'Site Team Name','Site Team Description');
/*!40000 ALTER TABLE `Team` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Ticket`
--

DROP TABLE IF EXISTS `Ticket`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Ticket` (
  `ticketId` bigint(20) NOT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `createDate` datetime DEFAULT NULL,
  `classNameId` bigint(20) DEFAULT NULL,
  `classPK` bigint(20) DEFAULT NULL,
  `key_` varchar(75) DEFAULT NULL,
  `expirationDate` datetime DEFAULT NULL,
  PRIMARY KEY (`ticketId`),
  KEY `IX_B2468446` (`key_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Ticket`
--

LOCK TABLES `Ticket` WRITE;
/*!40000 ALTER TABLE `Ticket` DISABLE KEYS */;
/*!40000 ALTER TABLE `Ticket` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `UserGroup`
--

DROP TABLE IF EXISTS `UserGroup`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `UserGroup` (
  `userGroupId` bigint(20) NOT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `parentUserGroupId` bigint(20) DEFAULT NULL,
  `name` varchar(75) DEFAULT NULL,
  `description` longtext,
  PRIMARY KEY (`userGroupId`),
  UNIQUE KEY `IX_23EAD0D` (`companyId`,`name`),
  KEY `IX_524FEFCE` (`companyId`),
  KEY `IX_69771487` (`companyId`,`parentUserGroupId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `UserGroup`
--

LOCK TABLES `UserGroup` WRITE;
/*!40000 ALTER TABLE `UserGroup` DISABLE KEYS */;
INSERT INTO `UserGroup` VALUES (10384,10132,0,'UG UserGroup Name','');
/*!40000 ALTER TABLE `UserGroup` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `UserGroupGroupRole`
--

DROP TABLE IF EXISTS `UserGroupGroupRole`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `UserGroupGroupRole` (
  `userGroupId` bigint(20) NOT NULL,
  `groupId` bigint(20) NOT NULL,
  `roleId` bigint(20) NOT NULL,
  PRIMARY KEY (`userGroupId`,`groupId`,`roleId`),
  KEY `IX_CCBE4063` (`groupId`),
  KEY `IX_CAB0CCC8` (`groupId`,`roleId`),
  KEY `IX_1CDF88C` (`roleId`),
  KEY `IX_DCDED558` (`userGroupId`),
  KEY `IX_73C52252` (`userGroupId`,`groupId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `UserGroupGroupRole`
--

LOCK TABLES `UserGroupGroupRole` WRITE;
/*!40000 ALTER TABLE `UserGroupGroupRole` DISABLE KEYS */;
/*!40000 ALTER TABLE `UserGroupGroupRole` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `UserGroupRole`
--

DROP TABLE IF EXISTS `UserGroupRole`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `UserGroupRole` (
  `userId` bigint(20) NOT NULL,
  `groupId` bigint(20) NOT NULL,
  `roleId` bigint(20) NOT NULL,
  PRIMARY KEY (`userId`,`groupId`,`roleId`),
  KEY `IX_1B988D7A` (`groupId`),
  KEY `IX_871412DF` (`groupId`,`roleId`),
  KEY `IX_887A2C95` (`roleId`),
  KEY `IX_887BE56A` (`userId`),
  KEY `IX_4D040680` (`userId`,`groupId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `UserGroupRole`
--

LOCK TABLES `UserGroupRole` WRITE;
/*!40000 ALTER TABLE `UserGroupRole` DISABLE KEYS */;
INSERT INTO `UserGroupRole` VALUES (10169,10357,10145),(10365,10357,10363),(10169,10388,10145),(10169,10435,10145),(10169,10481,10145),(10169,10585,10145),(10169,10617,10145),(10169,10626,10145),(10169,10663,10145),(10169,10678,10145),(10169,10752,10145);
/*!40000 ALTER TABLE `UserGroupRole` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `UserIdMapper`
--

DROP TABLE IF EXISTS `UserIdMapper`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `UserIdMapper` (
  `userIdMapperId` bigint(20) NOT NULL,
  `userId` bigint(20) DEFAULT NULL,
  `type_` varchar(75) DEFAULT NULL,
  `description` varchar(75) DEFAULT NULL,
  `externalUserId` varchar(75) DEFAULT NULL,
  PRIMARY KEY (`userIdMapperId`),
  UNIQUE KEY `IX_41A32E0D` (`type_`,`externalUserId`),
  UNIQUE KEY `IX_D1C44A6E` (`userId`,`type_`),
  KEY `IX_E60EA987` (`userId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `UserIdMapper`
--

LOCK TABLES `UserIdMapper` WRITE;
/*!40000 ALTER TABLE `UserIdMapper` DISABLE KEYS */;
/*!40000 ALTER TABLE `UserIdMapper` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `UserTracker`
--

DROP TABLE IF EXISTS `UserTracker`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `UserTracker` (
  `userTrackerId` bigint(20) NOT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `userId` bigint(20) DEFAULT NULL,
  `modifiedDate` datetime DEFAULT NULL,
  `sessionId` varchar(200) DEFAULT NULL,
  `remoteAddr` varchar(75) DEFAULT NULL,
  `remoteHost` varchar(75) DEFAULT NULL,
  `userAgent` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`userTrackerId`),
  KEY `IX_29BA1CF5` (`companyId`),
  KEY `IX_46B0AE8E` (`sessionId`),
  KEY `IX_E4EFBA8D` (`userId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `UserTracker`
--

LOCK TABLES `UserTracker` WRITE;
/*!40000 ALTER TABLE `UserTracker` DISABLE KEYS */;
INSERT INTO `UserTracker` VALUES (1,10132,10169,'2014-04-03 16:39:47','F4E0B1012F9E825467C716FEB3EB9AF5','127.0.0.1','127.0.0.1','Mozilla/5.0 (Windows NT 6.1; WOW64; rv:22.0) Gecko/20100101 Firefox/22.0'),(2,10132,10169,'2014-04-03 16:44:27','7E633B578F49A363DB571D234F4E00EC','127.0.0.1','127.0.0.1','Mozilla/5.0 (Windows NT 6.1; WOW64; rv:22.0) Gecko/20100101 Firefox/22.0'),(3,10132,10169,'2014-04-03 16:46:29','BB19F558618171DA5A57F543DA10F2C9','127.0.0.1','127.0.0.1','Mozilla/5.0 (Windows NT 6.1; WOW64; rv:22.0) Gecko/20100101 Firefox/22.0'),(4,10132,10169,'2014-04-03 16:47:17','430B9E4F550A7327489D76F6E8D1390F','127.0.0.1','127.0.0.1','Mozilla/5.0 (Windows NT 6.1; WOW64; rv:22.0) Gecko/20100101 Firefox/22.0'),(5,10132,10169,'2014-04-03 16:49:35','A1818F5252C7B7BDD47A7B853EAE5C64','127.0.0.1','127.0.0.1','Mozilla/5.0 (Windows NT 6.1; WOW64; rv:22.0) Gecko/20100101 Firefox/22.0'),(6,10132,10169,'2014-04-03 16:50:33','A3815612377D7C2C877BEE3F960DCD3D','127.0.0.1','127.0.0.1','Mozilla/5.0 (Windows NT 6.1; WOW64; rv:22.0) Gecko/20100101 Firefox/22.0'),(7,10132,10169,'2014-04-03 16:50:56','518628BBD93A76486BA7B81EA2CA7288','127.0.0.1','127.0.0.1','Mozilla/5.0 (Windows NT 6.1; WOW64; rv:22.0) Gecko/20100101 Firefox/22.0'),(8,10132,10169,'2014-04-03 16:51:18','49AA69127F4F5A3A48241751E843BADE','127.0.0.1','127.0.0.1','Mozilla/5.0 (Windows NT 6.1; WOW64; rv:22.0) Gecko/20100101 Firefox/22.0'),(9,10132,10169,'2014-04-03 16:51:59','4650858DDFFC890EE9312F9A364C7108','127.0.0.1','127.0.0.1','Mozilla/5.0 (Windows NT 6.1; WOW64; rv:22.0) Gecko/20100101 Firefox/22.0'),(10,10132,10543,'2014-04-03 16:52:10','1CC1E263021C0E5EDB4CBC66E056A59D','127.0.0.1','127.0.0.1','Mozilla/5.0 (Windows NT 6.1; WOW64; rv:22.0) Gecko/20100101 Firefox/22.0'),(12,10132,10543,'2014-04-03 16:52:46','E5472B71A74291738EED18D1E30EDAC8','127.0.0.1','127.0.0.1','Mozilla/5.0 (Windows NT 6.1; WOW64; rv:22.0) Gecko/20100101 Firefox/22.0'),(13,10132,10169,'2014-04-03 16:53:02','3F626A0211679447285509DC381CFC0D','127.0.0.1','127.0.0.1','Mozilla/5.0 (Windows NT 6.1; WOW64; rv:22.0) Gecko/20100101 Firefox/22.0'),(14,10132,10169,'2014-04-03 16:53:30','6207870294503AC470701E27948DA362','127.0.0.1','127.0.0.1','Mozilla/5.0 (Windows NT 6.1; WOW64; rv:22.0) Gecko/20100101 Firefox/22.0'),(15,10132,10169,'2014-04-03 16:55:39','687DC589734A0807CF80D976B718BC51','127.0.0.1','127.0.0.1','Mozilla/5.0 (Windows NT 6.1; WOW64; rv:22.0) Gecko/20100101 Firefox/22.0'),(17,10132,10589,'2014-04-03 16:56:28','0E322ED426FDAFABACFEF9D28A875248','127.0.0.1','127.0.0.1','Mozilla/5.0 (Windows NT 6.1; WOW64; rv:22.0) Gecko/20100101 Firefox/22.0'),(18,10132,10169,'2014-04-03 16:56:37','FDE5E1D21EEC3CF2163A8A71C454DCCB','127.0.0.1','127.0.0.1','Mozilla/5.0 (Windows NT 6.1; WOW64; rv:22.0) Gecko/20100101 Firefox/22.0'),(19,10132,10589,'2014-04-03 16:57:03','C1A1227374A59D5D24CE2E3E33340321','127.0.0.1','127.0.0.1','Mozilla/5.0 (Windows NT 6.1; WOW64; rv:22.0) Gecko/20100101 Firefox/22.0'),(20,10132,10169,'2014-04-03 16:58:22','5991B81CE406CA5456F61D56BF1803C4','127.0.0.1','127.0.0.1','Mozilla/5.0 (Windows NT 6.1; WOW64; rv:22.0) Gecko/20100101 Firefox/22.0'),(21,10132,10169,'2014-04-03 16:59:05','9CAC0A25FF8E9E2DC43FA13FF7A739DB','127.0.0.1','127.0.0.1','Mozilla/5.0 (Windows NT 6.1; WOW64; rv:22.0) Gecko/20100101 Firefox/22.0'),(22,10132,10169,'2014-04-03 17:00:07','8E28A7FE2A1E0EEB94F8AD2ABDD83E3A','127.0.0.1','127.0.0.1','Mozilla/5.0 (Windows NT 6.1; WOW64; rv:22.0) Gecko/20100101 Firefox/22.0'),(23,10132,10169,'2014-04-03 17:01:51','80543AC8C67EB424E4D02359500B4300','127.0.0.1','127.0.0.1','Mozilla/5.0 (Windows NT 6.1; WOW64; rv:22.0) Gecko/20100101 Firefox/22.0'),(24,10132,10169,'2014-04-03 17:03:42','28C11E287BEEAAE532ABCD51BD120919','127.0.0.1','127.0.0.1','Mozilla/5.0 (Windows NT 6.1; WOW64; rv:22.0) Gecko/20100101 Firefox/22.0'),(25,10132,10169,'2014-04-03 17:04:19','E1C4FB323070D945E61B7461254CE211','127.0.0.1','127.0.0.1','Mozilla/5.0 (Windows NT 6.1; WOW64; rv:22.0) Gecko/20100101 Firefox/22.0'),(26,10132,10169,'2014-04-03 17:05:09','81F09D8AC60EE84BD74ACAF152E254BD','127.0.0.1','127.0.0.1','Mozilla/5.0 (Windows NT 6.1; WOW64; rv:22.0) Gecko/20100101 Firefox/22.0'),(27,10132,10169,'2014-04-03 17:05:53','3F9F08C6853758A4C59872835BB17127','127.0.0.1','127.0.0.1','Mozilla/5.0 (Windows NT 6.1; WOW64; rv:22.0) Gecko/20100101 Firefox/22.0'),(28,10132,10169,'2014-04-03 17:06:49','1DE9560B8F46DCF93ACE5D0C992F5027','127.0.0.1','127.0.0.1','Mozilla/5.0 (Windows NT 6.1; WOW64; rv:22.0) Gecko/20100101 Firefox/22.0');
/*!40000 ALTER TABLE `UserTracker` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `UserTrackerPath`
--

DROP TABLE IF EXISTS `UserTrackerPath`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `UserTrackerPath` (
  `userTrackerPathId` bigint(20) NOT NULL,
  `userTrackerId` bigint(20) DEFAULT NULL,
  `path_` longtext,
  `pathDate` datetime DEFAULT NULL,
  PRIMARY KEY (`userTrackerPathId`),
  KEY `IX_14D8BCC0` (`userTrackerId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `UserTrackerPath`
--

LOCK TABLES `UserTrackerPath` WRITE;
/*!40000 ALTER TABLE `UserTrackerPath` DISABLE KEYS */;
INSERT INTO `UserTrackerPath` VALUES (1,1,'/portal/layout?p_l_id=10160','2014-04-03 16:38:59'),(2,1,'/portal/update_terms_of_use?doAsUserId=&referer=%2Fc%3FdoAsUserId%3D','2014-04-03 16:39:01'),(3,1,'/portal/layout?p_l_id=10160','2014-04-03 16:39:01'),(4,1,'/portal/update_reminder_query','2014-04-03 16:39:02'),(5,1,'/portal/layout?p_l_id=10160','2014-04-03 16:39:02'),(6,1,'/portal/layout?p_l_id=10160','2014-04-03 16:39:04'),(7,1,'/layout_management/update_page','2014-04-03 16:39:07'),(8,1,'/portal/layout?p_l_id=10333','2014-04-03 16:39:07'),(9,1,'/portal/layout?p_l_id=10160','2014-04-03 16:39:10'),(10,1,'/portal/layout?p_l_id=10333','2014-04-03 16:39:10'),(11,1,'/portal/update_layout','2014-04-03 16:39:14'),(12,1,'/portal/layout?p_l_id=10333&p_p_state=normal&p_p_lifecycle=0&p_p_id=98&_98_tabs1=framework_versions&_98_struts_action=%2fsoftware_catalog%2fview&p_p_mode=view','2014-04-03 16:39:16'),(13,1,'/portal/layout?p_l_id=10333&p_p_state=normal&p_p_lifecycle=0&p_p_id=98&_98_struts_action=%2fsoftware_catalog%2fedit_framework_version&p_p_mode=view','2014-04-03 16:39:17'),(14,1,'/portal/layout?p_l_id=10333','2014-04-03 16:39:19'),(15,1,'/portal/layout?p_l_id=10333&p_p_state=normal&p_p_lifecycle=0&p_p_id=98&_98_tabs1=framework_versions&_98_struts_action=%2fsoftware_catalog%2fview&p_p_mode=view','2014-04-03 16:39:19'),(16,1,'/portal/layout?p_l_id=10333&p_p_state=normal&p_p_lifecycle=0&p_p_id=98&_98_tabs1=licenses&_98_struts_action=%2fsoftware_catalog%2fview&p_p_mode=view','2014-04-03 16:39:20'),(17,1,'/portal/layout?p_l_id=10333&p_p_state=normal&p_p_lifecycle=0&p_p_id=98&_98_struts_action=%2fsoftware_catalog%2fedit_license&p_p_mode=view','2014-04-03 16:39:21'),(18,1,'/portal/layout?p_l_id=10333','2014-04-03 16:39:22'),(19,1,'/portal/layout?p_l_id=10333&p_p_state=normal&p_p_lifecycle=0&p_p_id=98&_98_tabs1=licenses&_98_struts_action=%2fsoftware_catalog%2fview&p_p_mode=view','2014-04-03 16:39:23'),(20,1,'/portal/layout?p_l_id=10333&p_p_state=normal&p_p_lifecycle=0&p_p_id=98&_98_tabs1=products&_98_struts_action=%2fsoftware_catalog%2fview&p_p_mode=view','2014-04-03 16:39:24'),(21,1,'/portal/layout?p_l_id=10333&p_p_state=normal&p_p_lifecycle=0&p_p_id=98&_98_struts_action=%2fsoftware_catalog%2fedit_product_entry&p_p_mode=view','2014-04-03 16:39:25'),(22,1,'/portal/layout?p_l_id=10333','2014-04-03 16:39:29'),(23,1,'/portal/layout?p_l_id=10333','2014-04-03 16:39:31'),(24,1,'/portal/layout?p_l_id=10333&p_p_state=normal&p_p_lifecycle=0&p_p_id=98&_98_tabs1=products&_98_struts_action=%2fsoftware_catalog%2fview&p_p_mode=view','2014-04-03 16:39:31'),(25,1,'/portal/layout?p_l_id=10333&p_p_state=normal&p_p_lifecycle=0&p_p_id=98&_98_tabs1=products&_98_struts_action=%2fsoftware_catalog%2fview&p_p_mode=view','2014-04-03 16:39:32'),(26,1,'/portal/layout?p_l_id=10333&p_p_state=normal&p_p_lifecycle=0&p_p_id=98&_98_productEntryId=10344&_98_struts_action=%2fsoftware_catalog%2fview_product_entry&p_p_mode=view','2014-04-03 16:39:33'),(27,1,'/portal/layout?p_l_id=10333&p_p_state=normal&p_p_lifecycle=0&p_p_id=98&_98_productEntryId=10344&_98_struts_action=%2fsoftware_catalog%2fedit_product_version&p_p_mode=view','2014-04-03 16:39:34'),(28,1,'/portal/layout?p_l_id=10333','2014-04-03 16:39:37'),(29,1,'/portal/layout?p_l_id=10333&p_p_state=normal&p_p_lifecycle=0&p_p_id=98&_98_productEntryId=10344&_98_struts_action=%2fsoftware_catalog%2fview_product_entry&p_p_mode=view','2014-04-03 16:39:37'),(30,1,'/portal/layout?p_l_id=10160','2014-04-03 16:39:43'),(31,1,'/portal/layout?p_l_id=10160','2014-04-03 16:39:46'),(32,1,'/portal/logout','2014-04-03 16:39:47'),(33,2,'/portal/layout?p_l_id=10160','2014-04-03 16:39:51'),(34,2,'/portal/layout?p_l_id=10160','2014-04-03 16:39:54'),(35,2,'/portal/layout?p_l_id=10152','2014-04-03 16:39:56'),(36,2,'/portal/layout?p_l_id=10152','2014-04-03 16:39:57'),(37,2,'/portal/layout?p_l_id=10152','2014-04-03 16:39:59'),(38,2,'/portal/session_click','2014-04-03 16:39:59'),(39,2,'/portal/layout?p_l_id=10152','2014-04-03 16:40:01'),(40,2,'/portal/layout?p_l_id=10152','2014-04-03 16:40:01'),(41,2,'/portal/layout?p_l_id=10152','2014-04-03 16:40:02'),(42,2,'/portal/layout?p_l_id=10160','2014-04-03 16:40:03'),(43,2,'/portal/layout?p_l_id=10152','2014-04-03 16:40:04'),(44,2,'/portal/layout?p_l_id=10152','2014-04-03 16:40:05'),(45,2,'/portal/layout?p_l_id=10160','2014-04-03 16:40:06'),(46,2,'/portal/layout?p_l_id=10152','2014-04-03 16:40:08'),(47,2,'/portal/layout?p_l_id=10152','2014-04-03 16:40:09'),(48,2,'/portal/layout?p_l_id=10152','2014-04-03 16:40:10'),(49,2,'/portal/layout?p_l_id=10160','2014-04-03 16:40:11'),(50,2,'/portal/layout?p_l_id=10152','2014-04-03 16:40:12'),(51,2,'/portal/layout?p_l_id=10152','2014-04-03 16:40:13'),(52,2,'/portal/layout?p_l_id=10152','2014-04-03 16:40:16'),(53,2,'/portal/session_click','2014-04-03 16:40:16'),(54,2,'/portal/layout?p_l_id=10152','2014-04-03 16:40:18'),(55,2,'/portal/layout?p_l_id=10152','2014-04-03 16:40:18'),(56,2,'/portal/layout?p_l_id=10152','2014-04-03 16:40:20'),(57,2,'/portal/layout?p_l_id=10152','2014-04-03 16:40:21'),(58,2,'/portal/layout?p_l_id=10152','2014-04-03 16:40:23'),(59,2,'/portal/layout?p_l_id=10152','2014-04-03 16:40:24'),(60,2,'/portal/layout?p_l_id=10152','2014-04-03 16:40:25'),(61,2,'/portal/layout?p_l_id=10152','2014-04-03 16:40:27'),(62,2,'/portal/layout?p_l_id=10152','2014-04-03 16:40:27'),(63,2,'/portal/layout?p_l_id=10160','2014-04-03 16:40:29'),(64,2,'/portal/layout?p_l_id=10152','2014-04-03 16:40:30'),(65,2,'/portal/layout?p_l_id=10152','2014-04-03 16:40:32'),(66,2,'/portal/layout?p_l_id=10152','2014-04-03 16:40:33'),(67,2,'/portal/layout?p_l_id=10160','2014-04-03 16:40:34'),(68,2,'/portal/layout?p_l_id=10152','2014-04-03 16:40:35'),(69,2,'/portal/layout?p_l_id=10152','2014-04-03 16:40:36'),(70,2,'/portal/layout?p_l_id=10152','2014-04-03 16:40:39'),(71,2,'/portal/layout?p_l_id=10152','2014-04-03 16:40:41'),(72,2,'/portal/layout?p_l_id=10152','2014-04-03 16:40:41'),(73,2,'/portal/layout?p_l_id=10160','2014-04-03 16:40:42'),(74,2,'/portal/layout?p_l_id=10152','2014-04-03 16:40:43'),(75,2,'/portal/layout?p_l_id=10152','2014-04-03 16:40:45'),(76,2,'/portal/layout?p_l_id=10152','2014-04-03 16:40:46'),(77,2,'/portal/session_click','2014-04-03 16:40:47'),(78,2,'/portal/layout?p_l_id=10152','2014-04-03 16:40:48'),(79,2,'/portal/layout?p_l_id=10152','2014-04-03 16:40:50'),(80,2,'/portal/layout?p_l_id=10152','2014-04-03 16:40:51'),(81,2,'/portal/json_service','2014-04-03 16:40:53'),(82,2,'/portal/layout?p_l_id=10160','2014-04-03 16:40:55'),(83,2,'/portal/layout?p_l_id=10152','2014-04-03 16:40:57'),(84,2,'/portal/layout?p_l_id=10152','2014-04-03 16:40:58'),(85,2,'/portal/layout?p_l_id=10152','2014-04-03 16:40:59'),(86,2,'/portal/layout?p_l_id=10152','2014-04-03 16:41:01'),(87,2,'/portal/layout?p_l_id=10152','2014-04-03 16:41:03'),(88,2,'/portal/layout?p_l_id=10152','2014-04-03 16:41:04'),(89,2,'/portal/layout?p_l_id=10152','2014-04-03 16:41:05'),(90,2,'/portal/layout?p_l_id=10152','2014-04-03 16:41:08'),(91,2,'/portal/layout?p_l_id=10152','2014-04-03 16:41:08'),(92,2,'/portal/layout?p_l_id=10160','2014-04-03 16:41:09'),(93,2,'/portal/layout?p_l_id=10152','2014-04-03 16:41:10'),(94,2,'/portal/layout?p_l_id=10152','2014-04-03 16:41:11'),(95,2,'/portal/layout?p_l_id=10152','2014-04-03 16:41:13'),(96,2,'/portal/layout?p_l_id=10152','2014-04-03 16:41:15'),(97,2,'/portal/layout?p_l_id=10152','2014-04-03 16:41:16'),(98,2,'/portal/layout?p_l_id=10152','2014-04-03 16:41:17'),(99,2,'/portal/layout?p_l_id=10152','2014-04-03 16:41:18'),(100,2,'/portal/layout?p_l_id=10152','2014-04-03 16:41:19'),(101,2,'/portal/layout?p_l_id=10152','2014-04-03 16:41:20'),(102,2,'/portal/layout?p_l_id=10152','2014-04-03 16:41:23'),(103,2,'/portal/layout?p_l_id=10152','2014-04-03 16:41:23'),(104,2,'/portal/layout?p_l_id=10152','2014-04-03 16:41:24'),(105,2,'/portal/layout?p_l_id=10160','2014-04-03 16:41:26'),(106,2,'/portal/layout?p_l_id=10152','2014-04-03 16:41:27'),(107,2,'/portal/layout?p_l_id=10152','2014-04-03 16:41:29'),(108,2,'/portal/layout?p_l_id=10152','2014-04-03 16:41:30'),(109,2,'/portal/json_service','2014-04-03 16:41:31'),(110,2,'/portal/layout?p_l_id=10152','2014-04-03 16:41:31'),(111,2,'/portal/session_click','2014-04-03 16:41:31'),(112,2,'/portal/json_service','2014-04-03 16:41:32'),(113,2,'/portal/layout?p_l_id=10152','2014-04-03 16:41:34'),(114,2,'/portal/session_click','2014-04-03 16:41:34'),(115,2,'/portal/layout?p_l_id=10152','2014-04-03 16:41:34'),(116,2,'/portal/json_service','2014-04-03 16:41:35'),(117,2,'/portal/json_service','2014-04-03 16:41:35'),(118,2,'/portal/json_service','2014-04-03 16:41:35'),(119,2,'/portal/layout?p_l_id=10160','2014-04-03 16:41:36'),(120,2,'/portal/layout?p_l_id=10152','2014-04-03 16:41:37'),(121,2,'/portal/layout?p_l_id=10152','2014-04-03 16:41:39'),(122,2,'/portal/layout?p_l_id=10152','2014-04-03 16:41:40'),(123,2,'/portal/json_service','2014-04-03 16:41:41'),(124,2,'/portal/layout?p_l_id=10152','2014-04-03 16:41:42'),(125,2,'/portal/json_service','2014-04-03 16:41:42'),(126,2,'/portal/json_service','2014-04-03 16:41:42'),(127,2,'/portal/layout?p_l_id=10152','2014-04-03 16:41:45'),(128,2,'/portal/layout?p_l_id=10152','2014-04-03 16:41:46'),(129,2,'/portal/layout?p_l_id=10152','2014-04-03 16:41:48'),(130,2,'/portal/layout?p_l_id=10152','2014-04-03 16:41:50'),(131,2,'/portal/layout?p_l_id=10152','2014-04-03 16:41:50'),(132,2,'/portal/layout?p_l_id=10160','2014-04-03 16:41:52'),(133,2,'/portal/layout?p_l_id=10152','2014-04-03 16:41:54'),(134,2,'/portal/layout?p_l_id=10152','2014-04-03 16:41:55'),(135,2,'/portal/layout?p_l_id=10152','2014-04-03 16:41:56'),(136,2,'/portal/layout?p_l_id=10152','2014-04-03 16:41:58'),(137,2,'/portal/layout?p_l_id=10152','2014-04-03 16:42:00'),(138,2,'/portal/layout?p_l_id=10152','2014-04-03 16:42:01'),(139,2,'/portal/layout?p_l_id=10152','2014-04-03 16:42:01'),(140,2,'/portal/json_service','2014-04-03 16:42:02'),(141,2,'/portal/layout?p_l_id=10152','2014-04-03 16:42:03'),(142,2,'/portal/json_service','2014-04-03 16:42:03'),(143,2,'/portal/layout?p_l_id=10152','2014-04-03 16:42:04'),(144,2,'/portal/layout?p_l_id=10152','2014-04-03 16:42:04'),(145,2,'/portal/json_service','2014-04-03 16:42:05'),(146,2,'/portal/json_service','2014-04-03 16:42:05'),(147,2,'/portal/layout?p_l_id=10160','2014-04-03 16:42:05'),(148,2,'/portal/layout?p_l_id=10152','2014-04-03 16:42:07'),(149,2,'/portal/layout?p_l_id=10152','2014-04-03 16:42:09'),(150,2,'/portal/layout?p_l_id=10152','2014-04-03 16:42:10'),(151,2,'/portal/layout?p_l_id=10152','2014-04-03 16:42:11'),(152,2,'/portal/layout?p_l_id=10152','2014-04-03 16:42:13'),(153,2,'/portal/layout?p_l_id=10152','2014-04-03 16:42:14'),(154,2,'/portal/layout?p_l_id=10152','2014-04-03 16:42:17'),(155,2,'/portal/layout?p_l_id=10152','2014-04-03 16:42:17'),(156,2,'/portal/layout?p_l_id=10160','2014-04-03 16:42:18'),(157,2,'/portal/layout?p_l_id=10152','2014-04-03 16:42:20'),(158,2,'/portal/layout?p_l_id=10152','2014-04-03 16:42:21'),(159,2,'/portal/layout?p_l_id=10152','2014-04-03 16:42:22'),(160,2,'/portal/layout?p_l_id=10152','2014-04-03 16:42:24'),(161,2,'/portal/session_click','2014-04-03 16:42:24'),(162,2,'/portal/layout?p_l_id=10152','2014-04-03 16:42:25'),(163,2,'/portal/layout?p_l_id=10152','2014-04-03 16:42:25'),(164,2,'/portal/layout?p_l_id=10160','2014-04-03 16:42:26'),(165,2,'/portal/layout?p_l_id=10152','2014-04-03 16:42:28'),(166,2,'/portal/layout?p_l_id=10152','2014-04-03 16:42:29'),(167,2,'/portal/layout?p_l_id=10152','2014-04-03 16:42:30'),(168,2,'/portal/layout?p_l_id=10152','2014-04-03 16:42:32'),(169,2,'/portal/layout?p_l_id=10152','2014-04-03 16:42:35'),(170,2,'/portal/layout?p_l_id=10152','2014-04-03 16:42:36'),(171,2,'/portal/layout?p_l_id=10152','2014-04-03 16:42:37'),(172,2,'/portal/layout?p_l_id=10152','2014-04-03 16:42:39'),(173,2,'/portal/layout?p_l_id=10152','2014-04-03 16:42:39'),(174,2,'/portal/layout?p_l_id=10152','2014-04-03 16:42:40'),(175,2,'/portal/layout?p_l_id=10160','2014-04-03 16:42:42'),(176,2,'/portal/layout?p_l_id=10152','2014-04-03 16:42:43'),(177,2,'/portal/layout?p_l_id=10152','2014-04-03 16:42:45'),(178,2,'/portal/layout?p_l_id=10152','2014-04-03 16:42:46'),(179,2,'/portal/layout?p_l_id=10152','2014-04-03 16:42:48'),(180,2,'/portal/layout?p_l_id=10152','2014-04-03 16:42:49'),(181,2,'/portal/layout?p_l_id=10152','2014-04-03 16:42:50'),(182,2,'/portal/layout?p_l_id=10152','2014-04-03 16:42:51'),(183,2,'/portal/layout?p_l_id=10152','2014-04-03 16:42:52'),(184,2,'/portal/layout?p_l_id=10152','2014-04-03 16:42:54'),(185,2,'/portal/layout?p_l_id=10152','2014-04-03 16:42:54'),(186,2,'/portal/layout?p_l_id=10160','2014-04-03 16:42:55'),(187,2,'/portal/layout?p_l_id=10152','2014-04-03 16:42:56'),(188,2,'/portal/layout?p_l_id=10152','2014-04-03 16:42:58'),(189,2,'/portal/layout?p_l_id=10152','2014-04-03 16:42:59'),(190,2,'/portal/layout?p_l_id=10152','2014-04-03 16:43:00'),(191,2,'/portal/layout?p_l_id=10152','2014-04-03 16:43:02'),(192,2,'/portal/layout?p_l_id=10152','2014-04-03 16:43:04'),(193,2,'/portal/layout?p_l_id=10152','2014-04-03 16:43:05'),(194,2,'/portal/layout?p_l_id=10152','2014-04-03 16:43:06'),(195,2,'/portal/layout?p_l_id=10152','2014-04-03 16:43:08'),(196,2,'/portal/layout?p_l_id=10152','2014-04-03 16:43:08'),(197,2,'/portal/layout?p_l_id=10160','2014-04-03 16:43:09'),(198,2,'/portal/layout?p_l_id=10152','2014-04-03 16:43:10'),(199,2,'/portal/layout?p_l_id=10152','2014-04-03 16:43:12'),(200,2,'/portal/layout?p_l_id=10152','2014-04-03 16:43:13'),(201,2,'/portal/layout?p_l_id=10152','2014-04-03 16:43:14'),(202,2,'/portal/layout?p_l_id=10152','2014-04-03 16:43:16'),(203,2,'/portal/layout?p_l_id=10152','2014-04-03 16:43:18'),(204,2,'/portal/layout?p_l_id=10160','2014-04-03 16:44:23'),(205,2,'/portal/layout?p_l_id=10160','2014-04-03 16:44:26'),(206,2,'/portal/logout','2014-04-03 16:44:27'),(207,3,'/portal/layout?p_l_id=10160','2014-04-03 16:44:30'),(208,3,'/portal/layout?p_l_id=10160','2014-04-03 16:44:33'),(209,3,'/portal/layout?p_l_id=10152','2014-04-03 16:44:34'),(210,3,'/portal/layout?p_l_id=10152','2014-04-03 16:44:35'),(211,3,'/portal/layout?p_l_id=10152','2014-04-03 16:44:37'),(212,3,'/portal/layout?p_l_id=10152','2014-04-03 16:44:38'),(213,3,'/portal/layout?p_l_id=10152','2014-04-03 16:44:38'),(214,3,'/portal/layout?p_l_id=10152','2014-04-03 16:44:39'),(215,3,'/portal/layout?p_l_id=10160','2014-04-03 16:44:40'),(216,3,'/portal/layout?p_l_id=10152','2014-04-03 16:44:42'),(217,3,'/portal/layout?p_l_id=10152','2014-04-03 16:44:43'),(218,3,'/portal/layout?p_l_id=10152','2014-04-03 16:44:45'),(219,3,'/portal/layout?p_l_id=10152','2014-04-03 16:44:46'),(220,3,'/portal/layout?p_l_id=10152','2014-04-03 16:44:49'),(221,3,'/portal/layout?p_l_id=10152','2014-04-03 16:44:49'),(222,3,'/portal/layout?p_l_id=10392','2014-04-03 16:44:52'),(223,3,'/portal/layout?p_l_id=10392','2014-04-03 16:44:53'),(224,3,'/portal/update_layout','2014-04-03 16:44:56'),(225,3,'/portal/layout?p_l_id=10160','2014-04-03 16:44:58'),(226,3,'/portal/layout?p_l_id=10152','2014-04-03 16:44:59'),(227,3,'/portal/layout?p_l_id=10152','2014-04-03 16:45:01'),(228,3,'/portal/layout?p_l_id=10152','2014-04-03 16:45:02'),(229,3,'/portal/layout?p_l_id=10152','2014-04-03 16:45:03'),(230,3,'/portal/session_click','2014-04-03 16:45:03'),(231,3,'/portal/layout?p_l_id=10152','2014-04-03 16:45:05'),(232,3,'/portal/layout?p_l_id=10152','2014-04-03 16:45:05'),(233,3,'/portal/session_click','2014-04-03 16:45:05'),(234,3,'/portal/layout?p_l_id=10392','2014-04-03 16:45:08'),(235,3,'/portal/layout?p_l_id=10392','2014-04-03 16:45:09'),(236,3,'/portal/layout?p_l_id=10392','2014-04-03 16:45:10'),(237,3,'/portal/layout?p_l_id=10392','2014-04-03 16:45:12'),(238,3,'/portal/layout?p_l_id=10392','2014-04-03 16:45:13'),(239,3,'/ratings/rate_entry','2014-04-03 16:45:14'),(240,3,'/portal/layout?p_l_id=10392','2014-04-03 16:45:15'),(241,3,'/portal/layout?p_l_id=10392','2014-04-03 16:45:16'),(242,3,'/portal/layout?p_l_id=10392','2014-04-03 16:45:19'),(243,3,'/portal/layout?p_l_id=10392','2014-04-03 16:45:19'),(244,3,'/portal/layout?p_l_id=10160','2014-04-03 16:46:25'),(245,3,'/portal/layout?p_l_id=10160','2014-04-03 16:46:27'),(246,3,'/portal/logout','2014-04-03 16:46:29'),(247,4,'/portal/layout?p_l_id=10160','2014-04-03 16:46:32'),(248,4,'/portal/layout?p_l_id=10160','2014-04-03 16:46:34'),(249,4,'/portal/layout?p_l_id=10152','2014-04-03 16:46:36'),(250,4,'/portal/layout?p_l_id=10152','2014-04-03 16:46:37'),(251,4,'/portal/layout?p_l_id=10152','2014-04-03 16:46:38'),(252,4,'/portal/session_click','2014-04-03 16:46:38'),(253,4,'/portal/layout?p_l_id=10152','2014-04-03 16:46:41'),(254,4,'/portal/layout?p_l_id=10152','2014-04-03 16:46:41'),(255,4,'/portal/layout?p_l_id=10160','2014-04-03 16:46:44'),(256,4,'/layout_management/update_page','2014-04-03 16:46:47'),(257,4,'/portal/layout?p_l_id=10424','2014-04-03 16:46:48'),(258,4,'/portal/layout?p_l_id=10160','2014-04-03 16:46:50'),(259,4,'/portal/layout?p_l_id=10424','2014-04-03 16:46:51'),(260,4,'/portal/layout?p_l_id=10160','2014-04-03 16:46:53'),(261,4,'/portal/layout?p_l_id=10424','2014-04-03 16:46:54'),(262,4,'/portal/update_layout','2014-04-03 16:46:57'),(263,4,'/portal/layout?p_l_id=10424','2014-04-03 16:47:00'),(264,4,'/portal/layout?p_l_id=10424','2014-04-03 16:47:02'),(265,4,'/portal/layout?p_l_id=10160','2014-04-03 16:47:05'),(266,4,'/portal/layout?p_l_id=10424','2014-04-03 16:47:06'),(267,4,'/portal/layout?p_l_id=10424','2014-04-03 16:47:07'),(268,4,'/portal/layout?p_l_id=10160','2014-04-03 16:47:13'),(269,4,'/portal/layout?p_l_id=10160','2014-04-03 16:47:15'),(270,4,'/portal/logout','2014-04-03 16:47:17'),(271,5,'/portal/layout?p_l_id=10160','2014-04-03 16:47:21'),(272,5,'/portal/layout?p_l_id=10160','2014-04-03 16:47:24'),(273,5,'/portal/layout?p_l_id=10152','2014-04-03 16:47:25'),(274,5,'/portal/layout?p_l_id=10152','2014-04-03 16:47:26'),(275,5,'/portal/layout?p_l_id=10152','2014-04-03 16:47:28'),(276,5,'/portal/layout?p_l_id=10152','2014-04-03 16:47:29'),(277,5,'/portal/layout?p_l_id=10152','2014-04-03 16:47:29'),(278,5,'/portal/layout?p_l_id=10152','2014-04-03 16:47:31'),(279,5,'/portal/layout?p_l_id=10160','2014-04-03 16:47:32'),(280,5,'/portal/layout?p_l_id=10152','2014-04-03 16:47:34'),(281,5,'/portal/layout?p_l_id=10152','2014-04-03 16:47:35'),(282,5,'/portal/layout?p_l_id=10152','2014-04-03 16:47:37'),(283,5,'/portal/layout?p_l_id=10152','2014-04-03 16:47:38'),(284,5,'/portal/layout?p_l_id=10152','2014-04-03 16:47:40'),(285,5,'/portal/layout?p_l_id=10152','2014-04-03 16:47:40'),(286,5,'/portal/layout?p_l_id=10160','2014-04-03 16:47:41'),(287,5,'/portal/layout?p_l_id=10152','2014-04-03 16:47:43'),(288,5,'/portal/layout?p_l_id=10152','2014-04-03 16:47:45'),(289,5,'/portal/layout?p_l_id=10152','2014-04-03 16:47:45'),(290,5,'/portal/layout?p_l_id=10152','2014-04-03 16:47:47'),(291,5,'/portal/session_click','2014-04-03 16:47:47'),(292,5,'/portal/layout?p_l_id=10152','2014-04-03 16:47:47'),(293,5,'/portal/session_click','2014-04-03 16:47:48'),(294,5,'/portal/layout?p_l_id=10152','2014-04-03 16:47:50'),(295,5,'/portal/layout?p_l_id=10152','2014-04-03 16:47:50'),(296,5,'/portal/layout?p_l_id=10439','2014-04-03 16:47:53'),(297,5,'/portal/layout?p_l_id=10439','2014-04-03 16:47:54'),(298,5,'/portal/update_layout','2014-04-03 16:47:58'),(299,5,'/portal/layout?p_l_id=10160','2014-04-03 16:47:59'),(300,5,'/portal/layout?p_l_id=10152','2014-04-03 16:48:00'),(301,5,'/portal/layout?p_l_id=10152','2014-04-03 16:48:02'),(302,5,'/portal/layout?p_l_id=10152','2014-04-03 16:48:03'),(303,5,'/portal/layout?p_l_id=10152','2014-04-03 16:48:05'),(304,5,'/portal/layout?p_l_id=10152','2014-04-03 16:48:05'),(305,5,'/portal/layout?p_l_id=10152','2014-04-03 16:48:08'),(306,5,'/portal/layout?p_l_id=10152','2014-04-03 16:48:08'),(307,5,'/portal/layout?p_l_id=10152','2014-04-03 16:48:10'),(308,5,'/portal/layout?p_l_id=10152','2014-04-03 16:48:10'),(309,5,'/portal/layout?p_l_id=10160','2014-04-03 16:48:12'),(310,5,'/portal/layout?p_l_id=10152','2014-04-03 16:48:13'),(311,5,'/portal/layout?p_l_id=10152','2014-04-03 16:48:15'),(312,5,'/portal/layout?p_l_id=10152','2014-04-03 16:48:16'),(313,5,'/portal/layout?p_l_id=10152','2014-04-03 16:48:17'),(314,5,'/portal/layout?p_l_id=10152','2014-04-03 16:48:18'),(315,5,'/portal/layout?p_l_id=10152','2014-04-03 16:48:21'),(316,5,'/portal/layout?p_l_id=10152','2014-04-03 16:48:28'),(317,5,'/portal/layout?p_l_id=10152','2014-04-03 16:48:30'),(318,5,'/portal/layout?p_l_id=10152','2014-04-03 16:48:30'),(319,5,'/portal/layout?p_l_id=10160','2014-04-03 16:48:32'),(320,5,'/portal/layout?p_l_id=10152','2014-04-03 16:48:33'),(321,5,'/portal/layout?p_l_id=10152','2014-04-03 16:48:35'),(322,5,'/portal/layout?p_l_id=10152','2014-04-03 16:48:36'),(323,5,'/portal/layout?p_l_id=10152','2014-04-03 16:48:37'),(324,5,'/portal/layout?p_l_id=10152','2014-04-03 16:48:40'),(325,5,'/portal/layout?p_l_id=10152','2014-04-03 16:48:45'),(326,5,'/portal/layout?p_l_id=10152','2014-04-03 16:48:49'),(327,5,'/portal/layout?p_l_id=10152','2014-04-03 16:48:49'),(328,5,'/portal/layout?p_l_id=10160','2014-04-03 16:48:51'),(329,5,'/portal/layout?p_l_id=10152','2014-04-03 16:48:52'),(330,5,'/portal/layout?p_l_id=10152','2014-04-03 16:48:54'),(331,5,'/portal/layout?p_l_id=10152','2014-04-03 16:48:55'),(332,5,'/portal/json_service','2014-04-03 16:48:56'),(333,5,'/portal/json_service','2014-04-03 16:48:56'),(334,5,'/portal/json_service','2014-04-03 16:49:01'),(335,5,'/portal/json_service','2014-04-03 16:49:01'),(336,5,'/portal/json_service','2014-04-03 16:49:01'),(337,5,'/portal/json_service','2014-04-03 16:49:01'),(338,5,'/portal/session_click','2014-04-03 16:49:03'),(339,5,'/portal/json_service','2014-04-03 16:49:04'),(340,5,'/portal/json_service','2014-04-03 16:49:04'),(341,5,'/portal/json_service','2014-04-03 16:49:05'),(342,5,'/portal/json_service','2014-04-03 16:49:06'),(343,5,'/portal/layout?p_l_id=10439','2014-04-03 16:49:08'),(344,5,'/portal/layout?p_l_id=10439','2014-04-03 16:49:09'),(345,5,'/portal/layout?p_l_id=10439','2014-04-03 16:49:12'),(346,5,'/portal/layout?p_l_id=10439','2014-04-03 16:49:14'),(347,5,'/portal/layout?p_l_id=10439','2014-04-03 16:49:14'),(348,5,'/portal/layout?p_l_id=10439','2014-04-03 16:49:17'),(349,5,'/portal/layout?p_l_id=10439','2014-04-03 16:49:18'),(350,5,'/portal/layout?p_l_id=10439','2014-04-03 16:49:19'),(351,5,'/portal/session_click','2014-04-03 16:49:21'),(352,5,'/portal/json_service','2014-04-03 16:49:22'),(353,5,'/asset/get_categories?vocabularyId=10469&limit=50&start=0&end=50','2014-04-03 16:49:22'),(354,5,'/portal/layout?p_l_id=10439','2014-04-03 16:49:24'),(355,5,'/portal/layout?p_l_id=10439','2014-04-03 16:49:24'),(356,5,'/portal/layout?p_l_id=10160','2014-04-03 16:49:30'),(357,5,'/portal/layout?p_l_id=10160','2014-04-03 16:49:33'),(358,5,'/portal/logout','2014-04-03 16:49:35'),(359,6,'/portal/layout?p_l_id=10160','2014-04-03 16:49:38'),(360,6,'/portal/layout?p_l_id=10160','2014-04-03 16:49:41'),(361,6,'/portal/layout?p_l_id=10152','2014-04-03 16:49:42'),(362,6,'/portal/layout?p_l_id=10152','2014-04-03 16:49:43'),(363,6,'/portal/layout?p_l_id=10152','2014-04-03 16:49:45'),(364,6,'/portal/layout?p_l_id=10152','2014-04-03 16:49:46'),(365,6,'/portal/layout?p_l_id=10152','2014-04-03 16:49:46'),(366,6,'/portal/layout?p_l_id=10152','2014-04-03 16:49:47'),(367,6,'/portal/layout?p_l_id=10160','2014-04-03 16:49:48'),(368,6,'/portal/layout?p_l_id=10152','2014-04-03 16:49:50'),(369,6,'/portal/layout?p_l_id=10152','2014-04-03 16:49:51'),(370,6,'/portal/layout?p_l_id=10152','2014-04-03 16:49:53'),(371,6,'/portal/layout?p_l_id=10152','2014-04-03 16:49:54'),(372,6,'/portal/layout?p_l_id=10152','2014-04-03 16:49:56'),(373,6,'/portal/layout?p_l_id=10152','2014-04-03 16:49:56'),(374,6,'/portal/layout?p_l_id=10485','2014-04-03 16:50:00'),(375,6,'/portal/layout?p_l_id=10485','2014-04-03 16:50:01'),(376,6,'/portal/update_layout','2014-04-03 16:50:05'),(377,6,'/portal/layout?p_l_id=10160','2014-04-03 16:50:05'),(378,6,'/portal/layout?p_l_id=10152','2014-04-03 16:50:07'),(379,6,'/portal/layout?p_l_id=10152','2014-04-03 16:50:08'),(380,6,'/portal/layout?p_l_id=10152','2014-04-03 16:50:09'),(381,6,'/portal/session_click','2014-04-03 16:50:10'),(382,6,'/portal/layout?p_l_id=10152','2014-04-03 16:50:11'),(383,6,'/portal/layout?p_l_id=10152','2014-04-03 16:50:11'),(384,6,'/portal/layout?p_l_id=10160','2014-04-03 16:50:12'),(385,6,'/portal/layout?p_l_id=10152','2014-04-03 16:50:14'),(386,6,'/portal/layout?p_l_id=10152','2014-04-03 16:50:16'),(387,6,'/portal/layout?p_l_id=10152','2014-04-03 16:50:17'),(388,6,'/portal/layout?p_l_id=10152','2014-04-03 16:50:18'),(389,6,'/portal/session_click','2014-04-03 16:50:18'),(390,6,'/portal/layout?p_l_id=10160','2014-04-03 16:50:29'),(391,6,'/portal/layout?p_l_id=10160','2014-04-03 16:50:32'),(392,6,'/portal/logout','2014-04-03 16:50:33'),(393,7,'/portal/layout?p_l_id=10160','2014-04-03 16:50:37'),(394,7,'/portal/layout?p_l_id=10160','2014-04-03 16:50:39'),(395,7,'/portal/layout?p_l_id=10152','2014-04-03 16:50:40'),(396,7,'/portal/layout?p_l_id=10152','2014-04-03 16:50:41'),(397,7,'/portal/layout?p_l_id=10152','2014-04-03 16:50:42'),(398,7,'/portal/session_click','2014-04-03 16:50:42'),(399,7,'/portal/layout?p_l_id=10152','2014-04-03 16:50:44'),(400,7,'/portal/layout?p_l_id=10152','2014-04-03 16:50:44'),(401,7,'/portal/layout?p_l_id=10160','2014-04-03 16:50:52'),(402,7,'/portal/layout?p_l_id=10160','2014-04-03 16:50:54'),(403,7,'/portal/logout','2014-04-03 16:50:56'),(404,8,'/portal/layout?p_l_id=10160','2014-04-03 16:51:00'),(405,8,'/portal/layout?p_l_id=10160','2014-04-03 16:51:01'),(406,8,'/portal/layout?p_l_id=10152','2014-04-03 16:51:03'),(407,8,'/portal/layout?p_l_id=10152','2014-04-03 16:51:04'),(408,8,'/portal/layout?p_l_id=10152','2014-04-03 16:51:05'),(409,8,'/portal/session_click','2014-04-03 16:51:05'),(410,8,'/portal/layout?p_l_id=10152','2014-04-03 16:51:07'),(411,8,'/portal/layout?p_l_id=10152','2014-04-03 16:51:07'),(412,8,'/portal/session_click','2014-04-03 16:51:07'),(413,8,'/portal/layout?p_l_id=10160','2014-04-03 16:51:14'),(414,8,'/portal/layout?p_l_id=10160','2014-04-03 16:51:17'),(415,8,'/portal/logout','2014-04-03 16:51:18'),(416,9,'/portal/layout?p_l_id=10160','2014-04-03 16:51:22'),(417,9,'/portal/layout?p_l_id=10160','2014-04-03 16:51:25'),(418,9,'/portal/layout?p_l_id=10152','2014-04-03 16:51:26'),(419,9,'/portal/layout?p_l_id=10152','2014-04-03 16:51:28'),(420,9,'/portal/layout?p_l_id=10152','2014-04-03 16:51:28'),(421,9,'/portal/session_click','2014-04-03 16:51:28'),(422,9,'/portal/session_click','2014-04-03 16:51:31'),(423,9,'/portal/layout?p_l_id=10152','2014-04-03 16:51:31'),(424,9,'/portal/layout?p_l_id=10152','2014-04-03 16:51:31'),(425,9,'/portal/layout?p_l_id=10152','2014-04-03 16:51:34'),(426,9,'/portal/layout?p_l_id=10152','2014-04-03 16:51:35'),(427,9,'/portal/layout?p_l_id=10152','2014-04-03 16:51:35'),(428,9,'/portal/layout?p_l_id=10160','2014-04-03 16:51:37'),(429,9,'/portal/layout?p_l_id=10152','2014-04-03 16:51:38'),(430,9,'/portal/layout?p_l_id=10152','2014-04-03 16:51:39'),(431,9,'/portal/layout?p_l_id=10152','2014-04-03 16:51:40'),(432,9,'/portal/layout?p_l_id=10152','2014-04-03 16:51:43'),(433,9,'/portal/layout?p_l_id=10152','2014-04-03 16:51:43'),(434,9,'/portal/json_service','2014-04-03 16:51:44'),(435,9,'/portal/layout?p_l_id=10160','2014-04-03 16:51:47'),(436,9,'/portal/layout?p_l_id=10152','2014-04-03 16:51:48'),(437,9,'/portal/layout?p_l_id=10152','2014-04-03 16:51:49'),(438,9,'/portal/layout?p_l_id=10152','2014-04-03 16:51:51'),(439,9,'/portal/layout?p_l_id=10152','2014-04-03 16:51:52'),(440,9,'/portal/json_service','2014-04-03 16:51:53'),(441,9,'/portal/json_service','2014-04-03 16:51:53'),(442,9,'/portal/layout?p_l_id=10152','2014-04-03 16:51:55'),(443,9,'/portal/layout?p_l_id=10152','2014-04-03 16:51:55'),(444,9,'/portal/json_service','2014-04-03 16:51:56'),(445,9,'/portal/layout?p_l_id=10160','2014-04-03 16:51:58'),(446,9,'/portal/logout','2014-04-03 16:51:59'),(447,10,'/portal/layout?p_l_id=10160','2014-04-03 16:52:04'),(448,10,'/portal/update_terms_of_use?doAsUserId=&referer=%2Fc%3FdoAsUserId%3D','2014-04-03 16:52:05'),(449,10,'/portal/layout?p_l_id=10160','2014-04-03 16:52:05'),(450,10,'/portal/update_reminder_query','2014-04-03 16:52:06'),(451,10,'/portal/layout?p_l_id=10160','2014-04-03 16:52:06'),(452,10,'/portal/layout?p_l_id=10160','2014-04-03 16:52:08'),(453,10,'/portal/logout','2014-04-03 16:52:10'),(471,12,'/portal/layout?p_l_id=10160','2014-04-03 16:52:43'),(472,12,'/portal/layout?p_l_id=10160','2014-04-03 16:52:45'),(473,12,'/portal/logout','2014-04-03 16:52:46'),(474,13,'/portal/layout?p_l_id=10160','2014-04-03 16:52:51'),(475,13,'/portal/layout?p_l_id=10160','2014-04-03 16:52:58'),(476,13,'/portal/layout?p_l_id=10160','2014-04-03 16:53:00'),(477,13,'/portal/logout','2014-04-03 16:53:02'),(478,14,'/portal/layout?p_l_id=10160','2014-04-03 16:53:06'),(479,14,'/portal/layout?p_l_id=10160','2014-04-03 16:53:07'),(480,14,'/portal/layout?p_l_id=10152','2014-04-03 16:53:09'),(481,14,'/portal/layout?p_l_id=10152','2014-04-03 16:53:10'),(482,14,'/portal/layout?p_l_id=10152','2014-04-03 16:53:11'),(483,14,'/portal/session_click','2014-04-03 16:53:11'),(484,14,'/portal/layout?p_l_id=10152','2014-04-03 16:53:13'),(485,14,'/portal/layout?p_l_id=10152','2014-04-03 16:53:13'),(486,14,'/portal/session_click','2014-04-03 16:53:13'),(487,14,'/portal/layout?p_l_id=10160','2014-04-03 16:53:14'),(488,14,'/portal/layout?p_l_id=10152','2014-04-03 16:53:15'),(489,14,'/portal/layout?p_l_id=10152','2014-04-03 16:53:17'),(490,14,'/portal/layout?p_l_id=10152','2014-04-03 16:53:18'),(491,14,'/portal/layout?p_l_id=10152','2014-04-03 16:53:20'),(492,14,'/portal/layout?p_l_id=10152','2014-04-03 16:53:20'),(493,14,'/portal/layout?p_l_id=10160','2014-04-03 16:53:26'),(494,14,'/portal/layout?p_l_id=10160','2014-04-03 16:53:29'),(495,14,'/portal/logout','2014-04-03 16:53:30'),(496,15,'/portal/layout?p_l_id=10160','2014-04-03 16:53:34'),(497,15,'/portal/layout?p_l_id=10160','2014-04-03 16:53:40'),(498,15,'/layout_management/update_page','2014-04-03 16:53:42'),(499,15,'/portal/layout?p_l_id=10566','2014-04-03 16:53:43'),(500,15,'/portal/layout?p_l_id=10160','2014-04-03 16:53:45'),(501,15,'/portal/layout?p_l_id=10566','2014-04-03 16:53:46'),(502,15,'/portal/layout?p_l_id=10160','2014-04-03 16:53:48'),(503,15,'/portal/layout?p_l_id=10566','2014-04-03 16:53:50'),(504,15,'/portal/update_layout','2014-04-03 16:53:54'),(505,15,'/portal/layout?p_l_id=10566','2014-04-03 16:53:55'),(506,15,'/portal/layout?p_l_id=10566','2014-04-03 16:53:57'),(507,15,'/portal/layout?p_l_id=10566','2014-04-03 16:53:57'),(508,15,'/portal/layout?p_l_id=10566','2014-04-03 16:53:59'),(509,15,'/portal/layout?p_l_id=10566','2014-04-03 16:54:02'),(510,15,'/portal/layout?p_l_id=10566','2014-04-03 16:54:02'),(511,15,'/portal/layout?p_l_id=10566','2014-04-03 16:54:04'),(512,15,'/portal/layout?p_l_id=10566','2014-04-03 16:54:05'),(513,15,'/portal/layout?p_l_id=10566','2014-04-03 16:54:08'),(514,15,'/portal/layout?p_l_id=10566','2014-04-03 16:54:19'),(515,15,'/portal/layout?p_l_id=10566','2014-04-03 16:54:20'),(516,15,'/portal/layout?p_l_id=10566','2014-04-03 16:54:22'),(517,15,'/portal/layout?p_l_id=10566','2014-04-03 16:54:23'),(518,15,'/portal/layout?p_l_id=10566','2014-04-03 16:54:26'),(519,15,'/portal/layout?p_l_id=10566','2014-04-03 16:54:26'),(520,15,'/portal/layout?p_l_id=10566','2014-04-03 16:54:28'),(521,15,'/portal/layout?p_l_id=10160','2014-04-03 16:55:35'),(522,15,'/portal/layout?p_l_id=10160','2014-04-03 16:55:38'),(523,15,'/portal/logout','2014-04-03 16:55:39'),(550,17,'/portal/layout?p_l_id=10160','2014-04-03 16:56:22'),(551,17,'/portal/update_terms_of_use?doAsUserId=&referer=%2Fc%3FdoAsUserId%3D','2014-04-03 16:56:23'),(552,17,'/portal/layout?p_l_id=10160','2014-04-03 16:56:23'),(553,17,'/portal/update_reminder_query','2014-04-03 16:56:24'),(554,17,'/portal/layout?p_l_id=10160','2014-04-03 16:56:24'),(555,17,'/portal/layout?p_l_id=10160','2014-04-03 16:56:26'),(556,17,'/portal/logout','2014-04-03 16:56:28'),(557,18,'/portal/layout?p_l_id=10160','2014-04-03 16:56:32'),(558,18,'/portal/layout?p_l_id=10160','2014-04-03 16:56:35'),(559,18,'/portal/logout','2014-04-03 16:56:37'),(560,19,'/portal/layout?p_l_id=10160','2014-04-03 16:56:41'),(561,19,'/portal/layout?p_l_id=10598','2014-04-03 16:56:42'),(562,19,'/portal/layout?p_l_id=10598','2014-04-03 16:56:45'),(563,19,'/portal/layout?p_l_id=10598','2014-04-03 16:56:48'),(564,19,'/portal/layout?p_l_id=10598','2014-04-03 16:56:49'),(565,19,'/portal/layout?p_l_id=10598','2014-04-03 16:56:50'),(566,19,'/portal/layout?p_l_id=10598','2014-04-03 16:56:50'),(567,19,'/portal/layout?p_l_id=10160','2014-04-03 16:56:59'),(568,19,'/portal/layout?p_l_id=10160','2014-04-03 16:57:02'),(569,19,'/portal/logout','2014-04-03 16:57:03'),(570,20,'/portal/layout?p_l_id=10160','2014-04-03 16:57:07'),(571,20,'/portal/layout?p_l_id=10160','2014-04-03 16:57:11'),(572,20,'/portal/layout?p_l_id=10152','2014-04-03 16:57:12'),(573,20,'/portal/layout?p_l_id=10152','2014-04-03 16:57:14'),(574,20,'/portal/layout?p_l_id=10152','2014-04-03 16:57:16'),(575,20,'/portal/layout?p_l_id=10152','2014-04-03 16:57:18'),(576,20,'/portal/layout?p_l_id=10152','2014-04-03 16:57:18'),(577,20,'/portal/layout?p_l_id=10152','2014-04-03 16:57:19'),(578,20,'/portal/layout?p_l_id=10160','2014-04-03 16:57:21'),(579,20,'/portal/layout?p_l_id=10152','2014-04-03 16:57:22'),(580,20,'/portal/layout?p_l_id=10152','2014-04-03 16:57:24'),(581,20,'/portal/layout?p_l_id=10152','2014-04-03 16:57:26'),(582,20,'/portal/layout?p_l_id=10152','2014-04-03 16:57:27'),(583,20,'/portal/layout?p_l_id=10152','2014-04-03 16:57:29'),(584,20,'/portal/layout?p_l_id=10152','2014-04-03 16:57:30'),(585,20,'/portal/layout?p_l_id=10160','2014-04-03 16:57:31'),(586,20,'/portal/layout?p_l_id=10152','2014-04-03 16:57:32'),(587,20,'/portal/layout?p_l_id=10152','2014-04-03 16:57:34'),(588,20,'/portal/layout?p_l_id=10152','2014-04-03 16:57:35'),(589,20,'/portal/layout?p_l_id=10152','2014-04-03 16:57:36'),(590,20,'/portal/layout?p_l_id=10152','2014-04-03 16:57:37'),(591,20,'/portal/layout?p_l_id=10152','2014-04-03 16:57:46'),(592,20,'/portal/layout?p_l_id=10152','2014-04-03 16:57:47'),(593,20,'/portal/layout?p_l_id=10636','2014-04-03 16:57:49'),(594,20,'/portal/layout?p_l_id=10636','2014-04-03 16:57:50'),(595,20,'/portal/update_layout','2014-04-03 16:57:54'),(596,20,'/portal/layout?p_l_id=10636','2014-04-03 16:57:57'),(597,20,'/portal/layout?p_l_id=10636','2014-04-03 16:57:58'),(598,20,'/portal/layout?p_l_id=10636','2014-04-03 16:57:59'),(599,20,'/portal/layout?p_l_id=10636','2014-04-03 16:58:00'),(600,20,'/portal/layout?p_l_id=10636','2014-04-03 16:58:00'),(601,20,'/portal/layout?p_l_id=10636','2014-04-03 16:58:03'),(602,20,'/portal/layout?p_l_id=10636','2014-04-03 16:58:05'),(603,20,'/portal/layout?p_l_id=10636','2014-04-03 16:58:07'),(604,20,'/portal/layout?p_l_id=10636','2014-04-03 16:58:09'),(605,20,'/portal/layout?p_l_id=10636','2014-04-03 16:58:10'),(606,20,'/portal/emoticons','2014-04-03 16:58:11'),(607,20,'/portal/layout?p_l_id=10636','2014-04-03 16:58:12'),(608,20,'/portal/layout?p_l_id=10636','2014-04-03 16:58:13'),(609,20,'/portal/layout?p_l_id=10160','2014-04-03 16:58:18'),(610,20,'/portal/layout?p_l_id=10160','2014-04-03 16:58:21'),(611,20,'/portal/logout','2014-04-03 16:58:22'),(612,21,'/portal/layout?p_l_id=10160','2014-04-03 16:58:26'),(613,21,'/portal/layout?p_l_id=10160','2014-04-03 16:58:30'),(614,21,'/layout_management/update_page','2014-04-03 16:58:33'),(615,21,'/portal/layout?p_l_id=10651','2014-04-03 16:58:33'),(616,21,'/portal/layout?p_l_id=10160','2014-04-03 16:58:35'),(617,21,'/portal/layout?p_l_id=10651','2014-04-03 16:58:36'),(618,21,'/portal/layout?p_l_id=10160','2014-04-03 16:58:39'),(619,21,'/portal/layout?p_l_id=10651','2014-04-03 16:58:40'),(620,21,'/portal/update_layout','2014-04-03 16:58:43'),(621,21,'/portal/layout?p_l_id=10651','2014-04-03 16:58:44'),(622,21,'/portal/layout?p_l_id=10651','2014-04-03 16:58:47'),(623,21,'/portal/layout?p_l_id=10651','2014-04-03 16:58:47'),(624,21,'/portal/layout?p_l_id=10160','2014-04-03 16:58:51'),(625,21,'/portal/layout?p_l_id=10651','2014-04-03 16:58:52'),(626,21,'/portal/layout?p_l_id=10651','2014-04-03 16:58:53'),(627,21,'/portal/layout?p_l_id=10651','2014-04-03 16:58:55'),(628,21,'/portal/layout?p_l_id=10651','2014-04-03 16:58:55'),(629,21,'/portal/layout?p_l_id=10160','2014-04-03 16:59:01'),(630,21,'/portal/layout?p_l_id=10160','2014-04-03 16:59:03'),(631,21,'/portal/logout','2014-04-03 16:59:05'),(632,22,'/portal/layout?p_l_id=10160','2014-04-03 16:59:08'),(633,22,'/portal/layout?p_l_id=10160','2014-04-03 16:59:12'),(634,22,'/portal/layout?p_l_id=10152','2014-04-03 16:59:14'),(635,22,'/portal/layout?p_l_id=10152','2014-04-03 16:59:15'),(636,22,'/portal/layout?p_l_id=10152','2014-04-03 16:59:16'),(637,22,'/portal/layout?p_l_id=10152','2014-04-03 16:59:18'),(638,22,'/portal/layout?p_l_id=10152','2014-04-03 16:59:18'),(639,22,'/portal/layout?p_l_id=10152','2014-04-03 16:59:19'),(640,22,'/portal/layout?p_l_id=10160','2014-04-03 16:59:20'),(641,22,'/portal/layout?p_l_id=10152','2014-04-03 16:59:22'),(642,22,'/portal/layout?p_l_id=10152','2014-04-03 16:59:23'),(643,22,'/portal/layout?p_l_id=10152','2014-04-03 16:59:25'),(644,22,'/portal/layout?p_l_id=10152','2014-04-03 16:59:27'),(645,22,'/portal/layout?p_l_id=10152','2014-04-03 16:59:29'),(646,22,'/portal/layout?p_l_id=10152','2014-04-03 16:59:29'),(647,22,'/portal/layout?p_l_id=10667','2014-04-03 16:59:33'),(648,22,'/portal/layout?p_l_id=10667','2014-04-03 16:59:34'),(649,22,'/portal/update_layout','2014-04-03 16:59:38'),(650,22,'/portal/layout?p_l_id=10667','2014-04-03 16:59:40'),(651,22,'/portal/layout?p_l_id=10667','2014-04-03 16:59:41'),(652,22,'/portal/update_layout','2014-04-03 16:59:45'),(653,22,'/portal/layout?p_l_id=10667','2014-04-03 16:59:48'),(654,22,'/portal/layout?p_l_id=10667','2014-04-03 16:59:49'),(655,22,'/portal/update_layout','2014-04-03 16:59:53'),(656,22,'/portal/layout?p_l_id=10667','2014-04-03 16:59:54'),(657,22,'/portal/layout?p_l_id=10160','2014-04-03 17:00:03'),(658,22,'/portal/layout?p_l_id=10160','2014-04-03 17:00:05'),(659,22,'/portal/logout','2014-04-03 17:00:07'),(660,23,'/portal/layout?p_l_id=10160','2014-04-03 17:00:10'),(661,23,'/portal/layout?p_l_id=10160','2014-04-03 17:00:13'),(662,23,'/portal/layout?p_l_id=10152','2014-04-03 17:00:15'),(663,23,'/portal/layout?p_l_id=10152','2014-04-03 17:00:16'),(664,23,'/portal/layout?p_l_id=10152','2014-04-03 17:00:18'),(665,23,'/portal/layout?p_l_id=10152','2014-04-03 17:00:19'),(666,23,'/portal/layout?p_l_id=10152','2014-04-03 17:00:19'),(667,23,'/portal/layout?p_l_id=10152','2014-04-03 17:00:21'),(668,23,'/portal/layout?p_l_id=10160','2014-04-03 17:00:22'),(669,23,'/portal/layout?p_l_id=10152','2014-04-03 17:00:23'),(670,23,'/portal/layout?p_l_id=10152','2014-04-03 17:00:24'),(671,23,'/portal/layout?p_l_id=10152','2014-04-03 17:00:26'),(672,23,'/portal/layout?p_l_id=10152','2014-04-03 17:00:28'),(673,23,'/portal/layout?p_l_id=10152','2014-04-03 17:00:30'),(674,23,'/portal/layout?p_l_id=10152','2014-04-03 17:00:30'),(675,23,'/portal/layout?p_l_id=10682','2014-04-03 17:00:34'),(676,23,'/portal/layout?p_l_id=10682','2014-04-03 17:00:35'),(677,23,'/portal/update_layout','2014-04-03 17:00:38'),(678,23,'/portal/layout?p_l_id=10682','2014-04-03 17:00:39'),(679,23,'/portal/layout?p_l_id=10682','2014-04-03 17:00:43'),(680,23,'/portal/layout?p_l_id=10682','2014-04-03 17:00:43'),(681,23,'/portal/layout?p_l_id=10682','2014-04-03 17:00:45'),(682,23,'/portal/layout?p_l_id=10682','2014-04-03 17:00:46'),(683,23,'/portal/layout?p_l_id=10682','2014-04-03 17:00:58'),(684,23,'/portal/layout?p_l_id=10682','2014-04-03 17:01:09'),(685,23,'/portal/layout?p_l_id=10682','2014-04-03 17:01:09'),(686,23,'/portal/layout?p_l_id=10160','2014-04-03 17:01:10'),(687,23,'/portal/layout?p_l_id=10152','2014-04-03 17:01:11'),(688,23,'/portal/layout?p_l_id=10152','2014-04-03 17:01:13'),(689,23,'/portal/layout?p_l_id=10152','2014-04-03 17:01:14'),(690,23,'/portal/session_click','2014-04-03 17:01:16'),(691,23,'/portal/layout?p_l_id=10152','2014-04-03 17:01:17'),(692,23,'/portal/layout?p_l_id=10152','2014-04-03 17:01:19'),(693,23,'/portal/layout?p_l_id=10152','2014-04-03 17:01:19'),(694,23,'/portal/layout?p_l_id=10152','2014-04-03 17:01:21'),(695,23,'/portal/layout?p_l_id=10152','2014-04-03 17:01:23'),(696,23,'/portal/layout?p_l_id=10152','2014-04-03 17:01:23'),(697,23,'/portal/layout?p_l_id=10152','2014-04-03 17:01:26'),(698,23,'/portal/layout?p_l_id=10152','2014-04-03 17:01:27'),(699,23,'/portal/layout?p_l_id=10152','2014-04-03 17:01:39'),(700,23,'/portal/layout?p_l_id=10152','2014-04-03 17:01:39'),(701,23,'/portal/layout?p_l_id=10152&_20_folderId=10705&p_p_lifecycle=0&p_p_id=20&_20_struts_action=%2fdocument_library%2fview&p_p_mode=view','2014-04-03 17:01:41'),(702,23,'/portal/layout?p_l_id=10160','2014-04-03 17:01:47'),(703,23,'/portal/layout?p_l_id=10160','2014-04-03 17:01:50'),(704,23,'/portal/logout','2014-04-03 17:01:51'),(705,24,'/portal/layout?p_l_id=10160','2014-04-03 17:01:55'),(706,24,'/portal/layout?p_l_id=10160','2014-04-03 17:01:57'),(707,24,'/portal/layout?p_l_id=10152','2014-04-03 17:01:59'),(708,24,'/portal/layout?p_l_id=10152','2014-04-03 17:02:00'),(709,24,'/portal/layout?p_l_id=10152','2014-04-03 17:02:02'),(710,24,'/portal/session_click','2014-04-03 17:02:02'),(711,24,'/portal/layout?p_l_id=10152','2014-04-03 17:02:03'),(712,24,'/portal/session_click','2014-04-03 17:02:03'),(713,24,'/portal/layout?p_l_id=10152','2014-04-03 17:02:04'),(714,24,'/portal/layout?p_l_id=10152','2014-04-03 17:02:04'),(715,24,'/portal/layout?p_l_id=10160','2014-04-03 17:02:05'),(716,24,'/portal/layout?p_l_id=10152','2014-04-03 17:02:06'),(717,24,'/portal/layout?p_l_id=10152','2014-04-03 17:02:07'),(718,24,'/portal/layout?p_l_id=10152','2014-04-03 17:02:09'),(719,24,'/portal/layout?p_l_id=10152','2014-04-03 17:02:10'),(720,24,'/portal/layout?p_l_id=10152','2014-04-03 17:02:11'),(721,24,'/portal/layout?p_l_id=10152','2014-04-03 17:02:11'),(722,24,'/portal/layout?p_l_id=10160','2014-04-03 17:02:19'),(723,24,'/portal/layout?p_l_id=10160','2014-04-03 17:02:22'),(724,24,'/portal/logout','2014-04-03 17:03:42'),(725,25,'/portal/layout?p_l_id=10160','2014-04-03 17:03:46'),(726,25,'/portal/layout?p_l_id=10160','2014-04-03 17:03:50'),(727,25,'/layout_management/update_page','2014-04-03 17:03:52'),(728,25,'/portal/layout?p_l_id=10713','2014-04-03 17:03:53'),(729,25,'/portal/layout?p_l_id=10160','2014-04-03 17:03:55'),(730,25,'/portal/layout?p_l_id=10713','2014-04-03 17:03:56'),(731,25,'/portal/update_layout','2014-04-03 17:03:59'),(732,25,'/portal/layout?p_l_id=10160','2014-04-03 17:04:00'),(733,25,'/portal/layout?p_l_id=10152','2014-04-03 17:04:02'),(734,25,'/portal/layout?p_l_id=10152','2014-04-03 17:04:03'),(735,25,'/portal/session_click','2014-04-03 17:04:04'),(736,25,'/portal/layout?p_l_id=10152','2014-04-03 17:04:05'),(737,25,'/portal/layout?p_l_id=10152','2014-04-03 17:04:07'),(738,25,'/portal/layout?p_l_id=10152','2014-04-03 17:04:07'),(739,25,'/portal/layout?p_l_id=10160','2014-04-03 17:04:15'),(740,25,'/portal/layout?p_l_id=10160','2014-04-03 17:04:18'),(741,25,'/portal/logout','2014-04-03 17:04:19'),(742,26,'/portal/layout?p_l_id=10160','2014-04-03 17:04:23'),(743,26,'/portal/layout?p_l_id=10160','2014-04-03 17:04:27'),(744,26,'/layout_management/update_page','2014-04-03 17:04:30'),(745,26,'/portal/layout?p_l_id=10725','2014-04-03 17:04:30'),(746,26,'/portal/layout?p_l_id=10160','2014-04-03 17:04:33'),(747,26,'/portal/layout?p_l_id=10725','2014-04-03 17:04:34'),(748,26,'/portal/update_layout','2014-04-03 17:04:38'),(749,26,'/portal/layout?p_l_id=10152','2014-04-03 17:04:39'),(750,26,'/portal/json_service','2014-04-03 17:04:40'),(751,26,'/portal/json_service','2014-04-03 17:04:40'),(752,26,'/portal/session_click','2014-04-03 17:04:41'),(753,26,'/portal/layout?p_l_id=10152','2014-04-03 17:04:42'),(754,26,'/portal/layout?p_l_id=10152','2014-04-03 17:04:42'),(755,26,'/portal/json_service','2014-04-03 17:04:43'),(756,26,'/portal/layout?p_l_id=10160','2014-04-03 17:04:46'),(757,26,'/portal/layout?p_l_id=10725','2014-04-03 17:04:47'),(758,26,'/portal/layout?p_l_id=10725','2014-04-03 17:04:49'),(759,26,'/portal/layout?p_l_id=10725','2014-04-03 17:04:50'),(760,26,'/portal/layout?p_l_id=10725','2014-04-03 17:04:52'),(761,26,'/portal/layout?p_l_id=10725','2014-04-03 17:04:54'),(762,26,'/portal/layout?p_l_id=10725','2014-04-03 17:04:54'),(763,26,'/portal/layout?p_l_id=10160','2014-04-03 17:04:56'),(764,26,'/portal/layout?p_l_id=10725','2014-04-03 17:04:57'),(765,26,'/portal/json_service','2014-04-03 17:04:59'),(766,26,'/portal/layout?p_l_id=10160','2014-04-03 17:05:04'),(767,26,'/portal/layout?p_l_id=10160','2014-04-03 17:05:07'),(768,26,'/portal/logout','2014-04-03 17:05:09'),(769,27,'/portal/layout?p_l_id=10160','2014-04-03 17:05:12'),(770,27,'/portal/layout?p_l_id=10160','2014-04-03 17:05:15'),(771,27,'/portal/layout?p_l_id=10152','2014-04-03 17:05:17'),(772,27,'/portal/layout?p_l_id=10152','2014-04-03 17:05:18'),(773,27,'/portal/layout?p_l_id=10152','2014-04-03 17:05:19'),(774,27,'/portal/layout?p_l_id=10152','2014-04-03 17:05:20'),(775,27,'/portal/layout?p_l_id=10152','2014-04-03 17:05:22'),(776,27,'/portal/layout?p_l_id=10152','2014-04-03 17:05:22'),(777,27,'/portal/layout?p_l_id=10160','2014-04-03 17:05:23'),(778,27,'/portal/layout?p_l_id=10152','2014-04-03 17:05:25'),(779,27,'/portal/layout?p_l_id=10152','2014-04-03 17:05:26'),(780,27,'/portal/layout?p_l_id=10152','2014-04-03 17:05:27'),(781,27,'/portal/layout?p_l_id=10152','2014-04-03 17:05:30'),(782,27,'/portal/layout?p_l_id=10152','2014-04-03 17:05:30'),(783,27,'/portal/json_service','2014-04-03 17:05:31'),(784,27,'/portal/layout?p_l_id=10160','2014-04-03 17:05:33'),(785,27,'/portal/layout?p_l_id=10152','2014-04-03 17:05:35'),(786,27,'/portal/layout?p_l_id=10152','2014-04-03 17:05:36'),(787,27,'/portal/layout?p_l_id=10152','2014-04-03 17:05:38'),(788,27,'/portal/layout?p_l_id=10152','2014-04-03 17:05:40'),(789,27,'/portal/json_service','2014-04-03 17:05:41'),(790,27,'/portal/layout?p_l_id=10160','2014-04-03 17:05:48'),(791,27,'/portal/layout?p_l_id=10160','2014-04-03 17:05:51'),(792,27,'/portal/logout','2014-04-03 17:05:53'),(793,28,'/portal/layout?p_l_id=10160','2014-04-03 17:05:57'),(794,28,'/portal/layout?p_l_id=10160','2014-04-03 17:06:00'),(795,28,'/portal/layout?p_l_id=10152','2014-04-03 17:06:01'),(796,28,'/portal/layout?p_l_id=10152','2014-04-03 17:06:02'),(797,28,'/portal/layout?p_l_id=10152','2014-04-03 17:06:04'),(798,28,'/portal/layout?p_l_id=10152','2014-04-03 17:06:06'),(799,28,'/portal/layout?p_l_id=10152','2014-04-03 17:06:06'),(800,28,'/portal/layout?p_l_id=10152','2014-04-03 17:06:07'),(801,28,'/portal/layout?p_l_id=10160','2014-04-03 17:06:08'),(802,28,'/portal/layout?p_l_id=10152','2014-04-03 17:06:10'),(803,28,'/portal/layout?p_l_id=10152','2014-04-03 17:06:11'),(804,28,'/portal/layout?p_l_id=10152','2014-04-03 17:06:13'),(805,28,'/portal/layout?p_l_id=10152','2014-04-03 17:06:14'),(806,28,'/portal/layout?p_l_id=10152','2014-04-03 17:06:16'),(807,28,'/portal/layout?p_l_id=10152','2014-04-03 17:06:17'),(808,28,'/portal/layout?p_l_id=10160','2014-04-03 17:06:18'),(809,28,'/portal/layout?p_l_id=10152','2014-04-03 17:06:19'),(810,28,'/portal/layout?p_l_id=10152','2014-04-03 17:06:21'),(811,28,'/portal/layout?p_l_id=10152','2014-04-03 17:06:22'),(812,28,'/portal/json_service','2014-04-03 17:06:23'),(813,28,'/portal/json_service','2014-04-03 17:06:25'),(814,28,'/portal/json_service','2014-04-03 17:06:25'),(815,28,'/portal/json_service','2014-04-03 17:06:25'),(816,28,'/portal/layout?p_l_id=10756','2014-04-03 17:06:28'),(817,28,'/portal/layout?p_l_id=10756','2014-04-03 17:06:29'),(818,28,'/portal/update_layout','2014-04-03 17:06:33'),(819,28,'/portal/layout?p_l_id=10756','2014-04-03 17:06:34'),(820,28,'/portal/layout?p_l_id=10160','2014-04-03 17:06:45'),(821,28,'/portal/layout?p_l_id=10160','2014-04-03 17:06:48'),(822,28,'/portal/logout','2014-04-03 17:06:49');
/*!40000 ALTER TABLE `UserTrackerPath` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `User_`
--

DROP TABLE IF EXISTS `User_`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `User_` (
  `uuid_` varchar(75) DEFAULT NULL,
  `userId` bigint(20) NOT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `createDate` datetime DEFAULT NULL,
  `modifiedDate` datetime DEFAULT NULL,
  `defaultUser` tinyint(4) DEFAULT NULL,
  `contactId` bigint(20) DEFAULT NULL,
  `password_` varchar(75) DEFAULT NULL,
  `passwordEncrypted` tinyint(4) DEFAULT NULL,
  `passwordReset` tinyint(4) DEFAULT NULL,
  `passwordModifiedDate` datetime DEFAULT NULL,
  `digest` varchar(255) DEFAULT NULL,
  `reminderQueryQuestion` varchar(75) DEFAULT NULL,
  `reminderQueryAnswer` varchar(75) DEFAULT NULL,
  `graceLoginCount` int(11) DEFAULT NULL,
  `screenName` varchar(75) DEFAULT NULL,
  `emailAddress` varchar(75) DEFAULT NULL,
  `facebookId` bigint(20) DEFAULT NULL,
  `openId` varchar(1024) DEFAULT NULL,
  `portraitId` bigint(20) DEFAULT NULL,
  `languageId` varchar(75) DEFAULT NULL,
  `timeZoneId` varchar(75) DEFAULT NULL,
  `greeting` varchar(255) DEFAULT NULL,
  `comments` longtext,
  `firstName` varchar(75) DEFAULT NULL,
  `middleName` varchar(75) DEFAULT NULL,
  `lastName` varchar(75) DEFAULT NULL,
  `jobTitle` varchar(100) DEFAULT NULL,
  `loginDate` datetime DEFAULT NULL,
  `loginIP` varchar(75) DEFAULT NULL,
  `lastLoginDate` datetime DEFAULT NULL,
  `lastLoginIP` varchar(75) DEFAULT NULL,
  `lastFailedLoginDate` datetime DEFAULT NULL,
  `failedLoginAttempts` int(11) DEFAULT NULL,
  `lockout` tinyint(4) DEFAULT NULL,
  `lockoutDate` datetime DEFAULT NULL,
  `agreedToTermsOfUse` tinyint(4) DEFAULT NULL,
  `active_` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`userId`),
  UNIQUE KEY `IX_615E9F7A` (`companyId`,`emailAddress`),
  UNIQUE KEY `IX_C5806019` (`companyId`,`screenName`),
  UNIQUE KEY `IX_9782AD88` (`companyId`,`userId`),
  UNIQUE KEY `IX_5ADBE171` (`contactId`),
  KEY `IX_3A1E834E` (`companyId`),
  KEY `IX_5204C37B` (`companyId`,`active_`),
  KEY `IX_6EF03E4E` (`companyId`,`defaultUser`),
  KEY `IX_1D731F03` (`companyId`,`facebookId`),
  KEY `IX_89509087` (`companyId`,`openId`(255)),
  KEY `IX_762F63C6` (`emailAddress`),
  KEY `IX_A18034A4` (`portraitId`),
  KEY `IX_E0422BDA` (`uuid_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `User_`
--

LOCK TABLES `User_` WRITE;
/*!40000 ALTER TABLE `User_` DISABLE KEYS */;
INSERT INTO `User_` VALUES ('c02dc602-239d-467a-8e52-02958d4fc5ab',10135,10132,'2014-04-03 16:33:40','2014-04-03 16:33:40',1,10136,'password',0,0,NULL,'5533ed38b5e33c076a804bb4bca644f9,4b2c83b9c14991181b3134f9975c6229,4b2c83b9c14991181b3134f9975c6229','','',0,'10135','default@liferay.com',0,'',0,'en_US','UTC','Welcome!','','','','','','2014-04-03 16:33:40','',NULL,'',NULL,0,0,NULL,1,1),('9a883172-faf9-4a8f-bae3-eb6030ff4a65',10169,10132,'2014-04-03 16:33:40','2014-04-03 17:07:24',0,10170,'qUqP5cyxm6YcTAhz05Hph5gvu9M=',1,0,NULL,'e5d86c6f3672e52795891c3597f20de0,751da756639bc033b572ba2e7849b589,96dc35369e5f37bdf80cb3bda0e8fb3b','what-is-your-father\'s-middle-name','test',0,'test','test@liferay.com',0,'',0,'en_US','UTC','Welcome Test Test!','','Test','','Test','','2014-04-03 17:06:53','127.0.0.1','2014-04-03 17:05:57','127.0.0.1',NULL,0,0,NULL,1,1),('17ee6c75-62e6-45a2-80f9-1d627765dacc',10365,10132,'2014-04-03 16:40:50','2014-04-03 16:40:50',0,10366,'2kdOQznd/gtSt3z8kz/7c1JJYFc=',1,0,NULL,'','','',0,'usersn','userea@liferay.com',0,'',0,'en_US','UTC','Welcome userfn userln!','','userfn','','userln','',NULL,'',NULL,'',NULL,0,0,NULL,0,1),('3be7aa05-cbba-487a-ae1f-6a3b4448536d',10543,10132,'2014-04-03 16:51:43','2014-04-03 16:52:34',0,10544,'w9ROMe8CoaZhmZ0PSMRGW9run60=',1,0,'2014-04-03 16:52:34','0136ce4cb0109115dc5fe03059dbb770,584f10d0b6ef9daa98c5fcf8e55d678e,a34b1d1b5991793198c670ff1b8c3936','what-is-your-father\'s-middle-name','test',0,'userpp','userpp@liferay.com',0,'',0,'en_US','UTC','Welcome userPPfn userPPln!','','userPPfn','','userPPln','','2014-04-03 16:52:43','127.0.0.1','2014-04-03 16:52:04','127.0.0.1',NULL,0,0,NULL,1,1),('e0be1517-78c7-4d0b-8a67-79ccb46b480e',10589,10132,'2014-04-03 16:56:03','2014-04-03 16:56:13',0,10590,'W6ph5Mm5Pz8GgiULbPgzG37mj9g=',1,0,'2014-04-03 16:56:13','9d98818f6a7586654518a63e427065c5,76b619a1eacc598e71a2c42a552baf61,42801ddf9e5076f95d2981bc87f15ff0','what-is-your-father\'s-middle-name','test',0,'usersmsn','usersm@liferay.com',0,'',0,'en_US','UTC','Welcome userSMfn userSMln!','','userSMfn','','userSMln','','2014-04-03 16:56:41','127.0.0.1','2014-04-03 16:56:22','127.0.0.1',NULL,0,0,NULL,1,1),('84585a58-8a50-4615-bb90-e70c5ea5d79e',10743,10132,'2014-04-03 17:05:30','2014-04-03 17:05:30',0,10744,'BuTjWqmYElolhodaj1Y+uhb32Ck=',1,0,NULL,'','','',0,'usercf','usercf@liferay.com',0,'',0,'en_US','UTC','Welcome userCFfn userCFln!','','userCFfn','','userCFln','',NULL,'',NULL,'',NULL,0,0,NULL,0,1);
/*!40000 ALTER TABLE `User_` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Users_Groups`
--

DROP TABLE IF EXISTS `Users_Groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Users_Groups` (
  `userId` bigint(20) NOT NULL,
  `groupId` bigint(20) NOT NULL,
  PRIMARY KEY (`userId`,`groupId`),
  KEY `IX_C4F9E699` (`groupId`),
  KEY `IX_F10B6C6B` (`userId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Users_Groups`
--

LOCK TABLES `Users_Groups` WRITE;
/*!40000 ALTER TABLE `Users_Groups` DISABLE KEYS */;
INSERT INTO `Users_Groups` VALUES (10169,10157),(10169,10357),(10365,10357),(10169,10388),(10169,10435),(10169,10481),(10169,10585),(10169,10617),(10169,10626),(10169,10663),(10169,10678),(10169,10752);
/*!40000 ALTER TABLE `Users_Groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Users_Orgs`
--

DROP TABLE IF EXISTS `Users_Orgs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Users_Orgs` (
  `userId` bigint(20) NOT NULL,
  `organizationId` bigint(20) NOT NULL,
  PRIMARY KEY (`userId`,`organizationId`),
  KEY `IX_7EF4EC0E` (`organizationId`),
  KEY `IX_FB646CA6` (`userId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Users_Orgs`
--

LOCK TABLES `Users_Orgs` WRITE;
/*!40000 ALTER TABLE `Users_Orgs` DISABLE KEYS */;
INSERT INTO `Users_Orgs` VALUES (10365,10375);
/*!40000 ALTER TABLE `Users_Orgs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Users_Permissions`
--

DROP TABLE IF EXISTS `Users_Permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Users_Permissions` (
  `userId` bigint(20) NOT NULL,
  `permissionId` bigint(20) NOT NULL,
  PRIMARY KEY (`userId`,`permissionId`),
  KEY `IX_8AE58A91` (`permissionId`),
  KEY `IX_C26AA64D` (`userId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Users_Permissions`
--

LOCK TABLES `Users_Permissions` WRITE;
/*!40000 ALTER TABLE `Users_Permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `Users_Permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Users_Roles`
--

DROP TABLE IF EXISTS `Users_Roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Users_Roles` (
  `userId` bigint(20) NOT NULL,
  `roleId` bigint(20) NOT NULL,
  PRIMARY KEY (`userId`,`roleId`),
  KEY `IX_C19E5F31` (`roleId`),
  KEY `IX_C1A01806` (`userId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Users_Roles`
--

LOCK TABLES `Users_Roles` WRITE;
/*!40000 ALTER TABLE `Users_Roles` DISABLE KEYS */;
INSERT INTO `Users_Roles` VALUES (10169,10138),(10135,10139),(10169,10141),(10365,10141),(10543,10141),(10589,10141),(10743,10141),(10169,10142),(10365,10142),(10543,10142),(10589,10142),(10743,10142);
/*!40000 ALTER TABLE `Users_Roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Users_Teams`
--

DROP TABLE IF EXISTS `Users_Teams`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Users_Teams` (
  `userId` bigint(20) NOT NULL,
  `teamId` bigint(20) NOT NULL,
  PRIMARY KEY (`userId`,`teamId`),
  KEY `IX_4D06AD51` (`teamId`),
  KEY `IX_A098EFBF` (`userId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Users_Teams`
--

LOCK TABLES `Users_Teams` WRITE;
/*!40000 ALTER TABLE `Users_Teams` DISABLE KEYS */;
INSERT INTO `Users_Teams` VALUES (10365,10381);
/*!40000 ALTER TABLE `Users_Teams` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Users_UserGroups`
--

DROP TABLE IF EXISTS `Users_UserGroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Users_UserGroups` (
  `userGroupId` bigint(20) NOT NULL,
  `userId` bigint(20) NOT NULL,
  PRIMARY KEY (`userGroupId`,`userId`),
  KEY `IX_66FF2503` (`userGroupId`),
  KEY `IX_BE8102D6` (`userId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Users_UserGroups`
--

LOCK TABLES `Users_UserGroups` WRITE;
/*!40000 ALTER TABLE `Users_UserGroups` DISABLE KEYS */;
INSERT INTO `Users_UserGroups` VALUES (10384,10365);
/*!40000 ALTER TABLE `Users_UserGroups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Vocabulary`
--

DROP TABLE IF EXISTS `Vocabulary`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Vocabulary` (
  `vocabularyId` bigint(20) NOT NULL,
  `groupId` bigint(20) DEFAULT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `userId` bigint(20) DEFAULT NULL,
  `userName` varchar(75) DEFAULT NULL,
  `createDate` datetime DEFAULT NULL,
  `modifiedDate` datetime DEFAULT NULL,
  `name` varchar(75) DEFAULT NULL,
  `description` varchar(75) DEFAULT NULL,
  `folksonomy` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`vocabularyId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Vocabulary`
--

LOCK TABLES `Vocabulary` WRITE;
/*!40000 ALTER TABLE `Vocabulary` DISABLE KEYS */;
/*!40000 ALTER TABLE `Vocabulary` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `WebDAVProps`
--

DROP TABLE IF EXISTS `WebDAVProps`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `WebDAVProps` (
  `webDavPropsId` bigint(20) NOT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `createDate` datetime DEFAULT NULL,
  `modifiedDate` datetime DEFAULT NULL,
  `classNameId` bigint(20) DEFAULT NULL,
  `classPK` bigint(20) DEFAULT NULL,
  `props` longtext,
  PRIMARY KEY (`webDavPropsId`),
  UNIQUE KEY `IX_97DFA146` (`classNameId`,`classPK`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `WebDAVProps`
--

LOCK TABLES `WebDAVProps` WRITE;
/*!40000 ALTER TABLE `WebDAVProps` DISABLE KEYS */;
/*!40000 ALTER TABLE `WebDAVProps` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Website`
--

DROP TABLE IF EXISTS `Website`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Website` (
  `websiteId` bigint(20) NOT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `userId` bigint(20) DEFAULT NULL,
  `userName` varchar(75) DEFAULT NULL,
  `createDate` datetime DEFAULT NULL,
  `modifiedDate` datetime DEFAULT NULL,
  `classNameId` bigint(20) DEFAULT NULL,
  `classPK` bigint(20) DEFAULT NULL,
  `url` longtext,
  `typeId` int(11) DEFAULT NULL,
  `primary_` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`websiteId`),
  KEY `IX_96F07007` (`companyId`),
  KEY `IX_4F0F0CA7` (`companyId`,`classNameId`),
  KEY `IX_F960131C` (`companyId`,`classNameId`,`classPK`),
  KEY `IX_1AA07A6D` (`companyId`,`classNameId`,`classPK`,`primary_`),
  KEY `IX_F75690BB` (`userId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Website`
--

LOCK TABLES `Website` WRITE;
/*!40000 ALTER TABLE `Website` DISABLE KEYS */;
INSERT INTO `Website` VALUES (10772,10132,10169,'Test Test','2014-04-03 17:07:24','2014-04-03 17:07:24',10009,10170,'http://www.liferayportal01.com',11029,1);
/*!40000 ALTER TABLE `Website` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `WikiNode`
--

DROP TABLE IF EXISTS `WikiNode`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `WikiNode` (
  `uuid_` varchar(75) DEFAULT NULL,
  `nodeId` bigint(20) NOT NULL,
  `groupId` bigint(20) DEFAULT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `userId` bigint(20) DEFAULT NULL,
  `userName` varchar(75) DEFAULT NULL,
  `createDate` datetime DEFAULT NULL,
  `modifiedDate` datetime DEFAULT NULL,
  `name` varchar(75) DEFAULT NULL,
  `description` longtext,
  `lastPostDate` datetime DEFAULT NULL,
  PRIMARY KEY (`nodeId`),
  UNIQUE KEY `IX_920CD8B1` (`groupId`,`name`),
  UNIQUE KEY `IX_7609B2AE` (`uuid_`,`groupId`),
  KEY `IX_5D6FE3F0` (`companyId`),
  KEY `IX_B480A672` (`groupId`),
  KEY `IX_6C112D7C` (`uuid_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `WikiNode`
--

LOCK TABLES `WikiNode` WRITE;
/*!40000 ALTER TABLE `WikiNode` DISABLE KEYS */;
INSERT INTO `WikiNode` VALUES ('ca9880df-f83c-4bd0-b992-901a4d66e8f0',10401,10388,10132,10169,'Test Test','2014-04-03 16:44:56','2014-04-03 16:44:56','Main','','2014-04-03 16:45:12'),('85f40be9-e553-419b-b911-765221aee724',10413,10388,10132,10169,'Test Test','2014-04-03 16:45:05','2014-04-03 16:45:05','Wiki Node Name','Wiki Node Description',NULL);
/*!40000 ALTER TABLE `WikiNode` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `WikiPage`
--

DROP TABLE IF EXISTS `WikiPage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `WikiPage` (
  `uuid_` varchar(75) DEFAULT NULL,
  `pageId` bigint(20) NOT NULL,
  `resourcePrimKey` bigint(20) DEFAULT NULL,
  `groupId` bigint(20) DEFAULT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `userId` bigint(20) DEFAULT NULL,
  `userName` varchar(75) DEFAULT NULL,
  `createDate` datetime DEFAULT NULL,
  `modifiedDate` datetime DEFAULT NULL,
  `nodeId` bigint(20) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `version` double DEFAULT NULL,
  `minorEdit` tinyint(4) DEFAULT NULL,
  `content` longtext,
  `summary` longtext,
  `format` varchar(75) DEFAULT NULL,
  `head` tinyint(4) DEFAULT NULL,
  `parentTitle` varchar(255) DEFAULT NULL,
  `redirectTitle` varchar(255) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `statusByUserId` bigint(20) DEFAULT NULL,
  `statusByUserName` varchar(75) DEFAULT NULL,
  `statusDate` datetime DEFAULT NULL,
  PRIMARY KEY (`pageId`),
  UNIQUE KEY `IX_3D4AF476` (`nodeId`,`title`,`version`),
  UNIQUE KEY `IX_2CD67C81` (`resourcePrimKey`,`nodeId`,`version`),
  UNIQUE KEY `IX_899D3DFB` (`uuid_`,`groupId`),
  KEY `IX_A2001730` (`format`),
  KEY `IX_C8A9C476` (`nodeId`),
  KEY `IX_E7F635CA` (`nodeId`,`head`),
  KEY `IX_65E84AF4` (`nodeId`,`head`,`parentTitle`),
  KEY `IX_9F7655DA` (`nodeId`,`head`,`parentTitle`,`status`),
  KEY `IX_432F0AB0` (`nodeId`,`head`,`status`),
  KEY `IX_46EEF3C8` (`nodeId`,`parentTitle`),
  KEY `IX_1ECC7656` (`nodeId`,`redirectTitle`),
  KEY `IX_546F2D5C` (`nodeId`,`status`),
  KEY `IX_997EEDD2` (`nodeId`,`title`),
  KEY `IX_E745EA26` (`nodeId`,`title`,`head`),
  KEY `IX_BEA33AB8` (`nodeId`,`title`,`status`),
  KEY `IX_B771D67` (`resourcePrimKey`,`nodeId`),
  KEY `IX_94D1054D` (`resourcePrimKey`,`nodeId`,`status`),
  KEY `IX_FBBE7C96` (`userId`,`nodeId`,`status`),
  KEY `IX_9C0E478F` (`uuid_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `WikiPage`
--

LOCK TABLES `WikiPage` WRITE;
/*!40000 ALTER TABLE `WikiPage` DISABLE KEYS */;
INSERT INTO `WikiPage` VALUES ('5f0d6038-7068-4f28-b284-53387f1e9bf1',10402,10403,10388,10132,10169,'Test Test','2014-04-03 16:44:56','2014-04-03 16:44:56',10401,'FrontPage',1,1,'','New','creole',0,'','',0,10169,'Test Test','2014-04-03 16:44:56'),('354c8731-b4c7-4d4d-9913-7798bdffde28',10414,10403,10388,10132,10169,'Test Test','2014-04-03 16:45:12','2014-04-03 16:45:12',10401,'FrontPage',1.1,0,'Wiki FrontPage Content','','creole',1,'','',0,10169,'Test Test','2014-04-03 16:45:12');
/*!40000 ALTER TABLE `WikiPage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `WikiPageResource`
--

DROP TABLE IF EXISTS `WikiPageResource`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `WikiPageResource` (
  `uuid_` varchar(75) DEFAULT NULL,
  `resourcePrimKey` bigint(20) NOT NULL,
  `nodeId` bigint(20) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`resourcePrimKey`),
  UNIQUE KEY `IX_21277664` (`nodeId`,`title`),
  KEY `IX_BE898221` (`uuid_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `WikiPageResource`
--

LOCK TABLES `WikiPageResource` WRITE;
/*!40000 ALTER TABLE `WikiPageResource` DISABLE KEYS */;
INSERT INTO `WikiPageResource` VALUES ('08285d6d-8aee-41c2-8ebc-548524732436',10403,10401,'FrontPage');
/*!40000 ALTER TABLE `WikiPageResource` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `WorkflowDefinitionLink`
--

DROP TABLE IF EXISTS `WorkflowDefinitionLink`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `WorkflowDefinitionLink` (
  `workflowDefinitionLinkId` bigint(20) NOT NULL,
  `groupId` bigint(20) DEFAULT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `userId` bigint(20) DEFAULT NULL,
  `userName` varchar(75) DEFAULT NULL,
  `createDate` datetime DEFAULT NULL,
  `modifiedDate` datetime DEFAULT NULL,
  `classNameId` bigint(20) DEFAULT NULL,
  `workflowDefinitionName` varchar(75) DEFAULT NULL,
  `workflowDefinitionVersion` int(11) DEFAULT NULL,
  PRIMARY KEY (`workflowDefinitionLinkId`),
  KEY `IX_A8B0D276` (`companyId`),
  KEY `IX_A4DB1F0F` (`companyId`,`workflowDefinitionName`,`workflowDefinitionVersion`),
  KEY `IX_B6EE8C9E` (`groupId`,`companyId`,`classNameId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `WorkflowDefinitionLink`
--

LOCK TABLES `WorkflowDefinitionLink` WRITE;
/*!40000 ALTER TABLE `WorkflowDefinitionLink` DISABLE KEYS */;
/*!40000 ALTER TABLE `WorkflowDefinitionLink` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `WorkflowInstanceLink`
--

DROP TABLE IF EXISTS `WorkflowInstanceLink`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `WorkflowInstanceLink` (
  `workflowInstanceLinkId` bigint(20) NOT NULL,
  `groupId` bigint(20) DEFAULT NULL,
  `companyId` bigint(20) DEFAULT NULL,
  `userId` bigint(20) DEFAULT NULL,
  `userName` varchar(75) DEFAULT NULL,
  `createDate` datetime DEFAULT NULL,
  `modifiedDate` datetime DEFAULT NULL,
  `classNameId` bigint(20) DEFAULT NULL,
  `classPK` bigint(20) DEFAULT NULL,
  `workflowInstanceId` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`workflowInstanceLinkId`),
  KEY `IX_415A7007` (`groupId`,`companyId`,`classNameId`,`classPK`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `WorkflowInstanceLink`
--

LOCK TABLES `WorkflowInstanceLink` WRITE;
/*!40000 ALTER TABLE `WorkflowInstanceLink` DISABLE KEYS */;
/*!40000 ALTER TABLE `WorkflowInstanceLink` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2014-04-03 10:07:59
